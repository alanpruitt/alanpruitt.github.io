## HLTH-150: Mod 01 Summary And Wrap Up Daily Calorie And Macronutrient Balance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 01 Summary & Wrap-Up: Daily Calorie & Macronutrient Balance

Balance Energético, Distribución de Macronutrientes y Disponibilidad Energética


### Step 1: Core Energy Balance & Nutrition Synthesis

Congratulations on completing Module 01! You have established the foundational energy balance principles, Dietary Reference Intakes (DRIs), and evidence-based standards governing human performance and metabolic health:

- Thermodynamics & Energy Equilibrium: Energy Balance equals Energy Intake (caloric consumption) minus Total Daily Energy Expenditure ($\text{TDEE} = \text{BMR/RMR} + \text{TEF} + \text{EEE} + \text{NEAT}$).
- Acceptable Macronutrient Distribution Ranges (AMDR): Carbohydrates ($45\text{--}65\%$), Fats ($20\text{--}35\%$), and Proteins ($10\text{--}35\%$) establish the baseline macronutrient architecture for active individuals and athletes.
- Energy Availability (EA) & REDs: Maintaining an optimal $\text{EA} \ge 45\text{ kcal/kg FFM/day}$ protects endocrine, bone, and metabolic function, whereas $\text{EA} < 30\text{ kcal/kg FFM/day}$ triggers Relative Energy Deficiency in Sport.
- Federal Dietary Standards SSoT: All sports nutrition prescriptions prioritize the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and current Dietary Guidelines for Americans (DGA) over commercial fad diets.

### Step 2: Workplace Intelligence & AI Nutritional Auditing

In sports nutrition, clinical dietetics, and performance coaching, professionals leverage generative AI preceptors to calculate energy equations, estimate basal metabolic rate (BMR), and audit client dietary intake logs.

- AI Mathematical Auditing: Sports dietitians prompt AI tools to execute energy equations (Mifflin-St Jeor / Cunningham) and cross-verify macronutrient ratios.
- Delimiter Security Protocol (###): Enclosing client biometric profiles (age, body mass, height, physical activity factor) inside triple hashes ( ### ) ensures clean data boundary isolation during automated preceptor queries.
- Clinical Auditing & Safeguards: Practitioners audit AI outputs against federal standards (PAGA 2018 & DGA) to guarantee client safety and eliminate Low Energy Availability (LEA) risks.

### Step 3: Module 01 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 02:

English Response: TDEE comprises Basal/Resting Metabolic Rate (BMR/RMR ~60–75%) , Thermic Effect of Food (TEF ~10%) , Exercise Energy Expenditure (EEE) , and Non-Exercise Activity Thermogenesis (NEAT) .

Respuesta en Español: El TDEE comprende la Tasa Metabólica Basal/en Reposo (BMR/RMR ~60–75%) , el Efecto Térmico de los Alimentos (TEF ~10%) , el Gasto Energético por Ejercicio (EEE) y la Termogénesis por Actividad No Asociada al Ejercicio (NEAT) .

English Response: Carbohydrates: 45% to 65% of total daily calories; Dietary Fats: 20% to 35% ; Protein: 10% to 35% (with active individuals scaled to 1.2–2.0 g/kg/day).

Respuesta en Español: Carbohidratos: 45% a 65% de las calorías diarias totales; Grasas: 20% a 35% ; Proteínas: 10% a 35% (escalando a 1.2–2.0 g/kg/día en personas activas).

English Response: Energy Availability is dietary energy intake minus exercise energy expenditure, normalized to Fat-Free Mass ($\text{FFM}$). Low energy availability ($< 30\text{ kcal/kg FFM/day}$) suppresses endocrine, reproductive, bone, and metabolic health (Relative Energy Deficiency in Sport / REDs).

Respuesta en Español: La Disponibilidad Energética es la ingesta calórica menos el gasto por ejercicio, respecto a la Masa Libre de Grasa ($\text{FFM}$). La baja disponibilidad ($< 30\text{ kcal/kg FFM/día}$) altera la función endocrina, ósea y metabólica (síndrome REDs).

English Response: TEF represents the energy required to digest, absorb, metabolize, and store food nutrients, accounting for approximately 10% of daily caloric expenditure (with protein exhibiting the highest thermic cost).

Respuesta en Español: El TEF representa la energía necesaria para digerir, absorber, metabolizar y almacenar los nutrientes, representando aproximadamente el 10% del gasto calórico diario (siendo la proteína la que mayor costo térmico presenta).

English Response: Enclosing client biometric and nutritional profile data inside triple hashes (`###`) ensures clean data boundary isolation, prevents prompt drift, and maintains precise alignment with DGA and PAGA 2018 standards.

Respuesta en Español: Encapitular los datos biométricos y de perfil nutricional del cliente entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas DGA y PAGA 2018.

English Response: Extreme ambient desert heat accelerates sweat losses and electrolyte depletion, which impair thermoregulation and cardiovascular efficiency, making climate-controlled indoor fueling strategies vital.

Respuesta en Español: El calor extremo del desierto acelera la pérdida de sudor y el agotamiento de electrolitos, los cuales alteran la termorregulación y la eficiencia cardiovascular, haciendo vitales las estrategias de nutrición en interiores climatizados.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: NEAT represents energy expended for all daily activities outside of sleeping, eating, and structured exercise (e.g., fidgeting, standing, occupational movement). It varies significantly up to 2,000 kcal/day between individuals based on lifestyle.

Respuesta en Español: El NEAT representa la energía gastada en todas las actividades diarias fuera del sueño, alimentación y ejercicio estructurado (ej. deambulación, estar de pie, movimientos ocupacionales). Varía significativamente hasta en 2,000 kcal/día entre personas.


### AI Simulation Workspace • Energy Balance Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive synthesis connecting metabolic math, AMDR distribution, and climate-adapted fueling:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Module 01 Energy Balance Synthesis ###:
Role: Academic Sports Nutritionist and Clinical Dietetic Mentor in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA / USDA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Components of Total Daily Energy Expenditure (BMR, TEF, EEE, NEAT).
   Key Point: Federal AMDR percentage splits (Carbohydrates 45-65%, Protein 10-35%, Fats 20-35%).
   Key Point: Energy Availability thresholds (Optimal >=45 vs. Low Energy Availability <30 kcal/kg FFM/day).
Step 2: Detail how proper whole-food meal timing and hydration support metabolic stability in high-heat desert environments.
Step 3: Keep all inputs and structured recommendations wrapped within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 02 — Carbohydrates & Glycogen Kinetics

In plain English, next week in Module 02: Carbohydrates & Glycogen you will learn how your body breaks down whole-food carbohydrates (like oats, beans, corn tortillas, and fruit) and stores them in your muscles and liver as glycogen—your body's high-octane fuel tank. Why it matters: heat stress in Yuma burns through muscle glycogen faster, so athletes and field workers hit 'the wall' early if their carbohydrate plan is too low.

- Pattern (Context): Comparing complex, fiber-rich whole-food carbohydrates against refined sugars and evaluating glycogen depletion during prolonged desert exercise.
- Rule (Constraint): Prescribing daily carbohydrate targets ( 3–10 g/kg/day based on training volume) and fiber goals (14 g per 1,000 kcal) under 2025–2030 DGA .
- Solve (Intervention): Completing Mod 02 Discussion: Glycogen Fueling in the Heat and Mod 02 Lab: Carbohydrate & Glycogen Fueling Plan .

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Summary & Wrap-Up: Daily Calorie & Macronutrient Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 01: Resumen y Evaluación

Balance Energético, Distribución de Macronutrientes y Disponibilidad Energética


### Step 1: Síntesis de Balance Energético y Nutrición

¡Felicitaciones por completar el Módulo 01! Ha establecido los principios fundamentales del balance energético, las Ingestas Dietéticas de Referencia (DRI) y los estándares basados en evidencia:

- Termodinámica y Equilibrio Energético: Balance Energético = Ingesta Calórica menos Gasto Energético Diario Total ($\text{TDEE} = \text{BMR/RMR} + \text{TEF} + \text{EEE} + \text{NEAT}$).
- Rangos AMDR: Carbohidratos ($45\text{ a }65\%$), Grasas ($20\text{ a }35\%$) y Proteínas ($10\text{ a }35\%$) proporcionan la arquitectura nutricional para personas activas.
- Disponibilidad Energética ($\text{EA}$): Mantener una $\text{EA} \ge 45\text{ kcal/kg FFM/día}$ protege la salud ósea y metabólica, evitando el síndrome REDs ($< 30\text{ kcal/kg FFM/día}$).
- Pautas Federales SSoT: Todas las recomendaciones priorizan las Guías Alimentarias (DGA) y las Pautas PAGA 2018 (2.ª ed.) sobre las modas comerciales.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría con IA

En la nutrición deportiva y el entrenamiento de salud, los profesionales utilizan IA generativa para calcular requerimientos energéticos, estimar el metabolismo basal y auditar registros alimentarios.

- Auditoría Matemática Asistida por IA: Verificación de fórmulas energéticas (Mifflin-St Jeor) y cálculo de macronutrientes.
- Seguridad con Delimitadores (###): Uso de tres numerales ( ### ) para aislar datos biométricos.
- Verificación Clínica: Contraste de resultados frente a pautas federales para asegurar planes seguros y evitar riesgos de baja disponibilidad energética.

### Step 3: Autoevaluación del Módulo 01

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 02:


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: HLTH-150 Sintesis Modulo 01 ###:
Role: Mentor Academico de Nutricion Deportiva y Dietetica Clinica.
SSoT: Guias Alimentarias para los Estadounidenses (DGA / USDA) y Pautas PAGA 2018 (2.a edicion).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Componentes del TDEE (BMR, TEF, EEE, NEAT).
   Key Point: Rangos AMDR federales (Carbohidratos 45-65%, Proteina 10-35%, Grasas 20-35%).
   Key Point: Umbrales de Disponibilidad Energetica (Optima >=45 vs. Baja <30 kcal/kg FFM/dia).
Step 2: Detallar como el horario de comidas e hidratacion apoyan la estabilidad metabolica en el desierto de Yuma.
Step 3: Mantener todos los datos entre delimitadores (###).
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 02 — Carbohidratos y Cinética del Glucógeno

En palabras sencillas (Contexto Norteño): el glucógeno es el tanque de reserva que guardas en los músculos y el hígado cuando comes carbohidratos de verdad como frijoles, avena, arroz, tortillas de maíz y fruta. Si los términos bioquímicos se ponen pesados la próxima semana, concéntrate primero en calcular cuántos gramos de carbohidrato por kilo de peso ( 3 a 10 g/kg/día ) necesita tu cliente para no quedarse sin pila bajo el sol de Yuma.

- Patrón (Contexto): Diferenciar los carbohidratos complejos ricos en fibra de los azúcares refinados y evaluar el gasto de glucógeno en el calor.
- Regla (Restricción): Aplicar las metas de carbohidratos ( 3–10 g/kg/día según carga física) y fibra dietética de DGA 2025–2030 .
- Solución (Intervención): Completar el Foro del Mód 02 (Glycogen Fueling in the Heat) y el Laboratorio del Mód 02 (Carbohydrate & Glycogen Fueling Plan) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 01 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 01:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 01)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
