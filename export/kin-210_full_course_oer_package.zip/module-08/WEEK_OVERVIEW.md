## Week 08: Cardiorespiratory Training & Midterm Evaluation

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Stage training organizes cardio workouts into three progressive heart-rate and breathing zones so clients build stamina without overtraining.** Stage I builds a steady aerobic base where you can hold a conversation, Stage II introduces lactate-threshold intervals, and Stage III trains peak power. This week also includes our Module 08 Midterm Student Course Evaluation.
>
> **Español (Norteño):** El entrenamiento cardiovascular por etapas lleva al cliente desde caminar a buen paso hasta hacer intervalos intensos de forma segura y medida. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar las tres etapas de cardio y completar tu Evaluación de Medio Término.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** March 2, 2027 - March 8, 2027  
**Weekly Due Date:** Monday, March 8, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 08: Cardiorespiratory Training Programming & Midterm Evaluation** (`module-08_cardio_programming.md` / `module-08_cardio_programming.html`)
  * *NASM OPT & Clinical Focus:* NASM Stage I, II, and III Cardiorespiratory Training, VT1/VT2 Zones & Midterm Course Evaluation
  * *Deliverables:* Mod 08 Coaching Sprint Simulation: NASM Stage I, II & III Cardiorespiratory Periodization | Mod 08 Lab & Simulation (GY 116): Submaximal Talk Test (VT1) & Stage I–II Interval Programming Lab | Mod 08: Midterm Student Course Evaluation (Replaces Weekly Discussion)

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, March 2, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, March 8, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
