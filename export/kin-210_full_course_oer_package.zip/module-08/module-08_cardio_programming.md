## Module 08: Cardiorespiratory Training Programming & Midterm Evaluation

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Stage training organizes cardio workouts into three progressive heart-rate and breathing zones so clients build stamina without overtraining.** Stage I builds a steady aerobic base where you can hold a conversation, Stage II introduces lactate-threshold intervals, and Stage III trains peak power. This week also includes our Module 08 Midterm Student Course Evaluation.
>
> **Español (Norteño):** El entrenamiento cardiovascular por etapas lleva al cliente desde caminar a buen paso hasta hacer intervalos intensos de forma segura y medida. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar las tres etapas de cardio y completar tu Evaluación de Medio Término.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 08: Cardiorespiratory Training & Midterm Evaluation (March 2, 2027 - March 8, 2027)  
**NASM OPT & Clinical Focus:** NASM Stage I, II, and III Cardiorespiratory Training, VT1/VT2 Zones & Midterm Course Evaluation  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, March 8, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 8.1:** Design progressive NASM Stage I (65–75% HRmax / VT1), Stage II (76–85% HRmax), and Stage III (86–95% HRmax / VT2) cardiorespiratory programs aligned with PAGA 2018 and ACSM 12th Edition guidelines, and complete the Midterm Student Course Evaluation.
* **LO 8.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 8.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Stage training organizes cardio workouts into three progressive heart-rate and breathing zones so clients build stamina without overtraining.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{NASM Cardio Stages}: \text{Stage I } (65\text{–}75\%\text{ HR}_{\max}) \rightarrow \text{Stage II } (76\text{–}85\%\text{ HR}_{\max}) \rightarrow \text{Stage III } (86\text{–}95\%\text{ HR}_{\max})$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Stage I aerobic base building (RPE 12–13, below Ventilatory Threshold 1) for cardiometabolic disease management.
* **Path B (Athletic & Human Performance):** Stage II and Stage III work-to-recovery interval periodization to raise Maximum Oxygen Uptake (VO₂ Max) and lactate threshold.
* **Path C (General Fitness & Lifestyle Coaching):** Structuring 150–300 minutes/week of heat-adapted Stage I and Stage II sessions for Yuma residents.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client S.B. | Age: 34 | Location: Yuma, AZ | Goal: Improve 5K race pace and aerobic fitness | Error: Performs Stage III high-intensity intervals (90% HRmax) 5 days in a row outdoors at 5:00 PM (101°F), reporting elevated Resting Heart Rate (RHR +9 bpm), leg heaviness, and poor sleep.] ###
```

* **Pattern (Context / Patrón):** Consecutive daily Stage III sessions in 101°F heat without Stage I recovery base cause sympathetic overreaching, glycogen depletion, and thermal strain.
* **Rule (Constraint / Regla):** NASM Optimum Performance Training (OPT) Stage Training & PAGA 2018 / ACSM 12th Ed. Rule: Stage III workouts require prior Stage I–II conditioning and must be separated by 48–72 hours of Stage I active recovery (65–75% HRmax) or rest.
* **Solve (Intervention / Solución):** Restructure S.B.'s weekly microcycle into 3 Stage I aerobic base sessions (6:00 AM outdoor or indoor GY 116), 1 Stage II threshold session, and 1 Stage III interval session separated by 72 hours, and submit the Module 08 Midterm Evaluation.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Design a 7-day periodized NASM Stage I, II, and III cardiorespiratory microcycle for Client S.B. in Yuma, AZ.
Context: [CLINICAL_PROFILE: Client S.B. | Age: 34 | Location: Yuma, AZ | Goal: Improve 5K race pace and aerobic fitness | Error: Performs Stage III high-intensity intervals (90% HRmax) 5 days in a row outdoors at 5:00 PM (101°F), reporting elevated Resting Heart Rate (RHR +9 bpm), leg heaviness, and poor sleep.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a day-by-day Stage Training schedule with %HRmax zones, VT1/VT2 Talk Test markers, work-to-rest intervals, and heat-safety timing.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 08)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine generated a baseline workout template for Cardiorespiratory Training Programming & Midterm Evaluation, but my audit against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model** identified two critical clinical gaps. First, in our **Pattern** diagnosis, consecutive daily Stage III sessions in 101°F heat without Stage I recovery base cause sympathetic overreaching, glycogen depletion, and thermal strain. The raw AI output failed to adjust the exercise tempo, rest interval, and joint alignment cues for these specific kinetic-chain and environmental constraints. Second, under our **Rule** step (NASM Optimum Performance Training (OPT) Stage Training & PAGA 2018 / ACSM 12th Ed. Rule: Stage III workouts require prior Stage I–II conditioning and must be separated by 48–72 hours of Stage I active recovery (65–75% HRmax) or rest.), every acute variable must match the client's current OPT phase and Yuma's ambient thermal load rather than relying on unverified defaults. I corrected the prescription by enforcing exact NASM OPT acute variables, verifying pre-session hydration and heart-rate/RPE boundaries, and logging the updated protocol in `exwtoolkit.com`.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In my own words, when I coach this client on the floor in GY Room 116 here at Arizona Western College, my job as the human Pilot and Architect is to look past the computer screen and watch how they actually move, stabilize, and breathe in real time. Following the Pattern / Rule / Solve protocol, the **Pattern** is consecutive daily Stage III sessions in 101°F heat without Stage I recovery base cause sympathetic overreaching, glycogen depletion, and thermal strain. Under our Academic Source of Truth **Rule** (NASM Optimum Performance Training (OPT) Stage Training & PAGA 2018 / ACSM 12th Ed. Rule: Stage III workouts require prior Stage I–II conditioning and must be separated by 48–72 hours of Stage I active recovery (65–75% HRmax) or rest.), an automated AI workout generator cannot spot joint compensations or Yuma heat fatigue on the gym floor. My **Solve** puts safety and coaching presence first: Restructure S.B.'s weekly microcycle into 3 Stage I aerobic base sessions (6:00 AM outdoor or indoor GY 116), 1 Stage II threshold session, and 1 Stage III interval session separated by 72 hours, and submit the Module 08 Midterm Evaluation. During our Tuesday and Thursday laboratory sessions in GY Room 116, I demonstrate each movement first, use clear external cues in English and Norteño-Spanish so the client feels stable and confident, and log their Rate of Perceived Exertion and acute variables in `exwtoolkit.com` to achieve full **PAGA 2018**, **ACSM 12th Edition**, and **NASM OPT** mastery.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM Optimum Performance Training (OPT) Stage Training & PAGA 2018 / ACSM 12th Ed. Rule: Stage III workouts require prior Stage I–II conditioning and must be separated by 48–72 hours of Stage I active recovery (65–75% HRmax) or rest. Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 08: Cardiorespiratory Training & Midterm Evaluation):**
  1. **Mod 08 Coaching Sprint Simulation: NASM Stage I, II & III Cardiorespiratory Periodization**
  2. **Mod 08 Lab & Simulation (GY 116): Submaximal Talk Test (VT1) & Stage I–II Interval Programming Lab**
  3. **Mod 08: Midterm Student Course Evaluation (Replaces Weekly Discussion)**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* Why does scheduling Stage III high-intensity intervals on back-to-back days violate both NASM Stage Training rules and bioenergetic recovery physiology?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
