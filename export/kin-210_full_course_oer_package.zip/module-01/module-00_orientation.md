## Module 00: Orientation, Journey Selection & Curriculum-as-Code (CaC) Foundations

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Module 00 sets up your hybrid schedule, your Choose Your Own Journey pathway, and our 10-7-0 Mastery Grading Scale.** We meet Mondays and Wednesdays in AS Building Room 115 for lecture and Tuesdays and Thursdays in Gymnasium Room 116 for hands-on lab practice. Every lab and simulation offers unlimited revisions until Friday, May 7, 2027.
>
> **Español (Norteño):** Esta semana arrancamos el curso híbrido en el campus de Yuma eligiendo tu ruta profesional y conociendo el gimnasio. Si los términos técnicos se ponen pesados, concéntrate primero en ubicar los salones AS 115 y GY 116, elegir tu Ruta (A, B o C) y entender la escala 10-7-0.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 01: Orientation & Human Movement System (January 11, 2027 - January 18, 2027)  
**NASM OPT & Clinical Focus:** Onboarding, Choose Your Own Journey Selection (Path A / B / C) & Hybrid Lab Safety  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, January 18, 2027 at 11:59 PM MST (MLK Jr. Holiday does not change due date) | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 0.1:** Select a Personal Fitness Training Specialization Pathway (Path A Clinical, Path B Performance, or Path C Lifestyle) and apply the Clinical Framing Protocol (Pattern / Rule / Solve) across hybrid lecture and gymnasium lab sessions.
* **LO 0.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 0.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Module 00 sets up your hybrid schedule, your Choose Your Own Journey pathway, and our 10-7-0 Mastery Grading Scale.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{Centaur Trainer Workflow} = \text{Human Clinical Framing (Pattern / Rule)} + \text{AI Calculation Audit (Solve)}$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Intake screening, medical clearance gates, and cardiometabolic risk stratification in Yuma County.
* **Path B (Athletic & Human Performance):** Multi-planar force vectors, athletic movement prep, and court/field testing in GY Room 116.
* **Path C (General Fitness & Lifestyle Coaching):** Baseline functional health habits, workplace wellness, and desert heat adherence.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Resident Cohort Intake | Location: AWC Yuma Campus (AS 115 & GY 116) | Ambient Environment: Sonoran Desert Borderland | Objective: Establish baseline biometric logging on exwtoolkit.com and select Path A, Path B, or Path C.] ###
```

* **Pattern (Context / Patrón):** New personal training residents often jump straight to exercise selection without first screening client risk factors, movement compensations, or environmental heat load.
* **Rule (Constraint / Regla):** PAGA 2018 (2nd Ed.), ACSM 12th Ed., and NASM Optimum Performance Training (OPT) Pre-Participation Rule: Every training decision begins with pre-activity health screening, scope-of-practice verification, and structured phase selection.
* **Solve (Intervention / Solución):** Complete the Module 00 Orientation Checklist, select Path A, Path B, or Path C for the semester, and verify gymnasium safety protocols in GY Room 116.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Draft a Week 01 Personal Fitness Training Residency Onboarding & Pathway Selection Plan (Path A, B, or C) with pre-participation screening gates.
Context: [CLINICAL_PROFILE: Resident Cohort Intake | Location: AWC Yuma Campus (AS 115 & GY 116) | Ambient Environment: Sonoran Desert Borderland | Objective: Establish baseline biometric logging on exwtoolkit.com and select Path A, Path B, or Path C.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a structured Pattern / Rule / Solve onboarding checklist linking AS 115 lectures, GY 116 lab safety, and exwtoolkit.com biometric logging.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 00)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine generated a baseline workout template for Orientation, Journey Selection & Curriculum-as-Code (CaC) Foundations, but my audit against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model** identified two critical clinical gaps. First, in our **Pattern** diagnosis, new personal training residents often jump straight to exercise selection without first screening client risk factors, movement compensations, or environmental heat load. The raw AI output failed to adjust the exercise tempo, rest interval, and joint alignment cues for these specific kinetic-chain and environmental constraints. Second, under our **Rule** step (PAGA 2018 (2nd Ed.), ACSM 12th Ed., and NASM Optimum Performance Training (OPT) Pre-Participation Rule: Every training decision begins with pre-activity health screening, scope-of-practice verification, and structured phase selection.), every acute variable must match the client's current OPT phase and Yuma's ambient thermal load rather than relying on unverified defaults. I corrected the prescription by enforcing exact NASM OPT acute variables, verifying pre-session hydration and heart-rate/RPE boundaries, and logging the updated protocol in `exwtoolkit.com`.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In my own words, when I coach this client on the floor in GY Room 116 here at Arizona Western College, my job as the human Pilot and Architect is to look past the computer screen and watch how they actually move, stabilize, and breathe in real time. Following the Pattern / Rule / Solve protocol, the **Pattern** is new personal training residents often jump straight to exercise selection without first screening client risk factors, movement compensations, or environmental heat load. Under our Academic Source of Truth **Rule** (PAGA 2018 (2nd Ed.), ACSM 12th Ed., and NASM Optimum Performance Training (OPT) Pre-Participation Rule: Every training decision begins with pre-activity health screening, scope-of-practice verification, and structured phase selection.), an automated AI workout generator cannot spot joint compensations or Yuma heat fatigue on the gym floor. My **Solve** puts safety and coaching presence first: Complete the Module 00 Orientation Checklist, select Path A, Path B, or Path C for the semester, and verify gymnasium safety protocols in GY Room 116. During our Tuesday and Thursday laboratory sessions in GY Room 116, I demonstrate each movement first, use clear external cues in English and Norteño-Spanish so the client feels stable and confident, and log their Rate of Perceived Exertion and acute variables in `exwtoolkit.com` to achieve full **PAGA 2018**, **ACSM 12th Edition**, and **NASM OPT** mastery.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** PAGA 2018 (2nd Ed.), ACSM 12th Ed., and NASM Optimum Performance Training (OPT) Pre-Participation Rule: Every training decision begins with pre-activity health screening, scope-of-practice verification, and structured phase selection. Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 01: Orientation & Human Movement System):**
  1. **Mod 00 Onboarding Check: Hybrid Schedule, Pathway Selection & 10-7-0 Mastery Agreement**
  2. **Mod 00 Lab Orientation: GY Room 116 Safety Walkthrough & exwtoolkit.com Setup**
  3. **Mod 00 Discussion: Self-Introduction & Choose Your Own Journey Pathway (2 Peer Replies)**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* How do the three Academic Sources of Truth—PAGA 2018, ACSM 12th Edition, and the NASM Optimum Performance Training (OPT) Model—work together during a client intake?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
