## Week 01: Orientation & Human Movement System

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Module 00 sets up your hybrid schedule, your Choose Your Own Journey pathway, and our 10-7-0 Mastery Grading Scale.** We meet Mondays and Wednesdays in AS Building Room 115 for lecture and Tuesdays and Thursdays in Gymnasium Room 116 for hands-on lab practice. Every lab and simulation offers unlimited revisions until Friday, May 7, 2027.
>
> **Español (Norteño):** Esta semana arrancamos el curso híbrido en el campus de Yuma eligiendo tu ruta profesional y conociendo el gimnasio. Si los términos técnicos se ponen pesados, concéntrate primero en ubicar los salones AS 115 y GY 116, elegir tu Ruta (A, B o C) y entender la escala 10-7-0.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** January 11, 2027 - January 18, 2027  
**Weekly Due Date:** Monday, January 18, 2027 at 11:59 PM MST (MLK Jr. Holiday does not change due date)  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 00: Orientation, Journey Selection & Curriculum-as-Code (CaC) Foundations** (`module-00_orientation.md` / `module-00_orientation.html`)
  * *NASM OPT & Clinical Focus:* Onboarding, Choose Your Own Journey Selection (Path A / B / C) & Hybrid Lab Safety
  * *Deliverables:* Mod 00 Onboarding Check: Hybrid Schedule, Pathway Selection & 10-7-0 Mastery Agreement | Mod 00 Lab Orientation: GY Room 116 Safety Walkthrough & exwtoolkit.com Setup | Mod 00 Discussion: Self-Introduction & Choose Your Own Journey Pathway (2 Peer Replies)
* **Module 01: Introduction to the Human Movement System & Optimum Performance Training (OPT) Model** (`module-01_human_movement.md` / `module-01_human_movement.html`)
  * *NASM OPT & Clinical Focus:* Kinetic Chain Integration (Muscular, Articular, Nervous Systems) & NASM OPT Phases 1–5
  * *Deliverables:* Mod 01 Coaching Sprint Simulation: Mapping Kinetic Chain Imbalances to NASM OPT Phases | Mod 01 Lab & Simulation (GY 116): Kinetic Chain Inspection & Phase 1 Stabilization Setup | Mod 01 Discussion: Why Stabilization Precedes Strength and Power in the OPT Model

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Monday, January 11, 2027 (Mod 00) & Tuesday, January 12, 2027 (Mod 01)
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, January 18, 2027 at 11:59 PM MST (MLK Jr. Holiday does not change due date)
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
