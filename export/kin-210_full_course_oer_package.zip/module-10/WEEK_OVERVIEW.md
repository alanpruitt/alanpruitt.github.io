## Week 10: Resistance Training: Stabilization, Strength, Power

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Resistance training acute variables—reps, sets, tempo, weight, and rest—determine whether a workout builds endurance, muscle size, maximal strength, or explosive power.** In the NASM OPT Model, Phase 2 uses strength-plus-stabilization supersets, Phase 3 targets hypertrophy, Phase 4 builds maximal strength, and Phase 5 pairs heavy strength with explosive power.
>
> **Español (Norteño):** Las variables agudas del entrenamiento con pesas son como la receta de cocina: cambiar las repeticiones, la velocidad y el descanso cambia por completo el resultado en el músculo. Si los términos técnicos se ponen pesados, concéntrate primero en cómo funcionan las superseries de las Fases 2 y 5.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** March 16, 2027 - March 22, 2027  
**Weekly Due Date:** Monday, March 22, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 10: Resistance Training: Stabilization, Strength, and Power** (`module-10_resistance_training.md` / `module-10_resistance_training.html`)
  * *NASM OPT & Clinical Focus:* Acute Variables (Reps, Sets, Tempo, Intensity, Rest) Across OPT Phases 1, 2, 3, 4 & 5
  * *Deliverables:* Mod 10 Coaching Sprint Simulation: Acute Variables & Superset Mechanics Across OPT Phases 1–5 | Mod 10 Lab & Simulation (GY 116): Executing Phase 2 Strength-Endurance & Phase 5 Power Supersets | Mod 10 Discussion: Auditing AI Resistance Programs Against NASM OPT Acute Variables

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, March 16, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, March 22, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
