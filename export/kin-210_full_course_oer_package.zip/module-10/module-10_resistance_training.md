## Module 10: Resistance Training: Stabilization, Strength, and Power

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Resistance training acute variables—reps, sets, tempo, weight, and rest—determine whether a workout builds endurance, muscle size, maximal strength, or explosive power.** In the NASM OPT Model, Phase 2 uses strength-plus-stabilization supersets, Phase 3 targets hypertrophy, Phase 4 builds maximal strength, and Phase 5 pairs heavy strength with explosive power.
>
> **Español (Norteño):** Las variables agudas del entrenamiento con pesas son como la receta de cocina: cambiar las repeticiones, la velocidad y el descanso cambia por completo el resultado en el músculo. Si los términos técnicos se ponen pesados, concéntrate primero en cómo funcionan las superseries de las Fases 2 y 5.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 10: Resistance Training: Stabilization, Strength, Power (March 16, 2027 - March 22, 2027)  
**NASM OPT & Clinical Focus:** Acute Variables (Reps, Sets, Tempo, Intensity, Rest) Across OPT Phases 1, 2, 3, 4 & 5  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, March 22, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 10.1:** Prescribe exact acute training variables (repetitions, sets, tempo, %1-RM intensity, and rest intervals) and biomechanical superset pairings across NASM Optimum Performance Training (OPT) Phases 1 through 5.
* **LO 10.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 10.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Resistance training acute variables—reps, sets, tempo, weight, and rest—determine whether a workout builds endurance, muscle size, maximal strength, or explosive power.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{Phase 2 Superset} = \text{Biomechanically Similar Strength } (2\text{-}0\text{-}2) + \text{Stabilization } (4\text{-}2\text{-}1) \quad (\text{8–12 Reps, 0–60s Rest})$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Phase 1 Stabilization Endurance (12–20 reps, 50–70% 1-RM, 4-2-1 tempo) and Phase 2 Strength Endurance for safe bone density and joint support.
* **Path B (Athletic & Human Performance):** Phase 4 Maximal Strength (1–5 reps, 85–100% 1-RM, 3–5 min rest) and Phase 5 Power Supersets (heavy strength + explosive medicine ball/plyometric).
* **Path C (General Fitness & Lifestyle Coaching):** Phase 2 Strength Endurance supersets (8–12 reps) and Phase 3 Muscular Development (6–12 reps, 75–85% 1-RM) meeting PAGA 2018 muscle-strengthening guidelines.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client V.R. | Age: 26 | Location: Yuma, AZ | Goal: Phase 2 Strength Endurance (Path C) & Phase 5 Power transition (Path B) | AI Error: Pairs a barbell bench press (chest) with a seated cable row (back) and calls it a 'NASM Phase 2 Superset' with 1-RM loads.] ###
```

* **Pattern (Context / Patrón):** The AI confuses a traditional agonist-antagonist superset (chest + back) with a NASM Phase 2 Strength Endurance superset, which requires pairing two biomechanically similar exercises for the *same* muscle group (stable strength + unstable stabilization).
* **Rule (Constraint / Regla):** NASM Optimum Performance Training (OPT) Phase 2 & Phase 5 Superset Rule: Phase 2 pairs a stable strength exercise (8–12 reps, 2-0-2 tempo) immediately with a stabilization exercise for the same biomechanical pattern (8–12 reps, 4-2-1 tempo); Phase 5 pairs a heavy strength exercise (1–5 reps at 85–100% 1-RM) with an explosive power exercise (8–10 reps at 30–45% 1-RM or 10% bodyweight).
* **Solve (Intervention / Solución):** Correct V.R.'s Phase 2 chest superset in GY 116 to: (1) Flat Barbell Bench Press (10 reps, 2-0-2 tempo) immediately followed by (2) Stability Ball Push-Up (10 reps, 4-2-1 tempo), resting 60 seconds between supersets.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Audit the AI's superset error and build a complete NASM Phase 2 Strength Endurance and Phase 5 Power acute-variable table for Client V.R.
Context: [CLINICAL_PROFILE: Client V.R. | Age: 26 | Location: Yuma, AZ | Goal: Phase 2 Strength Endurance (Path C) & Phase 5 Power transition (Path B) | AI Error: Pairs a barbell bench press (chest) with a seated cable row (back) and calls it a 'NASM Phase 2 Superset' with 1-RM loads.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a side-by-side Phase 2 vs. Phase 5 Superset Table with exact reps, sets, tempo, %1-RM intensity, rest intervals, and biomechanical pairings.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 10)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine generated a baseline workout template for Resistance Training: Stabilization, Strength, and Power, but my audit against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model** identified two critical clinical gaps. First, in our **Pattern** diagnosis, the AI confuses a traditional agonist-antagonist superset (chest + back) with a NASM Phase 2 Strength Endurance superset, which requires pairing two biomechanically similar exercises for the *same* muscle group (stable strength + unstable stabilization). The raw AI output failed to adjust the exercise tempo, rest interval, and joint alignment cues for these specific kinetic-chain and environmental constraints. Second, under our **Rule** step (NASM Optimum Performance Training (OPT) Phase 2 & Phase 5 Superset Rule: Phase 2 pairs a stable strength exercise (8–12 reps, 2-0-2 tempo) immediately with a stabilization exercise for the same biomechanical pattern (8–12 reps, 4-2-1 tempo); Phase 5 pairs a heavy strength exercise (1–5 reps at 85–100% 1-RM) with an explosive power exercise (8–10 reps at 30–45% 1-RM or 10% bodyweight).), every acute variable must match the client's current OPT phase and Yuma's ambient thermal load rather than relying on unverified defaults. I corrected the prescription by enforcing exact NASM OPT acute variables, verifying pre-session hydration and heart-rate/RPE boundaries, and logging the updated protocol in `exwtoolkit.com`.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In my own words, when I coach this client on the floor in GY Room 116 here at Arizona Western College, my job as the human Pilot and Architect is to look past the computer screen and watch how they actually move, stabilize, and breathe in real time. Following the Pattern / Rule / Solve protocol, the **Pattern** is the AI confuses a traditional agonist-antagonist superset (chest + back) with a NASM Phase 2 Strength Endurance superset, which requires pairing two biomechanically similar exercises for the *same* muscle group (stable strength + unstable stabilization). Under our Academic Source of Truth **Rule** (NASM Optimum Performance Training (OPT) Phase 2 & Phase 5 Superset Rule: Phase 2 pairs a stable strength exercise (8–12 reps, 2-0-2 tempo) immediately with a stabilization exercise for the same biomechanical pattern (8–12 reps, 4-2-1 tempo); Phase 5 pairs a heavy strength exercise (1–5 reps at 85–100% 1-RM) with an explosive power exercise (8–10 reps at 30–45% 1-RM or 10% bodyweight).), an automated AI workout generator cannot spot joint compensations or Yuma heat fatigue on the gym floor. My **Solve** puts safety and coaching presence first: Correct V.R.'s Phase 2 chest superset in GY 116 to: (1) Flat Barbell Bench Press (10 reps, 2-0-2 tempo) immediately followed by (2) Stability Ball Push-Up (10 reps, 4-2-1 tempo), resting 60 seconds between supersets. During our Tuesday and Thursday laboratory sessions in GY Room 116, I demonstrate each movement first, use clear external cues in English and Norteño-Spanish so the client feels stable and confident, and log their Rate of Perceived Exertion and acute variables in `exwtoolkit.com` to achieve full **PAGA 2018**, **ACSM 12th Edition**, and **NASM OPT** mastery.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM Optimum Performance Training (OPT) Phase 2 & Phase 5 Superset Rule: Phase 2 pairs a stable strength exercise (8–12 reps, 2-0-2 tempo) immediately with a stabilization exercise for the same biomechanical pattern (8–12 reps, 4-2-1 tempo); Phase 5 pairs a heavy strength exercise (1–5 reps at 85–100% 1-RM) with an explosive power exercise (8–10 reps at 30–45% 1-RM or 10% bodyweight). Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 10: Resistance Training: Stabilization, Strength, Power):**
  1. **Mod 10 Coaching Sprint Simulation: Acute Variables & Superset Mechanics Across OPT Phases 1–5**
  2. **Mod 10 Lab & Simulation (GY 116): Executing Phase 2 Strength-Endurance & Phase 5 Power Supersets**
  3. **Mod 10 Discussion: Auditing AI Resistance Programs Against NASM OPT Acute Variables**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* What is the exact difference between a NASM Phase 2 Strength Endurance superset and a NASM Phase 5 Power superset in terms of load, tempo, and exercise pairing?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model.
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-210` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
