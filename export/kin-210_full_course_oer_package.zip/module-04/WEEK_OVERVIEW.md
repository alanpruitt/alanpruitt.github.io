## Week 04: Bioenergetics & Energy Systems

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Bioenergetics explains how your cells turn food into adenosine triphosphate (ATP) to power everything from a 5-second jump to a 60-minute walk.** Short, explosive efforts use stored phosphocreatine (ATP-PC), hard 30–90 second sets use glucose (glycolysis), and steady endurance relies on oxygen (oxidative metabolism). Matching rest intervals to the right energy system prevents premature burnout.
>
> **Español (Norteño):** Tu cuerpo tiene tres velocidades de motor para producir energía según la duración y fuerza del ejercicio. Si los términos técnicos se ponen pesados, concéntrate primero en cuánto descanso necesita el cliente entre series para recargar su batería muscular.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** February 2, 2027 - February 8, 2027  
**Weekly Due Date:** Monday, February 8, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 04: Bioenergetics & Energy Systems** (`module-04_bioenergetics.md` / `module-04_bioenergetics.html`)
  * *NASM OPT & Clinical Focus:* ATP-PC, Glycolytic, and Oxidative Pathways, Work-to-Rest Ratios & EPOC
  * *Deliverables:* Mod 04 Coaching Sprint Simulation: Bioenergetic Pathways & Work-to-Rest Prescriptions | Mod 04 Lab & Simulation (GY 116): Wingate/Shuttle Glycolytic vs. ATP-PC Recovery Timing Lab | Mod 04 Discussion: Why Rest Intervals Determine Which Energy System You Actually Train

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, February 2, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, February 8, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
