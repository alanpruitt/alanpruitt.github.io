## Module 09: Core & Balance Training Integration

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Core and balance training strengthens the deep spinal stabilizers and single-leg control that protect your back and knees during every movement.** Instead of starting with rapid sit-ups or medicine-ball throws, the OPT Model trains isometric core holds and single-leg balance first, then dynamic control, and finally reactive power.
>
> **Español (Norteño):** El abdomen y el equilibrio son los cimientos de cualquier casa: antes de hacer abdominales rápidos o saltos, primero enseñamos a estabilizar la columna y pararse firme en una pierna. Si los términos técnicos se ponen pesados, concéntrate primero en las tres etapas de abdomen y equilibrio: estable, dinámico y reactivo.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 09: Core & Balance Training Integration (March 9, 2027 - March 15, 2027)  
**NASM OPT & Clinical Focus:** Local vs. Global Core Musculature, Drawing-In & Bracing, and Core/Balance Levels 1–3  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, March 15, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 9.1:** Differentiate Local Stabilization and Global Movement core systems, and progress Core-Stabilization, Core-Strength, and Core-Power alongside Balance-Stabilization, Balance-Strength, and Balance-Power in GY Room 116.
* **LO 9.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 9.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Core and balance training strengthens the deep spinal stabilizers and single-leg control that protect your back and knees during every movement.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{Core & Balance Continuum} = \text{Stabilization (No Joint Motion)} \rightarrow \text{Strength (Controlled Full ROM)} \rightarrow \text{Power (Explosive/Reactive)}$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Core-Stabilization (marching, floor bridge, plank) and Balance-Stabilization (single-leg lift and chop) for lumbar protection and fall prevention.
* **Path B (Athletic & Human Performance):** Core-Power (rotation chest pass, medicine ball pullover throw) and Balance-Power (multi-planar hop with stabilization).
* **Path C (General Fitness & Lifestyle Coaching):** Integrating 2–3 days/week of functional core and balance progressions into PAGA 2018 adult and older-adult routines.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client C.W. | Age: 61 | Location: Yuma, AZ | Goal: Improve golf rotational power and prevent falls on uneven desert trails | Error: AI fitness app prescribes weighted Russian twists on a stability ball and box jumps despite C.W. failing a 10-second single-leg balance test.] ###
```

* **Pattern (Context / Patrón):** Prescribing high-velocity transverse spinal rotation (Core-Power) and plyometric hops (Balance-Power) to a client lacking intervertebral stabilization and single-leg proprioception creates high lumbar disc and ankle/knee injury risk.
* **Rule (Constraint / Regla):** NASM Optimum Performance Training (OPT) Core & Balance Rule & PAGA 2018 Older Adult Rule: Clients must demonstrate mastery in Level 1 Stabilization (little-to-no spine or joint motion: floor bridge, plank, single-leg balance reach) before advancing to Level 2 Strength or Level 3 Power.
* **Solve (Intervention / Solución):** Regress C.W. in GY 116 to Core-Stabilization (marching, prone iso-abs, pallof press) and Balance-Stabilization (single-leg balance with multi-planar reach) for 4 weeks before introducing dynamic cable rotations.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Audit the AI's Core-Power/Balance-Power prescription for Client C.W. and design a safe Level 1-to-Level 2 Core & Balance progression.
Context: [CLINICAL_PROFILE: Client C.W. | Age: 61 | Location: Yuma, AZ | Goal: Improve golf rotational power and prevent falls on uneven desert trails | Error: AI fitness app prescribes weighted Russian twists on a stability ball and box jumps despite C.W. failing a 10-second single-leg balance test.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a Pattern / Rule / Solve progression table contrasting Local vs. Global core activation, drawing-in vs. bracing cues, and Level 1–2 exercises.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 09)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine generated a baseline workout template for Core & Balance Training Integration, but my audit against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model** identified two critical clinical gaps. First, in our **Pattern** diagnosis, prescribing high-velocity transverse spinal rotation (Core-Power) and plyometric hops (Balance-Power) to a client lacking intervertebral stabilization and single-leg proprioception creates high lumbar disc and ankle/knee injury risk. The raw AI output failed to adjust the exercise tempo, rest interval, and joint alignment cues for these specific kinetic-chain and environmental constraints. Second, under our **Rule** step (NASM Optimum Performance Training (OPT) Core & Balance Rule & PAGA 2018 Older Adult Rule: Clients must demonstrate mastery in Level 1 Stabilization (little-to-no spine or joint motion: floor bridge, plank, single-leg balance reach) before advancing to Level 2 Strength or Level 3 Power.), every acute variable must match the client's current OPT phase and Yuma's ambient thermal load rather than relying on unverified defaults. I corrected the prescription by enforcing exact NASM OPT acute variables, verifying pre-session hydration and heart-rate/RPE boundaries, and logging the updated protocol in `exwtoolkit.com`.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In my own words, when I coach this client on the floor in GY Room 116 here at Arizona Western College, my job as the human Pilot and Architect is to look past the computer screen and watch how they actually move, stabilize, and breathe in real time. Following the Pattern / Rule / Solve protocol, the **Pattern** is prescribing high-velocity transverse spinal rotation (Core-Power) and plyometric hops (Balance-Power) to a client lacking intervertebral stabilization and single-leg proprioception creates high lumbar disc and ankle/knee injury risk. Under our Academic Source of Truth **Rule** (NASM Optimum Performance Training (OPT) Core & Balance Rule & PAGA 2018 Older Adult Rule: Clients must demonstrate mastery in Level 1 Stabilization (little-to-no spine or joint motion: floor bridge, plank, single-leg balance reach) before advancing to Level 2 Strength or Level 3 Power.), an automated AI workout generator cannot spot joint compensations or Yuma heat fatigue on the gym floor. My **Solve** puts safety and coaching presence first: Regress C.W. in GY 116 to Core-Stabilization (marching, prone iso-abs, pallof press) and Balance-Stabilization (single-leg balance with multi-planar reach) for 4 weeks before introducing dynamic cable rotations. During our Tuesday and Thursday laboratory sessions in GY Room 116, I demonstrate each movement first, use clear external cues in English and Norteño-Spanish so the client feels stable and confident, and log their Rate of Perceived Exertion and acute variables in `exwtoolkit.com` to achieve full **PAGA 2018**, **ACSM 12th Edition**, and **NASM OPT** mastery.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM Optimum Performance Training (OPT) Core & Balance Rule & PAGA 2018 Older Adult Rule: Clients must demonstrate mastery in Level 1 Stabilization (little-to-no spine or joint motion: floor bridge, plank, single-leg balance reach) before advancing to Level 2 Strength or Level 3 Power. Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 09: Core & Balance Training Integration):**
  1. **Mod 09 Coaching Sprint Simulation: Auditing Core & Balance Progressions Across OPT Levels 1–3**
  2. **Mod 09 Lab & Simulation (GY 116): Drawing-In, Bracing & Multi-Planar Balance Progression Lab**
  3. **Mod 09 Discussion: Why Sit-Ups and Russian Twists Are Not Phase 1 Core Exercises**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* What is the biomechanical difference between a Core-Stabilization exercise (Phase 1) and a Core-Strength exercise (Phases 2–4) in the NASM OPT Model?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model.
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-210` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
