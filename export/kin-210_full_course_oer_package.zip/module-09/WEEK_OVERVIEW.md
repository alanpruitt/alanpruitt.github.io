## Week 09: Core & Balance Training Integration

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Core and balance training strengthens the deep spinal stabilizers and single-leg control that protect your back and knees during every movement.** Instead of starting with rapid sit-ups or medicine-ball throws, the OPT Model trains isometric core holds and single-leg balance first, then dynamic control, and finally reactive power.
>
> **Español (Norteño):** El abdomen y el equilibrio son los cimientos de cualquier casa: antes de hacer abdominales rápidos o saltos, primero enseñamos a estabilizar la columna y pararse firme en una pierna. Si los términos técnicos se ponen pesados, concéntrate primero en las tres etapas de abdomen y equilibrio: estable, dinámico y reactivo.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** March 9, 2027 - March 15, 2027  
**Weekly Due Date:** Monday, March 15, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 09: Core & Balance Training Integration** (`module-09_core_balance.md` / `module-09_core_balance.html`)
  * *NASM OPT & Clinical Focus:* Local vs. Global Core Musculature, Drawing-In & Bracing, and Core/Balance Levels 1–3
  * *Deliverables:* Mod 09 Coaching Sprint Simulation: Auditing Core & Balance Progressions Across OPT Levels 1–3 | Mod 09 Lab & Simulation (GY 116): Drawing-In, Bracing & Multi-Planar Balance Progression Lab | Mod 09 Discussion: Why Sit-Ups and Russian Twists Are Not Phase 1 Core Exercises

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, March 9, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, March 15, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
