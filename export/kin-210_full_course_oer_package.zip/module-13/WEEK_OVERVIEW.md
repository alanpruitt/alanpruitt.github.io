## Week 13: Special Considerations & Chronic Conditions

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Training clients with chronic conditions requires smart exercise modifications—like avoiding breath-holding or floor positions that spike blood pressure.** Almost every adult can exercise safely when you adjust posture, breathing, intensity, and environment. Using ACSM 12th Edition and PAGA 2018 special-population rules lets you keep clients moving safely in GY Room 116.
>
> **Español (Norteño):** Entrenar a personas con presión alta, diabetes, embarazo o de la tercera edad requiere adaptar las posturas y la respiración para que el ejercicio sea medicina segura. Si los términos técnicos se ponen pesados, concéntrate primero en evitar que aguanten la respiración al hacer fuerza (maniobra de Valsalva).

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** April 13, 2027 - April 19, 2027  
**Weekly Due Date:** Monday, April 19, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 13: Special Considerations: Chronic Health Conditions** (`module-13_special_considerations.md` / `module-13_special_considerations.html`)
  * *NASM OPT & Clinical Focus:* ACSM 12th Ed. & NASM OPT Modifications for Hypertension, Diabetes, Obesity, Pregnancy, Youth & Older Adults
  * *Deliverables:* Mod 13 Coaching Sprint Simulation: Special Populations FITT & OPT Modification Audit | Mod 13 Lab & Simulation (GY 116): Peripheral Heart Action Circuit & Clinical Safety Gate Practicum | Mod 13 Discussion: Coaching Clients with Hypertension, Diabetes, and Orthopedic Limitations

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, April 13, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, April 19, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
