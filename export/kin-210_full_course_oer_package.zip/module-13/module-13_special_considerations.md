## Module 13: Special Considerations: Chronic Health Conditions

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Training clients with chronic conditions requires smart exercise modifications—like avoiding breath-holding or floor positions that spike blood pressure.** Almost every adult can exercise safely when you adjust posture, breathing, intensity, and environment. Using ACSM 12th Edition and PAGA 2018 special-population rules lets you keep clients moving safely in GY Room 116.
>
> **Español (Norteño):** Entrenar a personas con presión alta, diabetes, embarazo o de la tercera edad requiere adaptar las posturas y la respiración para que el ejercicio sea medicina segura. Si los términos técnicos se ponen pesados, concéntrate primero en evitar que aguanten la respiración al hacer fuerza (maniobra de Valsalva).

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 13: Special Considerations & Chronic Conditions (April 13, 2027 - April 19, 2027)  
**NASM OPT & Clinical Focus:** ACSM 12th Ed. & NASM OPT Modifications for Hypertension, Diabetes, Obesity, Pregnancy, Youth & Older Adults  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, April 19, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 13.1:** Modify Frequency, Intensity, Time, Type (FITT) and NASM Optimum Performance Training (OPT) exercise selection for clients with hypertension, Type 2 diabetes, obesity, pregnancy, youth, and older age using ACSM 12th Edition and PAGA 2018 safety gates.
* **LO 13.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 13.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Training clients with chronic conditions requires smart exercise modifications—like avoiding breath-holding or floor positions that spike blood pressure.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{Diabetes Pre-Exercise Gate}: 100\text{ mg/dL} \le \text{Blood Glucose} \le 250\text{ mg/dL} \quad (\text{Rule of 15 if } < 100\text{ mg/dL})$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Managing hypertension (no Valsalva, seated/standing over prone/supine, RPE 11–13 on beta-blockers) and Type 2 diabetes (pre-exercise blood glucose check 100–250 mg/dL, foot inspection).
* **Path B (Youth & Master Athletic Performance):** Epiphyseal growth-plate safety and multi-skill development in youth; recovery and joint-sparing progressions in master athletes.
* **Path C (Pregnancy, Obesity & Lifestyle Coaching):** Avoiding supine exercise after the 1st trimester (ACOG/PAGA 2018) and selecting low-impact supported modalities for joint protection.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client N.D. | Age: 59 | Location: Yuma, AZ | Conditions: Controlled Stage 2 Hypertension (on beta-blocker; Resting BP 134/84 mmHg) and Type 2 Diabetes (pre-session blood glucose: 82 mg/dL) | AI Error: Prescribes heavy overhead barbell presses to failure, prone supermans on the floor, and target heart rate of 150 bpm.] ###
```

* **Pattern (Context / Patrón):** Three compounding clinical hazards: (1) Pre-exercise blood glucose of 82 mg/dL (<100 mg/dL hypoglycemia threshold), (2) overhead isometric/heavy pressing and rapid prone-to-standing posture shifts spike blood pressure or trigger orthostatic hypotension, and (3) beta-blockers blunt heart-rate response, making a 150 bpm target dangerous.
* **Rule (Constraint / Regla):** ACSM 12th Ed., PAGA 2018 & NASM Special Populations Rule: (1) Administer 15 g fast-acting carbohydrate and re-check blood glucose after 15 minutes until $\ge 100\text{ mg/dL}$ before starting exercise; (2) use Borg Rate of Perceived Exertion (RPE 11–13) instead of age-predicted heart rate for clients on beta-blockers; (3) use seated or standing peripheral heart action circuits with continuous rhythmic breathing (never Valsalva).
* **Solve (Intervention / Solución):** Provide 15 g carbohydrate snack and confirm blood glucose $\ge 100\text{ mg/dL}$ before training in GY 116; replace overhead/prone lifts with a seated/standing Phase 1 Peripheral Heart Action circuit (12–15 reps, RPE 12, exhaling on exertion).

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Audit the AI's unsafe workout for Client N.D. (Hypertension on beta-blockers + Type 2 Diabetes with 82 mg/dL pre-exercise glucose) and design a modified Phase 1 Peripheral Heart Action circuit.
Context: [CLINICAL_PROFILE: Client N.D. | Age: 59 | Location: Yuma, AZ | Conditions: Controlled Stage 2 Hypertension (on beta-blocker; Resting BP 134/84 mmHg) and Type 2 Diabetes (pre-session blood glucose: 82 mg/dL) | AI Error: Prescribes heavy overhead barbell presses to failure, prone supermans on the floor, and target heart rate of 150 bpm.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a structured Pattern / Rule / Solve table covering the Rule of 15 hypoglycemia gate, beta-blocker RPE monitoring, Valsalva prevention, and seated/standing PHA exercise pairings.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 13)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI output failed three mandatory **ACSM 12th Edition** and **NASM Special Populations** safety gates for Client N.D. First, N.D. arrived at GY Room 116 with a pre-exercise blood glucose of $82\text{ mg/dL}$, which is below the ACSM $100\text{ mg/dL}$ hypoglycemia safety threshold; starting exercise immediately risks acute hypoglycemic dizziness or syncope. Second, the AI prescribed a target heart rate of 150 bpm without accounting for N.D.'s beta-blocker medication, which pharmacologically blunts heart rate and cardiac output—requiring intensity to be regulated via the Borg Rate of Perceived Exertion (RPE 11–13) and Talk Test instead of age-predicted heart-rate formulas. Third, heavy overhead pressing to failure and rapid prone-to-standing floor transitions provoke the Valsalva maneuver, dangerously spiking systolic blood pressure and risking orthostatic hypotension. I replaced the entire routine with a seated/standing Peripheral Heart Action (PHA) circuit.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In plain English, before N.D. touches a single weight in GY Room 116, we pause at our intake table to address his $82\text{ mg/dL}$ blood sugar using the Rule of 15: I have him take 15 grams of fast-acting carbohydrate, rest comfortably in the air-conditioned gym for 15 minutes, and re-check his glucose on `exwtoolkit.com` to confirm it is safely above $100\text{ mg/dL}$. Once cleared, I explain why we are ignoring his smartwatch's 150 bpm alert—because his beta-blocker keeps his pulse lower on purpose—and instead coach him to stay at a comfortable 12 out of 20 on the Borg RPE scale where he can speak in full sentences. We run a standing and seated Peripheral Heart Action circuit alternating upper- and lower-body movements (like seated cable rows and supported goblet box squats for 12–15 reps), cueing him to exhale smoothly on every push and pull.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** ACSM 12th Ed., PAGA 2018 & NASM Special Populations Rule: (1) Administer 15 g fast-acting carbohydrate and re-check blood glucose after 15 minutes until $\ge 100\text{ mg/dL}$ before starting exercise; (2) use Borg Rate of Perceived Exertion (RPE 11–13) instead of age-predicted heart rate for clients on beta-blockers; (3) use seated or standing peripheral heart action circuits with continuous rhythmic breathing (never Valsalva). Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 13: Special Considerations & Chronic Conditions):**
  1. **Mod 13 Coaching Sprint Simulation: Special Populations FITT & OPT Modification Audit**
  2. **Mod 13 Lab & Simulation (GY 116): Peripheral Heart Action Circuit & Clinical Safety Gate Practicum**
  3. **Mod 13 Discussion: Coaching Clients with Hypertension, Diabetes, and Orthopedic Limitations**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* Why does the Peripheral Heart Action (PHA) circuit system—alternating upper-body and lower-body exercises in standing or seated positions—work so well for clients with hypertension?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model.
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-210` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
