## Module 03: Cardiovascular & Respiratory Systems in Exercise

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Your heart, blood vessels, and lungs work as a delivery pipeline that brings oxygen to working muscles and clears heat and carbon dioxide.** During exercise, cardiac output rises because your heart beats faster and pumps more blood per beat. In Yuma heat, blood is also sent to the skin for cooling, which pushes heart rate higher at the same pace.
>
> **Español (Norteño):** El corazón y los pulmones son el sistema de riego que lleva oxígeno al músculo y enfría el cuerpo. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el gasto cardíaco sube con el ejercicio y por qué el calor de Yuma acelera el pulso.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 03: Cardiovascular & Respiratory Systems (January 26, 2027 - February 1, 2027)  
**NASM OPT & Clinical Focus:** Cardiac Output, Stroke Volume, Oxygen Transport & Desert Thermoregulatory Drift  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, February 1, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 3.1:** Calculate cardiac output, stroke volume, and Karvonen Heart Rate Reserve (HRR) zones, and explain cardiovascular drift during exercise in Yuma's desert climate.
* **LO 3.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 3.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Your heart, blood vessels, and lungs work as a delivery pipeline that brings oxygen to working muscles and clears heat and carbon dioxide.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\dot{Q} = \text{HR} \times \text{SV} \quad \text{and} \quad \text{Target HR} = \left[(\text{HR}_{\max} - \text{RHR}) \times \%\text{Intensity}\right] + \text{RHR}$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Monitoring Resting Heart Rate (RHR), blood pressure responses, and Rate of Perceived Exertion (RPE) for clients with Stage 1 Hypertension.
* **Path B (Athletic & Human Performance):** Maximizing Stroke Volume (SV) and Maximum Oxygen Uptake (VO₂ Max) kinetics across Zone 2 and Zone 3 training.
* **Path C (General Fitness & Lifestyle Coaching):** Using the Talk Test and Resting Heart Rate (RHR) trends on exwtoolkit.com to guide 150–300 min/week aerobic conditioning.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client D.V. | Age: 44 | Location: Yuma, AZ | Resting Heart Rate (RHR): 72 bpm | Resting BP: 126/82 mmHg | Observation: Outdoor brisk walk at 4:30 PM (99°F) causes heart rate to drift from 128 bpm at minute 10 to 154 bpm at minute 30 with no change in walking speed.] ###
```

* **Pattern (Context / Patrón):** Cardiovascular drift in 99°F Yuma ambient heat: cutaneous vasodilation and sweat plasma loss reduce venous return and stroke volume, forcing heart rate upward to maintain cardiac output.
* **Rule (Constraint / Regla):** ACSM 12th Ed. & PAGA 2018 (2nd Ed.) Cardiorespiratory Rule: Moderate aerobic intensity corresponds to 40–59% Heart Rate Reserve (HRR) or Borg Rate of Perceived Exertion (RPE 12–13); heat-induced cardiovascular drift requires pace reduction, fluid replacement, or climate-controlled indoor training.
* **Solve (Intervention / Solución):** Calculate D.V.'s 40–59% Heart Rate Reserve target zone, transition afternoon walks into GY Room 116 or 6:00 AM outdoor bouts, and regulate intensity via RPE 12–13 + 250 mL fluid every 15–20 minutes.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Calculate Karvonen Heart Rate Reserve (HRR) target zones and draft a heat-adjusted cardiorespiratory protocol for Client D.V.
Context: [CLINICAL_PROFILE: Client D.V. | Age: 44 | Location: Yuma, AZ | Resting Heart Rate (RHR): 72 bpm | Resting BP: 126/82 mmHg | Observation: Outdoor brisk walk at 4:30 PM (99°F) causes heart rate to drift from 128 bpm at minute 10 to 154 bpm at minute 30 with no change in walking speed.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return step-by-step HRR math, a Pattern / Rule / Solve explanation of cardiovascular drift, and indoor/early-morning pacing adjustments.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 03)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine generated a baseline workout template for Cardiovascular & Respiratory Systems in Exercise, but my audit against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model** identified two critical clinical gaps. First, in our **Pattern** diagnosis, cardiovascular drift in 99°F Yuma ambient heat: cutaneous vasodilation and sweat plasma loss reduce venous return and stroke volume, forcing heart rate upward to maintain cardiac output. The raw AI output failed to adjust the exercise tempo, rest interval, and joint alignment cues for these specific kinetic-chain and environmental constraints. Second, under our **Rule** step (ACSM 12th Ed. & PAGA 2018 (2nd Ed.) Cardiorespiratory Rule: Moderate aerobic intensity corresponds to 40–59% Heart Rate Reserve (HRR) or Borg Rate of Perceived Exertion (RPE 12–13); heat-induced cardiovascular drift requires pace reduction, fluid replacement, or climate-controlled indoor training.), every acute variable must match the client's current OPT phase and Yuma's ambient thermal load rather than relying on unverified defaults. I corrected the prescription by enforcing exact NASM OPT acute variables, verifying pre-session hydration and heart-rate/RPE boundaries, and logging the updated protocol in `exwtoolkit.com`.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In my own words, when I coach this client on the floor in GY Room 116 here at Arizona Western College, my job as the human Pilot and Architect is to look past the computer screen and watch how they actually move, stabilize, and breathe in real time. Following the Pattern / Rule / Solve protocol, the **Pattern** is cardiovascular drift in 99°F Yuma ambient heat: cutaneous vasodilation and sweat plasma loss reduce venous return and stroke volume, forcing heart rate upward to maintain cardiac output. Under our Academic Source of Truth **Rule** (ACSM 12th Ed. & PAGA 2018 (2nd Ed.) Cardiorespiratory Rule: Moderate aerobic intensity corresponds to 40–59% Heart Rate Reserve (HRR) or Borg Rate of Perceived Exertion (RPE 12–13); heat-induced cardiovascular drift requires pace reduction, fluid replacement, or climate-controlled indoor training.), an automated AI workout generator cannot spot joint compensations or Yuma heat fatigue on the gym floor. My **Solve** puts safety and coaching presence first: Calculate D.V.'s 40–59% Heart Rate Reserve target zone, transition afternoon walks into GY Room 116 or 6:00 AM outdoor bouts, and regulate intensity via RPE 12–13 + 250 mL fluid every 15–20 minutes. During our Tuesday and Thursday laboratory sessions in GY Room 116, I demonstrate each movement first, use clear external cues in English and Norteño-Spanish so the client feels stable and confident, and log their Rate of Perceived Exertion and acute variables in `exwtoolkit.com` to achieve full **PAGA 2018**, **ACSM 12th Edition**, and **NASM OPT** mastery.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** ACSM 12th Ed. & PAGA 2018 (2nd Ed.) Cardiorespiratory Rule: Moderate aerobic intensity corresponds to 40–59% Heart Rate Reserve (HRR) or Borg Rate of Perceived Exertion (RPE 12–13); heat-induced cardiovascular drift requires pace reduction, fluid replacement, or climate-controlled indoor training. Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 03: Cardiovascular & Respiratory Systems):**
  1. **Mod 03 Coaching Sprint Simulation: Cardiac Output, Karvonen HRR & Desert Cardiovascular Drift**
  2. **Mod 03 Lab & Simulation (GY 116): Resting & Submaximal Heart Rate, Blood Pressure & Ventilation Lab**
  3. **Mod 03 Discussion: Managing Cardiovascular Drift During Outdoor Training in Yuma**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* Why does heart rate climb steadily during a 30-minute constant-speed run in 99°F Yuma weather even when running pace stays exactly the same?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
