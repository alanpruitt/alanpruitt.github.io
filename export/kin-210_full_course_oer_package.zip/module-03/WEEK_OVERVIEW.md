## Week 03: Cardiovascular & Respiratory Systems

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Your heart, blood vessels, and lungs work as a delivery pipeline that brings oxygen to working muscles and clears heat and carbon dioxide.** During exercise, cardiac output rises because your heart beats faster and pumps more blood per beat. In Yuma heat, blood is also sent to the skin for cooling, which pushes heart rate higher at the same pace.
>
> **Español (Norteño):** El corazón y los pulmones son el sistema de riego que lleva oxígeno al músculo y enfría el cuerpo. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el gasto cardíaco sube con el ejercicio y por qué el calor de Yuma acelera el pulso.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** January 26, 2027 - February 1, 2027  
**Weekly Due Date:** Monday, February 1, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 03: Cardiovascular & Respiratory Systems in Exercise** (`module-03_cardiorespiratory.md` / `module-03_cardiorespiratory.html`)
  * *NASM OPT & Clinical Focus:* Cardiac Output, Stroke Volume, Oxygen Transport & Desert Thermoregulatory Drift
  * *Deliverables:* Mod 03 Coaching Sprint Simulation: Cardiac Output, Karvonen HRR & Desert Cardiovascular Drift | Mod 03 Lab & Simulation (GY 116): Resting & Submaximal Heart Rate, Blood Pressure & Ventilation Lab | Mod 03 Discussion: Managing Cardiovascular Drift During Outdoor Training in Yuma

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, January 26, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, February 1, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
