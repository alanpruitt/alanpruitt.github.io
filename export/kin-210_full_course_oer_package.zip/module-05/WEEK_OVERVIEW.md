## Week 05: Biomechanics & Applied Kinesiology

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Biomechanics applies physics—levers, torque, and line of pull—to human joints so exercises build muscle without straining ligaments.** Moving a dumbbell further from your body increases the moment arm and multiplies joint torque without adding a single pound to the weight. Understanding force-couples helps you fix posture and cue safer lifting mechanics.
>
> **Español (Norteño):** La biomecánica nos enseña cómo funcionan las palancas del cuerpo: entre más lejos sostienes una pesa del centro del cuerpo, más pesada se vuelve para la articulación. Si los términos técnicos se ponen pesados, concéntrate primero en cómo cuidar la espalda baja acercando la carga al cuerpo.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** February 9, 2027 - February 15, 2027  
**Weekly Due Date:** Monday, February 15, 2027 at 11:59 PM MST (Presidents Day Holiday does not change due date)  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 05: Biomechanics & Applied Kinesiology** (`module-05_biomechanics.md` / `module-05_biomechanics.html`)
  * *NASM OPT & Clinical Focus:* Joint Torque, Lever Systems, Force-Couples & Length-Tension Relationships
  * *Deliverables:* Mod 05 Coaching Sprint Simulation: Torque Calculations, Force-Couples & Reciprocal Inhibition | Mod 05 Lab & Simulation (GY 116): Moment-Arm Manipulation & Force-Couple Assessment Lab | Mod 05 Discussion: Using Lever Arms and Force-Couples to Adjust Exercise Difficulty Safely

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, February 9, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, February 15, 2027 at 11:59 PM MST (Presidents Day Holiday does not change due date)
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
