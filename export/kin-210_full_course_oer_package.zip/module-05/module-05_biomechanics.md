## Module 05: Biomechanics & Applied Kinesiology

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Biomechanics applies physics—levers, torque, and line of pull—to human joints so exercises build muscle without straining ligaments.** Moving a dumbbell further from your body increases the moment arm and multiplies joint torque without adding a single pound to the weight. Understanding force-couples helps you fix posture and cue safer lifting mechanics.
>
> **Español (Norteño):** La biomecánica nos enseña cómo funcionan las palancas del cuerpo: entre más lejos sostienes una pesa del centro del cuerpo, más pesada se vuelve para la articulación. Si los términos técnicos se ponen pesados, concéntrate primero en cómo cuidar la espalda baja acercando la carga al cuerpo.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 05: Biomechanics & Applied Kinesiology (February 9, 2027 - February 15, 2027)  
**NASM OPT & Clinical Focus:** Joint Torque, Lever Systems, Force-Couples & Length-Tension Relationships  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, February 15, 2027 at 11:59 PM MST (Presidents Day Holiday does not change due date) | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 5.1:** Calculate joint torque ($\tau = F \times d_{\perp}$), evaluate altered length-tension and force-couple relationships (reciprocal inhibition), and modify moment arms during gymnasium resistance training.
* **LO 5.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 5.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Biomechanics applies physics—levers, torque, and line of pull—to human joints so exercises build muscle without straining ligaments.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\tau = F \times d_{\perp} \quad (\text{Torque in N}\cdot\text{m} = \text{Force in N} \times \text{Perpendicular Moment Arm in m})$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Reducing lumbar shear torque and moment-arm loading for clients with history of low-back discomfort.
* **Path B (Athletic & Human Performance):** Optimizing Force-Velocity curves and ground reaction force vectors during athletic hip extension.
* **Path C (General Fitness & Lifestyle Coaching):** Teaching safe hip-hinge mechanics and load proximity for everyday lifting and occupational tasks in Yuma.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client H.P. | Age: 47 | Location: Yuma, AZ | Occupation: Warehouse supervisor | Observation in GY 116: Performs a 250 N (56 lb) kettlebell deadlift with the bell 0.42 m anterior to the L4/L5 lumbar fulcrum and exhibits an arched lower back (anterior pelvic tilt).] ###
```

* **Pattern (Context / Patrón):** An excessive 0.42 m moment arm generates $250\text{ N} \times 0.42\text{ m} = 105\text{ N}\cdot\text{m}$ of lumbar extensor torque, compounded by tight hip flexors inhibiting gluteus maximus activation (altered reciprocal inhibition).
* **Rule (Constraint / Regla):** NASM Optimum Performance Training (OPT) Biomechanics & ACSM 12th Ed. Rule: Minimize destructive spinal shear torque by keeping the load line of gravity close to the joint axis ($d_{\perp} \le 0.15\text{ m}$) and restoring pelvic force-couple balance (inhibiting overactive hip flexors/erector spinae; activating core/glutes).
* **Solve (Intervention / Solución):** Cue H.P. to position the kettlebell directly between the ankles ($d_{\perp} = 0.15\text{ m}$, cutting torque from $105\text{ N}\cdot\text{m}$ to $37.5\text{ N}\cdot\text{m}$, a 64.3% reduction) after hip-flexor mobility prep and glute bridges.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Calculate L4/L5 lumbar torque at $d_{\perp} = 0.42\text{ m}$ vs. $d_{\perp} = 0.15\text{ m}$ and draft a force-couple correction plan for Client H.P.
Context: [CLINICAL_PROFILE: Client H.P. | Age: 47 | Location: Yuma, AZ | Occupation: Warehouse supervisor | Observation in GY 116: Performs a 250 N (56 lb) kettlebell deadlift with the bell 0.42 m anterior to the L4/L5 lumbar fulcrum and exhibits an arched lower back (anterior pelvic tilt).] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return step-by-step torque calculations ($\tau = F \times d_{\perp}$), percentage torque reduction, and a Pattern / Rule / Solve corrective cueing plan.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 05)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine generated a baseline workout template for Biomechanics & Applied Kinesiology, but my audit against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model** identified two critical clinical gaps. First, in our **Pattern** diagnosis, an excessive 0.42 m moment arm generates $250\text{ N} \times 0.42\text{ m} = 105\text{ N}\cdot\text{m}$ of lumbar extensor torque, compounded by tight hip flexors inhibiting gluteus maximus activation (altered reciprocal inhibition). The raw AI output failed to adjust the exercise tempo, rest interval, and joint alignment cues for these specific kinetic-chain and environmental constraints. Second, under our **Rule** step (NASM Optimum Performance Training (OPT) Biomechanics & ACSM 12th Ed. Rule: Minimize destructive spinal shear torque by keeping the load line of gravity close to the joint axis ($d_{\perp} \le 0.15\text{ m}$) and restoring pelvic force-couple balance (inhibiting overactive hip flexors/erector spinae; activating core/glutes).), every acute variable must match the client's current OPT phase and Yuma's ambient thermal load rather than relying on unverified defaults. I corrected the prescription by enforcing exact NASM OPT acute variables, verifying pre-session hydration and heart-rate/RPE boundaries, and logging the updated protocol in `exwtoolkit.com`.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In my own words, when I coach this client on the floor in GY Room 116 here at Arizona Western College, my job as the human Pilot and Architect is to look past the computer screen and watch how they actually move, stabilize, and breathe in real time. Following the Pattern / Rule / Solve protocol, the **Pattern** is an excessive 0.42 m moment arm generates $250\text{ N} \times 0.42\text{ m} = 105\text{ N}\cdot\text{m}$ of lumbar extensor torque, compounded by tight hip flexors inhibiting gluteus maximus activation (altered reciprocal inhibition). Under our Academic Source of Truth **Rule** (NASM Optimum Performance Training (OPT) Biomechanics & ACSM 12th Ed. Rule: Minimize destructive spinal shear torque by keeping the load line of gravity close to the joint axis ($d_{\perp} \le 0.15\text{ m}$) and restoring pelvic force-couple balance (inhibiting overactive hip flexors/erector spinae; activating core/glutes).), an automated AI workout generator cannot spot joint compensations or Yuma heat fatigue on the gym floor. My **Solve** puts safety and coaching presence first: Cue H.P. to position the kettlebell directly between the ankles ($d_{\perp} = 0.15\text{ m}$, cutting torque from $105\text{ N}\cdot\text{m}$ to $37.5\text{ N}\cdot\text{m}$, a 64.3% reduction) after hip-flexor mobility prep and glute bridges. During our Tuesday and Thursday laboratory sessions in GY Room 116, I demonstrate each movement first, use clear external cues in English and Norteño-Spanish so the client feels stable and confident, and log their Rate of Perceived Exertion and acute variables in `exwtoolkit.com` to achieve full **PAGA 2018**, **ACSM 12th Edition**, and **NASM OPT** mastery.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM Optimum Performance Training (OPT) Biomechanics & ACSM 12th Ed. Rule: Minimize destructive spinal shear torque by keeping the load line of gravity close to the joint axis ($d_{\perp} \le 0.15\text{ m}$) and restoring pelvic force-couple balance (inhibiting overactive hip flexors/erector spinae; activating core/glutes). Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 05: Biomechanics & Applied Kinesiology):**
  1. **Mod 05 Coaching Sprint Simulation: Torque Calculations, Force-Couples & Reciprocal Inhibition**
  2. **Mod 05 Lab & Simulation (GY 116): Moment-Arm Manipulation & Force-Couple Assessment Lab**
  3. **Mod 05 Discussion: Using Lever Arms and Force-Couples to Adjust Exercise Difficulty Safely**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* How can a personal trainer make a bodyweight or dumbbell exercise in GY Room 116 significantly harder or easier simply by changing the moment arm ($d_{\perp}$)?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model.
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-210` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
