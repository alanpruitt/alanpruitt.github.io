## Week 06: Integrated Fitness Assessments

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Integrated fitness assessments find movement compensations and health risks before you write a client's training program.** In GY Room 116, we combine health screening with static posture checks, the Overhead Squat Assessment, and submaximal heart-rate tests. Identifying overactive and underactive muscles takes the guesswork out of exercise selection.
>
> **Español (Norteño):** Antes de recetar cualquier rutina, evaluamos cómo se para y cómo se mueve el cliente para detectar qué músculos están tensos y cuáles están débiles. Si los términos técnicos se ponen pesados, concéntrate primero en observar los pies, las rodillas y la espalda durante la sentadilla con brazos arriba.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** February 16, 2027 - February 22, 2027  
**Weekly Due Date:** Monday, February 22, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 06: Integrated Fitness Assessments** (`module-06_assessments.md` / `module-06_assessments.html`)
  * *NASM OPT & Clinical Focus:* PAR-Q+, Static Posture, Overhead Squat Assessment (OHSA), Functional Movement Screen (FMS) & Cardiorespiratory Testing
  * *Deliverables:* Mod 06 Coaching Sprint Simulation: Overhead Squat Assessment (OHSA) Overactive/Underactive Audit | Mod 06 Lab & Simulation (GY 116): Live Static Posture, OHSA & YMCA 3-Minute Step Test Lab | Mod 06 Discussion: Translating Overhead Squat Compensations into Targeted Exercise Selection

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, February 16, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, February 22, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
