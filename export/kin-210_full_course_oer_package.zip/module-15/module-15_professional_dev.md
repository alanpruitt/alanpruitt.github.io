## Module 15: Professional Development, Practice, and Legal Scope

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Professional practice covers ethics, legal liability, client confidentiality, and Emergency Action Plans in the fitness facility.** A professional trainer never diagnoses injuries, prescribes medication, or trains a client without signed informed consent and PAR-Q+ clearance. Maintaining a 4-year record archive and a clear Emergency Action Plan protects both your clients and your career.
>
> **Español (Norteño):** Ser un entrenador profesional significa respetar el código de ética, cuidar la privacidad del cliente y saber exactamente qué hacer en una emergencia médica. Si los términos técnicos se ponen pesados, concéntrate primero en los límites legales de nuestra profesión y el plan de acción de emergencia en GY 116.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 15: Professional Development & Legal Scope (April 27, 2027 - May 3, 2027)  
**NASM OPT & Clinical Focus:** NASM Code of Professional Conduct, Risk Management, Informed Consent, Liability & Emergency Action Plans (EAP)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, May 3, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 15.1:** Audit fitness facility operations against the NASM Code of Professional Conduct, ACSM 12th Edition Emergency Action Plan (EAP) standards, HIPAA/FERPA confidentiality rules, and professional scope-of-practice boundaries.
* **LO 15.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 15.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Professional practice covers ethics, legal liability, client confidentiality, and Emergency Action Plans in the fitness facility.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{Professional Risk Shield} = \text{PAR-Q+ \& Informed Consent} + \text{Strict Scope of Practice} + \text{Verified AED/EAP}$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Interprofessional Practice):** Interprofessional referral workflows to physicians, physical therapists, and Registered Dietitians.
* **Path B (Strength & Conditioning Risk Management):** Facility floor spacing, free-weight spotting standards, and heat-illness Emergency Action Plans in GY Room 116.
* **Path C (Fitness Business & Legal Operations):** Independent contractor vs. employee ethics, professional liability insurance, and 4-year secure client record retention.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Facility Audit Scenario | Location: Yuma Community Fitness Center | Findings: (1) Trainer diagnoses a client's acute shoulder pain as a 'supraspinatus tear' and performs manual joint manipulation, (2) client PAR-Q+ forms are left open on the front desk, and (3) the AED battery indicator is blinking red.] ###
```

* **Pattern (Context / Patrón):** Triple legal and ethical breach: (1) practicing physical therapy/medicine without a license (diagnosing and manipulating a joint), (2) violating client record confidentiality, and (3) failing facility Emergency Action Plan (EAP) and Automated External Defibrillator (AED) readiness.
* **Rule (Constraint / Regla):** NASM Code of Professional Conduct & ACSM 12th Ed. Risk Management Rule: Certified Personal Trainers must never diagnose medical/orthopedic conditions, must refer acute pain to a licensed medical professional, must secure all client records for at least 4 years in locked/encrypted storage, and must verify daily AED/EAP readiness.
* **Solve (Intervention / Solución):** Execute a 3-part Facility Remediation Plan: cease diagnostic/manipulative claims and refer the client to a physician/PT, lock all intake records in encrypted exwtoolkit.com storage, and replace/verify the AED battery and posted GY 116 Emergency Action Plan.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Audit the three legal and safety violations at the Yuma Community Fitness Center and draft a comprehensive Facility Risk Management & Emergency Action Plan (EAP).
Context: [CLINICAL_PROFILE: Facility Audit Scenario | Location: Yuma Community Fitness Center | Findings: (1) Trainer diagnoses a client's acute shoulder pain as a 'supraspinatus tear' and performs manual joint manipulation, (2) client PAR-Q+ forms are left open on the front desk, and (3) the AED battery indicator is blinking red.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a structured Pattern / Rule / Solve remediation table citing the NASM Code of Professional Conduct, 4-year record retention mandate, interprofessional PT/MD referral protocol, and ACSM 12th Ed. AED/EAP checklist.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 15)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** My clinical and legal audit against the **NASM Code of Professional Conduct** and **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)** identified three severe liability breaches that the generic AI summary understated. First, telling a client they have a 'supraspinatus tear' and performing manual joint manipulation constitutes practicing medicine/physical therapy without a license—an immediate violation of a Certified Personal Trainer's legal scope of practice. Second, leaving completed PAR-Q+ and health-history forms visible on a counter violates client confidentiality; NASM requires all client records, informed consents, and liability waivers to be stored in locked cabinets or encrypted digital storage (`exwtoolkit.com`) for a minimum of **4 years**. Third, operating a fitness floor with a blinking-red Automated External Defibrillator (AED) battery violates ACSM pre-activity facility safety standards and invalidates the Emergency Action Plan (EAP).
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In plain English, walking the floor in GY Room 116 as a professional trainer means protecting client safety and confidentiality before the workout even starts. First, if a client reports sharp shoulder pain during a press, I immediately stop the movement, never guess at a medical diagnosis, document the symptom objectively in `exwtoolkit.com`, and provide a written referral to a licensed physician or physical therapist. Second, I ensure every PAR-Q+, informed consent, and biometric log is immediately saved inside our password-protected `exwtoolkit.com` vault under our 4-year retention policy—never left on a clipboard where others can read it. Finally, before opening GY Room 116 each Tuesday and Thursday, I visually inspect the wall-mounted AED status indicator, confirm the first-aid kit and ice immersion supplies for Yuma heat emergencies, and review EMS access doors with my lab partner.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM Code of Professional Conduct & ACSM 12th Ed. Risk Management Rule: Certified Personal Trainers must never diagnose medical/orthopedic conditions, must refer acute pain to a licensed medical professional, must secure all client records for at least 4 years in locked/encrypted storage, and must verify daily AED/EAP readiness. Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 15: Professional Development & Legal Scope):**
  1. **Mod 15 Coaching Sprint Simulation: Legal Scope of Practice, Ethics & Emergency Action Plan Audit**
  2. **Mod 15 Lab & Simulation (GY 116): Facility Risk Management, Spotting & AED/EAP Drill**
  3. **Mod 15 Discussion: Protecting Clients and Your Career Through Ethical Scope of Practice**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* What are the four specific actions a Certified Personal Trainer must *never* perform under the NASM Code of Professional Conduct?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
