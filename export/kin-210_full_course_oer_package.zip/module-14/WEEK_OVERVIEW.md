## Week 14: Behavioral Coaching & Final Evaluation

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Behavioral coaching uses active listening, stages of change, and SMART goals to help clients stick with their program long-term.** Even the best workout plan fails if the client stops showing up. Submitting your Module 14 Final Student Course Evaluation this week also unlocks the Module 16 Capstone Practical Defense early on Tuesday, April 20!
>
> **Español (Norteño):** El mejor programa de entrenamiento no sirve si el cliente abandona a la segunda semana; saber escuchar y motivar hace la diferencia. Si los términos técnicos se ponen pesados, concéntrate primero en las etapas de cambio y en enviar tu Evaluación Final del Curso para abrir el Módulo 16.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** April 20, 2027 - April 26, 2027  
**Weekly Due Date:** Monday, April 26, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 14: Behavioral Coaching & Client Relations (Final Evaluation)** (`module-14_behavioral_coaching.md` / `module-14_behavioral_coaching.html`)
  * *NASM OPT & Clinical Focus:* Transtheoretical Model (TTM), SMART Goals, Motivational Interviewing & Final Course Evaluation (Unlocks Mod 16 Early)
  * *Deliverables:* Mod 14 Coaching Sprint Simulation: Transtheoretical Model (TTM) & Motivational Interviewing Audit | Mod 14 Lab & Simulation (GY 116): Live Client Consultation, SMART Goal Setting & Barrier Resolution | Mod 14: Final Student Course Evaluation (Must-Submit Unlocks Module 16 Early)

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, April 20, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, April 26, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
