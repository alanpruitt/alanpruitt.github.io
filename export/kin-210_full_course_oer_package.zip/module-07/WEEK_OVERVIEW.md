## Week 07: Flexibility & Mobility Training Protocols

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Flexibility training uses foam rolling and targeted stretching to restore normal joint motion and muscle balance before workouts.** Muscle spindles trigger a protective stretch reflex when a muscle is stretched too fast, while Golgi tendon organs help a tight muscle relax after 30 seconds of gentle tension. Matching Corrective, Active, or Dynamic flexibility to your client's OPT phase prevents injury.
>
> **Español (Norteño):** Estirar no es jalar el músculo a la fuerza; es enseñarle al sistema nervioso a soltar la tensión paso a paso con el rodillo de espuma y estiramientos controlados. Si los términos técnicos se ponen pesados, concéntrate primero en la secuencia de inhibir con rodillo y alargar por 30 segundos.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** February 23, 2027 - March 1, 2027  
**Weekly Due Date:** Monday, March 1, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 07: Flexibility & Mobility Training Protocols** (`module-07_flexibility.md` / `module-07_flexibility.html`)
  * *NASM OPT & Clinical Focus:* Corrective, Active, and Functional Flexibility Continuum (SMR, Static, Active-Isolated, Dynamic)
  * *Deliverables:* Mod 07 Coaching Sprint Simulation: Neurophysiology of Flexibility (Autogenic vs. Reciprocal Inhibition) | Mod 07 Lab & Simulation (GY 116): Corrective, Active-Isolated & Dynamic Flexibility Practicum | Mod 07 Discussion: Matching Flexibility Protocols to NASM OPT Phases 1, 2–4, and 5

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, February 23, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, March 1, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
