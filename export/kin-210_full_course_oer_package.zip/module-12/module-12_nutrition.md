## Module 12: Applied Nutrition & Supplementation Guidelines

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Personal trainers educate clients on general fueling, protein targets, and desert hydration while referring medical diets to Registered Dietitians.** Calculating Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) helps clients match their food intake to their training goals. In Yuma's heat, weighing before and after workouts tells you exactly how much fluid and electrolytes to replace.
>
> **Español (Norteño):** Como entrenadores personales enseñamos hábitos generales de hidratación y proteína para el ejercicio, pero nunca recetamos dietas médicas para enfermedades. Si los términos técnicos se ponen pesados, concéntrate primero en calcular el gasto diario de energía y reponer el agua perdida por el sudor en Yuma.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 12: Applied Nutrition & Supplementation (April 6, 2027 - April 12, 2027)  
**NASM OPT & Clinical Focus:** CPT Nutritional Scope of Practice, TDEE/BMR Calculations, Desert Hydration & Ergogenic Supplement Auditing  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, April 12, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 12.1:** Calculate Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE), apply ACSM 12th Edition and NASM sweat-loss hydration protocols (16–24 oz fluid per pound lost), audit ergogenic aids, and enforce the Certified Personal Trainer (CPT) vs. Registered Dietitian (RD) scope of practice.
* **LO 12.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 12.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Personal trainers educate clients on general fueling, protein targets, and desert hydration while referring medical diets to Registered Dietitians.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{TDEE} = \text{BMR} \times \text{Activity Factor} \quad \text{and} \quad \text{Fluid Replacement} = 16\text{–}24\text{ oz per } 1.0\text{ lb Sweat Loss}$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Scope Gate):** Identifying when a client with Type 2 Diabetes or renal disease requires immediate referral to a Registered Dietitian (RD) for Medical Nutrition Therapy.
* **Path B (Athletic & Human Performance):** Evidence-based protein dosing (1.4–2.0 g/kg/day), carbohydrate availability, and third-party tested (NSF Certified for Sport) creatine/caffeine auditing.
* **Path C (General Fitness & Lifestyle Coaching):** Sustainable energy balance using TDEE calculations and desert sweat-loss rehydration in Yuma.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client G.M. | Age: 29 | Location: Yuma, AZ | Body Mass: 80 kg | BMR: 1,800 kcal/day | Activity Factor: 1.55 (TDEE = 2,790 kcal/day) | Issue: Loses 2.0 lbs (0.91 kg) of body weight during a 60-minute summer training session and asks you to prescribe a ketogenic diet for his recently diagnosed pre-diabetes and take an unlabeled pre-workout stimulant.] ###
```

* **Pattern (Context / Patrón):** A 2.0-lb acute sweat loss represents a ~1.1% body-mass dehydration deficit in Yuma heat, while prescribing a disease-specific ketogenic meal plan violates the Personal Trainer legal scope of practice.
* **Rule (Constraint / Regla):** NASM CPT & ACSM 12th Ed. Scope of Practice & Hydration Rule: Certified Personal Trainers provide general fueling education, calculate TDEE, require third-party testing (NSF/USP) for supplements, prescribe 16–24 oz (475–710 mL) of fluid with electrolytes per pound of body mass lost during exercise, and refer any disease-specific meal plan to a Registered Dietitian (RD).
* **Solve (Intervention / Solución):** Prescribe 32–48 oz of chilled water with electrolytes post-session to replace the 2.0-lb sweat loss, decline the pre-diabetes meal-plan request with a warm referral to a Registered Dietitian, and discontinue the unverified stimulant powder.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Calculate Client G.M.'s Total Daily Energy Expenditure (TDEE) and post-exercise fluid replacement volume, and audit his ketogenic diet and supplement requests against NASM CPT Scope of Practice.
Context: [CLINICAL_PROFILE: Client G.M. | Age: 29 | Location: Yuma, AZ | Body Mass: 80 kg | BMR: 1,800 kcal/day | Activity Factor: 1.55 (TDEE = 2,790 kcal/day) | Issue: Loses 2.0 lbs (0.91 kg) of body weight during a 60-minute summer training session and asks you to prescribe a ketogenic diet for his recently diagnosed pre-diabetes and take an unlabeled pre-workout stimulant.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a structured Pattern / Rule / Solve table showing BMR/TDEE math, exact fluid replacement ounces (16–24 oz/lb lost), third-party supplement verification criteria, and a Registered Dietitian referral note.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 12)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine calculated Client G.M.'s Total Daily Energy Expenditure ($1,800 \times 1.55 = 2,790\text{ kcal/day}$), but my clinical audit against **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, **PAGA 2018**, and the **NASM Code of Professional Conduct** caught two critical safety and legal errors. First, the AI drafted a prescriptive ketogenic meal plan to treat G.M.'s newly diagnosed pre-diabetes. Under NASM and Arizona scope-of-practice rules, prescribing Medical Nutrition Therapy for a diagnosed metabolic condition is strictly reserved for a licensed Registered Dietitian (RD). Second, the AI recommended only 'drinking to thirst' after a 2.0-lb (0.91 kg) sweat loss in Yuma heat and ignored the unlabeled stimulant powder. Under ACSM 12th Edition hydration rules, every 1.0 lb of sweat loss requires 16 to 24 oz (475–710 mL) of fluid with electrolytes, and any supplement lacking NSF Certified for Sport or USP verification must be discontinued.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In plain English, when I sit down with G.M. after his weigh-out in GY Room 116, I protect both his health and my professional license by drawing a clear, respectful boundary. First, I show him on `exwtoolkit.com` that losing 2.0 pounds in one hour of Yuma training is water loss, not fat loss, so we need 32 to 48 ounces of cold water with electrolytes over the next two hours before his next session. Second, I explain warmly that while I can teach general whole-food fueling and calculate his 2,790 kcal/day TDEE and protein targets (1.4–2.0 g/kg/day), designing a clinical ketogenic diet for pre-diabetes requires a Registered Dietitian, and I hand him our AWC interprofessional referral form. Finally, we replace the unverified stimulant powder with third-party NSF-verified hydration habits and morning training hours.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM CPT & ACSM 12th Ed. Scope of Practice & Hydration Rule: Certified Personal Trainers provide general fueling education, calculate TDEE, require third-party testing (NSF/USP) for supplements, prescribe 16–24 oz (475–710 mL) of fluid with electrolytes per pound of body mass lost during exercise, and refer any disease-specific meal plan to a Registered Dietitian (RD). Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 12: Applied Nutrition & Supplementation):**
  1. **Mod 12 Coaching Sprint Simulation: TDEE Calculations, Desert Rehydration & CPT Scope-of-Practice Audit**
  2. **Mod 12 Lab & Simulation (GY 116): Pre/Post-Workout Sweat-Loss Weighing & Ergogenic Label Audit**
  3. **Mod 12 Discussion: Drawing the Line Between General Fitness Fueling and Medical Nutrition Therapy**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* Why is prescribing a specific daily meal plan to treat a client's diagnosed metabolic or cardiovascular condition outside a Certified Personal Trainer's legal scope of practice?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model.
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-210` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
