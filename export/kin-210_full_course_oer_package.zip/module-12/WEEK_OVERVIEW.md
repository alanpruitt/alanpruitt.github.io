## Week 12: Applied Nutrition & Supplementation

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Personal trainers educate clients on general fueling, protein targets, and desert hydration while referring medical diets to Registered Dietitians.** Calculating Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) helps clients match their food intake to their training goals. In Yuma's heat, weighing before and after workouts tells you exactly how much fluid and electrolytes to replace.
>
> **Español (Norteño):** Como entrenadores personales enseñamos hábitos generales de hidratación y proteína para el ejercicio, pero nunca recetamos dietas médicas para enfermedades. Si los términos técnicos se ponen pesados, concéntrate primero en calcular el gasto diario de energía y reponer el agua perdida por el sudor en Yuma.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** April 6, 2027 - April 12, 2027  
**Weekly Due Date:** Monday, April 12, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 12: Applied Nutrition & Supplementation Guidelines** (`module-12_nutrition.md` / `module-12_nutrition.html`)
  * *NASM OPT & Clinical Focus:* CPT Nutritional Scope of Practice, TDEE/BMR Calculations, Desert Hydration & Ergogenic Supplement Auditing
  * *Deliverables:* Mod 12 Coaching Sprint Simulation: TDEE Calculations, Desert Rehydration & CPT Scope-of-Practice Audit | Mod 12 Lab & Simulation (GY 116): Pre/Post-Workout Sweat-Loss Weighing & Ergogenic Label Audit | Mod 12 Discussion: Drawing the Line Between General Fitness Fueling and Medical Nutrition Therapy

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, April 6, 2027 at 12:00 AM MST (Follows Spring Break: March 30 – April 5, 2027)
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, April 12, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
