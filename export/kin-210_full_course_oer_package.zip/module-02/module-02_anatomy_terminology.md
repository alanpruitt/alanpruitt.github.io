## Module 02: Structural Anatomy & Kinesiological Terminology

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Anatomical planes and joint terms give fitness professionals a precise map for describing how the body moves in three dimensions.** Every exercise moves forward-and-back (sagittal), side-to-side (frontal), or rotationally (transverse). Mastering eccentric (lowering), isometric (holding), and concentric (lifting) muscle actions helps you cue clients safely in the gym.
>
> **Español (Norteño):** En el gimnasio no basta con decir 'mueve el brazo'; necesitamos saber en qué plano se mueve la articulación y qué músculo frena o empuja. Si los términos técnicos se ponen pesados, concéntrate primero en distinguir los tres planos de movimiento y las fases de bajar, sostener y subir el peso.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 02: Structural Anatomy & Terminology (January 19, 2027 - January 25, 2027)  
**NASM OPT & Clinical Focus:** Planes of Motion (Sagittal, Frontal, Transverse), Joint Actions & Muscle Contraction Types  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, January 25, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 2.1:** Classify multi-planar human movements across sagittal, frontal, and transverse planes, and cue eccentric, isometric, and concentric muscle actions during gymnasium resistance exercises.
* **LO 2.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 2.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Anatomical planes and joint terms give fitness professionals a precise map for describing how the body moves in three dimensions.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{NASM Phase 1 Tempo (4-2-1)} = 4\text{s Eccentric Deceleration} + 2\text{s Isometric Stabilization} + 1\text{s Concentric Acceleration}$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Safe sagittal-to-frontal plane progression for an older adult improving hip abductor stability to prevent falls.
* **Path B (Athletic & Human Performance):** Multi-planar transverse rotational deceleration and agonistic/antagonistic muscle recruitment for field athletes.
* **Path C (General Fitness & Lifestyle Coaching):** Balancing sagittal, frontal, and transverse movements across a 2-day/week PAGA 2018 full-body routine.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Client M.L. | Age: 31 | Location: Somerton, AZ | Assessment in GY 116: Performs 100% of weekly gym exercises in the sagittal plane (treadmill, leg press, chest press, bicep curls) | Issue: Medial knee valgus (caving inward) during lateral stepping and rotational tasks.] ###
```

* **Pattern (Context / Patrón):** Exclusive sagittal-plane training leaves frontal-plane abductors (gluteus medius) and transverse-plane external rotators undertrained, causing frontal/transverse knee valgus instability.
* **Rule (Constraint / Regla):** NASM Optimum Performance Training (OPT) Multi-Planar Rule & ACSM 12th Ed.: Comprehensive neuromuscular training must integrate sagittal, frontal, and transverse planes with controlled eccentric deceleration (4-second lowering phase).
* **Solve (Intervention / Solución):** Add frontal-plane lateral tube walks and step-ups plus transverse-plane cable rotations with a 4-2-1 tempo (4s eccentric, 2s isometric hold, 1s concentric) in GY Room 116.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Draft a multi-planar corrective exercise and resistance progression for Client M.L. across the sagittal, frontal, and transverse planes.
Context: [CLINICAL_PROFILE: Client M.L. | Age: 31 | Location: Somerton, AZ | Assessment in GY 116: Performs 100% of weekly gym exercises in the sagittal plane (treadmill, leg press, chest press, bicep curls) | Issue: Medial knee valgus (caving inward) during lateral stepping and rotational tasks.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a structured Pattern / Rule / Solve table classifying each exercise by plane of motion, joint action, prime mover, and 4-2-1 muscle action tempo.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 02)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine generated a baseline workout template for Structural Anatomy & Kinesiological Terminology, but my audit against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model** identified two critical clinical gaps. First, in our **Pattern** diagnosis, exclusive sagittal-plane training leaves frontal-plane abductors (gluteus medius) and transverse-plane external rotators undertrained, causing frontal/transverse knee valgus instability. The raw AI output failed to adjust the exercise tempo, rest interval, and joint alignment cues for these specific kinetic-chain and environmental constraints. Second, under our **Rule** step (NASM Optimum Performance Training (OPT) Multi-Planar Rule & ACSM 12th Ed.: Comprehensive neuromuscular training must integrate sagittal, frontal, and transverse planes with controlled eccentric deceleration (4-second lowering phase).), every acute variable must match the client's current OPT phase and Yuma's ambient thermal load rather than relying on unverified defaults. I corrected the prescription by enforcing exact NASM OPT acute variables, verifying pre-session hydration and heart-rate/RPE boundaries, and logging the updated protocol in `exwtoolkit.com`.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In my own words, when I coach this client on the floor in GY Room 116 here at Arizona Western College, my job as the human Pilot and Architect is to look past the computer screen and watch how they actually move, stabilize, and breathe in real time. Following the Pattern / Rule / Solve protocol, the **Pattern** is exclusive sagittal-plane training leaves frontal-plane abductors (gluteus medius) and transverse-plane external rotators undertrained, causing frontal/transverse knee valgus instability. Under our Academic Source of Truth **Rule** (NASM Optimum Performance Training (OPT) Multi-Planar Rule & ACSM 12th Ed.: Comprehensive neuromuscular training must integrate sagittal, frontal, and transverse planes with controlled eccentric deceleration (4-second lowering phase).), an automated AI workout generator cannot spot joint compensations or Yuma heat fatigue on the gym floor. My **Solve** puts safety and coaching presence first: Add frontal-plane lateral tube walks and step-ups plus transverse-plane cable rotations with a 4-2-1 tempo (4s eccentric, 2s isometric hold, 1s concentric) in GY Room 116. During our Tuesday and Thursday laboratory sessions in GY Room 116, I demonstrate each movement first, use clear external cues in English and Norteño-Spanish so the client feels stable and confident, and log their Rate of Perceived Exertion and acute variables in `exwtoolkit.com` to achieve full **PAGA 2018**, **ACSM 12th Edition**, and **NASM OPT** mastery.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM Optimum Performance Training (OPT) Multi-Planar Rule & ACSM 12th Ed.: Comprehensive neuromuscular training must integrate sagittal, frontal, and transverse planes with controlled eccentric deceleration (4-second lowering phase). Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 02: Structural Anatomy & Terminology):**
  1. **Mod 02 Coaching Sprint Simulation: Multi-Planar Exercise Classification & Tempo Cueing**
  2. **Mod 02 Lab & Simulation (GY 116): Sagittal, Frontal, and Transverse Plane Movement Audit**
  3. **Mod 02 Discussion: Fixing Single-Plane Training Blind Spots in Everyday Gym Programs**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* Why does controlling the 4-second eccentric (lowering) phase of a squat in GY Room 116 improve tendon resilience and joint stability more than dropping quickly into the bottom position?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
