## Week 02: Structural Anatomy & Terminology

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Anatomical planes and joint terms give fitness professionals a precise map for describing how the body moves in three dimensions.** Every exercise moves forward-and-back (sagittal), side-to-side (frontal), or rotationally (transverse). Mastering eccentric (lowering), isometric (holding), and concentric (lifting) muscle actions helps you cue clients safely in the gym.
>
> **Español (Norteño):** En el gimnasio no basta con decir 'mueve el brazo'; necesitamos saber en qué plano se mueve la articulación y qué músculo frena o empuja. Si los términos técnicos se ponen pesados, concéntrate primero en distinguir los tres planos de movimiento y las fases de bajar, sostener y subir el peso.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** January 19, 2027 - January 25, 2027  
**Weekly Due Date:** Monday, January 25, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 02: Structural Anatomy & Kinesiological Terminology** (`module-02_anatomy_terminology.md` / `module-02_anatomy_terminology.html`)
  * *NASM OPT & Clinical Focus:* Planes of Motion (Sagittal, Frontal, Transverse), Joint Actions & Muscle Contraction Types
  * *Deliverables:* Mod 02 Coaching Sprint Simulation: Multi-Planar Exercise Classification & Tempo Cueing | Mod 02 Lab & Simulation (GY 116): Sagittal, Frontal, and Transverse Plane Movement Audit | Mod 02 Discussion: Fixing Single-Plane Training Blind Spots in Everyday Gym Programs

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, January 19, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, January 25, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
