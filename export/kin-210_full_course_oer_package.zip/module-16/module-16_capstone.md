## Module 16: Capstone Practical Synthesis & Portfolio Defense

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Your Module 16 Capstone brings together every assessment, flexibility, cardio, core, balance, SAQ, and resistance skill into one complete client portfolio.** Module 16 unlocks early on Tuesday, April 20 as soon as you submit the Module 14 Final Student Course Evaluation, giving you a 2.5-week runway. There is no separate weekly discussion or lab this week—only your Final Portfolio and Practical Defense due Friday, May 7.
>
> **Español (Norteño):** El Proyecto Final del Módulo 16 reúne todo lo que practicamos en el salón AS 115 y el gimnasio GY 116 en un plan completo de 12 semanas para tu cliente. Si los términos técnicos se ponen pesados, recuerda que este módulo se abre desde el 20 de abril al enviar tu Evaluación Final y cierra el viernes 7 de mayo.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 16: Capstone Practical Synthesis & Defense (May 3, 2027 - May 7, 2027 (Early-Unlocks Tuesday, April 20, 2027 via Mod 14 Evaluation))  
**NASM OPT & Clinical Focus:** Comprehensive 12-Week Periodized NASM OPT Program Design, Live Gymnasium Practical & Verbatim Defense (Final Portfolio Only)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Friday, May 7, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 16.1:** Synthesize a complete 12-week periodized NASM Optimum Performance Training (OPT) macrocycle and execute a live gymnasium coaching defense for your selected Pathway (Path A, Path B, or Path C) verified against PAGA 2018 and ACSM 12th Edition guidelines.
* **LO 16.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 16.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Your Module 16 Capstone brings together every assessment, flexibility, cardio, core, balance, SAQ, and resistance skill into one complete client portfolio.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** $\text{KIN-210 Capstone Mastery (10/10)} = \text{Pattern (OHSA \& Vitals)} + \text{Rule (PAGA / ACSM / NASM OPT)} + \text{Solve (12-Week Periodized Defense)}$

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Capstone Portfolio):** 12-week Clinical Special Population periodized macrocycle (OPT Phases 1–2 + Stage I–II Cardio) with medical referral and desert heat-safety gates.
* **Path B (Athletic Performance Capstone Portfolio):** 12-week Athletic Performance macrocycle (OPT Phases 1, 2, 4, and 5 + Stage I–III Cardio + Reactive/SAQ progression).
* **Path C (General Fitness & Lifestyle Capstone Portfolio):** 12-week Healthy Body Composition & Active Living macrocycle (OPT Phases 1–3 + PAGA 2018 150–300 min/week aerobic + behavioral SMART roadmap).

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
## [CLINICAL_PROFILE: Capstone Client Portfolio | Location: Yuma, AZ & GY Room 116 | Pathway: Resident's Selected Track (Path A Clinical, Path B Performance, or Path C Lifestyle) | Deliverable: Complete exwtoolkit.com Assessment Log + 12-Week Periodized NASM OPT Macrocycle + 4-Part Centaur Defense.] ###
```

* **Pattern (Context / Patrón):** Synthesizing multi-system client intake data (PAR-Q+, Resting Heart Rate, Blood Pressure, Overhead Squat Assessment, cardiorespiratory stage, and Yuma environmental barriers) into a cohesive 12-week periodized plan.
* **Rule (Constraint / Regla):** PAGA 2018 (2nd Ed.), ACSM 12th Ed., and NASM Optimum Performance Training (OPT) Capstone Rule: Every phase transition must justify acute training variables (reps, sets, tempo, intensity, rest), corrective flexibility, core/balance/reactive progressions, and Yuma heat-safety modifications.
* **Solve (Intervention / Solución):** Deliver a complete 12-week periodized NASM OPT macrocycle (3 mesocycles × 4 weeks), `exwtoolkit.com` assessment log, and 4-Part Centaur Defense by Friday, May 7, 2027 at 11:59 PM MST.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Draft a 12-week periodized NASM Optimum Performance Training (OPT) macrocycle (3 four-week mesocycles) for my Capstone client along my selected Pathway (Path A, B, or C).
Context: [CLINICAL_PROFILE: Capstone Client Portfolio | Location: Yuma, AZ & GY Room 116 | Pathway: Resident's Selected Track (Path A Clinical, Path B Performance, or Path C Lifestyle) | Deliverable: Complete exwtoolkit.com Assessment Log + 12-Week Periodized NASM OPT Macrocycle + 4-Part Centaur Defense.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return an annual/12-week macrocycle table detailing Mesocycles 1–3, OPT Phases, Stage I–III Cardio, Flexibility/Core/Balance/SAQ integration, acute variables, and Yuma heat adaptations.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 16)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** In my Capstone audit of the AI engine's 12-week macrocycle against **PAGA 2018 (2nd Edition)**, **ACSM's Guidelines for Exercise Testing and Prescription (12th Edition)**, and the **NASM Optimum Performance Training (OPT) Model**, I identified and corrected three structural periodization flaws. First, the AI scheduled Mesocycle 1 in Phase 3 Muscular Development without addressing the client's Overhead Squat Assessment compensations (medial knee valgus and anterior pelvic tilt logged in `exwtoolkit.com`); NASM rules mandate starting Mesocycle 1 (Weeks 1–4) in **Phase 1 Stabilization Endurance** (12–20 reps, 4-2-1 tempo) with Corrective Flexibility (SMR + static stretching). Second, in Mesocycle 2 (Weeks 5–8, Phase 2 Strength Endurance), the AI paired unrelated muscle groups instead of biomechanically similar strength + stabilization supersets. Third, I added Yuma summer hydration (16–24 oz fluid/lb lost) and indoor GY Room 116 scheduling across Mesocycle 3.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In plain English, my Module 16 Capstone Portfolio proves that a human Personal Fitness Trainer is the Architect and Pilot of long-term client transformation here in Yuma. Across my 12-week plan in GY Room 116, I guide my client through three clear 4-week building blocks: Weeks 1–4 fix posture, ankle/hip mobility, and single-leg stability in Phase 1; Weeks 5–8 build work capacity and lean muscle through Phase 2 supersets and Stage II cardio; and Weeks 9–12 peak along my chosen pathway while hitting the full **PAGA 2018** standard of 150 to 300 minutes of weekly aerobic activity and 2+ days of full-body resistance training. By combining hands-on cueing in GY Room 116, real-time `exwtoolkit.com` biometric tracking, and Motivational Interviewing, my client finishes the semester stronger, safer, and self-sufficient.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** PAGA 2018 (2nd Ed.), ACSM 12th Ed., and NASM Optimum Performance Training (OPT) Capstone Rule: Every phase transition must justify acute training variables (reps, sets, tempo, intensity, rest), corrective flexibility, core/balance/reactive progressions, and Yuma heat-safety modifications. Never train a client through acute joint pain, dizziness, hypoglycemia ($<100\text{ mg/dL}$), or uncompensated heat strain.

* **Module Deliverables (Week 16: Capstone Practical Synthesis & Defense):**
  1. **Mod 16 Capstone Practical Synthesis & Portfolio Defense (Unlocks Early Apr 20 via Mod 14 Eval — Closes Friday, May 7, 2027 at 11:59 PM MST)**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* How does your 12-week Capstone Portfolio prove that a human Personal Fitness Trainer adds irreplaceable clinical judgment beyond what an automated AI workout generator can produce?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model.
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-210` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
