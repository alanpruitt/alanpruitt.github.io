## Week 16: Capstone Practical Synthesis & Defense

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Your Module 16 Capstone brings together every assessment, flexibility, cardio, core, balance, SAQ, and resistance skill into one complete client portfolio.** Module 16 unlocks early on Tuesday, April 20 as soon as you submit the Module 14 Final Student Course Evaluation, giving you a 2.5-week runway. There is no separate weekly discussion or lab this week—only your Final Portfolio and Practical Defense due Friday, May 7.
>
> **Español (Norteño):** El Proyecto Final del Módulo 16 reúne todo lo que practicamos en el salón AS 115 y el gimnasio GY 116 en un plan completo de 12 semanas para tu cliente. Si los términos técnicos se ponen pesados, recuerda que este módulo se abre desde el 20 de abril al enviar tu Evaluación Final y cierra el viernes 7 de mayo.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** May 3, 2027 - May 7, 2027 (Early-Unlocks Tuesday, April 20, 2027 via Mod 14 Evaluation)  
**Weekly Due Date:** Friday, May 7, 2027 at 11:59 PM MST  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 16: Capstone Practical Synthesis & Portfolio Defense** (`module-16_capstone.md` / `module-16_capstone.html`)
  * *NASM OPT & Clinical Focus:* Comprehensive 12-Week Periodized NASM OPT Program Design, Live Gymnasium Practical & Verbatim Defense (Final Portfolio Only)
  * *Deliverables:* Mod 16 Capstone Practical Synthesis & Portfolio Defense (Unlocks Early Apr 20 via Mod 14 Eval — Closes Friday, May 7, 2027 at 11:59 PM MST)

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, April 20, 2027 at 12:00 AM MST (Prerequisite: Mod 14 Final Student Course Evaluation)
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Friday, May 7, 2027 at 11:59 PM MST
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
