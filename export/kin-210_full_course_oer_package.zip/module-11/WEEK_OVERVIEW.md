## Week 11: Reactive, Speed, Agility, and Quickness (SAQ) Training

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Plyometric and Speed, Agility, and Quickness (SAQ) training teaches your nervous system to absorb landing forces safely and react quickly in any direction.** Every jump uses the Stretch-Shortening Cycle: loading (eccentric), a split-second transition (amortization), and exploding upward (concentric). Even older adults benefit from low-impact agility ladder drills to prevent falls.
>
> **Español (Norteño):** El entrenamiento pliométrico y de agilidad enseña al cuerpo a aterrizar suave como resorte y cambiar de dirección rápido sin lastimarse las rodillas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo controlar el aterrizaje de 3 a 5 segundos antes de hacer saltos continuos.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Dates:** March 23, 2027 - March 29, 2027  
**Weekly Due Date:** Monday, March 29, 2027 at 11:59 PM MST (Spring Break follows March 30 – April 5)  
**End-of-Semester Lock Date ("Until"):** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  

---

## Hybrid Schedule & Modules in This Week
* **Lecture (M/W 5:00 PM – 8:00 PM MST):** Yuma Campus, AS Building, Room 115
* **Laboratory (T/Th 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116
* **Digital Toolkit:** [exwtoolkit.com](https://exwtoolkit.com)

* **Module 11: Reactive, Speed, Agility, and Quickness (SAQ) Training** (`module-11_saq_training.md` / `module-11_saq_training.html`)
  * *NASM OPT & Clinical Focus:* Stretch-Shortening Cycle (SSC), Plyometric Phases 1–3 & Speed, Agility, and Quickness (SAQ) Drills across Lifespan
  * *Deliverables:* Mod 11 Coaching Sprint Simulation: Stretch-Shortening Cycle & Lifespan SAQ Prescription | Mod 11 Lab & Simulation (GY 116): Landing Mechanics Audit & SAQ Agility Ladder Practicum | Mod 11 Discussion: Adapting SAQ Drills for Youth, Athletes, and Older Fall-Prevention Clients

---

## Weekly Cadence & Mastery Policy
* **Clinical Framing Protocol:** Every lecture, simulation, and GY 116 laboratory assessment follows **`Pattern / Rule / Solve`** (Spanish: **`Patrón / Regla / Solución`**).
* **Opens:** Tuesday, March 23, 2027 at 12:00 AM MST
* **Discussion Initial Post Due:** Thursday at 11:59 PM MST (Skipped on Module 08 Midterm, Module 14 Final Evaluation, and Module 16 Capstone weeks)
* **Discussion Peer Replies Due:** Sunday at 11:59 PM MST (2 replies in Module 00; 1 reply in regular weeks)
* **Simulations, Gymnasium Labs & Evaluations Target Due Date:** Monday, March 29, 2027 at 11:59 PM MST (Spring Break follows March 30 – April 5)
* **Mastery Revision Window:** All Simulations and Labs remain open with **Unlimited Attempts (`-1`)** until **Friday, May 7, 2027 at 11:59 PM MST** on the **10 / 7 / 0 Mastery Grading Scale**.

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

## STRUCTURAL_DELIMITER_BOUND_1 ###
## STRUCTURAL_DELIMITER_BOUND_2 ###
## STRUCTURAL_DELIMITER_BOUND_3 ###
