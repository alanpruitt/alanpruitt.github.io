# KIN-265: Mod 01 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 01 Coaching Sprint Simulation: Pre-Exercise Screening & Safety Gate Basics

Sesión de Coaching del Módulo 01: Movimiento Seguro y Pautas para Poblaciones Especiales

- Rate-Pressure Product (RPP = Heart Rate × Systolic Blood Pressure): Clinical index of myocardial oxygen demand; keeping HR and SBP controlled prevents cardiac ischemia and angina during post-cardiac rehab conditioning. En palabras sencillas: Indicador de cuánto trabajo y oxígeno exige el músculo del corazón; mantener controlados el pulso y la presión evita dolor de pecho (angina).
- Extended Warm-Up & Cool-Down (10–15 Minutes Each): Cardiac patients require a 10–15 minute gradual warm-up to open coronary arteries and a 10–15 minute cool-down to prevent post-exercise hypotension and arrhythmias. En palabras sencillas: En pacientes del corazón dedicamos de 10 a 15 minutos a calentar suave y otros 10 a 15 minutos a enfriar para evitar mareos o arritmias.
- Angina & Hemodynamic Termination Criteria: Immediate exercise stop triggers: chest/jaw/arm discomfort, drop in systolic BP >10 mmHg with increasing workload, dizziness, or unusual shortness of breath. En palabras sencillas: Señales para detener el ejercicio de inmediato: opresión en el pecho o brazo, mareo, falta de aire anormal o caída de la presión arterial.
- KIN-265.1.1.AY26-27: Apply PAGA 2018 (2nd Ed) physical activity principles to design safe, adapted exercise for individuals with chronic conditions. Aplicar las pautas PAGA 2018 (2.ª ed.) para diseñar ejercicio seguro y adaptado a personas con afecciones crónicas.
- KIN-265.1.2.AY26-27: Evaluate clinical safety considerations and dispel the myth that chronic conditions require complete physical inactivity. Evaluar las consideraciones de seguridad clínica y desmitificar la creencia de que las condiciones crónicas requieren inactividad total.

### Your Weekly Win: Movement as Medicine for Special Populations

Welcome to your first weekly Coaching Sprint ! This assignment is designed to give you a quick, confidence-building win. Instead of being intimidated by clinical complexity, you will choose a real-world client scenario below, chat with your AI Socratic Coach, and master the foundational federal rule from PAGA 2018: physical activity is safe and beneficial for individuals with chronic health conditions and disabilities, adapted to their abilities (at least 150 minutes of moderate aerobic activity + multicomponent movement) . Walk away with a memorable insight you can use immediately in your life and career!

Esta sesión semanal está diseñada para brindarle un logro claro y motivador. Elegirá su ruta profesional, conversará con su Coach de IA y dominará la regla federal fundamental de PAGA 2018: la actividad física es segura y beneficiosa para personas con afecciones crónicas o discapacidades, adaptada a sus capacidades individuales.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés profesional

Scenario: Retired teacher (Rosa, 71) with mild osteoarthritis and fear of falling who avoids all walking and exercise to "protect her knees."


```text
###
[TRACK]: Track 1 - Older Adults & Fall Prevention Path
[CLIENT]: Retired Educator (Rosa, 71) | [LOCATION]: Yuma, AZ
[SITUATION]: Diagnosed with mild bilateral knee osteoarthritis. Has become completely sedentary due to fear of falling and belief that joint pain requires total bed rest.
[COACHING GOAL]: Dispel the "rest cures arthritis" myth using PAGA 2018 older adult standards (multicomponent physical activity: balance training, low-impact aerobic walking, and muscle strengthening to reduce pain and fall risk).
###
```

Scenario: Agricultural worker (Arturo, 54) managing Type 2 Diabetes and Hypertension who believes exercise is unsafe with high blood pressure.


```text
###
[TRACK]: Track 2 - Chronic Disease Management Path
[CLIENT]: Farmworker & Supervisor (Arturo, 54) | [LOCATION]: Yuma County, AZ
[SITUATION]: Diagnosed with Type 2 Diabetes (HbA1c 8.2%) and Stage 1 Hypertension. Avoids intentional exercise because he fears physical exertion will cause an acute cardiac event.
[COACHING GOAL]: Reassure Arturo using PAGA 2018 guidelines for adults with chronic conditions, explaining how progressive moderate aerobic movement (e.g., 30 min/day) improves insulin sensitivity and lowers blood pressure safely.
###
```

Scenario: Community college student (David, 22) using a manual wheelchair who believes federal fitness guidelines do not apply to seated individuals.


```text
###
[TRACK]: Track 3 - Physical Disability & Adaptive Mobility Path
[CLIENT]: Student & Graphic Designer (David, 22) | [LOCATION]: Yuma, AZ
[SITUATION]: Uses a manual wheelchair following a spinal cord injury. Believes standard exercise recommendations (150 minutes) only apply to ambulatory individuals who can stand or run.
[COACHING GOAL]: Apply PAGA 2018 standards for adults with disabilities, designing an adaptive upper-body aerobic (arm ergometry/wheeling) and resistance program tailored to David's capabilities.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-265 Special Populations Baseline Tool Box ###:
Role: Supportive KIN-265 Special Populations Exercise Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Active Older Adults & Chronic Conditions.

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in clear, simple terms why physical inactivity is detrimental for chronic conditions and how PAGA 2018 standards (150 minutes of moderate aerobic activity adapted to ability + multicomponent balance/strength) solve the client's specific challenge.
Step 3: Guide the student to create an easy weekly adapted action plan that respects the client's current physical capabilities safely.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) that reinforces movement as medicine.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and the client's health/mobility challenge.
- PAGA 2018 Special Populations Standards (SSoT): State the federal physical activity guidelines for individuals with chronic conditions or disabilities (150 min moderate activity adapted to abilities + balance/strength).
- My Adapted Weekly Action Plan: Describe a realistic, safe 5-day schedule tailored to the client's condition.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why your pre-exercise safety screening and adapted multicomponent plan (aerobic + strength + balance) protect your client under PAGA 2018 special populations standards.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 01 Coaching Sprint • Track 1 (Older Adults / Rosa)

- Chosen Track & Client: Track 1: Older Adults & Fall Prevention (Rosa, 71, retired educator). Problem: Rosa avoids walking due to knee osteoarthritis and fear of falling. She doesn't realize that structured, low-impact multicomponent movement actually lubricates joints, strengthens supporting muscles, and significantly lowers fall risk.
- Track 1: Older Adults & Fall Prevention (Rosa, 71, retired educator).
- Problem: Rosa avoids walking due to knee osteoarthritis and fear of falling. She doesn't realize that structured, low-impact multicomponent movement actually lubricates joints, strengthens supporting muscles, and significantly lowers fall risk.
- PAGA 2018 Special Populations Standards (SSoT): Aerobic Guideline: Aim for 150 to 300 minutes of moderate-intensity activity per week, or as much as abilities allow if unable to meet the full baseline. Multicomponent Guideline: Include balance training, aerobic activity, and muscle-strengthening exercises (at least 2 days/week) to maintain functional independence and prevent falls.
- Aerobic Guideline: Aim for 150 to 300 minutes of moderate-intensity activity per week, or as much as abilities allow if unable to meet the full baseline.
- Multicomponent Guideline: Include balance training, aerobic activity, and muscle-strengthening exercises (at least 2 days/week) to maintain functional independence and prevent falls.
- My Adapted Weekly Action Plan for Rosa: Monday, Wednesday, Friday: Two 15-minute low-impact walking sessions (or water walking) daily = 30 minutes/day × 3 days = 90 minutes moderate aerobic . Tuesday and Thursday: 15 minutes of chair-assisted squats, heel-to-toe tandem balance stands, and seated resistance band rows = 2 days multicomponent balance & strength .
- Monday, Wednesday, Friday: Two 15-minute low-impact walking sessions (or water walking) daily = 30 minutes/day × 3 days = 90 minutes moderate aerobic .
- Tuesday and Thursday: 15 minutes of chair-assisted squats, heel-to-toe tandem balance stands, and seated resistance band rows = 2 days multicomponent balance & strength .
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Rosa's fear of walking with knee osteoarthritis is a protective instinct that can trap her in a dangerous cycle of disuse atrophy, synovial stiffness, and heightened fall risk. If an unverified AI chatbot prescribed high-impact outdoor jogging or unsupported lunges in Yuma's heat, the compressive joint shear and thermal strain would flare her osteoarthritis and risk a fall. Grounded in PAGA 2018 special population guidelines, our priority is multicomponent low-impact movement matched to her functional ability: indoor stationary cycling and water aerobics lubricate articular cartilage without impact forces, while chair-supported sit-to-stands and heel-to-toe balance drills strengthen her quadriceps and proprioceptive control safely."
- My Memorable Coaching Takeaway: EN: "Movement is medicine for every body—adapting exercise to your abilities protects joints and builds lasting independence!" ES: "¡El movimiento es medicina para todos los cuerpos: adaptar el ejercicio a tus capacidades protege las articulaciones y fomenta una independencia duradera!"
- EN: "Movement is medicine for every body—adapting exercise to your abilities protects joints and builds lasting independence!"
- ES: "¡El movimiento es medicina para todos los cuerpos: adaptar el ejercicio a tus capacidades protege las articulaciones y fomenta una independencia duradera!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M01_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 01 (Mod 01 Coaching Sprint: Pre-Exercise Screening & Safety Gate Basics)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 01 Simulación de Coaching: Movimiento Seguro y Poblaciones Especiales

Evaluación Rápida y Aprendizaje Práctico de las Pautas Federales PAGA 2018


### Su Logro Semanal: El Movimiento como Medicina

¡Bienvenido a su primera sesión de coaching! Esta actividad está diseñada para darle un logro claro y sin estrés. Elegirá un caso práctico, conversará con su Coach de IA y dominará la regla federal fundamental de PAGA 2018: la actividad física adaptada es segura y esencial para personas con afecciones crónicas y discapacidades (150 minutos de actividad moderada + entrenamiento multicomponente de balance y fuerza) .


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-265 Poblaciones Especiales ###:
Rol: Coach de Ejercicio para Poblaciones Especiales de KIN-265 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Adultos Mayores y Condiciones Cronicas.

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla por que la inactividad fisica es perjudicial para las afecciones cronicas y como las pautas PAGA 2018 (150 minutos de actividad moderada adaptada + ejercicio multicomponente de balance y fuerza) ayudan a mi cliente.
Step 3: Guiar al estudiante para elaborar un plan semanal adaptado y facil que respete las capacidades fisicas actuales de su cliente de forma segura.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como el movimiento adaptado protege las articulaciones y fomenta la independencia.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de salud/movilidad de su cliente.
- Pautas PAGA 2018 para Poblaciones Especiales (SSoT): Cite las pautas federales para personas con condiciones crónicas o discapacidades (150 min adaptados + balance/fuerza).
- Mi Plan Semanal Adaptado: Describa un horario realista y seguro de 5 días adaptado a la condición de su cliente.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué su filtro de seguridad previo y su plan multicomponente adaptado protegen a su cliente según las pautas PAGA 2018 para poblaciones especiales.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, el miedo de Rosa a caminar por su osteoartritis de rodilla puede atraparla en un ciclo peligroso de atrofia muscular, rigidez articular y mayor riesgo de caídas. Si una IA genérica le recetara trotar en pavimento bajo el calor de Yuma, el impacto articular agravaría su dolor. Siguiendo las pautas de PAGA 2018 para poblaciones especiales, prescribimos movimiento multicomponente de bajo impacto: bicicleta estática en interiores, ejercicios de fuerza desde silla y equilibrio con apoyo, fortaleciendo sus cuádriceps sin sobrecargar sus rodillas."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:
