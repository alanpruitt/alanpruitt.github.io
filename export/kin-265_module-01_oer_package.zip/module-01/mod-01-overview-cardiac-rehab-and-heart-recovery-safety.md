# KIN-265: Mod 01 Overview Cardiac Rehab And Heart Recovery Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 01 Overview: Cardiac Rehab & Heart Recovery Safety


### Welcome to Module 01: Cardiac Rehab & Heart Recovery Safety

Welcome to KIN-265! In Phase III outpatient cardiac rehabilitation, our primary clinical objective is restoring functional aerobic capacity and muscular endurance without crossing into myocardial ischemia. Grounded in our academic Single Source of Truth (SSoT)—the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —we evaluate myocardial oxygen demand through the Rate Pressure Product (Double Product: $\text{DP} = \text{HR} \times \text{SBP}$) and establish non-negotiable target heart rate safety ceilings ($\text{Ischemic Threshold} - 10\text{ bpm}$).

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will audit hemodynamic stress testing patterns, apply clinical sternal stability and ischemic ceiling rules, and solve exercise programming challenges for post-CABG and cardiac patients in Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, August 18, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, August 20, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, August 23, 2026, at 11:59 PM MST
- Lab 01 Direct Submission / Entrega de Laboratorio: Monday, August 24, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 01 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Extract baseline clinical stress test data, ischemic ST-segment depression markers ($\ge 1\text{ mm}$), and surgical sternotomy timelines. Extraer datos basales de pruebas de esfuerzo, marcadores de infradesnivel del segmento ST (≥ 1 mm) y tiempos de cicatrización posquirúrgica.
- CLO 2 (Rule Application): Apply PAGA 2018 chronic disease guidelines and clinical safety thresholds ($\text{HR Ceiling} = \text{Ischemic Onset} - 10\text{ bpm}$; sternal loading $< 10\text{ lbs}$) to protect cardiovascular patients. Aplicar pautas PAGA 2018 y límites de seguridad clínica (límite de FC = umbral isquémico - 10 lpm; carga esternal < 10 lbs) en pacientes cardíacos.
- CLO 3 (Problem Solving): Formulate an individualized Phase III cardiac exercise prescription with RPE telemetry monitoring, strict termination criteria, and heat-adapted parameters for Yuma County. Diseñar una prescripción de Fase III con monitoreo de esfuerzo (RPE), criterios estrictos de finalización y adaptaciones para el calor de Yuma.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit cardiovascular rehabilitation across your chosen career track:

Auditing post-CABG surgical recovery (J.R., 64), calculating Double Product limits, and enforcing sternal healing restrictions in an outpatient hospital setting.

Supervising safe, low-intensity indoor community walking and resistance circuits for seniors with stable coronary artery disease in Yuma County.

Reconditioning a master's endurance athlete post-stent placement, establishing rate-pressure product boundaries and avoiding myocardial strain during training.


### Module 01 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Clinical Readings: Cardiac Rehabilitation & PAGA 2018 Standards
- Discussion Board 01: Peer Self-Introduction & Community Connection
- Lab Assignment 01: Phase III Cardiac Rehab Audit & Gemini AI Tool Box
- Module 01 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 01 (Mod 01 Overview: Cardiac Rehab & Heart Recovery Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 01 Visión General: Rehabilitación Cardíaca y Límites de Seguridad Isquémica


### Bienvenido al Módulo 01: Rehabilitación Cardíaca Ambulatoria y Límites Hemodinámicos

¡Bienvenido a KIN-265! En la Fase III de rehabilitación cardíaca ambulatoria, nuestro objetivo clínico primordial es restaurar la capacidad funcional y la fuerza sin cruzar al territorio de la isquemia miocárdica. Fundamentados en nuestra Fuente Única de Verdad (SSoT)—las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) —evaluamos la demanda miocárdica de oxígeno mediante el Doble Producto ($\text{DP} = \text{FC} \times \text{PAS}$) y establecemos techos de seguridad estrictos ($\text{Umbral Isquémico} - 10\text{ lpm}$).

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará patrones en pruebas de esfuerzo, aplicará precauciones esternales posquirúrgicas y diseñará programas de ejercicio seguros adaptados al clima de Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 18 de agosto de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 20 de agosto de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 23 de agosto de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 01: Lunes, 24 de agosto de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Extraer datos de pruebas de esfuerzo, identificar infradesnivel del segmento ST (≥ 1 mm) y evaluar tiempos de cicatrización esternal.
- CLO 2 (Regla): Aplicar normas de PAGA 2018 para condiciones crónicas y límites clínicos (límite de FC = umbral isquémico - 10 lpm; carga esternal < 10 lbs).
- CLO 3 (Solución): Prescribir protocolos de Fase III con monitoreo de esfuerzo (RPE 11–13) y adaptaciones térmicas para el condado de Yuma.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la rehabilitación cardiovascular a través de su ruta profesional:

Auditoría de recuperación posquirúrgica (J.R., 64 años), cálculo de límites de Doble Producto y precauciones esternales en entorno ambulatorio.

Supervisión de caminatas de baja intensidad y circuitos de fuerza en interiores para adultos mayores con cardiopatía coronaria estable.

Reacondicionamiento de atletas máster poscolocación de stent, manteniendo límites seguros de presión-frecuencia cardíaca.


### Ruta de Aprendizaje del Módulo 01

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Clínicas: Rehabilitación Cardíaca y Normas PAGA 2018
- Foro de Discusión 01: Presentación Personal y Conexión Comunitaria
- Laboratorio 01: Auditoría de Rehabilitación Cardíaca Fase III y Gemini IA
- Comprobación de Conocimientos y Resumen del Módulo 01

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 01 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 01 Required Readings: Cardiac Rehab & Heart Recovery Safety →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 01 Discussion: Meet Your Classmates & Special Populations Goals →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 01 Coaching Sprint: Pre-Exercise Screening & Safety Gate Basics →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 01 Lab: Heart Recovery & Safe Exercise Limits Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 01 Summary & Wrap-Up: Cardiac Rehab & Heart Recovery Safety →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
