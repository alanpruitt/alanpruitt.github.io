## HLTH-150: Mod 11 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 11 Lab & Simulation: Supplement Label & Safety Verification Audit

Laboratorio del Módulo 11: Auditoría de Riesgo de Suplementos y Análisis Regulatorio

- Food-First Principle (DGA 2025–2030 Whole-Food Priority): Whole foods provide synergistic matrices of protein, fiber, micronutrients, and phytochemicals that isolated powders and pills cannot replicate. En palabras sencillas: Primero la comida real: ningún polvo ni pastilla sustituye los nutrientes completos de una comida bien balanceada.
- Third-Party Contamination Verification (NSF Certified for Sport / Informed-Choice): Dietary supplements are not pre-approved by the FDA under DSHEA (1994); athletes must verify independent third-party batch testing to avoid banned substances or heavy metals. En palabras sencillas: Como los suplementos no pasan control previo de la FDA, siempre busca sellos como NSF Certified for Sport o Informed-Choice para evitar sustancias prohibidas o contaminantes.
- Proprietary Blends vs. Evidence-Based Ergogenic Dosing: Proprietary blends hide exact ingredient amounts and often mask excessive stimulants; evidence-based supplements (e.g., creatine monohydrate 3–5 g/day) list exact single-ingredient doses. En palabras sencillas: Rechaza etiquetas con 'mezclas patentadas' (proprietary blends) que esconden cuánto traen de cada ingrediente o meten exceso de cafeína.

### DSHEA Regulatory Realities, Class A Ergogenic Dosing & Third-Party Certification

In this laboratory assignment, you will conduct a clinical supplement safety audit and construct an evidence-based ergogenic recommendation. Grounded in the 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) and using the Clinical Framing Protocol (Pattern / Rule / Solve) , you will analyze the lack of FDA pre-market approval under the Dietary Supplement Health and Education Act (DSHEA of 1994), calculate precise dosages for Class A ergogenic aids, mandate third-party batch testing seals (NSF Certified for Sport / Informed-Sport), and execute an AI-driven safety audit using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría de seguridad de suplementos dietéticos, aplicando las Guías Alimentarias para Estadounidenses 2025-2030 (enfoque de comida real), el Protocolo de Encuadre Clínico (Patrón / Regla / Solución), las regulaciones de DSHEA (1994) y la certificación de lotes de terceros.

- HLTH-150.11.3.AY26-27: Evaluate dietary supplement safety hazards, DSHEA regulatory gaps, and Class A ergogenic dosing boundaries across clinical, community, and athletic populations. Evaluar los riesgos de suplementos, vacíos regulatorios de DSHEA y dosificación de ayudas ergogénicas Clase A.
- HLTH-150.11.4.AY26-27: Design food-first supplement risk mitigation protocols and bilingual coaching cue cards aligned with 2025-2030 Dietary Guidelines for Americans. Diseñar protocolos de mitigación de riesgos de suplementos y tarjetas de instrucción bilingües según las Guías Alimentarias 2025-2030.
- Module Window / Ventana del Módulo: Opens Tuesday, October 27, 2026, at 12:00 AM MST Abre el martes, 27 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, November 2, 2026, at 11:59 PM MST Lunes, 2 de noviembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Scale) Ponderación de evaluación para laboratorios semanales y simulaciones prácticas

### Lab Objectives

Objetivos del Laboratorio

- Audit the physiological risks of unverified retail supplements, proprietary stimulant blends, and sympathomimetic amine toxicity. Auditar los riesgos fisiológicos de suplementos comerciales no verificados y mezclas propietarias de estimulantes.
- Apply federal 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) and sports nutrition dosing rules for Class A ergogenic aids (creatine monohydrate 0.03 g/kg/day, beta-alanine 3.2-6.4 g/day, caffeine 3-6 mg/kg). Aplicar las Guías Alimentarias 2025-2030 y las reglas de dosificación para ayudas ergogénicas Clase A.
- Formulate a 4-week food-first supplement safety protocol paired with mandatory third-party batch testing verification (NSF Certified for Sport). Formular un protocolo de seguridad de suplementos de 4 semanas con certificación obligatoria de lotes por terceros.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-11

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos del Caso de Suplementación

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Cardiovascular safety in rehabilitation; managing beta-blocker drug interactions and proprietary stimulant pre-workout toxicity.

Focus: Community supplement literacy; addressing imported "miracle fat-burner" capsules, sympathomimetic side effects, and deceptive claims.

Focus: Collegiate athletic ergogenics; calculating Class A dosing (creatine & beta-alanine) and enforcing NSF Certified for Sport anti-doping compliance.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete supplement risk audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline supplement profile.
- Part 1: Pattern Recognition: Identify specific supplement hazards (proprietary stimulant blends, unverified online compounds, or anti-doping contamination risks).
- Part 2: Rule Application: Cite DSHEA 1994 regulatory realities, 2025-2030 Dietary Guidelines for Americans real-food baselines, and Class A ergogenic dosing parameters.
- Part 3: Solving the Gap (Active Verification & Safety Protocol): In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your food-first strategy and third-party testing requirement (NSF Certified for Sport) protect client safety and eliminate legal/physiological hazards under the 2025-2030 Dietary Guidelines for Americans. Detail your specific dosing, retail verification steps, and 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 11 Lab • Track 3 (Sports Performance / K.L.)

- Selected Track & Client Initials: Track 3: Sports Performance & Coaching Path • Collegiate Sprinter K.L. (Age 21, Female, Body Mass: 78.0 kg). Goal: Optimize sprint acceleration, anaerobic power output, and repeat-sprint buffering.
- Part 1: Pattern Recognition: K.L. seeks to utilize creatine monohydrate and beta-alanine to enhance power. However, considering retail powders with proprietary stimulant blends introduces an unacceptable hazard of contamination with WADA/NCAA-banned substances (such as dehydroepiandrosterone or synthetic stimulants), which would result in immediate athletic disqualification.
- Part 2: Rule Application (2025-2030 Dietary Guidelines & Ergogenic Standards): Under the 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) and sports nutrition consensus, athletes must establish baseline whole-food adequacy before introducing ergogenic aids. Both creatine monohydrate and beta-alanine are Class A ergogenic aids with proven anaerobic efficacy. Clinical dosing rules require: Creatine Monohydrate: Daily maintenance dose of 0.03 g/kg/day = 2.3 g/day (rounded to 3.0 g/day for practical single-dose compliance) or 5-day loading at 0.3 g/kg/day (23.4 g/day split into four 5.8g doses). Beta-Alanine: 3.2 g/day split into two 1.6g doses taken with meals to prevent paresthesia. Third-Party Rule: Collegiate athletes must exclusively choose products certified by NSF Certified for Sport or Informed-Sport .
- Creatine Monohydrate: Daily maintenance dose of 0.03 g/kg/day = 2.3 g/day (rounded to 3.0 g/day for practical single-dose compliance) or 5-day loading at 0.3 g/kg/day (23.4 g/day split into four 5.8g doses).
- Beta-Alanine: 3.2 g/day split into two 1.6g doses taken with meals to prevent paresthesia.
- Third-Party Rule: Collegiate athletes must exclusively choose products certified by NSF Certified for Sport or Informed-Sport .
- Part 3: Solving the Gap (Active Verification & Safety Protocol): 4-Week Supplement Risk Mitigation Plan: Step 1 (Food-First Optimization): Increase dietary complex carbohydrate intake (6-8 g/kg) and consume lean red meat and salmon providing naturally occurring dietary creatine. Step 2 (Clinical Dosing): Prescribe NSF Certified pure creatine monohydrate at a conservative 3.0 g/day post-workout with whole fruit, and beta-alanine at 3.2 g/day split into two 1.6g doses. Step 3 (Third-Party Batch Audit): Require K.L. to scan every container batch lot number using the NSF Certified for Sport mobile app before breaking the container seal. Active Verification: In my clinical reasoning, K.L.'s greatest career vulnerability is not a lack of power, but an inadvertent positive anti-doping test triggered by unverified retail powders. Because DSHEA of 1994 exempts supplement manufacturers from FDA safety testing, unverified "proprietary blends" frequently harbor undeclared stimulants and cross-contaminants. By establishing a whole-food nutritional foundation aligned with the 2025-2030 Dietary Guidelines and strictly restricting supplementation to pure, single-ingredient compounds bearing the NSF Certified for Sport seal, we safely maximize her anaerobic energy pathways while guaranteeing absolute compliance with NCAA and WADA anti-doping mandates. Bilingual Coaching Cue Card: EN: "Prioritize whole-food nutrition first, verify that every supplement carries the NSF Certified for Sport seal, and stick to three grams of pure creatine daily with your recovery meal." ES: "Priorice la nutrición con alimentos integrales, verifique que cada suplemento tenga el sello NSF Certified for Sport y tome tres gramos diarios de creatina pura con su comida de recuperación."
- 4-Week Supplement Risk Mitigation Plan: Step 1 (Food-First Optimization): Increase dietary complex carbohydrate intake (6-8 g/kg) and consume lean red meat and salmon providing naturally occurring dietary creatine. Step 2 (Clinical Dosing): Prescribe NSF Certified pure creatine monohydrate at a conservative 3.0 g/day post-workout with whole fruit, and beta-alanine at 3.2 g/day split into two 1.6g doses. Step 3 (Third-Party Batch Audit): Require K.L. to scan every container batch lot number using the NSF Certified for Sport mobile app before breaking the container seal.
- Step 1 (Food-First Optimization): Increase dietary complex carbohydrate intake (6-8 g/kg) and consume lean red meat and salmon providing naturally occurring dietary creatine.
- Step 2 (Clinical Dosing): Prescribe NSF Certified pure creatine monohydrate at a conservative 3.0 g/day post-workout with whole fruit, and beta-alanine at 3.2 g/day split into two 1.6g doses.
- Step 3 (Third-Party Batch Audit): Require K.L. to scan every container batch lot number using the NSF Certified for Sport mobile app before breaking the container seal.
- Active Verification: In my clinical reasoning, K.L.'s greatest career vulnerability is not a lack of power, but an inadvertent positive anti-doping test triggered by unverified retail powders. Because DSHEA of 1994 exempts supplement manufacturers from FDA safety testing, unverified "proprietary blends" frequently harbor undeclared stimulants and cross-contaminants. By establishing a whole-food nutritional foundation aligned with the 2025-2030 Dietary Guidelines and strictly restricting supplementation to pure, single-ingredient compounds bearing the NSF Certified for Sport seal, we safely maximize her anaerobic energy pathways while guaranteeing absolute compliance with NCAA and WADA anti-doping mandates.
- Bilingual Coaching Cue Card: EN: "Prioritize whole-food nutrition first, verify that every supplement carries the NSF Certified for Sport seal, and stick to three grams of pure creatine daily with your recovery meal." ES: "Priorice la nutrición con alimentos integrales, verifique que cada suplemento tenga el sello NSF Certified for Sport y tome tres gramos diarios de creatina pura con su comida de recuperación."
- Repository Verification: AI Preceptor audit log exported and archived: EXW_Professional_AI_Repository / EXW_150_M11_Supplement_Audit.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 11 (Mod 11 Lab: Supplement Label & Safety Verification Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 11 Práctica de Laboratorio: Auditoría de Riesgo de Suplementos

Análisis Regulatorio DSHEA, Dosificación Clase A y Certificación de Lotes


### Visión General del Laboratorio

Ejecute una auditoría clínica utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluando vacíos de DSHEA, aplicando pautas de las Guías Alimentarias 2025-2030 ("comida real") y redactando su verificación activa en su propia voz profesional.


### Estructura de Entrega


#### Parte 1: Reconocimiento de Patrones

Identifique riesgos de contaminación, mezclas propietarias o interacciones estimulantes en el caso del cliente.


#### Parte 2: Aplicación de Reglas (DSHEA 1994 / Guías Alimentarias 2025-2030)

Aplique los estándares de dosificación para ayudas Clase A (creatina y beta-alanina) y la exigencia de sellos de terceros (NSF Certified for Sport).


#### Parte 3: Resolución de la Brecha (Verificación Activa y Protocolo)

Detalle el protocolo de 3 pasos, redacte su verificación activa de 100 a 150 palabras justificando la seguridad y proporcione la tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

Patrón: Atleta universitaria de 21 años (78 kg) expuesta a riesgo de suspensión por considerar polvos comerciales con mezclas propietarias y estimulantes no declarados.

Regla: Bajo DSHEA de 1994 no hay supervisión previa de seguridad por la FDA. La creatina pura debe dosificarse a 0.03 g/kg/día (2.3 g/día) y la beta-alanina a 3.2 g/día dividida. Se exige verificación obligatoria mediante NSF Certified for Sport o Informed-Sport.

Solución y Verificación Activa: En mi criterio clínico, el mayor peligro para K.L. no es la falta de fuerza, sino un resultado analítico adverso en una prueba antidopaje debido a la contaminación cruzada en suplementos comerciales no verificados. Al establecer que los alimentos integrales son la prioridad número uno y exigir que cualquier ayuda ergogénica porte el sello NSF Certified for Sport—que evalúa lotes contra más de 280 sustancias prohibidas—garantizamos una mejora del rendimiento segura, ética y legal.

ES: "Priorice la nutrición con alimentos integrales, verifique que cada suplemento tenga el sello NSF Certified for Sport y tome tres gramos diarios de creatina pura con su comida de recuperación."

HLTH-150 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 11)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 11)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
