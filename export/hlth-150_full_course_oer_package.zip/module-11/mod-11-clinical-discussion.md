# HLTH-150: Mod 11 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 11 Discussion: Spotting Unsafe Supplement Claims


### Dietary Supplement Regulations, Class A Ergogenic Aids & Consumer Protection

Under the Dietary Supplement Health and Education Act (DSHEA of 1994), dietary supplements do not require FDA pre-market safety or efficacy approval prior to retail distribution. In regional fitness centers and community stores across Yuma County, shelves are lined with unverified herbal compounds, stimulant-laced pre-workouts, and exaggerated performance claims. As exercise and sports nutrition professionals, our responsibility is to audit supplements against rigorous scientific evidence (Class A ergogenics: creatine monohydrate, caffeine, beta-alanine, sodium bicarbonate) and mandate third-party batch testing seals ( NSF Certified for Sport or Informed-Sport ) to protect client health and prevent inadvertent anti-doping violations. Select your Build Your Own Journey Track below, audit a real-world scenario using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / U.S. Dietary Guidelines / ACSM Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #150-11

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Managing stimulant interactions and cardiovascular risk in clinical rehabilitation patients taking unverified over-the-counter supplements.

Focus: Counteracting deceptive marketing and unverified online fat-burners among community residents in Yuma County.

Focus: Safe ergogenic aid implementation (Creatine & Beta-Alanine) and anti-doping third-party testing in collegiate athletes.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Supplement Risk / Ruta y Riesgo de Suplemento: State your chosen track and identify the specific safety, physiological, or regulatory hazards present in the client's scenario. Indique la ruta seleccionada e identifique los riesgos específicos de seguridad, fisiológicos o regulatorios presentes en el caso.
- Clinical Framing Protocol Analysis (Pattern / Rule / Solve) / Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Explain how DSHEA regulations impact product safety (Pattern), apply Class A ergogenic standards and third-party testing rules (Rule), and formulate your food-first safety protocol and dosage plan (Solve). Explique el impacto de DSHEA (Patrón), aplique las normas de ayudas Clase A y pruebas de terceros (Regla) y formule su protocolo de seguridad y dosificación (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence client education card in both English and Spanish emphasizing third-party verification and safe usage. Proporcione una tarjeta educativa concisa de 2 oraciones en inglés y español enfatizando la certificación de terceros y el uso seguro.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Compare third-party certification challenges, discuss how DSHEA loopholes affect diverse populations, and evaluate their food-first recommendations.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Collegiate sprinter K.L. seeks to enhance anaerobic power using creatine monohydrate and beta-alanine. However, purchasing unverified retail brands with proprietary blends exposes her to significant cross-contamination risks with WADA-prohibited substances, which could result in a catastrophic collegiate suspension.

Rule Application (DSHEA 1994 / ACSM / WADA Standards): Under DSHEA (1994), FDA pre-market verification does not exist. Both creatine monohydrate and beta-alanine are Class A ergogenic aids with robust safety profiles. Clinical dosing protocols require creatine maintenance at 0.03 g/kg/day (2.3 g/day) or a 5-day loading protocol at 0.3 g/kg/day (23 g/day split into 4 doses), and beta-alanine at 3.2 to 6.4 g/day split into smaller doses to avoid paresthesia. Collegiate athletes must exclusively choose products verified by NSF Certified for Sport or Informed-Sport .

Solve (Supplement Safety Protocol & Dosing Plan): We institute a 3-step food-first supplement protocol:

- Step 1 (Food-First Adequacy): Optimize daily carbohydrate and lean protein intake prior to supplement initiation.
- Step 2 (Clinical Dosing): Prescribe NSF Certified creatine monohydrate at a conservative 3.0 g/day daily maintenance dose and beta-alanine at 3.2 g/day (split into two 1.6g doses with meals).
- Step 3 (Third-Party Batch Audit): Require K.L. to look up each product batch code on the NSF Certified for Sport mobile database prior to consumption.
EN: "Only consume supplements carrying the NSF Certified for Sport seal, and stick to 3 grams of pure creatine monohydrate daily with a post-workout meal."

ES: "Consuma únicamente suplementos con el sello NSF Certified for Sport y mantenga 3 gramos diarios de creatina monohidratada pura con su comida post-entrenamiento."


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 11 (Mod 11 Discussion: Spotting Unsafe Supplement Claims)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 11 Foro de Discusión: Afirmaciones de Suplementos vs. Pruebas de Terceros


### Regulaciones de Suplementos, Ayudas Clase A y Protección al Consumidor

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar la seguridad de los suplementos dietéticos, los vacíos de la ley DSHEA (1994) y la necesidad de certificaciones de lotes de terceros.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Identifique los riesgos del suplemento en el caso del cliente (ej. estimulantes ocultos, mezclas propietarias o riesgo de contaminación cruzada).


#### Parte 2: Aplicación de Reglas (DSHEA 1994 / Estándares ACSM)

Explique la falta de verificación previa de la FDA, los criterios para ayudas Clase A (creatina y cafeína) y la exigencia de sellos de certificación de terceros como NSF Certified for Sport.


#### Parte 3: Resolución de la Brecha (Protocolo de Seguridad y Tarjeta Bilingüe)

Diseñe un protocolo de 3 pasos (comida primero, validación Clase A, auditoría de lote) con dosificación exacta y proporcione una tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

Patrón: La atleta K.L. busca maximizar potencia con creatina y beta-alanina, pero adquirir productos comerciales sin certificar pone en grave peligro su elegibilidad competitiva por riesgo de contaminación con sustancias prohibidas.

Regla: Bajo DSHEA de 1994, no hay supervisión de seguridad previa por la FDA. La creatina pura debe dosificarse a 0.03 g/kg/día (2.3 g/día) y la beta-alanina a 3.2 g/día dividida en dosis pequeñas. Se exige verificación obligatoria mediante NSF Certified for Sport o Informed-Sport.

Solución: Priorizar la ingesta de carbohidratos integrales, prescribir 3 g/día de monohidrato de creatina certificado por NSF y auditar el código de lote en la base de datos de NSF antes de ingerirlo.

ES: "Consuma únicamente suplementos con el sello NSF Certified for Sport y mantenga 3 gramos diarios de creatina monohidratada pura con su comida post-entrenamiento."

HLTH-150 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
