## HLTH-150: Mod 11 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 11) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 11 Discussion: Spotting Unsafe Supplement Claims


### Dietary Supplement Regulations, Class A Ergogenic Aids & Consumer Protection

Under the Dietary Supplement Health and Education Act (DSHEA of 1994), dietary supplements do not require FDA pre-market safety or efficacy approval prior to retail distribution. In regional fitness centers and community stores across Yuma County, shelves are lined with unverified herbal compounds, stimulant-laced pre-workouts, and exaggerated performance claims. As exercise and sports nutrition professionals, our responsibility is to audit supplements against rigorous scientific evidence (Class A ergogenics: creatine monohydrate, caffeine, beta-alanine, sodium bicarbonate) and mandate third-party batch testing seals ( NSF Certified for Sport or Informed-Sport ) to protect client health and prevent inadvertent anti-doping violations. Select your Build Your Own Journey Track below, audit a real-world scenario using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / U.S. Dietary Guidelines / ACSM Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #150-11

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Managing stimulant interactions and cardiovascular risk in clinical rehabilitation patients taking unverified over-the-counter supplements.

Focus: Counteracting deceptive marketing and unverified online fat-burners among community residents in Yuma County.

Focus: Safe ergogenic aid implementation (Creatine & Beta-Alanine) and anti-doping third-party testing in collegiate athletes.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Supplement Risk / Ruta y Riesgo de Suplemento: State your chosen track and identify the specific safety, physiological, or regulatory hazards present in the client's scenario. Indique la ruta seleccionada e identifique los riesgos específicos de seguridad, fisiológicos o regulatorios presentes en el caso.
- Clinical Framing Protocol Analysis (Pattern / Rule / Solve) / Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Explain how DSHEA regulations impact product safety (Pattern), apply Class A ergogenic standards and third-party testing rules (Rule), and formulate your food-first safety protocol and dosage plan (Solve). Explique el impacto de DSHEA (Patrón), aplique las normas de ayudas Clase A y pruebas de terceros (Regla) y formule su protocolo de seguridad y dosificación (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence client education card in both English and Spanish emphasizing third-party verification and safe usage. Proporcione una tarjeta educativa concisa de 2 oraciones en inglés y español enfatizando la certificación de terceros y el uso seguro.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Compare third-party certification challenges, discuss how DSHEA loopholes affect diverse populations, and evaluate their food-first recommendations.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Collegiate sprinter K.L. seeks to enhance anaerobic power using creatine monohydrate and beta-alanine. However, purchasing unverified retail brands with proprietary blends exposes her to significant cross-contamination risks with WADA-prohibited substances, which could result in a catastrophic collegiate suspension.

Rule Application (DSHEA 1994 / ACSM / WADA Standards): Under DSHEA (1994), FDA pre-market verification does not exist. Both creatine monohydrate and beta-alanine are Class A ergogenic aids with robust safety profiles. Clinical dosing protocols require creatine maintenance at 0.03 g/kg/day (2.3 g/day) or a 5-day loading protocol at 0.3 g/kg/day (23 g/day split into 4 doses), and beta-alanine at 3.2 to 6.4 g/day split into smaller doses to avoid paresthesia. Collegiate athletes must exclusively choose products verified by NSF Certified for Sport or Informed-Sport .

Solve (Supplement Safety Protocol & Dosing Plan): We institute a 3-step food-first supplement protocol:

- Step 1 (Food-First Adequacy): Optimize daily carbohydrate and lean protein intake prior to supplement initiation.
- Step 2 (Clinical Dosing): Prescribe NSF Certified creatine monohydrate at a conservative 3.0 g/day daily maintenance dose and beta-alanine at 3.2 g/day (split into two 1.6g doses with meals).
- Step 3 (Third-Party Batch Audit): Require K.L. to look up each product batch code on the NSF Certified for Sport mobile database prior to consumption.
EN: "Only consume supplements carrying the NSF Certified for Sport seal, and stick to 3 grams of pure creatine monohydrate daily with a post-workout meal."

ES: "Consuma únicamente suplementos con el sello NSF Certified for Sport y mantenga 3 gramos diarios de creatina monohidratada pura con su comida post-entrenamiento."


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 11 (Mod 11 Discussion: Spotting Unsafe Supplement Claims)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 11 Foro de Discusión: Afirmaciones de Suplementos vs. Pruebas de Terceros


### Regulaciones de Suplementos, Ayudas Clase A y Protección al Consumidor

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar la seguridad de los suplementos dietéticos, los vacíos de la ley DSHEA (1994) y la necesidad de certificaciones de lotes de terceros.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Identifique los riesgos del suplemento en el caso del cliente (ej. estimulantes ocultos, mezclas propietarias o riesgo de contaminación cruzada).


#### Parte 2: Aplicación de Reglas (DSHEA 1994 / Estándares ACSM)

Explique la falta de verificación previa de la FDA, los criterios para ayudas Clase A (creatina y cafeína) y la exigencia de sellos de certificación de terceros como NSF Certified for Sport.


#### Parte 3: Resolución de la Brecha (Protocolo de Seguridad y Tarjeta Bilingüe)

Diseñe un protocolo de 3 pasos (comida primero, validación Clase A, auditoría de lote) con dosificación exacta y proporcione una tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

Patrón: La atleta K.L. busca maximizar potencia con creatina y beta-alanina, pero adquirir productos comerciales sin certificar pone en grave peligro su elegibilidad competitiva por riesgo de contaminación con sustancias prohibidas.

Regla: Bajo DSHEA de 1994, no hay supervisión de seguridad previa por la FDA. La creatina pura debe dosificarse a 0.03 g/kg/día (2.3 g/día) y la beta-alanina a 3.2 g/día dividida en dosis pequeñas. Se exige verificación obligatoria mediante NSF Certified for Sport o Informed-Sport.

Solución: Priorizar la ingesta de carbohidratos integrales, prescribir 3 g/día de monohidrato de creatina certificado por NSF y auditar el código de lote en la base de datos de NSF antes de ingerirlo.

ES: "Consuma únicamente suplementos con el sello NSF Certified for Sport y mantenga 3 gramos diarios de creatina monohidratada pura con su comida post-entrenamiento."

HLTH-150 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 11)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 11)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
