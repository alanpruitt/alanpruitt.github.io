# HLTH-150: Mod 11 Required Readings Sports Supplements Label Safety And Food First Rules

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 11 Required Readings: Sports Supplements, Label Safety & Food-First Rules

Lecturas Obligatorias: Ayudas Ergogénicas, Regulaciones DSHEA y Seguridad en Suplementos


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Third-party supplement verification (such as USP or NSF Certified for Sport) checks that a product actually contains what its label claims without banned contaminants. Because dietary supplements are not pre-approved like prescription drugs, unverified powders carry contamination and health risks. Applying a Food-First rule protects athletes from unsafe stimulants and wasted money.


#### En Palabras Sencillas (Norteño Context)

Comprar suplementos sin sello verificado es como comprar refacciones sin marca en un tianguis: no sabes qué traen adentro. Si los términos técnicos se ponen pesados, concéntrate primero en el principio de Comida Real Primero y cómo verificar sellos de seguridad NSF o USP.


### Regional Focus: Consumer Safety & Supplement Fraud in Yuma County

Enfoque Regional: Seguridad del Consumidor y Fraude de Suplementos en el Condado de Yuma

In Yuma County and border-adjacent regions, retail stores and online marketplaces frequently stock imported or unregulated dietary supplements making exaggerated health and performance claims. Under U.S. law (DSHEA), dietary supplements do not require FDA approval for safety or efficacy prior to market entry. Consequently, consumer safety relies heavily on professional auditing, third-party batch testing (NSF, Informed-Sport), and strict adherence to evidence-based standards.

En el condado de Yuma y regiones fronterizas, los comercios y mercados en línea frecuentemente ofrecen suplementos importados o no regulados con afirmaciones exageradas. Bajo la ley de EE. UU. (DSHEA), los suplementos no requieren aprobación previa de la FDA, por lo que la seguridad del consumidor depende de auditorías profesionales y certificaciones de terceros.


### Reading 1: Ergogenic Aid Classifications & Class A Evidence

Lectura 1: Clasificación de Ayudas Ergogénicas y Evidencia Clase A


#### Step 1: Defining Ergogenic Aids and Scientific Validation

Definición de Ayudas Ergogénicas y Validación Científica

An ergogenic aid is any training technique, mechanical device, nutritional practice, pharmacological method, or dietary supplement that can improve exercise performance, energy production, or recovery capacity. Sports science categorizes supplements based on peer-reviewed evidence into validated (Class A) agents and unproven compounds.

Una ayuda ergogénica es cualquier técnica, dispositivo, práctica nutricional o suplemento que mejora el rendimiento o la recuperación. La ciencia del deporte categoriza los suplementos según su evidencia en agentes validados (Clase A) y compuestos no probados.


#### Step 2: Validated Class A Ergogenic Agents

Agentes Ergogénicos Validados Clase A

In alignment with ISSN and ACSM position stands, four primary supplements demonstrate consistent performance enhancement:

De acuerdo con las posturas del ISSN y ACSM, cuatro suplementos principales demuestran mejora constante:

- Creatine Monohydrate: Expands phosphocreatine pools, accelerating ATP resynthesis during high-intensity, short-duration bursts and supporting lean mass accretion. Monohidrato de Creatina: Amplía las reservas de fosfocreatina, acelerando la resíntesis de ATP en esfuerzos breves de alta intensidad.
- Caffeine: Acts as an adenosine receptor antagonist in the central nervous system, reducing perceived exertion and enhancing motor unit recruitment. Cafeína: Actúa como antagonista de los receptores de adenosina en el sistema nervioso central, reduciendo el esfuerzo percibido.
- Beta-Alanine: Combines with histidine to synthesize carnosine, serving as an intracellular muscle buffer against hydrogen ion accumulation during high-intensity efforts. Beta-Alanina: Se combina con la histidina para sintetizar carnosina, sirviendo como amortiguador intracelular contra la acidosis.
- Sodium Bicarbonate: Acts as an extracellular blood buffer, neutralizing hydrogen ions generated during anaerobic glycolysis and delaying metabolic fatigue. Bicarbonato de Sodio: Actúa como amortiguador sanguíneo extracelular, neutralizando iones de hidrógeno generados en la glucólisis anaeróbica.

### Reading 2: DSHEA Regulations & Third-Party Testing Certifications

Lectura 2: Regulaciones DSHEA y Certificaciones de Terceros


#### Step 1: The Dietary Supplement Health and Education Act (DSHEA of 1994)

La Ley de Salud y Educación de Suplementos Dietéticos (DSHEA de 1994)

Enacted in 1994, DSHEA established the regulatory framework governing dietary supplements in the United States. Under DSHEA, supplements are regulated as a subset of foods rather than pharmaceuticals. Manufacturers are legally responsible for ensuring product safety prior to marketing, but they do not need to prove efficacy or obtain FDA pre-market approval . The FDA bears the burden of proof to remove unsafe products after they reach store shelves.

Promulgada en 1994, la ley DSHEA estableció el marco regulatorio de los suplementos en EE. UU. Bajo DSHEA, los suplementos se regulan como alimentos y no como fármacos. Los fabricantes son responsables de la seguridad, pero no necesitan demostrar eficacia ni obtener aprobación previa de la FDA .


#### Step 2: Third-Party Batch Testing & Anti-Doping Compliance

Pruebas de Lote de Terceros y Cumplimiento Antidopaje

Because manufacturing cross-contamination and undeclared stimulant adulteration remain prevalent in the supplement industry, collegiate and elite athletes must exclusively utilize products bearing rigorous third-party certification seals, such as NSF Certified for Sport or Informed-Sport / Informed-Choice , guaranteeing batch purity and WADA compliance.

Debido a la contaminación cruzada y la adulteración con estimulantes no declarados, los atletas deben utilizar exclusivamente productos con sellos de certificación de terceros de buena reputación (como NSF Certified for Sport o Informed-Sport), garantizando pureza y cumplimiento WADA.


### Reading 3: Safety Auditing & Risk Mitigation Protocols

Lectura 3: Auditoría de Seguridad y Protocolos de Mitigación de Riesgos

Implementing an evidence-based supplement audit protocol requires evaluating four critical safety checkpoints:

Implementar un protocolo de auditoría de suplementos basado en evidencia requiere evaluar cuatro puntos críticos de seguridad:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Under DSHEA (1994), dietary supplements are regulated as foods rather than drugs. Manufacturers do not need FDA pre-market approval for safety or efficacy; the FDA bears the burden of proof to remove unsafe products after sale.

Respuesta en Español: Bajo DSHEA (1994), los suplementos se regulan como alimentos. Los fabricantes no necesitan aprobación previa de la FDA; la agencia debe demostrar que un producto es inseguro para retirarlo del mercado.

English Response: Creatine monohydrate expands intramuscular phosphocreatine pools, accelerating the rate of ATP resynthesis during short-duration, high-intensity muscular contractions.

Respuesta en Español: La creatina amplía las reservas intramusculares de fosfocreatina, acelerando la resíntesis de ATP durante contracciones musculares breves y de alta intensidad.

English Response: Third-party testing verifies that product contents match label claims and tests for undeclared stimulants or banned substances, protecting athletes from inadvertent anti-doping rule violations.

Respuesta en Español: Las pruebas de terceros verifican que el contenido coincida con la etiqueta y analizan la ausencia de estimulantes no declarados o sustancias prohibidas, protegiendo al atleta contra violaciones antidopaje.


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 11 (Mod 11 Required Readings: Sports Supplements, Label Safety & Food-First Rules)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Module 11 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
