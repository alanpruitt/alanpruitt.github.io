# HLTH-150: Mod 11 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 11 Coaching Sprint Simulation: Food First vs. Sports Supplements

Sesión de Coaching del Módulo 11: Ayudas Ergogénicas, Regulaciones DSHEA y Auditorías de Seguridad

- Food-First Principle (DGA 2025–2030 Whole-Food Priority): Whole foods provide synergistic matrices of protein, fiber, micronutrients, and phytochemicals that isolated powders and pills cannot replicate. En palabras sencillas: Primero la comida real: ningún polvo ni pastilla sustituye los nutrientes completos de una comida bien balanceada.
- Third-Party Contamination Verification (NSF Certified for Sport / Informed-Choice): Dietary supplements are not pre-approved by the FDA under DSHEA (1994); athletes must verify independent third-party batch testing to avoid banned substances or heavy metals. En palabras sencillas: Como los suplementos no pasan control previo de la FDA, siempre busca sellos como NSF Certified for Sport o Informed-Choice para evitar sustancias prohibidas o contaminantes.
- Proprietary Blends vs. Evidence-Based Ergogenic Dosing: Proprietary blends hide exact ingredient amounts and often mask excessive stimulants; evidence-based supplements (e.g., creatine monohydrate 3–5 g/day) list exact single-ingredient doses. En palabras sencillas: Rechaza etiquetas con 'mezclas patentadas' (proprietary blends) que esconden cuánto traen de cada ingrediente o meten exceso de cafeína.
- HLTH-150.11.1.AY26-27: Evaluate DSHEA (1994) regulatory boundaries, Class A ergogenic mechanisms (creatine, caffeine, beta-alanine), and adverse stimulant interactions. Evaluar los límites regulatorios de DSHEA (1994), los mecanismos ergogénicos Clase A y las interacciones adversas de estimulantes.
- HLTH-150.11.2.AY26-27: Audit third-party batch certification seals (NSF Certified for Sport / Informed-Sport) and formulate food-first clinical safety protocols. Auditar sellos de certificación de lotes de terceros y formular protocolos clínicos de seguridad basados en alimentos integrales.

### Coach Alan's Weekly Win: Trust But Verify • The Food-First Supplement Defense

How do sports nutritionists and clinical exercise physiologists protect clients in a multi-billion-dollar supplement industry operating without FDA pre-market safety approval? Grounded in the 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) and sports nutrition science, whole-food adequacy always precedes ergogenic supplementation. Under the Dietary Supplement Health and Education Act (DSHEA of 1994), products can reach retail shelves without verified purity, dosing accuracy, or safety trials. By applying the Clinical Framing Protocol (Pattern / Rule / Solve) , practitioners separate proven Class A ergogenic aids from hazardous proprietary blends and mandate third-party batch testing seals (NSF Certified for Sport). Choose your coaching track below, consult your AI Socratic Coach, and master supplement safety auditing!

¿Cómo protegen los profesionales a sus clientes ante una industria de suplementos que no requiere aprobación previa de la FDA bajo la ley DSHEA (1994)? Basándonos en las Guías Alimentarias para Estadounidenses 2025-2030 (enfoque de comida real) y el Protocolo de Encuadre Clínico, verificamos sellos de terceros (NSF Certified for Sport). ¡Elija su ruta y dialogue con su coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Scenario: Cardiac rehab participant (J.T., 62) taking antihypertensive beta-blockers who is consuming an unverified high-stimulant retail pre-workout powder.

Scenario: Community center attendee (A.M., 38) spending personal savings on unverified imported "fat burner" capsules causing tremors and acute anxiety.

Scenario: Collegiate sprinter (K.L., 21, 78 kg) wanting to initiate creatine monohydrate and beta-alanine supplementation with guaranteed WADA anti-doping compliance.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission / Fase 3: Entrega en Canvas (Solo Texto)

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's supplement challenge.
- DSHEA & Ergogenic Analysis: Explain the lack of FDA pre-market oversight, hazards of proprietary blends, and Class A evidence for your client.
- Part 3: Active Verification & Safety Protocol: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your food-first strategy and third-party testing requirement (NSF Certified for Sport) protect client safety and eliminate legal/physiological hazards under DSHEA and sports nutrition standards.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 11 Coaching Sprint • Track 3 (Athletic Performance / K.L.)

- Chosen Track & Client: Track 3: Sports Performance & Coaching Path • Collegiate Sprinter K.L. (Age 21, 78.0 kg). Challenge: Desires to use creatine monohydrate and beta-alanine to boost repeat sprint power, but risks inadvertent anti-doping violations by considering uncertified retail brands containing proprietary stimulant blends.
- Track 3: Sports Performance & Coaching Path • Collegiate Sprinter K.L. (Age 21, 78.0 kg).
- Challenge: Desires to use creatine monohydrate and beta-alanine to boost repeat sprint power, but risks inadvertent anti-doping violations by considering uncertified retail brands containing proprietary stimulant blends.
- DSHEA & Ergogenic Analysis: DSHEA Regulatory Realities: Dietary supplements do not undergo FDA pre-market efficacy or safety testing. Uncertified retail products frequently suffer from manufacturing cross-contamination with banned prohormones or undeclared synthetic stimulants. Both creatine monohydrate and beta-alanine are Class A ergogenic aids with proven anaerobic efficacy when dosed correctly (3.0 g/day maintenance for creatine; 3.2 g/day split for beta-alanine).
- DSHEA Regulatory Realities: Dietary supplements do not undergo FDA pre-market efficacy or safety testing. Uncertified retail products frequently suffer from manufacturing cross-contamination with banned prohormones or undeclared synthetic stimulants.
- Both creatine monohydrate and beta-alanine are Class A ergogenic aids with proven anaerobic efficacy when dosed correctly (3.0 g/day maintenance for creatine; 3.2 g/day split for beta-alanine).
- Part 3: Active Verification & Safety Protocol: "Implement a food-first carbohydrate foundation, restrict supplementation exclusively to pure single-ingredient compounds carrying the NSF Certified for Sport seal, and dose creatine monohydrate at 3.0 g/day paired with a post-workout meal." Active Verification: In my clinical reasoning, K.L.'s greatest athletic threat is not a lack of power, but an inadvertent positive drug test that would terminate her collegiate track career. Because DSHEA allows manufacturers to sell untested powders with vague proprietary blends, simply trusting an over-the-counter label is a catastrophic coaching error. By enforcing a strict food-first nutrition baseline and mandating that any supplemental creatine or beta-alanine bear the NSF Certified for Sport seal—which guarantees batch-by-batch laboratory testing for over 280 banned substances—we protect both her physiological health and her athletic eligibility under NCAA/WADA standards.
- "Implement a food-first carbohydrate foundation, restrict supplementation exclusively to pure single-ingredient compounds carrying the NSF Certified for Sport seal, and dose creatine monohydrate at 3.0 g/day paired with a post-workout meal."
- Active Verification: In my clinical reasoning, K.L.'s greatest athletic threat is not a lack of power, but an inadvertent positive drug test that would terminate her collegiate track career. Because DSHEA allows manufacturers to sell untested powders with vague proprietary blends, simply trusting an over-the-counter label is a catastrophic coaching error. By enforcing a strict food-first nutrition baseline and mandating that any supplemental creatine or beta-alanine bear the NSF Certified for Sport seal—which guarantees batch-by-batch laboratory testing for over 280 banned substances—we protect both her physiological health and her athletic eligibility under NCAA/WADA standards.
- Part 4: My Memorable Coaching Takeaway: EN: "Food comes first, evidence dictates the dose, and the NSF Certified for Sport seal protects your athletic career from hidden contaminants!" ES: "¡La comida es primero, la evidencia dicta la dosis y el sello NSF Certified for Sport protege tu carrera atlética de contaminantes ocultos!"
- EN: "Food comes first, evidence dictates the dose, and the NSF Certified for Sport seal protects your athletic career from hidden contaminants!"
- ES: "¡La comida es primero, la evidencia dicta la dosis y el sello NSF Certified for Sport protege tu carrera atlética de contaminantes ocultos!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M11_Coaching_Sprint.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 11 (Mod 11 Coaching Sprint: Food First vs. Sports Supplements)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 11 Simulación de Coaching: Ayudas Ergogénicas y Auditoría de Seguridad

Evaluación Rápida de Suplementos y Cumplimiento Antidopaje


### Visión General de la Sesión

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar la seguridad de los suplementos, las realidades de la ley DSHEA y la exigencia de certificaciones de lotes de terceros.


### Estructura de Entrega


#### Parte 1: Reconocimiento de Patrones

Identifique los riesgos de suplementación, mezclas propietarias y falta de verificación de la FDA en el caso seleccionado.


#### Parte 2: Aplicación de Reglas (DSHEA 1994 / Normas de Nutrición Deportiva)

Explique las pautas para ayudas ergogénicas Clase A y la exigencia de sellos de certificación de terceros como NSF Certified for Sport.


#### Parte 3: Resolución de la Brecha (Verificación Activa y Estrategia)

Redacte su verificación activa en su propia voz justificando por qué la prioridad de alimentos integrales y la certificación NSF protegen al cliente.


### Modelo de Respuesta de Alta Fidelidad 10/10

Patrón: Atleta universitaria de 21 años (78 kg) expuesta a riesgo de suspensión por considerar polvos comerciales con mezclas propietarias y estimulantes no declarados.

Regla: Bajo DSHEA de 1994 no hay supervisión previa de seguridad por la FDA. La creatina pura debe dosificarse a 3 g/día de mantenimiento y la beta-alanina a 3.2 g/día dividida. Se exige verificación obligatoria mediante NSF Certified for Sport.

Verificación Activa y Solución: En mi criterio clínico, el mayor peligro para K.L. no es la falta de fuerza, sino un resultado analítico adverso en una prueba antidopaje debido a la contaminación cruzada en suplementos comerciales no verificados. Al establecer que los alimentos integrales son la prioridad número uno y exigir que cualquier ayuda ergogénica porte el sello NSF Certified for Sport—que evalúa lotes contra más de 280 sustancias prohibidas—garantizamos una mejora del rendimiento segura, ética y legal.

ES: "¡La comida es primero, la evidencia dicta la dosis y el sello NSF Certified for Sport protege tu carrera atlética de contaminantes ocultos!"

HLTH-150 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
