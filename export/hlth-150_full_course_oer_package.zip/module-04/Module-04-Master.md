## HLTH-150: LAB 04 - MICRONUTRIENTS / MICRONUTRIENTES 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## > ###  Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (sports nutrition requirements, hydration audits, and energy demands).

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This module explores the physiological roles of essential vitamins and minerals in regulating exercise metabolism, cellular defense, and oxygen transport. Students will evaluate real-world fluid-electrolyte balance dynamics to mitigate performance deficits without falling for commercial hydration marketing gimmicks. All recommended dietary allowances and balance frameworks align strictly with our dual SSoT: the current **U.S. Dietary Guidelines for Americans** and the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* *Español (Regional): Este módulo explora las funciones fisiológicas de las vitaminas y minerales esenciales en la regulación del metabolismo del ejercicio, la defensa celular y el transporte de oxígeno. Los estudiantes evaluarán la dinámica del equilibrio hidroelectrolítico en el mundo real para mitigar los déficits de rendimiento sin caer en trucos comerciales de marketing de hidratación. Todas las dosis e ingestas recomendadas se alinean estrictamente con nuestro SSoT dual: las **Pautas Dietéticas para Estadounidenses** vigentes y las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.1], [LO 2.3])** Explain the role of macronutrients and micronutrients in supporting exercise and athletic performance; Identify the importance and impact of hydration and electrolytes on performance recovery and thermoregulation.
* *Español (Regional) ([LO 2.1], [LO 2.3]): Explicar el papel de los macronutrientes y micronutrientes en el apoyo al ejercicio y el rendimiento deportivo; Identificar la importancia y el impacto de la hidratación y los electrolitos en la recuperación del rendimiento y la termorregulación.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Recognize intracellular fluid shifts, signs of micronutrient deficiencies, and acute electrolyte depletion patterns during heavy athletic sweat trials.
2. **Rule / Regla:** Apply formal federal Recommended Dietary Allowances (RDA) for essential minerals and standard fluid replacement rules (450-675 mL per 0.5 kg of body mass lost) from the SSoT.
3. **Solve / Solución:** Formulate a targeted fluid-electrolyte restoration timeline and micronutrient profile matrix to safely maintain homeostatic thermoregulation and muscle contractility.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Fluid-Electrolyte Restoration Modeling / Objetivo: Modelado de Restauración de Hidroelectrolitos

Students will initialize their electrolyte tracking sheets inside the digital sandbox workspace using the data metrics wrapped below.

```text
## METABOLIC_STRATA:
- Mass Loss: 1.5 kg post-exercise sweep
- Essential Markers: High muscle cramping reports during outdoor trials
- Fluid Intake: Pure water ingestion only with zero sodium integration
###
```

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Input the baseline mass depletion measurements into the fluid calculation tool.
2. Determine total volume replenishment ranges needed using standard federal rules.
3. Audit the current hydration strategy to explain why pure water intake triggers secondary cramping patterns.

---

## Part B: Practical Application (Onsite Lab) / Aplicación Práctica Presencial (Laboratorio)

## Location: Community College Athletics Track & Localized Prep Kitchen Space

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Construct an electrolyte replacement log to balance sodium and potassium markers alongside fluid volumes.
2. Build a whole-food snack strategy that provides required mineral markers matching federal RDA targets.
3. Complete compliance entries confirming final tracking logs align with the core federal dietary guidelines.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This assignment is evaluated using the strict **10/7/0 Mastery Scale** / *Esta asignación se evalúa utilizando la escala estricta de Maestría **10/7/0**:*

* **10 (Exemplary / Ejemplar):**
  * **English:** Zero-drift integration. All core guidelines are applied exactly, target parameters remain securely enclosed within delimiter structures (`###`), and bilingual parity is fully preserved.
  * *Español (Regional): Integración con cero desviaciones. Todas las pautas de referencia se aplican exactamente, los parámetros de configuración permanecen contenidos de forma segura dentro de las estructuras delimitadoras (`###`) y se conserva por completo la paridad bilingüe.*
* **7 (Competent / Competente):**
  * **English:** Core performance metrics are safe, safe thermal boundaries are maintained, and calculations are accurate, but minor regional translation gaps, loose formatting, or structural layout misplacements are flagged.
  * *Español (Regional): Las métricas de rendimiento principales son seguras, se mantienen los límites de seguridad térmica y los cálculos son precisos, pero se señalan brechas menores de traducción regional, formato suelto o desalineaciones en la estructura.*
* **0 (Recalibrate / Recalibrar):**
  * **English:** Critical calculation drift is present, safety thresholds are violated, commercial/fad-based trends are promoted instead of the federal SSoT, or core data inputs are left un-delimited.
  * *Español (Regional): Se presenta una desviación crítica en los cálculos, se violan los límites de seguridad, se promueven tendencias comerciales en lugar de la Fuente Única de Verdad (SSoT) federal, o las entradas de datos clave se dejan sin delimitar.*

---

## HLTH-150 Module Discussion: Micronutrient Defense & Electrolyte Homeostasis

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Evaluate the target configuration variables to construct your fluid tracking sheets, and defend your whole-food mineral selections using evidence-based federal rules.
* **Español (Regional):** Evaluar las variables de configuración para construir sus hojas de seguimiento de líquidos y defender sus selecciones de minerales de alimentos integrales utilizando reglas federales basadas en evidencia.
###



## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
