## HLTH-150: Mod 04 Summary And Wrap Up Hot Weather Hydration And Fluid Replacement

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 04 Summary & Wrap-Up: Hot-Weather Hydration & Fluid Replacement

Dinámica de Fluidos, Tasas de Sudoración, Termorregulación y Prevención de Hiponatremia


### Step 1: Core Fluid Dynamics & Thermoregulation Synthesis

Congratulations on completing Module 04! You have mastered the physiological mechanisms governing high-heat thermoregulation, fluid kinetics, and electrolyte homeostasis during athletic and occupational exertion:

- The 2.0% Dehydration Boundary & Cardiovascular Drift: Losing greater than 2.0% of baseline body mass in water diminishes plasma volume and stroke volume, forcing a compensatory rise in heart rate (cardiovascular drift) to sustain cardiac output and heat dissipation.
- Individualized Sweat Rate Kinetics: Sweat rates vary widely based on body mass, exertion intensity, and desert thermal strain. Hourly fluid losses must be quantified using nude body mass shifts to design precise intra-activity replenishment schedules (0.4 to 0.8 L/hour with 300 to 600 mg sodium/L).
- Exercise-Associated Hyponatremia (EAH) Hazard: Ingesting large volumes of plain water in excess of sweat loss dilutes serum sodium below 135 mmol/L, causing intracellular water shift, cerebral swelling, and cognitive disorientation.
- The 125% to 150% Rehydration Standard: Complete post-exercise recovery requires consuming 125% to 150% of the net fluid deficit (1.25 to 1.50 L per kg of weight lost) paired with dietary sodium within 2 to 4 hours post-shift.

### Step 2: Workplace Intelligence & AI Hydration Auditing

In occupational health, athletic training, and clinical dietetics, specialists leverage generative AI preceptors to audit sweat logs, calculate acute mass deficits, and formulate evidence-based rehydration schedules.

- AI-Assisted Hydration Calculations: Sports nutritionists prompt AI preceptors to execute fluid kinetics formulas (percentage mass loss, total sweat volume, hourly sweat rate) with mathematical precision.
- Delimiter Security Protocol (###): Client body mass values, fluid intake volumes, and urine logs must be enclosed inside triple hashes ( ### ) to maintain data isolation during automated preceptor analysis.
- Clinical Auditing: Professionals verify AI outputs against federal standards (ACSM Position Stand & Dietary Guidelines for Americans) to guarantee client safety and eliminate hyponatremia risks.

### Step 3: Module 04 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 05:

English Response: Continuous sweating and cutaneous vasodilation deplete blood plasma volume, which reduces venous return and ventricular stroke volume (SV). To maintain a constant cardiac output (Cardiac Output = Heart Rate * Stroke Volume), the heart must progressively increase its contraction frequency (HR drift), elevating cardiovascular strain and rating of perceived exertion.

Respuesta en Español: La sudoración continua y la vasodilatación cutánea reducen el volumen plasmático y el volumen sistólico (SV). Para mantener el gasto cardíaco (Gasto Cardíaco = FC * SV), el corazón incrementa progresivamente la frecuencia cardíaca (deriva de FC), aumentando el esfuerzo percibido.

English Response: Profuse sweating causes substantial sodium losses. Drinking large volumes of plain water in excess of sweat rates replaces fluid volume without replacing electrolytes, which dilutes extracellular sodium concentration below 135 mmol/L. This osmotic imbalance triggers Exercise-Associated Hyponatremia (EAH), driving water into brain cells and causing headaches, confusion, and potential cerebral edema.

Respuesta en Español: La sudoración profusa elimina grandes cantidades de sodio. Beber agua sola en exceso diluye la concentración de sodio en sangre por debajo de 135 mmol/L. Este desequilibrio osmótico provoca hiponatremia asociada al ejercicio (EAH), desplazando agua hacia las células cerebrales y causando edema cerebral.

English Response: ACSM guidelines mandate consuming 125% to 150% of the net fluid deficit (1.25 to 1.50 Liters for every 1.0 kg of body mass lost). A volume exceeding 100% is necessary because obligatory renal urine production and ongoing residual sweating continue after exertion stops.

Respuesta en Español: Las pautas del ACSM exigen consumir del 125% al 150% del déficit de fluidos (1.25 a 1.50 litros por cada 1.0 kg de peso perdido). Se requiere más del 100% porque la producción de orina y la sudoración residual continúan activas después de finalizar la actividad física.

English Response: Enclosing client body mass values, sweat rate metrics, and fluid intake logs inside triple hashes (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with ACSM and DGA standards.

Respuesta en Español: Encapitular los valores de masa corporal, métricas de tasa de sudoración y registros de ingesta de líquidos del cliente entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas de ACSM y DGA.

English Response: Extreme desert heat spikes sweat rates and electrolyte depletion beyond safe replenishment capacities, making air-conditioned indoor facilities (72°F / 22°C) vital to prevent heat illness and severe dehydration.

Respuesta en Español: El calor extremo del desierto dispara las tasas de sudoración y el agotamiento de electrolitos más allá de las capacidades de reposo seguro, haciendo vitales las instalaciones interiores climatizadas (22 °C) para prevenir enfermedades por calor y deshidratación severa.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: A deficit exceeding 2.0% body mass reduces blood volume, increases core body temperature, lowers aerobic endurance capacity, and significantly elevates the rating of perceived exertion (RPE) for any given workload.

Respuesta en Español: Un déficit superior al 2.0% de la masa corporal reduce el volumen sanguíneo, eleva la temperatura corporal central, disminuye la capacidad de resistencia aeróbica y eleva significativamente la calificación del esfuerzo percibido (RPE).

English Response: Sweat Rate = [(Pre-exercise Body Weight − Post-exercise Body Weight) + Fluid Consumed − Urine Output] / Exercise Duration in Hours.

Respuesta en Español: Tasa de Sudoración = [(Peso corporal previo − Peso corporal posterior) + Líquidos consumidos − Orina emitida] / Duración del ejercicio en horas.


### AI Simulation Workspace • Fluid Dynamics Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive synthesis connecting sweat rate math, thermoregulatory drift, and desert hydration protocols:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Module 04 Fluid Dynamics Synthesis ###:
Role: Academic Sports Nutritionist and Thermal Physiology Mentor in the Narrator voice.
SSoT: ACSM Position Stand on Exercise and Fluid Replacement & Dietary Guidelines for Americans (DGA / USDA).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Dehydration Severity Tiers (<2.0% Euhydration vs. >2.0% Hypohydration vs. Severe >4.0% Deficit).
   Key Point: Physiological Mechanisms (Cardiovascular Drift, Stroke Volume Reduction, Core Temperature Elevation).
   Key Point: ACSM Rehydration Rules (Hourly Fluid Targets, Sodium Concentrations, 125% to 150% Deficit Replacement).
Step 2: Detail how plain water over-consumption triggers Exercise-Associated Hyponatremia (EAH) and outline preventative electrolyte strategies for desert heat in Yuma County.
Step 3: Keep all formulas in plain-text math and wrap all inputs within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 05 — Energy Systems & Bioenergetics

In plain English, next week in Module 05: Energy Systems & Bioenergetics you will learn how your cells convert the carbs and fats on your plate into cellular fuel (ATP) across short sprints, middle-distance efforts, and all-day endurance work. Why it matters: understanding which metabolic 'gear' your client is using tells you whether they need fast-digesting carbohydrates or steady fat-and-complex-carb meals.

- Pattern (Context): Matching the three ATP energy systems (Phosphagen/ATP-PCr, Anaerobic Glycolysis, and Aerobic Oxidative Phosphorylation) to real-world sports and labor.
- Rule (Constraint): Aligning whole-food substrate availability with exercise intensity and duration under the 2025–2030 DGA .
- Solve (Intervention): Completing Mod 05 Discussion: Fueling the Three Energy Systems and Mod 05 Lab: Bioenergetics & Fueling Match .

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 04 (Mod 04 Summary & Wrap-Up: Hot-Weather Hydration & Fluid Replacement)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 04: Resumen y Evaluación

Dinámica de Fluidos, Tasas de Sudoración, Termorregulación y Prevención de Hiponatremia


### Step 1: Síntesis de Dinámica de Fluidos y Termorregulación

¡Felicitaciones por completar el Módulo 04! Ha establecido los conocimientos fundamentales sobre termorregulación en calor extremo, cinética de fluidos y balance hidroelectrolítico:

- Límite del 2.0% y Deriva Cardiovascular: Perder más del 2.0% del peso corporal en sudor reduce el volumen plasmático y el volumen sistólico, provocando un aumento de la frecuencia cardíaca (deriva cardiovascular) para mantener el gasto cardíaco.
- Cinética de la Tasa de Sudoración: Las pérdidas varían ampliamente. La tasa horaria debe cuantificarse mediante el cambio de peso corporal para diseñar protocolos precisos (0.4 a 0.8 L/hora con 300 a 600 mg de sodio/L).
- Riesgo de Hiponatremia (EAH): Consumir grandes volúmenes de agua sola sin sodio diluye el sodio plasmático por debajo de 135 mmol/L, provocando edema celular y desorientación cognitiva.
- Regla de Rehidratación del 125% al 150%: La recuperación post-ejercicio exige reponer del 125% al 150% del déficit de líquidos (1.25 a 1.50 L por cada kg perdido) con sodio en las 2 a 4 horas posteriores.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría de Hidratación con IA

En la salud ocupacional, el deporte y la dietética, los profesionales utilizan IA generativa para auditar registros de sudoración y diseñar programas de rehidratación basados en evidencia.

- Cálculos de Hidratación Asistidos por IA: Verificación de fórmulas de cinética de fluidos (porcentaje de pérdida de masa, volumen de sudor y tasa horaria) con precisión matemática.
- Seguridad con Delimitadores (###): Uso de tres numerales ( ### ) para estructurar registros de peso y líquidos.
- Verificación Clínica: Los profesionales contrastan los resultados con las pautas del ACSM para garantizar la seguridad y prevenir la hiponatremia.

### Step 3: Autoevaluación del Módulo 04

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 05:


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: HLTH-150 Sintesis Modulo 04 ###:
Rol: Mentor Academico de Nutricion Deportiva y Fisiologia Termica.
SSoT: Postura Oficial del ACSM sobre Ejercicio y Reemplazo de Liquidos y Guias Alimentarias (DGA / USDA).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Niveles de Deshidratacion (Euhidratacion <2.0% vs. Hipohidratacion >2.0% vs. Deficit Severo >4.0%).
   Key Point: Mecanismos Fisiologicos (Deriva Cardiovascular, Caida del Volumen Sistolico, Elevacion de Temperatura).
   Key Point: Reglas de Rehidratacion del ACSM (Metas Horarias, Concentracion de Sodio, Reemplazo del 125% al 150%).
Step 2: Detallar como el consumo excesivo de agua sola causa hiponatremia (EAH) y estructurar estrategias preventivas con electrolitos para el calor de Yuma.
Step 3: Mantener todas las formulas en texto plano y los datos entre delimitadores (###).
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 05 — Sistemas Energéticos y Bioenergética

En palabras sencillas (Contexto Norteño): la próxima semana conectarás el plato de comida con el motor celular para ver cómo los carbohidratos y las grasas se convierten en energía (ATP) según la velocidad del ejercicio. Si las rutas metabólicas se ponen pesadas, concéntrate primero en identificar cuándo el cuerpo quema más carbohidratos (esfuerzos intensos) y cuándo usa más grasas y carbohidratos complejos (esfuerzos largos).

- Patrón (Contexto): Conectar los tres sistemas de energía (ATP-PCr, glucólisis y sistema oxidativo) con el tipo de deporte o trabajo físico.
- Regla (Restricción): Alinear la selección de alimentos reales de DGA 2025–2030 con la intensidad y duración del esfuerzo.
- Solución (Intervención): Completar el Foro del Mód 05 (Fueling the Three Energy Systems) y el Laboratorio del Mód 05 (Bioenergetics & Fueling Match) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 04 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 04:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 04)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
