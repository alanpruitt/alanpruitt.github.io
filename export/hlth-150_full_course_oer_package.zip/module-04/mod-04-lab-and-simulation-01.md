## HLTH-150: Mod 04 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 04) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 04 Lab & Simulation: Hot-Weather Hydration & Fluid Replacement Plan

Laboratorio del Módulo 04: Dinámica de Fluidos, Tasas de Sudoración y Termorregulación

- Euhydration Baseline (5–7 mL/kg Pre-Exercise): Drinking 5–7 mL/kg of water at least 4 hours before exercise so the client begins training hydrated (pale-yellow urine color 1–3). En palabras sencillas: Tomar agua suficiente horas antes de salir a entrenar o trabajar para empezar bien hidratado desde el principio.
- Body Mass Loss Dehydration Threshold (>2% Loss): Losing more than 2% of pre-exercise body weight through sweat impairs thermoregulation, increases heart rate, and degrades physical and cognitive performance. En palabras sencillas: Perder más del 2% de tu peso corporal en sudor hace que suba el pulso, baje la fuerza y aumente el riesgo de golpe de calor en Yuma.
- Post-Exercise Fluid Replacement Rule (16–24 oz per lb Lost): Replacing every 1 lb (0.45 kg) of body weight lost during exercise with 16–24 oz (1.25–1.5 L) of fluid paired with dietary sodium. En palabras sencillas: Por cada libra de peso que bajes sudando en la sesión, recuperar de 16 a 24 onzas de líquido acompañado de alimentos con sal.
Welcome to your fourth practical laboratory assignment in Sports Nutrition. This week, we analyze high-heat athletic and occupational thermoregulation by diving deep into fluid and electrolyte dynamics. You will calculate individualized sweat rates, evaluate cardiovascular drift, and formulate an evidence-based rehydration protocol utilizing our academic Single Sources of Truth (SSoTs): the American College of Sports Medicine (ACSM) Position Stand on Exercise and Fluid Replacement and the Dietary Guidelines for Americans (DGA / USDA) .

Bienvenido a su cuarta práctica de laboratorio de nutrición deportiva. Esta semana analizaremos la termorregulación atlética y ocupacional en condiciones de alto calor, profundizando en la dinámica de fluidos y electrólitos según la Postura Oficial del ACSM sobre Ejercicio y Reemplazo de Fluidos y las Guías Alimentarias federales (DGA) .

- HLTH-150.4.1.AY26-27: Analyze fluid intake kinetics, total sweat loss, and percentage body mass deficit under severe ambient thermal strain. Analizar la cinética de ingesta de líquidos, la pérdida de sudor y el porcentaje de déficit de masa corporal bajo estrés térmico extremo.
- HLTH-150.4.2.AY26-27: Formulate evidence-based rehydration schedules (125% to 150% fluid replacement + sodium matching) to prevent hyponatremia and heat exhaustion. Formular cronogramas de rehidratación basados en evidencia (reposición del 125% al 150% de líquidos y sodio) para prevenir la hiponatremia y el agotamiento por calor.
- Module Window / Ventana del Módulo: Opens Tuesday, September 8, 2026, at 12:00 AM MST Abre el martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, September 14, 2026, at 11:59 PM MST Lunes, 14 de septiembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación: Weekly Labs & Clinical Simulations Benchmark (10 Points) Ponderación para laboratorios semanales y simulaciones clínicas (10 Puntos)

### Lab Objectives / Objetivos del Laboratorio

Competencias clave del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Evaluate the physiological mechanisms of eccrine sweating, cardiovascular drift, and high-heat thermoregulation in Yuma desert climates. Evaluar los mecanismos fisiológicos de la sudoración ecrina, la deriva cardiovascular y la termorregulación en el clima de Yuma.
- Calculate total sweat loss, fluid deficit, and percentage of body weight lost using standard body mass shifts. Calcular la pérdida total de sudor, el déficit de líquidos y el porcentaje de masa corporal perdida a partir de cambios de peso.
- Synthesize a targeted, electrolyte-matched rehydration schedule (125% to 150% replacement) to prevent hyponatremia and heat-related illness during occupational or athletic exertion. Sintetizar un programa de rehidratación con electrólitos (125% al 150%) para prevenir la hiponatremia y las enfermedades por calor.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-04 / Fase 1: Selección de Escenario de Simulación Clínica

Elija su Ruta y Revise los Datos del Caso

Choose ONE of the three career-aligned tracks below to audit in the Gemini AI Tool Box:

Focus: Hypertensive patient taking diuretic medication experiencing acute thermoregulatory drift and electrolyte imbalance during outdoor exercise.


```text
###
[TRACK / RUTA]: Track 1 - Clinical & Chronic Disease Prevention Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: H.M.
[AGE / EDAD]: 58 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma, AZ
[HEIGHT / ESTATURA]: 5 ft 10 in (178 cm)
[CLINICAL PROFILE]: Essential Hypertension (treated with thiazide diuretic); participates in 2-hour morning outdoor walking sessions (100°F heat index).
[BIOMETRIC SHIFTS DURING SESSION]:
Key Point: Pre-Walk Body Weight: 192 lbs (87.3 kg)
Key Point: Post-Walk Body Weight: 186 lbs (84.5 kg)
Key Point: Fluid Consumed During Walk: 32 ounces of plain water (approx. 0.95 Liters).
Key Point: Urine Output: None.
[RELEVANT SYMPTOMS]: Dizziness, muscle cramping, dry mucous membranes, elevated heart rate drift (+25 bpm above target zone).
###
```

Focus: Agricultural field supervisor suffering severe hypohydration and salt-crusting during 8-hour outdoor shifts in 112°F desert heat.


```text
###
[TRACK / RUTA]: Track 2 - Community & Public Health Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: D.G.
[AGE / EDAD]: 31 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 6 ft 0 in (183 cm)
[OCCUPATION]: Agricultural Field Crop Supervisor (Supervisor de Cultivos Agrícolas)
[DAILY ACTIVITY MATRIX]: Walks 14,000+ steps per day inspecting field irrigation during an 8-hour shift (112°F average heat index).
[BIOMETRIC SHIFTS DURING ONE SHIFT]:
Key Point: Pre-Shift Naked Body Weight: 180 lbs (81.8 kg)
Key Point: Post-Shift Naked Body Weight: 172 lbs (78.2 kg)
Key Point: Fluid Consumed During Shift: 64 ounces of plain water (approx. 1.9 liters).
Key Point: Urine Output: None recorded.
[RELEVANT SYMPTOM CHECK]: Severe headache at hour 6, dark-orange dry tongue, heavy salt-crusting across shirt collar.
###
```

Focus: Ultra-endurance desert marathon runner facing exercise-associated hyponatremia (EAH) and high sweat sodium loss.


```text
###
[TRACK / RUTA]: Track 3 - Sports & Athletic Performance Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: K.B.
[AGE / EDAD]: 27 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma, AZ
[HEIGHT / ESTATURA]: 5 ft 7 in (170 cm)
[SPORT]: Endurance Trail Runner (3-hour training runs in 104°F heat)
[BIOMETRIC SHIFTS DURING RUN]:
Key Point: Pre-Run Body Weight: 138 lbs (62.7 kg)
Key Point: Post-Run Body Weight: 133 lbs (60.5 kg)
Key Point: Fluid Consumed During Run: 48 ounces of plain distilled water (approx. 1.42 Liters).
Key Point: Urine Output: None.
[RELEVANT SYMPTOM CHECK]: Nausea, swelling in hands/fingers, confusion, heavy white salt-staining on running vest.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


```text
Safety Auditor Protocol: HLTH-150 Module 04 Fluid Dynamics Tool Box ###:
Role: Socratic Sports Nutrition Mentor in the Narrator voice.
SSoT: ACSM Position Stand on Exercise and Fluid Replacement & Dietary Guidelines for Americans (DGA / USDA).

Instructions:
Step 1: Review the clinical client profile wrapped in triple-hashes (###) below.
Step 2: PATTERN: Calculate the client's percentage of body weight lost, total sweat loss in liters, and hourly sweat rate over the session duration using plain-text math formulas. Explain why exceeding a 2.0% fluid deficit triggers performance degradation and thermoregulatory failure.
Step 3: RULE: Explain the physiological risk of Exercise-Associated Hyponatremia (EAH) caused by consuming plain water during heavy sodium loss (salt-crusting), citing ACSM standards.
Step 4: SOLVE: Design a pre-, intra-, and post-activity rehydration protocol featuring 125% to 150% fluid replacement and sodium matching appropriate for Yuma County heat conditions. Include a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Template

Plantilla de Entrega en el Cuadro de Texto de Canvas

Copy the template below, populate your responses, and submit directly in Canvas:


```text
HLTH-150 Module 04 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]
Client Initials: [Insert Client Initials]

Step 1: Pattern Recognition (Physiological Gap Analysis & Thermoregulation):
Key Point: Baseline Session Data: Duration: ___ hours | Environmental Heat Index: ___°F
Key Point: Eccrine Sweating & Evaporative Cooling Assessment:
Key Point: Cardiovascular Drift Analysis (Plasma Volume Drop, Stroke Volume, HR Drift):
Key Point: Clinical Risk Assessment (>2.0% Dehydration Threshold & Salt-Crusting):

Step 2: Rule Application (ACSM Fluid Kinetics & Plain-Text Math):
Key Point: Body Weight Loss Percentage: [(Pre-Weight - Post-Weight) / Pre-Weight] * 100 = ___%
Key Point: Acute Mass Deficit: Pre-Mass (___ kg) - Post-Mass (___ kg) = ___ kg (___ Liters)
Key Point: Total Sweat Loss (L): Mass Deficit (___ L) + Fluid Ingested (___ L) - Urine (___ L) = ___ Liters
Key Point: Hourly Sweat Rate: Total Sweat Loss (___ L) / Duration (___ hrs) = ___ L/hour
Key Point: Exercise-Associated Hyponatremia (EAH) Risk Evaluation:

Step 3: Problem Solving (125% to 150% Rehydration Protocol & Client Card):
Key Point: Pre-Activity Hydration Strategy (2 to 4 hours prior): ___ oz / L + ___ mg Sodium
Key Point: Intra-Activity Hydration & Electrolyte Strategy (Hourly Target): ___ oz / L + ___ mg Sodium/L
Key Point: Post-Activity Recovery Protocol:
  Key Point: 125% Replacement Volume: Deficit (___ L) * 1.25 = ___ Liters
  Key Point: 150% Replacement Volume: Deficit (___ L) * 1.50 = ___ Liters
  Key Point: Electrolyte & Whole-Food Sodium Sources: [Specify sodium mg/L and food pairings]
Key Point: Bilingual Client Instruction Card (EN / ES):

Step 4: Part 3 — Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice):
Key Point: [In 150-word minimum (150+ words) written in your own clinical voice, justify how your sweat-rate math, >2% dehydration threshold audit, and 1.25-1.5 L/kg sodium-fluid replacement protocol prevent heat exhaustion and hyponatremia in Yuma County]

Step 5: Repository Verification:
AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M04_Fluid_Dynamics_Audit.pdf
End Submission ###:
```


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Part 1: Physiological Gap Analysis: Key Point — Thermoregulatory Sweat Mechanics: In a 112°F desert environment, convective and radiative heat loss fails; the body relies almost 100% on eccrine sweat evaporation to dissipate metabolic heat, rapidly depleting plasma volume. Key Point — Cardiovascular Drift: Plasma volume reduction forces stroke volume to decline; to sustain cardiac output (Cardiac Output = Heart Rate * Stroke Volume), heart rate climbs progressively (+20 to +30 bpm), inducing severe fatigue. Key Point — Clinical Assessment: D.G.'s 4.4% body weight deficit far exceeds the critical 2.0% ACSM threshold. Heavy salt-crusting on his collar confirms high sweat sodium loss ("salty sweater").

Part 2: Rule Application & Target Calculations (ACSM Standards): Key Point — Body Weight Loss %: [(180 lbs - 172 lbs) / 180 lbs] 100 = (8 lbs / 180 lbs) 100 = Step 4: 44% body weight loss . Key Point — Acute Mass Deficit: 81.8 kg pre-shift - 78.2 kg post-shift = 3.6 kg = Outcome 3.6: Liters net water deficit . Key Point — Total Sweat Loss: Mass Deficit (3.6 L) + Fluid Consumed (1.9 L) - Urine Output (0 L) = Outcome 5.5: Liters total sweat loss . Key Point — Hourly Sweat Rate: 5.5 Liters / 8 hours = Outcome 0.69: Liters/hour (approx. 23.3 oz/hour) . Key Point — Exercise-Associated Hyponatremia (EAH) Risk: Consuming 64 oz of plain water without sodium against 5.5 L of salty sweat loss dilutes extracellular sodium below 135 mmol/L, driving water into cells and causing headache, dizziness, and early cerebral edema.

Part 3: Solving the Gap (Prescription & Rehydration): Key Point — Pre-Shift (2 to 4 hours prior): Drink 16 to 20 oz of water containing 300 to 500 mg sodium to establish baseline euhydration. Key Point — Intra-Shift (Hourly): Consume 24 oz (0.7 L) every hour matching his 0.69 L/hr sweat rate, mixed with high-sodium electrolytes (700 to 1000 mg sodium per liter). Restrict plain water intake. Key Point — Post-Shift Recovery (125% to 150% Replacement): Key Point: 125% Volume: 3.6 L 1.25 = Outcome 4.5: Liters . Key Point: 150% Volume: 3.6 L 1.50 = Outcome 5.4: Liters . Key Point: Strategy: Rehydrate with 4.5 to 5.4 L of electrolyte fluid over 4 hours post-shift, paired with salted pretzels and tomato juice.

EN: "You lost 4.4% of your body weight and significant salt during your shift. Drink 24 ounces of water mixed with sodium electrolytes every hour at work, and rehydrate with 4.5 liters of electrolyte fluid after your shift to stay safe."

ES: "Perdió el 4.4% de su peso corporal y abundante sal durante su turno. Beba 24 onzas de agua con electrolitos cada hora en el trabajo y rehidrátese con 4.5 litros de líquido con sodio después de su jornada para mantenerse seguro."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_150_M04_Fluid_Dynamics_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 04 (Mod 04 Lab: Hot-Weather Hydration & Fluid Replacement Plan)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Ejercicio y el Deporte


## Módulo 04 Laboratorio y Simulación: Dinámica de Fluidos y Termorregulación

Termorregulación, Tasa de Sudoración y Prevención de Hiponatremia

En este laboratorio, auditará la dinámica de hidratación de un cliente en calor extremo utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , calculando la tasa de sudoración horaria y prescribiendo el protocolo de rehidratación según las pautas oficiales del ACSM.

- Apertura del Módulo: Martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Fecha Límite de Entrega: Lunes, 14 de septiembre de 2026, a las 11:59 PM MST
- Ponderación: Puntuación de laboratorios semanales y auditorías clínicas (10 Puntos)

### Paso 1: Consulta en la Caja de Herramientas de IA Gemini

Pegue los datos de la ruta elegida en Gemini IA y copie esta plantilla debajo:


```text
Protocolo Safety Auditor: HLTH-150 Laboratorio 04 ###:
Rol: Mentor Socratico de Nutricion Deportiva con la voz del Narrador.
SSoT: Postura Oficial del ACSM sobre Ejercicio y Reemplazo de Liquidos y Guias Alimentarias (DGA / USDA).

Instrucciones:
Step 1: Revisar los datos del caso de la ruta seleccionada por el estudiante entre delimitadores (###).
Step 2: PATRON: Calcular el porcentaje de perdida de peso, la perdida total de sudor en litros y la tasa horaria de sudoracion en texto plano. Explicar por que superar el umbral del 2.0% causa fatiga y deriva cardiovascular.
Step 3: REGLA: Explicar el riesgo de Hiponatremia Asociada al Ejercicio (EAH) por consumir agua sola sin sodio durante sudoracion intensa, segun las normas ACSM.
Step 4: SOLUCION: Disenar un protocolo de rehidratacion pre, intra y post-actividad con reposicion del 125% al 150% de liquidos y sodio adaptado al calor de Yuma.
Step 5: Generar una tarjeta de instruccion bilingue para el cliente (EN / ES).

Entrada de Datos del Cliente ###:
[PEGUE AQUI LOS DATOS DE SU RUTA ENTRE DELIMITADORES]
Fin de Datos del Cliente ###:
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Plantilla de Entrega en Canvas (Solo Texto)


```text
HLTH-150 Entrega de Laboratorio Modulo 04 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clinica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]
Iniciales del Cliente: [Insertar Iniciales]

Step 1: Reconocimiento de Patrones (Analisis Fisiologico y Termorregulacion):
Key Point: Datos de la Sesion: Duracion: ___ horas | Indice de Calor: ___°F
Key Point: Evaluacion de Sudoracion Ecrina y Enfriamiento Evaporativo:
Key Point: Analisis de Deriva Cardiovascular (Caida de Plasma, Volumen Sistolico, Deriva de FC):
Key Point: Evaluacion de Riesgo Clinico (Umbral de Deshidratacion >2.0% y Manchas de Sal):

Step 2: Aplicacion de Reglas (Cinetica de Fluidos ACSM y Matematicas en Texto Plano):
Key Point: Porcentaje de Perdida de Peso: [(Peso Previo - Peso Posterior) / Peso Previo] * 100 = ___%
Key Point: Deficit Agudo de Masa: Masa Previa (___ kg) - Masa Posterior (___ kg) = ___ kg (___ Litros)
Key Point: Perdida Total de Sudor (L): Deficit de Masa (___ L) + Liquidos Consumidos (___ L) - Orina (___ L) = ___ Litros
Key Point: Tasa Horaria de Sudoracion: Perdida Total (___ L) / Duracion (___ hrs) = ___ L/hora
Key Point: Evaluacion de Riesgo de Hiponatremia Asociada al Ejercicio (EAH):

Step 3: Resolucion de Problemas (Protocolo de Rehidratacion 125% a 150% y Tarjeta Bilingue):
Key Point: Estrategia Pre-Actividad (2 a 4 horas antes): ___ oz / L + ___ mg Sodio
Key Point: Estrategia Intra-Actividad (Meta Horaria): ___ oz / L + ___ mg Sodio/L
Key Point: Protocolo de Recuperacion Post-Actividad:
  Key Point: Volumen de Reposicion 125%: Deficit (___ L) * 1.25 = ___ Litros
  Key Point: Volumen de Reposicion 150%: Deficit (___ L) * 1.50 = ___ Litros
  Key Point: Fuentes de Electrolitos y Alimentos Reales con Sodio: [Especificar mg de sodio/L y alimentos]
Key Point: Tarjeta de Instruccion Bilingue para el Cliente (EN / ES):

Step 4: Verificación Activa Clinica Obligatoria (Mínimo 150 Palabras en su Propia Voz Humana):
Key Point: [En mínimo 150 palabras (150+ palabras) escritas en su propia voz clinica, justifique como sus calculos de tasa de sudoracion, umbral de >2% de deshidratacion y reposicion de 1.25-1.5 L/kg con sodio previenen el golpe de calor e hiponatremia en Yuma]

Step 5: Verificacion del Repositorio:
Intercambio con la IA exportado y guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M04_Fluid_Dynamics_Audit.pdf
Fin de la Entrega ###:
```

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi razonamiento clínico, las recomendaciones genéricas de hidratación fallan en el condado de Yuma porque a más de 108°F el cuerpo depende casi por completo de la evaporación del sudor para enfriarse. Al superar el umbral del 2% de pérdida de peso corporal, cae el volumen plasmático y se dispara la deriva cardiovascular. Calcular la tasa exacta de sudoración por hora y reponer de 1.25 a 1.5 litros por cada kilogramo perdido junto con sodio y potasio de alimentos reales retiene el líquido a nivel renal y previene tanto el agotamiento por calor como la hiponatremia."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 04)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
