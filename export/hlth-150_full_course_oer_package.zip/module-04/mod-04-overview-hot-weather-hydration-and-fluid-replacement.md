## HLTH-150: Mod 04 Overview Hot Weather Hydration And Fluid Replacement

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 04 Overview: Hot-Weather Hydration & Fluid Replacement


### Welcome to Module 04: Hot-Weather Hydration & Fluid Replacement

Welcome to Week 4! This week, we analyze the physiological mechanisms governing high-heat thermoregulation, sweat rate dynamics, and fluid replacement using our academic Single Sources of Truth (SSoTs): the Dietary Guidelines for Americans (DGA / USDA) , the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) , and the ACSM Joint Position Stand on Exercise and Fluid Replacement . In desert climates where temperatures exceed 105°F (40.5°C), calculating fluid deficits and avoiding both severe dehydration (>2% body mass loss) and Exercise-Associated Hyponatremia (EAH) is essential for human survival and performance.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will calculate raw sweat loss equations, apply federal and clinical hydration benchmarks (replacing 125%–150% of fluid losses alongside sodium replenishment), and design practical, heat-adapted whole-food hydration strategies for agricultural field harvesters and athletes across Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 8, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 10, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 13, 2026, at 11:59 PM MST
- Lab 04 Direct Submission / Entrega de Laboratorio: Monday, September 14, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 04 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Calculate acute sweat loss rates, net fluid deficits, and percentage body mass loss during physical exertion and occupational work in extreme ambient heat. Calcular las tasas de sudoración aguda, el déficit neto de líquidos y el porcentaje de masa corporal perdida durante el esfuerzo en calor extremo.
- CLO 2 (Rule Application): Apply federal DGA and ACSM fluid replacement rules to differentiate hypohydration risks from Exercise-Associated Hyponatremia (EAH) caused by excessive plain water ingestion. Aplicar las pautas DGA y ACSM de hidratación para diferenciar los riesgos de deshidratación de la hiponatremia inducida por consumo exclusivo de agua.
- CLO 3 (Problem Solving): Formulate an evidence-based, localized rehydration protocol prescribing 125% to 150% fluid replacement with sodium and whole-food electrolytes tailored for Yuma County field workers and athletes. Formular un protocolo de rehidratación del 125% al 150% con sodio y electrólitos de alimentos reales adaptado a los trabajadores y atletas de Yuma.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit fluid dynamics and heat strain through your chosen career track:

Auditing electrolyte shifts, cardiovascular drift, and thermoregulatory strain in hypertensive or diabetic patients exercising in outpatient rehab facilities.

Prescribing accessible, cost-effective hydration, shaded rest cycles, and whole-food sodium strategies for agricultural field crews across Yuma County.

Calculating hourly sweat rates and structuring multi-transportable carbohydrate-electrolyte rehydration (125%–150%) for cross-country runners and tactical athletes.


### Module 04 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Fluid Replacement, Sweat Math & Thermoregulation
- Discussion Board 04: Fluid Dynamics & Heat Adaptation
- Lab Assignment 04: Sweat Rate Calculations & Gemini AI Tool Box
- Module 04 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 04 (Mod 04 Overview: Hot-Weather Hydration & Fluid Replacement)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 04 Visión General: Dinámica de Fluidos y Termorregulación


### Bienvenido al Módulo 04: Dinámica de Fluidos, Balance de Electrólitos y Calor Extremo

¡Bienvenido a la Semana 4! Esta semana analizaremos la termorregulación, la tasa de sudoración y las estrategias de rehidratación utilizando nuestras Fuentes Únicas de Verdad (SSoT): las Guías Alimentarias para los Estadounidenses (DGA / USDA) , las Pautas de Actividad Física (PAGA 2018, 2.ª edición) y la Postura Oficial del ACSM sobre Ejercicio y Reemplazo de Líquidos . En climas donde el termómetro supera los 40.5°C (105°F), el cálculo preciso del sudor y la prevención de la hiponatremia son vitales.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , calculará el déficit hídrico, aplicará reglas de reposición (125% a 150% del peso perdido) y formulará estrategias con alimentos reales y electrólitos para trabajadores agrícolas y atletas en Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 10 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 13 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 04: Lunes, 14 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Calcular la tasa de sudoración, el déficit de líquidos y el porcentaje de pérdida de peso en calor extremo.
- CLO 2 (Regla): Aplicar normas de hidratación para evitar la deshidratación severa y la hiponatremia asociada al ejercicio.
- CLO 3 (Solución): Diseñar una estrategia de reemplazo del 125% al 150% con sodio y alimentos reales adaptada al clima de Yuma.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará el balance hídrico a través de su ruta profesional:

Auditoría de balance hidroelectrolítico y deriva cardiovascular en pacientes con diabetes o hipertensión en centros ambulatorios.

Protocolos de hidratación accesible, rotación en sombra y reposición de sodio para cuadrillas agrícolas en el campo de Yuma.

Cálculo de tasas de sudor y prescripción de soluciones de electrolitos (125%–150%) para corredores y atletas tácticos.


### Ruta de Aprendizaje del Módulo 04

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Reemplazo de Fluidos, Termorregulación y Pautas DGA
- Foro de Discusión 04: Dinámica de Fluidos y Adaptación al Calor
- Laboratorio 04: Cálculos de Tasa de Sudoración y Consulta de IA
- Comprobación de Conocimientos y Resumen del Módulo 04

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 04 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 04 Required Readings: Hot-Weather Hydration & Fluid Replacement →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 04 Discussion: Staying Hydrated in Yuma Heat →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 04 Coaching Sprint: Spotting Dehydration & Heat Stress →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 04 Lab: Hot-Weather Hydration & Fluid Replacement Plan →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 04 Summary & Wrap-Up: Hot-Weather Hydration & Fluid Replacement →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 04)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
