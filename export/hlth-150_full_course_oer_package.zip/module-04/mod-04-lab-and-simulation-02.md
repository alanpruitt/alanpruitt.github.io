# HLTH-150: Mod 04 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición Deportiva y para el Ejercicio


## Mod 04 Coaching Sprint Simulation: Spotting Dehydration & Heat Stress

Sesión de Coaching del Módulo 04: Dinámica de Fluidos, Sudoración y Termorregulación

- Euhydration Baseline (5–7 mL/kg Pre-Exercise): Drinking 5–7 mL/kg of water at least 4 hours before exercise so the client begins training hydrated (pale-yellow urine color 1–3). En palabras sencillas: Tomar agua suficiente horas antes de salir a entrenar o trabajar para empezar bien hidratado desde el principio.
- Body Mass Loss Dehydration Threshold (>2% Loss): Losing more than 2% of pre-exercise body weight through sweat impairs thermoregulation, increases heart rate, and degrades physical and cognitive performance. En palabras sencillas: Perder más del 2% de tu peso corporal en sudor hace que suba el pulso, baje la fuerza y aumente el riesgo de golpe de calor en Yuma.
- Post-Exercise Fluid Replacement Rule (16–24 oz per lb Lost): Replacing every 1 lb (0.45 kg) of body weight lost during exercise with 16–24 oz (1.25–1.5 L) of fluid paired with dietary sodium. En palabras sencillas: Por cada libra de peso que bajes sudando en la sesión, recuperar de 16 a 24 onzas de líquido acompañado de alimentos con sal.
- HLTH-150.4.1.AY26-27: Evaluate fluid balance, electrolyte homeostasis, and thermoregulatory responses during exercise in extreme environments. Evaluar el equilibrio de líquidos, la homeostasis de electrolitos y las respuestas termorreguladoras durante el ejercicio.
- HLTH-150.4.2.AY26-27: Apply sports nutrition hydration protocols and electrolyte replenishment strategies to prevent heat illness and optimize physical performance. Aplicar protocolos de hidratación y reposición de electrolitos para prevenir enfermedades por calor y optimizar el rendimiento.

### Your Weekly Win: Hydration, Heat & Human Performance

How does fluid balance affect cardiovascular strain and muscular endurance when exercising in high temperatures? Proper hydration and electrolyte balance are essential for thermoregulation, maintaining blood volume, and preventing heat illness. Understanding sweat rates and fluid replacement strategies separates safe athletic performance from heat exhaustion. Choose your coaching track below, chat with your AI Socratic Coach, and master exercise hydration science!

¿Cómo afecta el equilibrio de líquidos al rendimiento en altas temperaturas? Una hidratación adecuada es esencial para la termorregulación y la prevención de golpes de calor. ¡Elija su ruta, dialogue con su Coach de IA y domine la ciencia de la hidratación!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés vocacional

Scenario: Outdoor construction worker (Manuel, 42) working in extreme desert heat who relies entirely on soda and energy drinks for hydration, leading to severe cramps and dizziness.


```text
###
[TRACK]: Track 1 - Clinical & Environmental Heat Path
[CLIENT]: Outdoor Laborer in Desert Heat (Manuel, 42) | [LOCATION]: Yuma, AZ
[SITUATION]: Experiences severe heat cramps, dizziness, and dehydration while working outdoors due to consuming caffeinated sugary beverages instead of water and electrolytes.
[COACHING GOAL]: Apply sports hydration guidelines to explain electrolyte replacement and water balance during heavy labor in high ambient temperatures.
###
```

Scenario: Youth soccer coach (Coach Ray, 35) who prohibits players from drinking water during practice, believing it causes stomach cramps.


```text
###
[TRACK]: Track 2 - Community & Youth Coaching Path
[CLIENT]: Youth Soccer Coach (Coach Ray, 35) | [LOCATION]: Yuma County, AZ
[SITUATION]: Enforces outdated restriction rules on water breaks during hot afternoon youth soccer practices, putting young athletes at risk of heat exhaustion.
[COACHING GOAL]: Educate the coach on modern sports hydration protocols, sweat loss monitoring, and scheduled fluid intake for youth athletes.
###
```

Scenario: Endurance cyclist (Elena, 31) training for a century ride who only drinks plain water for 5 hours, resulting in hyponatremia and severe fatigue.


```text
###
[TRACK]: Track 3 - Adult Fitness & Endurance Coaching Path
[CLIENT]: Long-Distance Endurance Cyclist (Elena, 31) | [LOCATION]: Yuma, AZ
[SITUATION]: Drinks massive amounts of plain water during long hot training rides without replacing sodium, causing electrolyte dilution and hyponatremia symptoms.
[COACHING GOAL]: Calculate customized electrolyte replacement and fluid intake rates for prolonged endurance training in arid environments.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: HLTH-150 Fluid Dynamics & Heat Tool Box ###:
Role: Supportive HLTH-150 Sports Nutrition Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: ACSM Position Stand on Exercise and Fluid Replacement & Dietary Guidelines for Americans (DGA / USDA).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms fluid balance, electrolyte homeostasis (sodium loss/replacement), and thermoregulation during exercise in high heat.
Step 3: Guide the student to outline ONE practical hydration strategy or electrolyte replacement plan for the client.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how proper hydration sustains performance and protects health in the heat.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's hydration challenge or environmental risk.
- Fluid Dynamics & Thermoregulation Analysis: Explain how fluid loss, electrolyte balance, and heat stress impact your client's physiology.
- My Practical Hydration Strategy: Provide 1 clear, evidence-based fluid and electrolyte recommendation.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why replacing sweat losses at 1.25–1.5 L per kg lost with sodium-electrolyte fluids (rather than plain water alone) prevents exercise-associated hyponatremia and cardiovascular drift in Yuma's heat.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 04 Coaching Sprint • Track 3 (Endurance / Elena)

- Chosen Track & Client: Track 3: Adult Fitness & Endurance Coaching (Elena, 31). Challenge: Elena drinks only plain water during 5-hour long hot cycling rides, leading to sodium dilution and hyponatremia symptoms.
- Track 3: Adult Fitness & Endurance Coaching (Elena, 31).
- Challenge: Elena drinks only plain water during 5-hour long hot cycling rides, leading to sodium dilution and hyponatremia symptoms.
- Fluid Dynamics & Thermoregulation Analysis: Electrolyte Homeostasis: Sweating loses both water and vital electrolytes (especially sodium). Drinking excessive plain water without sodium replaces fluid volume while diluting blood electrolyte concentrations, causing hyponatremia. Proper endurance hydration requires matching fluid intake with sodium replacement to maintain blood osmolality and cardiovascular function.
- Electrolyte Homeostasis: Sweating loses both water and vital electrolytes (especially sodium). Drinking excessive plain water without sodium replaces fluid volume while diluting blood electrolyte concentrations, causing hyponatremia.
- Proper endurance hydration requires matching fluid intake with sodium replacement to maintain blood osmolality and cardiovascular function.
- My Practical Hydration Strategy for Elena: "Switch from plain water to an electrolyte sports drink containing 300 to 600 mg of sodium per liter during rides exceeding 90 minutes to maintain electrolyte balance and prevent hyponatremia."
- "Switch from plain water to an electrolyte sports drink containing 300 to 600 mg of sodium per liter during rides exceeding 90 minutes to maintain electrolyte balance and prevent hyponatremia."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Elena's headache, nausea, and confusion after 5 hours of cycling in Yuma heat are classic red flags of Exercise-Associated Hyponatremia (EAH) caused by chugging plain, sodium-free water. When an endurance athlete or agricultural worker sweats heavily in 105°F+ desert heat, they lose both plasma water and large amounts of extracellular sodium. If a generic AI chatbot simply tells her to 'drink more water whenever she feels fatigued,' she will further dilute her serum sodium below 135 mmol/L, risking cerebral edema. By enforcing ACSM and DGA hydration rules—pairing 500–700 mg/L of sodium electrolytes with 6–8% carbohydrates during prolonged heat exposure and rehydrating at 1.25–1.5 L per kg of body mass lost—we restore plasma osmolality safely."
- My Memorable Coaching Takeaway: EN: "Water keeps you cool, but electrolytes keep your cells in balance during the heat!" ES: "¡El agua te mantiene fresco, pero los electrolitos mantienen tus células en equilibrio bajo el calor!"
- EN: "Water keeps you cool, but electrolytes keep your cells in balance during the heat!"
- ES: "¡El agua te mantiene fresco, pero los electrolitos mantienen tus células en equilibrio bajo el calor!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M04_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 04 (Mod 04 Coaching Sprint: Spotting Dehydration & Heat Stress)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición Deportiva y para el Ejercicio


## Módulo 04 Simulación de Coaching: Dinámica de Fluidos y Calor

Evaluación Rápida y Aprendizaje Práctico de la Hidratación Deportiva


### Su Logro Semanal: Hidratación, Calor y Rendimiento Humano

Esta sesión le permitirá entender cómo el equilibrio de líquidos afecta la termorregulación y la resistencia cardiovascular en altas temperaturas. Aprenda a calcular tasas de sudoración y estrategias de reposición de electrolitos. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: HLTH-150 Dinamica de Fluidos y Calor ###:
Rol: Coach de Nutricion Deportiva de HLTH-150 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Postura Oficial del ACSM sobre Ejercicio y Reemplazo de Liquidos y Guias Alimentarias (DGA / USDA).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla el equilibrio de liquidos, la homeostasis de electrolitos (perdida/reemplazo de sodio) y la termorregulacion durante el ejercicio en ambientes calurosos.
Step 3: Guiar al estudiante para proponer UNA estrategia practica de hidratacion o plan de reemplazo de electrolitos para el cliente.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la hidratacion adecuada sostiene el rendimiento y protege la salud bajo el calor.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de hidratación o riesgo ambiental de su cliente.
- Análisis de Dinámica de Fluidos y Termorregulación: Explique cómo la pérdida de líquidos, el equilibrio de electrolitos y el estrés térmico impactan la fisiología de su cliente.
- Mi Estrategia Práctica de Hidratación: Escriba 1 recomendación clara y basada en evidencia sobre líquidos y electrolitos.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué reponer de 1.25 a 1.5 L por cada kg perdido usando líquidos con sodio (y no solo agua simple) previene la hiponatremia y la deriva cardiovascular en el calor de Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, el dolor de cabeza, náusea y confusión de Elena tras pedalear 5 horas bajo el calor de Yuma son signos clásicos de Hiponatremia Asociada al Ejercicio (EAH) por beber únicamente agua simple sin sodio. Si una IA genérica le recomienda tomar más agua sola al sentirse fatigada, diluirá aún más su sodio sérico por debajo de 135 mmol/L. Al integrar bebidas con electrolitos (500–700 mg/L de sodio) y reponer 1.25 a 1.5 L por cada kg de peso perdido con alimentos salados reales, protegemos su equilibrio osmótico y función neurológica."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:
