# HLTH-150: Mod 04 Required Readings Hot Weather Hydration And Fluid Replacement

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 04 Required Readings: Hot-Weather Hydration & Fluid Replacement

Lecturas Obligatorias y Recursos de Estudio: Dinámica de Fluidos, Tasas de Sudoración y Termorregulación


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Euhydration (normal body water balance) keeps blood volume stable so your body can cool itself through sweat in extreme heat. When you exercise in Yuma's 105°F+ dry heat, losing more than 2% of body weight in sweat strains your heart and raises core temperature. Calculating pre- and post-exercise fluid replacement prevents heat exhaustion and heat stroke.


#### En Palabras Sencillas (Norteño Context)

Salir a entrenar al sol de Yuma sin hidratación medida es como correr una troca en el desierto con el radiador medio vacío. Si los términos técnicos se ponen pesados, concéntrate primero en la regla de perder menos del 2% de peso corporal por sudor y cuánto líquido reponer por cada libra perdida.


### Required SSoT Text & Clinical Guidelines

Single Source of Truth (SSoT): ACSM Position Stand on Exercise and Fluid Replacement (Sawka et al.) • Dietary Guidelines for Americans (DGA / USDA) • Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) .

- Official Journal Article (MSSE): ACSM Position Stand: Exercise and Fluid Replacement (MSSE Portal)
- PubMed Reference Index: PubMed Index Reference (PMID: 17277604)
- Official Guidelines Portal: Dietary Guidelines for Americans Official Portal: Fluid & Electrolyte Balance

### Regional Focus: Desert Thermoregulation & Agricultural Heat Index

Enfoque Regional: Termorregulación en el Desierto y Estrés Térmico en el Condado de Yuma

In Yuma County and regional agricultural border communities, ambient summer temperatures routinely exceed 105°F (40.5°C). High thermal strain causes rapid cutaneous blood pooling, elevated sweat rates (often exceeding 1.5 to 2.5 L/hr in unacclimated workers), and pronounced cardiovascular drift. For agricultural field harvesters and tactical athletes, failing to balance sodium along with water increases the clinical risk of Exercise-Associated Hyponatremia (EAH) and exertional heat illness. Kinesiologists and sports nutritionists mandate structured fluid protocols paired with dietary sodium and shaded rest cycles.

En el condado de Yuma y las comunidades agrícolas fronterizas, las temperaturas de verano superan habitualmente los 40.5°C (105°F). El estrés térmico provoca vasodilatación cutánea, tasas de sudoración elevadas (1.5 a 2.5 L/h) y deriva cardiovascular. Para los trabajadores de campo y atletas tácticos, reponer agua sin sodio eleva el riesgo de hiponatremia asociada al ejercicio (EAH) y golpe de calor. Se deben prescribir protocolos estructurados con sodio y descansos programados en sombra.


### Reading 1: Dehydration Boundaries & Cardiovascular Drift

Lectura 1: Límites Críticos de Deshidratación y Deriva Cardiovascular


#### Step 1: The 2.0% Body Mass Loss Threshold

Umbral de Pérdida de Masa Corporal del 2.0%

Dehydration exceeding Step 2: 0% of baseline body mass significantly degrades aerobic exercise performance, impairs cognitive decision-making, and impairs heat dissipation by reducing cutaneous blood flow and sweating sensitivity:


#### Step 2: Physiological Mechanisms of Cardiovascular Drift

Mecanismos Fisiológicos de la Deriva Cardiovascular

During prolonged steady-state physical exertion in high heat, continuous sweat loss reduces blood plasma volume, which diminishes venous return and ventricular end-diastolic volume. Consequently, stroke volume (SV) declines. To sustain cardiac output (Cardiac Output = Heart Rate * Stroke Volume), the sympathetic nervous system forces a progressive, compensatory rise in heart rate (HR), elevating cardiovascular strain and perceived exertion (RPE).

Durante el ejercicio prolongado en calor, la sudoración continua reduce el volumen plasmático, disminuyendo el retorno venoso y el volumen de eyección (SV). Para mantener el gasto cardíaco (Gasto Cardíaco = FC * SV), el corazón aumenta progresivamente la frecuencia cardíaca (FC), elevando el esfuerzo percibido y la fatiga.


### Reading 2: Sweat Rate Calculations & Post-Exercise Rehydration

Lectura 2: Matemáticas de la Tasa de Sudoración y Protocolos de Rehidratación


#### Step 1: Individualized Sweat Rate Formula

Fórmula Individualizada de Tasa de Sudoración

Individual sweat rates vary based on body mass, genetics, environmental heat index, and acclimation status. The clinical sweat rate equation calculates hourly fluid losses:


#### Step 2: 125% to 150% Rehydration Standard & EAH Prevention

Estándar de Rehidratación del 125% al 150% y Prevención de Hiponatremia

Because obligatory post-exercise urinary fluid excretion continues after physical work stops, individuals must consume 125% to 150% of their acute body mass deficit (1.25 to 1.50 L per kg lost) within 2 to 4 hours post-shift:

- Electrolyte Pairing: Ingestion of dietary sodium (300 to 600 mg sodium per liter of fluid) or whole-food snacks (pickles, salted nuts, pretzels) is mandatory to retain plasma osmolality and prevent rapid renal clearance.
- Exercise-Associated Hyponatremia (EAH): Over-drinking hypotonic fluids (plain water) beyond sweat loss dilutes serum sodium below 135 mmol/L, leading to cellular swelling, cerebral edema, confusion, seizures, and potential fatality.

### Key Terminology / Glosario Clave

A gradual, progressive rise in heart rate during prolonged steady-state exercise in warm conditions, driven by reduced blood volume and decreased stroke volume secondary to sweating and cutaneous blood pooling.

Aumento progresivo de la frecuencia cardíaca durante el ejercicio continuo en calor, causado por la disminución del volumen de eyección y la reducción del volumen plasmático.

A clinical electrolyte disturbance characterized by serum sodium concentration below 135 mmol/L, caused by excessive consumption of plain water or hypotonic fluids exceeding sweat losses.

Alteración electrolítica donde el sodio sérico cae por debajo de 135 mmol/L debido a la sobreingesta de agua sola en exceso de las pérdidas de sudor.

Euhydration defines a normal physiological state of optimal total body water; hypohydration represents a state of water deficit exceeding 2.0% of body mass, which degrades physical output and thermal regulation.

La euhidratación representa un estado óptimo de agua corporal; la hipohidratación es el déficit hídrico superior al 2.0% del peso, deteriorando el rendimiento y la termorregulación.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Dinámica de Fluidos

Select each question below to confirm your understanding of hydration math before starting Discussion 04 and Lab 04:

English Response: Under ACSM and sports nutrition standards, exceeding a Step 2: 0% body mass deficit represents the critical threshold where aerobic endurance capacity, cognitive vigilance, and thermoregulatory cooling mechanisms degrade significantly.

Respuesta en Español: Según el ACSM, perder más del Step 2: 0% de la masa corporal en agua constituye el umbral crítico donde decaen la resistencia aeróbica, la función cognitiva y la capacidad de disipación de calor.

English Response: Drinking exactly 100% of fluid losses is insufficient because obligatory kidney filtration and ongoing sweating continue during post-exercise recovery. Consuming 125% to 150% (1.25 to 1.50 L per kg lost) with dietary sodium ensures full restoration of plasma volume and euhydration.

Respuesta en Español: Ingerir solo el 100% es insuficiente debido a las pérdidas obligatorias por orina y sudoración residual. Reponer del 125% al 150% (1.25 a 1.50 L por kg perdido) con sodio garantiza restaurar por completo el volumen plasmático.

English Response: When large volumes of sodium are lost through sweat and replaced exclusively with plain water in excess of sweat rate, the extracellular fluid becomes hypotonic. Serum sodium drops below 135 mmol/L, forcing water intracellularly and causing dangerous cerebral swelling.

Respuesta en Español: Al perder sodio por sudor e ingerir grandes volúmenes de agua sola por encima de la tasa de sudoración, el plasma se diluye (sodio sérico menor a 135 mmol/L), provocando entrada de agua a las células y edema cerebral potencialmente mortal.


### AI Simulation Workspace • Fluid Dynamics Simulation

Copy the prompt below into Gemini to audit client sweat rates, calculate percentage dehydration deficits, and structure heat-adapted rehydration plans:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: HLTH-150 Module 04 Fluid Dynamics Tool Box ###:
Role: Sports Nutritionist and Thermal Physiology Specialist in the Narrator voice.
SSoT: ACSM Position Stand on Exercise and Fluid Replacement & Dietary Guidelines for Americans (DGA / USDA).

Instructions:
Step 1: Audit the student's client hydration data enclosed within triple-hashes (###) below.
Step 2: Calculate total body mass loss (kg and %), net fluid deficit (L), and hourly sweat rate (L/hr).
Step 3: Evaluate clinical safety boundaries, identifying whether dehydration exceeds 2.0% or if plain water over-consumption poses Exercise-Associated Hyponatremia (EAH) risk.
Step 4: Prescribe a 125% to 150% post-exertion rehydration protocol specifying fluid volumes, sodium concentration (300-600 mg/L), and whole-food electrolyte snacks for Yuma County heat.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
Pre-Exercise Mass: [Insert kg or lbs]
Post-Exercise Mass: [Insert kg or lbs]
Exertion Duration: [Insert hours or minutes]
Fluids Consumed During Exertion: [Insert L or oz]
Urine Volume (if any): [Insert L or oz]
Ambient Temperature / Heat Index: [e.g., 108°F / 42°C in Yuma County]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 04 (Mod 04 Required Readings: Hot-Weather Hydration & Fluid Replacement)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Lecturas Obligatorias: Dinámica de Fluidos, Tasas de Sudoración y Termorregulación


### Texto Fuente SSoT y Lineamientos de Hidratación

Fuente Única de Verdad (SSoT): Postura Oficial del ACSM sobre Ejercicio y Reemplazo de Líquidos (Sawka et al.) • Guías Alimentarias para los Estadounidenses (DGA / USDA) • Pautas PAGA 2018 (2.ª edición) .

Consenso Oficial del ACSM: Ejercicio y Reposición de Líquidos (MSSE)

- Portal de Guías Alimentarias: Guías Alimentarias para los Estadounidenses: Agua, Sodio y Electrólitos

### Conceptos Científicos Centrales


#### Step 1: Umbral de Deshidratación y Deriva Cardiovascular

Perder más del 2.0% del peso corporal en sudor deteriora la función cardiovascular. La reducción del volumen plasmático disminuye el volumen de eyección y eleva compensatoriamente la frecuencia cardíaca (deriva cardiovascular) para mantener el gasto cardíaco.


#### Step 2: Tasa de Sudoración y Rehidratación del 125% al 150%

La reposición post-ejercicio debe equivaler al 125%–150% del peso perdido (1.25 a 1.50 L por kg perdido) acompañado de sodio (300 a 600 mg por litro) para evitar la hiponatremia asociada al ejercicio (sodio sérico menor a 135 mmol/L).


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 04 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 04:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
