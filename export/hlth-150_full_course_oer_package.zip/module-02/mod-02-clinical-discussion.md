## HLTH-150: Mod 02 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 02) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 02 Discussion: Whole-Food Carbs for Daily Energy

Foro de Discusión 02: Cinética de Carbohidratos y Estrategias de Reabastecimiento de Glucógeno

This week, we evaluate carbohydrate-fueling kinetics, hepatic and muscular glycogen depletion, and the physiological mechanisms of "bonking" or energy crashes. Select a career-aligned track below and audit a real-world refueling plan under extreme environmental or metabolic strain using Google Gemini!

Esta semana evaluamos la cinética de los carbohidratos, el agotamiento de glucógeno muscular y hepático, y la mecánica del colapso por hipoglucemia ("bonking"). ¡Seleccione una ruta alineada con su carrera y audite un plan de reabastecimiento con Google Gemini!


### Discussion Schedule & Deadlines / Horario y Fechas Límite

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST
Bilingual Participation Welcome / Participación Bilingüe Bienvenida: You are warmly encouraged to post in English or Spanish according to your preference. Le animamos a publicar en inglés o en español, según su preferencia.


#### Instructor Community Feedback Practice / Práctica de Retroalimentación del Instructor

I review all initial submissions and post technical calculation audits and fueling feedback directly in this public discussion thread as well as inside SpeedGrader. Check back regularly to read feedback across all peer posts to refine your carbohydrate timing calculations!

Reviso todas las publicaciones y aporto retroalimentación directamente en este foro público y en SpeedGrader. ¡Consulte con regularidad los comentarios para perfeccionar sus cálculos de carbohidratos!


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI Preceptor query:

Focus: Type 2 Diabetic recreational walker (M.G., 52) experiencing exercise-induced reactive hypoglycemia and glycogen exhaustion during 90-minute morning walks.

Focus: Municipal outdoor maintenance worker (R.V., 41) performing 6+ hours of heavy physical labor in 102°F Yuma heat with acute carbohydrate depletion.

Focus: Competitive endurance gravel cyclist (A.L., 34) experiencing acute performance failure ("bonking") at Mile 60 of long desert rides.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Case / Ruta y Caso Seleccionado: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and client initials. Indique la ruta seleccionada y las iniciales del cliente.
- Audit Glycogen Mechanics & "Bonking" / Audite la Mecánica del Glucógeno: Explain the physiological difference between muscle glycogen depletion and systemic hypoglycemia for your client's specific workload. Why do they experience rapid fatigue or performance failure? Explique la diferencia fisiológica entre el agotamiento de glucógeno muscular y la hipoglucemia sistémica. ¿Por qué experimenta fatiga rápida?
- Prescribe ACSM/AND Carbohydrate Timing / Prescriba Tiempos de Carbohidratos: Using body weight (kg), calculate pre-activity (1–4 g/kg), intra-activity (30–60 g/hr or 60–90 g/hr for >2.5 hrs), and post-activity recovery (1.0–1.2 g/kg/hr) carbohydrate targets in plain-text math. Usando el peso corporal (kg), calcule las metas de carbohidratos pre-, intra- y post-actividad según ACSM/AND en texto plano.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Audit their carbohydrate calculations (g/kg and g/hr), verify their glucose-to-fructose ratio (SGLT1/GLUT5), or suggest an alternative heat-stable food source for Yuma conditions!

Antes del domingo a las 11:59 PM MST , responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Audite sus cálculos, verifique la relación de transporte o sugiera un alimento estable al calor.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Scenario Selection / Selección de Escenario: A 75.0 kg (165 lb) male gravel cyclist training for a 100-mile ride in Yuma County (5–6 hours duration in 98°F desert heat). Un ciclista de gravel masculino de 75.0 kg (165 lb) que entrena para una ruta de 100 millas en el condado de Yuma (5–6 horas de duración bajo un calor desértico de 37°C / 98°F).
- Glycogen Audit & Bonking / Auditoría de Glucógeno y Hipoglucemia: Intramuscular glycogen provides localized glucose for type II muscle fibers. Once depleted (after ~2 to 3 hours), the body relies on liver glycogen to maintain blood glucose. When liver glycogen is exhausted, blood glucose plunges below 70 mg/dL (hypoglycemia), triggering central nervous system shutdown and severe performance collapse ("bonking"). El glucógeno intramuscular proporciona glucosa local a las fibras musculares. Una vez agotado (~2 a 3 horas), el cuerpo depende del glucógeno hepático. Cuando se agota el glucógeno hepático, la glucosa en sangre cae por debajo de 70 mg/dL (hipoglucemia), lo que desencadena fatiga central y colapso ("la pájara").
- ACSM Fueling Prescription / Prescripción de Nutrición ACSM: Pre-Ride (3 hrs prior) / Pre-Entrenamiento: 75 kg × 2.0 g/kg = 150g carbohydrates (oatmeal, banana, toast with honey). 75 kg × 2.0 g/kg = 150 g de carbohidratos (avena, plátano, pan tostado con miel). Intra-Ride (Hourly) / Durante el Recorrido: 75 g/h of multiple-transportable carbohydrates (2:1 maltodextrin/fructose ratio using 1 energy gel + 24 oz 6% sports drink) to maximize SGLT1 and GLUT5 intestinal transporters. 75 g/h de carbohidratos de transporte múltiple (relación 2:1 maltodextrina:fructosa) para maximizar los transportadores SGLT1 y GLUT5. Post-Ride Recovery (First 4 hrs) / Recuperación Post-Entrenamiento: 75 kg × 1.2 g/kg/hr = 90g/hr rapid-acting carbohydrates paired with 25g whey protein to optimize GLUT4 translocation and glycogen resynthesis. 75 kg × 1.2 g/kg/h = 90 g/h de carbohidratos rápidos combinados con 25 g de proteína para optimizar la resíntesis de glucógeno.
- Pre-Ride (3 hrs prior) / Pre-Entrenamiento: 75 kg × 2.0 g/kg = 150g carbohydrates (oatmeal, banana, toast with honey). 75 kg × 2.0 g/kg = 150 g de carbohidratos (avena, plátano, pan tostado con miel).
- Intra-Ride (Hourly) / Durante el Recorrido: 75 g/h of multiple-transportable carbohydrates (2:1 maltodextrin/fructose ratio using 1 energy gel + 24 oz 6% sports drink) to maximize SGLT1 and GLUT5 intestinal transporters. 75 g/h de carbohidratos de transporte múltiple (relación 2:1 maltodextrina:fructosa) para maximizar los transportadores SGLT1 y GLUT5.
- Post-Ride Recovery (First 4 hrs) / Recuperación Post-Entrenamiento: 75 kg × 1.2 g/kg/hr = 90g/hr rapid-acting carbohydrates paired with 25g whey protein to optimize GLUT4 translocation and glycogen resynthesis. 75 kg × 1.2 g/kg/h = 90 g/h de carbohidratos rápidos combinados con 25 g de proteína para optimizar la resíntesis de glucógeno.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Discussion: Whole-Food Carbs for Daily Energy)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Discussion board prompts and learning activities in HLTH-150 follow Universal Design for Learning (UDL) principles. This board uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools (e.g., Genio).

Español (Regional): Todos los temas de discusión y las actividades de aprendizaje en HLTH-150 se basan en los principios del Diseño Universal para el Aprendizaje (UDL). Este foro utiliza un diseño centrado en texto y adaptado a dispositivos móviles, compatible al 100% con lectores de pantalla y con sistemas de toma de notas con IA.

Process Over Product Evaluation / Evaluación de Proceso:

Discussions are untimed and evaluated on a low-stakes, 3-tier grading scale (10/7/0 pts) to emphasize community connection, reflective learning, and peer dialogue over testing pressure.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

If you require specific accommodations to participate in this Discussion board, contact AWC AccessABILITY Services or notify Coach Alan Pruitt.

3C Building, Yuma Campus | Phone: (928) 344-7674 Email: lisa.swenson@azwestern.edu | access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Discusión 02: Carbohidratos y Reabastecimiento de Glucógeno

Cinética de Carbohidratos y Estrategias de Reabastecimiento de Glucógeno

Esta semana evaluamos la cinética de los carbohidratos, el agotamiento de glucógeno muscular y hepático, y la mecánica del colapso por hipoglucemia ("bonking"). Seleccione una ruta y audite un plan de alimentación con Google Gemini.


### Fase 1: Selección de Escenario de Simulación Clínica

Elija UNA de las tres rutas para copiar los datos en su consulta de IA:

Caminante con Diabetes Tipo 2 (M.G., 52 años) con hipoglucemia reactiva al minuto 60.

Trabajador municipal (R.V., 41 años) en jornadas de 6 horas bajo 39°C (102°F) sin carbohidratos.

Ciclista de gravel (A.L., 34 años) con colapso de rendimiento ("bonking") en la milla 60.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)


### Tareas de Discusión (Entrega: Jueves 11:59 PM MST):

- Ruta y Caso Seleccionado: Indique la ruta seleccionada (Ruta 1 Clínica, Ruta 2 Comunitaria o Ruta 3 Deportiva) y las iniciales del cliente.
- Auditoría de Glucógeno y "Bonking": Explique la diferencia fisiológica entre el agotamiento de glucógeno muscular y la hipoglucemia sistémica. ¿Por qué experimenta fatiga rápida?
- Prescripción de Carbohidratos ACSM/AND: Usando el peso corporal (kg), calcule las metas de carbohidratos antes (1 a 4 g/kg), durante (30 a 60 g/h o 60 a 90 g/h para >2.5 h) y después (1.0 a 1.2 g/kg/h).

#### Requisito de Interacción entre Compañeros

Antes del domingo a las 11:59 PM MST , responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta requerida). Audite sus cálculos de carbohidratos (g/kg y g/h), verifique la proporción de glucosa a fructosa (SGLT1/GLUT5) o sugiera un alimento alternativo estable al calor para las condiciones de Yuma.


#### Ejemplo de Entrega de Alta Fidelidad (10/10) en Español

- Selección del Escenario: Ciclista de gravel masculino de 75.0 kg (165 lb) que entrena para una ruta de 100 millas en el condado de Yuma (5 a 6 horas bajo calor de 37°C / 98°F).
- Auditoría de Glucógeno y "Bonking": El glucógeno muscular proporciona glucosa local a las fibras musculares. Una vez agotado (~2 a 3 horas), el cuerpo depende del glucógeno hepático. Cuando este se agota, la glucosa sanguínea cae por debajo de 70 mg/dL (hipoglucemia), provocando fatiga del sistema nervioso central y colapso ("la pájara").
- Prescripción de Carbohidratos ACSM: Antes de rodar (3 h antes): 75 kg × 2.0 g/kg = 150 g de carbohidratos (avena, plátano, pan tostado con miel). Durante la ruta (por hora): 75 g/h de carbohidratos de transporte múltiple (relación 2:1 maltodextrina:fructosa con 1 gel + 24 oz de bebida al 6%) para activar SGLT1 y GLUT5. Recuperación posterior: 75 kg × 1.2 g/kg/h = 90 g/h de carbohidratos rápidos con 25 g de proteína de suero para optimizar la resíntesis de glucógeno.
- Antes de rodar (3 h antes): 75 kg × 2.0 g/kg = 150 g de carbohidratos (avena, plátano, pan tostado con miel).
- Durante la ruta (por hora): 75 g/h de carbohidratos de transporte múltiple (relación 2:1 maltodextrina:fructosa con 1 gel + 24 oz de bebida al 6%) para activar SGLT1 y GLUT5.
- Recuperación posterior: 75 kg × 1.2 g/kg/h = 90 g/h de carbohidratos rápidos con 25 g de proteína de suero para optimizar la resíntesis de glucógeno.

### ACCESIBILIDAD Y UDL

Todos los temas de discusión y actividades en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total accesibilidad para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 02)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
