## HLTH-150: Mod 02 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 02) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Lab & Simulation: Carbohydrate Fueling & Recovery Plan

Laboratorio del Módulo 02: Protocolos de Carbohidratos y Ventanas de Reposición de Glucógeno

- Skeletal Muscle & Liver Glycogen Stores (3–12 g/kg/day): Primary stored carbohydrate fuel for moderate-to-high intensity exercise; daily needs scale from 3–5 g/kg (light activity) to 6–10+ g/kg (endurance training). En palabras sencillas: La reserva de carbohidratos guardada en músculos e hígado que te da fuerza para entrenar sin agotarte a mitad de la sesión.
- Complex Whole-Food Carbohydrates & Dietary Fiber (14 g / 1,000 kcal): Whole grains, oats, brown rice, corn tortillas, pinto beans, and whole fruits provide sustained glucose release and gut-protective fiber. En palabras sencillas: Carbohidratos de absorción constante como avena, frijoles, arroz y tortilla de maíz que mantienen estable el azúcar y aportan fibra.
- Glycemic Load & Pre-Exercise Digestive Comfort: Selecting higher-fiber whole carbs for daily meals while tapering fiber and fat closer to exercise to prevent gastrointestinal distress. En palabras sencillas: Comer buena fibra durante el día, pero elegir alimentos más ligeros antes de entrenar para evitar pesadez estomacal.
Welcome to your second practical laboratory assignment in Sports Nutrition! This week, we dive into the science of carbohydrate kinetics and endurance fueling. You will evaluate an active individual's glycogen depletion rate and design a targeted pre-, intra-, and post-exercise refueling plan utilizing our academic Single Source of Truth (SSoT): the Joint Position Statement on Nutrition and Athletic Performance by the American College of Sports Medicine (ACSM) and the Academy of Nutrition and Dietetics (AND) .

Bienvenido a su segunda práctica de laboratorio de nutrición deportiva. Esta semana analizaremos el rendimiento en resistencia, la cinética de carbohidratos y el agotamiento de glucógeno utilizando las pautas académicas del ACSM y la AND.

- HLTH-150.2.1.AY26-27: Determine carbohydrate targets (g/kg/day) based on training duration, volume, and glycemic response. Determinar objetivos de carbohidratos (g/kg/día) basados en la duración del entrenamiento, volumen y respuesta glucémica.
- HLTH-150.2.3.AY26-27: Audit muscle and liver glycogen replenishment strategies using whole-food carbohydrate sources and fluid metrics. Auditar estrategias de reposición de glucógeno muscular y hepático utilizando fuentes de carbohidratos integrales y métricas de líquidos.
- Module Window / Ventana del Módulo: Opens Tuesday at 12:00 AM MST / Abre el martes a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday by 11:59 PM MST / Lunes a las 11:59 PM MST
- Submission Format / Formato: Text-only entry typed or pasted directly into the Canvas text box. (No file uploads accepted). / Texto directo en Canvas (No se aceptan archivos adjuntos).

### Lab Objectives / Objetivos del Laboratorio

- Evaluate the physiological mechanisms of intramuscular glycogen depletion and hypoglycemia ("bonking") during prolonged exercise. Evaluar los mecanismos fisiológicos del agotamiento de glucógeno e hipoglucemia durante el ejercicio prolongado.
- Calculate targeted pre-exercise, intra-exercise (g/hr), and post-exercise carbohydrate demands based on body mass in kg. Calcular las demandas de carbohidratos pre-, durante y post-ejercicio según la masa corporal en kg.
- Synthesize a high-heat compliant carbohydrate and fluid protocol that matches sweat rates and intestinal absorption limits. Sintetizar un protocolo de carbohidratos e hidratación adaptado al calor de Yuma que respete la absorción intestinal.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-02

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos del Caso

Choose ONE of the three career-aligned tracks below to audit in the Gemini AI Tool Box:

Focus: Type 2 Diabetic recreational walker experiencing exercise-induced reactive hypoglycemia and glycogen exhaustion during 90-minute morning walks.

Focus: Municipal outdoor laborer performing 6+ hours of heavy physical labor in extreme desert heat with acute carbohydrate depletion.

Focus: Competitive endurance gravel cyclist experiencing acute performance breakdown ("bonking") at Mile 60 of long desert rides.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI along with your chosen track data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas (Solo Texto)

- Selected Track & Client Baseline: State your chosen track, client weight (kg and lbs), and their primary fueling complaint. Indique la ruta, peso del cliente (kg y lb) y su problema principal de combustible.
- Part 1: Physiological Gap Analysis (Pattern): Explain the physiological mechanism of fatigue ("bonking"), differentiating systemic hypoglycemia from muscle glycogen depletion. Parte 1: Análisis Fisiológico (Explique la diferencia entre el agotamiento de glucógeno muscular y la hipoglucemia hepática).
- Part 2: Rule Application & Target Calculations (Rule): Apply ACSM/AND guidelines to compute Pre-exercise (g), During-exercise (g/hr), and Post-exercise recovery (g) carbohydrate targets in grams based on body weight in kg. Parte 2: Aplicación de Reglas ACSM/AND (Cálculos exactos en gramos antes, durante y después según el peso en kg).
- Part 3: Solving the Gap & Bilingual Client Card (Solve): Detail a practical refueling timeline (pre-activity meal, hourly intra-activity fuel/fluids in Yuma heat, and post-activity recovery) with a 2-sentence bilingual client card in English and Spanish. Parte 3: Resolución Práctica y Tarjeta Bilingüe (Plan de alimentos reales, líquidos con electrolitos y tarjeta de 2 oraciones en inglés y español).
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify how your pre-, intra- (g/hr), and post-exercise carbohydrate gram prescription and sodium-electrolyte hydration plan prevent both hepatic hypoglycemia and muscle glycogen depletion in Yuma's extreme heat. Parte 4: Verificación Activa Obligatoria (mínimo 150 palabras en su propia voz humana justificando cómo su plan previene la hipoglucemia hepática y el agotamiento de glucógeno en el calor de Yuma).
- Repository Verification: Confirm that your complete AI prompt exchange has been saved to your Google Drive repository ( EXW_Professional_AI_Repository ). Confirmación del Repositorio: Verifique que el registro de IA esté guardado en su carpeta de Google Drive.

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Part 1: Physiological Gap Analysis (Análisis de Brecha Fisiológica): Key Point — Mechanism of "Bonking": A.L.'s performance failure at Mile 60 (~3.5 hours into the ride) represents severe systemic carbohydrate depletion. In prolonged endurance exercise, intramuscular glycogen stores are depleted within 2 to 3 hours. Key Point — Hypoglycemia vs. Glycogen Depletion: Once muscle glycogen is exhausted, muscle fibers rely on blood glucose maintained by hepatic glycogenolysis. When liver glycogen is exhausted, circulating blood glucose plunges, precipitating central nervous system fatigue, motor tremors, and acute metabolic failure ("bonking"). Key Point — Current Strategy Deficit: Consuming only 40g pre-ride with 0g intra-ride carbohydrates drastically accelerates glycogen depletion in 98°F heat.

Part 2: Rule Application & Target Calculations (ACSM/AND Standards): Key Point — Biometric Weight: 165 lbs / 2.2 = Outcome 75.0: kg . Key Point — Pre-Exercise Target (1 to 4 g/kg, 1 to 4 hours prior): Target = 75 kg × 2.0 g/kg = 150 grams consumed 3 hours before start. Key Point — Intra-Exercise Target (>2.5 to 3 hours duration): 60 to 90 grams/hour of multiple-transportable carbohydrates (glucose-to-fructose 2:1 ratio) to maximize intestinal absorption through SGLT1 and GLUT5 transporters. Key Point — Post-Exercise Recovery Target (1.0 to 1.2 g/kg/hr for 4 hours): 75 kg × 1.2 g/kg = 90 grams/hour of rapid-acting carbohydrates.

Part 3: Solving the Gap (Resolución de Intervención): Key Point — Pre-Ride Loading (3 hours prior): Large bowl of oatmeal (80g carbs), 1 sliced banana (30g carbs), and 2 slices of toast with honey (40g carbs) = 150g carbs. Drink 16 to 20 oz water with electrolytes. Key Point — Intra-Ride Hourly Fueling (98°F Heat): Consume 1 energy gel (25g carbs) plus 24 oz of a 6% carbohydrate-electrolyte drink (~50g carbs) every hour = 75g carbs/hour . Fluid intake of 24 to 32 oz/hour with 500 to 700 mg sodium per liter to prevent hyponatremia. Key Point — Post-Ride Recovery (Within 30 mins): 20 oz low-fat chocolate milk, 1 large banana, and a turkey sandwich (90g carbs / 25g protein) to stimulate rapid glycogen resynthesis and myofibrillar repair.

EN: "To prevent hitting the wall at Mile 60, eat 150 grams of carbohydrates before your ride and consume 75 grams of carbohydrates with electrolyte fluids every hour. Refuel with chocolate milk and a recovery meal within 30 minutes of finishing to rebuild your energy stores."

ES: "Para evitar la fatiga extrema en la milla 60, consuma 150 gramos de carbohidratos antes de rodar y 75 gramos por hora con electrolitos. Recupérese con leche chocolatada y una comida completa dentro de los 30 minutos posteriores para restaurar su energía."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_150_M02_Carbohydrate_Protocol_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Lab: Carbohydrate Fueling & Recovery Plan)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in HLTH-150 follow Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This assignment is text-first, untimed, and screen-reader verified.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | access@azwestern.edu

HLTH-150 • Nutrición para el Ejercicio y el Deporte


## Módulo 02 Laboratorio y Simulación: Carbohidratos y Glucógeno

Cinética de Carbohidratos y Ventanas de Reposición de Glucógeno


### Agotamiento de Glucógeno, Hipoglucemia y Protocolos de Reabastecimiento

En esta práctica de laboratorio, auditará la cinética de carbohidratos utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , calculando las demandas previas, durante y posteriores al ejercicio según las pautas científicas del ACSM y la AND.


### Fase 1: Selección de Escenario de Simulación Clínica #150-02

Elija UNA de las tres rutas profesionales para realizar su auditoría:

Caminante recreativa con Diabetes Tipo 2 con hipoglucemia reactiva al minuto 60.

Trabajador de mantenimiento en jornadas de 6 horas bajo calor extremo de 39°C (102°F).

Ciclista de gravel de 100 millas con colapso de rendimiento ("bonking") en la milla 60.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


### Fase 3: Estructura de Entrega en Canvas (Solo Texto Plano)

- Ruta y Cliente: Indique la ruta seleccionada y el peso en kg y lb.
- Parte 1 (Patrón): Explique la causa del colapso (glucógeno muscular vs. hepático).
- Parte 2 (Regla ACSM/AND): Muestre los cálculos exactos en gramos antes, durante y después.
- Parte 3 (Solución): Diseñe el plan de alimentos reales, líquidos con sodio y la tarjeta bilingüe de 2 oraciones.
- Parte 4 (Verificación Activa Obligatoria): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique cómo sus cálculos de carbohidratos (antes, durante y después) y sodio previenen la hipoglucemia y el agotamiento de glucógeno en el calor de Yuma.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Evaluación en Español (Escala 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10 en Español

Parte 1: Análisis de Brecha Fisiológica: El colapso en la milla 60 (~3.5 horas) se debe a que las reservas de glucógeno muscular se vacían, forzando una oxidación de grasas más lenta que reduce la potencia de pedaleo. Al mismo tiempo, el hígado agota su glucógeno para mantener la glucosa en sangre, privando al cerebro de energía y provocando mareo, confusión y la clásica "pájara".

Parte 2: Aplicación de Reglas (Pautas ACSM/AND para 75 kg): Key Point — Antes de la ruta (3 h antes): 75 kg × 2.0 g/kg = 150 g de carbohidratos complejos . Key Point — Durante la ruta (>2.5 h): 60 a 90 g/hora de carbohidratos de transporte múltiple (glucosa + fructosa en proporción 2:1) para usar los transportadores SGLT1 y GLUT5. Key Point — Recuperación posterior: 75 kg × 1.2 g/kg = 90 g de carbohidratos rápidos más 20 a 25 g de proteína.

Parte 3: Resolución de la Brecha: Key Point — Comida previa: Tazón de avena con plátano, miel y tostadas (~150 g carbohidratos) + 16 a 20 oz de agua con electrolitos. Key Point — En ruta: 1 gel energético (25 g) más 24 oz de bebida deportiva con 6% de carbohidratos (~50 g) cada hora = 75 g carbohidratos/hora con 500 a 700 mg de sodio/L. Key Point — Recuperación: Leche chocolatada con un emparedado de pavo y arroz con frijoles (90 g carbohidratos / 25 g proteína). Tarjeta Bilingüe: "Para evitar la fatiga extrema en la milla 60, consuma 150 gramos de carbohidratos antes de rodar y 75 gramos por hora con electrolitos. Recupérese con leche chocolatada y una comida completa dentro de los 30 minutos posteriores para restaurar su energía."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M02_Carbohydrate_Protocol_Audit.pdf


### ACCESIBILIDAD Y UDL

Todos los materiales de HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi razonamiento clínico, un plan de IA sin verificar suele confundir toda la fatiga con simple sed y recomienda beber únicamente agua sola. En el calor de más de 105°F en Yuma, el gasto de glucógeno muscular se acelera por la respuesta adrenérgica y se pierde sodio rápidamente por el sudor. Tomar solo agua sin carbohidratos (30–60 g/h) ni electrolitos no previene la hipoglucemia hepática (mareo central) ni el agotamiento muscular, y aumenta el riesgo de hiponatremia. Al aplicar las metas de carbohidratos de alimentos reales antes, durante y después del esfuerzo, protegemos la seguridad neurológica y la recuperación física."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 02)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
