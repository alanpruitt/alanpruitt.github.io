## HLTH-150: Mod 02 Summary And Wrap Up Whole Food Carbohydrates And Energy Fueling

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 02 Summary & Wrap-Up: Whole-Food Carbohydrates & Energy Fueling

Resumen y Cierre del Módulo 02: Digestión, Absorción y Cinética de Carbohidratos

Congratulations on completing Module 02! This week, you mastered the biological pathways governing gastrointestinal digestion, mucosal nutrient transport, and carbohydrate periodization under athletic and environmental stress.

¡Felicitaciones por completar el Módulo 02! Esta semana ha dominado las vías biológicas de la digestión gastrointestinal, el transporte mucosal de nutrientes y la periodización de carbohidratos bajo estrés físico y ambiental.


### Core Digestion & Carbohydrate Assimilation Synthesis

Puntos Clave y Síntesis de la Asimilación de Carbohidratos

Digestion relies on salivary, gastric, pancreatic, and brush border enzymes (such as salivary/pancreatic amylase, maltase, and sucrase) to break complex carbohydrates down into single glucose and fructose molecules for cellular absorption.

La digestión utiliza enzimas salivales, pancreáticas e intestinales (amilasa, maltasa, sacarasa) para descomponer los carbohidratos complejos en glucosa y fructosa absorbibles.

Glucose utilizes sodium-dependent SGLT1 active transporters, which saturate around 60 g/hour. Fructose is absorbed independently through GLUT5 facilitated diffusion transporters (~30 g/hour). Combining both in a 2:1 ratio enables ultra-endurance athletes to absorb up to 90 g/hour without stomach distress.

La glucosa usa transportadores SGLT1 dependientes de sodio (saturados a ~60 g/h), mientras que la fructosa usa transportadores GLUT5 (~30 g/h). Combinarlos en proporción 2:1 permite absorber hasta 90 g/h sin malestar estomacal.

Intense exercise and high ambient heat in Yuma trigger sympathetic vasoconstriction, shunting up to 80% of blood flow away from the stomach toward working muscles and skin for cooling. Ingesting hypertonic, high-sugar solutions during exercise delays gastric emptying, causing nausea and cramping.

El ejercicio intenso y el calor desértico desvían hasta el 80% del flujo sanguíneo del estómago hacia los músculos y la piel, por lo que las bebidas excesivamente azucaradas provocan náuseas y calambres.


### Workplace Intelligence & AI Skills Competency

Inteligencia Laboral y Competencia en Habilidades de IA

In sports dietetics, clinical coaching, and fitness training, practitioners utilize generative AI to evaluate gastric emptying, model intestinal absorption thresholds, and design heat-safe fueling plans:

- AI-Assisted Fueling Diagnostics: Sports nutritionists prompt AI preceptors to simulate carbohydrate absorption kinetics and evaluate multiple transportable carbohydrate ratios (glucose:fructose).
- Delimiter Security (###): Enclosing client tolerance logs (fluid intake, sweat loss, GI symptom scores) inside triple hashes ( ### ) protects data boundaries during automated preceptor analysis.
- Clinical Auditing: Practitioners verify AI-generated fueling protocols against federal standards (ACSM/AND) to ensure training plans prevent hypoglycemia and gastrointestinal distress.

### Post-Module Mastery Self-Check (Bilingual Companion)

Autoevaluación de Dominio de Conceptos del Módulo 02

English Response: SGLT1 actively transports glucose (and galactose) across the intestinal wall using a sodium-dependent gradient (~60 g/hr capacity), while GLUT5 transports fructose independently via facilitated diffusion (~30 g/hr capacity). Combining both allows up to 90 g/hr absorption.

Respuesta en Español: SGLT1 transporta activamente glucosa mediante un gradiente dependiente de sodio (~60 g/h), mientras que GLUT5 transporta fructosa de forma independiente (~30 g/h). La combinación permite absorber hasta 90 g/h.

English Response: High-intensity exercise triggers sympathetic vasoconstriction, reducing blood flow to the digestive tract by up to 80%. This slows gastric emptying and can cause stomach cramps or nausea if high-sugar solid foods are consumed.

Respuesta en Español: El ejercicio intenso reduce el flujo sanguíneo digestivo hasta en un 80%, lo que retrasa el vaciado estomacal y puede causar náuseas o calambres si se ingieren alimentos muy azucarados o pesados.

English Response: Muscle glycogen is trapped inside muscle cells to power local contractions; its depletion causes peripheral power loss ("heavy legs"). Liver glycogen maintains circulating blood glucose for the brain; its depletion causes systemic hypoglycemia, leading to dizziness, confusion, and central "bonking."

Respuesta en Español: El glucógeno muscular solo alimenta las contracciones musculares locales (su falta produce pesadez muscular). El glucógeno hepático mantiene el azúcar en sangre para el cerebro (su falta produce hipoglucemia y mareos).

English Response: Enclosing client tolerance logs and fueling data within triple-hash delimiters (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with ACSM and sports nutrition standards.

Respuesta en Español: Encapitular los registros de tolerancia y datos de alimentación entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas de ACSM y nutrición deportiva.

English Response: Hypertonic solutions have a higher solute concentration than body fluids, drawing water into the intestinal lumen and slowing gastric emptying, which exacerbates dehydration and causes GI distress in the heat.

Respuesta en Español: Las soluciones hipertónicas tienen mayor concentración de solutos que los fluidos corporales, atrayendo agua hacia el intestino y retrasando el vaciado gástrico, lo que agrava la deshidratación y causa malestar estomacal bajo el calor.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: Enzymes located on the microvilli of enterocytes (such as maltase, sucrase, and lactase) hydrolyze disaccharides (maltose, sucrose, lactose) directly into monosaccharides (glucose, fructose, galactose) immediately prior to mucosal absorption.

Respuesta en Español: Las enzimas ubicadas en las microvellosidades de los enterocitos (como maltasa, sacarasa y lactasa) hidrolizan los disacáridos directamente en monosacáridos inmediatamente antes de la absorción mucosa.

English Response: Classic carbohydrate loading involves a 1-to-3 day taper in training volume combined with a high-carbohydrate diet (8 to 10 g/kg of body mass per day) to maximize intramuscular glycogen storage.

Respuesta en Español: La carga clásica de carbohidratos implica una reducción gradual del entrenamiento de 1 a 3 días combinada con una dieta alta en carbohidratos (8 a 10 g/kg de masa corporal al día) para maximizar el almacenamiento de glucógeno intramuscular.


### Module 02 Completion Checklist

Lista de Verificación Final del Módulo 02

- Core Readings Completed: Reviewed digestive physiology, intestinal transporters (SGLT1/GLUT5), and ACSM carbohydrate timing. Lecturas completadas: Revisión de fisiología digestiva y pautas de carbohidratos ACSM.
- Discussion 02 Completed: Posted initial carbohydrate audit and submitted peer evaluations using the Auditor Protocol. Discusión 02 completada: Publicación inicial y respuestas a compañeros.
- Lab 02 Submitted: Completed the carbohydrate kinetics mathematical audit and submitted text-only response with bilingual card. Laboratorio 02 entregado: Auditoría de carbohidratos y tarjeta bilingüe.
- AI Repository Verified: Exported all Gemini prompt exchanges into your Google Drive repository ( EXW_Professional_AI_Repository ). Repositorio de IA verificado: Archivos guardados en Google Drive.
SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 03 — Protein Synthesis & Muscle Mass

In plain English, next week in Module 03: Protein Synthesis & Mass you will learn how dietary protein provides the essential building blocks (amino acids like leucine) that repair and build muscle tissue after hard workouts or physical labor. Why it matters: getting the right daily protein amount from affordable whole foods protects strength and recovery without wasting money on overpriced powders.

- Pattern (Context): Evaluating complete vs. complementary plant and animal proteins (eggs, poultry, fish, dairy, and traditional pinto beans + corn/rice combinations).
- Rule (Constraint): Calculating evidence-based daily protein targets ( 1.2–2.0 g/kg/day for active individuals vs. 0.8 g/kg/day sedentary RDA) aligned with 2025–2030 DGA .
- Solve (Intervention): Completing Mod 03 Discussion: Whole-Food Protein Sources and Mod 03 Lab: Daily Protein & Muscle Recovery Plan .

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Summary & Wrap-Up: Whole-Food Carbohydrates & Energy Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Resumen y Cierre del Módulo 02

Digestión, Absorción y Cinética de Carbohidratos

¡Felicitaciones por completar el Módulo 02! Ha dominado cómo el cuerpo digiere los nutrientes, utiliza los transportadores intestinales SGLT1 y GLUT5, y cómo aplicar los tiempos de consumo de carbohidratos para evitar la pájara o fatiga extrema.


### Puntos Clave y Síntesis de Asimilación de Carbohidratos

Conceptos Fisiológicos Fundamentales

Las enzimas salivales, pancreáticas e intestinales reducen los carbohidratos complejos a glucosa y fructosa para su absorción celular.

La glucosa usa transportadores SGLT1 (~60 g/h máximo), mientras que la fructosa usa GLUT5 (~30 g/h). La combinación 2:1 permite absorber hasta 90 g/h sin dolor estomacal.

El ejercicio intenso y el calor de Yuma desvían la sangre del estómago hacia los músculos y la piel, por lo que las bebidas con exceso de azúcar provocan náuseas y calambres.


### Inteligencia Laboral y Competencia en Habilidades de IA

Aplicación Profesional en Dietética y Entrenamiento

En dietética deportiva y entrenamiento físico, los profesionales utilizan IA generativa para evaluar el vaciamiento gástrico, modelar la absorción y diseñar planes seguros para el calor:

- Diagnóstico de Nutrición Asistido por IA: Los nutricionistas consultan preceptores de IA para simular la cinética de absorción de carbohidratos y evaluar proporciones de transporte múltiple (glucosa:fructosa).
- Seguridad con Delimitadores (###): Encerrar los registros del cliente (líquidos, sudoración, síntomas digestivos) entre tres numerales ( ### ) protege los límites de los datos.
- Auditoría Clínica: Los especialistas verifican los protocolos generados por la IA contra las pautas de ACSM/AND para evitar hipoglucemias y molestias estomacales.

### Autoevaluación del Módulo 02

Verificación de Aprendizaje


### Lista de Verificación Final del Módulo 02

- Lecturas Obligatorias Completadas: Fisiología digestiva y pautas de carbohidratos ACSM.
- Discusión 02 Completada: Publicación inicial y respuestas a compañeros.
- Laboratorio 02 Entregado: Auditoría de carbohidratos y tarjeta bilingüe.
- Repositorio de IA Verificado: Archivos guardados en Google Drive ( EXW_Professional_AI_Repository ).
PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 03 — Síntesis Proteica y Masa Muscular

En palabras sencillas (Contexto Norteño): si los carbohidratos son la gasolina, la proteína (huevo, pollo, pescado, leche o la combinación clásica de frijoles con arroz/tortilla de maíz) son los ladrillos que reparan el músculo después de entrenar o chambear duro. Si los nombres de los aminoácidos se ponen pesados la próxima semana, concéntrate primero en calcular la meta de Outcome 1.2: a 2.0 gramos de proteína por kilo de peso al día con comida real.

- Patrón (Contexto): Analizar proteínas completas y complementarias accesibles para las familias del Valle de Yuma.
- Regla (Restricción): Calcular metas diarias de proteína basadas en evidencia ( 1.2–2.0 g/kg/día en personas activas) bajo las guías DGA 2025–2030 .
- Solución (Intervención): Completar el Foro del Mód 03 (Whole-Food Protein Sources) y el Laboratorio del Mód 03 (Daily Protein & Muscle Recovery Plan) .
HLTH-150 • Module 02 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 02:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 02)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
