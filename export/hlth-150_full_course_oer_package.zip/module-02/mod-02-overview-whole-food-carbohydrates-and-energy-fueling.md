# HLTH-150: Mod 02 Overview Whole Food Carbohydrates And Energy Fueling

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 02 Overview: Whole-Food Carbohydrates & Energy Fueling

Visión General del Módulo 02: Carbohidratos y Almacenamiento de Glucógeno

Welcome to Module 02! This week, we analyze how carbohydrates fuel physical movement, evaluate muscle and liver glycogen depletion, and master the physiology of "bonking" or energy crashes using our Single Source of Truth (SSoT): the Joint Position Statement on Nutrition and Athletic Performance (ACSM/AND) .

¡Bienvenido al Módulo 02! Esta semana analizaremos cómo los carbohidratos alimentan el movimiento, cómo se agota el glucógeno muscular y hepático, y la fisiología del colapso por hipoglucemia ("la pájara") según la postura conjunta del ACSM y la AND.


### Learning Objectives / Objetivos de Aprendizaje

- Differentiate Glycogen Pools: Differentiate intramuscular glycogen depletion (peripheral muscle fatigue) from systemic hypoglycemia (brain fog and dizziness) in active individuals. Diferenciar el agotamiento de glucógeno muscular (fatiga local) de la hipoglucemia sistémica (mareos y fatiga cerebral).
- Calculate Carbohydrate Targets: Calculate exact carbohydrate targets based on body weight in kg for pre-exercise (1–4 g/kg), during-exercise (30–90 g/hr), and post-exercise recovery (1.0–1.2 g/kg/hr). Calcular metas exactas de carbohidratos en g/kg antes (1–4 g/kg), durante (30–90 g/h) y después del ejercicio.
- Design Desert Fueling Plans: Design multiple-transportable carbohydrate and fluid protocols (using glucose and fructose in a 2:1 ratio) to sustain energy and hydration in high desert heat. Diseñar protocolos de carbohidratos de transporte múltiple (relación 2:1) y líquidos para el calor del desierto.

### Module Checklist / Lista de Tareas del Módulo:

- Required Readings: Review the ACSM/AND Carbohydrate & Glycogen Guidelines. Lecturas Obligatorias: Revisar las Pautas de Carbohidratos y Glucógeno de ACSM/AND.
- Discussion 02: Post your initial carbohydrate audit by Thursday 11:59 PM MST and submit peer evaluations by Sunday 11:59 PM MST. Discusión 02: Publicación inicial el jueves y respuestas a compañeros el domingo.
- Coaching Sprint 02: Chat with your AI Socratic Coach, complete your carbohydrate reflection, and submit plain-text responses. Sesión de Coaching 02: Interactuar con el Coach de IA y entregar en texto plano.
- Lab 02: Complete the carbohydrate and glycogen kinetics audit and submit directly into the Canvas text box by Monday 11:59 PM MST. Laboratorio 02: Completar la auditoría de carbohidratos y entregar en Canvas el lunes.

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Overview: Whole-Food Carbohydrates & Energy Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Module overview materials and learning activities in HLTH-150 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools.

Español: Todos los materiales del curso en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando total accesibilidad para lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Weekly learning objectives and tasks emphasize conceptual understanding, carbohydrate kinetics mastery, and evidence-based practice over testing pressure.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Visión General del Módulo 02: Carbohidratos y Glucógeno

Cinética de Carbohidratos y Estrategias de Combustible Deportivo

¡Bienvenido al Módulo 02! Esta semana analizaremos cómo los carbohidratos alimentan el movimiento humano, el agotamiento del glucógeno muscular y hepático, y la fisiología del colapso por falta de energía ("la pájara" o bonking) según las pautas científicas del ACSM y la AND.


### Objetivos de Aprendizaje

- Diferenciar Depósitos de Glucógeno: Diferenciar el agotamiento de glucógeno muscular (pérdida de potencia en piernas) de la hipoglucemia sistémica (mareos y confusión mental).
- Calcular Demandas de Carbohidratos: Calcular metas exactas en gramos según el peso en kg antes (1 a 4 g/kg), durante (30 a 90 g/h) y después del ejercicio (1.0 a 1.2 g/kg/h).
- Diseñar Planes para el Calor Desértico: Diseñar protocolos con carbohidratos de transporte múltiple (glucosa + fructosa en proporción 2:1) y líquidos con electrolitos.

### Lista de Tareas del Módulo:

- Lecturas Obligatorias: Revisar las pautas de carbohidratos y glucógeno de ACSM/AND.
- Discusión 02: Publicación inicial antes del jueves y respuestas a compañeros antes del domingo.
- Sesión de Coaching 02: Consultar al Coach de IA y enviar respuestas en texto plano.
- Laboratorio 02: Completar la auditoría de carbohidratos y entregar en Canvas antes del lunes 11:59 PM MST.

### ACCESIBILIDAD Y UDL

Todos los materiales de visión general en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando accesibilidad total para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu


### Module 02 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 02 Required Readings: Whole-Food Carbohydrates & Energy Fueling →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 02 Discussion: Whole-Food Carbs for Daily Energy →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 02 Coaching Sprint: Choosing Complex Carbs Over Added Sugars →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 02 Lab: Carbohydrate Fueling & Recovery Plan →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 02 Summary & Wrap-Up: Whole-Food Carbohydrates & Energy Fueling →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
