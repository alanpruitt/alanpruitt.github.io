## HLTH-150: Mod 02 Overview Whole Food Carbohydrates And Energy Fueling

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 02 Overview: Whole-Food Carbohydrates & Energy Fueling

Visión General del Módulo 02: Carbohidratos y Almacenamiento de Glucógeno

Welcome to Module 02! This week, we analyze how carbohydrates fuel physical movement, evaluate muscle and liver glycogen depletion, and master the physiology of "bonking" or energy crashes using our Single Source of Truth (SSoT): the Joint Position Statement on Nutrition and Athletic Performance (ACSM/AND) .

¡Bienvenido al Módulo 02! Esta semana analizaremos cómo los carbohidratos alimentan el movimiento, cómo se agota el glucógeno muscular y hepático, y la fisiología del colapso por hipoglucemia ("la pájara") según la postura conjunta del ACSM y la AND.


### Learning Objectives / Objetivos de Aprendizaje

- Differentiate Glycogen Pools: Differentiate intramuscular glycogen depletion (peripheral muscle fatigue) from systemic hypoglycemia (brain fog and dizziness) in active individuals. Diferenciar el agotamiento de glucógeno muscular (fatiga local) de la hipoglucemia sistémica (mareos y fatiga cerebral).
- Calculate Carbohydrate Targets: Calculate exact carbohydrate targets based on body weight in kg for pre-exercise (1–4 g/kg), during-exercise (30–90 g/hr), and post-exercise recovery (1.0–1.2 g/kg/hr). Calcular metas exactas de carbohidratos en g/kg antes (1–4 g/kg), durante (30–90 g/h) y después del ejercicio.
- Design Desert Fueling Plans: Design multiple-transportable carbohydrate and fluid protocols (using glucose and fructose in a 2:1 ratio) to sustain energy and hydration in high desert heat. Diseñar protocolos de carbohidratos de transporte múltiple (relación 2:1) y líquidos para el calor del desierto.

### Module Checklist / Lista de Tareas del Módulo:

- Required Readings: Review the ACSM/AND Carbohydrate & Glycogen Guidelines. Lecturas Obligatorias: Revisar las Pautas de Carbohidratos y Glucógeno de ACSM/AND.
- Discussion 02: Post your initial carbohydrate audit by Thursday 11:59 PM MST and submit peer evaluations by Sunday 11:59 PM MST. Discusión 02: Publicación inicial el jueves y respuestas a compañeros el domingo.
- Coaching Sprint 02: Chat with your AI Socratic Coach, complete your carbohydrate reflection, and submit plain-text responses. Sesión de Coaching 02: Interactuar con el Coach de IA y entregar en texto plano.
- Lab 02: Complete the carbohydrate and glycogen kinetics audit and submit directly into the Canvas text box by Monday 11:59 PM MST. Laboratorio 02: Completar la auditoría de carbohidratos y entregar en Canvas el lunes.

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Overview: Whole-Food Carbohydrates & Energy Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Module overview materials and learning activities in HLTH-150 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools.

Español: Todos los materiales del curso en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total accesibilidad para lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Weekly learning objectives and tasks emphasize conceptual understanding, carbohydrate kinetics mastery, and evidence-based practice over testing pressure.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Visión General del Módulo 02: Carbohidratos y Glucógeno

Cinética de Carbohidratos y Estrategias de Combustible Deportivo

¡Bienvenido al Módulo 02! Esta semana analizaremos cómo los carbohidratos alimentan el movimiento humano, el agotamiento del glucógeno muscular y hepático, y la fisiología del colapso por falta de energía ("la pájara" o bonking) según las pautas científicas del ACSM y la AND.


### Objetivos de Aprendizaje

- Diferenciar Depósitos de Glucógeno: Diferenciar el agotamiento de glucógeno muscular (pérdida de potencia en piernas) de la hipoglucemia sistémica (mareos y confusión mental).
- Calcular Demandas de Carbohidratos: Calcular metas exactas en gramos según el peso en kg antes (1 a 4 g/kg), durante (30 a 90 g/h) y después del ejercicio (1.0 a 1.2 g/kg/h).
- Diseñar Planes para el Calor Desértico: Diseñar protocolos con carbohidratos de transporte múltiple (glucosa + fructosa en proporción 2:1) y líquidos con electrolitos.

### Lista de Tareas del Módulo:

- Lecturas Obligatorias: Revisar las pautas de carbohidratos y glucógeno de ACSM/AND.
- Discusión 02: Publicación inicial antes del jueves y respuestas a compañeros antes del domingo.
- Sesión de Coaching 02: Consultar al Coach de IA y enviar respuestas en texto plano.
- Laboratorio 02: Completar la auditoría de carbohidratos y entregar en Canvas antes del lunes 11:59 PM MST.

### ACCESIBILIDAD Y UDL

Todos los materiales de visión general en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu


### Module 02 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 02 Required Readings: Whole-Food Carbohydrates & Energy Fueling →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 02 Discussion: Whole-Food Carbs for Daily Energy →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 02 Coaching Sprint: Choosing Complex Carbs Over Added Sugars →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 02 Lab: Carbohydrate Fueling & Recovery Plan →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 02 Summary & Wrap-Up: Whole-Food Carbohydrates & Energy Fueling →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 02)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
