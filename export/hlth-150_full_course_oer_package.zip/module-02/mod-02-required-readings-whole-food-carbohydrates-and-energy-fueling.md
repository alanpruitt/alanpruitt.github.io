# HLTH-150: Mod 02 Required Readings Whole Food Carbohydrates And Energy Fueling

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 02 Required Readings: Whole-Food Carbohydrates & Energy Fueling

Lecturas Obligatorias y Recursos de Estudio: Protocolos de Carbohidratos y Glucógeno


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Whole-food carbohydrates are your muscles' and brain's primary high-efficiency fuel during moderate and vigorous exercise. Your body stores digested carbohydrates as glycogen (stored sugar in muscle and liver tissue) to power physical work. Choosing fiber-rich whole grains, beans, and fruit prevents mid-workout fatigue and blood sugar crashes.


#### En Palabras Sencillas (Norteño Context)

Los carbohidratos de comida real—como frijoles, avena y fruta—son la gasolina limpia que mantiene prendido el motor durante un turno largo en Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en cómo ajustar los gramos de carbohidratos por kilo de peso según la duración del entrenamiento.


### Required SSoT Text & Professional Guidelines

Primary Single Source of Truth (SSoT): ACSM / AND / DC Joint Position Stand: Nutrition and Athletic Performance (Carbohydrate Fueling Protocols). Postura Conjunta de ACSM / AND / DC: Nutrición y Rendimiento Deportivo (Protocolos de Carbohidratos).

- Official Journal Article (MSSE): ACSM / AND / DC Position Stand: Nutrition & Athletic Performance (MSSE)
- Official DOI Link: DOI: 10.1249/MSS.0000000000000852
- PubMed Portal: PubMed Reference (PMID: 26891166)

### Core Scientific Concepts / Conceptos Clave


#### Step 1: Pre-Exercise Carbohydrate Loading / Carga Previa al Ejercicio

Consume Outcome 1.0: to 4.0 g/kg of body weight of low-fiber, easily digestible complex carbohydrates 1 to 4 hours prior to endurance events lasting >60 minutes to maximize hepatic and intramuscular glycogen stores.

Consumir de Outcome 1.0: a 4.0 g/kg de peso corporal de carbohidratos complejos de fácil digestión y bajos en fibra de 1 a 4 horas antes del ejercicio >60 minutos para llenar las reservas de glucógeno hepático y muscular sin causar malestar estomacal.


#### Step 2: Intra-Exercise Kinetics & Ultra-Endurance (>2.5 Hours) / Cinética Durante el Ejercicio

For continuous endurance sessions lasting 1.0 to 2.5 hours, consume 30 to 60 g/hour of rapidly oxidizing carbohydrates. For ultra-endurance sessions lasting >2.5 hours , ACSM guidelines recommend up to 90 g/hour using multiple transportable carbohydrates (a 2:1 ratio of glucose/maltodextrin to fructose). This activates both SGLT1 (glucose) and GLUT5 (fructose) intestinal transporters simultaneously, increasing carbohydrate absorption while preventing gastrointestinal distress.

Para sesiones de 1.0 a 2.5 horas, consumir de 30 a 60 g/h . Para eventos de ultrarresistencia >2.5 horas , el ACSM recomienda hasta 90 g/h de carbohidratos de transporte múltiple (relación 2:1 glucosa:fructosa) para activar los transportadores SGLT1 y GLUT5 al mismo tiempo.


#### Step 3: Post-Exercise Glycogen Resynthesis Window / Resíntesis de Glucógeno Posterior

When rapid recovery is needed (<8 hours between hard sessions), consume Outcome 1.0: to 1.2 g/kg/hour during the first 0 to 4 hours post-exercise, or pair 0.8 g/kg/hr of carbohydrates with 0.2 to 0.4 g/kg/hr of protein to stimulate insulin-mediated GLUT4 glycogen storage and muscle repair.

Para una recuperación rápida (<8 horas entre sesiones), consumir de Outcome 1.0: a 1.2 g/kg/h durante las primeras 0 a 4 horas posteriores, o combinar 0.8 g/kg/h de carbohidratos con proteína para acelerar el almacenamiento de glucógeno.


### Key Terminology / Glosario Clave

- Multiple Transportable Carbohydrates / Carbohidratos de Transporte Múltiple: A blend of glucose/maltodextrin and fructose (2:1 ratio) that utilizes both SGLT1 and GLUT5 intestinal transporters to achieve exogenous oxidation rates up to 90 g/hr without stomach upset. Mezcla de glucosa y fructosa (relación 2:1) que utiliza los transportadores intestinales SGLT1 y GLUT5 para absorber hasta 90 g/h sin causar dolor de estómago.
- Hepatic vs. Muscle Glycogen / Glucógeno Hepático vs. Muscular: Muscle glycogen fuels local muscle contractions, whereas liver glycogen maintains systemic blood glucose for the brain. Exhaustion of liver glycogen triggers central hypoglycemia, dizziness, and "bonking." El glucógeno muscular aporta energía a los músculos en movimiento, mientras que el glucógeno hepático mantiene la glucosa para el cerebro. Su agotamiento causa mareos y la clásica "pájara".
- SGLT1 & GLUT5 Transporters / Transportadores SGLT1 y GLUT5: Intestinal SGLT1 glucose transporters saturate at approximately 60 g/hr; fructose absorption via GLUT5 allows an additional ~30 g/hr of carbohydrate delivery. El transportador intestinal SGLT1 se satura a ~60 g/h de glucosa; el transportador GLUT5 de fructosa permite absorber ~30 g/h adicionales.

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Required Readings: Whole-Food Carbohydrates & Energy Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All course readings and study materials in HLTH-150 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers and AI note-taking tools.

Español: Todas las lecturas del curso en HLTH-150 siguen los principios del Diseño Universal para el Aprendizaje (UDL). Esta página utiliza un diseño accesible adaptado a dispositivos móviles y lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Study materials and reference guides remain permanently accessible to support self-paced learning, evidence-based prompt engineering, and clinical auditing without testing friction.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Lecturas Obligatorias y Recursos de Estudio

Protocolos de Carbohidratos, Cinética de Glucógeno y Nutrición Deportiva


### Texto Oficial SSoT y Pautas Profesionales

Fuente Única de la Verdad (SSoT): Postura Conjunta de ACSM / AND / DC: Nutrición y Rendimiento Deportivo (Protocolos de Carbohidratos).

- Artículo Oficial de Revista (MSSE): Postura Conjunta de ACSM / AND / DC (MSSE)
- Enlace DOI Oficial: DOI: 10.1249/MSS.0000000000000852
- Referencia en PubMed: PubMed (PMID: 26891166)

### Conceptos Científicos Clave


#### Step 1: Carga Previa al Ejercicio

Consumir de Outcome 1.0: a 4.0 g/kg de peso corporal de carbohidratos complejos de fácil digestión y bajos en fibra de 1 a 4 horas antes del ejercicio prolongado (>60 minutos) para optimizar el glucógeno hepático y muscular sin causar malestar estomacal.


#### Step 2: Cinética Durante el Ejercicio y Ultrarresistencia (>2.5 Horas)

Para ejercicio continuo de 1.0 a 2.5 horas, ingerir de 30 a 60 g/h . Para eventos de ultrarresistencia >2.5 horas , el ACSM recomienda hasta 90 g/h de carbohidratos de transporte múltiple (relación 2:1 glucosa:fructosa) para activar los transportadores SGLT1 y GLUT5 simultáneamente, maximizando la absorción.


#### Step 3: Ventana de Resíntesis de Glucógeno Posterior

Para una recuperación rápida (<8 horas entre sesiones), consumir de Outcome 1.0: a 1.2 g/kg/h durante las primeras 0 a 4 horas posteriores, o combinar 0.8 g/kg/h de carbohidratos con 0.2 a 0.4 g/kg/h de proteína para acelerar el almacenamiento de glucógeno vía GLUT4.


### Glosario Clave

- Carbohidratos de Transporte Múltiple: Mezcla de glucosa y fructosa (proporción 2:1) que utiliza los transportadores SGLT1 y GLUT5 para absorber hasta 90 g/h de energía sin causar malestar estomacal.
- Glucógeno Hepático vs. Muscular: El glucógeno muscular alimenta las contracciones musculares locales, mientras que el glucógeno hepático mantiene la glucosa para el cerebro. Su vaciamiento provoca mareos y la clásica "pájara".
- Transportadores SGLT1 y GLUT5: El transportador SGLT1 se satura a ~60 g/h de glucosa; añadir fructosa vía GLUT5 permite absorber ~30 g/h adicionales.

### ACCESIBILIDAD Y UDL

Todas las lecturas del curso en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando total compatibilidad con lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

HLTH-150 • Module 02 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 02:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
