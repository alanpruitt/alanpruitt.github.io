## HLTH-150: Mod 02 Required Readings Whole Food Carbohydrates And Energy Fueling

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 02 Required Readings: Whole-Food Carbohydrates & Energy Fueling

Lecturas Obligatorias y Recursos de Estudio: Protocolos de Carbohidratos y Glucógeno


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Whole-food carbohydrates are your muscles' and brain's primary high-efficiency fuel during moderate and vigorous exercise. Your body stores digested carbohydrates as glycogen (stored sugar in muscle and liver tissue) to power physical work. Choosing fiber-rich whole grains, beans, and fruit prevents mid-workout fatigue and blood sugar crashes.


#### En Palabras Sencillas (Norteño Context)

Los carbohidratos de comida real—como frijoles, avena y fruta—son la gasolina limpia que mantiene prendido el motor durante un turno largo en Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en cómo ajustar los gramos de carbohidratos por kilo de peso según la duración del entrenamiento.


### Required SSoT Text & Professional Guidelines

Primary Single Source of Truth (SSoT): ACSM / AND / DC Joint Position Stand: Nutrition and Athletic Performance (Carbohydrate Fueling Protocols). Postura Conjunta de ACSM / AND / DC: Nutrición y Rendimiento Deportivo (Protocolos de Carbohidratos).

- Official Journal Article (MSSE): ACSM / AND / DC Position Stand: Nutrition & Athletic Performance (MSSE)
- Official DOI Link: DOI: 10.1249/MSS.0000000000000852
- PubMed Portal: PubMed Reference (PMID: 26891166)

### Core Scientific Concepts / Conceptos Clave


#### Step 1: Pre-Exercise Carbohydrate Loading / Carga Previa al Ejercicio

Consume Outcome 1.0: to 4.0 g/kg of body weight of low-fiber, easily digestible complex carbohydrates 1 to 4 hours prior to endurance events lasting >60 minutes to maximize hepatic and intramuscular glycogen stores.

Consumir de Outcome 1.0: a 4.0 g/kg de peso corporal de carbohidratos complejos de fácil digestión y bajos en fibra de 1 a 4 horas antes del ejercicio >60 minutos para llenar las reservas de glucógeno hepático y muscular sin causar malestar estomacal.


#### Step 2: Intra-Exercise Kinetics & Ultra-Endurance (>2.5 Hours) / Cinética Durante el Ejercicio

For continuous endurance sessions lasting 1.0 to 2.5 hours, consume 30 to 60 g/hour of rapidly oxidizing carbohydrates. For ultra-endurance sessions lasting >2.5 hours , ACSM guidelines recommend up to 90 g/hour using multiple transportable carbohydrates (a 2:1 ratio of glucose/maltodextrin to fructose). This activates both SGLT1 (glucose) and GLUT5 (fructose) intestinal transporters simultaneously, increasing carbohydrate absorption while preventing gastrointestinal distress.

Para sesiones de 1.0 a 2.5 horas, consumir de 30 a 60 g/h . Para eventos de ultrarresistencia >2.5 horas , el ACSM recomienda hasta 90 g/h de carbohidratos de transporte múltiple (relación 2:1 glucosa:fructosa) para activar los transportadores SGLT1 y GLUT5 al mismo tiempo.


#### Step 3: Post-Exercise Glycogen Resynthesis Window / Resíntesis de Glucógeno Posterior

When rapid recovery is needed (<8 hours between hard sessions), consume Outcome 1.0: to 1.2 g/kg/hour during the first 0 to 4 hours post-exercise, or pair 0.8 g/kg/hr of carbohydrates with 0.2 to 0.4 g/kg/hr of protein to stimulate insulin-mediated GLUT4 glycogen storage and muscle repair.

Para una recuperación rápida (<8 horas entre sesiones), consumir de Outcome 1.0: a 1.2 g/kg/h durante las primeras 0 a 4 horas posteriores, o combinar 0.8 g/kg/h de carbohidratos con proteína para acelerar el almacenamiento de glucógeno.


### Key Terminology / Glosario Clave

- Multiple Transportable Carbohydrates / Carbohidratos de Transporte Múltiple: A blend of glucose/maltodextrin and fructose (2:1 ratio) that utilizes both SGLT1 and GLUT5 intestinal transporters to achieve exogenous oxidation rates up to 90 g/hr without stomach upset. Mezcla de glucosa y fructosa (relación 2:1) que utiliza los transportadores intestinales SGLT1 y GLUT5 para absorber hasta 90 g/h sin causar dolor de estómago.
- Hepatic vs. Muscle Glycogen / Glucógeno Hepático vs. Muscular: Muscle glycogen fuels local muscle contractions, whereas liver glycogen maintains systemic blood glucose for the brain. Exhaustion of liver glycogen triggers central hypoglycemia, dizziness, and "bonking." El glucógeno muscular aporta energía a los músculos en movimiento, mientras que el glucógeno hepático mantiene la glucosa para el cerebro. Su agotamiento causa mareos y la clásica "pájara".
- SGLT1 & GLUT5 Transporters / Transportadores SGLT1 y GLUT5: Intestinal SGLT1 glucose transporters saturate at approximately 60 g/hr; fructose absorption via GLUT5 allows an additional ~30 g/hr of carbohydrate delivery. El transportador intestinal SGLT1 se satura a ~60 g/h de glucosa; el transportador GLUT5 de fructosa permite absorber ~30 g/h adicionales.

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Required Readings: Whole-Food Carbohydrates & Energy Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All course readings and study materials in HLTH-150 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers and AI note-taking tools.

Español: Todas las lecturas del curso en HLTH-150 siguen los principios del Diseño Universal para el Aprendizaje (UDL). Esta página utiliza un diseño accesible adaptado a dispositivos móviles y lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Study materials and reference guides remain permanently accessible to support self-paced learning, evidence-based prompt engineering, and clinical auditing without testing friction.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Lecturas Obligatorias y Recursos de Estudio

Protocolos de Carbohidratos, Cinética de Glucógeno y Nutrición Deportiva


### Texto Oficial SSoT y Pautas Profesionales

Fuente Única de la Verdad (SSoT): Postura Conjunta de ACSM / AND / DC: Nutrición y Rendimiento Deportivo (Protocolos de Carbohidratos).

- Artículo Oficial de Revista (MSSE): Postura Conjunta de ACSM / AND / DC (MSSE)
- Enlace DOI Oficial: DOI: 10.1249/MSS.0000000000000852
- Referencia en PubMed: PubMed (PMID: 26891166)

### Conceptos Científicos Clave


#### Step 1: Carga Previa al Ejercicio

Consumir de Outcome 1.0: a 4.0 g/kg de peso corporal de carbohidratos complejos de fácil digestión y bajos en fibra de 1 a 4 horas antes del ejercicio prolongado (>60 minutos) para optimizar el glucógeno hepático y muscular sin causar malestar estomacal.


#### Step 2: Cinética Durante el Ejercicio y Ultrarresistencia (>2.5 Horas)

Para ejercicio continuo de 1.0 a 2.5 horas, ingerir de 30 a 60 g/h . Para eventos de ultrarresistencia >2.5 horas , el ACSM recomienda hasta 90 g/h de carbohidratos de transporte múltiple (relación 2:1 glucosa:fructosa) para activar los transportadores SGLT1 y GLUT5 simultáneamente, maximizando la absorción.


#### Step 3: Ventana de Resíntesis de Glucógeno Posterior

Para una recuperación rápida (<8 horas entre sesiones), consumir de Outcome 1.0: a 1.2 g/kg/h durante las primeras 0 a 4 horas posteriores, o combinar 0.8 g/kg/h de carbohidratos con 0.2 a 0.4 g/kg/h de proteína para acelerar el almacenamiento de glucógeno vía GLUT4.


### Glosario Clave

- Carbohidratos de Transporte Múltiple: Mezcla de glucosa y fructosa (proporción 2:1) que utiliza los transportadores SGLT1 y GLUT5 para absorber hasta 90 g/h de energía sin causar malestar estomacal.
- Glucógeno Hepático vs. Muscular: El glucógeno muscular alimenta las contracciones musculares locales, mientras que el glucógeno hepático mantiene la glucosa para el cerebro. Su vaciamiento provoca mareos y la clásica "pájara".
- Transportadores SGLT1 y GLUT5: El transportador SGLT1 se satura a ~60 g/h de glucosa; añadir fructosa vía GLUT5 permite absorber ~30 g/h adicionales.

### ACCESIBILIDAD Y UDL

Todas las lecturas del curso en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total compatibilidad con lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

HLTH-150 • Module 02 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 02:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 02)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
