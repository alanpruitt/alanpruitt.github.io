# HLTH-150: Mod 02 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Coaching Sprint Simulation: Choosing Complex Carbs Over Added Sugars

Sesión de Coaching del Módulo 02: Carbohidratos y Almacenamiento de Glucógeno

- Skeletal Muscle & Liver Glycogen Stores (3–12 g/kg/day): Primary stored carbohydrate fuel for moderate-to-high intensity exercise; daily needs scale from 3–5 g/kg (light activity) to 6–10+ g/kg (endurance training). En palabras sencillas: La reserva de carbohidratos guardada en músculos e hígado que te da fuerza para entrenar sin agotarte a mitad de la sesión.
- Complex Whole-Food Carbohydrates & Dietary Fiber (14 g / 1,000 kcal): Whole grains, oats, brown rice, corn tortillas, pinto beans, and whole fruits provide sustained glucose release and gut-protective fiber. En palabras sencillas: Carbohidratos de absorción constante como avena, frijoles, arroz y tortilla de maíz que mantienen estable el azúcar y aportan fibra.
- Glycemic Load & Pre-Exercise Digestive Comfort: Selecting higher-fiber whole carbs for daily meals while tapering fiber and fat closer to exercise to prevent gastrointestinal distress. En palabras sencillas: Comer buena fibra durante el día, pero elegir alimentos más ligeros antes de entrenar para evitar pesadez estomacal.
- HLTH-150.2.1.AY26-27: Analyze carbohydrate metabolism, glycogen storage, and glycemic response in relation to energy output and physical performance. Analizar el metabolismo de carbohidratos, el almacenamiento de glucógeno y la respuesta glucémica en relación con el rendimiento físico.
- HLTH-150.2.2.AY26-27: Apply federal Dietary Guidelines and sports nutrition standards to calculate appropriate carbohydrate intake for diverse activity profiles. Aplicar las Guías Dietéticas federales y normas de nutrición deportiva para calcular la ingesta adecuada de carbohidratos.

### Your Weekly Win: Fueling Human Movement

How does what you put on your plate turn into explosive sprint energy on the field or steady endurance on the trail? Carbohydrates are the body's primary high-octane fuel, stored efficiently as glycogen in muscles and the liver. Understanding how to balance complex carbohydrates, fiber, and glycogen replenishment separates sustainable performance from early exhaustion. Choose your coaching track below, chat with your AI Socratic Coach, and master carbohydrate fueling science!

¿Cómo se convierte la comida en energía para el movimiento? Los carbohidratos son el combustible principal del cuerpo, almacenados como glucógeno en el hígado y los músculos. ¡Elija su ruta, dialogue con su Coach de IA y domine la ciencia del combustible!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Selección de Escenario de Simulación Clínica

Scenario: Patient managing prediabetes (Carlos, 52) who wants to start a walking program but is terrified that eating any carbohydrates will spike his blood sugar.

Scenario: Youth soccer coach (Maya, 28) whose players eat sugary candy right before matches thinking it counts as "carb loading."

Scenario: Half-marathon runner (Jessica, 28) following an extreme low-carb diet who is hitting the "wall" early in her long training runs.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client / Ruta y Cliente Seleccionado: State your selected track and client's nutritional challenge. Indique la ruta y el desafío de carbohidratos de su cliente.
- Carbohydrate & Glycogen Analysis / Análisis de Carbohidratos y Glucógeno: Explain how carbohydrates are metabolized and stored as glycogen in relation to your client's activity profile. Explique cómo se metabolizan y almacenan los carbohidratos en relación con la actividad de su cliente.
- My Practical Nutrition Strategy / Mi Estrategia Práctica: Provide 1 clear, evidence-based dietary recommendation aligned with federal guidelines. Escriba 1 recomendación basada en evidencia y alineada con las pautas federales.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why prioritizing complex whole-food carbohydrates and timely glycogen replenishment prevents "bonking" and protects metabolic health under DGA 2025–2030 standards.
- My Memorable Coaching Takeaway / Mi Frase Inolvidable de Coaching: Write your favorite memorable takeaway sentence in English and Spanish. Escriba su aprendizaje clave en inglés y español.
- Repository Verification / Verificación del Repositorio: Confirm export to EXW_Professional_AI_Repository . Confirme el guardado en su carpeta de Google Drive.

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 02 Coaching Sprint • Track 3 (Endurance / Jessica)

- Chosen Track & Client: Track 3: Adult Fitness & Endurance Coaching (Jessica, 28). Challenge: Jessica is following an extreme low-carb diet while training for a half-marathon, leading to depleted muscle glycogen and early training exhaustion around Mile 6.
- Track 3: Adult Fitness & Endurance Coaching (Jessica, 28).
- Challenge: Jessica is following an extreme low-carb diet while training for a half-marathon, leading to depleted muscle glycogen and early training exhaustion around Mile 6.
- Carbohydrate & Glycogen Analysis: Glycogen Storage: Carbohydrates are stored as glycogen in liver and skeletal muscle tissue. Endurance exercise relies heavily on this stored glycogen for sustained energy. Eliminating carbs starves working muscles of their primary high-octane fuel. Aligning with federal Dietary Guidelines, endurance runners require nutrient-dense complex carbohydrates to maintain performance without sudden energy crashes.
- Glycogen Storage: Carbohydrates are stored as glycogen in liver and skeletal muscle tissue. Endurance exercise relies heavily on this stored glycogen for sustained energy. Eliminating carbs starves working muscles of their primary high-octane fuel.
- Aligning with federal Dietary Guidelines, endurance runners require nutrient-dense complex carbohydrates to maintain performance without sudden energy crashes.
- My Practical Nutrition Strategy for Jessica: "Reintroduce high-fiber complex carbohydrates (like whole grains, sweet potatoes, and beans) into daily meals, and consume easily digestible carbs (like a banana or toast with honey) 60 minutes before long runs to top off glycogen stores."
- "Reintroduce high-fiber complex carbohydrates (like whole grains, sweet potatoes, and beans) into daily meals, and consume easily digestible carbs (like a banana or toast with honey) 60 minutes before long runs to top off glycogen stores."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Jessica hitting 'the wall' at mile 6 of her half-marathon training is not a cardiovascular fitness failure—it is severe skeletal muscle glycogen depletion caused by her ketogenic low-carb diet. While adipose fat stores are vast, beta-oxidation cannot generate ATP fast enough to sustain high-intensity running above 70% VO2max, Especially when Yuma's heat accelerates carbohydrate oxidation. By applying the 2025–2030 Dietary Guidelines for Americans (45–65% AMDR from complex carbohydrates and <10% added sugars), introducing 5–7 g/kg/day of whole grains, fruit, and legumes plus 30–60 g/hr of intra-run carbohydrates restores her liver and muscle glycogen reservoirs so she can finish strong without hypoglycemic dizziness."
- My Memorable Coaching Takeaway: EN: "Carbohydrates are not the enemy—they are the premium fuel that powers endurance and performance!" ES: "¡Los carbohidratos no son el enemigo; son el combustible premium que impulsa la resistencia y el rendimiento!"
- EN: "Carbohydrates are not the enemy—they are the premium fuel that powers endurance and performance!"
- ES: "¡Los carbohidratos no son el enemigo; son el combustible premium que impulsa la resistencia y el rendimiento!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M02_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 02 (Mod 02 Coaching Sprint: Choosing Complex Carbs Over Added Sugars)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Coaching Sprint prompts and learning activities in HLTH-150 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools.

Español: Todas las actividades de Coaching Sprint en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando accesibilidad total para lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Coaching Sprints are low-stakes, untimed reflections evaluated on a 3-tier scale (10/7/0 pts) to build confidence, practical nutrition reasoning, and bilingual coaching skills.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

HLTH-150 • Nutrición Deportiva y para el Ejercicio


## Módulo 02 Simulación de Coaching: Carbohidratos y Glucógeno

Evaluación Rápida y Aprendizaje Práctico de la Nutrición Energética


### Su Logro Semanal: Abasteciendo el Movimiento Humano

Esta sesión le permitirá entender cómo los carbohidratos se transforman en energía y se almacenan como glucógeno. Aprenda a equilibrar carbohidratos complejos y fibra de acuerdo con las Guías Dietéticas federales. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Elija UNA de las tres rutas profesionales para su consulta con el Coach de IA:

Paciente con prediabetes (Carlos, 52 años) que eliminó los carbohidratos por miedo a elevar su azúcar.

Entrenadora de fútbol (Maya, 28 años) cuyos jugadores comen dulces antes del partido.

Corredora de medio maratón (Jessica, 28 años) con dieta extrema baja en carbohidratos.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de carbohidratos de su cliente.
- Análisis de Carbohidratos y Glucógeno: Explique cómo se metabolizan y almacenan los carbohidratos en relación con la actividad de su cliente.
- Mi Estrategia Nutricional Práctica: Escriba 1 recomendación basada en evidencia y alineada con las pautas federales.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué priorizar carbohidratos complejos de alimentos reales y reponer el glucógeno previene el colapso energético ("la pared") según las Guías DGA 2025–2030.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Evaluación en Español (Escala 10/7/0)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: HLTH-150 Módulo 02 Sesión de Coaching • Ruta 3 (Resistencia / Jessica)

- Ruta y Cliente Seleccionado: Ruta 3: Entrenamiento en Adultos y Resistencia (Jessica, 28 años). Reto: Jessica sigue una dieta estricta sin carbohidratos mientras entrena para un medio maratón, vaciando sus reservas de glucógeno muscular y chocando contra "la pared" en la milla 6.
- Ruta 3: Entrenamiento en Adultos y Resistencia (Jessica, 28 años).
- Reto: Jessica sigue una dieta estricta sin carbohidratos mientras entrena para un medio maratón, vaciando sus reservas de glucógeno muscular y chocando contra "la pared" en la milla 6.
- Análisis de Carbohidratos y Glucógeno: Almacenamiento de Glucógeno: Los carbohidratos se almacenan como glucógeno en el hígado y el músculo. El ejercicio de resistencia depende de este combustible rápido. Eliminar los carbohidratos priva al músculo de su energía principal. Las Guías Dietéticas federales indican que los corredores de resistencia necesitan carbohidratos complejos ricos en nutrientes para mantener el ritmo sin fatiga temprana.
- Almacenamiento de Glucógeno: Los carbohidratos se almacenan como glucógeno en el hígado y el músculo. El ejercicio de resistencia depende de este combustible rápido. Eliminar los carbohidratos priva al músculo de su energía principal.
- Las Guías Dietéticas federales indican que los corredores de resistencia necesitan carbohidratos complejos ricos en nutrientes para mantener el ritmo sin fatiga temprana.
- Mi Estrategia Nutricional para Jessica: "Reintroducir carbohidratos complejos ricos en fibra (granos enteros, camote y frijoles) en las comidas diarias, y consumir un refrigerio ligero de carbohidratos (como plátano o tostada con miel) 60 minutos antes de las carreras largas para llenar el glucógeno."
- "Reintroducir carbohidratos complejos ricos en fibra (granos enteros, camote y frijoles) en las comidas diarias, y consumir un refrigerio ligero de carbohidratos (como plátano o tostada con miel) 60 minutos antes de las carreras largas para llenar el glucógeno."
- Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi criterio clínico, el hecho de que Jessica choque contra 'la pared' en la milla 6 no es falta de condición cardiopulmonar, sino el vaciamiento severo de glucógeno muscular causado por su dieta sin carbohidratos. A intensidades de medio maratón y bajo el calor de Yuma, la oxidación de grasas no produce ATP con la rapidez necesaria. Al aplicar las Guías Alimentarias 2025–2030 (45–65% AMDR de carbohidratos complejos y menos del 10% de azúcares añadidos), incorporar 5–7 g/kg/día de avena, arroz, fruta y legumbres más 30–60 g/h en carrera restaura su glucógeno y evita la hipoglucemia."
- Mi Frase Inolvidable de Coaching: EN: "Carbohydrates are not the enemy—they are the premium fuel that powers endurance and performance!" ES: "¡Los carbohidratos no son el enemigo; son el combustible premium que impulsa la resistencia y el rendimiento!"
- EN: "Carbohydrates are not the enemy—they are the premium fuel that powers endurance and performance!"
- ES: "¡Los carbohidratos no son el enemigo; son el combustible premium que impulsa la resistencia y el rendimiento!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M02_Quiz_Sprint.pdf

### ACCESIBILIDAD Y UDL

Todas las actividades de Coaching Sprint en HLTH-150 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando accesibilidad total para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:
