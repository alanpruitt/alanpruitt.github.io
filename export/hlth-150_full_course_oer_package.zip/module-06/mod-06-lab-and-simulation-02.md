# HLTH-150: Mod 06 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Coaching Sprint Simulation: Getting Vitamins & Minerals from Real Food

Sesión de Coaching del Módulo 06: Micronutrientes, Electrólitos y Dinámica de Hidratación

- Heme vs. Non-Heme Iron & Oxygen Transport: Iron forms hemoglobin and myoglobin to carry oxygen; pairing plant non-heme iron (beans, spinach) with Vitamin C (citrus/lime) triples absorption. En palabras sencillas: El hierro lleva oxígeno a tu sangre y músculos; ponerle limón o naranja a los frijoles y espinacas ayuda a que el cuerpo lo absorba mucho mejor.
- Bone Mineral Triad (Calcium, Vitamin D & Magnesium): Essential micronutrients from dairy, fortified foods, fish, greens, and legumes that protect bone mineral density against stress fractures. En palabras sencillas: Calcio, vitamina D y magnesio obtenidos de alimentos reales para mantener los huesos fuertes y prevenir fisuras por impacto.
- Whole-Food Antioxidants vs. Mega-Dose Pills: Colorful fruits and vegetables reduce exercise oxidative stress naturally, whereas high-dose antioxidant pills can blunt training adaptations. En palabras sencillas: Las frutas y verduras de colores protegen tus células de forma natural, mientras que abusar de pastillas en megadosis puede frenar tu progreso.
- HLTH-150.6.1.AY26-27: Evaluate the role of essential vitamins and minerals (iron, calcium, Vitamin D, and electrolytes) in energy metabolism, oxygen transport, and skeletal health. Evaluar el papel de vitaminas y minerales esenciales en el metabolismo energético, el transporte de oxígeno y la salud ósea.
- HLTH-150.6.2.AY26-27: Apply dietary standards and micronutrient guidelines to prevent deficiencies, maintain fluid balance, and support optimal recovery. Aplicar normas dietéticas y pautas de micronutrientes para prevenir deficiencias, mantener el balance hídrico y apoyar la recuperación.

### Your Weekly Win: The Power of Micronutrients & Cellular Fluid Balance

While macronutrients provide bulk caloric energy, micronutrients (vitamins and minerals) and electrolytes act as the vital spark plugs that drive enzymatic ATP resynthesis, systemic oxygen transport, and neuromuscular contraction. Uncorrected deficiencies in iron, calcium, or sodium can silently undermine athletic performance and health. Choose your coaching track below, chat with your AI Socratic Coach, and master micronutrient and hydration science!

¿Cómo impactan los micronutrientes en el rendimiento? Aunque no aportan calorías directas, las vitaminas, minerales y electrólitos regulan cada reacción metabólica y de transporte de oxígeno. ¡Elija su ruta, dialogue con su Coach de IA y domine la ciencia nutricional!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija el escenario que más se alinee con su interés vocacional

Scenario: Anemia-prone female endurance runner (Elena, 24) with low serum ferritin experiencing chronic fatigue and shortness of breath during training at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Metabolic Health Path
[CLIENT]: Anemia-Prone Endurance Runner (Elena, 24) | [LOCATION]: Yuma, AZ
[SITUATION]: Suffers from depleted iron stores (serum ferritin < 15 ng/mL), leading to compromised hemoglobin synthesis, chronic fatigue, poor systemic oxygen transport, and elevated running heart rates.
[COACHING GOAL]: Apply federal DGA standards to explain the physiological role of iron, heme vs. non-heme bioavailability, and vitamin C pairing to correct deficiency safely.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Sports Medicine & Hematology.
###
```

Scenario: High school basketball athlete (Jordan, 16) taking unregulated mega-dose vitamin supplement stacks without understanding proper micronutrient upper limits.


```text
###
[TRACK]: Track 2 - Community & Youth Coaching Path
[CLIENT]: High School Basketball Athlete (Jordan, 16) | [LOCATION]: Yuma County, AZ
[SITUATION]: Consuming excessive commercial mega-dose fat-soluble vitamin supplements (Vitamins A and D exceeding Tolerable Upper Intake Levels), risking toxicity and gastrointestinal distress.
[COACHING GOAL]: Educate the athlete on whole-food nutrient density versus supplement risks, aligned with DGA food-first standards and hydration adequacy.
[COMMUNITY SITE]: Yuma County Public Health Services District & High School Athletic Centers.
###
```

Scenario: Adult strength lifter (Marcus, 30) cutting dairy and calcium intake entirely during a cutting phase, risking bone mineral density and skeletal integrity.


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Coaching Path
[CLIENT]: Strength Lifter Cutting Dairy (Marcus, 30) | [LOCATION]: Yuma, AZ
[SITUATION]: Eliminates dairy and calcium-rich foods to accelerate a calorie cutting phase, compromising bone mineralization and skeletal structural support under heavy axial barbell loads.
[COACHING GOAL]: Analyze calcium (1,000 mg/day) and Vitamin D requirements for resistance training and identify accessible whole-food dietary sources to protect bone mineral density.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: HLTH-150 Micronutrients & Hydration Tool Box ###:
Role: Supportive HLTH-150 Sports Nutrition Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Dietary Guidelines for Americans (DGA / USDA) & Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms the physiological role of essential vitamins, minerals, or electrolytes relevant to the client's health and athletic profile.
Step 3: Guide the student to give their client ONE practical whole-food dietary adjustment or micronutrient strategy to correct their deficiency or toxicity risk.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how micronutrients sustain cellular function and athletic vitality.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's micronutrient challenge or dietary restriction.
- Micronutrient & Physiological Analysis: Explain how specific vitamins, minerals, or electrolytes function relative to your client's health and performance needs.
- My Practical Micronutrient Strategy: Provide 1 clear, evidence-based whole-food dietary recommendation.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why whole-food vitamin/mineral bioavailability and the $16\text{–}24\text{ oz/lb}$ sweat replacement rule are safer than megadose supplements.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 06 Coaching Sprint • Track 3 (Strength / Marcus)

- Chosen Track & Client: Track 3: Adult Fitness & Strength Coaching (Marcus, 30). Challenge: Marcus has completely eliminated dairy and calcium-rich foods during a cutting phase, risking bone mineral density and structural skeletal support under heavy axial barbell loads.
- Track 3: Adult Fitness & Strength Coaching (Marcus, 30).
- Challenge: Marcus has completely eliminated dairy and calcium-rich foods during a cutting phase, risking bone mineral density and structural skeletal support under heavy axial barbell loads.
- Micronutrient & Physiological Analysis: Calcium & Bone Health: Calcium (1,000 mg/day RDA) and Vitamin D are essential for bone mineralization and actin-myosin cross-bridge excitation-contraction coupling. Heavy resistance training places immense mechanical stress on skeletal tissue; inadequate dietary calcium forces the body to resorb bone calcium, increasing the risk of stress fractures. Eliminating entire food groups during cutting phases compromises long-term athletic longevity unless alternative bioavailable sources are provided.
- Calcium & Bone Health: Calcium (1,000 mg/day RDA) and Vitamin D are essential for bone mineralization and actin-myosin cross-bridge excitation-contraction coupling. Heavy resistance training places immense mechanical stress on skeletal tissue; inadequate dietary calcium forces the body to resorb bone calcium, increasing the risk of stress fractures.
- Eliminating entire food groups during cutting phases compromises long-term athletic longevity unless alternative bioavailable sources are provided.
- My Practical Micronutrient Strategy for Marcus: "Incorporate calcium-fortified unsweetened plant milks, dark leafy greens (collard greens and kale), canned sardines with bones, or calcium-set tofu into your daily meal plan to achieve 1,000 mg of calcium daily without adding unwanted surplus calories."
- "Incorporate calcium-fortified unsweetened plant milks, dark leafy greens (collard greens and kale), canned sardines with bones, or calcium-set tofu into your daily meal plan to achieve 1,000 mg of calcium daily without adding unwanted surplus calories."
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, commercial megadose vitamin pills create a false sense of security while risking fat-soluble toxicity above the Tolerable Upper Intake Level (UL) and failing to replace sweat fluid losses in Yuma. By following the 2025–2030 Dietary Guidelines food-first mandate, we pair plant non-heme iron (beans, spinach) with Vitamin C (citrus, tomatoes) to triple intestinal absorption, deliver fat-soluble Vitamins A, D, E, and K alongside natural food lipids, and replace every pound of sweat lost with 16 to 24 ounces of water. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- My Memorable Coaching Takeaway: EN: "Strong muscles need strong bones—never sacrifice micronutrient adequacy for a calorie deficit!" ES: "¡Los músculos fuertes necesitan huesos fuertes; nunca sacrifiques los micronutrientes por un déficit calórico!"
- EN: "Strong muscles need strong bones—never sacrifice micronutrient adequacy for a calorie deficit!"
- ES: "¡Los músculos fuertes necesitan huesos fuertes; nunca sacrifiques los micronutrientes por un déficit calórico!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M06_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 06 (Mod 06 Coaching Sprint: Getting Vitamins & Minerals from Real Food)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición Deportiva y para el Ejercicio


## Módulo 06 Simulación de Coaching: Micronutrientes e Hidratación

Evaluación Rápida y Aprendizaje Práctico de Vitaminas, Minerales y Electrólitos


### Su Logro Semanal: El Poder de los Micronutrientes y el Balance Celular

Esta sesión le permitirá comprender el papel fundamental de las vitaminas, minerales y electrólitos en las reacciones enzimáticas, el transporte de oxígeno y la salud ósea. Aprenda a prevenir deficiencias nutricionales de forma segura. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: HLTH-150 Micronutrientes e Hidratacion ###:
Rol: Coach de Nutricion Deportiva de HLTH-150 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Guias Alimentarias para los Estadounidenses (DGA / USDA) y Pautas de Actividad Fisica (PAGA 2018, 2.a edicion).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla el papel de las vitaminas, minerales o electrolitos esenciales relevantes para la salud y el perfil atletico de su cliente.
Step 3: Guiar al estudiante para proponer UN ajuste dietetico practico o estrategia de micronutrientes para corregir su deficiencia o riesgo de toxicidad.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como los micronutrientes sostienen la funcion celular y la vitalidad atletica.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de micronutrientes o restricción dietética de su cliente.
- Análisis de Micronutrientes y Fisiología: Explique cómo funcionan vitaminas o minerales específicos en relación con las necesidades de salud y rendimiento de su cliente.
- Mi Estrategia Práctica de Micronutrientes: Escriba 1 recomendación dietética clara y basada en alimentos reales.
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica explicando por qué la biodisponibilidad de vitaminas y minerales en alimentos reales y la regla de $16\text{–}24\text{ oz/lb}$ superan a las megadosis en pastillas.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Ejemplo de La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): "En mi juicio clínico, las pastillas de megadosis pueden superar el Límite Superior Tolerable (UL) sin corregir la deshidratación en Yuma. Siguiendo las Pautas DGA 2025–2030 de comida real primero, combinamos frijoles con vitamina C natural para triplicar la absorción de hierro y reponemos de 16 a 24 onzas de agua por cada libra de sudor perdida."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:
