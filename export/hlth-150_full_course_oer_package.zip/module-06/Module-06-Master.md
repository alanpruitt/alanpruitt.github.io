## HLTH-150: LAB 06 - DIET STRATEGIES / ESTRATEGIAS DIETÉTICAS 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## > ###  Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (sports nutrition requirements, hydration audits, and energy demands).

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This module covers the physiological evaluation of multi-day dietary variations, macronutrient manipulation strategies, and their long-term effects on physical performance and metabolic health. Students will use evidence-based baselines to critically audit modern commercial diet trends, identifying how severe energy restrictions or imbalances impact systemic recovery. All structural criteria and comparison baselines align exclusively with our dual SSoT: the current **U.S. Dietary Guidelines for Americans** and the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* *Español (Regional): Este módulo abarca la evaluación fisiológica de las variaciones dietéticas de varios días, las estrategias de manipulación de macronutrientes y sus efectos a largo plazo en el rendimiento físico y la salud metabólica. Los estudiantes utilizarán líneas de referencia basadas en evidencia para auditar críticamente las tendencias dietéticas comerciales modernas, identificando cómo las restricciones energéticas severas afectan la recuperación sistémica. Todos los criterios de comparación se alinean exclusivamente con nuestro SSoT dual: las **Pautas Dietéticas para Estadounidenses** vigentes y las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.4])** Evaluate various diet and supplementation strategies and their effects on health and physical performance.
* *Español (Regional) ([LO 2.4]): Evaluar diversas estrategias de dieta y suplementación y sus efectos sobre la salud y el rendimiento físico.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Map multi-day energetic deficits, micronutrient shortfalls, and performance degradation patterns associated with restrictive commercial dietary structures.
2. **Rule / Regla:** Apply formal daily energy availability rules and macronutrient adequacy ranges (45% to 65% carbohydrates, 10% to 35% protein, 20% to 35% fat) established within the dual SSoT.
3. **Solve / Solución:** Engineer an optimized multi-day fueling modification strategy that balances specific training volumes safely while maintaining strict compliance with federal guidelines.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Commercial Trend Auditing & AI Sandbox Interaction

Students will initialize their nutritional optimization models inside the digital sandbox workspace using the setup records wrapped below.

```text
## METABOLIC_STRATA:
- Mass Marker: 20-year-old male student-athlete (Mesa, AZ)
- Activity Profile: Intercollegiate soccer player training 5 days per week (Estimated Total Daily Energy Expenditure (TDEE): 3,200 kcal/day)
- Intervention Setup: Extreme commercial low-carbohydrate fad diet (Carnivore/Keto variation) for 21 days
- Current Intake: 2,200 kcal/day (Carbohydrates: 25g [4.5%], Protein: 220g [40%], Fat: 135g [55%])
- Symptom Tracker: Profound premature fatigue during intervals, muscle cramping at minute 60, delayed cognitive focus
###
```

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

Copy the complete command instruction block below, including the triple-hash delimiters, and paste it directly into your Gemini AI interface. Use the interactive dialogue output to complete your auditing workspace.

## <h3>AI TOOL KIT PROMPT - HLTH-150 MODULE 06 QUIZ MASTER</h3>
You are acting as the Lead Clinical Diet audit assistant for an introductory kinesiology program. Your task is to stress-test a student's capacity to audit modern commercial dietary trends against the strict federal standards established in the U.S. Dietary Guidelines for Americans and the PAGA 2018 (2nd Ed).

Instructions for your interaction with the student:

1. Initialize the session by displaying the current baseline data wrapped inside '###' delimiters exactly as provided by the student.
2. Ask the student one question at a time to guide them through The Clinical Framing Protocol analysis framework:
   * **Step 1 (Pattern):** Ask them to calculate the baseline percentage deficits compared to the standard Acceptable Macronutrient Distribution Ranges (AMDR).
   * **Step 2 (Rule):** Ask them to identify the specific physiological and metabolic mechanisms disrupted when an active individual drops carbohydrate levels down to 25 grams per day.
   * **Step 3 (Solve):** Prompt them to calculate the exact adjustment required in carbohydrate grams to bring this configuration up to a reference baseline target of 55% of total energy needs.
3. Wait for the student's direct text input before moving to the next level of the evaluation loop. Do not provide the answer; coach them toward aligning the setup parameters safely with federal standards.

## ---

## Part B: Practical Application (Onsite Lab) / Aplicación Práctica Presencial (Laboratorio)

## Location: Community College Athletics Facilities & Localized Workspace Orientation

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

Submit a formal clinical assessment sheet containing the following structural verification lines:

1. **The Pattern Audit:** A table detailing the energy mismatch between target TDEE and current calorie intake, listing the exact macro percentages that violate the SSoT AMDR bounds.
2. **The Clinical Rule Assessment:** A short essay outline identifying the primary biochemical pathways impacted by severe carbohydrate restriction (e.g., glycogen depletion, compromised glycolytic energy transfer system capacity).
3. **The Sustainable Modification Plan:** A rebalanced daily menu strategy built entirely upon the U.S. Dietary Guidelines framework, providing a clean calculation map of grams to meet the 3,200 kcal/day energetic needs while staying clear of low-carb commercial trends.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This assignment is evaluated using the strict **10/7/0 Mastery Scale** / *Esta asignación se evalúa utilizando la escala estricta de Maestría **10/7/0**:*

* **10 (Exemplary / Ejemplar):**
  * **English:** Zero-drift integration. All core guidelines are applied exactly, target parameters remain securely enclosed within delimiter structures (`###`), and bilingual parity is fully preserved.
  * *Español (Regional): Integración con cero desviaciones. Todas las pautas de referencia se aplican exactamente, los parámetros de configuración permanecen contenidos de forma segura dentro de las estructuras delimitadoras (`###`) y se conserva por completo la paridad bilingüe.*
* **7 (Competent / Competente):**
  * **English:** Core performance metrics are safe, safe thermal boundaries are maintained, and calculations are accurate, but minor regional translation gaps, loose formatting, or structural layout misplacements are flagged.
  * *Español (Regional): Las métricas de rendimiento principales son seguras, se mantienen los límites de seguridad térmica y los cálculos son precisos, pero se señalan brechas menores de traducción regional, formato suelto o desalineaciones en la estructura.*
* **0 (Recalibrate / Recalibrar):**
  * **English:** Critical calculation drift is present, safety thresholds are violated, commercial/fad-based trends are promoted instead of the federal SSoT, or core data inputs are left un-delimited.
  * *Español (Regional): Se presenta una desviación crítica en los cálculos, se violan los límites de seguridad, se promueven tendencias comerciales en lugar de la Fuente Única de Verdad (SSoT) federal, o las entradas de datos clave se dejan sin delimitar.*

---

## HLTH-150 Module Discussion: Commercial Trends vs. Evidence-Based Dietary Guidelines

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Evaluate the target configuration variables to map your macronutrient adjustments, and defend your meal tracking modifications using the federal reference standards.
* **Español (Regional):** Evaluar las variables de configuración para mapear los ajustes de macronutrientes y defender sus modificaciones de seguimiento de comidas utilizando los estándares de referencia federales.
###



## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
