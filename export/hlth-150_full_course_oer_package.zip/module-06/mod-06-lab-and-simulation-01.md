## HLTH-150: Mod 06 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Lab & Simulation: Micronutrient & Daily Hydration Audit

Laboratorio del Módulo 06: Auditoría de Micronutrientes e Hidratación Diaria


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: In this lab, you will audit a Yuma client's vitamin, mineral, and daily water intake using the 2025–2030 Dietary Guidelines for Americans. You will calculate exact sweat fluid replacement ($16\text{–}24\text{ oz}$ per pound lost), replace risky megadose pills with bioavailable whole foods, and defend your clinical plan in your own voice. This builds real-world skill in solving fatigue, cramping, and dehydration without expensive commercial powders.

En Palabras Sencillas (Contexto Norteño): En este laboratorio vas a revisar si a tu cliente en Yuma le faltan vitaminas, minerales o agua del diario. Si los términos técnicos se ponen pesados, concéntrate primero en cambiar las pastillas de megadosis por comida real (frijoles con limón, sardinas, aguacate, verdura verde) y en calcular cuántas onzas de agua debe tomar por cada libra de sudor perdida.

- Heme vs. Non-Heme Iron & Oxygen Transport: Iron forms hemoglobin and myoglobin to carry oxygen; pairing plant non-heme iron (beans, spinach) with Vitamin C (citrus/lime) triples absorption. En palabras sencillas: El hierro lleva oxígeno a tu sangre y músculos; ponerle limón o naranja a los frijoles y espinacas ayuda a que el cuerpo lo absorba mucho mejor.
- Bone Mineral Triad (Calcium, Vitamin D & Magnesium): Essential micronutrients from dairy, fortified foods, fish, greens, and legumes that protect bone mineral density against stress fractures. En palabras sencillas: Calcio, vitamina D y magnesio obtenidos de alimentos reales para mantener los huesos fuertes y prevenir fisuras por impacto.
- Whole-Food Antioxidants vs. Mega-Dose Pills: Colorful fruits and vegetables reduce exercise oxidative stress naturally, whereas high-dose antioxidant pills can blunt training adaptations. En palabras sencillas: Las frutas y verduras de colores protegen tus células de forma natural, mientras que abusar de pastillas en megadosis puede frenar tu progreso.

### Lab Objectives / Objetivos del Laboratorio

- HLTH-150.4.1.AY26-27: Audit micronutrient adequacy (Iron, Calcium, Vitamin D, Magnesium, Potassium, Vitamin C) and Tolerable Upper Intake Level ($\text{UL}$) safety using the 2025–2030 Dietary Guidelines for Americans .
- HLTH-150.4.2.AY26-27: Calculate individualized sweat mass-loss percentages and fluid replacement volumes ($16\text{–}24\text{ oz/lb}$ lost) for active Yuma County residents using the Clinical Framing Protocol (Pattern / Rule / Solve) .
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-06 / Fase 1: Selección de Escenario de Simulación Clínica


```text
STRUCTURAL_DELIMITER_BOUND_1 ###:
[CASE FILE]: #150-06A (Track 1: Clinical & Dietetics Path)
[CLIENT]: Valeria M., Age 21, AWC Cross-Country Runner (Yuma, AZ; Pre-run Mass: 130.0 lbs; Post-run Mass: 127.0 lbs after 60-min desert run)
[CURRENT LOG]: Plant-forward diet eating spinach and pinto beans while drinking 16 oz iced black tea with meals; takes an unverified "Energy Booster" pill containing 150 mg Vitamin B6 (UL = 100 mg/day) and 65 mg elemental iron on an empty stomach (causing nausea); drinks only 24 oz water post-run.
[CLINICAL TASK]: Audit her 3.0 lb (2.3%) sweat loss, B6 UL violation, and tea tannin iron block against DGA 2025-2030 food-first standards.
STRUCTURAL_DELIMITER_BOUND_1 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_2 ###:
[CASE FILE]: #150-06B (Track 2: Community & Public Health Path)
[CLIENT]: Sra. Rosa G., Age 64, Retired Teacher & Morning Walker (Somerton, AZ)
[CURRENT LOG]: Avoids all dairy due to mild lactose sensitivity; gets ~350 mg/day Calcium (RDA = 1,200 mg/day) and 150 IU/day Vitamin D (RDA = 600-800 IU/day); drinks only 36 oz total fluid/day (mostly sweet coffee) and experiences afternoon headaches and dark yellow urine after 45-minute walks.
[CLINICAL TASK]: Audit her DGA 2025-2030 Nutrients of Public Health Concern (Calcium, Vitamin D, Potassium) and daily water intake (AI = 91 oz / 2.7 L total water).
STRUCTURAL_DELIMITER_BOUND_2 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_3 ###:
[CASE FILE]: #150-06C (Track 3: Sports & Tactical Performance Path)
[CLIENT]: Mateo R., Age 33, Agricultural Irrigation Supervisor (San Luis, AZ; Pre-shift Mass: 190.0 lbs; Post-shift Mass: 185.5 lbs in 104°F heat)
[CURRENT LOG]: Loses 4.5 lbs (2.37% body mass) during morning field inspection; drinks two sugary energy drinks and 32 oz plain water with zero potassium- or magnesium-rich whole foods; takes a 15,000 IU preformed Vitamin A supplement daily (UL = 10,000 IU / 3,000 mcg RAE) "for desert eye protection"; reports calf cramping.
[CLINICAL TASK]: Audit his 4.5 lb sweat deficit (72-108 oz replacement target), fat-soluble Vitamin A UL toxicity risk, and whole-food electrolyte needs.
STRUCTURAL_DELIMITER_BOUND_3 ###:
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Consulta de IA


```text
Safety Auditor Protocol — HLTH-150 Module 06 Lab ###:
Act as my HLTH-150 Clinical Nutrition & Hydration Auditor. Evaluate the Yuma client case wrapped in triple-hashes (###) below using the 2025-2030 Dietary Guidelines for Americans (Real Food Focus) and PAGA 2018:
Step 1: PATTERN: Calculate % body-mass sweat loss and identify micronutrient shortfalls or Tolerable Upper Intake Level (UL) supplement hazards.
Step 2: RULE: Cite DGA 2025-2030 RDAs/AIs/ULs and the 16-24 oz per pound sweat replacement rule.
Step 3: SOLVE: Design a culturally grounded Yuma whole-food micronutrient & hydration plan plus a 2-sentence bilingual instruction card (EN/ES). Remind me to write my 150-word minimum Active Verification (Part 3) in my own human voice!
Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Requirements

- Selected Track & Client Initials: State your track (#150-06A, #150-06B, or #150-06C).
- Part 1: Pattern Recognition (Micronutrient & Sweat Audit): Quantify % body-mass sweat loss or daily water deficit, underconsumed micronutrients, and any supplement UL violations.
- Part 2: Rule Application (DGA 2025–2030 & Hydration Standards): Cite exact RDAs/AIs/ULs from the 2025–2030 Dietary Guidelines for Americans and the $16\text{–}24\text{ oz/lb}$ fluid replacement rule.
- Part 3: Solving the Gap (Whole-Food Meal & Hydration Plan + Bilingual Card): Provide a food-first meal and hydration schedule plus a 2-sentence bilingual client card (EN/ES).
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why your whole-food bioavailability and fluid replacement strategy is safer and more effective than generic AI supplement advice.
- Part 5: Repository Verification: Confirm archiving in EXW_Professional_AI_Repository / EXW_150_M06_Micronutrient_Hydration_Audit.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Selected Track: Track 1 (#150-06A • Valeria M., Age 21, AWC Cross-Country Runner, Yuma, AZ).

Part 1: Pattern Recognition: Valeria lost $3.0\text{ lbs}$ ($130.0 ightarrow 127.0\text{ lbs} = 2.31\%$ body mass), crossing the $\ge 2\%$ dehydration threshold that reduces stroke volume and increases thermal strain. Drinking only $24\text{ oz}$ post-run leaves at least a $24\text{–}48\text{ oz}$ fluid deficit. Simultaneously, her black iced tea at meals contains polyphenolic tannins that chelate non-heme iron ($\text{Fe}^{3+}$) from her pinto beans and spinach, while her "Energy Booster" pill delivers $150\text{ mg/day}$ of Vitamin $B_6$—exceeding the federal Tolerable Upper Intake Level ($\text{UL} = 100\text{ mg/day}$) and risking peripheral sensory neuropathy.

Part 2: Rule Application (DGA 2025–2030 & Hydration Standards): Under the 2025–2030 Dietary Guidelines for Americans , the adult female RDA for Iron is $18\text{ mg/day}$ (higher turnover in endurance runners) and the Vitamin $B_6$ RDA is $1.3\text{ mg/day}$ ($\text{UL} = 100\text{ mg/day}$). Non-heme iron bioavailability triples when paired with $\ge 75\text{ mg}$ of whole-food Vitamin C and separated from tea/coffee tannins by at least 60 minutes. Acute sweat losses require $16\text{–}24\text{ oz}$ of fluid per pound lost ($3.0\text{ lbs} imes 16\text{–}24\text{ oz} = 48\text{–}72\text{ oz}$).

Part 3: Solving the Gap (Whole-Food & Hydration Plan + Bilingual Card): Discontinue the $150\text{ mg}$ $B_6$ pill and fasting iron tablet immediately. Serve $1\text{ cup}$ of pinto beans and sautéed spinach over corn tortillas topped with fresh pico de gallo and squeezed lime (Vitamin C) plus $3\text{ oz}$ grilled chicken or pumpkin seeds, moving iced tea to 90 minutes between meals. Rehydrate post-run with $60\text{ oz}$ of cool water paired with salted watermelon and avocado toast for natural sodium and potassium. EN Card: "Pair your pinto beans and greens with fresh lime and tomatoes while waiting an hour before drinking iced tea so your body absorbs three times more iron naturally. Drink 60 ounces of water with a salted fruit snack after your 3-pound run loss to restore full hydration." ES Card: "Acompañe sus frijoles pintos y espinacas con limón fresco y jitomate, esperando una hora antes de tomar té helado para triplicar la absorción natural de hierro. Tome 60 onzas de agua con fruta y una pizca de sal después de correr para recuperar las 3 libras de sudor perdidas."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI chatbot often tells fatigued runners to take more iron and B-vitamin energy pills without auditing bioavailability blocks or toxicity ceilings. In Valeria's case, her 150 mg Vitamin B6 supplement already exceeds the 100 mg/day Tolerable Upper Intake Level, risking nerve damage, while her mealtime black tea blocks the plant iron on her plate. By applying the 2025–2030 Dietary Guidelines food-first protocol, we eliminate both the toxic B6 megadose and the nauseating empty-stomach iron pill. Pairing her pinto beans with fresh lime and tomatoes converts ferric iron into absorbable ferrous iron, and replacing her 3-pound Yuma sweat loss with 60 ounces of water and whole-food electrolytes restores plasma volume safely. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."

Part 5: Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M06_Micronutrient_Hydration_Audit.pdf .


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 06 (Mod 06 Lab: Micronutrient & Daily Hydration Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 06 Laboratorio y Simulación: Auditoría de Micronutrientes e Hidratación Diaria

- Parte 1 (Patrón): Calcule el porcentaje de pérdida de peso por sudor o déficit hídrico diario e identifique deficiencias de micronutrientes o excesos sobre el Límite Superior ($\text{UL}$).
- Parte 2 (Regla): Cite las recomendaciones RDA/AI/UL de las Pautas Alimentarias DGA 2025–2030 y la regla de $16\text{–}24\text{ oz}$ por cada libra perdida.
- Parte 3 (Solución): Diseñe un plan de comidas reales e hidratación para el clima de Yuma junto con una tarjeta bilingüe de 2 oraciones (EN/ES).
- Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica por qué su estrategia de biodisponibilidad con alimentos reales e hidratación supera a las pastillas de megadosis.
- Parte 5: Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository / EXW_150_M06_Micronutrient_Hydration_Audit.pdf .
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 06)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
