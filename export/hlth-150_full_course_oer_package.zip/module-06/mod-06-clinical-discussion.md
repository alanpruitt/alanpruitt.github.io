## HLTH-150: Mod 06 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 06) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 06 Discussion: Essential Vitamins, Minerals & Water Intake

Cálculo de Tasas de Sudoración, Pérdida de Masa Corporal y Rehidratación en Climas Extremos


### Individualized Fluid Balance, Mass Loss Audits & Federal Guidelines

In the high-heat environment of the Sonoran Desert (exceeding 105°F / 40.5°C in Yuma County), fluid and electrolyte deficits accumulate rapidly. Blanket hydration recommendations fail because hourly sweat rates vary widely based on body mass, training intensity, and heat acclimatization. Select your Build Your Own Journey Track below, audit a fluid dynamics case file using Google Gemini, and apply federal nutrition standards ( Dietary Guidelines for Americans / PAGA 2018 )!

En el desierto de Sonora, el calor extremo acelera los déficits de líquidos y electrólitos. Las recomendaciones genéricas fallan porque las tasas de sudoración varían drásticamente. Seleccione su ruta profesional, audite un caso real de dinámica de fluidos y aplique las normas federales DGA y PAGA 2018 con el Preceptor de IA Gemini.

- Topic Opens / Apertura del Foro: Tuesday, September 22, 2026, at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday, September 24, 2026, at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 27, 2026, at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday, September 28, 2026, at 11:59 PM MST / Lunes a las 11:59 PM MST
You are warmly encouraged to post in English or Spanish according to your preference. Le animamos a publicar en inglés o en español según su preferencia académica.

To support your clinical sports nutrition skills, instructor evaluations and mathematical fluid audits are posted in this public community forum as well as in Gradebook.


### Phase 1: Select Your Clinical Simulation Case File #150-06 / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Industrial HVAC technician (M.V., 34) presenting with severe uncompensated dehydration, cardiovascular drift, and plasma volume contraction at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[PATIENT INITIALS]: M.V. | [AGE]: 34 | [SEX]: Male | [LOCATION]: Yuma, AZ
[OCCUPATION]: Industrial HVAC Technician working on commercial rooftops in 108°F heat.
[CLINICAL PROFILE]: Reports afternoon dizziness, heart palpitations, elevated heart rate (cardiovascular drift), and dark amber urine (USG > 1.025).
[FLUID METRICS]: Pre-shift weight: 88.0 kg (194.0 lbs); Post-shift weight: 85.2 kg (187.8 lbs); Shift duration: 4.0 hours; Fluid consumed during shift: 1.0 Liter plain water; Urine output: 0.0 Liters.
[CLINICAL ASSESSMENT]: Acute exertional dehydration exceeding 3.18% body mass loss with unreplaced sodium deficit.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Occupational Medicine.
###
```

Focus: Agricultural irrigation supervisor (M.V., 34) addressing crew reliance on high-sugar commercial energy drinks in 110°F summer field conditions in Yuma County.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CLIENT INITIALS]: M.V. | [AGE]: 34 | [SEX]: Male | [LOCATION]: Yuma County, AZ
[OCCUPATION]: Agricultural Irrigation Crew Supervisor managing field workers in 110°F summer heat.
[COMMUNITY CHALLENGE]: Workers consume 3 to 4 high-sugar commercial sports/energy drinks per 5-hour shift (exceeding 120g added sugar), causing gastrointestinal cramps and osmotic diarrhea while failing to replace essential sodium, potassium, and magnesium.
[FLUID METRICS]: Average worker mass loss: 2.5 kg (5.5 lbs) on a 75 kg baseline (3.33% dehydration); Fluid consumed: 1.5 Liters of commercial high-sugar beverages.
[COMMUNITY SITE]: Yuma County Public Health Services District & Agricultural Cooperative.
###
```

Focus: Collegiate endurance runner (M.V., 34) completing a 90-minute tempo run in 102°F heat, experiencing severe late-session pace drop due to acute dehydration.


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[ATHLETE INITIALS]: M.V. | [AGE]: 34 | [SEX]: Male | [LOCATION]: Yuma, AZ
[SPORT]: Distance Runner / Triathlete (AWC Summer Training Fleet)
[TRAINING SESSION]: 90-minute outdoor tempo run (1.5 hours) in 102°F heat and 20% relative humidity.
[METRICS]: Pre-run mass: 70.0 kg (154.3 lbs); Post-run mass: 67.8 kg (149.5 lbs); Fluid consumed during run: 0.6 Liters of water; Urine output: 0.0 Liters.
[PERFORMANCE DEFICIT]: Severe pace deceleration in final 30 minutes, elevated RPE (18/20), and post-run throbbing headache caused by exceeding the 2.0% body weight deficit threshold.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a mathematical fluid and electrolyte audit:


```text
Safety Auditor Protocol: HLTH-150 Hydration & Sweat Rate Preceptor ###:
Role: Academic Sports Nutritionist and Environmental Exercise Physiologist in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA / USDA) & Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Review the candidate case file wrapped in triple-hashes (###) below.
Step 2: PATTERN: Calculate exact acute body mass loss (kg and lbs), percentage of body weight dehydration, total sweat loss volume (Liters), and hourly sweat rate (L/hour).
Step 3: RULE: Apply federal DGA and PAGA standards to evaluate the physiological risks of exceeding the 2.0% body weight loss threshold, emphasizing sodium loss (300 to 600 mg/L) and cardiovascular drift.
Step 4: SOLVE: Detail an acute rehydration prescription replacing 125% to 150% of the net fluid deficit within 4 to 6 hours post-exposure paired with sodium, and provide a 2-sentence bilingual client instruction card (English and Spanish).
Step 5: Maintain all client data wrapped in triple-hash (###) delimiters.

Candidate Data Input ###:
[Paste Your Selected Track Data Block Here]
End Candidate Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Fluid Metrics: State your chosen track and report the client's calculated body mass lost (kg and lbs), percentage dehydration, total sweat volume, and hourly sweat rate in L/hr. Indique la ruta seleccionada y reporte la masa perdida (kg y lb), porcentaje de deshidratación, volumen total y tasa de sudoración en L/h.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit (Pattern / Rule / Solve): Explain why exceeding the 2.0% mass loss threshold causes cardiovascular drift and thermal strain (Pattern), cite DGA/PAGA fluid and sodium replacement rules (Rule), and calculate the exact 125% to 150% rehydration volume in Liters (Solve). Explique el impacto fisiológico de superar el umbral del 2.0% (Patrón), cite las normas DGA/PAGA de sodio y líquidos (Regla) y calcule el volumen de reposición al 125% a 150% en litros (Solución).
- Bilingual Client Instruction Card: Provide a concise 2-sentence explanation of the fluid and sodium rehydration strategy in both English and Spanish so your client can execute it safely in high desert heat. Incluya una explicación concisa de 2 oraciones en inglés y español para educar al cliente sobre la rehidratación adecuada en el calor.

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their mathematical calculations (sweat rate, percent dehydration, 125% to 150% rehydration targets), and discuss how fluid and electrolyte strategies differ between clinical, agricultural, and athletic environments in Yuma.

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Evalúe sus cálculos de sudoración y compare las estrategias de hidratación entre el ámbito clínico, agrícola y deportivo.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Track & Calculated Fluid Metrics: Track 3 Sports Performance. Mass Loss: 70.0 kg - 67.8 kg = 2.2 kg lost (4.85 lbs) . Percent Dehydration: (2.2 kg / 70.0 kg) * 100 = 3.14% body weight deficit . Total Sweat Volume: 2.2 kg mass loss + 0.6 L intake = 2.80 Liters total sweat loss . Hourly Sweat Rate: 2.80 L / 1.5 hours = 1.87 L/hour (approx. 63 oz/hour) . Ruta 3 Rendimiento Deportivo. Masa perdida: 2.2 kg (3.14% de deshidratación). Pérdida total de sudor: 2.80 L. Tasa horaria de sudoración: 1.87 L/hora.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit: Pattern (Cardiovascular Drift & Hypovolemia): Exceeding the 2.0% dehydration threshold contracts blood plasma volume, reducing stroke volume. To maintain cardiac output and evaporative sweat cooling in 102°F heat, the heart must beat faster (cardiovascular drift). Peripheral blood flow is compromised, causing rapid pace decline, headache, and severe fatigue. Rule (DGA & PAGA Standards): Federal guidelines mandate that body mass loss must be limited to less than 2.0% during exercise. For exercise in high heat lasting >60 minutes, fluid replacement must include 300 to 600 mg sodium per Liter to maintain osmotic balance and retain consumed fluids. Solve (Acute Rehydration Protocol): Replace 125% to 150% of the 2.2 kg deficit over the next 4 to 6 hours: 2.2 * 1.25 to 1.50 = 2.75 to 3.30 Liters of fluid paired with 1,400 to 1,800 mg sodium (using electrolyte beverages and whole foods like pretzels and chicken broth). For future runs, target 800 to 1,000 mL/hr fluid intake. Patrón: La deshidratación del 3.14% reduce el volumen de plasma y eleva la FC. Regla: PAGA/DGA exige limitar la pérdida a <2.0% y reponer 300 a 600 mg Na/L. Solución: Reponer de 2.75 a 3.30 L con sodio en 4 a 6 horas.
- Bilingual Client Handout Card: EN: "You lost over 3% of your body weight, which caused your severe fatigue and headache. Drink 3 Liters of fluid mixed with electrolytes over the next 5 hours and eat a salted snack to fully rehydrate." ES: "Usted perdió más del 3% de su peso corporal, lo que causó su fatiga y dolor de cabeza. Beba 3 litros de agua con electrólitos durante las próximas 5 horas y consuma un refrigerio salado para rehidratarse."

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 06 (Mod 06 Discussion: Essential Vitamins, Minerals & Water Intake)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 06 Foro de Discusión: Tasas de Sudoración y Dinámica de Hidratación

Analice el caso del cliente M.V. utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) según la ruta profesional seleccionada y envíe sus respuestas en Canvas.

- Apertura del Foro: Martes, 22 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 24 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 27 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 28 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta Seleccionada y Métricas de Fluidos: Indique su ruta seleccionada, masa corporal perdida (kg y lb), porcentaje de deshidratación, volumen total y tasa de sudoración en L/hora.
- Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Explique por qué superar el umbral del 2.0% compromete el rendimiento y eleva la frecuencia cardíaca (Patrón), cite las pautas DGA/PAGA sobre reposición de sodio (300 a 600 mg/L) y líquidos (Regla), y calcule el volumen exacto de rehidratación al 125% a 150% (Solución).
- Tarjeta de Instrucción Bilingüe: Incluya una explicación concisa de 2 oraciones en inglés y español sobre el plan de rehidratación con electrólitos para climas desérticos.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 06)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
