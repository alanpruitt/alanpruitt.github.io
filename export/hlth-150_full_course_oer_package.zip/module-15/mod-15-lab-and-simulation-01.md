# HLTH-150: Mod 15 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 15 Coaching Sprint Simulation: Nutrition Scope of Practice & Ethics

- Nutrition Scope of Practice (General DGA Coaching vs. Medical Nutrition Therapy): Fitness and wellness coaches educate clients on DGA 2025–2030 whole-food habits and hydration, while only a Registered Dietitian (RD/RDN) provides Medical Nutrition Therapy (MNT) for disease. En palabras sencillas: Como entrenadores enseñamos hábitos de comida real e hidratación (DGA 2025–2030), pero las dietas médicas para enfermedades las prescribe un Nutriólogo Clínico Certificado (RD).
- Cultural & Economic Food Security (Yuma / Imperial Valley Grocery Reality): Designing affordable, culturally familiar meal plans using regional staples (pinto beans, lentils, seasonal produce, eggs, corn tortillas, canned tuna/sardines) rather than costly specialty items. En palabras sencillas: Armar planes económicos con alimentos de nuestra región (frijol pinto, lentejas, huevo, tortilla de maíz, atún y fruta de temporada) que sí se ajusten al bolsillo familiar.
- Four-Step Dietary Audit Verification: Cross-checking TDEE math, AMDR percentages, added-sugar caps (<10%), and Yuma fluid/electrolyte targets before delivering a client nutrition plan. En palabras sencillas: Revisar calorías, porcentajes de macronutrientes, límite de azúcar (<10%) e hidratación antes de entregar cualquier guía al cliente.

### Coach Alan's Final Check-In: Outstanding Work & Happy Thanksgiving

Team, you have reached the finish line of HLTH-150! Over the past fifteen weeks, you transformed complex nutritional biochemistry and federal dietary guidelines into practical, professional competencies across clinical, community, and athletic settings.

As you assemble your final career portfolios and complete your final audits, please remember to enjoy the Thanksgiving Holiday on November 26 and 27 . Take time to rest, connect with family, and celebrate your incredible academic achievements. I am immensely proud of every single one of you!


### Module 15 Tactical Roadmap / Ruta Táctica del Módulo 15

- Step 1: Required Readings: Master professional ethics, legal scope of practice, and portfolio assembly.
- Step 2: Discussion Showcase: Share your final career portfolio and reply to peers by Sunday, November 29 at 11:59 PM MST.
- Step 3: Final Lab Audit: Complete your comprehensive final practical audit and submit by Monday, November 30 at 11:59 PM MST.
- Step 4: Semester Completion: Celebrate the successful culmination of HLTH-150!
Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Master Class Clinical Triage & Nutrition Scope-of-Practice Auditor (/simulators/master-class-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate the ethical and legal boundary between DGA 2025–2030 real-food wellness coaching (within scope) and Medical Nutrition Therapy / clinical eating-disorder diagnosis (mandatory RDN/MD referral gate). Copy your VERIFIED simulator receipt or slider values into the submission template below.

Open Master Class Clinical Triage & Nutrition Scope-of-Practice Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/master-class-auditor y "PAGA"): Calibre el límite ético y legal entre la educación nutricional con alimentos reales (DGA 2025–2030, dentro de su alcance) y la Terapia Médica Nutricional (referencia obligatoria al RDN/médico). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### The Coach's Playbook: Three Professional Principles to Carry Forward

Always distinguish general wellness coaching from Medical Nutrition Therapy (MNT), maintaining an active interdisciplinary referral network.

Prioritize peer-reviewed evidence and federal standards (PAGA 2018 / DGA) over commercial fad diets and sensationalized wellness trends.

Stay curious, maintain rigorous AI tool literacy with secure data delimiters (###), and serve as a trusted health advocate in your community.


### AI Study Coach • Final Semester Review

Want a final 60-second review prompt before submitting your portfolio? Copy this prompt into Gemini:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Final Portfolio Synthesis ###:
Role: Clinical Sports Nutritionist and Academic Mentor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Generate an encouraging final summary celebrating the student's mastery across bioenergetics, macronutrients, hydration, timing, ergogenic aids, energy balance, and lifespan nutrition.
Step 2: Review the core tenets of the Clinical Framing Protocol (Pattern / Rule / Solve) and AI safety auditing (###).
Step 3: Provide an inspiring closing statement for future exercise science professionals.
End Review Master Protocol ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 15 (Mod 15 Coaching Sprint: Nutrition Scope of Practice & Ethics)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 15 Sprint de Entrenamiento: Portafolio Final y Celebración


### Mensaje Final del Entrenador Alan: Excelente Trabajo y Feliz Acción de Gracias

¡Equipo, han llegado a la meta de HLTH-150! Durante las últimas quince semanas, transformaron la bioquímica nutricional y las pautas federales en competencias profesionales prácticas en entornos clínicos, comunitarios y deportivos.

Mientras ensamblan sus portafolios y completan sus auditorías finales, recuerden disfrutar del receso de Acción de Gracias el 26 y 27 de noviembre . Tómense el tiempo para descansar, conectar con su familia y celebrar sus increíbles logros académicos. ¡Estoy inmensamente orgulloso de todos ustedes!


### Ruta Táctica del Módulo 15

- Step 1: Lecturas Obligatorias: Dominar la ética profesional, el ámbito de práctica y el ensamblaje del portafolio.
- Step 2: Presentación en el Foro: Compartir su portafolio y responder a compañeros antes del domingo 29 de noviembre a las 11:59 PM MST.
- Step 3: Auditoría de Laboratorio Final: Completar la auditoría práctica final y entregar antes del lunes 30 de noviembre a las 11:59 PM MST.
- Step 4: Culminación del Semestre: ¡Celebrar la exitosa finalización de HLTH-150!

### Estrategia del Entrenador: Tres Principios Profesionales a Futuro

Distinguir siempre el entrenamiento general de la Terapia Nutricional Médica (MNT), manteniendo una red activa de derivación.

Priorizar la evidencia científica y normas federales (PAGA 2018 / DGA) sobre dietas de moda y tendencias de redes sociales.

Mantener la curiosidad, dominar las herramientas de IA con delimitadores seguros (###) y servir como educador de salud confiable.


### Entrenador de Estudio con IA • Repaso Final

¿Desea un resumen final de 60 segundos antes de enviar su portafolio? Copie este prompt en Gemini:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Review Master Protocol: HLTH-150 Final Portfolio Synthesis ###:
Rol: Nutriologo Deportivo Clinico y Mentor Academico en la voz del Narrator.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Generar un resumen final alentador celebrando el dominio del estudiante en bioenergetica, macronutrientes, hidratacion, sincronizacion, ergogenicos, balance energetico y nutricion vital.
Step 2: Revisar los principios del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patron / Regla / Solucion) y auditoria de IA (###).
Step 3: Proporcionar una declaración de cierre inspiradora para futuros profesionales.
Fin del Protocolo Review Master ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
