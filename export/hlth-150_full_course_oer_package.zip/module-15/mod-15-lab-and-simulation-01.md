## HLTH-150: Mod 15 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 15) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 15 Coaching Sprint Simulation: Nutrition Scope of Practice & Ethics

- Nutrition Scope of Practice (General DGA Coaching vs. Medical Nutrition Therapy): Fitness and wellness coaches educate clients on DGA 2025–2030 whole-food habits and hydration, while only a Registered Dietitian (RD/RDN) provides Medical Nutrition Therapy (MNT) for disease. En palabras sencillas: Como entrenadores enseñamos hábitos de comida real e hidratación (DGA 2025–2030), pero las dietas médicas para enfermedades las prescribe un Nutriólogo Clínico Certificado (RD).
- Cultural & Economic Food Security (Yuma / Imperial Valley Grocery Reality): Designing affordable, culturally familiar meal plans using regional staples (pinto beans, lentils, seasonal produce, eggs, corn tortillas, canned tuna/sardines) rather than costly specialty items. En palabras sencillas: Armar planes económicos con alimentos de nuestra región (frijol pinto, lentejas, huevo, tortilla de maíz, atún y fruta de temporada) que sí se ajusten al bolsillo familiar.
- Four-Step Dietary Audit Verification: Cross-checking TDEE math, AMDR percentages, added-sugar caps (<10%), and Yuma fluid/electrolyte targets before delivering a client nutrition plan. En palabras sencillas: Revisar calorías, porcentajes de macronutrientes, límite de azúcar (<10%) e hidratación antes de entregar cualquier guía al cliente.

### Coach Alan's Final Check-In: Outstanding Work & Happy Thanksgiving

Team, you have reached the finish line of HLTH-150! Over the past fifteen weeks, you transformed complex nutritional biochemistry and federal dietary guidelines into practical, professional competencies across clinical, community, and athletic settings.

As you assemble your final career portfolios and complete your final audits, please remember to enjoy the Thanksgiving Holiday on November 26 and 27 . Take time to rest, connect with family, and celebrate your incredible academic achievements. I am immensely proud of every single one of you!


### Module 15 Tactical Roadmap / Ruta Táctica del Módulo 15

- Step 1: Required Readings: Master professional ethics, legal scope of practice, and portfolio assembly.
- Step 2: Discussion Showcase: Share your final career portfolio and reply to peers by Sunday, November 29 at 11:59 PM MST.
- Step 3: Final Lab Audit: Complete your comprehensive final practical audit and submit by Monday, November 30 at 11:59 PM MST.
- Step 4: Semester Completion: Celebrate the successful culmination of HLTH-150!
Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Master Class Clinical Triage & Nutrition Scope-of-Practice Auditor (/simulators/master-class-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate the ethical and legal boundary between DGA 2025–2030 real-food wellness coaching (within scope) and Medical Nutrition Therapy / clinical eating-disorder diagnosis (mandatory RDN/MD referral gate). Copy your VERIFIED simulator receipt or slider values into the submission template below.

Open Master Class Clinical Triage & Nutrition Scope-of-Practice Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/master-class-auditor y "PAGA"): Calibre el límite ético y legal entre la educación nutricional con alimentos reales (DGA 2025–2030, dentro de su alcance) y la Terapia Médica Nutricional (referencia obligatoria al RDN/médico). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### The Coach's Playbook: Three Professional Principles to Carry Forward

Always distinguish general wellness coaching from Medical Nutrition Therapy (MNT), maintaining an active interdisciplinary referral network.

Prioritize peer-reviewed evidence and federal standards (PAGA 2018 / DGA) over commercial fad diets and sensationalized wellness trends.

Stay curious, maintain rigorous AI tool literacy with secure data delimiters (###), and serve as a trusted health advocate in your community.


### AI Study Coach • Final Semester Review

Want a final 60-second review prompt before submitting your portfolio? Copy this prompt into Gemini:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Final Portfolio Synthesis ###:
Role: Clinical Sports Nutritionist and Academic Mentor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Generate an encouraging final summary celebrating the student's mastery across bioenergetics, macronutrients, hydration, timing, ergogenic aids, energy balance, and lifespan nutrition.
Step 2: Review the core tenets of the Clinical Framing Protocol (Pattern / Rule / Solve) and AI safety auditing (###).
Step 3: Provide an inspiring closing statement for future exercise science professionals.
End Review Master Protocol ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 15 (Mod 15 Coaching Sprint: Nutrition Scope of Practice & Ethics)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 15 Sprint de Entrenamiento: Portafolio Final y Celebración


### Mensaje Final del Entrenador Alan: Excelente Trabajo y Feliz Acción de Gracias

¡Equipo, han llegado a la meta de HLTH-150! Durante las últimas quince semanas, transformaron la bioquímica nutricional y las pautas federales en competencias profesionales prácticas en entornos clínicos, comunitarios y deportivos.

Mientras ensamblan sus portafolios y completan sus auditorías finales, recuerden disfrutar del receso de Acción de Gracias el 26 y 27 de noviembre . Tómense el tiempo para descansar, conectar con su familia y celebrar sus increíbles logros académicos. ¡Estoy inmensamente orgulloso de todos ustedes!


### Ruta Táctica del Módulo 15

- Step 1: Lecturas Obligatorias: Dominar la ética profesional, el ámbito de práctica y el ensamblaje del portafolio.
- Step 2: Presentación en el Foro: Compartir su portafolio y responder a compañeros antes del domingo 29 de noviembre a las 11:59 PM MST.
- Step 3: Auditoría de Laboratorio Final: Completar la auditoría práctica final y entregar antes del lunes 30 de noviembre a las 11:59 PM MST.
- Step 4: Culminación del Semestre: ¡Celebrar la exitosa finalización de HLTH-150!

### Estrategia del Entrenador: Tres Principios Profesionales a Futuro

Distinguir siempre el entrenamiento general de la Terapia Nutricional Médica (MNT), manteniendo una red activa de derivación.

Priorizar la evidencia científica y normas federales (PAGA 2018 / DGA) sobre dietas de moda y tendencias de redes sociales.

Mantener la curiosidad, dominar las herramientas de IA con delimitadores seguros (###) y servir como educador de salud confiable.


### Entrenador de Estudio con IA • Repaso Final

¿Desea un resumen final de 60 segundos antes de enviar su portafolio? Copie este prompt en Gemini:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Review Master Protocol: HLTH-150 Final Portfolio Synthesis ###:
Rol: Nutriologo Deportivo Clinico y Mentor Academico en la voz del Narrator.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Generar un resumen final alentador celebrando el dominio del estudiante en bioenergetica, macronutrientes, hidratacion, sincronizacion, ergogenicos, balance energetico y nutricion vital.
Step 2: Revisar los principios del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patron / Regla / Solucion) y auditoria de IA (###).
Step 3: Proporcionar una declaración de cierre inspiradora para futuros profesionales.
Fin del Protocolo Review Master ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 15)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 15)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
