# HLTH-150: Mod 15 Overview Nutrition Scope Of Practice And Complete Client Planning

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 15 Overview: Nutrition Scope of Practice & Complete Client Planning

El Porqué del Módulo 15 (Círculo Dorado — Contexto Norteño): “¿Por qué todo entrenador debe conocer la línea exacta entre la orientación nutricional y la terapia médica, y cómo ese límite ético protege la seguridad del cliente?”


### Module 15 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 15: Nutrition Scope of Practice & Complete Client Planning

Welcome to Week 15, the culmination of our semester journey in HLTH-150! Building upon our study of lifespan nutrition, this final Module centers on synthesizing your learning into a Comprehensive Career Portfolio . Whether your professional pathway lies in clinical rehabilitation, community public health, or athletic performance coaching, this portfolio showcases your mastery of the Clinical Framing Protocol (Pattern / Rule / Solve), the federal Single Sources of Truth (PAGA 2018 and DGA), and AI-driven clinical auditing.

Important Holiday Notice: Arizona Western College observes the Thanksgiving Holiday on Thursday, November 26, and Friday, November 27, 2026 . Campus offices are closed, and no classes are scheduled. Adjusted deadlines ensure you have ample time to celebrate and rest.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will consolidate your semester case files, reflect on your chosen career track, and prepare for professional practice.


### Weekly Schedule & Adjusted Thanksgiving Deadlines / Horario y Fechas Límite

- Module Opens / Apertura: Tuesday, November 24, 2026, at 12:00 AM MST
- Thanksgiving Holiday Closure: Thursday, November 26 & Friday, November 27, 2026 (Campus Closed)
- Final Portfolio Initial Post: Friday, November 27, 2026, at 11:59 PM MST (Adjusted for holiday flexibility)
- Final Portfolio Peer Replies: Sunday, November 29, 2026, at 11:59 PM MST
- Final Lab & Course Wrap-Up Due: Monday, November 30, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 15 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Synthesize semester-long case studies and evaluate how sports nutrition principles apply across clinical, community, and athletic domains. Sintetizar estudios de caso semestrales y evaluar la aplicación práctica de los principios de nutrición deportiva.
- CLO 2 (Rule Application): Integrate federal PAGA 2018 and DGA standards with professional ethics, scope of practice, and AI safety auditing protocols. Integrar las normas federales de PAGA 2018 y DGA con la ética profesional y protocolos de auditoría de IA.
- CLO 3 (Problem Solving): Assemble a professional career portfolio showcasing evidence-based prescriptions ready for real-world health and exercise settings. Ensamblar un portafolio profesional que demuestre prescripciones basadas en evidencia listas para el entorno laboral real.

### Build Your Own Journey • Career Portfolio Pathways

Your final portfolio reflects your chosen professional pathway throughout the semester:

Compiling clinical case audits, rehabilitation protein pacing, diuretic hydration protocols, and sarcopenia prevention plans.

Compiling budget-friendly whole-food nutrition plans, OSHA heat safety protocols, and community wellness initiatives in Yuma County.

Compiling strength athlete protein pacing, sweat rate biometrics, nutrient timing windows, and NSF-certified supplement audits.


### Module 15 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Professional Ethics, Scope of Practice & Career Portfolios
- Discussion Board: Final Career Portfolio Showcase & Peer Reflection
- Lab Assignment: Comprehensive Final Practical Audit & Gemini AI Tool Kit
- Course Wrap-Up & Semester Completion
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 15 (Mod 15 Overview: Nutrition Scope of Practice & Complete Client Planning)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 15 Visión General: Portafolio Profesional Final


### Bienvenido al Módulo 15: Síntesis del Curso, Portafolios y Vacaciones de Acción de Gracias

¡Bienvenido a la Semana 15, la culminación de nuestro semestre en HLTH-150! Este módulo final se centra en sintetizar su aprendizaje en un Portafolio Profesional Integral . Ya sea en rehabilitación clínica, salud pública o acondicionamiento deportivo, este portafolio demuestra su dominio del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y las normas federales (PAGA 2018 y DGA).

Aviso Importante de Vacaciones: Tenga en cuenta que Arizona Western College observa el receso de Acción de Gracias el jueves 26 y viernes 27 de noviembre de 2026 . Las oficinas del campus estarán cerradas y no hay clases programadas. Las fechas límite se han ajustado para dar flexibilidad.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , consolidará sus estudios de caso y se preparará para la práctica profesional.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Sintetizar estudios de caso semestrales y evaluar la aplicación práctica de los principios de nutrición deportiva.
- CLO 2 (Regla): Integrar las normas federales de PAGA 2018 y DGA con la ética profesional y protocolos de auditoría de IA.
- CLO 3 (Solución): Ensamblar un portafolio profesional que demuestre prescripciones basadas en evidencia listas para el entorno laboral real.

### Construya su Propio Camino • Portafolios Profesionales

Su portafolio final refleja la ruta profesional seleccionada durante el semestre:

Compilación de auditorías clínicas, pacing proteico de rehabilitación, protocolos de hidratación y planes contra la sarcopenia.

Compilación de planes de nutrición con alimentos económicos, protocolos OSHA de calor y bienestar comunitario en Yuma.

Compilación de pacing proteico para atletas de fuerza, biometría de sudoración, ventanas de sincronización y auditorías NSF.


### Ruta de Aprendizaje del Módulo 15

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Ética Profesional, Ámbito de Práctica y Portafolios de Carrera
- Foro de Discusión: Presentación del Portafolio Profesional Final y Reflexión
- Práctica de Laboratorio: Auditoría Práctica Final Integral y Caja de Herramientas
- Conclusión del Curso y Finalización del Semestre

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA. Esta estructura es responsiva en dispositivos móviles, compatible con lectores de pantalla y diseñada para un acceso equitativo.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 15 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 15 Required Readings: Nutrition Scope of Practice & Complete Client Planning →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 15 Discussion: Sharing Your Nutrition Coaching Portfolio →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 15 Coaching Sprint: Nutrition Scope of Practice & Ethics →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 15 Lab: Complete Client Nutrition Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 15 Summary & Wrap-Up: Nutrition Scope of Practice & Complete Client Planning →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
