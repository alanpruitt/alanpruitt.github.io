## HLTH-150: Mod 15 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 15) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 15 Discussion: Sharing Your Nutrition Coaching Portfolio

- Nutrition Scope of Practice (General DGA Coaching vs. Medical Nutrition Therapy): Fitness and wellness coaches educate clients on DGA 2025–2030 whole-food habits and hydration, while only a Registered Dietitian (RD/RDN) provides Medical Nutrition Therapy (MNT) for disease. En palabras sencillas: Como entrenadores enseñamos hábitos de comida real e hidratación (DGA 2025–2030), pero las dietas médicas para enfermedades las prescribe un Nutriólogo Clínico Certificado (RD).
- Cultural & Economic Food Security (Yuma / Imperial Valley Grocery Reality): Designing affordable, culturally familiar meal plans using regional staples (pinto beans, lentils, seasonal produce, eggs, corn tortillas, canned tuna/sardines) rather than costly specialty items. En palabras sencillas: Armar planes económicos con alimentos de nuestra región (frijol pinto, lentejas, huevo, tortilla de maíz, atún y fruta de temporada) que sí se ajusten al bolsillo familiar.
- Four-Step Dietary Audit Verification: Cross-checking TDEE math, AMDR percentages, added-sugar caps (<10%), and Yuma fluid/electrolyte targets before delivering a client nutrition plan. En palabras sencillas: Revisar calorías, porcentajes de macronutrientes, límite de azúcar (<10%) e hidratación antes de entregar cualquier guía al cliente.

### Sharing Semester Artifacts, Career Track Highlights & Thanksgiving Reflection

Welcome to our final Discussion board! This semester, you mastered energy systems, macronutrient biology, hydration kinetics, nutrient timing, ergogenic audits, energy balance, and lifespan nutrition using the Clinical Framing Protocol (Pattern / Rule / Solve) framework and federal SSoT standards. For this final showcase, share highlights from your professional portfolio, reflect on your chosen career track, and celebrate your growth alongside classmates. Review the adjusted Thanksgiving holiday deadlines below and share your insights!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Thanksgiving Holiday Closure: Thursday, Nov 26 & Friday, Nov 27 (Campus Closed)
- Initial Post Due / Publicación Inicial: Friday, November 27 at 11:59 PM MST (Holiday flexibility) / Viernes a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday, November 29 at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday, November 30 at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Final Portfolio Showcase Case File #150-15

Choose ONE of the three career-aligned tracks below to summarize in your final portfolio showcase:

Focus: Summarizing clinical case audits, protein pacing for sarcopenia, cardiac rehab hydration, and interdisciplinary referral standards.

Focus: Summarizing community nutrition programs in Yuma County, agricultural heat safety protocols, and budget-friendly whole-food plans.

Focus: Summarizing strength athlete protein pacing, sweat rate biometrics, nutrient timing windows, and NSF supplement safety audits.


### Phase 2: AI Portfolio Synthesis & Reflection Prompt


### Discussion Tasks / Tareas de Discusión (Due Friday, Nov 27 / Viernes 11:59 PM MST):

- Career Track Selection & Key Artifact / Ruta y Artefacto Clave: State your chosen career track and share your favorite artifact or lab audit from the semester. Indique su ruta profesional y comparta su artefacto favorito o auditoría de laboratorio del semestre.
- Clinical Framing Protocol (Pattern / Rule / Solve) & SSoT Reflection / Reflexión del Ciclo y SSoT: Explain how applying the Clinical Framing Protocol (Pattern / Rule / Solve) and federal SSoT standards (PAGA 2018 / DGA) shaped your professional growth. Explique cómo la aplicación del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y las normas SSoT moldearon su crecimiento profesional.
- Bilingual Professional Statement / Declaración Profesional Bilingüe: Provide a concise 2-sentence professional statement summarizing your nutrition philosophy in both English and Spanish. Proporcione una declaración profesional concisa de 2 oraciones resumiendo su filosofía en inglés y español.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday, November 29 at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Celebrate their semester achievements, compare portfolio insights, and wish them a wonderful Thanksgiving weekend.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Portfolio Highlight & Clinical Framing Protocol (Pattern / Rule / Solve) Synthesis: Throughout HLTH-150, I specialized in Track 3 (Sports Performance). My favorite artifact is the Module 7 Protein Pacing and Leucine Trigger Audit for athlete D.K. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, I learned to identify flawed meal-distribution patterns, apply ACSM and PAGA 2018 dosing rules (0.30 to 0.40 g/kg per meal), and solve performance bottlenecks with whole-food pacing.

Professional Growth & AI Governance: Integrating the Gemini AI Tool Kit with secure triple-hash delimiters taught me the importance of data isolation and clinical auditing. I am proud to graduate with a robust toolkit ready to support athletic excellence across Arizona.

EN: "As a sports nutrition practitioner, I am committed to advancing athletic performance through evidence-based federal standards and whole-food fueling strategies."

ES: "Como profesional en nutrición deportiva, me comprometo a impulsar el rendimiento atlético mediante normas federales basadas en evidencia y estrategias de alimentación."

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 15 (Mod 15 Discussion: Sharing Your Nutrition Coaching Portfolio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 15 Foro de Discusión: Presentación del Portafolio Profesional


### Compartiendo Artefactos Semestrales, Destacados y Reflexión de Acción de Gracias

¡Bienvenidos a nuestro foro de discusión final! A lo largo del semestre, ustedes han dominado sistemas energéticos, macronutrientes, hidratación, sincronización, ergogénicos, balance energético y nutrición vital usando el Protocolo de Encuadre Clínico (Patrón / Regla / Solución). Para esta presentación, compartan sus aspectos destacados del portafolio y celebren su crecimiento. ¡Revisen las fechas límite ajustadas por Acción de Gracias y compartan sus ideas!


### Estructura de Entrega para el Foro


#### Parte 1: Selección de Ruta y Artefacto Clave

Indique su ruta profesional y comparta su artefacto favorito o auditoría de laboratorio del semestre.


#### Parte 2: Reflexión del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y SSoT

Explique cómo la aplicación del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) y las normas SSoT moldearon su crecimiento profesional.


#### Parte 3: Declaración Profesional Bilingüe

Proporcione una declaración profesional concisa de 2 oraciones resumiendo su filosofía nutricional en inglés y español.


### Modelo de Respuesta de Alta Fidelidad 10/10

Durante HLTH-150, me especialicé en la Ruta 3 (Rendimiento Deportivo). Mi artefacto favorito es la auditoría de pacing proteico del Módulo 7. Usando el Protocolo de Encuadre Clínico (Patrón / Regla / Solución), aprendí a identificar patrones de distribución defectuosos, aplicar reglas de dosificación ACSM y PAGA 2018, y resolver cuellos de botella con alimentos integrales.

EN: "As a sports nutrition practitioner, I am committed to advancing athletic performance through evidence-based federal standards and whole-food fueling strategies." ES: "Como profesional en nutrición deportiva, me comprometo a impulsar el rendimiento atlético mediante normas federales basadas en evidencia y estrategias de alimentación."

HLTH-150 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 15)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 15)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
