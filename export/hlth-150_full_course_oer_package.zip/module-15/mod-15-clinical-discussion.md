# HLTH-150: Mod 15 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 15 Discussion: Sharing Your Nutrition Coaching Portfolio

- Nutrition Scope of Practice (General DGA Coaching vs. Medical Nutrition Therapy): Fitness and wellness coaches educate clients on DGA 2025–2030 whole-food habits and hydration, while only a Registered Dietitian (RD/RDN) provides Medical Nutrition Therapy (MNT) for disease. En palabras sencillas: Como entrenadores enseñamos hábitos de comida real e hidratación (DGA 2025–2030), pero las dietas médicas para enfermedades las prescribe un Nutriólogo Clínico Certificado (RD).
- Cultural & Economic Food Security (Yuma / Imperial Valley Grocery Reality): Designing affordable, culturally familiar meal plans using regional staples (pinto beans, lentils, seasonal produce, eggs, corn tortillas, canned tuna/sardines) rather than costly specialty items. En palabras sencillas: Armar planes económicos con alimentos de nuestra región (frijol pinto, lentejas, huevo, tortilla de maíz, atún y fruta de temporada) que sí se ajusten al bolsillo familiar.
- Four-Step Dietary Audit Verification: Cross-checking TDEE math, AMDR percentages, added-sugar caps (<10%), and Yuma fluid/electrolyte targets before delivering a client nutrition plan. En palabras sencillas: Revisar calorías, porcentajes de macronutrientes, límite de azúcar (<10%) e hidratación antes de entregar cualquier guía al cliente.

### Sharing Semester Artifacts, Career Track Highlights & Thanksgiving Reflection

Welcome to our final Discussion board! This semester, you mastered energy systems, macronutrient biology, hydration kinetics, nutrient timing, ergogenic audits, energy balance, and lifespan nutrition using the Clinical Framing Protocol (Pattern / Rule / Solve) framework and federal SSoT standards. For this final showcase, share highlights from your professional portfolio, reflect on your chosen career track, and celebrate your growth alongside classmates. Review the adjusted Thanksgiving holiday deadlines below and share your insights!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Thanksgiving Holiday Closure: Thursday, Nov 26 & Friday, Nov 27 (Campus Closed)
- Initial Post Due / Publicación Inicial: Friday, November 27 at 11:59 PM MST (Holiday flexibility) / Viernes a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday, November 29 at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday, November 30 at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Final Portfolio Showcase Case File #150-15

Choose ONE of the three career-aligned tracks below to summarize in your final portfolio showcase:

Focus: Summarizing clinical case audits, protein pacing for sarcopenia, cardiac rehab hydration, and interdisciplinary referral standards.

Focus: Summarizing community nutrition programs in Yuma County, agricultural heat safety protocols, and budget-friendly whole-food plans.

Focus: Summarizing strength athlete protein pacing, sweat rate biometrics, nutrient timing windows, and NSF supplement safety audits.


### Phase 2: AI Portfolio Synthesis & Reflection Prompt


### Discussion Tasks / Tareas de Discusión (Due Friday, Nov 27 / Viernes 11:59 PM MST):

- Career Track Selection & Key Artifact / Ruta y Artefacto Clave: State your chosen career track and share your favorite artifact or lab audit from the semester. Indique su ruta profesional y comparta su artefacto favorito o auditoría de laboratorio del semestre.
- Clinical Framing Protocol (Pattern / Rule / Solve) & SSoT Reflection / Reflexión del Ciclo y SSoT: Explain how applying the Clinical Framing Protocol (Pattern / Rule / Solve) and federal SSoT standards (PAGA 2018 / DGA) shaped your professional growth. Explique cómo la aplicación del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y las normas SSoT moldearon su crecimiento profesional.
- Bilingual Professional Statement / Declaración Profesional Bilingüe: Provide a concise 2-sentence professional statement summarizing your nutrition philosophy in both English and Spanish. Proporcione una declaración profesional concisa de 2 oraciones resumiendo su filosofía en inglés y español.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday, November 29 at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Celebrate their semester achievements, compare portfolio insights, and wish them a wonderful Thanksgiving weekend.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Portfolio Highlight & Clinical Framing Protocol (Pattern / Rule / Solve) Synthesis: Throughout HLTH-150, I specialized in Track 3 (Sports Performance). My favorite artifact is the Module 7 Protein Pacing and Leucine Trigger Audit for athlete D.K. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, I learned to identify flawed meal-distribution patterns, apply ACSM and PAGA 2018 dosing rules (0.30 to 0.40 g/kg per meal), and solve performance bottlenecks with whole-food pacing.

Professional Growth & AI Governance: Integrating the Gemini AI Tool Kit with secure triple-hash delimiters taught me the importance of data isolation and clinical auditing. I am proud to graduate with a robust toolkit ready to support athletic excellence across Arizona.

EN: "As a sports nutrition practitioner, I am committed to advancing athletic performance through evidence-based federal standards and whole-food fueling strategies."

ES: "Como profesional en nutrición deportiva, me comprometo a impulsar el rendimiento atlético mediante normas federales basadas en evidencia y estrategias de alimentación."

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 15 (Mod 15 Discussion: Sharing Your Nutrition Coaching Portfolio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 15 Foro de Discusión: Presentación del Portafolio Profesional


### Compartiendo Artefactos Semestrales, Destacados y Reflexión de Acción de Gracias

¡Bienvenidos a nuestro foro de discusión final! A lo largo del semestre, ustedes han dominado sistemas energéticos, macronutrientes, hidratación, sincronización, ergogénicos, balance energético y nutrición vital usando el Protocolo de Encuadre Clínico (Patrón / Regla / Solución). Para esta presentación, compartan sus aspectos destacados del portafolio y celebren su crecimiento. ¡Revisen las fechas límite ajustadas por Acción de Gracias y compartan sus ideas!


### Estructura de Entrega para el Foro


#### Parte 1: Selección de Ruta y Artefacto Clave

Indique su ruta profesional y comparta su artefacto favorito o auditoría de laboratorio del semestre.


#### Parte 2: Reflexión del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y SSoT

Explique cómo la aplicación del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) y las normas SSoT moldearon su crecimiento profesional.


#### Parte 3: Declaración Profesional Bilingüe

Proporcione una declaración profesional concisa de 2 oraciones resumiendo su filosofía nutricional en inglés y español.


### Modelo de Respuesta de Alta Fidelidad 10/10

Durante HLTH-150, me especialicé en la Ruta 3 (Rendimiento Deportivo). Mi artefacto favorito es la auditoría de pacing proteico del Módulo 7. Usando el Protocolo de Encuadre Clínico (Patrón / Regla / Solución), aprendí a identificar patrones de distribución defectuosos, aplicar reglas de dosificación ACSM y PAGA 2018, y resolver cuellos de botella con alimentos integrales.

EN: "As a sports nutrition practitioner, I am committed to advancing athletic performance through evidence-based federal standards and whole-food fueling strategies." ES: "Como profesional en nutrición deportiva, me comprometo a impulsar el rendimiento atlético mediante normas federales basadas en evidencia y estrategias de alimentación."

HLTH-150 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
