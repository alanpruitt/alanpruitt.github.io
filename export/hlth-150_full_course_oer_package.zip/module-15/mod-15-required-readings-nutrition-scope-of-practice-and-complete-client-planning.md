# HLTH-150: Mod 15 Required Readings Nutrition Scope Of Practice And Complete Client Planning

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 15 Required Readings: Nutrition Scope of Practice & Complete Client Planning

Lecturas Obligatorias: Ética Profesional, Ámbito de Práctica y Portafolios

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from 2025–2030 Dietary Guidelines for Americans (Real-Food Focus) & PAGA 2018), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 15): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Nutrition scope of practice separates general whole-food wellness coaching from Medical Nutrition Therapy (MNT) performed by a Registered Dietitian (RDN). Wellness coaches guide healthy eating habits using the 2025–2030 Dietary Guidelines while referring clinical diseases like kidney failure or eating disorders to an RDN. Staying within scope ensures ethical, safe, and evidence-based client care.


#### En Palabras Sencillas (Norteño Context)

Un buen entrenador sabe hasta dónde llega su cancha de nutrición general y cuándo pasarle el balón al nutriólogo clínico (RDN). Si los términos técnicos se ponen pesados, concéntrate primero en la diferencia entre educación nutricional basada en DGA 2025–2030 y terapia médica nutricional.


### Regional Focus: Professional Standards & Community Leadership in Yuma

Enfoque Regional: Estándares Profesionales y Liderazgo Comunitario en Yuma

As graduates of HLTH-150 entering the health and exercise profession in Yuma County and across Arizona, you serve as ambassadors of evidence-based sports nutrition. Upholding professional ethics means respecting the legal scope of practice—distinguishing between general fitness coaching and licensed medical nutrition therapy—while utilizing federal SSoT standards (PAGA 2018 and DGA) to empower clients toward sustainable lifestyle transformations.

Como egresados de HLTH-150 que ingresan al ámbito profesional en el condado de Yuma y Arizona, ustedes actúan como embajadores de la nutrición basada en evidencia. Mantener la ética profesional implica respetar el ámbito legal de práctica y utilizar las normas SSoT (PAGA 2018 y DGA) para guiar a los clientes hacia cambios sostenibles.


### Reading 1: Professional Scope of Practice & Legal Boundaries

Lectura 1: Ámbito Profesional de Práctica y Límites Legales


#### Step 1: Distinguishing Coaching from Medical Nutrition Therapy

Diferenciación entre Entrenamiento y Terapia Nutricional Médica

Exercise professionals, kinesiologists, and personal trainers provide general physical activity guidance, sports nutrition education, and macro-level pacing strategies based on federal guidelines (PAGA 2018 / DGA). However, treating pathological medical conditions (such as renal disease, diabetes management, or clinical eating disorders) constitutes Medical Nutrition Therapy (MNT), which legally requires a Registered Dietitian Nutritionist (RDN) or licensed physician.

Los profesionales del ejercicio ofrecen orientación general en actividad física y educación nutricional basada en PAGA 2018. Sin embargo, tratar condiciones médicas patológicas constituye Terapia Nutricional Médica (MNT), requiriendo legalmente a un Dietista Registrado (RDN).


#### Step 2: Establishing Interdisciplinary Referral Networks

Establecimiento de Redes de Derivación Interdisciplinaria

An ethical practitioner recognizes their professional boundaries and maintains an active local referral network. When client needs exceed general wellness coaching—such as clinical eating disorders, acute metabolic pathologies, or severe dehydration—prompt referral to licensed allied health specialists is mandatory.

Un profesional ético reconoce sus límites y mantiene una red activa de derivación local. Cuando las necesidades del cliente superan el entrenamiento general, la derivación rápida a especialistas es obligatoria.


### Reading 2: Assembling the Comprehensive Career Portfolio

Lectura 2: Ensamblaje del Portafolio Profesional Integral


#### Step 1: Structuring Artifacts by Career Track

Estructuración de Artefactos por Ruta Profesional

A professional career portfolio functions as tangible proof of competency for future employers, transfer institutions, or clinical directors. Your portfolio integrates completed lab audits, AI preceptor prompt templates, bilingual client instruction cards, and Clinical Framing Protocol (Pattern / Rule / Solve) analyses structured around your chosen career path (Clinical, Community, or Athletic Performance).

Un portafolio profesional funciona como prueba tangible de competencia. Su portafolio integra auditorías de laboratorio completadas, plantillas de IA, tarjetas bilingües y análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución).


#### Step 2: Integrating AI Tool Kits and Safety Protocols

Integración de Cajas de Herramientas de IA y Protocolos de Seguridad

Modern fitness leadership requires generative AI literacy paired with rigorous safety governance. Your portfolio highlights your ability to utilize secure triple-hash delimiters ( ### ) for data boundary isolation and preceptor auditing.

El liderazgo moderno en acondicionamiento físico requiere alfabetización en IA generativa junto con una rigurosa gobernanza de seguridad. Su portafolio destaca el uso de delimitadores seguros de tres almohadillas.


### Reading 3: Lifelong Learning & Evidence-Based Practice

Lectura 3: Aprendizaje Permanente y Práctica Basada en Evidencia

Nutrition science and exercise physiology evolve continuously. Maintaining professional excellence requires committing to lifelong learning:

La ciencia de la nutrición y la fisiología del ejercicio evolucionan continuamente. Mantener la excelencia profesional exige un compromiso con el aprendizaje permanente:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Wellness coaching provides general fitness and sports nutrition education, whereas treating pathological medical conditions constitutes Medical Nutrition Therapy (MNT), which legally requires a licensed RDN or physician.

Respuesta en Español: El entrenamiento de bienestar ofrece educación general, mientras que tratar condiciones patológicas constituye Terapia Nutricional Médica (MNT), requiriendo legalmente a un RDN o médico.

English Response: A career portfolio functions as tangible proof of competency for employers and transfer institutions, integrating completed lab audits, AI prompts, and bilingual client tools.

Respuesta en Español: Un portafolio funciona como prueba tangible de competencia para empleadores e instituciones de transferencia, integrando auditorías de laboratorio y herramientas bilingües.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

HLTH-150 • Module 15 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 15:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 15 (Mod 15 Required Readings: Nutrition Scope of Practice & Complete Client Planning)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```
