# HLTH-150: Mod 13 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 13 Coaching Sprint Simulation: Low Energy Availability in Active Clients

- Energy Availability Formula (EA = (EI − EEE) ÷ kg Fat-Free Mass): The dietary energy left over for basic physiological functions after subtracting Exercise Energy Expenditure (EEE), expressed per kg of Fat-Free Mass (FFM). En palabras sencillas: La energía que le queda libre a tus órganos vitales después de descontar las calorías que quemaste entrenando.
- Optimal vs. Low Energy Availability Thresholds (≥45 vs. <30 kcal/kg FFM/day): Healthy physiological function requires ~45 kcal/kg FFM/day; falling below 30 kcal/kg FFM/day triggers clinical Low Energy Availability (LEA). En palabras sencillas: Bajar de 30 calorías por kilo de masa libre de grasa pone al cuerpo en reserva de emergencia, apagando hormonas y debilitando los huesos.
- Relative Energy Deficiency in Sport (RED-S) & Multidisciplinary Referral Gate: Syndrome of impaired bone density, menstrual/endocrine dysfunction, frequent illness, and declining performance requiring immediate caloric restoration and physician/RD referral. En palabras sencillas: Señales de alarma como fatiga crónica, fracturas por estrés o falta de periodo menstrual que exigen subir calorías reales y referir al médico y nutriólogo clínico (RD).

### Coach Alan's Weekly Check-In: Health Above All Else

Team, welcome to Week 13! Last week we audited energy balance and body composition. This week, we examine a vital and compassionate topic: Eating Disorders, Disordered Eating, and Relative Energy Deficiency in Sport (RED-S) .

In competitive sports and clinical practice, chronic low energy availability silently erodes bone density, endocrine health, and psychological well-being. As exercise professionals, we don't look the other way—we master energy availability thresholds (<30 kcal/kg FFM/day), recognize behavioral warning signs, and execute proper interdisciplinary referrals anchored in federal SSoT baselines (PAGA 2018 / IOC RED-S Consensus).


### Module 13 Tactical Roadmap / Ruta Táctica del Módulo 13

- Step 1: Required Readings: Master energy availability math, RED-S systemic pathology, and clinical screening protocols.
- Step 2: Discussion Board: Evaluate clinical screening cases against referral standards by Thursday at 11:59 PM MST.
- Step 3: Lab 13 Audit: Complete your track's energy availability calculations, verify via the Gemini AI Tool Kit, and submit by Monday at 11:59 PM MST.
- Step 4: Module 13 Knowledge Check: Lock in your mastery of clinical warning signs and interdisciplinary support.
Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Active Client Energy Availability (RED-S) & Fueling Gate Calibrator (/simulators/cyoj-module11) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate daily energy intake, training expenditure, and hydration safety gates to prevent Low Energy Availability (<30 kcal/kg FFM/day) and RED-S using nutrient-dense real foods (DGA 2025–2030). Copy your VERIFIED simulator receipt or slider values into the submission template below • Paired RED-S Energy Availability route: /simulators/energy-availability-auditor .

Open Active Client Energy Availability (RED-S) & Fueling Gate Calibrator in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/cyoj-module11 y "PAGA"): Calibre la ingesta energética, el gasto por entrenamiento y la hidratación para prevenir la Baja Disponibilidad Energética (<30 kcal/kg FFM/día) y RED-S con alimentos reales (DGA 2025–2030). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### The Coach's Playbook: Three RED-S Traps to Avoid

Dismissing recurrent stress fractures, fatigue, or amenorrhea as normal athletic strain rather than recognizing underlying energy deficiency.

Attempting to counsel individuals with clinical eating disorders without involving licensed mental health therapists and medical physicians.

Permitting athletes to resume high-intensity training before hormonal normalization and bone mineral density stabilization occur.


### AI Study Coach • Quick Concept Check

Want a 60-second quiz on this week's clinical pathology before tackling the lab? Copy this prompt into Gemini:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Quiz Master Protocol: HLTH-150 Module 13 Coaching Sprint ###:
Role: Supportive HLTH-150 Study Coach.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Ask the student 3 quick multiple-choice questions testing:
   Section a: The critical Energy Availability threshold (<30 kcal/kg FFM/day)
   Section b: Systemic physiological impacts of RED-S on bone and endocrine health
   Section c: The necessity of interdisciplinary referral teams for clinical eating disorders
Step 2: Wait for the student's answer after each question before providing feedback.
Step 3: Keep feedback concise, encouraging, and anchored in evidence-based clinical safety standards.
End Quiz Master Protocol ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 13 (Mod 13 Coaching Sprint: Low Energy Availability in Active Clients)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 13 Sprint de Entrenamiento: Trastornos Alimentarios y RED-S


### Mensaje Semanal del Entrenador Alan: La Salud por Encima de Todo

¡Equipo, bienvenidos a la Semana 13! La semana pasada auditamos el balance energético. Esta semana examinamos un tema vital y compasivo: Trastornos Alimentarios, Conducta Alimentaria Desordenada y RED-S .

En el deporte competitivo y la práctica clínica, la baja disponibilidad energética erosiona la densidad ósea y la salud endocrina. Como profesionales, dominamos el umbral de disponibilidad energética (<30 kcal/kg FFM/día), reconocemos señales de alerta y realizamos derivaciones interdisciplinarias basadas en las normas federales (PAGA 2018 / COI RED-S).


### Ruta Táctica del Módulo 13

- Step 1: Lecturas Obligatorias: Dominar las matemáticas de disponibilidad energética, la patología sistémica del RED-S y los protocolos de tamizaje clínico.
- Step 2: Foro de Discusión: Evaluar casos de tamizaje clínico frente a normas de derivación antes del jueves a las 11:59 PM MST.
- Step 3: Laboratorio 13: Completar los cálculos de disponibilidad energética, verificar con Gemini IA y entregar antes del lunes a las 11:59 PM MST.
- Step 4: Comprobación de Conocimientos: Afianzar el dominio sobre señales de alerta clínica y apoyo multidisciplinario.

### Estrategia del Entrenador: Tres Errores sobre RED-S que Debes Evitar

Desestimar fracturas por estrés recurrentes, fatiga o amenorrea como tensión atlética normal en lugar de reconocer deficiencia energética.

Intentar aconsejar a personas con trastornos alimentarios clínicos sin involucrar a terapeutas de salud mental y médicos licenciados.

Permitir que los atletas reanuden entrenamientos intensos antes de que ocurra la normalización hormonal y la estabilización ósea.


### Entrenador de Estudio con IA • Repaso Rápido

¿Desea una autoevaluación rápida de 60 segundos antes de realizar la práctica de laboratorio? Copie este prompt en Gemini:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Quiz Master Protocol: HLTH-150 Modulo 13 Coaching Sprint ###:
Rol: Tutor de Estudio Solidario para HLTH-150.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Hacer al estudiante 3 preguntas rapidas de opcion multiple evaluando:
   Section a: El umbral crítico de disponibilidad energética (<30 kcal/kg FFM/día)
   Section b: Los impactos fisiológicos sistémicos del RED-S en la salud ósea y endocrina
   Section c: La necesidad de equipos de derivación interdisciplinaria para trastornos alimentarios
Step 2: Esperar la respuesta del estudiante tras cada pregunta antes de retroalimentar.
Step 3: Mantener explicaciones claras, motivadoras y fundamentadas en normas de seguridad clínica basadas en evidencia.
Fin del Protocolo Quiz Master ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
