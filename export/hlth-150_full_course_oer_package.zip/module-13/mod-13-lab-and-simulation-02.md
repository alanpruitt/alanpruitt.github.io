## HLTH-150: Mod 13 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 13) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 13 Lab & Simulation: Energy Availability & Safe Fueling Audit

- Energy Availability Formula (EA = (EI − EEE) ÷ kg Fat-Free Mass): The dietary energy left over for basic physiological functions after subtracting Exercise Energy Expenditure (EEE), expressed per kg of Fat-Free Mass (FFM). En palabras sencillas: La energía que le queda libre a tus órganos vitales después de descontar las calorías que quemaste entrenando.
- Optimal vs. Low Energy Availability Thresholds (≥45 vs. <30 kcal/kg FFM/day): Healthy physiological function requires ~45 kcal/kg FFM/day; falling below 30 kcal/kg FFM/day triggers clinical Low Energy Availability (LEA). En palabras sencillas: Bajar de 30 calorías por kilo de masa libre de grasa pone al cuerpo en reserva de emergencia, apagando hormonas y debilitando los huesos.
- Relative Energy Deficiency in Sport (RED-S) & Multidisciplinary Referral Gate: Syndrome of impaired bone density, menstrual/endocrine dysfunction, frequent illness, and declining performance requiring immediate caloric restoration and physician/RD referral. En palabras sencillas: Señales de alarma como fatiga crónica, fracturas por estrés o falta de periodo menstrual que exigen subir calorías reales y referir al médico y nutriólogo clínico (RD).

### Lab Overview: EA Math, Fat-Free Mass & Clinical Referral Protocols

In clinical practice, community health initiatives, and competitive athletics, evaluating energy availability requires precise mathematical calculations of dietary intake, exercise expenditure, and fat-free mass anchored in federal and IOC standards.

In this lab, you will calculate Energy Availability (EA), evaluate values against the critical clinical threshold of 30 kcal/kg FFM/day anchored in PAGA 2018 standards , and use the Gemini AI Tool Kit with secure triple-hash delimiters (###) to audit an individualized RED-S recovery protocol across your chosen career track.


### Lab Logistics & Submission Terms / Horario y Condiciones

- Due Date / Fecha Límite: Monday, November 16, 2026, at 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry or Upload (Markdown / PDF)
- Points / Puntos: 50 Total Points (Scored via Rubric)
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) y "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Part A: Choose Your Career Track & Client Scenario

Select the scenario that corresponds to your chosen professional pathway:

Client: 24-year-old female recreational runner presenting with recurrent tibial stress fracture and amenorrhea. Data: Mass: 55.0 kg | Body Fat: 16% (Fat-Free Mass = 46.2 kg) | Dietary Intake: 1,700 kcal/day | Exercise Expenditure: 700 kcal/day.

Client: 16-year-old high school cross-country runner exhibiting restrictive eating behaviors and declining performance. Data: Mass: 50.0 kg | Body Fat: 15% (Fat-Free Mass = 42.5 kg) | Dietary Intake: 1,600 kcal/day | Exercise Expenditure: 650 kcal/day.

Client: 19-year-old collegiate distance runner (AWC Matadors) experiencing chronic fatigue and RED-S pathology. Data: Mass: 58.0 kg | Body Fat: 12% (Fat-Free Mass = 51.0 kg) | Dietary Intake: 2,100 kcal/day | Exercise Expenditure: 850 kcal/day.


### Part B: Clinical Framing Protocol (Pattern / Rule / Solve) Calculations & Energy Availability Audit

Perform the following calculations step-by-step for your selected track:

- Fat-Free Mass (FFM): Calculate Mass (kg) multiplied by [1 minus (Body Fat Percentage divided by 100)].
- Energy Availability (EA): Calculate [Dietary Intake (kcal) minus Exercise Expenditure (kcal)] divided by Fat-Free Mass (kg).
- Clinical Threshold Audit: Compare calculated EA against the critical 30 kcal/kg FFM/day threshold. State whether the client is in a state of low energy availability.
- Restoration Caloric Target: Determine the recommended dietary intake increase required to elevate EA to a safe operating level (40 to 45 kcal/kg FFM/day).

### Part C: Gemini AI Tool Kit & Clinical Audit

Copy the prompt template below into Gemini AI to audit your manual calculations. All clinical inputs must remain enclosed within triple-hash delimiters (###):

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: HLTH-150 RED-S Tool Box ###:
Role: Clinical Sports Dietitian and Endocrinologist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Audit the student's manual calculation of Fat-Free Mass (FFM), Energy Availability (EA), Clinical Threshold Audit, and Restoration Caloric Target.
Step 2: Evaluate the client's risk for RED-S pathology, bone stress injuries, or endocrine suppression based on their calculated EA value.
Step 3: Formulate a multidisciplinary recovery protocol (Nutritional Energy Restoration, Interdisciplinary Referral, Return-to-Play Standards) tailored to the client's setting.

Client Data Input ###:
Career Track: [Insert Track 1, 2, or 3]
Client Body Mass: [Insert kg] | Body Fat Percentage: [Insert %]
Dietary Intake: [Insert kcal/day]
Exercise Energy Expenditure: [Insert kcal/day]
Student Calculated Fat-Free Mass: [Insert kg]
Student Calculated Energy Availability: [Insert kcal/kg FFM/day]
Student Calculated Restoration Target: [Insert kcal/day]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Submission Template

Copy and paste the template below into the Canvas submission box to complete your Lab assignment:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
HLTH-150 Module 13 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]

Step 1: Pattern Recognition & Energy Availability Calculations:
Key Point: Client Body Mass: ___ kg | Body Fat: ___ %
Key Point: Calculated Fat-Free Mass (FFM): ___ kg
Key Point: Dietary Intake: ___ kcal/day | Exercise Expenditure: ___ kcal/day
Key Point: Calculated Energy Availability (EA): ___ kcal/kg FFM/day
Key Point: Exceeds Low Energy Availability Threshold (<30 kcal/kg): [Yes/No]

Step 2: Rule Application (IOC RED-S / PAGA 2018 Standards):
Key Point: Analysis of endocrine and bone health risks for this client:
Key Point: Physiological necessity of restoring EA to 40 - 45 kcal/kg FFM/day:

Step 3: Problem Solving & Multidisciplinary Recovery Protocol:
Key Point: Nutritional Energy Restoration Strategy (Caloric Increase & Whole Foods):
Key Point: Interdisciplinary Referral Plan (Sports Medicine Physician & Registered Dietitian):
Key Point: Return-to-Play Clearance & Training Reduction Criteria:

Step 4: AI Tool Kit Audit Reflection:
Key Point: Summary of Gemini AI's audit of your calculations and delimiter compliance:
Key Point: Adjustments made to your final recovery prescription based on AI feedback:
End Submission ###:
```

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 13 (Mod 13 Lab: Energy Availability & Safe Fueling Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 13 Lab: Cálculo de Disponibilidad Energética y Auditoría RED-S


### Visión General del Laboratorio: Matemáticas de EA, Masa Libre de Grasa y Derivación Clínica

En la práctica clínica, la salud comunitaria y el deporte competitivo, evaluar la disponibilidad energética exige cálculos matemáticos precisos de la ingesta dietética, el gasto por ejercicio y la masa libre de grasa basados en normas federales y del COI.

En esta práctica calculará la Disponibilidad Energética (EA), evaluará los valores frente al umbral clínico crítico de 30 kcal/kg FFM/día anclado en las normas de PAGA 2018 y utilizará la Caja de Herramientas de IA Gemini con delimitadores seguros (###) para auditar un protocolo de recuperación RED-S en su ruta profesional.


### Logística de Laboratorio y Términos de Entrega

- Fecha Límite: Lunes, 16 de noviembre de 2026, a las 11:59 PM MST
- Formato: Entrada de texto directa en Canvas o archivo adjunto (Markdown / PDF)
- Puntaje: 50 Puntos Totales (Evaluados mediante Rúbrica)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Seleccione su Ruta Profesional y Caso Práctico

Elija el escenario correspondiente a su trayectoria vocacional:

Paciente: Corredora recreativa de 24 años con fractura por estrés tibial recurrente y amenorrea. Datos: Masa: 55.0 kg | Grasa: 16% (Masa Libre de Grasa = 46.2 kg) | Ingesta: 1,700 kcal/día | Gasto por ejercicio: 700 kcal/día.

Cliente: Corredora de preparatoria de 16 años con conductas restrictivas y rendimiento en declive. Datos: Masa: 50.0 kg | Grasa: 15% (Masa Libre de Grasa = 42.5 kg) | Ingesta: 1,600 kcal/día | Gasto por ejercicio: 650 kcal/día.

Atleta: Corredor universitario de fondo de 19 años (AWC Matadors) con fatiga crónica y patología RED-S. Datos: Masa: 58.0 kg | Grasa: 12% (Masa Libre de Grasa = 51.0 kg) | Ingesta: 2,100 kcal/día | Gasto por ejercicio: 850 kcal/día.


### Parte B: Cálculos del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y Auditoría de Disponibilidad Energética

Realice los siguientes cálculos paso a paso para el caso seleccionado:

- Masa Libre de Grasa (FFM): Calcule Masa (kg) multiplicada por [1 menos (Porcentaje de Grasa dividido por 100)].
- Disponibilidad Energética (EA): Calcule [Ingesta Dietética (kcal) menos Gasto por Ejercicio (kcal)] dividido por Masa Libre de Grasa (kg).
- Auditoría del Umbral Clínico: Compare la EA calculada frente al umbral crítico de 30 kcal/kg FFM/día. Indique si el cliente presenta baja disponibilidad energética.
- Meta Calórica de Restauración: Determine el aumento recomendado de ingesta dietética necesario para elevar la EA a un nivel seguro (40 a 45 kcal/kg FFM/día).

### Parte C: Caja de Herramientas de IA Gemini y Auditoría Clínica

Copie la siguiente plantilla en Gemini IA para auditar sus cálculos. Recuerde mantener los datos clínicos cerrados con delimitadores seguros (###):

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Safety Auditor Protocol: HLTH-150 RED-S Tool Box ###:
Rol: Dietista Deportivo Clinico y Endocrinologo.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Auditar los calculos manuales del estudiante sobre Masa Libre de Grasa (FFM), Disponibilidad Energética (EA), Auditoría del Umbral Clínico y Meta de Restauración.
Step 2: Evaluar el riesgo del cliente de sufrir patología RED-S, lesiones óseas o supresión endocrina según el valor de EA calculado.
Step 3: Formular un protocolo multidisciplinario de recuperación (Restauración Energética, Derivación Interdisciplinaria, Criterios de Reincorporación).

Entrada de Datos del Cliente ###:
Ruta Profesional: [Insertar Ruta 1, 2 o 3]
Masa Corporal del Cliente: [Insertar kg] | Porcentaje de Grasa: [Insertar %]
Ingesta Dietética: [Insertar kcal/día]
Gasto Energético por Ejercicio: [Insertar kcal/día]
Masa Libre de Grasa Calculada por Estudiante: [Insertar kg]
Disponibilidad Energética Calculada por Estudiante: [Insertar kcal/kg FFM/día]
Meta de Restauración Calculada: [Insertar kcal/día]
Fin de Datos del Cliente ###:
End Safety Auditor Protocol ###:
```


### Plantilla de Entrega

Copie y pegue la siguiente plantilla en Canvas para enviar su tarea de laboratorio:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
HLTH-150 Entrega de Laboratorio Módulo 13 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clínica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]

Step 1: Reconocimiento de Patrones y Cálculos de Disponibilidad Energética:
Key Point: Masa Corporal del Cliente: ___ kg | Grasa Corporal: ___ %
Key Point: Masa Libre de Grasa Calculada (FFM): ___ kg
Key Point: Ingesta Dietética: ___ kcal/día | Gasto por Ejercicio: ___ kcal/día
Key Point: Disponibilidad Energética Calculada (EA): ___ kcal/kg FFM/día
Key Point: Supera el Umbral de Baja Disponibilidad (<30 kcal/kg): [Sí/No]

Step 2: Aplicación de Reglas (Normas IOC RED-S / PAGA 2018):
Key Point: Análisis de los riesgos endocrinos y de salud ósea para este cliente:
Key Point: Importancia fisiológica de restaurar la EA a 40 - 45 kcal/kg FFM/día:

Step 3: Resolución de Problemas y Protocolo de Recuperación Multidisciplinario:
Key Point: Estrategia de Restauración Energética Nutricional (Aumento calórico y alimentos integrales):
Key Point: Plan de Derivación Interdisciplinaria (Médico deportivo y dietista registrado):
Key Point: Criterios de Autorización para Reincorporación y Reducción del Entrenamiento:

Step 4: Reflexion de la Auditoria con IA:
Key Point: Resumen de la revisión de cálculos realizada por Gemini IA y cumplimiento de delimitadores:
Key Point: Ajustes aplicados a la prescripción final de recuperación según la retroalimentación de la IA:
Fin de la Entrega ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 13)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 13)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
