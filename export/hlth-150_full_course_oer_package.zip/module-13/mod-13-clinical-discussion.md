# HLTH-150: Mod 13 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 13 Discussion: Spotting Disordered Eating & When to Refer

- Energy Availability Formula (EA = (EI − EEE) ÷ kg Fat-Free Mass): The dietary energy left over for basic physiological functions after subtracting Exercise Energy Expenditure (EEE), expressed per kg of Fat-Free Mass (FFM). En palabras sencillas: La energía que le queda libre a tus órganos vitales después de descontar las calorías que quemaste entrenando.
- Optimal vs. Low Energy Availability Thresholds (≥45 vs. <30 kcal/kg FFM/day): Healthy physiological function requires ~45 kcal/kg FFM/day; falling below 30 kcal/kg FFM/day triggers clinical Low Energy Availability (LEA). En palabras sencillas: Bajar de 30 calorías por kilo de masa libre de grasa pone al cuerpo en reserva de emergencia, apagando hormonas y debilitando los huesos.
- Relative Energy Deficiency in Sport (RED-S) & Multidisciplinary Referral Gate: Syndrome of impaired bone density, menstrual/endocrine dysfunction, frequent illness, and declining performance requiring immediate caloric restoration and physician/RD referral. En palabras sencillas: Señales de alarma como fatiga crónica, fracturas por estrés o falta de periodo menstrual que exigen subir calorías reales y referir al médico y nutriólogo clínico (RD).

### Recognizing RED-S Warning Signs, Behavioral Red Flags & Referral Standards

Identifying disordered eating and Relative Energy Deficiency in Sport (RED-S) in athletic and clinical populations requires compassion, acute observational skill, and strict adherence to professional boundaries. Exercise professionals must recognize behavioral warning signs and execute proper interdisciplinary referrals. Select your Build Your Own Journey Track below, audit a real-world clinical screening case using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / IOC RED-S Consensus / ACSM Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-13

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Managing recurrent stress fractures, amenorrhea, and bone density suppression in clinical rehabilitation patients.

Focus: Community education initiatives in Yuma County promoting positive body image and youth sports wellness.

Focus: Screening collegiate athletes for RED-S, restoring energy availability, and return-to-play clearance protocols.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & RED-S Warning Signs / Ruta y Señales de Alerta: State your chosen track and report the client's clinical presentation, noting specific physiological indicators of low energy availability. Indique la ruta seleccionada y reporte la presentación clínica del cliente, señalando indicadores fisiológicos de baja disponibilidad energética.
- Clinical Framing Protocol (Pattern / Rule / Solve) Analysis (Pattern / Rule / Solve) / Análisis del Protocolo de Marco Clínico (Patrón / Regla / Solución): Explain why chronic energy restriction impairs bone density and endocrine health (Pattern), cite IOC RED-S and PAGA 2018 screening standards (Rule), and provide the multidisciplinary support protocol (Solve). Explique por qué la restricción crónica afecta la densidad ósea (Patrón), cite las normas de tamizaje RED-S (Regla) y detalle el protocolo de apoyo (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence explanation of the recovery and support plan in both English and Spanish so your client can execute it easily. Proporcione una explicación concisa de 2 oraciones sobre el plan de recuperación en inglés y español para que su cliente la aplique fácilmente.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their screening recommendations, compare interdisciplinary referral pathways, and discuss how RED-S protocols must adapt across clinical, community, and athletic settings.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Collegiate distance runner B.W. exhibits classic RED-S indicators: chronic fatigue, declining race performance, frequent injuries, and an audited energy availability of 25 kcal/kg FFM/day—significantly below the 30 kcal/kg safety threshold.

Rule Application (IOC RED-S / PAGA 2018 Standards): According to IOC consensus statements, energy availability below 30 kcal/kg FFM/day disrupts endocrine signaling, suppresses bone formation, and impairs cardiovascular function. Immediate clinical intervention and temporary training reduction are mandatory.

Solve (Multidisciplinary Recovery Protocol): We establish a comprehensive recovery plan:

- Energy Restoration: Increase daily caloric intake by 500 kcal/day through nutrient-dense whole foods to elevate EA above 40 kcal/kg FFM/day.
- Interdisciplinary Referral: Coordinate immediate evaluation with a sports medicine physician and a registered sports dietitian specializing in RED-S.
- Return-to-Play Clearance: Enforce supervised training reduction until hormonal normalization and bone density stabilization are confirmed.
EN: "Increase your daily food intake to support your training, and partner with our sports medicine team to restore your long-term health."

ES: "Aumente su consumo diario de alimentos para respaldar su entrenamiento y colabore con nuestro equipo médico para restaurar su salud."

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 13 (Mod 13 Discussion: Spotting Disordered Eating & When to Refer)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 13 Foro de Discusión: Tamizaje Clínico y Derivación Interdisciplinaria


### Reconocimiento de Señales de Alerta de RED-S y Normas de Derivación

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) para auditar el tamizaje clínico según las pautas federales y de nutrición deportiva.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Reporte la presentación clínica del cliente, señalando indicadores fisiológicos de baja disponibilidad energética.


#### Parte 2: Aplicación de Reglas (Normas IOC RED-S / PAGA 2018)

Explique por qué la restricción energética crónica compromete la densidad ósea, citando el umbral crítico de 30 kcal/kg FFM/día.


#### Parte 3: Resolución de la Brecha (Protocolo Multidisciplinario y Tarjeta Bilingüe)

Diseñe un protocolo de restauración y derivación interdisciplinaria, proporcionando una tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

El corredor B.W. presenta indicadores clásicos de RED-S: fatiga crónica, rendimiento en declive, lesiones frecuentes y una disponibilidad energética auditada de 25 kcal/kg FFM/día, por debajo del umbral de seguridad.

Las declaraciones del COI establecen que la disponibilidad energética menor a 30 kcal/kg FFM/día altera la señalización endocrina y compromete la función ósea, requiriendo intervención clínica inmediata.

Protocolo Multidisciplinario: Aumento calórico de 500 kcal/día con alimentos integrales, derivación a medicina deportiva y dietista registrado, y reducción temporal supervisada del entrenamiento. Tarjeta de Instrucción Bilingüe: "Aumente su consumo diario de alimentos para respaldar su entrenamiento y colabore con nuestro equipo médico para restaurar su salud."

HLTH-150 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
