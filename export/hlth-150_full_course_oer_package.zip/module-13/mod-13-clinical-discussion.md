## HLTH-150: Mod 13 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 13) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 13 Discussion: Spotting Disordered Eating & When to Refer

- Energy Availability Formula (EA = (EI − EEE) ÷ kg Fat-Free Mass): The dietary energy left over for basic physiological functions after subtracting Exercise Energy Expenditure (EEE), expressed per kg of Fat-Free Mass (FFM). En palabras sencillas: La energía que le queda libre a tus órganos vitales después de descontar las calorías que quemaste entrenando.
- Optimal vs. Low Energy Availability Thresholds (≥45 vs. <30 kcal/kg FFM/day): Healthy physiological function requires ~45 kcal/kg FFM/day; falling below 30 kcal/kg FFM/day triggers clinical Low Energy Availability (LEA). En palabras sencillas: Bajar de 30 calorías por kilo de masa libre de grasa pone al cuerpo en reserva de emergencia, apagando hormonas y debilitando los huesos.
- Relative Energy Deficiency in Sport (RED-S) & Multidisciplinary Referral Gate: Syndrome of impaired bone density, menstrual/endocrine dysfunction, frequent illness, and declining performance requiring immediate caloric restoration and physician/RD referral. En palabras sencillas: Señales de alarma como fatiga crónica, fracturas por estrés o falta de periodo menstrual que exigen subir calorías reales y referir al médico y nutriólogo clínico (RD).

### Recognizing RED-S Warning Signs, Behavioral Red Flags & Referral Standards

Identifying disordered eating and Relative Energy Deficiency in Sport (RED-S) in athletic and clinical populations requires compassion, acute observational skill, and strict adherence to professional boundaries. Exercise professionals must recognize behavioral warning signs and execute proper interdisciplinary referrals. Select your Build Your Own Journey Track below, audit a real-world clinical screening case using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / IOC RED-S Consensus / ACSM Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-13

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Managing recurrent stress fractures, amenorrhea, and bone density suppression in clinical rehabilitation patients.

Focus: Community education initiatives in Yuma County promoting positive body image and youth sports wellness.

Focus: Screening collegiate athletes for RED-S, restoring energy availability, and return-to-play clearance protocols.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & RED-S Warning Signs / Ruta y Señales de Alerta: State your chosen track and report the client's clinical presentation, noting specific physiological indicators of low energy availability. Indique la ruta seleccionada y reporte la presentación clínica del cliente, señalando indicadores fisiológicos de baja disponibilidad energética.
- Clinical Framing Protocol (Pattern / Rule / Solve) Analysis (Pattern / Rule / Solve) / Análisis del Protocolo de Marco Clínico (Patrón / Regla / Solución): Explain why chronic energy restriction impairs bone density and endocrine health (Pattern), cite IOC RED-S and PAGA 2018 screening standards (Rule), and provide the multidisciplinary support protocol (Solve). Explique por qué la restricción crónica afecta la densidad ósea (Patrón), cite las normas de tamizaje RED-S (Regla) y detalle el protocolo de apoyo (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence explanation of the recovery and support plan in both English and Spanish so your client can execute it easily. Proporcione una explicación concisa de 2 oraciones sobre el plan de recuperación en inglés y español para que su cliente la aplique fácilmente.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their screening recommendations, compare interdisciplinary referral pathways, and discuss how RED-S protocols must adapt across clinical, community, and athletic settings.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Collegiate distance runner B.W. exhibits classic RED-S indicators: chronic fatigue, declining race performance, frequent injuries, and an audited energy availability of 25 kcal/kg FFM/day—significantly below the 30 kcal/kg safety threshold.

Rule Application (IOC RED-S / PAGA 2018 Standards): According to IOC consensus statements, energy availability below 30 kcal/kg FFM/day disrupts endocrine signaling, suppresses bone formation, and impairs cardiovascular function. Immediate clinical intervention and temporary training reduction are mandatory.

Solve (Multidisciplinary Recovery Protocol): We establish a comprehensive recovery plan:

- Energy Restoration: Increase daily caloric intake by 500 kcal/day through nutrient-dense whole foods to elevate EA above 40 kcal/kg FFM/day.
- Interdisciplinary Referral: Coordinate immediate evaluation with a sports medicine physician and a registered sports dietitian specializing in RED-S.
- Return-to-Play Clearance: Enforce supervised training reduction until hormonal normalization and bone density stabilization are confirmed.
EN: "Increase your daily food intake to support your training, and partner with our sports medicine team to restore your long-term health."

ES: "Aumente su consumo diario de alimentos para respaldar su entrenamiento y colabore con nuestro equipo médico para restaurar su salud."

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 13 (Mod 13 Discussion: Spotting Disordered Eating & When to Refer)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 13 Foro de Discusión: Tamizaje Clínico y Derivación Interdisciplinaria


### Reconocimiento de Señales de Alerta de RED-S y Normas de Derivación

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) para auditar el tamizaje clínico según las pautas federales y de nutrición deportiva.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Reporte la presentación clínica del cliente, señalando indicadores fisiológicos de baja disponibilidad energética.


#### Parte 2: Aplicación de Reglas (Normas IOC RED-S / PAGA 2018)

Explique por qué la restricción energética crónica compromete la densidad ósea, citando el umbral crítico de 30 kcal/kg FFM/día.


#### Parte 3: Resolución de la Brecha (Protocolo Multidisciplinario y Tarjeta Bilingüe)

Diseñe un protocolo de restauración y derivación interdisciplinaria, proporcionando una tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

El corredor B.W. presenta indicadores clásicos de RED-S: fatiga crónica, rendimiento en declive, lesiones frecuentes y una disponibilidad energética auditada de 25 kcal/kg FFM/día, por debajo del umbral de seguridad.

Las declaraciones del COI establecen que la disponibilidad energética menor a 30 kcal/kg FFM/día altera la señalización endocrina y compromete la función ósea, requiriendo intervención clínica inmediata.

Protocolo Multidisciplinario: Aumento calórico de 500 kcal/día con alimentos integrales, derivación a medicina deportiva y dietista registrado, y reducción temporal supervisada del entrenamiento. Tarjeta de Instrucción Bilingüe: "Aumente su consumo diario de alimentos para respaldar su entrenamiento y colabore con nuestro equipo médico para restaurar su salud."

HLTH-150 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 13)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 13)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
