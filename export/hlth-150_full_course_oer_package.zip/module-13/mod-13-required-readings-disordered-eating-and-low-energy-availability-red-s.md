# HLTH-150: Mod 13 Required Readings Disordered Eating And Low Energy Availability Red S

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 13 Required Readings: Disordered Eating & Low Energy Availability (RED-S)

Lecturas Obligatorias: Trastornos Alimentarios, Disponibilidad Energética y Patología RED-S

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from 2025–2030 Dietary Guidelines for Americans (Real-Food Focus) & PAGA 2018), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 13): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Relative Energy Deficiency in Sport (RED-S) happens when an active person does not eat enough calories to cover both exercise and basic body functions. Chronic under-fueling shuts down bone rebuilding, hormone balance, immunity, and cardiovascular health. Recognizing RED-S warning signs early lets you pause high-volume training and refer to a clinical care team.


#### En Palabras Sencillas (Norteño Context)

Si gastas más energía entrenando de la que entra en tu plato, el cuerpo empieza a apagar sistemas importantes para ahorrar corriente. Si los términos técnicos se ponen pesados, concéntrate primero en las señales de alerta de baja disponibilidad de energía (RED-S) y cuándo referir al equipo médico.


### Regional Focus: Athlete Welfare & Clinical Screening in Arizona

Enfoque Regional: Bienestar del Atleta y Tamizaje Clínico en Arizona

In Yuma County and across competitive athletic fleets in Arizona, endurance runners, weight-class wrestlers, and aesthetic sport participants face extreme pressures regarding body composition. Chronic low energy availability disrupts endocrine function, bone mineral density, and immune health—a syndrome defined by the International Olympic Committee as Relative Energy Deficiency in Sport (RED-S). Recognizing clinical pathology and establishing compassionate referral networks is a vital competency for exercise professionals.

En el condado de Yuma y en el deporte competitivo en Arizona, los atletas de resistencia y deportes de combate enfrentan presiones extremas sobre la composición corporal. La baja disponibilidad energética crónica altera la función endocrina y la densidad ósea (síndrome RED-S). Reconocer la patología clínica y establecer redes de derivación es fundamental.


### Reading 1: Energy Availability Thresholds & RED-S Pathology

Lectura 1: Umbrales de Disponibilidad Energética y Patología RED-S


#### Step 1: Calculating Energy Availability (EA)

Cálculo de la Disponibilidad Energética (EA)

Energy Availability (EA) is defined as dietary energy intake minus exercise energy expenditure, normalized to fat-free mass (FFM in kg):

La Disponibilidad Energética (EA) se define como la ingesta de energía dietética menos el gasto energético por ejercicio, normalizado a la masa libre de grasa (FFM en kg):

Optimal energy availability for healthy physiological function is approximately 45 kcal/kg FFM/day. Dropping below the critical clinical threshold of 30 kcal/kg FFM/day impairs metabolic rate, reproductive hormones, and bone formation.

La disponibilidad energética óptima es de aproximadamente 45 kcal/kg FFM/día. Descender por debajo del umbral clínico crítico de 30 kcal/kg FFM/día altera el metabolismo, las hormonas reproductivas y la formación ósea.


#### Step 2: Comprehensive Systemic Impacts of RED-S

Impactos Sistémicos Comprehensive del RED-S

Unlike the older Female Athlete Triad (which focused on energy availability, menstrual function, and bone mineral density), Relative Energy Deficiency in Sport (RED-S) encompasses wide-ranging physiological impairments affecting both male and female athletes:

A diferencia de la antigua Tríada de la Atleta Femenina, el RED-S abarca múltiples alteraciones fisiológicas en atletas de ambos sexos:

- Endocrine & Reproductive Impairment: Suppression of luteinizing hormone (LH), leading to functional hypothalamic amenorrhea in females and lowered testosterone in males. Déficit Endocrino y Reproductivo: Supresión de hormonas luteinizantes, provocando amenorrea hipotalámica y testosterona baja.
- Bone Health & Stress Fractures: Decreased estrogen and testosterone combined with elevated cortisol compromises bone turnover, elevating risk for stress fractures. Salud Ósea y Fracturas por Estrés: La disminución hormonal combinada con cortisol elevado compromete el recambio óseo y eleva el riesgo de fracturas.
- Psychological & Performance Decline: Depression, irritability, impaired judgment, reduced endurance performance, and diminished coordination. Deterioro Psicológico y de Rendimiento: Depresión, irritabilidad, juicio alterado, menor rendimiento de resistencia y coordinación disminuida.

### Reading 2: Clinical Eating Disorders & Behavioral Warning Signs

Lectura 2: Trastornos Alimentarios Clínicos y Señales de Alerta Conductual


#### Step 1: Diagnostic Classifications (DSM-5)

Clasificaciones Diagnósticas (DSM-5)

Clinical eating disorders are psychiatric conditions with profound nutritional and physical consequences. Key diagnoses include Anorexia Nervosa (AN) (severe caloric restriction, intense fear of weight gain, and distorted body image), Bulimia Nervosa (BN) (recurrent binge eating paired with inappropriate compensatory purging behaviors), and Binge Eating Disorder (BED) .

Los trastornos alimentarios clínicos son condiciones psiquiátricas con profundas consecuencias físicas. Las principales categorías incluyen la Anorexia Nerviosa (AN) , la Bulimia Nerviosa (BN) y el Trastorno por Atracón (BED) .


#### Step 2: Behavioral and Physical Warning Signs

Señales de Alerta Físicas y Conductuales

Exercise professionals must remain vigilant for behavioral red flags, including rigid food rules, excessive non-prescribed exercise beyond training schedules, frequent weighing, wearing layered clothing in warm environments, and social withdrawal around team meals.

Los profesionales del ejercicio deben estar atentos a banderas rojas conductuales, incluyendo reglas rígidas sobre alimentos, ejercicio excesivo no prescrito, pesajes frecuentes, uso de ropa en capas en clima cálido y aislamiento social durante las comidas.


### Reading 3: Multidisciplinary Screening & Referral Protocols

Lectura 3: Tamizaje Multidisciplinario y Protocolos de Derivación

Addressing eating disorders and RED-S requires a coordinated interdisciplinary team approach:

Abordar los trastornos alimentarios y el RED-S requiere un enfoque coordinado de equipo interdisciplinario:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Energy availability dropping below 30 kcal/kg of fat-free mass per day impairs endocrine function, suppresses reproductive hormones, and compromises bone mineral density.

Respuesta en Español: Una disponibilidad energética inferior a 30 kcal/kg de masa libre de grasa al día altera la función endocrina, suprime hormonas reproductivas y compromete la densidad ósea.

English Response: RED-S is a broader syndrome encompassing wide-ranging physiological impairments affecting both male and female athletes, including cardiovascular, metabolic, immunological, and psychological dysfunctions.

Respuesta en Español: El RED-S es un síndrome más amplio que abarca múltiples alteraciones fisiológicas en atletas de ambos sexos, incluyendo disfunciones cardiovasculares, metabólicas e inmunológicas.

English Response: Eating disorders are complex psychiatric conditions with severe physical complications requiring licensed mental health therapists, physicians, and registered dietitians; exercise professionals must not treat them in isolation.

Respuesta en Español: Los trastornos alimentarios son condiciones psiquiátricas complejas con complicaciones físicas graves que requieren terapeutas, médicos y dietistas licenciados; los entrenadores no deben tratarlos solos.

HLTH-150 • Module 13 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 13:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 13 (Mod 13 Required Readings: Disordered Eating & Low Energy Availability (RED-S))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```
