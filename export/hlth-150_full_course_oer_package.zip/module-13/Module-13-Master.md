## HLTH-150: LAB 13 - BEHAVIORAL NUTRITION & ADHERENCE / NUTRICIÓN CONDUCTUAL Y ADHERENCIA 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This module focuses on behavioral adherence models, habit formation strategies, and client counseling frameworks to support sustained physical activity and healthy nutrition. Students will analyze how personal routines, environmental barriers, and community resources influence long-term lifestyle changes. All counseling baselines, lifestyle assessment criteria, and behavioral targets align exclusively with our dual SSoT: the current **U.S. Dietary Guidelines for Americans** and the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* *Español (Regional): Este módulo se centra en los modelos de adherencia conductual, las estrategias de formación de hábitos y los marcos de asesoramiento al cliente para apoyar la actividad física sostenida y la nutrición saludable. Los estudiantes analizarán cómo las rutinas personales, las barreras ambientales y los recursos comunitarios influyen en los cambios de estilo de vida a largo plazo. Todos los criterios de evaluación del comportamiento se alinean exclusivamente con nuestro SSoT dual: las **Pautas Dietéticas para Estadounidenses** vigentes y las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.8])** Design an evidence-based physical activity or nutritional program that addresses a specific community or individual health need.
* *Español (Regional) ([LO 2.8]): Diseñar un programa de actividad física o nutrición basado en evidencia que aborde una necesidad de salud comunitaria o individual específica.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Map recurring client behavioral patterns, identifying barriers to lifestyle tracking, environmental triggers for dietary non-adherence, and drop-out indicators in community-level interventions.
2. **Rule / Regla:** Apply formal socio-ecological framework rules and evidence-based behavior modification principles outlined within the public health and lifestyle design guidelines of the SSoT.
3. **Solve / Solución:** Engineer a customized lifestyle counseling protocol and tracking matrix that builds structural habits to ensure safe, sustainable dietary adherence without violating federal standards.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Adherence Barrier Modeling & Script Auditing

Students will initialize their habit formation tools inside the digital sandbox workspace using the setup records wrapped below.

::: {.callout-note}
## Worked Example: Step-by-Step Guidance / Ejemplo Práctico Paso a Paso
**Context & Application:** When completing this lab assignment, follow this structured three-step approach based on our Single Sources of Truth (PAGA 2018 / ACSM 12th Ed.):

1. **Step 1 (Identify Pattern):** Review the client or case profile parameters for baseline activity, physiological constraints, or nutritional markers.
2. **Step 2 (Apply Rule):** Cross-reference the specific federal guidelines, volume targets, or physiological formulas required for the assessment.
3. **Step 3 (Solve):** Formulate your final recommendation or calculation clearly within the submission template below.
:::

```text
## METABOLIC_STRATA:
- Client Profile: Community member attempting lifestyle tracking re-entry
- Core Behavior Pattern: High initial compliance followed by a total tracking dropout at day 14 due to social-environmental constraints
- Current Intervention Strategy: Rigid calorie counting sheet without behavioral habit scaffolding
###
```

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Input the client behavioral profile parameters into the habit tracking database.
2. Cross-reference the client's activity barriers against federal physical activity and dietary support guidelines.
3. Use the AI interface to audit counseling approaches, evaluating how flexible habit scaffolding improves long-term client adherence compared to rigid tracking.

---

## Part B: Practical Application (Onsite Lab) / Aplicación Práctica Presencial (Laboratorio)

## Location: Community College Athletics Facilities & Localized Group Project Presentation Area

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Construct an objective, evidence-based habit formation log that establishes environmental cues for nutritional tracking.
2. Formulate a multi-tier client counseling protocol matrix using federal reference guidelines to support lifestyle adherence.
3. Complete final compliance sheets verifying that all behavior tracking recommendations remain free of commercial gimmick language.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This assignment is evaluated using the strict **10/7/0 Mastery Scale** / *Esta asignación se evalúa utilizando la escala estricta de Maestría **10/7/0**:*

* **10 (Exemplary / Ejemplar):**
  * **English:** Zero-drift integration. All core guidelines are applied exactly, target parameters remain securely enclosed within delimiter structures (`###`), and bilingual parity is fully preserved.
  * *Español (Regional): Integración con cero desviaciones. Todas las pautas de referencia se aplican exactamente, los parámetros de configuración permanecen contenidos de forma segura dentro de las estructuras delimitadoras (`###`) y se conserva por completo la paridad bilingüe.*
* **7 (Competent / Competente):**
  * **English:** Core performance metrics are safe, safe thermal boundaries are maintained, and calculations are accurate, but minor regional translation gaps, loose formatting, or structural layout misplacements are flagged.
  * *Español (Regional): Las métricas de rendimiento principales son seguras, se mantienen los límites de seguridad térmica y los cálculos son precisos, pero se señalan brechas menores de traducción regional, formato suelto o desalineaciones en la estructura.*
* **0 (Recalibrate / Recalibrar):**
  * **English:** Critical calculation drift is present, safety thresholds are violated, commercial/fad-based trends are promoted instead of the federal SSoT, or core data inputs are left un-delimited.
  * *Español (Regional): Se presenta una desviación crítica en los cálculos, se violan los límites de seguridad, se promueven tendencias comerciales en lugar de la Fuente Única de Verdad (SSoT) federal, o las entradas de datos clave se dejan sin delimitar.*

---

## HLTH-150 Module Discussion: Socio-Ecological Barriers vs. Sustainable Habit Formation

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Evaluate the target configuration variables to construct your behavioral tracking protocols, and defend your lifestyle modifications using evidence-based federal reference guidelines.
* **Español (Regional):** Evaluar las variables de configuración para construir sus protocolos de seguimiento de comportamiento y defender sus modificaciones de estilo de vida utilizando las pautas de referencia federales basadas en evidencia.
###



## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
