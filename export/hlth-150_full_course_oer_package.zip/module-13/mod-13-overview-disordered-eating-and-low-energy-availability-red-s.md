# HLTH-150: Mod 13 Overview Disordered Eating And Low Energy Availability Red S

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 13 Overview: Disordered Eating & Low Energy Availability (RED-S)

El Porqué del Módulo 13 (Círculo Dorado — Contexto Norteño): “¿Por qué comer menos energía de la que quemas (RED-S) apaga los huesos, las hormonas y el rendimiento, y cómo podemos detectar las señales de alerta a tiempo?”


### Module 13 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 13: Disordered Eating & Low Energy Availability (RED-S)

Welcome to Week 13! Building upon our study of energy balance, this week we examine a critical and sensitive clinical topic: Eating Disorders, Disordered Eating, and Relative Energy Deficiency in Sport (RED-S) . In athletic conditioning, physical therapy, and community health, chronic low energy availability impairs bone mineral density, endocrine function, cardiovascular health, and psychological well-being. As exercise professionals, we must recognize early warning signs, establish compassionate screening protocols, and prioritize athlete health above competitive pressures.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify energy deficit warning patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and IOC RED-S consensus baselines, and design multidisciplinary referral and recovery protocols.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, November 10, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, November 12, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, November 15, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, November 16, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 13 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Recognize physiological and psychological indicators of disordered eating, clinical eating disorders, and Relative Energy Deficiency in Sport (RED-S). Reconocer indicadores fisiológicos y psicológicos de trastornos alimentarios y RED-S.
- CLO 2 (Rule Application): Apply PAGA 2018 and IOC RED-S energy availability thresholds (<30 kcal/kg fat-free mass/day), clinical screening guidelines, and interdisciplinary referral standards. Aplicar los umbrales de disponibilidad energética de PAGA 2018 y RED-S, directrices de tamizaje y normas de derivación interdisciplinaria.
- CLO 3 (Problem Solving): Formulate an evidence-based clinical screening, energy availability audit, and multidisciplinary support plan tailored to vulnerable populations. Formular un plan clínico de tamizaje, auditoría de disponibilidad energética y apoyo multidisciplinario adaptado a poblaciones vulnerables.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Managing bone stress injuries, amenorrhea, and metabolic suppression in clinical rehabilitation patients experiencing chronic low energy availability.

Community education initiatives in Yuma County promoting positive body image, youth sports wellness, and destigmatizing mental health support.

Screening endurance runners and weight-class athletes for RED-S, restoring energy availability, and establishing return-to-play clearance protocols.


### Module 13 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Eating Disorders, Energy Availability Thresholds & RED-S Pathology
- Discussion Board: Clinical Screening, Warning Signs & Interdisciplinary Referral
- Lab Assignment: Energy Availability Calculation, RED-S Audit & Gemini AI Tool Kit
- Knowledge Check & Module Summary
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 13 (Mod 13 Overview: Disordered Eating & Low Energy Availability (RED-S))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 13 Visión General: Trastornos Alimentarios y RED-S


### Bienvenido al Módulo 13: Baja Disponibilidad Energética, Tamizaje y Protocolos de Recuperación

¡Bienvenido a la Semana 13! Basándonos en nuestro estudio sobre balance energético, esta semana examinamos un tema clínico crítico: Trastornos Alimentarios, Conducta Alimentaria Desordenada y RED-S . La baja disponibilidad energética crónica daña la densidad ósea, la función endocrina y la salud cardiovascular. Como profesionales, debemos reconocer señales de alerta y priorizar la salud por encima de la presión competitiva.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones de déficit, aplicarás los estándares de PAGA 2018 y RED-S, y diseñarás protocolos de derivación.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Reconocer indicadores fisiológicos y psicológicos de trastornos alimentarios y RED-S.
- CLO 2 (Regla): Aplicar los umbrales de disponibilidad energética de PAGA 2018 y RED-S (<30 kcal/kg masa libre de grasa/día), directrices de tamizaje y normas de derivación.
- CLO 3 (Solución): Formular un plan clínico de tamizaje, auditoría energética y apoyo multidisciplinario adaptado a poblaciones vulnerables.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, continuará trabajando dentro de la ruta profesional que haya seleccionado:

Manejo de lesiones por estrés óseo, amenorrea y supresión metabólica en pacientes clínicos con baja disponibilidad energética.

Iniciativas comunitarias en Yuma que promueven imagen corporal positiva, bienestar deportivo juvenil y apoyo en salud mental.

Tamizaje de corredores y atletas de categoría de peso para RED-S, restauración energética y protocolos de reincorporación deportiva.


### Ruta de Aprendizaje del Módulo 13

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Trastornos Alimentarios, Umbrales Energéticos y Patología RED-S
- Foro de Discusión: Tamizaje Clínico, Señales de Alerta y Derivación Interdisciplinaria
- Práctica de Laboratorio: Cálculo de Disponibilidad Energética, Auditoría RED-S y Caja de Herramientas
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA. Esta estructura es responsiva en dispositivos móviles, compatible con lectores de pantalla y diseñada para un acceso equitativo.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 13 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 13 Required Readings: Disordered Eating & Low Energy Availability (RED-S) →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 13 Discussion: Spotting Disordered Eating & When to Refer →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 13 Coaching Sprint: Low Energy Availability in Active Clients →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 13 Lab: Energy Availability & Safe Fueling Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 13 Summary & Wrap-Up: Disordered Eating & Low Energy Availability (RED-S) →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
