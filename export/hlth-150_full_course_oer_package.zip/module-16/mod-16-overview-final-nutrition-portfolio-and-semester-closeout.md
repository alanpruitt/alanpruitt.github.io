# HLTH-150: Mod 16 Overview Final Nutrition Portfolio And Semester Closeout

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 16 Overview: Final Nutrition Portfolio & Semester Closeout

El Porqué del Módulo 16 (Círculo Dorado — Contexto Norteño): “¿Por qué la alimentación con comida real es la base del rendimiento humano, y cómo demuestra tu Portafolio Final tu dominio de las Guías 2025–2030?”


### Module 16 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 16: Final Nutrition Portfolio & Semester Closeout

Welcome to Week 16, the official final work week of HLTH-150! Over the past sixteen weeks, you have journeyed from cellular bioenergetics and macronutrient metabolism to hydration kinetics, nutrient timing, ergogenic safety audits, energy balance, lifespan nutrition, and professional ethics. This final module focuses entirely on submitting your Comprehensive Final Capstone Practical Audit and Career Portfolio .

Important Operational Schedule: Module 16 officially opens on Monday, November 30, 2026, at 12:00 AM and concludes on Friday, December 4, 2026, at 11:59 PM . Final course grades will be officially submitted by faculty on Monday, December 7, 2026 .

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will consolidate your capstone artifacts, demonstrate professional readiness, and transition into your career or advanced academic pursuits.


### Final Week Schedule & Deadlines / Horario y Fechas Límite Finales

- Module 16 Opens / Apertura: Monday, November 30, 2026, at 12:00 AM MST
- Final Capstone Practical & Portfolio Due: Friday, December 4, 2026, at 11:59 PM MST (End of Term)
- Faculty Grade Submission: Monday, December 7, 2026, at 12:00 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 16 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Synthesize comprehensive case studies across bioenergetics, hydration, nutrient timing, and energy balance into a cohesive capstone artifact. Sintetizar estudios de caso integrales en un artefacto capstone cohesivo.
- CLO 2 (Rule Application): Integrate federal PAGA 2018 and DGA standards with professional scope of practice, ethical conduct, and secure AI auditing protocols. Integrar las normas federales de PAGA 2018 y DGA con el ámbito de práctica y protocolos de auditoría de IA.
- CLO 3 (Problem Solving): Present a professional capstone portfolio showcasing evidence-based health and exercise prescriptions ready for real-world deployment. Presentar un portafolio capstone profesional que demuestre prescripciones basadas en evidencia listas para el entorno real.

### Build Your Own Journey • Capstone Portfolio Pathways

Your final capstone portfolio reflects your chosen professional pathway throughout the semester:

Compiling clinical case audits, rehabilitation protein pacing, diuretic hydration protocols, and sarcopenia prevention plans.

Compiling budget-friendly whole-food nutrition plans, OSHA heat safety protocols, and community wellness initiatives in Yuma County.

Compiling strength athlete protein pacing, sweat rate biometrics, nutrient timing windows, and NSF-certified supplement audits.


### Module 16 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Final Schedule (You are here!)
- Required Readings: Capstone Integration & Professional Standards
- Lab Assignment: Final Capstone Practical Audit & Gemini AI Tool Kit Submission
- Official Course Completion & Grade Finalization
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 16 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 16 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 16 (Mod 16 Overview: Final Nutrition Portfolio & Semester Closeout)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 16 Visión General: Práctica Capstone Final


### Bienvenido al Módulo 16: Práctica Capstone Final y Calificaciones

¡Bienvenido a la Semana 16, la última semana de trabajo oficial de HLTH-150! Este módulo se centra en enviar su Auditoría Práctica Capstone Final y Portafolio Profesional .

Cronograma Operativo: El Módulo 16 abre el lunes 30 de noviembre de 2026 a las 12:00 AM y cierra el viernes 4 de diciembre de 2026 a las 11:59 PM . Las calificaciones finales serán enviadas el lunes 7 de diciembre de 2026 .

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , consolidará sus artefactos capstone para la práctica profesional.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 16 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 16 Required Readings: Final Nutrition Portfolio & Semester Closeout →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 16: Final Nutrition Portfolio & Case Defense →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
