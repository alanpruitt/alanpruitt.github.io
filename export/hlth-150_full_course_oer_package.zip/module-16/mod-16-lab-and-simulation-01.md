# HLTH-150: Mod 16 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 16 Capstone Simulation: Final Nutrition Portfolio & Case Defense

- Integrated TDEE, AMDR & Per-Kg Macronutrient Synthesis: Aligning total daily calories with both percentage AMDR boundaries and exact g/kg/day carbohydrate and protein targets for the client's activity level. En palabras sencillas: Cuadrar las calorías del día con los gramos exactos de carbohidrato, proteína y grasa que pide el nivel de actividad de tu cliente.
- Desert Thermoregulatory Hydration & Sodium Safety Gate: Embedding pre-, intra-, and post-session fluid and whole-food sodium targets tailored to Yuma / Imperial Valley environmental heat. En palabras sencillas: Incluir siempre el plan de agua y electrolitos con alimentos reales para proteger al cliente del calor de Yuma.
- Scope-of-Practice & Registered Dietitian (RD) Referral Defense: Explicitly documenting where general sports/wellness nutrition coaching ends and when a clinical referral to an RD or physician is triggered. En palabras sencillas: Dejar por escrito con claridad nuestro alcance profesional y cuándo referir al cliente con un nutriólogo clínico (RD) o médico.

### Lab Overview: Semester Synthesis, Practical Auditing & Capstone Portfolio Integration

In this final laboratory practical, you will consolidate your semester-long mastery by executing a comprehensive, multi-system nutrition and exercise audit. Drawing upon energy systems, macronutrient distribution, hydration kinetics, nutrient timing, ergogenic safety, energy balance, and lifespan nutrition, you will solve a complex, multi-variable client case study.

You will apply the Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in federal standards ( PAGA 2018 and DGA ) and use the Gemini AI Tool Kit with secure triple-hash delimiters (###) to finalize your professional capstone portfolio across your chosen career track.


### Lab Logistics & Final Deadlines / Horario y Condiciones

- Module 16 Operates: Monday, Nov 30 to Friday, Dec 4, 2026 (End of Term)
- Final Lab Due Date: Friday, December 4, 2026, at 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry
- Points / Puntos: 100 Total Points (Comprehensive Final Practical Rubric)
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Part A: Choose Your Career Track & Comprehensive Final Case File

Select the comprehensive final scenario corresponding to your chosen professional pathway:

Client: 66-year-old outpatient physical therapy patient managing mild hypertension with thiazide diuretics and sarcopenic obesity. Data: Mass: 78.0 kg | Height: 168 cm | Age: 66 | Current intake: High sodium restriction, low protein (0.8 g/kg), fasted morning therapy sessions with dizziness and cramping.

Client: 35-year-old agricultural field supervisor in Yuma County managing harvest crews in 108°F heat. Data: Mass: 82.0 kg | Height: 172 cm | Shift: 8 hours outdoors | Current hydration: Plain water only; afternoon fatigue, heat cramps, and reliance on unverified online weight-loss pills.

Client: 21-year-old collegiate distance runner and cross-country athlete (AWC Matadors) training in the desert. Data: Mass: 64.0 kg | Height: 178 cm | Mileage: 65 miles/week | Sweat rate: 1.6 L/hr | Presenting with chronic DOMS, early fatigue, and low energy availability (26 kcal/kg FFM/day).


### Part B: Clinical Framing Protocol (Pattern / Rule / Solve) Comprehensive Audit

Execute the following comprehensive audit step-by-step for your selected track:

- Pattern Recognition (Biometric & Nutritional Audit): Identify all metabolic bottlenecks, hydration deficits, timing errors, and dietary shortfalls in the client scenario.
- Rule Application (Federal SSoT Standards): Audit client metrics against PAGA 2018, DGA, ACSM, and IOC standards (e.g., 2.0% mass loss threshold, leucine trigger, 30 kcal/kg FFM/day EA).
- Problem Solving (Prescription Formulation): Formulate a comprehensive 3-phase nutritional and exercise prescription utilizing whole foods, proper hydration, nutrient timing, and scope-of-practice boundaries.
- Professional Portfolio Integration: Assemble your final portfolio reflection and bilingual professional capstone statement.

### Part C: Gemini AI Tool Kit & Final Practical Audit

Copy the prompt template below into Gemini AI to audit your comprehensive final practical. All clinical inputs must remain enclosed within triple-hash delimiters (###):

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: HLTH-150 Final Practical Tool Box ###:
Role: Clinical Sports Dietitian and Senior Curriculum Auditor.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Audit the student's comprehensive final practical audit across bioenergetics, hydration, nutrient timing, ergogenic aids, energy balance, and lifespan nutrition.
Step 2: Evaluate the student's adherence to federal SSoT standards (PAGA 2018 / DGA), scope of practice boundaries, and secure delimiter protocol (###).
Step 3: Formulate final commendations and professional readiness feedback.

Client Data Input ###:
Career Track: [Insert Track 1, 2, or 3]
Client Case Summary: [Insert summary of client biometric and dietary bottlenecks]
Student Clinical Framing Protocol (Pattern / Rule / Solve) Analysis (Pattern / Rule / Solve): [Insert student summary]
Student Comprehensive Prescription: [Insert student prescription summary]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Submission Template

Copy and paste the template below into the Canvas text entry submission box to complete your final Lab assignment and Capstone Portfolio:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
HLTH-150 Module 16 Final Practical Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]

Step 1: Comprehensive Pattern Recognition (Biometric & Dietary Audit):
Key Point: Client Profile & Presenting Bottlenecks:
Key Point: Key Metabolic & Physiological Deficits Identified:

Step 2: Rule Application (Federal SSoT Standards - PAGA 2018 / DGA):
Key Point: Evaluation against ACSM, DGA, PAGA 2018, and IOC standards:
Key Point: Scope of practice boundaries and interdisciplinary referral requirements:

Step 3: Problem Solving & Comprehensive Final Prescription:
Key Point: Whole-Food Nutrition & Protein Pacing Strategy:
Key Point: Hydration, Electrolyte & Nutrient Timing Strategy:
Key Point: Safety Audit, Supplement Verification & Lifespan Considerations:

Step 4: Final Career Capstone Artifacts & Bilingual Statement:
Key Point: Summary of semester portfolio artifacts included:
Key Point: Bilingual Professional Capstone Statement (English & Spanish):

Step 5: AI Tool Kit Audit Reflection:
Key Point: Summary of Gemini AI's final audit of your practical case and delimiter compliance:
End Submission ###:
```


### Comprehensive Final Practical Grading Rubric (100 Points Total)

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 16 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 16 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 16 (Mod 16: Final Nutrition Portfolio & Case Defense)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 16 Lab: Auditoría Práctica Capstone Final Integral


### Visión General del Laboratorio: Síntesis Semestral y Portafolio Capstone

En esta práctica de laboratorio final, consolidará su dominio semestral ejecutando una auditoría integral de nutrición y ejercicio. Aprovechando sistemas energéticos, macronutrientes, hidratación, sincronización, ergogénicos, balance energético y nutrición vital, resolverá un caso de estudio complejo.

Aplicará el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) anclado en normas federales ( PAGA 2018 y DGA ) y utilizará la Caja de Herramientas de IA Gemini con delimitadores seguros (###) para finalizar su portafolio capstone en su ruta elegida.


### Logística de Laboratorio y Fechas Límite Finales

- Operación del Módulo: Del lunes 30 de noviembre al viernes 4 de diciembre de 2026 (Fin de Término)
- Fecha Límite Final: Viernes, 4 de diciembre de 2026, a las 11:59 PM MST
- Formato: Entrada de texto directa en Canvas
- Puntaje: 100 Puntos Totales (Rúbrica de Práctica Final Capstone)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Seleccione su Ruta Profesional y Caso Práctico Capstone

Elija el escenario capstone final correspondiente a su trayectoria vocacional:

Paciente: Paciente de 66 años en fisioterapia con hipertensión (diuréticos) y obesidad sarcopénica. Datos: Masa: 78.0 kg | Altura: 168 cm | Edad: 66 | Ingesta: Restricción de sodio, baja proteína (0.8 g/kg), sesiones matutinas en ayunas con mareos.

Trabajador: Supervisor agrícola de 35 años en Yuma gestionando cuadrillas a 42°C (108°F). Datos: Masa: 82.0 kg | Altura: 172 cm | Jornada: 8 horas al aire libre | Hidratación: Solo agua simple; fatiga vespertina, calambres y uso de pastillas de pérdida de peso en línea.

Atleta: Corredor de fondo universitario (AWC Matadors) entrenando en el desierto. Datos: Masa: 64.0 kg | Altura: 178 cm | Millas: 65 mi/semana | Tasa de sudor: 1.6 L/h | Presenta dolor muscular crónico, fatiga y baja disponibilidad energética (26 kcal/kg FFM/día).


### Parte B: Auditoría Capstone Integral del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

Ejecute la siguiente auditoría capstone integral paso a paso para su ruta seleccionada:

- Reconocimiento de Patrones (Auditoría Biométrica y Nutricional): Identifique todos los cuellos de botella metabólicos, déficits hídricos y errores dietéticos en el caso.
- Aplicación de Reglas (Normas Federales SSoT): Audite las métricas del cliente frente a PAGA 2018, DGA, ACSM y COI (ej. umbral de 2%, disparador de leucina, EA de 30 kcal/kg).
- Resolución de Problemas (Formulación de Prescripción): Formule una prescripción nutricional y de ejercicio integral en 3 fases usando alimentos integrales y límites éticos de práctica.
- Integración al Portafolio Capstone: Ensamble su reflexión final y declaración profesional capstone bilingüe.

### Parte C: Caja de Herramientas de IA Gemini y Auditoría Capstone Final

Copie la siguiente plantilla en Gemini IA para auditar su práctica capstone final. Recuerde mantener los datos clínicos cerrados con delimitadores seguros (###):

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Safety Auditor Protocol: HLTH-150 Final Practical Tool Box ###:
Rol: Dietista Deportivo Clinico y Auditor Curricular Senior.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Auditar la práctica capstone final integral del estudiante en bioenergética, hidratación, sincronización, ergogénicos, balance energético y nutrición vital.
Step 2: Evaluar el apego a las normas federales SSoT (PAGA 2018 / DGA), límites del ámbito de práctica y protocolo de delimitadores (###).
Step 3: Formular recomendaciones finales y retroalimentación de preparación profesional.

Entrada de Datos del Cliente ###:
Ruta Profesional: [Insertar Ruta 1, 2 o 3]
Resumen del Caso: [Insertar resumen de biométricas y cuellos de botella]
Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Rule / Solve): [Insertar resumen del estudiante]
Prescripción Integral del Estudiante: [Insertar resumen de prescripción]
Fin de Datos del Cliente ###:
End Safety Auditor Protocol ###:
```


### Plantilla de Entrega

Copie y pegue la siguiente plantilla en Canvas para enviar su tarea de laboratorio y portafolio capstone:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
HLTH-150 Entrega Práctica Capstone Módulo 16 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clínica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]

Step 1: Reconocimiento de Patrones Integral (Auditoría Biométrica y Nutricional):
Key Point: Perfil del Cliente y Cuellos de Botella:
Key Point: Principales Déficits Metabólicos y Fisiológicos Identificados:

Step 2: Aplicación de Reglas (Normas Federales SSoT - PAGA 2018 / DGA):
Key Point: Evaluación frente a normas ACSM, DGA, PAGA 2018 y COI:
Key Point: Límites del ámbito de práctica y requisitos de derivación interdisciplinaria:

Step 3: Resolución de Problemas y Prescripción Capstone Final:
Key Point: Estrategia Nutricional con Alimentos Integrales y Distribución Proteica:
Key Point: Estrategia de Hidratación, Electrolitos y Sincronización:
Key Point: Auditoría de Seguridad, Verificación de Suplementos y Consideraciones Vitales:

Step 4: Artefactos del Portafolio Capstone y Declaración Bilingüe:
Key Point: Resumen de artefactos del portafolio semestral incluidos:
Key Point: Declaración Profesional Capstone Bilingüe (Inglés y Español):

Step 5: Reflexion de la Auditoria con IA:
Key Point: Resumen de la revisión final de Gemini IA y cumplimiento de delimitadores:
Fin de la Entrega ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 16 Quick Return Navigation / Regreso Rápido al Módulo 16:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
