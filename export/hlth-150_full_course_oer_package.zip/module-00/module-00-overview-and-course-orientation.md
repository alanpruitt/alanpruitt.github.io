## HLTH-150: Module 00 Overview And Course Orientation

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Module 00 Overview & Course Orientation


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Module 00 is your permanent, semester-long Ready Reference Guide for HLTH-150. It walks you through our weekly schedule, how to use AI safely as a clinical calculator, and how to revise any assignment for a full 10 / 10 score. Because this module stays open all 16 weeks, bookmark it and return whenever you need a quick refresher or example.


#### En Palabras Sencillas (Norteño Context)

Piensa en el Módulo 00 como el manual de guantera de tu troca: siempre está abierto durante todo el semestre por si ocupas checar un ejemplo o cómo subir una calificación a 10 / 10. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar Patrón / Regla / Solución para cuidar la seguridad de tu cliente.


### Module 00 Golden Circle Roadmap (WHY → HOW → WHAT) / Ruta del Módulo 00

In Plain English: Just like every weekly module in HLTH-150 , Module 00: Welcome: Start Here is organized from the inside out using Simon Sinek’s Golden Circle (Ring 1: THE WHY → Ring 2: THE HOW → Ring 3: THE WHAT) paired with our Clinical Framework ( Pattern / Rule / Solve ) . Click any item below to jump directly to that orientation step:

En Palabras Sencillas: Este Módulo 00 sigue exactamente el mismo orden del Círculo Dorado (EL PORQUÉ → EL CÓMO → EL QUÉ) que verás cada semana: primero el propósito y contexto regional de Yuma ( 0.1–0.3 ), luego las reglas de calificación 10-7-0 y los simuladores gratuitos paga2018.dev y exwtoolkit.com ( 0.4–0.6 ), y finalmente tu configuración práctica para arrancar el Módulo 01 ( 0.7–0.10 ).

Welcome to HLTH-150: Nutrition for Sports and Exercise ! This introductory Module prepares you for academic success by grounding your learning in evidence-based nutrition science. You will review course expectations, set up your digital AI learning portfolio, and learn to evaluate metabolic bioenergetics using federal dietary standards over commercial fad trends.

¡Bienvenido a HLTH-150: Nutrición para el Deporte y el Ejercicio ! Este módulo de inducción le preparará para el éxito académico al fundamentar su aprendizaje en la ciencia de la nutrición basada en evidencia. Revisará las expectativas del curso, configurará su portafolio digital de IA y aprenderá a evaluar la bioenergética metabólica utilizando estándares dietéticos federales en lugar de modas comerciales.


### Module Learning Objectives / Objetivos de Aprendizaje

- Navigate the Canvas course environment, Syllabus parameters, and course grading structure. Navegar por el entorno del curso en Canvas, así como por los parámetros del programa de estudios y la estructura de evaluación.
- Set up the cloud-based Google Drive repository ( EXW_Professional_AI_Repository ) for exporting AI prompt logs and nutritional audits. Configurar el repositorio en Google Drive para exportar los registros de instrucciones de IA y de auditorías nutricionales.
- Differentiate federal dietary benchmarks (DGA & PAGA) from unverified commercial supplement claims. Diferenciar los estándares dietéticos federales (DGA y PAGA) de las afirmaciones comerciales no verificadas.

### Course Learning Outcomes & Assessment Roadmap (AY26-27)

These official Arizona Western College institutional outcomes represent the core nutrition and exercise physiology competencies you will master and demonstrate across our benchmark milestones:

- HLTH-150.2.1.AY26-27: Discover how your body powers movement! Learn how energy demands change across light, moderate, and vigorous activities, and see how proper sports nutrition fuels performance, recovery, and overall health.
- HLTH-150.2.2.AY26-27: Master the science of hydration! Learn how sweat rates and exercise intensity change your fluid needs, and discover evidence-based strategies to prevent dehydration and optimize athletic performance.
- HLTH-150.2.3.AY26-27: Fuel athletic performance with smart nutrition! Discover the essential carbs, proteins, fats, vitamins, and minerals your body needs to maximize workout energy, accelerate recovery, and support long-term health.
- HLTH-150.2.4.AY26-27: Connect your plate to your performance! Discover how balanced, evidence-based nutrition syncs with your training cycle to maximize workout power, speed up muscle recovery, and reach peak athletic goals.
- HLTH-150.2.7.AY26-27: Master the science of nutrient timing! Learn when to eat and hydrate before, during, and after exercise to sustain energy, prevent fatigue, and accelerate muscle recovery for peak performance.
- HLTH-150.2.5.AY26-27: Separate nutrition facts from fads! Explore the science of healthy weight management, energy balance, and body composition to safely fuel athletic potential while maintaining peak physical performance.
- HLTH-150.2.6.AY26-27: Separate fact from marketing hype! Explore the science behind sports supplements—evaluating the proven benefits, hidden risks, and safety standards so you can make informed, evidence-based choices.

### Module 00 Task Checklist / Lista de Tareas:

- Read the complete Course Syllabus and Grading Policy. Lea el programa de estudios completo y las políticas de evaluación.
- Review and complete the Student Orientation Verification Self-Check below. Revise y complete la verificación de inducción a continuación.
- Create your Google Drive repository folder ( EXW_Professional_AI_Repository ). Cree su carpeta de repositorio en Google Drive.

### Student Orientation Verification Self-Check / Autoevaluación de Inducción

Click or tap each question to reveal the verification response and confirm your readiness for HLTH-150.

HLTH-150 Module 00 Ready-Reference Scaffold • Zero-Cost OER Clinical Web Apps


### Plain-English Guide: Simulations & Simulators ( paga2018.dev + exwtoolkit.com )

Guía Permanente del Módulo 00 en Palabras Sencillas: Cómo Usar los Simuladores, Activity Audit, Case Coach y Cuadros de Casos ( ### )


#### In Plain English (60-Second Cheat Sheet)

Before you read the details below, here is the short version: Throughout HLTH-150, you use two free, zero-login web apps located right in your left-hand Canvas Course Navigation menu— paga2018.dev (“PAGA”) and exwtoolkit.com (“Toolkit”)—to test client scenarios against 2025–2030 Dietary Guidelines for Americans ('Real Food' Focus) & PAGA 2018 and build your weekly assignments. You never need to create an account or memorize every button. Bookmark this Module 00 guide and use the breakdown below whenever you open a weekly Coaching Sprint (Stage 1) or Clinical Lab (Stage 2) .

En Palabras Sencillas (Contexto Norteño): Hablando claro, equipo: durante todo HLTH-150 usamos dos herramientas gratuitas y sin contraseña que están directo en el menú izquierdo de Canvas— “PAGA” ( paga2018.dev ) y “Toolkit” ( exwtoolkit.com ). Si los términos técnicos se ponen pesados, concéntrate primero en la tabla de 2 etapas aquí abajo: el micro-simulador integrado es para tu Coaching Sprint y las aplicaciones completas son para tu Laboratorio Clínico .


#### Part 1: Four Key Features Inside paga2018.dev (“PAGA” in Left Course Menu)

Step 1 — Triple-Hash ( ### ) Case Modals & “Load Example”

Tools on paga2018.dev only analyze lines placed between opening ### and closing ### markers . Above every input box, a side-by-side Example Case Modal explains each line, and the “Load example” button loads a working sample in 1 click.

Step 2 — Activity Audit ( /activity-audit )

Includes a 3-question interactive warm-up (covering the PAGA 2018 2-for-1 Rule where 1 vigorous minute counts as 2 moderate minutes) plus “Audit my week” to check aerobic ( 150–300 min/week ), strength ( >=2 days/week ), and balance targets.

Step 3 — HLTH-150 Coach & SSoT Lookup Modals

Paste your ### client case into Nutrition Coach (paga2018.dev/nutrition-coach) & USOPC Athlete Plates (/athlete-plates) and click Analyze case for a structured Pattern / Rule / Solve audit. Companion modals: USOPC Athlete Plates (/athlete-plates) • Activity Audit (/activity-audit) .

Step 4 — 4-Part Builder & My Dashboard

Click “Save to My Dashboard” (100% private browser storage, zero login required) and use the built-in 4-Part Canvas Submission Builder with live 150-word counters for Part 2 (Audit) and Part 3 (Active Verification) plus 1-click “Copy for Canvas” .


#### Part 2: Two-Stage Weekly Simulation Workflow ( exwtoolkit.com vs. paga2018.dev )


#### Resumen Rápido en Español (Contexto Norteño): paga2018.dev y exwtoolkit.com

- Cuadros de Casos con Signos ### y “Load example”: En paga2018.dev el sistema solo analiza lo que está entre la línea ### inicial y la línea ### final . Usa el botón “Load example” para probar primero un caso de muestra con 1 clic.
- Etapa 1 — Coaching Sprint ( X.4 [EL CÓMO] ): Usa el micro-simulador integrado dentro de tu página de Canvas hasta que el letrero cambie a VERIFIED y presiona Copy Verification Receipt .
- Etapa 2 — Laboratorio Clínico ( X.5 [EL QUÉ] ): Abre “Toolkit” ( exwtoolkit.com ), revisa la bandera de calor en vivo de MCAS Yuma ( KNYL ) , sigue la ruta ( 1. Caja de Biometría → 3. Caja de Combustible (TDEE, Calorías y Macros) → 4. Seguridad / 7. Recuperación → 9. Caja de Solución (“Copy for Canvas Submission”) ) y apóyate en Nutrition Coach (paga2018.dev/nutrition-coach) y Platos del Atleta USOPC (/athlete-plates) para verificar tus citas de Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales') y PAGA 2018 .
Semester-Long Ready Reference / Guía de Consulta Permanente: Module 00 remains unlocked all semester long. Bookmark this section and return whenever you want to check the 150-word minimum Active Verification (Part 3) Exemplar or the 4-Step Remedy Roadmap for upgrading a grade to 10 / 10.


### ACTIVE VERIFICATION (PART 3): WHAT IT IS, WHY WE USE IT, & 10/10 STUDENT EXEMPLARS


#### Step 1: What is "Active Verification"? / ¿Qué es la "Verificación Activa"?

In Plain English: The Active Verification is Part 3 of every Lab and Coaching Sprint submission under our Four-Part Submission Standard (following Part 1: The Engine Prompt with ### Delimiters and Part 2: The 150-Word Minimum Clinical Audit , and verified against Part 4: The 10/10 Student Exemplar ). It is a mandatory 150-word minimum paragraph written entirely in your own human voice (never written or polished by AI) where you justify why your clinical intervention is safe and realistic for a real person in Yuma, Arizona or the Imperial Valley , backed by our Academic Source of Truth ( 2025–2030 Dietary Guidelines for Americans ('Real Food' Focus) ).

En Palabras Sencillas (Norteño-Spanish): La Verificación Activa es la Parte 3 de cada Laboratorio y Sprint de Entrenamiento (después de la Parte 1: Instrucción con Delimitadores ### y la Parte 2: Auditoría Clínica de 150 Palabras ). Es un párrafo obligatorio de mínimo 150 palabras escrito totalmente con tu propia voz humana (nunca redactado por IA) donde justificas por qué tu plan es seguro y realista para una persona real en Yuma o el Valle Imperial , respaldado por nuestra Fuente Única de Verdad.


#### Step 2: Why Do We Use It? (The Clinical Framework: Pattern / Rule / Solve) / ¿Por qué la usamos?

In Plain English: In modern healthcare and kinesiology, AI is the calculator (The Engine), and you are the Architect (The Pilot) . An AI chatbot has never stood on a 112°F (44.4°C) Yuma sidewalk, has never coached an early-morning agricultural worker in San Luis or Somerton, and cannot take legal or ethical responsibility for a patient's safety. We use the Active Verification (Part 3) so you prove that a real human professional audited the local environment, checked the federal safety rules, and made the final clinical decision using Pattern / Rule / Solve (Patrón / Regla / Solución) .

En Palabras Sencillas (Norteño-Spanish): En la salud y el entrenamiento moderno, la IA es la calculadora (El Motor) y tú eres el Arquitecto Clínico (El Piloto) . Un chatbot de IA nunca ha sentido el calor de 112°F en una banqueta de Yuma ni conoce el ritmo de trabajo agrícola de nuestra gente en San Luis o Somerton. Usamos la Verificación Activa (Parte 3) para demostrar que un profesional humano real tomó la decisión final de seguridad aplicando Patrón / Regla / Solución .


#### Step 3: What It Looks Like: Your Course 10 / 10 Active Verification Exemplar

"In my own words, I overrode the AI's meal plan because it recommended expensive commercial pre-workout powders and sweetened sports drinks that violate our client's budget and blood sugar goals here in Somerton. Using Pattern / Rule / Solve, the Pattern is a 38-year-old agricultural packing-shed worker experiencing afternoon fatigue, high sodium intake from fast food, and chronic dehydration during 106°F (41.1°C) shifts. The Rule under the 2025–2030 Dietary Guidelines for Americans ('Real Food' Focus) prioritizes whole, nutrient-dense foods, plain water as the primary beverage, and limiting added sugars to less than 10% of daily calories. My Solve replaces her sugary afternoon energy drink and ultra-processed snack bar with 24 ounces of ice water, a homemade pinto bean and grilled chicken burrito on a whole-corn tortilla, and sliced jicama with lime—giving her steady complex carbohydrates, complete protein, and natural electrolytes from affordable local groceries."

Español (Regional): "En mis propias palabras, corregí el plan de comidas de la IA porque recomendaba polvos comerciales caros y bebidas deportivas azucaradas que afectan el presupuesto y la glucosa de nuestra clienta en Somerton. Usando Patrón / Regla / Solución, el Patrón es una trabajadora de empaque agrícola de 38 años con fatiga vespertina, alto consumo de sodio en comida rápida y deshidratación durante turnos a 106°F (41.1°C). La Regla de las Pautas Dietéticas para Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales') prioriza alimentos integrales ricos en nutrientes, agua natural como bebida principal y limitar los azúcares añadidos a menos del 10% de las calorías diarias. Mi Solución reemplaza su bebida energética azucarada con 24 onzas de agua fría, un burrito casero de frijoles pintos y pollo asado en tortilla de maíz integral, y jícama con limón."

"In my own words, I rejected the AI's suggestion to have my 54-year-old Yuma construction client jog outdoors at 4:00 PM because the ambient temperature is still 108°F (42.2°C), which creates an immediate heat-illness hazard. Following the Pattern / Rule / Solve protocol, the Pattern is a deconditioned outdoor worker with high occupational heat exposure and zero structured aerobic history. The Rule from the 2018 Physical Activity Guidelines for Americans (PAGA, Chapter 4) states that adults should accumulate 150 to 300 minutes per week of moderate-intensity aerobic activity (3.0 to 5.9 METs), and that starting with shorter, tolerable bouts is safest for inactive adults. My Solve moves his brisk walking sessions indoors to the air-conditioned AWC track or mall before work for 25 minutes, six days a week (150 minutes/week total), using the Talk Test (able to speak in full sentences) to keep his intensity safely moderate."

Español (Regional): "En mis propias palabras, rechacé la sugerencia de la IA de poner a mi cliente de construcción de 54 años en Yuma a trotar al aire libre a las 4:00 PM porque la temperatura ambiente sigue en 108°F (42.2°C), lo que crea un peligro inmediato de golpe de calor. Siguiendo el protocolo Patrón / Regla / Solución, el Patrón es un trabajador al aire libre desacondicionado con alta exposición al calor ocupacional. La Regla de las Pautas de Actividad Física para Estadounidenses de 2018 (PAGA, Capítulo 4) establece que los adultos deben acumular de 150 a 300 minutos por semana de actividad aeróbica moderada (3.0 a 5.9 METs). Mi Solución traslada sus caminatas a paso rápido bajo techo con aire acondicionado antes del trabajo durante 25 minutos, seis días a la semana (150 minutos/semana en total), usando la Prueba del Habla para mantener una intensidad moderada y segura."

"In my own words, I modified the AI's 8-week accelerated training plan for our 46-year-old San Luis elementary teacher because it scheduled 75-minute outdoor runs on back-to-back afternoons at 104°F (40.0°C) with zero strength training. Using the Pattern / Rule / Solve clinical framework, the Pattern is an inactive commuter experiencing afternoon heat fatigue and mild lower-back stiffness from standing on concrete classrooms all day. The Rule from the 2018 Physical Activity Guidelines for Americans (PAGA, 2nd Edition, Chapter 4) mandates 150 to 300 minutes per week of moderate-intensity aerobic activity (3.0 to 5.9 METs) paired with muscle-strengthening activities involving all major muscle groups on 2 or more days per week. My Solve splits her weekly movement into five 30-minute indoor brisk walks at 6:00 AM (150 minutes/week at Borg RPE 12) plus Tuesday and Friday 20-minute resistance-band core and lower-body circuits in air conditioning."

Español (Regional): "En mis propias palabras, modifiqué el plan acelerado de 8 semanas que generó la IA para nuestra maestra de primaria de 46 años en San Luis porque programaba carreras al aire libre de 75 minutos por la tarde a 104°F (40.0°C) sin nada de fuerza muscular. Usando el protocolo Patrón / Regla / Solución, el Patrón es una trabajadora sedentaria con fatiga por el calor vespertino y rigidez lumbar. La Regla de las Pautas de Actividad Física para Estadounidenses de 2018 (PAGA, 2.ª ed., Capítulo 4) exige acumular de 150 a 300 minutos semanales de actividad aeróbica moderada (3.0 a 5.9 METs) más al menos 2 días por semana de fortalecimiento muscular en todos los grupos principales. Mi Solución organiza cinco caminatas rápidas bajo techo de 30 minutos a las 6:00 AM (150 minutos/semana en RPE 12) más dos sesiones semanales de 20 minutos con ligas de resistencia en clima fresco."

"In my own words, I rejected the AI's Phase 4 heavy barbell back-squat prescription for our 36-year-old Yuma client in Gymnasium (GY) Room 116 because it ignored his Overhead Squat Assessment (OHSA) compensations. Applying Pattern / Rule / Solve, the Pattern observed during his Overhead Squat Assessment (OHSA) shows medial knee valgus and an excessive low-back arch driven by overactive adductors and hip flexors paired with underactive gluteus medius and intrinsic core stabilizers. The Rule integrating the NASM Optimum Performance Training (OPT) Model, ACSM 12th Edition, and PAGA 2018 mandates beginning in Phase 1 Stabilization Endurance (12–20 reps at a controlled 4-2-1 tempo) with Corrective Flexibility before heavy loading. My Solve coaches 30-second foam rolling and static stretching of his calves, adductors, and hip flexors, followed by lateral tube walks and 4-2-1 goblet box squats in air-conditioned GY Room 116 using external cues ('push the floor apart') to lock in safe knee alignment."

Español (Regional): "En mis propias palabras, rechacé la rutina de sentadilla pesada con barra en Fase 4 que sugirió la IA para nuestro cliente de 36 años en el Gimnasio (GY) Salón 116 porque ignoró sus compensaciones en la Evaluación de Sentadilla con Brazos Arriba (OHSA). Aplicando Patrón / Regla / Solución, el Patrón observado durante su Evaluación de Sentadilla (OHSA) muestra valgo medial de rodilla y arco lumbar excesivo por aductores y flexores de cadera hiperactivos junto con glúteo medio y core hipoactivos. La Regla del Modelo OPT de NASM, ACSM 12.ª Edición y PAGA 2018 exige iniciar en la Fase 1 de Estabilización (12 a 20 repeticiones con tempo controlado 4-2-1) y flexibilidad correctiva antes de cargar peso máximo. Mi Solución aplica 30 segundos de rodillo de espuma y estiramiento estático seguidos de caminatas laterales con liga y sentadillas goblet a cajón 4-2-1 en el GY 116."

"In my own words, the AI made a dangerous physiological error by prescribing high-intensity interval sprints on day one and miscalculating target heart rate using standard age-predicted formulas without accounting for the client's resting vitals. Applying Pattern / Rule / Solve, the Pattern is a 49-year-old sedentary Yuma office manager (BMI 31.2 kg/m², resting BP 134/86 mmHg, Resting Heart Rate 78 bpm) with no signs or symptoms of cardiovascular, metabolic, or renal disease. The Rule under the ACSM Guidelines for Exercise Testing and Prescription (12th Edition, Chapter 2 Preparticipation Screening & Chapter 5 FITT-VP) requires starting sedentary, asymptomatic individuals at light-to-moderate intensity (40% to 59% HRR) before progressing to vigorous work. Using the Karvonen formula with an estimated HRmax of 171 bpm (220 - 49), his Heart Rate Reserve is 93 bpm (171 - 78). My Solve sets his initial indoor treadmill walking target between 115 and 133 bpm for 30 minutes, 5 days per week."

Español (Regional): "En mis propias palabras, la IA cometió un error fisiológico peligroso al prescribir sprints de alta intensidad desde el primer día y calcular mal la frecuencia cardíaca objetivo sin considerar los signos vitales en reposo. Aplicando Patrón / Regla / Solución, el Patrón es un gerente de oficina sedentario de 49 años en Yuma (IMC 31.2 kg/m², PA en reposo 134/86 mmHg, FCR 78 lpm) sin síntomas de enfermedad cardiovascular, metabólica o renal. La Regla según las Pautas de ACSM (12ª Edición, Capítulos 2 y 5 FITT-VP) exige iniciar a personas sedentarias asintomáticas en intensidad ligera a moderada (40% a 59% FCR/HRR). Usando la fórmula de Karvonen con una FCmáx estimada de 171 lpm (220 - 49), su Reserva de Frecuencia Cardíaca es 93 lpm (171 - 78). Mi Solución fija su caminata inicial en caminadora bajo techo entre 115 y 133 lpm durante 30 minutos, 5 días por semana."

"In my own words, I corrected the AI's output because it used a standard heart-rate zone formula (220 - age) for a 67-year-old Foothills retiree taking a daily beta-blocker (metoprolol) for hypertension and living with knee osteoarthritis. Under Pattern / Rule / Solve, the Pattern is an older adult whose medication blunts heart-rate response and creates orthostatic dizziness risk, especially when walking outdoors in 105°F (40.6°C) Yuma heat. The Rule from the 2018 Physical Activity Guidelines for Americans (Chapters 5 and 6) requires multicomponent physical activity—combining aerobic, muscle-strengthening, and balance training—while regulating intensity via Rating of Perceived Exertion (RPE 11 to 13 on the 6–20 Borg scale, or the Talk Test) whenever beta-blockers invalidate heart-rate targets. My Solve moves her sessions into an indoor pool and air-conditioned studio at 8:00 AM, pairing low-impact aquatic walking with seated chair-stand strength and tandem-stance balance drills plus a 10-minute gradual cool-down."

Español (Regional): "En mis propias palabras, corregí el resultado de la IA porque utilizó una fórmula estándar de frecuencia cardíaca (220 - edad) para una jubilada de 67 años en los Foothills que toma un betabloqueador diario (metoprolol) para la hipertensión y vive con osteoartritis de rodilla. Bajo Patrón / Regla / Solución, el Patrón es una adulta mayor cuyo medicamento atenúa la respuesta del pulso y crea riesgo de mareo ortostático, especialmente bajo el calor de 105°F (40.6°C) en Yuma. La Regla de PAGA 2018 (Capítulos 5 y 6) exige actividad física multicomponente—combinando ejercicio aeróbico, fuerza muscular y equilibrio—regulando la intensidad mediante el Esfuerzo Percibido (RPE 11 a 13 o la Prueba del Habla) cuando los betabloqueadores invalidan las fórmulas de pulso. Mi Solución traslada sus sesiones a una alberca bajo techo y estudio con aire acondicionado a las 8:00 AM, con enfriamiento gradual de 10 minutos."


### HOW TO REMEDY A 0 / 10 OR UPGRADE A 7 / 10 GRADE / CÓMO SUBIR TU NOTA A 10 / 10

In Plain English: In our courses, a score of 0 / 10 (Recalibrate) is never a permanent punishment—it is a clinical safety pause and an open invitation to fix and resubmit your work for full 10 / 10 (Exemplary) credit. Similarly, if you earn 7 / 10 (Competent) , you can revise the minor gap and resubmit for 10 / 10 . All Labs and Coaching Sprints have Unlimited Attempts and stay unlocked through the end of the semester.

En Palabras Sencillas (Norteño-Spanish): En nuestros cursos, un 0 / 10 (Recalibrar) nunca es un castigo definitivo; es una pausa de seguridad clínica y una invitación abierta para corregir y volver a entregar por el 10 / 10 completo. Igualmente, si sacas 7 / 10 (Competente) , puedes corregir el detalle señalado y subir a 10 / 10 . Todos los Laboratorios y Sprints tienen Intentos Ilimitados abiertos hasta el final del semestre.


#### Why an Assignment Receives 0 / 10 (Recalibrate) / ¿Por qué se asigna un 0 / 10?

- Unverified AI Copy-Paste: Submitting raw AI output without auditing its errors (Part 2) or omitting your 150-word minimum human Active Verification (Part 3) . / Entregar texto copiado de la IA sin auditar sus errores o sin tu Verificación Activa de mínimo 150 palabras.
- Clinical Safety Breach: Prescribing an unsafe intervention (e.g., midday outdoor running in 110°F Yuma heat, or ignoring client medications/contraindications). / Recomendar algo clínicamente peligroso (ej. correr al mediodía a 110°F en Yuma o ignorar medicamentos/contraindicaciones).
- Missing Required Section: Leaving out Part 1 (Engine Prompt with ### ), Part 2 (150-Word Clinical Audit), or Part 3 (150-Word Minimum Active Verification). / Omitir alguna de las partes obligatorias de la entrega.

#### The 4-Step Remedy Roadmap / Los 4 Pasos para Subir tu Calificación a 10 / 10

- Step 1 — Open Your Grades Tab in Canvas (Not the To-Do List): Once an assignment has a 0 / 10 or 7 / 10 score, Canvas removes it from your "To-Do" sidebar. Click Grades in the left course menu and click the assignment title directly. Paso 1 — Abre la pestaña Grades (Calificaciones): Cuando una tarea ya tiene calificación, desaparece de tu lista "Por hacer" (To-Do). Entra a Grades en el menú izquierdo y haz clic en el nombre de la tarea.
- Step 2 — Read Coach Alan's In Plain English SpeedGrader Feedback: Read the specific comment left on your submission (starting with "In plain English:" or "En palabras sencillas:" ) that tells you the exact clinical rule, calculation, or missing section to fix. Paso 2 — Lee el comentario de Coach Alan en SpeedGrader: Revisa la nota específica donde te indico exactamente qué regla clínica, cálculo o sección necesitas completar.
- Step 3 — Revise Only What Was Flagged: Update your submission using Pattern / Rule / Solve (Patrón / Regla / Solución) , cite our Academic Source of Truth, and verify that your Part 3 Active Verification is at least 150 words in your own human voice. Paso 3 — Corrige lo señalado: Ajusta tu entrega aplicando Patrón / Regla / Solución , cita la guía oficial y confirma que tu Verificación Activa tenga mínimo 150 palabras en tu propia voz.
- Step 4 — Click New Attempt and Resubmit: Click New Attempt (or Try Again ), paste or upload your updated work, and submit. Your revision automatically enters Coach Alan's grading queue to be upgraded to 10 / 10 (Exemplary) ! Paso 4 — Haz clic en New Attempt (Nuevo Intento) y envía: Tu entrega actualizada entra automáticamente a revisión para subir tu nota a 10 / 10 (Ejemplar) .

### Ask HLTH-150 Clinical SSoT Questions (Pattern / Rule / Solve + 10/10 Exemplars)

In Plain English: Before you read the details below, here is the short version: Type any question about HLTH-150, 2025–2030 Dietary Guidelines for Americans ('Real Food' Focus) & PAGA 2018, our ### case delimiters, or a module topic below (or click a suggested query chip) to search our verified course curriculum and 10/10 student exemplars in real time.

En Palabras Sencillas (Contexto Norteño): Escribe cualquier duda sobre HLTH-150, Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales') y PAGA 2018, los cuadros ### o las tareas semanales aquí abajo (o toca una pregunta sugerida) para consultar ejemplos 10/10 y reglas verificadas al instante.

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 00)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 00)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
