# HLTH-150: 0 2 Course Syllabus And Communication Guidelines

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición para el Deporte y el Ejercicio


## 0-2: Course Syllabus & Communication Guidelines / Plan de Estudios y Pautas de Comunicación


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: This page outlines our weekly rhythm, communication expectations, and how Coach Alan supports your progress all semester. New modules open on Tuesdays, Initial Discussion posts are due Thursdays, Peer Replies are due Sundays, and Labs are due Mondays at 11:59 PM. If life gets hectic in Yuma, reach out early in Canvas Inbox so we can keep you on track.


#### En Palabras Sencillas (Norteño Context)

Aquí están las reglas del juego y los días de entrega para que organices tu semana sin sorpresas entre el trabajo y la familia. Si los términos técnicos se ponen pesados, concéntrate primero en el calendario semanal (jueves foro inicial, domingo réplica, lunes laboratorio) y en escribirme si ocupas apoyo.


### THE NUTRITION COURSE CONTRACT

EL CONTRATO DEL CURSO DE NUTRICIÓN

- English: Do not download an outdated PDF copy. The active Canvas Syllabus page is our live, real-time contract. It is engineered to load instantly on any mobile screen or browser, keeping our sports nutrition policies, grading parameters, and federal SSoT guidelines completely transparent.
- Español (Regional): No descargue una copia en PDF obsoleta. El plan de estudios activo en Canvas es nuestro contrato en tiempo real. Está diseñado para cargarse de forma instantánea en cualquier pantalla o navegador móvil, manteniendo transparentes las políticas de nutrición y los parámetros de calificación.

### OFFICIAL COMMUNICATION PROTOCOLS

PROTOCOLOS OFICIALES DE COMUNICACIÓN

- English: Always message Coach Alan directly through the Canvas Inbox. Expect a professional response within 24 business hours. For emergency coordination regarding dietary log submission windows, refer to the communication map inside your Module materials.
- Español (Regional): Envíe siempre mensajes directamente a Coach Alan a través de la Bandeja de Entrada de Canvas. Espere una respuesta profesional en un plazo de 24 horas hábiles. Para la coordinación de emergencias relacionadas con la entrega de registros dietéticos, consulte el mapa de comunicación.

### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All course materials and Syllabus guidelines in HLTH-150 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools (e.g., Genio).

Español (Regional): Todos los materiales del curso y las pautas del plan de estudios de HLTH-150 siguen los principios del Diseño Universal para el Aprendizaje (UDL). Esta página utiliza un diseño centrado en texto y adaptado a dispositivos móviles, compatible al 100% con lectores de pantalla y sistemas de toma de notas con IA.

Process Over Product Evaluation / Evaluación de Proceso:

Course policies and communications are structured to emphasize clear dialogue, professional growth, and accessible learning support without administrative friction.

Accessibility Services • AccessABILITY Resource Services (ARS) / Servicios de Accesibilidad (ARS) :

AccessABILITY Resource Services (ARS) partners with students with disabilities, faculty, and staff to remove barriers in the educational process through thoughtful design and accommodations. Whether you’re scheduling tutoring sessions at the AT Lab, requesting accommodations through our system, or seeking resources to achieve your educational and career goals, our team is here to assist. Located in the College Community Center (3C) on the main campus, we are committed to helping students build self-advocacy skills, overcome obstacles, and succeed academically.

AccessABILITY Resource Services (ARS) colabora con estudiantes con discapacidades, profesores y personal para eliminar barreras en el proceso educativo mediante un diseño cuidadoso y adaptaciones. Ya sea que programe tutorías en el Laboratorio de Tecnología de Asistencia (AT Lab), solicite adaptaciones o busque recursos para alcanzar sus metas académicas y profesionales, nuestro equipo está para apoyarle en el College Community Center (3C) del campus principal.

Location: College Community Center (3C), Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu | Web: AWC Accessibility Services

Our course architecture directly mirrors federal workforce standards set by the U.S. Department of Labor AI Literacy Framework ( Employment and Training Administration Advisory: Training and Employment Notice No. 07-25 , issued February 13, 2026) and institutional equity mandates set by Arizona Western College :

- Step 1: Zero-Cost Equity & Digital Access (DOL Delivery Principle 4 • Equitable Access): All required AI prompts utilize open-access, zero-cost tools (e.g., Google Gemini, exwtoolkit.com , and paga2018.dev ). Mobile-first, text-based formatting ensures seamless access across low-bandwidth connections and mobile devices.
- Step 2: Experiential Context & Prompt Engineering (DOL Content Areas 1, 2 & 3 / Delivery Principles 1 & 2 / Clinical Framing Protocol (Pattern / Rule / Solve)): You learn AI by directing it inside authentic exercise science workflows. All prompt logs must be documented in your cloud repository ( EXW_Professional_AI_Repository ).
- Step 3: Human-in-the-Loop SSoT Auditing (DOL Content Areas 4 & 5 / Delivery Principle 3 / SSoT Rules): Generative AI models are probabilistic and prone to hallucinations. Submitting unverified AI output constitutes an academic integrity violation. You must audit all AI recommendations against our course Single Source of Truth (SSoT).
- Content Area 1 (Understand AI Principles) → The Centaur Protocol: You act as the Clinical Architect / Pilot ; AI serves strictly as a probabilistic calculator requiring verification.
- Content Area 2 (Explore AI Uses) → Coaching Sprints & Clinical Labs: Hands-on exposure to authentic occupational cases using exwtoolkit.com and paga2018.dev .
- Content Area 3 (Direct AI Effectively) → Part 1 (P-T-C-F Prompt Engineering): Structured Persona, Task, Context, and Format prompts wrapped in ### delimiters.
- Content Area 4 (Evaluate Outputs) → Part 2 (150-Word Clinical SSoT Audit): Auditing AI outputs against federal .gov SSoTs ( PAGA 2018 , DGA 2025–2030 , ACSM 12th Ed. , NASM OPT ).
- Content Area 5 (Use AI Responsibly) → Part 3 (150-Word Active Verification) & Traffic Light Policy: Defending clinical decisions in your own voice with zero PII exposure.
- Delivery Principles 1–7 (Community College Execution): Experiential slider calibration (1), Yuma / Imperial Valley borderland context (2), durable human skills via Pattern / Rule / Solve and Sinek’s Golden Circle (3), $0 ZTC OER & Norteño-Spanish HSI parity (4), stackable portfolio pathways (5), faculty enabling tools (6), and Curriculum-as-Code agility (7).
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
