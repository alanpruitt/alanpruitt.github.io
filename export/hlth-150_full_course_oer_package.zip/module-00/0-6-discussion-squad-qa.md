# HLTH-150: 0 6 Discussion Squad Qa

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición para el Deporte y el Ejercicio


## 0-6: COMM CHECK: SQUAD Q&A / CONTROL DE COMUNICACIÓN: PREGUNTAS Y RESPUESTAS

"Radio check. Over." / "Prueba de radio. Adelante."


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: The Squad Q&A is your open community lounge to ask course questions, share study tips, and connect with classmates. If you have a general question about an assignment, a link, or a clinical concept, post it here so the whole class benefits. For private grade or personal questions, message Coach Alan directly in Canvas Inbox.


#### En Palabras Sencillas (Norteño Context)

Este foro es como la banca del gimnasio donde platicamos dudas generales entre compañeros y nos echamos la mano. Si los términos técnicos se ponen pesados, concéntrate primero en preguntar sin pena cualquier duda sobre el curso o mandar mensaje directo por Inbox si es algo privado.


### Open Frequency / Frecuencia Abierta

- English: Got a question? Someone else probably has the same one. This discussion board is our open forum for course-related questions. If you are confused about an instruction, can't find a reading, or found a technical glitch, post it here.
- Español (Regional): ¿Tiene alguna pregunta? Es probable que alguien más tenga la misma duda. Este foro de discusión es nuestro espacio abierto para preguntas relacionadas con el curso. Si tiene dudas sobre alguna instrucción, no encuentra una lectura o detecta una falla técnica, publíquela aquí.

### Ghost Mode Enabled / Modo Fantasma Activado

- English: Anonymous Posting is enabled. To encourage open communication, you can ask questions without attaching your name. (Though remember: there are no dumb questions, only unchecked errors).
- Español (Regional): La publicación anónima está activada. Para fomentar una comunicación abierta, puede realizar preguntas sin vincular su nombre. (Recuerde: no hay preguntas tontas, solo errores que no se reportan).

### Rules of Engagement / Reglas de Participación

- English (Check the Map First): Before you call for support, check the Syllabus and the Module onboarding pages. Español (Regional - Verifique el Mapa Primero): Antes de solicitar asistencia, revise el Plan de Estudios y las páginas de introducción del Módulo.
- English (No Personal Intel): Do not post about your specific grades here. Message Coach Alan directly via Canvas Inbox for private matters. Español (Regional - Sin Datos Personales): No publique información sobre sus calificaciones específicas aquí. Envíe un mensaje directo a Coach Alan a través de la Bandeja de Entrada de Canvas para asuntos privados.
- English (Help Your Squad): If you see a question and know the solution, jump in! Crowd-sourced intelligence makes the squad stronger. Español (Regional - Ayude a su Grupo): Si ve una pregunta y conoce la solución, ¡participe! El conocimiento colectivo fortalece a todo el grupo.
Pro Tip: Click "Subscribe" / Consejo Profesional: Haga clic en "Suscribirse"

English: Click the Subscribe button at the top of this thread to get notified when questions are answered.

Español (Regional): Haga clic en el botón de Suscribirse en la parte superior de este hilo para recibir notificaciones cuando se respondan las preguntas.


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Discussion forums and Q&A support structures in HLTH-150 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools (e.g., Genio).

Español (Regional): Todos los foros de discusión y estructuras de apoyo de preguntas y respuestas en HLTH-150 siguen los principios del Diseño Universal para el Aprendizaje (UDL). Esta página utiliza un diseño centrado en texto y adaptado a dispositivos móviles, compatible al 100% con lectores de pantalla y sistemas de toma de notas con IA.

Process Over Product Evaluation / Evaluación de Proceso:

Squad Q&A participation is untimed and open-ended to promote peer dialogue, collaborative problem-solving, and accessible learning support without testing friction.

Accessibility Services • AccessABILITY Resource Services (ARS) / Servicios de Accesibilidad (ARS) :

AccessABILITY Resource Services (ARS) partners with students with disabilities, faculty, and staff to remove barriers in the educational process through thoughtful design and accommodations. Whether you’re scheduling tutoring sessions at the AT Lab, requesting accommodations through our system, or seeking resources to achieve your educational and career goals, our team is here to assist. Located in the College Community Center (3C) on the main campus, we are committed to helping students build self-advocacy skills, overcome obstacles, and succeed academically.

AccessABILITY Resource Services (ARS) colabora con estudiantes con discapacidades, profesores y personal para eliminar barreras en el proceso educativo mediante un diseño cuidadoso y adaptaciones. Ya sea que programe tutorías en el Laboratorio de Tecnología de Asistencia (AT Lab), solicite adaptaciones o busque recursos para alcanzar sus metas académicas y profesionales, nuestro equipo está para apoyarle en el College Community Center (3C) del campus principal.

Location: College Community Center (3C), Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu | Web: AWC Accessibility Services

Our course architecture directly mirrors federal workforce standards set by the U.S. Department of Labor AI Literacy Framework ( Employment and Training Administration Advisory: Training and Employment Notice No. 07-25 , issued February 13, 2026) and institutional equity mandates set by Arizona Western College :

- Step 1: Zero-Cost Equity & Digital Access (DOL Delivery Principle 4 • Equitable Access): All required AI prompts utilize open-access, zero-cost tools (e.g., Google Gemini, exwtoolkit.com , and paga2018.dev ). Mobile-first, text-based formatting ensures seamless access across low-bandwidth connections and mobile devices.
- Step 2: Experiential Context & Prompt Engineering (DOL Content Areas 1, 2 & 3 / Delivery Principles 1 & 2 / Clinical Framing Protocol (Pattern / Rule / Solve)): You learn AI by directing it inside authentic exercise science workflows. All prompt logs must be documented in your cloud repository ( EXW_Professional_AI_Repository ).
- Step 3: Human-in-the-Loop SSoT Auditing (DOL Content Areas 4 & 5 / Delivery Principle 3 / SSoT Rules): Generative AI models are probabilistic and prone to hallucinations. Submitting unverified AI output constitutes an academic integrity violation. You must audit all AI recommendations against our course Single Source of Truth (SSoT).
- Content Area 1 (Understand AI Principles) → The Centaur Protocol: You act as the Clinical Architect / Pilot ; AI serves strictly as a probabilistic calculator requiring verification.
- Content Area 2 (Explore AI Uses) → Coaching Sprints & Clinical Labs: Hands-on exposure to authentic occupational cases using exwtoolkit.com and paga2018.dev .
- Content Area 3 (Direct AI Effectively) → Part 1 (P-T-C-F Prompt Engineering): Structured Persona, Task, Context, and Format prompts wrapped in ### delimiters.
- Content Area 4 (Evaluate Outputs) → Part 2 (150-Word Clinical SSoT Audit): Auditing AI outputs against federal .gov SSoTs ( PAGA 2018 , DGA 2025–2030 , ACSM 12th Ed. , NASM OPT ).
- Content Area 5 (Use AI Responsibly) → Part 3 (150-Word Active Verification) & Traffic Light Policy: Defending clinical decisions in your own voice with zero PII exposure.
- Delivery Principles 1–7 (Community College Execution): Experiential slider calibration (1), Yuma / Imperial Valley borderland context (2), durable human skills via Pattern / Rule / Solve and Sinek’s Golden Circle (3), $0 ZTC OER & Norteño-Spanish HSI parity (4), stackable portfolio pathways (5), faculty enabling tools (6), and Curriculum-as-Code agility (7).
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
