## HLTH-150: Module 00 — Course Orientation & Ready Reference Guide / Orientación del Curso y Guía de Referencia Permanente

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you read the details below, here is the short version: **Module 00 is your permanent, semester-long reference guide for how to succeed in HLTH-150.** It explains how we pair AI nutrition calculators with your own human judgment, how the 10 / 7 / 0 grading scale works, and how to revise any assignment for full 10 / 10 credit. Because this module stays open all semester, bookmark it and return whenever you need a refresher or an example.

## En Palabras Sencillas (Norteño Context)
Piensa en el Módulo 00 como el recetario base de la familia: siempre está abierto y a la mano durante todo el semestre por si ocupas checar cómo defender tu plan de nutrición o cómo subir una calificación a 10 / 10. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar comida real (`Real Food`) y tu propio criterio (`Patrón / Regla / Solución`) para cuidar a tu cliente.
:::

---

## Course Orientation & Permanent Reference Grounding / Orientación del Curso

* **English:** Welcome to **HLTH-150: Nutrition for Exercise & Wellness**. This introductory module establishes the foundational blueprint for evidence-based dietary coaching in the **Yuma, Arizona and Imperial Valley** region. Every module uses the **Clinical Framing Protocol (`Pattern / Rule / Solve`)** and is grounded in our Academic Source of Truth (SSoT): the **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** alongside the **2018 Physical Activity Guidelines for Americans (PAGA, 2nd Ed.)**. **Best Practice Note:** Module 00 remains unlocked the entire 16-week semester so you can reference our grading rules, AI workflow, and 10/10 exemplars at any time.
* **Español (Regional):** Bienvenido a **HLTH-150: Nutrición para el Ejercicio y el Bienestar**. Este módulo introductorio establece la base para la asesoría nutricional basada en evidencia en la región de **Yuma, Arizona y el Valle Imperial**. Cada módulo utiliza el **Protocolo de Encuadre Clínico (`Patrón / Regla / Solución`)** respaldado por las **Pautas Dietéticas para Estadounidenses 2025–2030 (Enfoque en "Alimentos Reales")**. **Nota Práctica:** El Módulo 00 permanece abierto durante las 16 semanas del semestre como tu guía de consulta rápida.

---

## Targeted Learning Objectives / Objetivos de Aprendizaje

* **([LO 2.8]):** Navigate the course structure, apply clinical nutrition problem-framing (`Pattern / Rule / Solve`), and use federal dietary standards (**DGA 2025–2030**) to design culturally and regionally grounded meal and hydration plans. / Navegar por la estructura del curso, aplicar el encuadre clínico (`Patrón / Regla / Solución`) y utilizar los estándares dietéticos federales (**DGA 2025–2030**) para diseñar planes de alimentación e hidratación adaptados a nuestra región.

---

## The Clinical Framing Protocol (`Pattern

In the **Matador Wellness Center Clinical AI Residency**, you are the **Architect / Pilot** (Problem Framing and Clinical Judgment) and the AI is the **Engine / Calculator** (Macronutrient & Energy Processing). Throughout the semester, every Discussion, Coaching Sprint, and Lab uses our three-part **Clinical Framing Protocol**:

1. **Pattern (`Patrón` — Context):** Diagnose the client's dietary baseline, cultural food preferences, grocery budget, hydration status, and regional stressors (such as $105^\circ\text{F}\text{ to }115^\circ\text{F}$ Yuma agricultural or outdoor labor heat).
2. **Rule (`Regla` — Constraint):** Define the clinical boundaries, macronutrient targets, added-sugar/sodium limits ($<10\%$ of daily kcal from added sugars; $<2,300\text{ mg/day}$ sodium), and whole-food priorities from the **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**.
3. **Solve (`Solución` — Intervention):** Execute a practical, culturally authentic "Real Food" and hydration prescription, patient education card, and human **Active Verification**.

---

## Plain-English Guide: Simulations & Simulators (`paga2018.dev` + `exwtoolkit.com`)

* **In Plain English:** Throughout HLTH-150, you use two free, zero-login web apps located right in your left-hand Canvas Course Navigation menu—**`paga2018.dev` ("PAGA")** and **`exwtoolkit.com` ("Toolkit")**—to test client nutrition and hydration scenarios against the **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** and **PAGA 2018**:
  1. **`paga2018.dev` ("PAGA" in Left Course Menu):**
     * **Activity Audit (`paga2018.dev/activity-audit`):** Check your client's weekly physical activity volume alongside their daily caloric and hydration needs.
     * **Nutrition Coach & Case Coach (`paga2018.dev/nutrition-coach`):** Step-by-step `Pattern / Rule / Solve` coaching sandbox for auditing macronutrients, added-sugar/sodium caps ($<10\%$ kcal added sugars; $<2,300\text{ mg/day}$ sodium), and "Real Food" meal swaps.
     * **Interactive Case Modals (`###` Copy Blocks):** Pre-built client profiles wrapped in triple-hash (`###`) delimiters. Click **"Copy Case (`###`)"** to copy the clean data block without formatting clutter.
     * **Bilingual EN / ES Toggle:** Switch any simulator or federal guideline between English and Norteño-grounded Spanish with one click.
  2. **`exwtoolkit.com` ("Toolkit" in Left Course Menu):**
     * **Stage 1 — Weekly Coaching Sprint:** Uses the embedded micro-simulator right on the Canvas assignment page (`Pattern / Rule / Solve` + 150-word Active Verification).
     * **Stage 2 — Weekly Clinical Lab:** Uses **`paga2018.dev`** + the **`exwtoolkit.com` 9-Box Clinical Architecture** (`1. Biometrics Box` $\rightarrow$ `2. Fuel Box (TDEE & Macros)` $\rightarrow$ `9. Solve Box` *"Copy for Canvas Submission"*).
* **En Palabras Sencillas (Contexto Norteño):** *Durante todo HLTH-150 usamos dos herramientas gratuitas y sin contraseña que están directo en el menú izquierdo de Canvas: **"PAGA"** (`paga2018.dev`, con **Activity Audit**, **Nutrition Coach** y **Cuadros de Casos `###`**) y **"Toolkit"** (`exwtoolkit.com`). El micro-simulador integrado en la página es para tu **Coaching Sprint (Etapa 1)**, y las aplicaciones completas son para tu **Laboratorio Clínico (Etapa 2)**.*

---

## Active Verification (`Part 3`): What It Is, Why We Use It, & 10/10 Student Exemplars (Harmonized Across `EXW 101 •...

## 1. What is "Active Verification"?
Every Lab and Coaching Sprint requires the **Four-Part Submission Standard**:
* **Part 1 (The Engine):** Your P-T-C-F Engineered Prompt (Persona, Task, Context, Format).
* **Part 2 (The Clinical Audit):** A 150-word critique of the AI's output against the **DGA 2025–2030 ("Real Food" Focus)** Source of Truth, catching ultra-processed supplement pushing, hydration miscalculations, or cultural mismatches.
* **Part 3 (Active Verification):** A **mandatory 150-word minimum verbatim text defense written entirely in your own human voice** justifying why your nutrition and hydration plan works safely for a real client in our community.
* **Part 4 (Comparison against the 10/10 Exemplar):** Verifying your work against the module model before submitting.

## 2. Why Do We Use Active Verification? (The Clinical Framework: Pattern / Rule / Solve)
* **In Plain English:** Generic AI chatbots frequently recommend expensive commercial powders, ultra-processed bars, or unrealistic grocery lists that ignore Yuma heat sweat losses and local family budgets. We require the 150-word **Active Verification** in your own words to prevent automated copy-pasting and to prove that **you**—the human nutrition coach—applied the **DGA 2025–2030 "Real Food"** rules to real local foods and real human lives.
* **En Palabras Sencillas (Norteño-Spanish):** *La Verificación Activa (mínimo 150 palabras en tu propia voz) demuestra que tú eres el piloto clínico y la IA es solo la calculadora de calorías. La IA suele recomendar polvos caros o dietas fuera de la realidad de nuestras familias en Yuma y el Valle Imperial. Aquí explicas con tus propias palabras cómo aplicaste `Patrón / Regla / Solución` y las reglas de Alimentos Reales (DGA 2025–2030) al presupuesto, cultura y clima real de tu cliente.*

## 3. What It Looks Like: HLTH-150 Student Exemplar (`10 / 10 Standard`)

> ### Exemplar: HLTH-150 Part 3 — Active Verification (156 words, DGA 2025–2030 Grounded)
> "In my own words, I overrode the AI's meal plan because it recommended expensive commercial pre-workout powders and sweetened sports drinks that violate our client's budget and blood sugar goals here in Somerton. Using `Pattern / Rule / Solve`, the **Pattern** is a 38-year-old agricultural packing-shed worker experiencing afternoon fatigue, high sodium intake from fast food, and chronic dehydration during $106^\circ\text{F}$ ($41.1^\circ\text{C}$) shifts. The **Rule** under the 2025–2030 Dietary Guidelines for Americans ('Real Food' Focus) prioritizes whole, nutrient-dense foods, plain water as the primary beverage, and limiting added sugars to less than $10\%$ of daily calories. My **Solve** replaces her sugary afternoon energy drink and ultra-processed snack bar with 24 ounces of ice water, a homemade pinto bean and grilled chicken burrito on a whole-corn tortilla, and sliced jicama with lime—giving her steady complex carbohydrates, complete protein, and natural electrolytes from affordable local groceries."

---

## The 10-7-0 Mastery Grading Scale & How to Remedy a `Recalibrate (0 / 10)` Score

All Discussions, Coaching Sprints, and Labs in HLTH-150 use **The 10-7-0 Mastery Grading Scale**:

* **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against DGA 2025–2030 with zero safety errors and a complete 150-word human Active Verification.
* **7 / 10 (Competent):** Catches the main nutritional issue and AI mistakes, with minor gaps in detail, word count, or DGA guideline citations. **You can revise and resubmit to reach 10 / 10.**
* **0 / 10 (Recalibrate):** Missing a required section (such as the 150-word Active Verification), unverified AI copy-paste, or unsafe nutritional advice (such as severe caloric restriction, dangerous dehydration in Yuma heat, or unverified supplement prescriptions). **`0 / 10` is never a permanent punishment—it is a clinical safety pause and an open invitation to fix the issue and resubmit for full `10 / 10` credit.**

## The 4-Step Remedy Roadmap: How to Fix a `0 / 10 (Recalibrate)` or Upgrade a `7 / 10 (Competent)` Grade

1. **Step 1 — Open Your `Grades` Tab in Canvas (Not the To-Do List):**
   Once an assignment is graded `0 / 10` or `7 / 10`, Canvas removes it from your "To-Do" sidebar. Click **`Grades`** in the left course navigation menu and click the assignment title directly.
2. **Step 2 — Read Coach Alan's *In Plain English* SpeedGrader Note:**
   Every returned assignment includes a specific comment starting with *"In plain English:"* (or *"En palabras sencillas:"*) explaining the exact DGA 2025–2030 rule, calculation, or missing section you need to address.
3. **Step 3 — Revise Only What Was Flagged:**
   Update your submission using **`Pattern / Rule / Solve` (`Patrón / Regla / Solución`)**, cite **DGA 2025–2030 ("Real Food" Focus)**, and verify that your **Part 3 Active Verification** is at least 150 words in your own human voice.
4. **Step 4 — Click `New Attempt` and Resubmit (Unlimited Attempts Open All Semester):**
   All Labs and Coaching Sprints have **Unlimited Attempts** enabled and remain unlocked through the end of the semester. Click **New Attempt**, submit your updated work, and Coach Alan will re-audit and upgrade your score to **`10 / 10 (Exemplary)`**.

## En Palabras Sencillas: Cómo Recuperar un `0 / 10 (Recalibrate)` o Subir un `7 / 10` a `10 / 10`
*Un `0 / 10 (Recalibrate)` nunca es un castigo definitivo; es una pausa de seguridad clínica y una invitación abierta para corregir y volver a entregar por el `10 / 10` completo. Entra a la pestaña **Grades (Calificaciones)** en Canvas, lee el comentario de Coach Alan en SpeedGrader, corrige el `Patrón / Regla / Solución` o tu Verificación Activa de 150 palabras, y haz clic en **New Attempt (Nuevo Intento)**. Tienes intentos ilimitados durante todo el semestre.*

---

## Check for Understanding
* Before starting Module 01, explain in your own words: Why does an AI meal plan built around commercial supplements instead of "Real Food" fail our Clinical Audit, and what four steps do you take in Canvas to upgrade a `0 / 10 (Recalibrate)` or `7 / 10 (Competent)` score to `10 / 10`?


###CASE_DATA_START###
Clinical Case Profile / Student Activity Parameters
###CASE_DATA_END###
