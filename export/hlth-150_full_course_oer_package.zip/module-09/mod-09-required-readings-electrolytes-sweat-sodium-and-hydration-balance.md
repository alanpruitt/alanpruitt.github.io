# HLTH-150: Mod 09 Required Readings Electrolytes Sweat Sodium And Hydration Balance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 09 Required Readings: Electrolytes, Sweat Sodium & Hydration Balance


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Electrolytes are essential minerals like sodium and potassium that conduct electrical signals to contract muscles and balance body water. When you sweat in extreme desert heat, you lose both water and sodium, which can trigger painful muscle cramps. Replacing both water and salt keeps your blood volume stable so your heart can deliver oxygen to working muscles.


#### En Palabras Sencillas (Norteño Context)

El cuerpo en el calor de Yuma es como el radiador de una troca en plena chinga: no solo ocupa agua, ocupa el refrigerante adecuado para no sobrecalentarse. Si los términos técnicos se ponen pesados, concéntrate primero en reponer el sodio que se pierde con el sudor para evitar los calambres.


### Regional Focus: Mineral Depletion in the Sonoran Desert

Enfoque Regional: Agotamiento Mineral y Estrés Electrolítico en el Desierto de Sonora

In Yuma County and the lower Colorado River basin, high ambient heat combined with rigorous physical labor or athletic training causes substantial sweat excretion that strips both water and critical minerals from extracellular fluid compartments. While fluid replacement prevents acute dehydration, failing to replenish electrolytes—specifically sodium and potassium—disrupts neuromuscular function and cellular osmolarity. Mastering mineral kinetics is essential for clinical and occupational safety in our desert community.

En el condado de Yuma y la cuenca baja del río Colorado, el calor ambiental elevado combinado con el entrenamiento o trabajo intenso provoca una sudoración abundante que elimina agua y minerales esenciales del espacio extracelular. Aunque reponer líquidos previene la deshidratación aguda, no reemplazar los electrolitos —específicamente el sodio y el potasio— altera la función neuromuscular y la osmolaridad celular. Dominar la cinética mineral es un requisito fundamental de seguridad clínica y laboral en nuestra comunidad.


### Reading 1: Electrolyte Kinetics & Mineral Homeostasis

Lectura 1: Cinética de Electrolitos y Homeostasis Mineral


#### Step 1: Sodium and Potassium Dynamics in Muscle Contraction

Dinámica del Sodio y el Potasio en la Contracción Muscular

Electrolytes are electrically charged minerals dissolved in body fluids that regulate nerve signaling, fluid balance, and muscle contraction. Sodium (Na+) is the primary extracellular cation governing plasma volume and osmotic pressure, whereas potassium (K+) functions predominantly inside cells to maintain resting membrane potential. During prolonged athletic exertion, sweat losses deplete total body sodium pools. Without adequate mineral replacement, action potential propagation across muscle membranes fails, increasing vulnerability to premature fatigue, cramping, and neuromuscular dysfunction.

Los electrolitos son minerales con carga eléctrica disueltos en los fluidos corporales que regulan la señalización nerviosa, el equilibrio hídrico y la contracción muscular. El sodio (Na+) es el principal catión extracelular que rige el volumen plasmático y la presión osmótica, mientras que el potasio (K+) actúa predominantemente dentro de las células. Durante el ejercicio prolongado, la pérdida por sudor agota las reservas corporales de sodio. Sin una reposición mineral adecuada, la propagación del potencial de acción falla, aumentando la vulnerabilidad a la fatiga prematura y los calambres.


#### Step 2: Federal Mineral Baselines (PAGA 2018 & DGA SSoT)

Parámetros Minerales Federales (SSoT PAGA 2018 y DGA)

In strict adherence to the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and current Dietary Guidelines for Americans (DGA) standards:

En estricto apego a las normas de PAGA 2018 (2.ª ed.) y las Guías Alimentarias (DGA):

- Sodium Intake Standards: Daily dietary reference values recommend balancing sodium intake against active excretion, supporting fluid retention without elevating cardiovascular strain. Estándares de Ingesta de Sodio: Los valores de referencia recomiendan equilibrar la ingesta de sodio frente a la excreción activa para apoyar la retención de líquidos sin elevar el esfuerzo cardiovascular.
- Potassium Rich Whole Foods: Emphasizing whole-food mineral sources (such as leafy greens, legumes, avocados, and root vegetables) maintains intracellular potassium homeostasis and supports glycogen storage in active skeletal muscle tissue. Alimentos Ricos en Potasio: Priorizar fuentes alimentarias integrales (como verduras de hoja verde, legumbres y aguacates) mantiene la homeostasis intracelular del potasio y favorece el almacenamiento de glucógeno.

### Reading 2: Osmolarity, Fluid Shifts & Hyponatremia Prevention

Lectura 2: Osmolaridad, Desplazamiento Hídrico y Prevención de Hiponatremia


#### Step 1: Plasma Osmolarity and Fluid Compartment Shifts

Osmolaridad Plasmática y Desplazamientos en Compartimentos Hídricos

Plasma osmolarity measures the concentration of solute particles per kilogram of water in blood plasma. As water is lost via sweat without solute replacement, plasma osmolarity rises, signaling the hypothalamus to stimulate thirst and renal water conservation via antidiuretic hormone (ADH). Conversely, consuming massive volumes of plain, hypotonic water dilutes extracellular solutes, driving an osmotic gradient that forces water into intracellular compartments.

La osmolaridad plasmática mide la concentración de solutos en el plasma sanguíneo. Al perder agua por el sudor sin reponer solutos, la osmolaridad aumenta, estimulando la sed y la retención renal a través de la hormona antidiurética (ADH). Por el contrario, consumir volúmenes masivos de agua simple e hipotónica diluye los solutos extracelulares, generando un gradiente osmótico que empuja agua hacia el interior de las células.


#### Step 2: Clinical Etiology of Exercise-Associated Hyponatremia (EAH)

Etiología Clínica de la Hiponatremia Asociada al Ejercicio (HAE)

Exercise-Associated Hyponatremia (EAH) is defined by a serum sodium concentration below 135 mmol/L during or up to 24 hours following physical activity. It represents a serious clinical emergency caused by over-ingesting hypotonic fluids (exceeding sweat and urine output) combined with persistent sodium losses. Symptoms range from bloating, nausea, and disorientation to severe encephalopathy, pulmonary edema, and seizures. Integrating moderate sodium supplementation during events exceeding two hours effectively mitigates this risk.

La Hiponatremia Asociada al Ejercicio (HAE) se define por una concentración de sodio sérico inferior a 135 mmol/L durante o después de la actividad física. Representa una emergencia clínica grave causada por la sobreingesta de líquidos hipotónicos combinada con la pérdida continua de sodio. Los síntomas varían desde distensión abdominal, náuseas y desorientación hasta encefalopatía severa y edema pulmonar. Integrar suplementación moderada de sodio en eventos mayores a dos horas mitiga eficazmente este riesgo.


### Reading 3: Practical Electrolyte Replacement Protocols

Lectura 3: Protocolos Prácticos de Reposición de Electrolitos

Designing an effective electrolyte replacement strategy requires addressing precise intake parameters across training phases:

Diseñar una estrategia eficaz de reposición de electrolitos requiere abordar parámetros precisos en cada fase del entrenamiento:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Sodium is the primary extracellular cation that maintains vascular volume and osmotic pressure. It allows proper action potential transmission across neuromuscular junctions; depleting sodium stores disrupts fluid distribution and nerve signaling, precipitating fatigue and cramping.

Respuesta en Español: El sodio es el principal catión extracelular que mantiene el volumen vascular y la presión osmótica. Permite la transmisión adecuada de potenciales de acción en las uniones neuromusculares; agotar sus reservas altera la distribución de líquidos y la señalización nerviosa.

English Response: EAH is caused primarily by over-consuming plain, hypotonic fluids (water) in quantities that exceed total sweat and urinary losses, diluting blood sodium levels below 135 mmol/L and creating dangerous cellular swelling.

Respuesta en Español: La HAE es causada principalmente por el consumo excesivo de líquidos hipotónicos (agua) en cantidades que superan las pérdidas por sudor y orina, diluyendo los niveles de sodio en sangre por debajo de 135 mmol/L.

English Response: For sustained physical exertion lasting more than 60 to 90 minutes, consuming 300 to 600 mg of sodium per hour helps offset sweat losses, maintain plasma osmolarity, and prevent hyponatremia.

Respuesta en Español: Para esfuerzos físicos sostenidos de más de 60 a 90 minutos, consumir de 300 a 600 mg de sodio por hora ayuda a compensar las pérdidas por sudor, mantener la osmolaridad plasmática y prevenir la hiponatremia.

HLTH-150 • Module 09 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 09 (Mod 09 Required Readings: Electrolytes, Sweat Sodium & Hydration Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```
