## HLTH-150: Mod 09 Required Readings Electrolytes Sweat Sodium And Hydration Balance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 09 Required Readings: Electrolytes, Sweat Sodium & Hydration Balance


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Electrolytes are essential minerals like sodium and potassium that conduct electrical signals to contract muscles and balance body water. When you sweat in extreme desert heat, you lose both water and sodium, which can trigger painful muscle cramps. Replacing both water and salt keeps your blood volume stable so your heart can deliver oxygen to working muscles.


#### En Palabras Sencillas (Norteño Context)

El cuerpo en el calor de Yuma es como el radiador de una troca en plena chinga: no solo ocupa agua, ocupa el refrigerante adecuado para no sobrecalentarse. Si los términos técnicos se ponen pesados, concéntrate primero en reponer el sodio que se pierde con el sudor para evitar los calambres.


### Regional Focus: Mineral Depletion in the Sonoran Desert

Enfoque Regional: Agotamiento Mineral y Estrés Electrolítico en el Desierto de Sonora

In Yuma County and the lower Colorado River basin, high ambient heat combined with rigorous physical labor or athletic training causes substantial sweat excretion that strips both water and critical minerals from extracellular fluid compartments. While fluid replacement prevents acute dehydration, failing to replenish electrolytes—specifically sodium and potassium—disrupts neuromuscular function and cellular osmolarity. Mastering mineral kinetics is essential for clinical and occupational safety in our desert community.

En el condado de Yuma y la cuenca baja del río Colorado, el calor ambiental elevado combinado con el entrenamiento o trabajo intenso provoca una sudoración abundante que elimina agua y minerales esenciales del espacio extracelular. Aunque reponer líquidos previene la deshidratación aguda, no reemplazar los electrolitos —específicamente el sodio y el potasio— altera la función neuromuscular y la osmolaridad celular. Dominar la cinética mineral es un requisito fundamental de seguridad clínica y laboral en nuestra comunidad.


### Reading 1: Electrolyte Kinetics & Mineral Homeostasis

Lectura 1: Cinética de Electrolitos y Homeostasis Mineral


#### Step 1: Sodium and Potassium Dynamics in Muscle Contraction

Dinámica del Sodio y el Potasio en la Contracción Muscular

Electrolytes are electrically charged minerals dissolved in body fluids that regulate nerve signaling, fluid balance, and muscle contraction. Sodium (Na+) is the primary extracellular cation governing plasma volume and osmotic pressure, whereas potassium (K+) functions predominantly inside cells to maintain resting membrane potential. During prolonged athletic exertion, sweat losses deplete total body sodium pools. Without adequate mineral replacement, action potential propagation across muscle membranes fails, increasing vulnerability to premature fatigue, cramping, and neuromuscular dysfunction.

Los electrolitos son minerales con carga eléctrica disueltos en los fluidos corporales que regulan la señalización nerviosa, el equilibrio hídrico y la contracción muscular. El sodio (Na+) es el principal catión extracelular que rige el volumen plasmático y la presión osmótica, mientras que el potasio (K+) actúa predominantemente dentro de las células. Durante el ejercicio prolongado, la pérdida por sudor agota las reservas corporales de sodio. Sin una reposición mineral adecuada, la propagación del potencial de acción falla, aumentando la vulnerabilidad a la fatiga prematura y los calambres.


#### Step 2: Federal Mineral Baselines (PAGA 2018 & DGA SSoT)

Parámetros Minerales Federales (SSoT PAGA 2018 y DGA)

In strict adherence to the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and current Dietary Guidelines for Americans (DGA) standards:

En estricto apego a las normas de PAGA 2018 (2.ª ed.) y las Guías Alimentarias (DGA):

- Sodium Intake Standards: Daily dietary reference values recommend balancing sodium intake against active excretion, supporting fluid retention without elevating cardiovascular strain. Estándares de Ingesta de Sodio: Los valores de referencia recomiendan equilibrar la ingesta de sodio frente a la excreción activa para apoyar la retención de líquidos sin elevar el esfuerzo cardiovascular.
- Potassium Rich Whole Foods: Emphasizing whole-food mineral sources (such as leafy greens, legumes, avocados, and root vegetables) maintains intracellular potassium homeostasis and supports glycogen storage in active skeletal muscle tissue. Alimentos Ricos en Potasio: Priorizar fuentes alimentarias integrales (como verduras de hoja verde, legumbres y aguacates) mantiene la homeostasis intracelular del potasio y favorece el almacenamiento de glucógeno.

### Reading 2: Osmolarity, Fluid Shifts & Hyponatremia Prevention

Lectura 2: Osmolaridad, Desplazamiento Hídrico y Prevención de Hiponatremia


#### Step 1: Plasma Osmolarity and Fluid Compartment Shifts

Osmolaridad Plasmática y Desplazamientos en Compartimentos Hídricos

Plasma osmolarity measures the concentration of solute particles per kilogram of water in blood plasma. As water is lost via sweat without solute replacement, plasma osmolarity rises, signaling the hypothalamus to stimulate thirst and renal water conservation via antidiuretic hormone (ADH). Conversely, consuming massive volumes of plain, hypotonic water dilutes extracellular solutes, driving an osmotic gradient that forces water into intracellular compartments.

La osmolaridad plasmática mide la concentración de solutos en el plasma sanguíneo. Al perder agua por el sudor sin reponer solutos, la osmolaridad aumenta, estimulando la sed y la retención renal a través de la hormona antidiurética (ADH). Por el contrario, consumir volúmenes masivos de agua simple e hipotónica diluye los solutos extracelulares, generando un gradiente osmótico que empuja agua hacia el interior de las células.


#### Step 2: Clinical Etiology of Exercise-Associated Hyponatremia (EAH)

Etiología Clínica de la Hiponatremia Asociada al Ejercicio (HAE)

Exercise-Associated Hyponatremia (EAH) is defined by a serum sodium concentration below 135 mmol/L during or up to 24 hours following physical activity. It represents a serious clinical emergency caused by over-ingesting hypotonic fluids (exceeding sweat and urine output) combined with persistent sodium losses. Symptoms range from bloating, nausea, and disorientation to severe encephalopathy, pulmonary edema, and seizures. Integrating moderate sodium supplementation during events exceeding two hours effectively mitigates this risk.

La Hiponatremia Asociada al Ejercicio (HAE) se define por una concentración de sodio sérico inferior a 135 mmol/L durante o después de la actividad física. Representa una emergencia clínica grave causada por la sobreingesta de líquidos hipotónicos combinada con la pérdida continua de sodio. Los síntomas varían desde distensión abdominal, náuseas y desorientación hasta encefalopatía severa y edema pulmonar. Integrar suplementación moderada de sodio en eventos mayores a dos horas mitiga eficazmente este riesgo.


### Reading 3: Practical Electrolyte Replacement Protocols

Lectura 3: Protocolos Prácticos de Reposición de Electrolitos

Designing an effective electrolyte replacement strategy requires addressing precise intake parameters across training phases:

Diseñar una estrategia eficaz de reposición de electrolitos requiere abordar parámetros precisos en cada fase del entrenamiento:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Sodium is the primary extracellular cation that maintains vascular volume and osmotic pressure. It allows proper action potential transmission across neuromuscular junctions; depleting sodium stores disrupts fluid distribution and nerve signaling, precipitating fatigue and cramping.

Respuesta en Español: El sodio es el principal catión extracelular que mantiene el volumen vascular y la presión osmótica. Permite la transmisión adecuada de potenciales de acción en las uniones neuromusculares; agotar sus reservas altera la distribución de líquidos y la señalización nerviosa.

English Response: EAH is caused primarily by over-consuming plain, hypotonic fluids (water) in quantities that exceed total sweat and urinary losses, diluting blood sodium levels below 135 mmol/L and creating dangerous cellular swelling.

Respuesta en Español: La HAE es causada principalmente por el consumo excesivo de líquidos hipotónicos (agua) en cantidades que superan las pérdidas por sudor y orina, diluyendo los niveles de sodio en sangre por debajo de 135 mmol/L.

English Response: For sustained physical exertion lasting more than 60 to 90 minutes, consuming 300 to 600 mg of sodium per hour helps offset sweat losses, maintain plasma osmolarity, and prevent hyponatremia.

Respuesta en Español: Para esfuerzos físicos sostenidos de más de 60 a 90 minutos, consumir de 300 a 600 mg de sodio por hora ayuda a compensar las pérdidas por sudor, mantener la osmolaridad plasmática y prevenir la hiponatremia.

HLTH-150 • Module 09 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 09 (Mod 09 Required Readings: Electrolytes, Sweat Sodium & Hydration Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 09)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
