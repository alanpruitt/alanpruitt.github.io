## HLTH-150: Mod 09 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 09) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Coaching Sprint Simulation: Balancing Sodium, Potassium & Water

- Exercise-Associated Hyponatremia (EAH — Serum Sodium <135 mmol/L): Dangerous dilution of blood sodium caused by overdrinking plain water above sweat losses during prolonged heat exposure without replacing sodium. En palabras sencillas: Peligro de bajar demasiado el sodio en la sangre por tomar litros de pura agua simple en el calor sin reponer sal con los alimentos.
- Sweat Sodium Concentration (500–1,500+ mg Na+/Liter): Heavy or 'salty' sweaters (white salt rings on clothing/hats) lose substantial sodium that must be replaced during and after prolonged desert sessions. En palabras sencillas: Si dejas manchas blancas de sal en la playera o gorra al sudar en Yuma, necesitas reponer ese sodio con comida real para evitar calambres y mareos.
- Real-Food Electrolyte Replacement (Sodium + Potassium Balance): Using salted whole foods—broth, salted pinto beans, corn tortillas, avocado, banana, citrus, and potatoes—instead of sugary commercial sports drinks. En palabras sencillas: Recuperar electrolitos con comida de verdad (caldo, frijoles con sal, aguacate, plátano y cítricos) en lugar de bebidas deportivas llenas de azúcar.
- HLTH-150.2.2.AY26-27: Calculate fluid turnover, sweat rate kinetics, and electrolyte replacement ratios for active populations under desert heat conditions. Calcular el recambio de fluidos, la cinética del sudor y las proporciones de reemplazo de electrolitos para poblaciones activas en calor desértico.
- HLTH-150.2.7.AY26-27: Audit nutritional hydration protocols against federal Dietary Guidelines for Americans (2025-2030) and apply clinical delimiter safeguards. Auditar protocolos nutricionales de hidratación frente a las Guías Alimentarias para Estadounidenses (2025-2030) y aplicar salvaguardas de delimitadores.

### Your Weekly Win: Mastering Mineral Homeostasis & Preventing Desert Hyponatremia

In Yuma County's intense heat, heavy sweat strips both water and critical minerals from the extracellular space. Chugging plain water without sodium replacement is a direct path to Exercise-Associated Hyponatremia (EAH). As clinical and athletic professionals, we don't rely on guesswork—we audit sodium pacing, apply federal SSoT baselines (PAGA 2018 / 2025-2030 Dietary Guidelines for Americans "Real Food" Focus), and design evidence-based replenishment protocols. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master clinical electrolyte auditing!

En el calor intenso de Yuma, el sudor abundante elimina agua y minerales esenciales. Beber agua simple sin reponer sodio es un camino directo a la hiponatremia (EAH). ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría clínica de electrolitos!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient rehab patient on thiazide diuretics managing mild hypertension; experiences severe cramps and lightheadedness after drinking 2.0 L plain tap water during exercise in Yuma heat.

Scenario: Agricultural field harvest supervisor in Yuma County working 4-hour shifts in 110°F heat; loses 2.5 kg net mass and drinks plain water without electrolyte replacement.

Scenario: Collegiate cross-country runner at Arizona Western College completing a 90-minute high-heat endurance run; experiences 3.38% body mass deficit and heavy thermal strain.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Patient E.S., Elena, or J.T.).
- Electrolyte & Mineral Analysis: Explain the key mineral kinetics or hyponatremia risk factor for your selected client under PAGA / 2025-2030 DGA guidelines.
- Part 3: Active Verification & Hydration Adjustment: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your sodium pacing adjustment (300-600 mg/hr) or whole-food hydration strategy protects client safety and prevents Exercise-Associated Hyponatremia (EAH).
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 09 Coaching Sprint • Track 1 (Patient E.S.)

- Selected Track & Client Name: Track 1: Clinical & Chronic Disease Prevention • Patient E.S. (Age 68).
- Electrolyte & Mineral Analysis: Patient E.S. takes hydrochlorothiazide for hypertension, which drives renal excretion of sodium. Consuming 2.0 L of plain water during physical therapy under Yuma's ambient heat severely diluted her extracellular osmolarity. This hypotonic dilution causes dangerous osmotic fluid shifts into muscle and brain tissues, triggering her acute muscle cramping, dizziness, and Exercise-Associated Hyponatremia (EAH) risk.
- Part 3: Active Verification & Hydration Adjustment: "Replace plain tap water during exercise with an oral electrolyte solution providing 500 mg sodium per liter, paced at 500–700 mL/hr, and recover post-exercise with nutrient-dense salted bean broth and half an avocado." Active Verification: In my clinical reasoning, E.S.'s diuretic medication eliminates her normal renal buffer for sodium retention. In our desert heat, drinking plain water without sodium replacement is actively hazardous because it lowers serum sodium below 135 mmol/L. Pacing sodium at 500 mg/L maintains intravascular osmotic pressure and neuromuscular excitability. Aligning with 2025-2030 Dietary Guidelines for Americans ('Real Food' Focus), I prioritize whole-food sodium and potassium recovery (salted broth, pinto beans, avocado) rather than sugary commercial drinks to safeguard both her blood pressure and metabolic stability.
- "Replace plain tap water during exercise with an oral electrolyte solution providing 500 mg sodium per liter, paced at 500–700 mL/hr, and recover post-exercise with nutrient-dense salted bean broth and half an avocado."
- Active Verification: In my clinical reasoning, E.S.'s diuretic medication eliminates her normal renal buffer for sodium retention. In our desert heat, drinking plain water without sodium replacement is actively hazardous because it lowers serum sodium below 135 mmol/L. Pacing sodium at 500 mg/L maintains intravascular osmotic pressure and neuromuscular excitability. Aligning with 2025-2030 Dietary Guidelines for Americans ('Real Food' Focus), I prioritize whole-food sodium and potassium recovery (salted broth, pinto beans, avocado) rather than sugary commercial drinks to safeguard both her blood pressure and metabolic stability.
- Part 4: My Memorable Coaching Takeaway: EN: "In the desert heat, water hydrates the body, but sodium protects the brain and muscles from hyponatremic shutdown!" ES: "¡En el calor del desierto, el agua hidrata el cuerpo, pero el sodio protege el cerebro y los músculos de un colapso por hiponatremia!"
- EN: "In the desert heat, water hydrates the body, but sodium protects the brain and muscles from hyponatremic shutdown!"
- ES: "¡En el calor del desierto, el agua hidrata el cuerpo, pero el sodio protege el cerebro y los músculos de un colapso por hiponatremia!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M09_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 09 (Mod 09 Coaching Sprint: Balancing Sodium, Potassium & Water)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 09 Simulación de Coaching: Cinética de Electrolitos y Homeostasis Mineral

Evaluación Rápida y Auditoría de Reposición Mineral


### Su Logro Semanal: Dominando la Homeostasis Mineral y Evitando la Hiponatremia

Tomar pura agua sola bajo el solazo de Yuma sin reponer sal es como echarle pura agua al radiador de una troca sin anticongelante: el motor se sobrecalienta y la máquina se traba. Esta sesión le permitirá aplicar las pautas de PAGA 2018 y las Guías Alimentarias 2025-2030 para dosificar el sodio ($300-600\text{ mg/h}$) y proteger la salud. ¡Elija su ruta, dialogue con su coach de IA y obtenga su lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Paciente de rehabilitación que toma hidroclorotiazida; calambres severos tras tomar 2.0 L de agua simple en el calor de Yuma.

Escenario: Supervisora agrícola en Yuma trabajando jornadas de 4 horas a 110°F; pierde 2.5 kg netos consumiendo agua simple sin sal.

Escenario: Corredor de campo traviesa de AWC en carrera de 90 minutos con calor intenso; déficit de peso del 3.38%.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el reto de reposición mineral de su cliente.
- Análisis de Electrolitos y Minerales: Explique los factores de riesgo de hiponatremia (EAH) y las pautas de PAGA / DGA 2025-2030 para su cliente.
- Parte 3: Verificación Activa y Ajuste de Hidratación: En una defensa obligatoria (aprox. mínimo 150 palabras (150+ palabras)) con su propia voz clínica, justifique por qué su dosificación de sodio (300-600 mg/h) o plan con alimentos integrales protege contra la hiponatremia y cumple con DGA.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: HLTH-150 Módulo 09 Sesión de Coaching • Ruta 1 (Paciente E.S.)

- Ruta y Cliente Seleccionado: Ruta 1: Prevención Clínica • Paciente E.S. (68 años).
- Análisis de Electrolitos y Minerales: La paciente toma hidroclorotiazida, un diurético que incrementa la excreción urinaria de sodio. Beber 2.0 L de agua pura durante el esfuerzo en el calor de Yuma diluyó bruscamente su osmolaridad extracelular, provocando edema intracelular, calambres severos y riesgo inminente de hiponatremia (EAH).
- Parte 3: Verificación Activa y Ajuste de Hidratación: "Reemplazar el agua pura durante el ejercicio con una solución electrolítica que aporte 500 mg de sodio por litro a un ritmo de 500 a 700 mL/h, y recuperarse tras la sesión con caldo de frijol con sal y medio aguacate." Verificación Activa: En mi criterio clínico, el diurético elimina el amortiguador renal de sodio de E.S. En el clima desértico, forzar agua pura es peligroso porque baja el sodio sérico por debajo de 135 mmol/L. Dosificar el sodio a 500 mg/L preserva el volumen plasmático y la contractilidad muscular. Siguiendo las Guías Alimentarias DGA 2025-2030 (enfoque en comida real), priorizo caldos con sal, frijoles y aguacate sobre bebidas deportivas azucaradas para cuidar su presión arterial y salud metabólica.
- "Reemplazar el agua pura durante el ejercicio con una solución electrolítica que aporte 500 mg de sodio por litro a un ritmo de 500 a 700 mL/h, y recuperarse tras la sesión con caldo de frijol con sal y medio aguacate."
- Verificación Activa: En mi criterio clínico, el diurético elimina el amortiguador renal de sodio de E.S. En el clima desértico, forzar agua pura es peligroso porque baja el sodio sérico por debajo de 135 mmol/L. Dosificar el sodio a 500 mg/L preserva el volumen plasmático y la contractilidad muscular. Siguiendo las Guías Alimentarias DGA 2025-2030 (enfoque en comida real), priorizo caldos con sal, frijoles y aguacate sobre bebidas deportivas azucaradas para cuidar su presión arterial y salud metabólica.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "In the desert heat, water hydrates the body, but sodium protects the brain and muscles from hyponatremic shutdown!" ES: "¡En el calor del desierto, el agua hidrata el cuerpo, pero el sodio protege el cerebro y los músculos de un colapso por hiponatremia!"
- EN: "In the desert heat, water hydrates the body, but sodium protects the brain and muscles from hyponatremic shutdown!"
- ES: "¡En el calor del desierto, el agua hidrata el cuerpo, pero el sodio protege el cerebro y los músculos de un colapso por hiponatremia!"
- Verificación del Repositorio: Registro de auditoría guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M09_Quiz_Sprint.pdf
HLTH-150 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 09)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
