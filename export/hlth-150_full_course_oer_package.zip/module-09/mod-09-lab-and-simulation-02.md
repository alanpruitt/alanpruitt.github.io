## HLTH-150: Mod 09 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Lab & Simulation: Sweat Sodium & Electrolyte Replacement Audit

- Exercise-Associated Hyponatremia (EAH — Serum Sodium <135 mmol/L): Dangerous dilution of blood sodium caused by overdrinking plain water above sweat losses during prolonged heat exposure without replacing sodium. En palabras sencillas: Peligro de bajar demasiado el sodio en la sangre por tomar litros de pura agua simple en el calor sin reponer sal con los alimentos.
- Sweat Sodium Concentration (500–1,500+ mg Na+/Liter): Heavy or 'salty' sweaters (white salt rings on clothing/hats) lose substantial sodium that must be replaced during and after prolonged desert sessions. En palabras sencillas: Si dejas manchas blancas de sal en la playera o gorra al sudar en Yuma, necesitas reponer ese sodio con comida real para evitar calambres y mareos.
- Real-Food Electrolyte Replacement (Sodium + Potassium Balance): Using salted whole foods—broth, salted pinto beans, corn tortillas, avocado, banana, citrus, and potatoes—instead of sugary commercial sports drinks. En palabras sencillas: Recuperar electrolitos con comida de verdad (caldo, frijoles con sal, aguacate, plátano y cítricos) en lugar de bebidas deportivas llenas de azúcar.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Drinking plain water without replacing sodium during intense desert heat can dilute blood minerals and cause hyponatremia. Heavy sweating in Yuma temperatures drains both fluid volume and essential salts like sodium and potassium. You must pace your sodium intake between 300 and 600 mg per hour alongside fluids to prevent dangerous cellular swelling and muscle cramping.


#### En Palabras Sencillas (Norteño Context)

Tomar pura agua sola bajo el solazo de Yuma sin reponer sal es como echarle pura agua al radiador de una troca sin anticongelante: el motor se sobrecalienta y la máquina se traba. Si los términos técnicos se ponen pesados, concéntrate primero en calcular cuánta agua y cuánto sodio perdiste al sudar.


### Mineral Biometrics, Osmolarity Kinetics, & Desert Heat Standards

In extreme desert microclimates like Yuma County, vigorous physical conditioning and agricultural labor strip substantial sodium ($Na^+$) and potassium ($K^+$) reserves from extracellular fluid compartments. While plain fluid replacement prevents hypohydration, failing to pace electrolytes risks Exercise-Associated Hyponatremia (EAH) and cellular swelling. In this lab, you will evaluate acute sodium depletion patterns, calculate personalized hourly sweat rates, apply federal PAGA 2018 (2nd Ed.) and 2025–2030 Dietary Guidelines for Americans (DGA) standards, and execute a clinical AI simulation using Google Gemini.

En este laboratorio, evaluará los patrones de pérdida de sodio, calculará las tasas de sudoración por hora, aplicará las pautas federales de PAGA 2018 y las Pautas Dietéticas para Estadounidenses (DGA) y ejecutará una simulación clínica con Google Gemini.

- HLTH-150.2.2.AY26-27: Analyze fluid intake and electrolyte replenishment needed for various levels of physical activity in extreme desert environments. Analizar la ingesta de líquidos y la reposición de electrolitos necesaria para diversos niveles de actividad física en entornos desérticos extremos.
- HLTH-150.2.7.AY26-27: Audit clinical mineral timing and osmolarity protocols to mitigate Exercise-Associated Hyponatremia (EAH) and dehydration. Auditar los protocolos clínicos de sincronización mineral y osmolaridad para mitigar la hiponatremia asociada al ejercicio (EAH) y la deshidratación.
- Module Window / Ventana del Módulo: Opens Tuesday, October 13, 2026, at 12:00 AM MST Abre el martes, 13 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 19, 2026, at 11:59 PM MST Lunes, 19 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Mastery Scale) Ponderación para laboratorios semanales y simulaciones clínicas

### Lab Objectives / Objetivos del Laboratorio

- Audit the pathophysiological mechanisms of acute sodium depletion, sweat rate kinetics, and plasma hypo-osmolarity triggering Exercise-Associated Hyponatremia (EAH). Auditar los mecanismos fisiopatológicos del agotamiento agudo de sodio, la cinética del sudor y la hipoosmolaridad plasmática que desencadenan la hiponatremia asociada al ejercicio (EAH).
- Apply federal PAGA 2018 and DGA mineral boundaries to calculate percent body mass loss (% BML, capped at 2.0%), hourly sweat rate ($L/hr$), and hourly sodium pacing requirements ($300-600\text{ mg/hr}$). Aplicar las pautas de PAGA 2018 y DGA para calcular el porcentaje de pérdida de masa corporal (% BML), la tasa de sudoración por hora y los requisitos de reposición de sodio ($300-600\text{ mg/h}$).
- Formulate a comprehensive 3-phase electrolyte replacement and whole-food recovery prescription (Pre-, Intra-, Post-Activity) accompanied by a 2-sentence bilingual client instruction card in English and authentic Spanish. Formular una prescripción de reposición de electrolitos de 3 fases con alimentos integrales y una tarjeta de instrucción bilingüe de 2 oraciones en inglés y español auténtico.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-09

Fase 1: Selección de Escenario de Simulación Clínica Clínico

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Scenario: Outpatient physical therapy patient (E.S., 68) managing mild hypertension with thiazide diuretics; presents with severe muscle cramping and lightheadedness after consuming 2.0 L of plain tap water during rehab exercises.

Scenario: Agricultural field harvest supervisor (Elena, 34) in Yuma County managing shifts in 110°F ambient heat; drinks 3.0 L plain water, loses 2.5 kg net mass, and experiences severe heat fatigue.

Scenario: Collegiate cross-country runner (J.T., 21) at Arizona Western College completing a 90-minute high-heat endurance run; experiences heavy thermal strain and 3.38% body mass deficit.


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Paso 2: Copie la plantilla y ejecute la auditoría clínica en Gemini Sandbox

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete clinical audit directly into the Canvas text box structured under the following numbered headers:

- Selected Track & Client Baseline: Declare chosen track, client initials, ambient conditions, and baseline mass in kg.
- Step 1: Pattern Breakdown (Exact Math & Mineral Audit): Detail exact step-by-step calculations for: Percent Body Mass Loss (% BML) and comparison to the 2.0% dehydration threshold. Hourly Sweat Rate ($L/hr$) factoring in fluid consumed and urine output. Evaluation of plasma dilution and Exercise-Associated Hyponatremia (EAH) risk. BLANK SUBMISSION SKELETON (PASTE INTO CANVAS TEXT ENTRY BOX) • PLANTILLA DE ENTREGA Click to Highlight Template (1 Clic) Selected! Press Ctrl+C / Cmd+C to Copy • ¡Seleccionado! [SELECTED TRACK AND CLIENT INITIALS]: Track [1 / 2 / 3] — Client [Initials] [PART 1 — PATTERN RECOGNITION AND P-T-C-F PROMPT]: [Summarize client baseline pattern, Yuma environmental stressors, and your P-T-C-F prompt.] [PART 2 — RULE APPLICATION AND CLINICAL AUDIT (150+ WORDS)]: [Audit the AI output against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus). State exact safety thresholds and corrections.] [PART 3 — SOLVE AND ACTIVE VERIFICATION IN MY OWN VOICE (150+ WORDS — MANDATORY FOR 10/10)]: [Defend your clinical prescription and safety logic in at least 150 words in your own coaching voice.] [PART 4 — BILINGUAL CLIENT COACHING CARD (2 SENTENCES)]: English: "[Write your 2-sentence plain-English takeaway here.]" Spanish: "[Escriba su resumen práctico de 2 oraciones en español aquí.]" [REPOSITORY VERIFICATION]: Confirmed exported and saved to EXW_Professional_AI_Repository.
- Percent Body Mass Loss (% BML) and comparison to the 2.0% dehydration threshold.
- Hourly Sweat Rate ($L/hr$) factoring in fluid consumed and urine output.
- Evaluation of plasma dilution and Exercise-Associated Hyponatremia (EAH) risk.
- Step 2: Rule Alignment (SSoT Clinical Audit - PAGA / DGA): Cite federal safety rules for sodium pacing (300 to 600 mg/hr), osmotic equilibrium, and the dangers of plain water over-consumption during desert heat.
- Part 3: Clinical Solve (Active Verification & Client Card): In a mandatory text defense (approx. 150 words) written in your own clinical voice, justify why your 3-phase hydration protocol (Pre-, Intra-, Post-Activity) aligns with federal PAGA 2018 / 2025-2030 DGA mineral rules and protects against hyponatremia (EAH). Conclude with a mandatory 2-sentence bilingual client instruction card in English and Spanish.
- Repository Verification: Confirm complete Gemini AI consultation log is exported and saved to Google Drive: EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Selected Track: Track 1 (Clinical & Chronic Disease Prevention Path) • Patient E.S. (Age 68)

- Selected Track & Client Baseline: Client: E.S., 68-year-old outpatient physical therapy patient managing hypertension with hydrochlorothiazide in Yuma, AZ. Biometrics: Pre-mass = 74.0 kg | Post-mass = 72.8 kg | Net loss = 1.2 kg | Session Duration = 1.5 hrs. Fluid Intake: 2.0 L plain water | Urine Output = 300 mL (0.3 L).
- Client: E.S., 68-year-old outpatient physical therapy patient managing hypertension with hydrochlorothiazide in Yuma, AZ.
- Biometrics: Pre-mass = 74.0 kg | Post-mass = 72.8 kg | Net loss = 1.2 kg | Session Duration = 1.5 hrs.
- Fluid Intake: 2.0 L plain water | Urine Output = 300 mL (0.3 L).
- Step 1: Pattern Breakdown (Exact Math & Mineral Audit): Percent Body Mass Loss: $[(74.0\text{ kg} - 72.8\text{ kg}) / 74.0\text{ kg}] \times 100 = 1.62\%$. While 1.62% is below the acute 2.0% dehydration threshold, it represents significant fluid turnover. Hourly Sweat Rate: $[(74.0 - 72.8) + 2.0\text{ L} - 0.3\text{ L}] / 1.5\text{ hr} = [1.2 + 1.7] / 1.5 = 2.9\text{ L} / 1.5\text{ hr} = 1.93\text{ L/hr}$. Pathophysiological Pattern: E.S. consumed 2.0 L of plain water while losing nearly 2.9 L of sweat and taking thiazide diuretics (which block sodium reabsorption in the distal renal tubules). This combination rapidly drives serum sodium below normal levels ($< 135\text{ mEq/L}$), triggering acute intracellular fluid shifts into brain and muscle tissue, explaining her severe cramping and postural dizziness.
- Percent Body Mass Loss: $[(74.0\text{ kg} - 72.8\text{ kg}) / 74.0\text{ kg}] \times 100 = 1.62\%$. While 1.62% is below the acute 2.0% dehydration threshold, it represents significant fluid turnover.
- Hourly Sweat Rate: $[(74.0 - 72.8) + 2.0\text{ L} - 0.3\text{ L}] / 1.5\text{ hr} = [1.2 + 1.7] / 1.5 = 2.9\text{ L} / 1.5\text{ hr} = 1.93\text{ L/hr}$.
- Pathophysiological Pattern: E.S. consumed 2.0 L of plain water while losing nearly 2.9 L of sweat and taking thiazide diuretics (which block sodium reabsorption in the distal renal tubules). This combination rapidly drives serum sodium below normal levels ($< 135\text{ mEq/L}$), triggering acute intracellular fluid shifts into brain and muscle tissue, explaining her severe cramping and postural dizziness.
- Step 2: Rule Alignment (SSoT Clinical Audit - PAGA / DGA): Under PAGA 2018 and clinical sports nutrition standards, fluid intake during heat exercise must match sweat rates without exceeding them, and must include 300 to 600 mg of sodium per hour for losses exceeding 1 hour. Consuming large boluses of plain water without sodium in a diuretic-treated patient directly violates clinical osmolarity standards and creates an acute risk of Exercise-Associated Hyponatremia (EAH).
- Under PAGA 2018 and clinical sports nutrition standards, fluid intake during heat exercise must match sweat rates without exceeding them, and must include 300 to 600 mg of sodium per hour for losses exceeding 1 hour.
- Consuming large boluses of plain water without sodium in a diuretic-treated patient directly violates clinical osmolarity standards and creates an acute risk of Exercise-Associated Hyponatremia (EAH).
- Part 3: Clinical Solve (Active Verification & Client Card): Pre-Activity: Consume 400 mL of water with a sodium-rich pre-exercise snack (e.g., 2 lightly salted whole-wheat pretzels or 1 cup vegetable broth providing ~300 mg sodium) 2 hours prior. Intra-Activity: Replace plain tap water with an oral electrolyte solution providing 500 mg sodium and 150 mg potassium per liter, paced at 600–800 mL/hr. Post-Activity: Rehydrate with 1.5 L fluid per kg lost (1.8 L total over 4 hours) utilizing whole-food recovery meals: bean and cheese burrito or tomato-lentil soup paired with a banana for potassium restoration. Active Verification: In my clinical assessment, E.S.'s thiazide diuretic prescription impairs her renal sodium retention, compounding sweat sodium losses in Yuma's arid desert environment. Forcing plain water dilutes extracellular osmolarity and creates immediate risk for cerebral edema and hyponatremic encephalopathy. Pacing sodium intake at 500 mg/L during exertion directly preserves blood pressure and neuromuscular action potentials. Post-activity recovery must rely on whole foods (beans, broth, avocado) rather than sugary commercial drinks, meeting 2025-2030 DGA standards for nutrient density while replenishing lost electrolyte stores safely. Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: EN: "Because your blood pressure water pills flush out extra salt, drinking only plain water causes muscle cramps and dangerous dizziness. Always sip an electrolyte drink with sodium during your therapy sessions and refuel with wholesome salted foods like broth or beans after exercising in the desert heat." ES: "Como sus pastillas para la presión eliminan sal a través de la orina, tomar pura agua sola le provoca calambres y mareos peligrosos. Tome siempre una bebida con electrolitos durante sus terapias y recupérese con alimentos nutritivos que contengan sodio como caldos o frijoles después de ejercitarse en el calor."
- Pre-Activity: Consume 400 mL of water with a sodium-rich pre-exercise snack (e.g., 2 lightly salted whole-wheat pretzels or 1 cup vegetable broth providing ~300 mg sodium) 2 hours prior.
- Intra-Activity: Replace plain tap water with an oral electrolyte solution providing 500 mg sodium and 150 mg potassium per liter, paced at 600–800 mL/hr.
- Post-Activity: Rehydrate with 1.5 L fluid per kg lost (1.8 L total over 4 hours) utilizing whole-food recovery meals: bean and cheese burrito or tomato-lentil soup paired with a banana for potassium restoration.
- Active Verification: In my clinical assessment, E.S.'s thiazide diuretic prescription impairs her renal sodium retention, compounding sweat sodium losses in Yuma's arid desert environment. Forcing plain water dilutes extracellular osmolarity and creates immediate risk for cerebral edema and hyponatremic encephalopathy. Pacing sodium intake at 500 mg/L during exertion directly preserves blood pressure and neuromuscular action potentials. Post-activity recovery must rely on whole foods (beans, broth, avocado) rather than sugary commercial drinks, meeting 2025-2030 DGA standards for nutrient density while replenishing lost electrolyte stores safely.
- Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW150_Mod09_Electrolyte_Audit_ES.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 09 (Mod 09 Lab: Sweat Sodium & Electrolyte Replacement Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 09 Práctica de Laboratorio: Cinética de Electrolitos y Balance Mineral

Biometría mineral, osmolaridad plasmática y normas de seguridad en el desierto


### En Palabras Sencillas: Guía de Navegación

Tomar pura agua sola bajo el solazo de Yuma sin reponer sal es como echarle pura agua al radiador de una troca sin anticongelante: el motor se sobrecalienta y la máquina se traba. Si los términos técnicos se ponen pesados, concéntrate primero en calcular cuánta agua y cuánto sodio perdiste al sudar.


### Visión General: Biometría Mineral y Seguridad Climática

En esta práctica de laboratorio, evaluará los patrones de pérdida de sodio, calculará la tasa de sudoración por hora y diseñará una prescripción de reposición mineral de 3 fases utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , respaldado por las pautas federales de PAGA 2018 y las Pautas Dietéticas para Estadounidenses (DGA).


### Estructura de Entrega en Cuadro de Texto de Canvas


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Comunitaria / Ruta 3 Deportiva) e incluya las iniciales del cliente.


#### Paso 1: Reconocimiento de Patrones (Cálculos de Sudor y Sodio)

Calcule el porcentaje de pérdida de peso (% BML), la tasa de sudoración por hora ($L/h$) y evalúe el riesgo de hiponatremia asociada al ejercicio (EAH).


#### Paso 2: Aplicación de Reglas (PAGA 2018 / DGA)

Aplique los estándares federales de reposición de sodio ($300-600\text{ mg/h}$) y equilibrio osmótico para evitar la dilución plasmática.


#### Paso 3: Solución Clínica (Verificación Activa y Tarjeta de Cliente)

En una defensa obligatoria (aprox. 150 palabras) con su propia voz clínica, justifique por qué su plan de hidratación de 3 fases con alimentos integrales protege contra la hiponatremia (EAH) según PAGA/DGA, y concluya con la tarjeta de instrucción bilingüe de 2 oraciones.


### Modelo de Respuesta de Alta Fidelidad 10/10

Paso 1: Reconocimiento de Patrones: La paciente E.S. perdió 1.2 kg netos en 1.5 horas, lo que equivale a un $1.62\%$ de masa corporal perdida. Su tasa de sudoración fue de $1.93\text{ L/h}$. A pesar de consumir 2.0 L de agua pura, el uso de hidroclorotiazida combinado con la ingesta excesiva de agua sin sodio provocó una dilución osmótica aguda y riesgo severo de hiponatremia (EAH), manifestado en calambres intensos y mareos posturales.

Paso 2: Aplicación de Reglas (PAGA / DGA): Las pautas clínicas dictan que en sesiones de ejercicio en calor con sudoración profusa se deben reponer entre 300 y 600 mg de sodio por hora . Tomar agua sola sin electrolitos en pacientes bajo tratamiento diurético diluye el sodio sérico por debajo de $135\text{ mEq/L}$, violando los estándares de seguridad osmótica.

Paso 3: Solución Clínica (Verificación Activa y Tarjeta Bilingüe): Se prescribe consumir 400 mL de agua con 300 mg de sodio antes de la sesión, reemplazar el agua pura durante el ejercicio con una solución electrolítica que aporte 500 mg de sodio por litro ($600-800\text{ mL/h}$), y recuperar el $150\%$ del peso perdido en las siguientes 4 horas consumiendo alimentos ricos en sodio y potasio (frijoles, caldo y plátano). Verificación Activa: En mi criterio clínico, el diurético tiazídico de E.S. deteriora su retención renal de sodio, agravando las pérdidas por sudor en el clima árido de Yuma. Forzar agua pura diluye la osmolaridad extracelular y crea un riesgo inmediato de edema cerebral y encefalopatía hiponatrémica. Dosificar el sodio a 500 mg/L durante el esfuerzo preserva la presión arterial y los potenciales de acción muscular. La recuperación post-ejercicio debe basarse en alimentos enteros y asequibles (frijoles, caldos, aguacate) en lugar de bebidas comerciales azucaradas, cumpliendo con las guías DGA 2025-2030 de densidad nutricional. Tarjeta Bilingüe: "Como sus pastillas para la presión eliminan sal a través de la orina, tomar pura agua sola le provoca calambres y mareos peligrosos. Tome siempre una bebida con electrolitos durante sus terapias y recupérese con alimentos nutritivos que contengan sodio como caldos o frijoles después de ejercitarse en el calor."

Verificación del Repositorio: Registro de auditoría exportado y archivado en Google Drive: EXW_Professional_AI_Repository / EXW150_Mod09_Electrolyte_Audit_ES.pdf

HLTH-150 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 09)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
