## HLTH-150: Mod 09 Summary And Wrap Up Electrolytes Sweat Sodium And Hydration Balance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 09 Summary & Wrap-Up: Electrolytes, Sweat Sodium & Hydration Balance


### Step 1: Core Electrolyte Kinetics & Mineral Homeostasis Synthesis

Congratulations on completing Module 09! You have successfully mastered the biochemical mechanics of mineral balance, plasma osmolarity shifts, and electrolyte replacement under extreme Sonoran Desert conditions:

- Sodium and Potassium Kinetics: Sodium (Na+) governs extracellular fluid volume and osmotic pressure, while potassium (K+) maintains intracellular resting membrane potential; heavy sweat excretion strips both minerals and disrupts action potential propagation.
- Preventing EAH: Over-drinking plain hypotonic water past sweat and urinary losses dilutes vascular sodium below 135 mmol/L, creating an osmotic gradient that drives cellular swelling and cerebral edema.
- Whole-Food Mineral Pacing: Integrate 300 to 600 mg of sodium per hour during continuous exertion exceeding 60 to 90 minutes, paired with whole-food potassium sources (greens, legumes, avocados) during recovery.

### Step 2: Workplace Intelligence & AI Safety Auditor Protocol

In clinical sports dietetics and occupational health, professionals utilize secure AI simulation frameworks to audit electrolyte pacing and protect client safety.

- AI-Assisted Mineral Calculations: Nutritionists prompt AI preceptors to evaluate sweat rates, sodium deficits, and fluid intake volumes with absolute mathematical precision.
- Delimiter Security Protocol (###): Client biometric files, pre/post exercise masses, and medical histories must be enclosed inside triple hashes ( ### ) to maintain strict data boundary isolation during automated preceptor analysis.
- Clinical Auditing: Professionals verify AI outputs against federal SSoT standards (PAGA 2018 / DGA) to guarantee client safety and eliminate hyponatremia risks.

### Step 3: Module 09 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 10:

English Calculation: Sodium is the primary extracellular cation maintaining vascular volume and osmotic pressure. It allows proper action potential transmission across neuromuscular junctions; depleting sodium stores disrupts fluid distribution and nerve signaling.

Cálculo en Español: El sodio es el principal catión extracelular que mantiene el volumen vascular y la presión osmótica. Permite la transmisión adecuada de potenciales de acción en las uniones neuromusculares; agotar sus reservas altera la distribución de líquidos.

English Rationale: EAH is caused primarily by over-consuming plain, hypotonic fluids (water) in quantities that exceed total sweat and urinary losses, diluting blood sodium levels below 135 mmol/L and creating dangerous cellular swelling.

Justificación en Español: La HAE es causada principalmente por el consumo excesivo de líquidos hipotónicos (agua) en cantidades que superan las pérdidas por sudor y orina, diluyendo los niveles de sodio en sangre por debajo de 135 mmol/L.

English Rationale: For sustained physical exertion lasting more than 60 to 90 minutes, consuming 300 to 600 mg of sodium per hour helps offset sweat losses, maintain plasma osmolarity, and prevent hyponatremia.

Justificación en Español: Para esfuerzos físicos sostenidos de más de 60 a 90 minutos, consumir de 300 a 600 mg de sodio por hora ayuda a compensar las pérdidas por sudor, mantener la osmolaridad plasmática y prevenir la hiponatremia.

English Response: Enclosing client biometric parameters and fluid logs inside triple hashes ( ### ) ensures clean data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 standards.

Respuesta en Español: Encapitular los datos biométricos y registros de líquidos del cliente entre delimitadores de tres numerales ( ### ) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con PAGA 2018.

English Response: Potassium functions predominantly inside cells to maintain resting membrane potential and supports efficient glycogen storage in active skeletal muscle tissue.

Respuesta en Español: El potasio actúa predominantemente dentro de las células para mantener el potencial de membrana en reposo y favorece el almacenamiento eficiente de glucógeno en el tejido muscular esquelético activo.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.


### AI Simulation Workspace • Exam Simulation & Synthesis

Copy the prompt below into Gemini to generate a personalized review sheet comparing thermoregulation (Module 08) and electrolyte kinetics (Module 09):

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Hydration & Electrolyte Synthesis ###:
Role: Clinical Sports Nutritionist and Academic Tutor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Fluid Dynamics (Sweat Rate, 2.0% Mass Loss Threshold)
   Key Point: Electrolyte Kinetics (Sodium/Potassium Balance, EAH Prevention)
Step 2: Explain how plain water over-consumption triggers cellular swelling during desert exertion.
Step 3: Provide 3 whole-food recovery snack options meeting both sodium and potassium replacement standards.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 10 — Nutrient Timing, Recovery, & Ergogenic Aids

In plain English, next week in Module 10: Nutrient Timing, Recovery, and Ergogenic Aids you will learn what to eat before, during, and right after a workout to speed up recovery, and how to audit dietary supplements so athletes do not waste money or fail a drug test. Why it matters: dietary supplements are not pre-approved by the FDA before hitting store shelves—you must verify third-party safety seals (NSF Certified for Sport or USP) and prioritize whole foods first.

- Pattern (Context): Auditing pre-/post-workout meal timing windows and evaluating ergogenic aid claims (creatine, caffeine, nitrates) vs. proprietary-blend red flags.
- Rule (Constraint): Enforcing the 2025–2030 DGA 'Food First' rule , DSHEA regulatory limits, and mandatory third-party testing verification (NSF / USP).
- Solve (Intervention): Completing Mod 10 Discussion: Supplement Safety & Food First and Mod 10 Lab: Nutrient Timing & Supplement Audit .

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 09 (Mod 09 Summary & Wrap-Up: Electrolytes, Sweat Sodium & Hydration Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 09: Resumen y Comprobación de Conocimientos


### Síntesis del Módulo 09: Cinética de Electrolitos y Homeostasis Mineral

Esta semana analizamos los mecanismos bioquímicos del balance mineral y la reposición de electrolitos. Evaluamos la función del sodio y potasio en la contracción muscular, la osmolaridad plasmática y los riesgos críticos de la Hiponatremia Asociada al Ejercicio (HAE).

Al vincular las normas federales ( pautas de PAGA 2018 / DGA ) con los protocolos de dosificación de sodio, consolidó una base científica para prescribir estrategias minerales seguras en entornos clínicos, comunitarios y deportivos.


### Conclusiones del Protocolo de Encuadre Clínico • Patrón, Regla, Solución

El sudor prolongado en climas áridos elimina sodio y potasio, alterando la propagación de impulsos nerviosos y generando calambres y fatiga neuromuscular prematura.

Ingerir agua simple en exceso sin sodio diluye el plasma sanguíneo por debajo de 135 mmol/L, provocando un desequilibrio osmótico con riesgo de edema cerebral.

Integrar de 300 a 600 mg de sodio por hora durante esfuerzos de más de 60 minutos y priorizar fuentes enteras de potasio (verduras, legumbres y aguacate) en la recuperación.


### Autoevaluación del Módulo 09 (Verificación Bilingüe)

Presione cada elemento para verificar su comprensión:

Respuesta en Español: El sodio es el principal catión extracelular que mantiene el volumen vascular y la presión osmótica. Permite la transmisión adecuada de potenciales de acción en las uniones neuromusculares; agotar sus reservas altera la distribución de líquidos.

English Calculation: Sodium is the primary extracellular cation maintaining vascular volume and osmotic pressure. It allows proper action potential transmission across neuromuscular junctions; depleting sodium stores disrupts fluid distribution.

Respuesta en Español: La HAE es causada principalmente por el consumo excesivo de líquidos hipotónicos (agua) en cantidades que superan las pérdidas por sudor y orina, diluyendo los niveles de sodio en sangre por debajo de 135 mmol/L.

English Rationale: EAH is caused primarily by over-consuming plain, hypotonic fluids (water) in quantities that exceed total sweat and urinary losses, diluting blood sodium levels below 135 mmol/L and creating cellular swelling.

Respuesta en Español: Para esfuerzos físicos sostenidos de más de 60 a 90 minutos, consumir de 300 a 600 mg de sodio por hora ayuda a compensar las pérdidas por sudor, mantener la osmolaridad plasmática y prevenir la hiponatremia.

English Rationale: For sustained physical exertion lasting more than 60 to 90 minutes, consuming 300 to 600 mg of sodium per hour helps offset sweat losses, maintain plasma osmolarity, and prevent hyponatremia.

Respuesta en Español: Encapitular los datos biométricos y registros de líquidos del cliente entre delimitadores de tres numerales ( ### ) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con PAGA 2018.

English Response: Enclosing client biometric parameters and fluid logs inside triple hashes ( ### ) ensures clean data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 standards.

Respuesta en Español: El potasio actúa predominantemente dentro de las células para mantener el potencial de membrana en reposo y favorece el almacenamiento eficiente de glucógeno en el tejido muscular esquelético activo.

English Response: Potassium functions predominantly inside cells to maintain resting membrane potential and supports efficient glycogen storage in active skeletal muscle tissue.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Review Master Protocol: HLTH-150 Sintesis de Hidratacion y Electrolitos ###:
Rol: Nutriologo Deportivo Clinico y Tutor Academico en la voz del Narrator.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Dinamica de Fluidos (Sweat Rate, 2.0% Mass Loss Threshold)
   Key Point: Cinetica de Electrolitos (Sodium/Potassium Balance, EAH Prevention)
Step 2: Explicar como el consumo excesivo de agua simple provoca inflamacion celular durante el esfuerzo en el desierto.
Step 3: Proponer 3 opciones de snacks integrales para la recuperacion que cumplan con los estandares de reposicion de sodio y potasio.
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 10 — Crononutrición, Recuperación y Ayudas Ergogénicas

En palabras sencillas (Contexto Norteño): ningún polvo mágico reemplaza un buen plato de comida real a tiempo, y muchos botes de 'pre-entreno' ni siquiera están revisados por la FDA antes de venderse. Si los nombres de los suplementos se ponen pesados la próxima semana, concéntrate primero en cuándo comer alrededor del entrenamiento y cómo exigir sellos de seguridad verificados (como NSF Certified for Sport o USP ).

- Patrón (Contexto): Auditar el horario de comidas antes y después de entrenar y revisar etiquetas de suplementos deportivos.
- Regla (Restricción): Aplicar el principio de 'Comida Real Primero' de DGA 2025–2030 y verificar sellos de pureza de terceros (NSF / USP).
- Solución (Intervención): Completar el Foro del Mód 10 (Supplement Safety & Food First) y el Laboratorio del Mód 10 (Nutrient Timing & Supplement Audit) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 09 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 09)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
