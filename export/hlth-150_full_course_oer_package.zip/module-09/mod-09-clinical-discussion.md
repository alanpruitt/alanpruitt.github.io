## HLTH-150: Mod 09 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 09) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Exercise and Sports / Nutrición para el Deporte y el Ejercicio


## Mod 09 Discussion: Electrolyte Protocols vs. Commercial Claims


### Electrolyte Homeostasis, Commercial Claims & Desert Heat Safety

Effective hydration in extreme heat environments like Yuma County and the Sonoran Desert requires strict physiological mineral balance. Commercial beverage marketing frequently promotes misleading claims—selling sugary neon sports drinks for low-intensity exertion, marketing expensive "electrolyte waters" with sub-therapeutic mineral amounts insufficient to prevent cramping, or pushing mega-dosed sodium packets without adequate fluid dilution. Relying solely on plain water during prolonged exertion risks life-threatening Exercise-Associated Hyponatremia (EAH) through extracellular solute dilution, while consuming improper commercial formulas can cause severe gastrointestinal distress, hypertonic fluid shifts, or delayed gastric emptying. In this discussion, you will audit commercial electrolyte claims against clinical physiological standards ( PAGA 2018 / U.S. Dietary Guidelines for Americans 2025–2030 Real Food Focus / ACSM Position Stands ). Select your Build Your Own Journey Track below, audit your simulation case using Google Gemini, and defend an evidence-based protocol!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #150-09

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Fluid management in clinical patients, diuretic interactions, and evaluating commercial "electrolyte waters" versus therapeutic mineral replenishment in physical therapy.

Focus: Occupational heat stress, evaluating high-sugar commercial sports drinks versus low-cost community whole-food oral rehydration solutions for agricultural harvesters in Yuma County.

Focus: Sweat rate testing, auditing concentrated commercial electrolyte supplement claims, intra-workout sodium pacing, and preventing hyponatremia in endurance athletes.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track, Metrics & Commercial Claim / Ruta, Métricas y Afirmación Comercial: State your chosen track and report the client's current fluid intake, sweat loss, or mineral deficit. Explicitly audit the commercial product or marketing claim they are using, explaining why it fails physiologically in desert conditions. Indique la ruta seleccionada, reporte las métricas de líquidos/sudor y audite la afirmación o producto comercial utilizado, explicando por qué falla fisiológicamente en el desierto.
- Clinical Framing Protocol Analysis (Pattern / Rule / Solve) / Análisis del Protocolo de Marco Clínico (Patrón / Regla / Solución): Pattern: Contrast the client's physiological needs against the commercial product's label (e.g., sub-therapeutic sodium in "electrolyte water", excessive sugar in commercial sports drinks, or hypertonic osmotic distress). Rule: Cite DGA 2025–2030 (Real Food Focus) , PAGA 2018 , and ACSM hydration standards, specifically addressing the 2.0% body mass deficit threshold, sodium pacing (300–600 mg/hr), and EAH risks. Solve: Prescribe a 3-phase rehydration protocol (Pre-Exercise Priming, Intra-Exercise Pacing, Post-Exercise Recovery at 125–150% fluid replacement) emphasizing real-food mineral sources or cost-effective oral rehydration solutions. Aplique Patrón (auditoría del producto comercial frente a necesidades fisiológicas), Regla (normas ACSM/DGA/PAGA, umbral del 2.0% y 300-600 mg/h de sodio) y Solución (protocolo de 3 fases con alimentos reales y reposición del 125-150%).
- Pattern: Contrast the client's physiological needs against the commercial product's label (e.g., sub-therapeutic sodium in "electrolyte water", excessive sugar in commercial sports drinks, or hypertonic osmotic distress).
- Rule: Cite DGA 2025–2030 (Real Food Focus) , PAGA 2018 , and ACSM hydration standards, specifically addressing the 2.0% body mass deficit threshold, sodium pacing (300–600 mg/hr), and EAH risks.
- Solve: Prescribe a 3-phase rehydration protocol (Pre-Exercise Priming, Intra-Exercise Pacing, Post-Exercise Recovery at 125–150% fluid replacement) emphasizing real-food mineral sources or cost-effective oral rehydration solutions.
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence explanation of the hydration and electrolyte plan in both English and Spanish so your client can execute it safely without falling for commercial marketing hype. Proporcione una explicación concisa de 2 oraciones sobre el plan de electrolitos en inglés y español para que su cliente la aplique con seguridad sin caer en el engaño publicitario.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their commercial claim critique, compare their sodium-to-fluid concentration ratios against yours, and discuss how evidence-based hydration protocols must adapt across clinical, occupational agricultural, and athletic desert environments.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition & Commercial Claim Audit: Athlete C.V. exhibits an acute sweat rate of 1.8 L/hr during 90-minute training sessions in Yuma desert heat. The athlete fell victim to a commercial claim advertising that an ultra-concentrated 1,500 mg sodium powder stick "eliminates 100% of cramps and hydrates 10x faster." By taking this hypertonic slurry in only 8 oz of water prior to running, the athlete induced osmotic fluid shifts into the gut, provoking nausea and delayed gastric emptying. Subsequently consuming only plain tap water on the run diluted extracellular sodium, creating an acute 3.2% body mass deficit (2.08 kg lost) that triggers severe muscle cramps and impairs cardiac output.

Rule Application (ACSM, PAGA 2018 & DGA Standards): ACSM Position Stands and PAGA 2018 guidelines confirm that dehydration exceeding 2.0% body mass impairs aerobic performance and thermal tolerance. For high sweat rates in extreme heat, physiological sodium replacement must be paced at 300 to 600 mg of sodium per hour in an isotonic or slightly hypotonic 6% to 8% carbohydrate-electrolyte solution, rather than an unbuffered hypertonic bolus. Post-exercise recovery requires restoring 125% to 150% of lost body mass alongside real-food sodium and potassium to prevent Exercise-Associated Hyponatremia (EAH).

Solve (Evidence-Based Protocol vs Commercial Hype): Rather than relying on overpriced, hypertonic commercial powders, we implement a structured 3-phase real-food and isotonic protocol:

- Phase 1 (Pre-Exercise Priming): Ingest 5 to 7 mL/kg of fluids (approx. 350–450 mL) 4 hours prior to running paired with a salted whole-food snack (e.g., pretzels or salted banana) to establish euhydration without GI distress.
- Phase 2 (Intra-Exercise Pacing): Replace plain water with an isotonic solution providing 400 mg sodium and 30g carbohydrates per hour (sipping 200–250 mL every 15–20 minutes) to maintain plasma osmolarity and sustain running pace.
- Phase 3 (Post-Exercise Recovery): Consume 125% to 150% of the 2.08 kg weight deficit (~2.6 to 3.1 Liters of fluids) over 4 to 6 hours, utilizing nutrient-dense real foods (watermelon, sodium-rich vegetable broth, Greek yogurt, or chocolate milk) for rapid glycogen and electrolyte re-synthesis.
EN: "Replace commercial mega-dose powders with isotonic fluid pacing (400 mg sodium/hour) during long runs, and restore 150% of sweat loss with mineral-rich whole foods afterward."

ES: "Reemplace los polvos comerciales concentrados con hidratación isotónica dosificada (400 mg de sodio/hora) durante carreras largas y reponga el 150% del sudor perdido con alimentos reales ricos en minerales."


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and commercial claim fallacies) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial, el estrés térmico y los mitos comerciales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 09 (Mod 09 Discussion: Electrolyte Protocols vs. Commercial Claims)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 09 Foro de Discusión: Protocolos de Electrolitos vs. Afirmaciones Comerciales


### Homeostasis Electrolítica, Reclamos Comerciales y Seguridad en el Calor Desértico

La hidratación efectiva en entornos de calor extremo como el Condado de Yuma y el Desierto de Sonora requiere un riguroso equilibrio mineral. La publicidad comercial a menudo promueve afirmaciones engañosas: bebidas deportivas azucaradas para esfuerzos leves, costosas "aguas con electrolitos" con cantidades insignificantes de minerales que no evitan los calambres, o polvos concentrados con exceso de sodio sin el agua necesaria para diluirlos. Depender únicamente de agua simple durante el ejercicio prolongado genera riesgo de Hiponatremia Asociada al Ejercicio (EAH) por dilución de solutos, mientras que el uso incorrecto de productos comerciales provoca problemas digestivos y deshidratación osmótica. En este foro, contrastará las afirmaciones comerciales frente a las pautas científicas ( PAGA 2018 / Guías Alimentarias para los Estadounidenses DGA 2025–2030 / ACSM ). ¡Seleccione su Ruta de Aprendizaje , audite el caso con Google Gemini y defienda un protocolo basado en evidencia!


### Estructura de Entrega para el Foro (Vence el Jueves a las 11:59 PM MST)


#### Parte 1: Reconocimiento de Patrones y Auditoría del Producto Comercial

Reporte las métricas de sudoración y líquidos del cliente. Identifique el producto o afirmación comercial que utiliza y explique por qué falla fisiológicamente en condiciones desérticas.


#### Parte 2: Aplicación de Reglas (Pautas ACSM / PAGA 2018 / DGA 2025–2030)

Explique el umbral crítico del 2.0% de déficit de masa corporal, la tasa óptima de reposición de sodio (300 a 600 mg por hora en esfuerzo prolongado) y la prevención de la hiponatremia por dilución.


#### Parte 3: Resolución de la Brecha (Protocolo de 3 Fases y Tarjeta Bilingüe)

Diseñe un protocolo hídrico en tres fases (Pre-ejercicio, Intra-ejercicio y Post-ejercicio al 125–150% del peso perdido) priorizando alimentos reales o soluciones de rehidratación accesibles, e incluya la tarjeta de instrucciones de 2 oraciones en inglés y español.


### Modelo de Respuesta de Alta Fidelidad 10/10

El atleta C.V. presenta una tasa de sudoración de 1.8 L/h bajo el calor de Yuma. Creyó en la publicidad de un polvo comercial que prometía "eliminar 100% de los calambres con hidratación 10 veces más rápida", pero al mezclar 1,500 mg de sodio en solo 8 oz de agua provocó un retraso gástrico osmótico severo. Luego, al beber únicamente agua simple en carrera, sufrió un déficit del 3.2% de peso corporal y calambres agudos por dilución electrolítica.

Las pautas de ACSM y PAGA 2018 establecen que pérdidas de masa superiores al 2.0% deterioran la termorregulación y el rendimiento. En calor extremo, el reemplazo debe ser de 300 a 600 mg de sodio por hora en soluciones isotónicas al 6-8%, reponiendo después del 125% al 150% del peso perdido con alimentos reales y sodio para evitar la hiponatremia (EAH).

Protocolo de 3 Fases: Pre-ejercicio (5 a 7 mL/kg de líquidos 4 horas antes con un refrigerio salado como plátano con sal o pretzels), Intra-ejercicio (200-250 mL cada 15-20 min aportando 400 mg de sodio/hora en solución isotónica) y Post-ejercicio (reponer de 2.6 a 3.1 Litros de líquidos [125-150% del déficit de 2.08 kg] en 4 a 6 horas combinando alimentos ricos en minerales como caldo vegetal, yogur griego o sandía). Tarjeta de Instrucción Bilingüe: "Reemplace los polvos comerciales concentrados con hidratación isotónica dosificada (400 mg de sodio/hora) durante carreras largas y reponga el 150% del sudor perdido con alimentos reales ricos en minerales."

HLTH-150 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 09)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
