## HLTH-150: LAB 10 - LIFE CYCLE NUTRITION / NUTRICIÓN EN EL CICLO DE VIDA 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This module examines the physiological and metabolic adjustments required across the human lifespan, from youth to aging populations. Students will evaluate how resting metabolic rates shift, how lean tissue mass changes, and how specific micronutrient needs evolve to preserve bone density and neuromuscular function. All lifespan baselines, nutritional modifications, and age-specific targets align exclusively with our dual SSoT: the current **U.S. Dietary Guidelines for Americans** and the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* *Español (Regional): Este módulo examina los ajustes fisiológicos y metabólicos requeridos a lo largo del ciclo de vida de los seres humanos, desde la juventud hasta las poblaciones en proceso de envejecimiento. Los estudiantes evaluarán cómo cambian las tasas metabólicas en reposo, cómo varía la masa de tejido magro y cómo evolucionan las necesidades de micronutrientes específicos para preservar la densidad ósea y la función neuromuscular. Todos los criterios de evaluación se alinean exclusivamente con nuestro SSoT dual: las **Pautas Dietéticas para Estadounidenses** vigentes y las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.7])** Identify how nutritional needs change throughout the life cycle, including youth, adult, and aging populations.
* *Español (Regional) ([LO 2.7]): Identificar cómo cambian las necesidades nutricionales a lo largo del ciclo de vida, incluyendo poblaciones jóvenes, adultas y de edad avanzada.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Recognize progressive age-related patterns of sarcopenia, decreased bone mineral density, down-regulated basal energy expenditure, and micronutrient malabsorption signs.
2. **Rule / Regla:** Apply formal age-calibrated Recommended Dietary Allowances (RDA) for key lifecycle inputs (such as calcium, Vitamin D, and Vitamin B12). Pair these with the protein guidelines established in the SSoT (greater than or equal to 1.2 g/kg for aging cohorts to preserve lean mass).
3. **Solve / Solución:** Formulate an evidence-based life cycle nutritional profile matrix that targets age-specific physiological degradation while maintaining absolute safety and compliance with federal dietary guidelines.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Lifespan Nutrient Calibration / Objetivo: Calibración de Nutrientes según el Ciclo de Vida

Students will initialize their age-stratified simulation templates inside the digital sandbox workspace using the setup metrics wrapped below.

::: {.callout-note}
## Worked Example: Step-by-Step Guidance / Ejemplo Práctico Paso a Paso
**Context & Application:** When completing this lab assignment, follow this structured three-step approach based on our Single Sources of Truth (PAGA 2018 / ACSM 12th Ed.):

1. **Step 1 (Identify Pattern):** Review the client or case profile parameters for baseline activity, physiological constraints, or nutritional markers.
2. **Step 2 (Apply Rule):** Cross-reference the specific federal guidelines, volume targets, or physiological formulas required for the assessment.
3. **Step 3 (Solve):** Formulate your final recommendation or calculation clearly within the submission template below.
:::

```text
## METABOLIC_STRATA:
- Target Group: Aging master athlete cohort (65-75 years old)
- Primary Clinical Presentation: Sarcopenia markers, progressive bone density decreases
- Daily Baseline Log: 1,800 kcal/day (Protein intake: 0.8 g/kg, Calcium intake: 800 mg)
###
```

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Input the age-specific intake and physical markers into the lifecycle modeling database.
2. Calculate the target daily protein and micronutrient mass values required using federal RDA standards.
3. Audit the current intake baseline to explain how low protein and mineral parameters accelerate tissue degradation over time.

---

## Part B: Practical Application (Onsite Lab) / Aplicación Práctica Presencial (Laboratorio)

## Location: Community College GY 116 Allied Health Testing Workspace

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Design a comprehensive lifespan modification grid comparing youth and aging physical targets across major macro blocks.
2. Formulate an evidence-based whole-food meal model that satisfies the elevated daily mineral benchmarks calculated in Part A.
3. Complete final compliance tracking logs to ensure absolute alignment with federal life cycle recommendations.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This assignment is evaluated using the strict **10/7/0 Mastery Scale** / *Esta asignación se evalúa utilizando la escala estricta de Maestría **10/7/0**:*

* **10 (Exemplary / Ejemplar):**
  * **English:** Zero-drift integration. All core guidelines are applied exactly, target parameters remain securely enclosed within delimiter structures (`###`), and bilingual parity is fully preserved.
  * *Español (Regional): Integración con cero desviaciones. Todas las pautas de referencia se aplican exactamente, los parámetros de configuración permanecen contenidos de forma segura dentro de las estructuras delimitadoras (`###`) y se conserva por completo la paridad bilingüe.*
* **7 (Competent / Competente):**
  * **English:** Core performance metrics are safe, safe thermal boundaries are maintained, and calculations are accurate, but minor regional translation gaps, loose formatting, or structural layout misplacements are flagged.
  * *Español (Regional): Las métricas de rendimiento principales son seguras, se mantienen los límites de seguridad térmica y los cálculos son precisos, pero se señalan brechas menores de traducción regional, formato suelto o desalineaciones en la estructura.*
* **0 (Recalibrate / Recalibrar):**
  * **English:** Critical calculation drift is present, safety thresholds are violated, commercial/fad-based trends are promoted instead of the federal SSoT, or core data inputs are left un-delimited.
  * *Español (Regional): Se presenta una desviación crítica en los cálculos, se violan los límites de seguridad, se promueven tendencias comerciales en lugar de la Fuente Única de Verdad (SSoT) federal, o las entradas de datos clave se dejan sin delimitar.*

---

## HLTH-150 Module Discussion: Lifespan Requirements vs. Commercial Anti-Aging Claims

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Evaluate the target configuration variables to construct your lifecycle tracking models, and defend your nutrient timing adjustments using evidence-based federal reference standards.
* **Español (Regional):** Evaluar las variables de configuración para construir sus modelos de seguimiento del ciclo de vida y defender sus ajustes de tiempo de nutrientes utilizando los estándares de referencia federales basados en evidencia.
###



## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
