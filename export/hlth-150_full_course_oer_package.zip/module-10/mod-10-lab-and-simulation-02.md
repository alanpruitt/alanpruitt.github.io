## HLTH-150: Mod 10 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Lab & Simulation: Pre- and Post-Workout Meal Plan Audit

Laboratorio del Módulo 10: Sincronización de Nutrientes y Ventanas de Alimentación

- Pre-Exercise Carbohydrate Loading Window (1–4 g/kg, 1–4 Hours Prior): Consuming 1–4 g/kg of easily digested, low-fat, moderate-fiber whole-food carbohydrates 1 to 4 hours before training to top off liver and muscle glycogen. En palabras sencillas: Comer de 1 a 4 gramos de carbohidrato por kilo entre 1 y 4 horas antes de entrenar (ej. avena con plátano o arroz con pollo) para llegar con energía sin pesadez.
- Intra-Workout Carbohydrate Target (30–60 g/hr for Sessions >60 Min): For continuous training or field labor lasting >60 minutes, supplying 30–60 g/hr of carbohydrates maintains blood glucose and delays central fatigue. En palabras sencillas: Cuando el entrenamiento dura más de una hora seguida, aportar de 30 a 60 gramos de carbohidrato por hora mantiene estable la glucosa y evita el bajón.
- Post-Exercise Glycogen & MPS Resynthesis Window (1.0–1.2 g/kg/hr Carbs + 20–40 g Protein): Rebuilding depleted glycogen and repairing muscle fibers within 30–120 minutes post-exercise using whole-food meals (DGA 2025–2030). En palabras sencillas: Al terminar de entrenar, combinar carbohidratos reales con 20 a 40 gramos de proteína para recargar el músculo y acelerar la recuperación.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Nutrient timing coordinates carbohydrate and protein intake around training sessions to maximize muscle glycogen storage and accelerate tissue repair. Consuming easily digestible carbohydrates within the pre-exercise fueling window ensures circulating blood glucose is available during sustained exertion. Ingesting carbohydrates and protein within two hours post-exercise speeds glycogen resynthesis and halts muscle protein breakdown.


#### En Palabras Sencillas (Norteño Context)

Comer a tiempo antes y después de entrenar es como echarle gasolina y checarle el aceite a la troca antes de salir al campo: si no le pones a la hora debida, te quedas tirado a medio camino. Si los términos técnicos se ponen pesados, concéntrate primero en cómo coordinar los carbohidratos antes y después de hacer ejercicio.


### Nutrient Timing Windows, Glycogen Resynthesis, & Substrate Pacing

In this laboratory assignment, you will conduct a qualitative nutrient timing audit and construct an evidence-based fueling prescription. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze glycogen depletion, pre-exercise meal spacing, and post-exercise recovery windows, apply 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) standards, and execute an AI-driven clinical simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría cualitativa de la sincronización de nutrientes y diseñará una prescripción de alimentación basada en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando el agotamiento de glucógeno y las ventanas de recuperación según las Guías Alimentarias para los Estadounidenses 2025-2030.

- HLTH-150.10.3.AY26-27: Analyze physiological fatigue patterns, substrate oxidation rates, and glycogen depletion risks during sustained exercise. Analizar los patrones de fatiga fisiológica, las tasas de oxidación de sustratos y los riesgos de agotamiento de glucógeno durante el ejercicio sostenido.
- HLTH-150.10.4.AY26-27: Design evidence-based nutrient timing schedules, pre- and post-fueling windows, and bilingual coaching cue cards aligned with the 2025-2030 Dietary Guidelines for Americans. Diseñar horarios de sincronización de nutrientes basados en evidencia, ventanas de alimentación previa y posterior, y tarjetas de instrucción bilingües alineadas con las Guías Alimentarias para los Estadounidenses 2025-2030.
- Module Window / Ventana del Módulo: Opens Tuesday, October 20, 2026, at 12:00 AM MST Abre el martes, 20 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 26, 2026, at 11:59 PM MST Lunes, 26 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Mastery Scale) Ponderación de evaluación para laboratorios semanales y simulaciones prácticas (Escala de Dominio 10/7/0)

### Lab Objectives / Objetivos del Laboratorio

Objetivos del Laboratorio

- Audit the physiological mechanisms of glycogen depletion, gastric emptying rates, and substrate utilization during sustained physical exertion. Auditar los mecanismos fisiológicos del agotamiento de glucógeno, el vaciamiento gástrico y la utilización de sustratos durante el esfuerzo físico continuo.
- Apply the 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) to structure progressive carbohydrate and protein intake windows that preserve metabolic performance. Aplicar las Guías Alimentarias para los Estadounidenses 2025-2030 ("Enfoque en Alimentos Reales") para estructurar ventanas de consumo de carbohidratos y proteínas.
- Formulate a 4-week nutrient timing remediation plan paired with bilingual coaching cue cards in English and Spanish. Formular un plan de sincronización de nutrientes de 4 semanas con tarjetas de instrucción bilingües en inglés y español.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-10

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos del Caso Nutricional

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Clinical metabolic support; managing fasted exercise risks, post-rehabilitation hypoglycemia, and structured meal spacing for outpatient physical therapy.

Focus: Occupational community nutrition; structuring affordable, culturally responsive pre-shift fueling and sustained energy pacing for agricultural field laborers in Yuma County.

Focus: Competitive athletic performance; periodizing pre-match glycogen supercompensation, intra-match carbohydrate pacing, and rapid post-match anabolic window resynthesis.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete nutrient timing audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline metabolic profile.
- Part 1: Pattern Recognition: Identify specific substrate limitations (glycogen depletion, fasted hypoglycemia, or intra-workout energy crashes).
- Part 2: Rule Application: Cite 2025-2030 Dietary Guidelines for Americans whole-food timing rules and recovery carbohydrate ratios.
- Part 3: Solving the Gap (Active Verification & Fueling Prescription): In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your 4-week nutrient timing plan protects client safety and aligns with 2025-2030 Dietary Guidelines for Americans ("Real Food" focus). Detail your pre-exercise spacing, intra-exercise carbohydrate oxidation, post-exercise glycogen resynthesis window, and 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient J.T. arrives at morning cardiac rehabilitation in a 12-hour fasted state, precipitating acute glycogen depletion and symptomatic hypoglycemia (blood glucose dropping to 68 mg/dL) within 25 minutes of aerobic exercise. Without circulating exogenous glucose, hepatic glycogenolysis cannot sustain skeletal muscle work, causing central fatigue and autonomic tremors.

Part 2: Rule Application (2025-2030 Dietary Guidelines for Americans Standards): Under the 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) and clinical sports nutrition standards, individuals engaging in therapeutic exertion must establish a pre-exercise fueling window 60 to 90 minutes prior, delivering 1.0 g/kg of low-glycemic, unrefined complex carbohydrates paired with moderate protein to maintain euglycemia. Post-exercise resynthesis requires a 3:1 carbohydrate-to-protein whole-food ratio within 45 minutes to halt catabolism.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): 4-Week Nutrient Timing Protocol: Key Point — Pre-Session Fueling (75 min prior): 1 cup steel-cut oats with 1 tablespoon ground flaxseed and 1/2 cup fresh berries (approx. 45g complex unrefined carbohydrates, 8g protein) to stabilize baseline blood glucose at 110-130 mg/dL. Key Point — Intra-Session Monitoring: Water intake of 4-6 oz every 15 minutes; emergency rescue carbohydrate (4 oz 100% orange juice) on standby if glucose dips below 80 mg/dL. Key Point — Post-Session Recovery (Within 45 min): 1 cup plain Greek yogurt with 1 sliced banana (approx. 30g carbohydrate, 15g protein, 2:1 to 3:1 whole-food ratio) supporting glycogen resynthesis and cellular repair. Active Verification (Own Voice): In my clinical reasoning, J.T.'s acute hypoglycemic crash at minute 25 is directly caused by entering cardiac rehabilitation in a prolonged fasted state while managing Type 2 diabetes. Fasted exercise forces hepatic gluconeogenesis to keep pace with working muscle uptake, which fails under physical exertion and precipitates dangerous blood glucose drops. By scheduling a whole-food complex carbohydrate and protein meal (steel-cut oats with flaxseed and berries) 75 minutes prior, we provide a slow, sustained systemic glucose release without spiking reactive insulin. Furthermore, ingesting plain Greek yogurt with banana within 45 minutes post-exercise exploits the insulin-independent GLUT4 translocation window to rapidly restore depleted glycogen stores without requiring artificial supplements, adhering fully to the 2025-2030 Dietary Guidelines "Real Food" mandate.

EN: "Eat your bowl of oatmeal with fruit one hour before therapy to keep your blood sugar steady and protect your heart during exercise. After your session, enjoy yogurt with banana within forty-five minutes to recharge your muscles safely."

ES: "Coma su tazón de avena con fruta una hora antes de su terapia para mantener su glucosa estable y proteger su corazón durante el ejercicio. Después de la sesión, disfrute de un yogur con plátano antes de cuarenta y cinco minutos para recuperar sus músculos de manera segura."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_150_M10_Nutrient_Timing_Audit.pdf


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 10 (Mod 10 Lab: Pre- and Post-Workout Meal Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 10 Práctica de Lab y Simulación: Sincronización de Nutrientes y Ventanas de Alimentación

Ventanas de Sincronización, Resíntesis de Glucógeno y Ritmo de Sustratos


### Ventanas de Sincronización, Resíntesis de Glucógeno y Ritmo de Sustratos

En esta práctica de laboratorio, realizará una auditoría cualitativa de la sincronización de nutrientes y diseñará una prescripción de alimentación basada en evidencia. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará el agotamiento de glucógeno y las ventanas de recuperación, aplicando los estándares de las Guías Alimentarias para los Estadounidenses 2025-2030 ("Enfoque en Alimentos Reales") y ejecutará una simulación con Google Gemini.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Soporte metabólico clínico; manejo de riesgos de ejercicio en ayunas, hipoglucemia post-rehabilitación y espaciamiento de comidas en terapia ambulatoria.

Enfoque: Nutrición comunitaria ocupacional; estructuración de alimentación previa accesible y culturalmente adecuada para jornaleros agrícolas en Yuma.

Enfoque: Rendimiento deportivo competitivo; periodización de supercompensación de glucógeno, ritmo intra-partido y resíntesis anabólica post-partido.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Comunitaria / Ruta 3 Deportiva) e incluya sus iniciales.


#### Parte 1: Reconocimiento de Patrones

Identifique las limitaciones de sustrato de su cliente (agotamiento de glucógeno, hipoglucemia en ayunas o fatiga intra-entrenamiento).


#### Parte 2: Aplicación de Reglas (DGA 2025-2030)

Aplique los estándares de alimentos reales de las Guías Alimentarias 2025-2030 y las proporciones de recuperación de carbohidratos.


#### Parte 3: Resolución de la Brecha

Detalle el plan de sincronización de nutrientes de 4 semanas con alimentos integrales, junto con una tarjeta de instrucción bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: El paciente J.T. acude a la rehabilitación cardíaca matutina en un estado de ayuno de 12 horas, lo que precipita un agotamiento agudo de glucógeno y una hipoglucemia sintomática (caída de glucosa a 68 mg/dL) a los 25 minutos de ejercicio aeróbico. Sin glucosa exógena circulante, la glucogenólisis hepática no puede sostener el trabajo del músculo esquelético, provocando fatiga central y temblores autonómicos.

Parte 2: Aplicación de Reglas (Guías Alimentarias 2025-2030): Según las Guías Alimentarias para los Estadounidenses 2025-2030 ("Enfoque en Alimentos Reales") y los estándares clínicos, las personas que realizan esfuerzo terapéutico deben establecer una ventana de alimentación previa de 60 a 90 minutos antes, consumiendo 1.0 g/kg de carbohidratos complejos no refinados de bajo índice glucémico combinados con proteína moderada para mantener la euglucemia. La resíntesis posterior requiere una proporción de 3:1 de carbohidratos a proteínas dentro de los 45 minutos para frenar el catabolismo.

Parte 3: Resolución de la Brecha: Key Point — Alimentación Previa (75 min antes): 1 taza de avena de grano cortado con 1 cucharada de linaza molida y 1/2 taza de bayas frescas (aprox. 45 g de carbohidratos complejos no refinados, 8 g de proteína) para estabilizar la glucosa entre 110 y 130 mg/dL. Key Point — Monitoreo Intra-Sesión: Consumo de 4 a 6 oz de agua cada 15 minutos; carbohidrato de rescate de emergencia (4 oz de jugo de naranja 100%) disponible si la glucosa cae por debajo de 80 mg/dL. Key Point — Recuperación Post-Sesión (en menos de 45 min): 1 taza de yogur griego natural con 1 plátano rebanado (aprox. 30 g de carbohidratos, 15 g de proteína, relación 2:1 a 3:1 de alimentos integrales) para la resíntesis de glucógeno y reparación muscular. Verificación Activa (Voz Propia): En mi juicio clínico, el desplome hipoglucémico de J.T. a los 25 minutos se debe directamente a entrar en esfuerzo en ayunas prolongado mientras maneja Diabetes Tipo 2. El ejercicio en ayunas obliga a la gluconeogénesis hepática a competir con la captación muscular, fallando bajo esfuerzo e induciendo caídas peligrosas de glucosa. Al programar una comida de carbohidratos complejos y proteína 75 minutos antes, aseguramos una liberación sostenida de glucosa sin provocar picos reactivos de insulina. Consumir yogur griego con plátano en menos de 45 minutos post-ejercicio aprovecha la translocación de GLUT4 para recargar glucógeno sin suplementos artificiales, cumpliendo plenamente con el mandato de comida real de las DGA 2025-2030. Tarjeta Bilingüe: "Coma su tazón de avena con fruta una hora antes de su terapia para mantener su glucosa estable y proteger su corazón durante el ejercicio. Después de la sesión, disfrute de un yogur con plátano antes de cuarenta y cinco minutos para recuperar sus músculos de manera segura."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M10_Nutrient_Timing_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 10)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
