## HLTH-150: Mod 10 Required Readings Pre During And Post Workout Meal Timing

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Required Readings: Pre-, During-, and Post-Workout Meal Timing

Lecturas Obligatorias: Ventanas de Sincronización de Nutrientes y Resíntesis de Glucógeno


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Nutrient timing means eating specific carbohydrates and protein at strategic intervals before, during, and after exercise. Eating at the right times keeps your blood sugar steady and quickly refills muscle fuel tanks called glycogen. This helps athletes and desert workers avoid hitting the wall and recover much faster.


#### En Palabras Sencillas (Norteño Context)

Piensa en esto como echarle gasolina a la troca antes de cruzar la Rumorosa o trabajar bajo el solazo de Yuma; no te esperas a que el tanque esté seco para buscar la gasolinera. Si los términos técnicos se ponen pesados, concéntrate primero en comer carbohidratos saludables antes del esfuerzo y recargar proteína con fruta al terminar.


### Regional Focus: Energy Availability & Desert Training Demands

Enfoque Regional: Disponibilidad Energética y Exigencias de Entrenamiento en el Desierto

In Yuma County and the lower Colorado River basin, high ambient temperatures impose additional physiological stress, accelerating glycogen depletion and elevating metabolic energy expenditure. Under these demanding environmental conditions, coordinating nutrient timing—ensuring adequate carbohydrate availability before exercise and prompt glycogen restoration afterward—is vital to prevent premature fatigue, sustain cognitive alertness, and protect lean tissue mass among athletes and outdoor workers.

En el condado de Yuma y la cuenca baja del río Colorado, el calor ambiental impone estrés fisiológico adicional, acelerando el agotamiento del glucógeno. Bajo estas condiciones, coordinar la sincronización de nutrientes —asegurando disponibilidad de carbohidratos antes del ejercicio y su pronta restauración posterior— es vital para prevenir la fatiga prematura y proteger la masa magra.


### Reading 1: Pre-Exercise Fueling & Glycogen Priming

Lectura 1: Alimentación Pre-Ejercicio y Preparación de Glucógeno


#### Step 1: Glycogen Loading and Meal Timing Spacing

Carga de Glucógeno y Espaciamiento de Comidas

Pre-exercise nutrition aims to top off liver and skeletal muscle glycogen stores, prevent hunger, and ensure optimal hydration. Consuming a carbohydrate-rich meal (1 to 4 g/kg body weight) 1 to 4 hours prior to exercise allows sufficient time for digestion, absorption, and hepatic glycogenesis. Eating too close to exercise can provoke reactive hypoglycemia due to an insulin spike coinciding with the onset of muscular contractions.

La nutrición pre-ejercicio busca maximizar las reservas hepáticas y musculares de glucógeno, prevenir el hambre y asegurar una hidratación óptima. Consumir una comida rica en carbohidratos (1 a 4 g/kg de peso) de 1 a 4 horas antes permite una digestión y absorción adecuadas.


#### Step 2: Federal Dietary Guidance Alignment (2025-2030 Dietary Guidelines for Americans & Real Food Focus)

Alineación con las Guías Dietéticas Federales (SSoT 2025-2030 DGA y Enfoque de Comida Real)

In strict alignment with the 2025-2030 Dietary Guidelines for Americans ("Real Food" focus) and sports nutrition timing standards:

De acuerdo con las normas de las Guías Alimentarias para los Estadounidenses 2025-2030 (DGA, con enfoque en alimentos reales) y estándares deportivos:

- Complex Carbohydrate Focus: Emphasize whole-grain complex carbohydrates, oats, and fruits to provide sustained glucose release and steady glycemic control. Enfoque en Carbohidratos Complejos: Priorizar carbohidratos complejos integrales, avena y frutas para asegurar una liberación sostenida de glucosa.
- Minimizing GI Distress: Restrict high-fat and excessive fiber items immediately before training to prevent delayed gastric emptying and gastrointestinal cramping. Minimizar el Malestar Gástrico: Restringir alimentos altos en grasa y fibra excesiva inmediatamente antes de entrenar para evitar un vaciamiento gástrico lento.

### Reading 2: Intra-Exercise Fueling & Carbohydrate Oxidation

Lectura 2: Alimentación Intra-Ejercicio y Oxidación de Carbohidratos


#### Step 1: Sparing Hepatic Glycogen During Prolonged Exertion

Ahorro de Glucógeno Hepático Durante el Esfuerzo Prolongado

For continuous exercise lasting longer than 60 to 90 minutes, exogenous carbohydrate ingestion (30 to 60 g/hr up to 90 g/hr for multi-hour endurance events using multiple transportable carbohydrates like glucose-fructose blends) maintains blood glucose oxidation, spares liver glycogen reserves, and delays central nervous system fatigue.

Para ejercicios continuos mayores de 60 a 90 minutos, la ingestión exógena de carbohidratos (30 a 60 g/h) mantiene la oxidación de glucosa en sangre, ahorra reservas hepáticas de glucógeno y retrasa la fatiga del sistema nervioso central.


#### Step 2: Gastric Emptying and Transport Kinetics

Vaciamiento Gástrico y Cinética de Transporte

Intra-workout fueling solutions must balance concentration and osmolality. Isotonic solutions (6% to 8% carbohydrate concentration) empty rapidly from the stomach, matching fluid absorption rates while delivering necessary glucose directly to active muscles via sodium-glucose cotransporters (SGLT1).

Las soluciones para el intra-entrenamiento deben equilibrar concentración y osmolaridad. Las soluciones isotónicas (6% a 8% de concentración) se vacían rápidamente del estómago, igualando las tasas de absorción de líquidos mientras entregan glucosa a los músculos activos.


### Reading 3: The Post-Exercise Anabolic Window & Glycogen Resynthesis

Lectura 3: Ventana Anabólica Post-Ejercicio y Resíntesis de Glucógeno

Post-exercise recovery focuses on two primary physiological priorities: replenishing depleted glycogen stores and stimulating muscle protein synthesis (MPS):

La recuperación post-ejercicio se centra en dos prioridades fisiológicas: reponer las reservas de glucógeno y estimular la síntesis de proteínas musculares (MPS):


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Eating 1 to 4 hours prior allows sufficient gastric emptying and hepatic processing, preventing the insulin surge from coinciding with muscular contractions and avoiding reactive hypoglycemia.

Respuesta en Español: Comer de 1 a 4 horas antes permite un vaciado gástrico adecuado y procesamiento hepático, previniendo que el pico de insulina coincida con el inicio de la contracción y evitando la hipoglucemia reactiva.

English Response: Exogenous carbohydrate feeding maintains blood glucose oxidation, spares liver glycogen reserves, and delays central nervous system fatigue during prolonged exertion.

Respuesta en Español: La alimentación exógena de carbohidratos mantiene la oxidación de glucosa sanguínea, ahorra las reservas hepáticas de glucógeno y retrasa la fatiga del sistema nervioso central.

English Response: Immediately post-exercise, muscle cell membranes exhibit heightened insulin sensitivity and insulin-independent glucose uptake channels, allowing rapid glycogen restoration when paired with amino acids.

Respuesta en Español: Inmediatamente después de entrenar, las membranas musculares muestran mayor sensibilidad a la insulina y canales de captación de glucosa independientes de la insulina, permitiendo una rápida restauración.


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 10 (Mod 10 Required Readings: Pre-, During-, and Post-Workout Meal Timing)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 10 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 10)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
