# HLTH-150: Mod 10 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 10 Discussion: Meal Timing vs. Total Daily Nutrition


### Pre-Fueling, Intra-Workout Pacing & Post-Exercise Recovery

While total daily macronutrient intake establishes the foundation of sports nutrition and clinical health, strategic nutrient timing dictates how efficiently energy is delivered and recovered during intensive training. From preventing reactive hypoglycemia before exercise to maximizing glycogen resynthesis in the post-workout window, timing separates average adaptation from elite recovery. Select your Build Your Own Journey Track below, audit a real-world nutrient timing case using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / U.S. Dietary Guidelines / ACSM Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #150-10

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Managing energy availability and timing pre-exercise nutrition for rehabilitation patients experiencing fatigue during physical therapy sessions.

Focus: Affordable pre-shift fueling strategies for agricultural workers in Yuma County to sustain energy during strenuous outdoor shifts.

Focus: Pre-event glycogen loading, intra-workout carbohydrate pacing (30 to 60g/hr), and post-exercise recovery optimization in collegiate athletes.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Timing Errors / Ruta y Errores de Sincronización: State your chosen track and report the client's current timing errors (e.g., fasted exercise, poor meal spacing, or post-workout delays). Indique la ruta seleccionada y reporte los errores de sincronización del cliente (ej. ejercicio en ayunas o retrasos post-entrenamiento).
- Clinical Framing Protocol Analysis (Pattern / Rule / Solve) / Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Explain why improper timing compromises performance or recovery due to hypoglycemia or missed anabolic windows (Pattern), cite federal/ACSM timing standards (Rule), and provide the structured fueling schedule (Solve). Explique por qué una mala sincronización afecta el rendimiento o recuperación (Patrón), cite las pautas ACSM/USDA (Regla) y detalle el horario estructurado (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence explanation of the nutrient timing plan in both English and Spanish so your client can execute it easily. Proporcione una explicación concisa de 2 oraciones sobre el plan de sincronización en inglés y español para que su cliente la aplique fácilmente.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their timing recommendations, compare pre- and post-exercise fueling strategies, and discuss how timing protocols must adapt across clinical, community, and athletic settings.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Athlete K.L. consumes a heavy meal 30 minutes before soccer practice, causing gastric distress due to delayed gastric emptying during exertion. Furthermore, she fails to consume intra-workout carbohydrates and delays post-workout refueling by 2 hours, missing optimal windows for glycogen resynthesis and muscle repair.

Rule Application (ACSM / PAGA 2018 Standards): According to ACSM and ISSN standards, pre-exercise meals should be spaced 2 to 4 hours prior to training. During intensive play exceeding 90 minutes, athletes should consume 30 to 60 g/hr of carbohydrates, followed by 1.0 to 1.2 g/kg of high-glycemic carbohydrates and 0.30 to 0.40 g/kg of protein post-exercise.

Solve (Nutrient Timing Prescription): We restructure K.L.'s fueling window across three distinct phases:

- Pre-Exercise (2.5 hours prior): 75g complex carbohydrates with lean protein (e.g., oatmeal with sliced banana and Greek yogurt).
- Intra-Exercise (During practice): 30g carbohydrates per hour via an isotonic sports drink or fruit chew.
- Post-Exercise (Within 45 minutes): 70g high-glycemic carbohydrates + 25g whey protein shake blended with fruit and milk.
EN: "Eat your pre-practice meal 3 hours early, sip sports drinks during training, and consume your recovery shake immediately afterward."

ES: "Consuma su comida pre-entrenamiento 3 horas antes, tome bebidas deportivas durante la práctica y consuma su malteada de recuperación inmediatamente después."


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 10 (Mod 10 Discussion: Meal Timing vs. Total Daily Nutrition)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 10 Foro de Discusión: Sincronización de Nutrientes


### Alimentación Previa, Pacing Intra-Entrenamiento y Recuperación

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar la sincronización de nutrientes según las pautas federales y de nutrición deportiva.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Reporte los errores de temporización del cliente (ej. ejercicio en ayunas o comidas muy pesadas antes de entrenar).


#### Parte 2: Aplicación de Reglas (Normas PAGA 2018 / ACSM)

Explique la importancia de espaciar los alimentos de 2 a 4 horas antes, consumir de 30 a 60 g/h de carbohidratos durante el ejercicio y aprovechar la ventana post-ejercicio.


#### Parte 3: Resolución de la Brecha (Plan de Sincronización y Tarjeta Bilingüe)

Diseñe un horario estructurado en tres fases (Pre, Intra y Post) con alimentos integrales y proporcione una tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

La atleta K.L. consume una comida pesada 30 minutos antes de practicar, provocando malestar estomacal. Además, no consume carbohidratos intra-entrenamiento y retrasa la recuperación post-ejercicio por 2 horas, perdiendo la ventana óptima de resíntesis de glucógeno.

Las pautas de ACSM y ISSN recomiendan espaciar las comidas previas de 2 a 4 horas, ingerir de 30 a 60 g/h de carbohidratos en entrenamientos mayores a 90 minutos y reponer con 1.0 a 1.2 g/kg de carbohidratos con proteína tras el ejercicio.

Plan en 3 Fases: Pre-ejercicio (75g de carbohidratos complejos 2.5 horas antes), Intra-ejercicio (30g de carbohidratos por hora) y Post-ejercicio (70g de carbohidratos de alto índice glucémico + 25g de proteína de suero). Tarjeta de Instrucción Bilingüe: "Consuma su comida pre-entrenamiento 3 horas antes, tome bebidas deportivas durante la práctica y consuma su malteada de recuperación inmediatamente después."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:
