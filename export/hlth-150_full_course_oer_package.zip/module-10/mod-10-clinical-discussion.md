## HLTH-150: Mod 10 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 10) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 10 Discussion: Meal Timing vs. Total Daily Nutrition


### Pre-Fueling, Intra-Workout Pacing & Post-Exercise Recovery

While total daily macronutrient intake establishes the foundation of sports nutrition and clinical health, strategic nutrient timing dictates how efficiently energy is delivered and recovered during intensive training. From preventing reactive hypoglycemia before exercise to maximizing glycogen resynthesis in the post-workout window, timing separates average adaptation from elite recovery. Select your Build Your Own Journey Track below, audit a real-world nutrient timing case using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / U.S. Dietary Guidelines / ACSM Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #150-10

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Managing energy availability and timing pre-exercise nutrition for rehabilitation patients experiencing fatigue during physical therapy sessions.

Focus: Affordable pre-shift fueling strategies for agricultural workers in Yuma County to sustain energy during strenuous outdoor shifts.

Focus: Pre-event glycogen loading, intra-workout carbohydrate pacing (30 to 60g/hr), and post-exercise recovery optimization in collegiate athletes.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Timing Errors / Ruta y Errores de Sincronización: State your chosen track and report the client's current timing errors (e.g., fasted exercise, poor meal spacing, or post-workout delays). Indique la ruta seleccionada y reporte los errores de sincronización del cliente (ej. ejercicio en ayunas o retrasos post-entrenamiento).
- Clinical Framing Protocol Analysis (Pattern / Rule / Solve) / Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Explain why improper timing compromises performance or recovery due to hypoglycemia or missed anabolic windows (Pattern), cite federal/ACSM timing standards (Rule), and provide the structured fueling schedule (Solve). Explique por qué una mala sincronización afecta el rendimiento o recuperación (Patrón), cite las pautas ACSM/USDA (Regla) y detalle el horario estructurado (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence explanation of the nutrient timing plan in both English and Spanish so your client can execute it easily. Proporcione una explicación concisa de 2 oraciones sobre el plan de sincronización en inglés y español para que su cliente la aplique fácilmente.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their timing recommendations, compare pre- and post-exercise fueling strategies, and discuss how timing protocols must adapt across clinical, community, and athletic settings.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Athlete K.L. consumes a heavy meal 30 minutes before soccer practice, causing gastric distress due to delayed gastric emptying during exertion. Furthermore, she fails to consume intra-workout carbohydrates and delays post-workout refueling by 2 hours, missing optimal windows for glycogen resynthesis and muscle repair.

Rule Application (ACSM / PAGA 2018 Standards): According to ACSM and ISSN standards, pre-exercise meals should be spaced 2 to 4 hours prior to training. During intensive play exceeding 90 minutes, athletes should consume 30 to 60 g/hr of carbohydrates, followed by 1.0 to 1.2 g/kg of high-glycemic carbohydrates and 0.30 to 0.40 g/kg of protein post-exercise.

Solve (Nutrient Timing Prescription): We restructure K.L.'s fueling window across three distinct phases:

- Pre-Exercise (2.5 hours prior): 75g complex carbohydrates with lean protein (e.g., oatmeal with sliced banana and Greek yogurt).
- Intra-Exercise (During practice): 30g carbohydrates per hour via an isotonic sports drink or fruit chew.
- Post-Exercise (Within 45 minutes): 70g high-glycemic carbohydrates + 25g whey protein shake blended with fruit and milk.
EN: "Eat your pre-practice meal 3 hours early, sip sports drinks during training, and consume your recovery shake immediately afterward."

ES: "Consuma su comida pre-entrenamiento 3 horas antes, tome bebidas deportivas durante la práctica y consuma su malteada de recuperación inmediatamente después."


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 10 (Mod 10 Discussion: Meal Timing vs. Total Daily Nutrition)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 10 Foro de Discusión: Sincronización de Nutrientes


### Alimentación Previa, Pacing Intra-Entrenamiento y Recuperación

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar la sincronización de nutrientes según las pautas federales y de nutrición deportiva.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Reporte los errores de temporización del cliente (ej. ejercicio en ayunas o comidas muy pesadas antes de entrenar).


#### Parte 2: Aplicación de Reglas (Normas PAGA 2018 / ACSM)

Explique la importancia de espaciar los alimentos de 2 a 4 horas antes, consumir de 30 a 60 g/h de carbohidratos durante el ejercicio y aprovechar la ventana post-ejercicio.


#### Parte 3: Resolución de la Brecha (Plan de Sincronización y Tarjeta Bilingüe)

Diseñe un horario estructurado en tres fases (Pre, Intra y Post) con alimentos integrales y proporcione una tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

La atleta K.L. consume una comida pesada 30 minutos antes de practicar, provocando malestar estomacal. Además, no consume carbohidratos intra-entrenamiento y retrasa la recuperación post-ejercicio por 2 horas, perdiendo la ventana óptima de resíntesis de glucógeno.

Las pautas de ACSM y ISSN recomiendan espaciar las comidas previas de 2 a 4 horas, ingerir de 30 a 60 g/h de carbohidratos en entrenamientos mayores a 90 minutos y reponer con 1.0 a 1.2 g/kg de carbohidratos con proteína tras el ejercicio.

Plan en 3 Fases: Pre-ejercicio (75g de carbohidratos complejos 2.5 horas antes), Intra-ejercicio (30g de carbohidratos por hora) y Post-ejercicio (70g de carbohidratos de alto índice glucémico + 25g de proteína de suero). Tarjeta de Instrucción Bilingüe: "Consuma su comida pre-entrenamiento 3 horas antes, tome bebidas deportivas durante la práctica y consuma su malteada de recuperación inmediatamente después."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 10)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
