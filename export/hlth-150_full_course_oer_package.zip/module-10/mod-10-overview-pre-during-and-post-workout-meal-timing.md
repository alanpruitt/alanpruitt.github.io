# HLTH-150: Mod 10 Overview Pre During And Post Workout Meal Timing

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 10 Overview: Pre-, During-, and Post-Workout Meal Timing


### Welcome to Module 10: Pre-, During-, and Post-Workout Meal Timing

Welcome to Week 10! Building upon our study of electrolyte and fluid balance, this week we examine the science of nutrient timing . In athletic training, physical therapy, and occupational performance, when you consume macronutrients is just as critical as what you consume. Optimizing pre-exercise glycogen stores, managing intra-event carbohydrate oxidation, and maximizing the post-exercise anabolic window dictate recovery velocity and physical adaptation.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify fueling fatigue patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) standards alongside Dietary Guidelines for Americans (DGA) baselines, and design individualized timing protocols.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 20, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 22, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 25, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 26, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 10 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze physiological fatigue patterns during prolonged exertion and identify glycogen depletion risks across diverse athletic and clinical scenarios. Analizar los patrones de fatiga fisiológica durante el esfuerzo prolongado e identificar riesgos de agotamiento de glucógeno.
- CLO 2 (Rule Application): Apply PAGA 2018 and DGA carbohydrate and protein timing standards, pre-exercise meal spacing rules, and post-exercise glycogen resynthesis thresholds. Aplicar las normas de sincronización de PAGA 2018 y DGA, las reglas de espaciamiento de comidas previas y los umbrales de resíntesis de glucógeno.
- CLO 3 (Problem Solving): Formulate an evidence-based nutrient timing prescription incorporating whole foods and targeted fueling windows tailored to intense training schedules. Formular una prescripción de sincronización de nutrientes basada en evidencia e integrada con alimentos integrales.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Timing nutrient delivery around physical therapy sessions for metabolic patients, managing post-surgical energy availability, and preventing hypoglycemic episodes.

Affordable pre-shift fueling strategies for manual laborers in Yuma County, sustained energy availability on limited budgets, and community nutrition education.

Maximizing glycogen supercompensation, intra-workout carbohydrate pacing (30 to 60g/hr), and post-exercise glycogen resynthesis protocols for competitive athletes.


### Module 10 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Nutrient Timing Windows, Pre-Fueling & Glycogen Resynthesis
- Discussion Board: Timing Protocols vs. Daily Macro Totals
- Lab Assignment: Fueling Window Audit, Pacing Formulation & Gemini AI Tool Kit
- Knowledge Check & Module Summary

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 10 (Mod 10 Overview: Pre-, During-, and Post-Workout Meal Timing)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 10 Visión General: Sincronización de Nutrientes


### Bienvenido al Módulo 10: Estrategias de Alimentación Pre, Intra y Post-Ejercicio

¡Bienvenido a la Semana 10! Basándonos en nuestro estudio sobre el balance hídrico, esta semana examinamos la ciencia de la sincronización de nutrientes (nutrient timing). En el entrenamiento deportivo y la salud clínica, el momento de consumo es tan crucial como la cantidad. Optimizar el glucógeno pre-ejercicio y maximizar la ventana anabólica post-ejercicio determina la velocidad de recuperación.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificarás patrones de fatiga, aplicarás los estándares de PAGA 2018 y DGA, y diseñarás protocolos de sincronización individualizados.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar los patrones de fatiga durante el esfuerzo prolongado e identificar los riesgos de agotamiento de glucógeno.
- CLO 2 (Regla): Aplicar las normas de sincronización de PAGA 2018 y DGA, las reglas de comidas previas y los umbrales de resíntesis de glucógeno.
- CLO 3 (Solución): Formular una prescripción de sincronización basada en evidencia e integrada con alimentos integrales adaptada a horarios de entrenamiento.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, continuará trabajando dentro de la ruta profesional que haya seleccionado:

Sincronización de nutrientes en terapia física para pacientes metabólicos, manejo de disponibilidad energética post-quirúrgica y prevención de hipoglucemia.

Estrategias accesibles de alimentación previa al turno para jornaleros en Yuma, energía sostenida con presupuestos limitados y educación comunitaria.

Maximización de la supercompensación de glucógeno, ritmo de carbohidratos intra-entrenamiento (30-60g/h) y protocolos de resíntesis post-ejercicio.


### Ruta de Aprendizaje del Módulo 10

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Ventanas de Sincronización, Alimentación Previa y Resíntesis de Glucógeno
- Foro de Discusión: Protocolos de Sincronización vs. Totales Diarios de Macronutrientes
- Práctica de Laboratorio: Auditoría de Ventanas de Alimentación, Formulación y Caja de Herramientas de IA
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA. Esta estructura es responsiva en dispositivos móviles, compatible con lectores de pantalla y diseñada para un acceso equitativo.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.


### Module 10 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 10 Required Readings: Pre-, During-, and Post-Workout Meal Timing →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 10 Discussion: Meal Timing vs. Total Daily Nutrition →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 10 Coaching Sprint: What to Eat Before, During & After Exercise →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 10 Lab: Pre- and Post-Workout Meal Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 10 Summary & Wrap-Up: Pre-, During-, and Post-Workout Meal Timing →
