## HLTH-150: Mod 10 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Coaching Sprint Simulation: What to Eat Before, During & After Exercise

Sesión de Coaching del Módulo 10: Sincronización de Nutrientes y Ventanas de Alimentación

- Pre-Exercise Carbohydrate Loading Window (1–4 g/kg, 1–4 Hours Prior): Consuming 1–4 g/kg of easily digested, low-fat, moderate-fiber whole-food carbohydrates 1 to 4 hours before training to top off liver and muscle glycogen. En palabras sencillas: Comer de 1 a 4 gramos de carbohidrato por kilo entre 1 y 4 horas antes de entrenar (ej. avena con plátano o arroz con pollo) para llegar con energía sin pesadez.
- Intra-Workout Carbohydrate Target (30–60 g/hr for Sessions >60 Min): For continuous training or field labor lasting >60 minutes, supplying 30–60 g/hr of carbohydrates maintains blood glucose and delays central fatigue. En palabras sencillas: Cuando el entrenamiento dura más de una hora seguida, aportar de 30 a 60 gramos de carbohidrato por hora mantiene estable la glucosa y evita el bajón.
- Post-Exercise Glycogen & MPS Resynthesis Window (1.0–1.2 g/kg/hr Carbs + 20–40 g Protein): Rebuilding depleted glycogen and repairing muscle fibers within 30–120 minutes post-exercise using whole-food meals (DGA 2025–2030). En palabras sencillas: Al terminar de entrenar, combinar carbohidratos reales con 20 a 40 gramos de proteína para recargar el músculo y acelerar la recuperación.
- HLTH-150.10.1.AY26-27: Apply 2025-2030 Dietary Guidelines for Americans ("Real Food" focus) and sports nutrition timing standards to evaluate pre-, intra-, and post-exercise fueling windows. Aplicar las Guías Alimentarias para los Estadounidenses 2025-2030 (enfoque en alimentos reales) y las pautas deportivas para evaluar las ventanas de alimentación pre, intra y post-ejercicio.
- HLTH-150.10.2.AY26-27: Audit metabolic substrate depletion and design evidence-based whole-food nutrient timing protocols across clinical, occupational, and athletic settings. Auditar el agotamiento de sustratos metabólicos y diseñar protocolos de sincronización de alimentos reales en contextos clínicos, ocupacionales y deportivos.

### Your Weekly Win: Mastering Substrate Timing & Anabolic Recovery Windows

Why does nutrient timing matter just as much as daily calorie and macronutrient totals? In Yuma's intense heat and demanding training environments, exercising fasted triggers reactive hypoglycemia, while heavy meals consumed too close to exertion cause debilitating gastrointestinal distress. Following the 2025-2030 Dietary Guidelines for Americans ("Real Food" focus) and sports nutrition standards, exercise professionals schedule carbohydrate and protein intake across three critical windows: pre-exercise priming (1 to 4 hours prior), intra-workout exogenous oxidation (30 to 60 g/hr), and post-exercise glycogen resynthesis (3:1 to 4:1 ratio within 45 minutes). Choose your coaching track below, chat with your AI Socratic Coach, and master nutrient timing auditing!

¿Por qué la sincronización de nutrientes es tan crucial como los totales diarios? En el calor de Yuma, entrenar en ayunas provoca hipoglucemia, mientras que comer pesado justo antes causa malestar gastrointestinal. ¡Elija su ruta, dialogue con su coach de IA y domine la sincronización de sustratos!


### The Clinical Framing Protocol (Pattern / Rule / Solve | Patrón / Regla / Solución)

Pattern / Patrón: Identify client energy intake timing, pre-exercise spacing errors, or post-workout refueling delays.

Rule / Regla: Apply 2025-2030 Dietary Guidelines for Americans ("Real Food" focus), pre-workout spacing (1-4 hours prior, 1-4 g/kg CHO), intra-workout pacing (30-60 g/hr), and post-exercise recovery ratios (3:1 to 4:1 CHO-to-protein).

Solve / Solución: Prescribe structured whole-food nutrient timing schedules and provide bilingual client instruction cue cards.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient cardiac rehabilitation patient with Type 2 diabetes arriving at 8:00 AM fasted; experiences severe lightheadedness and hypoglycemia (68 mg/dL) at minute 25.

Scenario: Agricultural harvest laborer in Yuma County starting 6-hour shifts at 5:00 AM relying solely on black coffee; suffers mid-morning exhaustion, heat cramping, and central fatigue.

Scenario: Collegiate soccer midfielder for AWC Matadors eating a heavy fast-food meal 30 minutes prior to practice; suffers GI cramping, late-match exhaustion at minute 65, and delayed recovery.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Patient J.T., A.M., or K.L.).
- Nutrient Timing & Glycemic Analysis: Explain the key substrate depletion or meal spacing challenge for your selected client under the 2025-2030 Dietary Guidelines for Americans ("Real Food" focus).
- Part 3: Active Verification & Fueling Protocol: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your nutrient timing schedule and whole-food choices protect your client's metabolic stability, prevent reactive hypoglycemia or GI distress, and align with 2025-2030 DGA guidelines.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 10 Coaching Sprint • Track 1 (Patient J.T.)

- Selected Track & Client Name: Track 1: Clinical & Chronic Disease Prevention • Patient J.T. (Age 64).
- Nutrient Timing & Glycemic Analysis: Patient J.T. arrives for morning cardiac rehabilitation in a 12-hour fasted state, precipitating acute glycogen depletion and reactive hypoglycemia (blood glucose plunging to 68 mg/dL) at minute 25. Under the 2025-2030 Dietary Guidelines for Americans ("Real Food" focus), individuals performing therapeutic exertion must establish a pre-exercise fueling window 60 to 90 minutes prior using low-glycemic, unrefined complex carbohydrates and protein to prevent central fatigue and ensure euglycemia.
- Part 3: Active Verification & Fueling Protocol: "Prescribe a pre-exercise meal of 1 cup steel-cut oatmeal with 1 tablespoon ground flaxseed and 1/2 cup fresh berries (approx. 45g complex unrefined carbohydrates, 8g protein) 75 minutes before physical therapy, followed by 1 cup plain Greek yogurt with banana within 45 minutes post-exercise." Active Verification: In my clinical reasoning, J.T.'s acute hypoglycemic crash at minute 25 is directly caused by entering cardiac rehabilitation in a prolonged fasted state while managing Type 2 diabetes. Fasted exercise forces hepatic gluconeogenesis to keep pace with working muscle uptake, which fails under physical exertion and precipitates dangerous blood glucose drops. By scheduling a whole-food complex carbohydrate and protein meal 75 minutes prior, we provide a slow, sustained systemic glucose release without spiking reactive insulin. Ingesting plain Greek yogurt with banana within 45 minutes post-exercise exploits the insulin-independent GLUT4 translocation window to rapidly restore depleted glycogen stores without requiring artificial supplements, adhering fully to the 2025-2030 Dietary Guidelines "Real Food" mandate.
- "Prescribe a pre-exercise meal of 1 cup steel-cut oatmeal with 1 tablespoon ground flaxseed and 1/2 cup fresh berries (approx. 45g complex unrefined carbohydrates, 8g protein) 75 minutes before physical therapy, followed by 1 cup plain Greek yogurt with banana within 45 minutes post-exercise."
- Active Verification: In my clinical reasoning, J.T.'s acute hypoglycemic crash at minute 25 is directly caused by entering cardiac rehabilitation in a prolonged fasted state while managing Type 2 diabetes. Fasted exercise forces hepatic gluconeogenesis to keep pace with working muscle uptake, which fails under physical exertion and precipitates dangerous blood glucose drops. By scheduling a whole-food complex carbohydrate and protein meal 75 minutes prior, we provide a slow, sustained systemic glucose release without spiking reactive insulin. Ingesting plain Greek yogurt with banana within 45 minutes post-exercise exploits the insulin-independent GLUT4 translocation window to rapidly restore depleted glycogen stores without requiring artificial supplements, adhering fully to the 2025-2030 Dietary Guidelines "Real Food" mandate.
- Part 4: My Memorable Coaching Takeaway: EN: "Fueling with real whole foods before training keeps blood sugar steady and recharging immediately afterward guarantees safe muscular recovery!" ES: "¡Alimentarse con comida real antes del ejercicio mantiene la glucosa estable y recargar de inmediato garantiza una recuperación muscular segura!"
- EN: "Fueling with real whole foods before training keeps blood sugar steady and recharging immediately afterward guarantees safe muscular recovery!"
- ES: "¡Alimentarse con comida real antes del ejercicio mantiene la glucosa estable y recargar de inmediato garantiza una recuperación muscular segura!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M10_Quiz_Sprint.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 10 (Mod 10 Coaching Sprint: What to Eat Before, During & After Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 10 Simulación de Coaching: Sincronización de Nutrientes

Evaluación Rápida y Auditoría de Ventanas de Alimentación


### Su Logro Semanal: Dominando la Sincronización de Sustratos y las Ventanas de Recuperación

Esta sesión le permitirá aplicar los principios de sincronización de nutrientes y las normas de las Guías Alimentarias 2025-2030 ("Enfoque en Alimentos Reales") para analizar las reservas de glucógeno y diseñar horarios de alimentación seguros. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Paciente de rehabilitación cardíaca (J.T., 64 años) con Diabetes Tipo 2 que llega a terapia física en ayunas; glucosa cae a 68 mg/dL a los 25 minutos.

Escenario: Jornalera agrícola en Yuma (A.M., 41 años) en turnos matutinos de 6 horas iniciando a las 5:00 AM solo con café negro; sufre fatiga central y calambres.

Escenario: Mediocampista de fútbol soccer universitario (K.L., 20 años) que consume comida pesada 30 minutos antes de entrenar; sufre calambres y fatiga en minuto 65.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de sincronización de nutrientes de su cliente.
- Análisis de Sincronización y Glucemia: Explique el agotamiento de sustratos y las normas de las Guías Alimentarias 2025-2030 ("Enfoque en Alimentos Reales") para su cliente.
- Parte 3: Verificación Activa y Protocolo de Alimentación: En una defensa obligatoria (aprox. mínimo 150 palabras (150+ palabras)) con su propia voz clínica, justifique por qué su horario de alimentación y fuentes de comida real protegen la estabilidad glucémica y previenen la hipoglucemia reactiva o malestar gastrointestinal según las DGA 2025-2030.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: HLTH-150 Módulo 10 Sesión de Coaching • Ruta 1 (Paciente J.T.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Prevención de Enfermedades Crónicas (Paciente J.T., 64 años). Reto: J.T. acude a la rehabilitación cardíaca matutina en un estado de ayuno de 12 horas, lo que precipita un agotamiento agudo de glucógeno y una hipoglucemia sintomática (caída de glucosa a 68 mg/dL) a los 25 minutos de ejercicio.
- Ruta 1: Clínica y Prevención de Enfermedades Crónicas (Paciente J.T., 64 años).
- Reto: J.T. acude a la rehabilitación cardíaca matutina en un estado de ayuno de 12 horas, lo que precipita un agotamiento agudo de glucógeno y una hipoglucemia sintomática (caída de glucosa a 68 mg/dL) a los 25 minutos de ejercicio.
- Análisis de Sincronización y Glucemia: Normas DGA 2025-2030 y Sustratos: Según las Guías Alimentarias 2025-2030 ("Enfoque en Alimentos Reales"), las personas que realizan esfuerzo terapéutico deben establecer una ventana de alimentación previa de 60 a 90 minutos antes, consumiendo 1.0 g/kg de carbohidratos complejos de bajo índice glucémico combinados con proteína moderada para mantener la euglucemia. La resíntesis posterior requiere una proporción de 3:1 de carbohidratos a proteínas dentro de los 45 minutos para frenar el catabolismo.
- Normas DGA 2025-2030 y Sustratos: Según las Guías Alimentarias 2025-2030 ("Enfoque en Alimentos Reales"), las personas que realizan esfuerzo terapéutico deben establecer una ventana de alimentación previa de 60 a 90 minutos antes, consumiendo 1.0 g/kg de carbohidratos complejos de bajo índice glucémico combinados con proteína moderada para mantener la euglucemia.
- La resíntesis posterior requiere una proporción de 3:1 de carbohidratos a proteínas dentro de los 45 minutos para frenar el catabolismo.
- Parte 3: Verificación Activa y Protocolo de Alimentación: "Prescribir 1 taza de avena de grano cortado con 1 cucharada de linaza molida y 1/2 taza de bayas frescas (aprox. 45 g de carbohidratos complejos, 8 g de proteína) 75 minutos antes de la terapia física, seguido de 1 taza de yogur griego natural con plátano dentro de los 45 minutos posteriores al ejercicio." Verificación Activa: En mi juicio clínico, el desplome hipoglucémico de J.T. a los 25 minutos se debe directamente a entrar en esfuerzo en ayunas prolongado mientras maneja Diabetes Tipo 2. El ejercicio en ayunas obliga a la gluconeogénesis hepática a competir con la captación muscular, fallando bajo esfuerzo e induciendo caídas peligrosas de glucosa. Al programar una comida de carbohidratos complejos y proteína 75 minutos antes, aseguramos una liberación sostenida de glucosa sin provocar picos reactivos de insulina. Consumir yogur griego con plátano en menos de 45 minutos post-ejercicio aprovecha la translocación de GLUT4 para recargar glucógeno sin suplementos artificiales, cumpliendo plenamente con el mandato de comida real de las DGA 2025-2030.
- "Prescribir 1 taza de avena de grano cortado con 1 cucharada de linaza molida y 1/2 taza de bayas frescas (aprox. 45 g de carbohidratos complejos, 8 g de proteína) 75 minutos antes de la terapia física, seguido de 1 taza de yogur griego natural con plátano dentro de los 45 minutos posteriores al ejercicio."
- Verificación Activa: En mi juicio clínico, el desplome hipoglucémico de J.T. a los 25 minutos se debe directamente a entrar en esfuerzo en ayunas prolongado mientras maneja Diabetes Tipo 2. El ejercicio en ayunas obliga a la gluconeogénesis hepática a competir con la captación muscular, fallando bajo esfuerzo e induciendo caídas peligrosas de glucosa. Al programar una comida de carbohidratos complejos y proteína 75 minutos antes, aseguramos una liberación sostenida de glucosa sin provocar picos reactivos de insulina. Consumir yogur griego con plátano en menos de 45 minutos post-ejercicio aprovecha la translocación de GLUT4 para recargar glucógeno sin suplementos artificiales, cumpliendo plenamente con el mandato de comida real de las DGA 2025-2030.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Fueling with real whole foods before training keeps blood sugar steady and recharging immediately afterward guarantees safe muscular recovery!" ES: "¡Alimentarse con comida real antes del ejercicio mantiene la glucosa estable y recargar de inmediato garantiza una recuperación muscular segura!"
- EN: "Fueling with real whole foods before training keeps blood sugar steady and recharging immediately afterward guarantees safe muscular recovery!"
- ES: "¡Alimentarse con comida real antes del ejercicio mantiene la glucosa estable y recargar de inmediato garantiza una recuperación muscular segura!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M10_Quiz_Sprint.pdf
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 10)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
