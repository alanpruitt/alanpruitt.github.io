## HLTH-150: Mod 01 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 01) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición Deportiva


## Mod 01 Coaching Sprint Simulation: Building a Balanced Real-Food Plate

Sesión de Coaching del Módulo 01: Balance Energético y el Plato Saludable

- Acceptable Macronutrient Distribution Ranges (AMDR): Evidence-based daily calorie splits: Carbohydrates 45–65%, Protein 10–35%, and Fats 20–35% of total daily energy intake. En palabras sencillas: El reparto saludable de tu energía diaria: 45–65% de carbohidratos naturales, 10–35% de proteína y 20–35% de grasas buenas.
- Resting Metabolic Rate (RMR) vs. Total Daily Energy Expenditure (TDEE): RMR is the energy required to keep vital organs functioning at rest (~60–75% of TDEE); TDEE adds physical activity and digestion. En palabras sencillas: La energía mínima que tu cuerpo necesita solo para vivir y respirar (RMR) frente al gasto total sumando tu trabajo y ejercicio del día (TDEE).
- Caloric Density vs. Nutrient Density: Whole foods deliver high vitamins, minerals, fiber, and protein per calorie, whereas ultra-processed snacks pack empty calories with minimal satiety. En palabras sencillas: Alimentos reales que te llenan y nutren de verdad por cada caloría, a diferencia de la comida chatarra que da calorías vacías.
- HLTH-150.1.1.AY26-27: Analyze dietary patterns and energy balance using current U.S. Dietary Guidelines (DGA) and PAGA standards. Analizar patrones dietéticos y balance energético según las Guías Alimentarias (DGA) y pautas PAGA.
- HLTH-150.1.2.AY26-27: Apply macronutrient distribution ranges (AMDR) to counter commercial nutrition fads and support baseline metabolic health. Aplicar rangos de distribución de macronutrientes (AMDR) para contrarrestar las modas comerciales y apoyar la salud metabólica.

### Your Weekly Win: Evidence-Based Fueling Over Fad Diets

Welcome to your first weekly Coaching Sprint ! This assignment is designed to give you a quick, confidence-building win. Instead of stressing over complex biochemical pathways, you will choose a real-world client scenario below, chat with your AI Socratic Coach, and master the two essential federal rules of sports and daily nutrition: Acceptable Macronutrient Distribution Ranges (AMDR: 45–65% Carbs, 10–35% Protein, 20–35% Fat) and nutrient-dense whole food balance (U.S. Dietary Guidelines) . Walk away with a memorable insight you can use immediately in your life and career!

Esta sesión semanal está diseñada para brindarle un logro claro y motivador. Elegirá su ruta profesional, conversará con su Coach de IA y dominará las reglas básicas de la nutrición basada en evidencia: los rangos de distribución de macronutrientes (AMDR) y el plato balanceado según las Guías Alimentarias federales.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés profesional

Scenario: Office manager (Carlos, 42) with prediabetes who drastically cuts all carbohydrates to near-zero and suffers severe afternoon brain fog and fatigue.


```text
###
[TRACK]: Track 1 - Clinical & Metabolic Health Path
[CLIENT]: Office Administrator (Carlos, 42) | [LOCATION]: Yuma, AZ
[SITUATION]: Cut all carbohydrates (<20g/day) following social media advice for prediabetes. Experiences extreme afternoon lethargy, brain fog, and intense cravings that lead to weekend bingeing.
[COACHING GOAL]: Help Carlos understand carbohydrate quality vs. total restriction, reintroducing complex carbohydrates (AMDR 45-65%) and high dietary fiber (>30g/day) to stabilize blood glucose and energy.
###
```

Scenario: Working mother (Elena, 29) who relies on expensive "cleanse" teas and detox shakes to lose weight because she believes healthy cooking takes hours.


```text
###
[TRACK]: Track 2 - Community & Family Nutrition Path
[CLIENT]: Working Parent & Student (Elena, 29) | [LOCATION]: Yuma County, AZ
[SITUATION]: Spends $120/month on commercial detox juices and meal replacements. Believes fresh whole-food nutrition is unaffordable and too time-consuming for a busy family.
[COACHING GOAL]: Dispel commercial detox myths using U.S. Dietary Guidelines, showing Elena how budget-friendly whole foods (beans, frozen vegetables, brown rice) provide sustainable, long-term vitality.
###
```

Scenario: Community college soccer player (Mateo, 20) who consumes 300g of protein powder daily while ignoring pre-game carbohydrates and proper hydration.


```text
###
[TRACK]: Track 3 - Athletic Performance & Youth Sports Path
[CLIENT]: Collegiate Soccer Midfielder (Mateo, 20) | [LOCATION]: Yuma, AZ
[SITUATION]: Drinks 4 massive protein shakes a day (>3.5g protein/kg) but eats almost zero carbohydrates before matches, leading to heavy legs and severe cramping by the 60th minute.
[COACHING GOAL]: Rebalance Mateo's macronutrient profile using sports nutrition standards (carbohydrates as the primary glycolytic fuel for soccer performance + adequate hydration).
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: HLTH-150 Energy Balance Tool Box ###:
Role: Supportive HLTH-150 Sports Nutrition Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Dietary Guidelines for Americans (DGA / USDA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in clear, simple terms why extreme fad diets or unbalanced macronutrient ratios cause metabolic fatigue and how federal standards (U.S. Dietary Guidelines & AMDR: 45-65% carbs, 10-35% protein, 20-35% fat) solve the client's specific challenge.
Step 3: Guide the student to create an easy daily fueling plan that incorporates affordable, nutrient-dense whole foods to fit the client's lifestyle.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how balanced whole-food nutrition drives daily energy.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and the client's nutritional challenge.
- Federal Nutrition Rules (SSoT): State the Acceptable Macronutrient Distribution Ranges (AMDR) and the core principle of the U.S. Dietary Guidelines.
- My Easy Daily Fueling Plan: Describe a realistic, whole-food dietary adjustment that restores energy balance without extreme restrictions.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why building a balanced whole-food plate within USDA AMDR ranges (45–65% CHO, 10–35% PRO, 20–35% FAT) protects your client from the metabolic crashes of fad diets.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 01 Coaching Sprint • Track 1 (Clinical / Carlos)

- Chosen Track & Client: Track 1: Clinical & Metabolic Health (Carlos, 42, office administrator). Problem: Carlos completely eliminated carbohydrates to manage prediabetes, causing severe afternoon fatigue and rebound bingeing. He does not realize that nutrient-dense complex carbohydrates with fiber stabilize blood sugar without extreme restriction.
- Track 1: Clinical & Metabolic Health (Carlos, 42, office administrator).
- Problem: Carlos completely eliminated carbohydrates to manage prediabetes, causing severe afternoon fatigue and rebound bingeing. He does not realize that nutrient-dense complex carbohydrates with fiber stabilize blood sugar without extreme restriction.
- Federal Nutrition Rules (SSoT): AMDR Standards: 45–65% of daily calories from carbohydrates, 10–35% from protein, and 20–35% from healthy fats. Dietary Guidelines Principle: Focus on dietary patterns rich in whole grains, legumes, vegetables, and lean proteins rather than eliminating entire macronutrient groups.
- AMDR Standards: 45–65% of daily calories from carbohydrates, 10–35% from protein, and 20–35% from healthy fats.
- Dietary Guidelines Principle: Focus on dietary patterns rich in whole grains, legumes, vegetables, and lean proteins rather than eliminating entire macronutrient groups.
- My Easy Daily Fueling Plan for Carlos: Breakfast & Lunch: Introduce steel-cut oats with chia seeds for breakfast, and swap white bread for black beans and quinoa with grilled chicken at lunch (complex carbs + high fiber). Afternoon Snack: Apple slices with almond butter to maintain steady glucose and eliminate the 3:00 PM energy crash.
- Breakfast & Lunch: Introduce steel-cut oats with chia seeds for breakfast, and swap white bread for black beans and quinoa with grilled chicken at lunch (complex carbs + high fiber).
- Afternoon Snack: Apple slices with almond butter to maintain steady glucose and eliminate the 3:00 PM energy crash.
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Carlos's 3:00 PM energy crash and evening rebound bingeing are the direct physiological consequence of an extreme zero-carb fad diet rather than a lack of willpower. When a generic internet diet strips away all carbohydrates, liver and muscle glycogen plummet, triggering cortisol release and intense cravings for refined sugar. By anchoring Carlos's nutrition in the 2025–2030 Dietary Guidelines for Americans and USDA AMDR benchmarks (45–65% complex carbohydrates, 10–35% lean protein, and 20–35% healthy fats), we reintroduce high-fiber whole foods like steel-cut oats, black beans, and quinoa. This slows gastric emptying, stabilizes postprandial blood glucose, and sustains his daily energy in Yuma without restrictive deprivation."
- My Memorable Coaching Takeaway: EN: "Food is fuel, not the enemy—balancing whole carbohydrates and protein creates steady daily energy without extreme diets!" ES: "¡La comida es combustible, no el enemigo: equilibrar carbohidratos integrales y proteínas genera energía constante sin dietas extremas!"
- EN: "Food is fuel, not the enemy—balancing whole carbohydrates and protein creates steady daily energy without extreme diets!"
- ES: "¡La comida es combustible, no el enemigo: equilibrar carbohidratos integrales y proteínas genera energía constante sin dietas extremas!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M01_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Coaching Sprint: Building a Balanced Real-Food Plate)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición Deportiva


## Módulo 01 Simulación de Coaching: Balance Energético y Nutrición

Evaluación Rápida y Aprendizaje Práctico de las Pautas Federales de Nutrición


### Su Logro Semanal: Nutrición con Evidencia Científica

¡Bienvenido a su primera sesión de coaching! Esta actividad está diseñada para darle un logro claro y sin estrés. Elegirá un caso práctico, conversará con su Coach de IA y dominará las dos pautas básicas de nutrición: los rangos de distribución de macronutrientes (AMDR: 45–65% carbohidratos, 10–35% proteína, 20–35% grasas) y el plato balanceado con alimentos integrales .


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: HLTH-150 Balance Energetico ###:
Rol: Coach de Nutricion Deportiva de HLTH-150 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Guias Alimentarias para los Estadounidenses (DGA / USDA) y Pautas PAGA 2018 (2.a edicion).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla por que las dietas de moda extremas o los desequilibrios de macronutrientes causan fatiga metabolica y como las pautas federales (Guias Alimentarias de EE. UU. y rangos AMDR: 45-65% carbohidratos, 10-35% proteina, 20-35% grasas) ayudan al cliente.
Step 3: Guiar al estudiante para elaborar un plan diario facil con alimentos integrales y accesibles que se ajuste a su vida diaria.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como equilibrar carbohidratos integrales y proteinas genera energia constante.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío nutricional de su cliente.
- Pautas Federales de Nutrición (SSoT): Cite los rangos AMDR exactos (45–65% carbohidratos, 10–35% proteína, 20–35% grasas) y el principio de las Guías Alimentarias.
- Mi Plan Diario Práctico: Describa un ajuste dietético realista con alimentos integrales para restaurar el balance energético sin restricciones extremas.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué armar un plato de alimentos reales dentro de los rangos AMDR (45–65% CHO, 10–35% PRO, 20–35% FAT) protege a su cliente de los bajones metabólicos de las dietas de moda.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, el agotamiento de Carlos a las 3:00 PM y sus atracones nocturnos son consecuencia directa de una dieta extrema sin carbohidratos y no falta de voluntad. Al eliminar todos los carbohidratos, sus reservas de glucógeno caen y provocan fatiga severa. Al aplicar las Guías Alimentarias 2025–2030 y los rangos AMDR (45–65% carbohidratos complejos, 10–35% proteína y 20–35% grasas saludables) con avena, frijoles negros y pollo, estabilizamos su glucosa en sangre y mantenemos su energía constante durante todo el día."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 01)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
