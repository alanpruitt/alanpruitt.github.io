## HLTH-150 (Module 01 Overview): Nutrition for Exercise & Sport: Performance Nutrition & Dietary Guidelines

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 01 Overview: Daily Calorie & Macronutrient Balance


### Welcome to Module 01: Daily Calorie & Macronutrient Balance

Welcome to HLTH-150! This week, we establish foundational metabolic math using our primary Single Sources of Truth (SSoTs): the Dietary Guidelines for Americans (DGA / USDA) and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) . Rather than following commercial wellness fads or marketing hype, you will learn to calculate Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) with mathematical precision.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify energy deficit and surplus patterns, apply federal Acceptable Macronutrient Distribution Ranges (AMDR) and protein standards (1.2–2.0 g/kg for active bodies), and design practical, heat-adapted whole-food meal strategies for active individuals and agricultural workers in Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, August 18, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, August 20, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, August 23, 2026, at 11:59 PM MST
- Lab 01 Direct Submission / Entrega de Laboratorio: Monday, August 24, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 01 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Calculate Basal Metabolic Rate (BMR) using the Mifflin-St Jeor equation and establish Total Daily Energy Expenditure (TDEE) across diverse physical activity tiers. Calcular la Tasa Metabólica Basal (BMR) mediante la fórmula de Mifflin-St Jeor y determinar el Gasto Energético Diario Total (TDEE).
- CLO 2 (Rule Application): Apply federal DGA AMDR percentages (45–65% Carbohydrates, 10–35% Protein, 20–35% Fats) and physical activity protein targets (1.2–2.0 g/kg) to balance metabolic energy intake. Aplicar los rangos AMDR federales y las metas de proteína en personas activas para equilibrar la ingesta energética.
- CLO 3 (Problem Solving): Formulate an evidence-based, climate-adapted whole-food nutrition and hydration protocol for active populations and agricultural workers operating in Yuma County's extreme summer heat. Diseñar un protocolo nutricional y de hidratación basado en alimentos reales y adaptado al calor extremo del condado de Yuma.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit energy balance and macronutrients through your chosen professional track:

Auditing energy availability, lean mass preservation, and metabolic deceleration in sedentary post-rehabilitation patients in outpatient clinical settings.

Prescribing accessible, cost-effective whole-food macronutrient distributions and electrolyte hydration for field workers and families in Yuma County.

Calculating high-volume glycogen replenishment (5–8 g/kg CHO) and tissue remodeling protein targets (1.6–2.2 g/kg) for collegiate and tactical athletes.


### Module 01 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Energy Balance, AMDR Ranges & DGA Federal Standards
- Discussion Board 01: Peer Self-Introduction & Community Connection
- Lab Assignment 01: Energy Balance, Macronutrient Audit & Gemini AI Tool Box
- Module 01 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Overview: Daily Calorie & Macronutrient Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 01 Visión General: Balance Energético y Macronutrientes


### Bienvenido al Módulo 01: Balance Energético, Matemáticas Metabólicas y Alimentos Reales

¡Bienvenido a HLTH-150! Esta semana estableceremos los cálculos metabólicos fundamentales utilizando nuestras Fuentes Únicas de Verdad (SSoT): las Guías Alimentarias para los Estadounidenses (DGA / USDA) y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) . En lugar de seguir modas comerciales o suplementos costosos, aprenderá a calcular la Tasa Metabólica Basal (BMR) y el Gasto Energético Total (TDEE) con precisión científica.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará patrones de balance calórico, aplicará los rangos AMDR federales y las metas de proteína (1.2 a 2.0 g/kg), y diseñará estrategias de alimentación e hidratación adaptadas al calor extremo del condado de Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 18 de agosto de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 20 de agosto de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 23 de agosto de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 01: Lunes, 24 de agosto de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Calcular el BMR mediante la ecuación de Mifflin-St Jeor y establecer el TDEE en diferentes niveles de actividad física.
- CLO 2 (Regla): Aplicar los porcentajes AMDR federales (45–65% carbohidratos, 10–35% proteína, 20–35% grasas) y metas de proteína (1.2–2.0 g/kg).
- CLO 3 (Solución): Formular un protocolo nutricional con alimentos reales y de hidratación adaptado al clima de alto calor del condado de Yuma.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará el balance energético a través de su ruta profesional:

Auditoría de balance calórico y preservación de masa magra en pacientes sedentarios en rehabilitación.

Prescripción de alimentos integrales económicos e hidratación para trabajadores agrícolas de Yuma.

Cálculo de reposición de glucógeno y metas proteicas para atletas universitarios y tácticos.


### Ruta de Aprendizaje del Módulo 01

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Balance Energético, Rangos AMDR y Pautas DGA
- Foro de Discusión 01: Presentación Personal y Conexión Comunitaria
- Laboratorio 01: Balance Energético, Auditoría de Macronutrientes y Gemini IA
- Comprobación de Conocimientos y Resumen del Módulo 01

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 01 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 01 Required Readings: Daily Calorie & Macronutrient Balance →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 01 Discussion: Meet Your Classmates & Real-Food Goals →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 01 Coaching Sprint: Building a Balanced Real-Food Plate →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 01 Lab: Daily Calorie & Macronutrient Balance Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 01 Summary & Wrap-Up: Daily Calorie & Macronutrient Balance →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 01)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
