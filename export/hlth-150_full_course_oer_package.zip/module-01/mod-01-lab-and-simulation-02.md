## HLTH-150: Mod 01 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 01) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 01 Lab & Simulation: Daily Calorie & Macronutrient Balance Audit

Laboratorio del Módulo 01: Balance Energético y la Ecuación de Macronutrientes

- Acceptable Macronutrient Distribution Ranges (AMDR): Evidence-based daily calorie splits: Carbohydrates 45–65%, Protein 10–35%, and Fats 20–35% of total daily energy intake. En palabras sencillas: El reparto saludable de tu energía diaria: 45–65% de carbohidratos naturales, 10–35% de proteína y 20–35% de grasas buenas.
- Resting Metabolic Rate (RMR) vs. Total Daily Energy Expenditure (TDEE): RMR is the energy required to keep vital organs functioning at rest (~60–75% of TDEE); TDEE adds physical activity and digestion. En palabras sencillas: La energía mínima que tu cuerpo necesita solo para vivir y respirar (RMR) frente al gasto total sumando tu trabajo y ejercicio del día (TDEE).
- Caloric Density vs. Nutrient Density: Whole foods deliver high vitamins, minerals, fiber, and protein per calorie, whereas ultra-processed snacks pack empty calories with minimal satiety. En palabras sencillas: Alimentos reales que te llenan y nutren de verdad por cada caloría, a diferencia de la comida chatarra que da calorías vacías.
Welcome to your first practical laboratory assignment in Sports Nutrition. This week, we bypass commercial marketing claims and calculate raw metabolic math using our core academic Single Sources of Truth (SSoTs): the Dietary Guidelines for Americans (DGA / USDA) and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) .

Bienvenido a su primera práctica de laboratorio de nutrición deportiva. Esta semana dejaremos de lado el marketing comercial y calcularemos matemáticas metabólicas exactas utilizando nuestras Fuentes Únicas de Verdad (SSoTs): las Pautas Dietéticas para los Estadounidenses (DGA / USDA) y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) .

- HLTH-150.1.1.AY26-27: Evaluate baseline dietary patterns against current U.S. Dietary Guidelines for Americans (DGA) and PAGA standards. Evaluar los patrones dietéticos iniciales según las Pautas Dietéticas para los Estadounidenses (DGA) y normas PAGA.
- HLTH-150.1.2.AY26-27: Apply the Clinical Framing Protocol (Pattern / Rule / Solve) framework to identify nutrient density deficits in client food logs. Aplicar el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para identificar déficits de densidad de nutrientes en registros de alimentos.
- Module Window / Ventana del Módulo: Opens Tuesday, August 18, 2026, at 12:00 AM MST Abre el martes, 18 de agosto de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, August 24, 2026, at 11:59 PM MST Lunes, 24 de agosto de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación: Weekly Labs & Clinical Simulations Benchmark (10 Points) Ponderación para laboratorios semanales y simulaciones clínicas (10 Puntos)

### Lab Objectives / Objetivos del Laboratorio

Competencias clave del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Deconstruct individual client activity profiles to calculate baseline Total Daily Energy Expenditure (TDEE). Desglosar los perfiles de actividad individual para calcular el Gasto Energético Diario Total (TDEE).
- Apply federal Acceptable Macronutrient Distribution Ranges (AMDR) and protein thresholds for active individuals. Aplicar los rangos AMDR federales y las metas de proteína para personas activas.
- Formulate targeted caloric prescriptions and macronutrient distributions optimized for desert environmental demands. Formular metas calóricas y de macronutrientes optimizadas para las demandas del clima desértico.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-01 / Fase 1: Selección de Escenario de Simulación Clínica

Elija su Ruta y Revise los Datos del Caso

Choose ONE of the three career-aligned tracks below to audit in the Gemini AI Tool Box:

Focus: Sedentary healthcare administrator with prediabetes seeking energy balance management and metabolic risk reduction.


```text
###
[TRACK / RUTA]: Track 1 - Clinical & Chronic Disease Prevention Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: M.E.
[AGE / EDAD]: 45 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma, AZ
[HEIGHT / ESTATURA]: 5 ft 4 in (162.5 cm) | [WEIGHT / PESO]: 182 lbs (82.5 kg)
[OCCUPATION / OCUPACIÓN]: Hospital Desk Administrator (Sedentary, 9+ hours sitting per day)
[DAILY ACTIVITY MATRIX / MATRIZ DE ACTIVIDAD DIARIA]:
Key Point: Occupational: Under 3,000 steps/day
Key Point: Structured Exercise: 0 days/week
[CLINICAL PROFILE & GOAL]: HbA1c 5.9% (Prediabetes), elevated fasting blood lipids. Goal: Moderate energy deficit (-300 to -500 kcal) for weight loss while balancing blood glucose using USDA AMDR guidelines.
###
```

Focus: Agricultural field inspector with extreme heat energy expenditure seeking lean mass accretion and heat crash prevention.


```text
###
[TRACK / RUTA]: Track 2 - Community & Public Health Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: T.B.
[AGE / EDAD]: 28 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 5 ft 10 in (178 cm) | [WEIGHT / PESO]: 175 lbs (79.5 kg)
[OCCUPATION / OCUPACIÓN]: Field Crop Inspector (Inspección de Cultivos Agrícolas)
[DAILY ACTIVITY MATRIX / MATRIZ DE ACTIVIDAD DIARIA]:
Key Point: Occupational: Walks 12,000+ steps per day in field conditions (Average heat index: 102°F–112°F)
Key Point: Structured Exercise: 0 days/week (plans light resistance training once energy demands are resolved)
[PRIMARY PERFORMANCE GOAL]: Accrete lean muscle mass (+0.5 to 1.0 lb/week) and avoid chronic midday energy crashes in desert heat.
###
```

Focus: Collegiate endurance cross-country runner seeking metabolic energy fueling and muscle protein synthesis recovery.


```text
###
[TRACK / RUTA]: Track 3 - Sports & Athletic Performance Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: A.R.
[AGE / EDAD]: 20 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma, AZ (AWC Athletics)
[HEIGHT / ESTATURA]: 5 ft 11 in (180 cm) | [WEIGHT / PESO]: 152 lbs (69 kg)
[SPORT & ATHLETIC STATUS]: Collegiate Cross-Country Runner (Corredor Universitario)
[DAILY ACTIVITY MATRIX / MATRIZ DE ACTIVIDAD DIARIA]:
Key Point: Training Volume: Runs 45+ miles/week + 2 resistance training sessions
[PRIMARY PERFORMANCE GOAL]: Maximize muscle glycogen replenishment, optimize protein intake (1.6 to 2.0 g/kg per sports nutrition guidelines), and support heavy athletic expenditure without muscle catabolism.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


```text
Safety Auditor Protocol: HLTH-150 Module 01 Energy Balance Tool Box ###:
Role: Socratic Sports Nutrition Mentor in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA / USDA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Review the student's selected career track case data enclosed within triple-hashes (###) below.
Step 2: PATTERN: Calculate estimated Basal Metabolic Rate (BMR) using the Mifflin-St Jeor formula and derive Total Daily Energy Expenditure (TDEE) with an appropriate physical activity multiplier.
Step 3: RULE: Cross-reference energy requirements against the federal USDA AMDR percentage ranges (CHO 45–65%, PRO 10–35%, FAT 20–35%) and verify protein targets in g/kg.
Step 4: SOLVE: Design a targeted daily caloric prescription (specifying surplus, deficit, or maintenance) with exact grams of Carbohydrates, Protein, and Fats, adapted to Yuma's desert climate.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Template

Plantilla de Entrega en el Cuadro de Texto de Canvas

Copy the template below, populate your responses, and submit directly in Canvas:


```text
HLTH-150 Module 01 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]
Client Initials: [Insert Client Initials]

Step 1: Pattern Recognition (BMR & TDEE Metabolic Math):
Key Point: Biometric Values: Mass: ___ kg | Height: ___ cm | Age: ___ years
Key Point: BMR Calculation (Mifflin-St Jeor): [Show formula and result in kcal/day]
Key Point: Physical Activity Level (PAL) Multiplier: [State PAL factor used]
Key Point: TDEE Calculation: [BMR * PAL = ___ kcal/day]

Step 2: Rule Application (Federal AMDR & Protein Standards):
Key Point: Caloric Adjustment (Deficit, Surplus, or Maintenance Target): ___ kcal/day
Key Point: USDA AMDR Target Percentages: CHO: ___% | PRO: ___% | FAT: ___%
Key Point: Daily Protein Ingestion Standard: ___ g/kg/day

Step 3: Problem Solving (Macronutrient Gram Prescription & Client Card):
Key Point: Total Daily Protein: ___ grams/day (___ kcal)
Key Point: Total Daily Fats: ___ grams/day (___ kcal)
Key Point: Total Daily Carbohydrates: ___ grams/day (___ kcal)
Key Point: Desert Hydration & Field Fueling Strategy: [Describe whole-food and fluid plan]
Key Point: Bilingual Client Instruction Card (EN / ES):

Step 4: Part 3 — Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice):
Key Point: [In 150-word minimum (150+ words) written in your own clinical voice, justify why your Mifflin-St Jeor TDEE, USDA AMDR split, and Yuma desert hydration strategy protect this client from energy-availability deficits or heat dehydration]

Step 5: Repository Verification:
AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M01_Energy_Balance_Audit.pdf
End Submission ###:
```


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Part 1: Pattern Recognition (BMR & TDEE Calculation): Key Point — Biometric Conversions: Weight = $175\text{ lbs} / 2.2 = 79.5\text{ kg}$. Height = $70\text{ in} \times 2.54 = 177.8\text{ cm}$. Age = 28 years. Key Point — BMR (Mifflin-St Jeor for Men): $$\text{BMR} = 10(79.5) + 6.25(177.8) - 5(28) + 5 = 795 + 1111.25 - 140 + 5 = \mathbf{1771.25\text{ kcal/day}}$$ Key Point — TDEE Calculation: Accounting for T.B.'s extreme occupational workload (12,000+ steps daily in desert field conditions), we apply a "heavy activity" multiplier of 1.725: $$\text{TDEE} = 1771.25\text{ kcal} \times 1.725 = \mathbf{3055\text{ kcal/day}}$$ Key Point — Inactivity / Energy Deficit Pattern: T.B. operates in chronic energy deficit relative to his agricultural labor demands, explaining his midday fatigue.

Part 2: Rule Application (USDA AMDR & Protein Standards): Key Point — Caloric Target: To promote muscle accretion (+0.5 to 1.0 lb/week) and prevent heat fatigue, we establish a +500 kcal surplus, setting daily intake to 3555 kcal/day . Key Point — USDA AMDR Ranges: Carbohydrates 45%–65%, Fats 20%–35%, Protein 10%–35%. Key Point — Protein Standard: Active individuals performing heavy physical labor requiring tissue recovery require 1.8 g/kg protein daily.

Part 3: Solving the Gap (Prescription & Field Strategy): Key Point — Protein (1.8 g/kg): $79.5\text{ kg} \times 1.8\text{ g} = \mathbf{143\text{ g protein daily}}$ ($572\text{ kcal}$, 16.1% of total energy). Key Point — Fats (25% target): $3555\text{ kcal} \times 0.25 = 889\text{ kcal} = \mathbf{99\text{ g fats daily}}$. Key Point — Carbohydrates (Remaining Balance): $3555 - (572 + 889) = 2094\text{ kcal} = \mathbf{524\text{ g carbohydrates daily}}$ (58.9% of total energy, fueling daily step demands). Key Point — Field Strategy: Consume 16 to 24 oz of water with electrolyte replacement every hour of fieldwork in Yuma heat. Carry heat-stable whole-food snacks (mixed nuts, dried fruit, beef jerky, bean burritos).

EN: "To gain lean muscle and maintain energy during long field shifts, consume 3555 calories daily with 143 grams of protein and abundant complex carbs. Carry portable, heat-stable snacks like nuts and dried fruit to avoid midday fatigue."

ES: "Para aumentar masa muscular y mantener energía en el campo, consuma 3555 calorías diarias con 143 gramos de proteína y carbohidratos complejos. Lleve refrigerios resistentes al calor como nueces y fruta deshidratada para evitar la fatiga."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_150_M01_Energy_Balance_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Lab: Daily Calorie & Macronutrient Balance Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 01 Laboratorio y Simulación: Balance Energético y la Ecuación de Macronutrientes

Cálculo de Gasto Energético Diario y Distribución de Macronutrientes

En este laboratorio práctico, auditará el perfil energético de un cliente utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , calculando el metabolismo basal con la fórmula Mifflin-St Jeor, aplicando los rangos AMDR del USDA y estableciendo la ingesta de proteínas según las normas federales DGA / PAGA 2018.

- Apertura del Módulo: Martes, 18 de agosto de 2026, a las 12:00 AM MST
- Fecha Límite de Entrega: Lunes, 24 de agosto de 2026, a las 11:59 PM MST
- Ponderación: Puntuación de laboratorios semanales y auditorías clínicas (10 Puntos)

### Paso 1: Consulta en la Caja de Herramientas de IA Gemini

Pegue los datos de la ruta elegida en Gemini IA y copie esta plantilla debajo:


```text
Protocolo Safety Auditor: HLTH-150 Laboratorio 01 ###:
Rol: Mentor Socratico de Nutricion Deportiva con la voz del Narrador.
SSoT: Guias Alimentarias para los Estadounidenses (DGA / USDA) y Pautas PAGA 2018 (2.a edicion).

Instrucciones:
Step 1: Revisar los datos del caso de la ruta seleccionada por el estudiante entre delimitadores (###).
Step 2: PATRON: Calcular la Tasa Metabolica Basal (BMR) con Mifflin-St Jeor y derivar el Gasto Energetico Diario Total (TDEE) con el multiplicador de actividad fisica (PAL).
Step 3: REGLA: Comparar las necesidades caloricas con los rangos AMDR (Carbohidratos 45-65%, Proteina 10-35%, Grasas 20-35%) y verificar las metas de proteina en g/kg.
Step 4: SOLUCION: Formular una prescripcion calorica diaria con gramos exactos de Carbohidratos, Proteina y Grasas, adaptada al calor de Yuma.
Step 5: Generar una tarjeta de instruccion bilingue para el cliente (EN / ES).

Entrada de Datos del Cliente ###:
[PEGUE AQUI LOS DATOS DE SU RUTA ENTRE DELIMITADORES]
Fin de Datos del Cliente ###:
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Plantilla de Entrega en Canvas (Solo Texto)


```text
HLTH-150 Entrega de Laboratorio Modulo 01 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clinica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]
Iniciales del Cliente: [Insertar Iniciales]

Step 1: Reconocimiento de Patrones (Matematicas de BMR y TDEE):
Key Point: Datos Biometricos: Masa: ___ kg | Estatura: ___ cm | Edad: ___ anos
Key Point: Calculo de BMR (Mifflin-St Jeor): [Mostrar formula y resultado en kcal/dia]
Key Point: Factor de Actividad Fisica (PAL): [Indicar factor utilizado]
Key Point: Calculo de TDEE: [BMR * PAL = ___ kcal/dia]

Step 2: Aplicacion de Reglas (Rangos AMDR y Metas de Proteina):
Key Point: Ajuste Calorico (Meta de Deficit, Superavit o Mantenimiento): ___ kcal/dia
Key Point: Porcentajes AMDR del USDA: Carbohidratos: ___% | Proteina: ___% | Grasas: ___%
Key Point: Estandar de Proteina Diario: ___ g/kg/dia

Step 3: Resolucion de Problemas (Prescripcion de Gramos y Tarjeta Bilingue):
Key Point: Proteina Diaria Total: ___ gramos/dia (___ kcal)
Key Point: Grasas Diarias Totales: ___ gramos/dia (___ kcal)
Key Point: Carbohidratos Diarios Totales: ___ gramos/dia (___ kcal)
Key Point: Estrategia de Hidratacion y Alimentos para el Calor: [Describir plan]
Key Point: Tarjeta de Instruccion Bilingue para el Cliente (EN / ES):

Step 4: Verificación Activa Clinica Obligatoria (Mínimo 150 Palabras en su Propia Voz Humana):
Key Point: [En mínimo 150 palabras (150+ palabras) escritas en su propia voz clinica, justifique por que su calculo de TDEE, distribucion AMDR y estrategia de hidratacion en el calor de Yuma protegen al cliente]

Step 5: Verificacion del Repositorio:
Intercambio con la IA exportado y guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M01_Energy_Balance_Audit.pdf
Fin de la Entrega ###:
```

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi criterio clínico como arquitecto nutricional, aplicar una dieta genérica de 1,500 kcal de internet a un cliente activo en Yuma provocaría un déficit energético peligroso, pérdida de masa muscular y agotamiento por calor. Al calcular con precisión la Tasa Metabólica Basal mediante Mifflin-St Jeor y el TDEE según su nivel de actividad física, aseguramos la disponibilidad energética real. Anclar los gramos diarios en los rangos AMDR del USDA con alimentos reales (frijoles, arroz integral, carnes magras) e hidratación con electrolitos protege el glucógeno y previene la deshidratación en el desierto."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 01)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
