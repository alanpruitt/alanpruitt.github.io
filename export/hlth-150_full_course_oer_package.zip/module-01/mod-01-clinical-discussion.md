## HLTH-150: Mod 01 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Foundations of Nutrition for Sport & Exercise / Fundamentos de Nutrición para el Deporte y el Ejercicio


## Mod 01 Discussion: Meet Your Classmates & Real-Food Goals

Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Alimentos Reales


### In Plain English: Discussion Guide

Before you read the details below, here is the short version: This discussion is how we meet each other and connect everyday eating habits to the 2025–2030 Dietary Guidelines for Americans. You will introduce yourself, choose your career track, and share one practical whole-food nutrition goal for active living in Yuma County.


#### En Palabras Sencillas (Contexto Norteño)

Es como sentarse a la mesa con compañeros nuevos: platicamos de dónde somos, qué carrera estudiamos y cómo armar un plato con comida real y buena hidratación para aguantar el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en presentarte y compartir un cambio sencillo de comida real.


### Discussion Schedule & Deadlines / Horario y Fechas Límite

- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST (150-word minimum (150+ words))
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST (Reply to TWO (2) classmates for our Week 1 Self-Introduction)
- Bilingual Participation Welcome / Participación Bilingüe: You are warmly encouraged to write in English, Spanish, or both!

### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Nursing, Dietetics, Physical Therapy, or Outpatient Wellness Counseling.

Community Nutrition, School Health, or Agricultural Workforce Wellness in Yuma County.

Athletic Coaching, Strength & Conditioning, or Tactical/First-Responder Fueling.


### Initial Post Requirements (Due Thursday @ 11:59 PM MST • 100–150 Words)

- Community Introduction: Share your name (and preferred name), where you are from, your favorite way to move or fuel your body, and your career goal after AWC.
- Step 1: Pattern Recognition (Context): Identify one common real-world barrier to healthy movement, nutrition, or safe exercise you see in Yuma County / Imperial Valley (such as summer heat, long shifts, or fear of injury).
- Step 2: Rule Application (SSoT Benchmark): Cite one foundational rule from our course Source of Truth (2025–2030 Dietary Guidelines for Americans (DGA, Real-Food Focus) & USDA AMDR Standards) that addresses this barrier.
- Step 3: Solve & Personal Action Step: Propose one realistic weekly habit or coaching strategy you want to master this semester, plus a 1-sentence bilingual takeaway (EN / ES).
- Peer Engagement (Due Sunday @ 11:59 PM MST): Reply to at least TWO (2) classmates , welcoming them to the class and connecting with their career track or weekly goal.

### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track: Track 2 (Community & Public Health Path)

Hello classmates! My name is Valeria, and I am from San Luis, AZ. I love morning runs along the levee and cooking traditional meals with my grandmother on weekends. I am taking HLTH-150 as part of my Community Health degree so I can teach practical, budget-friendly nutrition to families and field workers here in Yuma County.

Pattern / Rule / Solve Application: A common nutritional challenge I see in our community ( Pattern ) is relying on high-sugar energy drinks and fast food during busy workdays, which causes mid-afternoon energy crashes. Under the 2025–2030 Dietary Guidelines for Americans (DGA) and USDA AMDR standards ( Rule ), daily calories should come from nutrient-dense whole foods balanced at 45–65% complex carbohydrates, 10–35% protein, and 20–35% healthy fats, while keeping added sugars under 10%. My practical intervention ( Solve ) is packing a real-food lunch box with pinto beans, grilled chicken, corn tortillas, avocado, and chilled water with lime and a pinch of salt to sustain energy and hydration in Yuma's heat.

Bilingual Takeaway (EN / ES): EN: "Balancing traditional whole foods like beans, corn tortillas, and lean protein within USDA AMDR ranges delivers steady all-day energy without added-sugar crashes!" ES: "¡Equilibrar alimentos reales tradicionales como frijoles, tortillas de maíz y proteína magra dentro de los rangos AMDR brinda energía constante todo el día sin bajones de azúcar!"


### Evaluation Rubric (10 Points Total • 10/7/0 Mastery Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Discussion: Meet Your Classmates & Real-Food Goals)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Fundamentos de Nutrición para el Deporte y el Ejercicio


## Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Alimentos Reales


### Requisitos de la Publicación Inicial (Jueves 11:59 PM MST • 100–150 Palabras) y 2 Respuestas (Domingo 11:59 PM MST)

- Presentación Personal: Comparta su nombre (y cómo prefiere que le llamen), de dónde es, cómo le gusta mantenerse activo y su meta profesional después de AWC.
- Step 1: Patrón (Contexto Regional): Identifique una barrera común en el condado de Yuma / Valle Imperial (como el calor extremo o turnos largos de trabajo).
- Step 2: Regla (Fuente de Verdad SSoT): Cite una regla fundamental de nuestra Fuente de Verdad (Guías Alimentarias para los Estadounidenses 2025–2030 (DGA, Enfoque en Alimentos Reales) y Rangos AMDR).
- Step 3: Solución y Meta Semanal: Proponga un hábito práctico para este semestre y una frase de aprendizaje bilingüe (EN / ES).
- Interacción con Compañeros: Responda al menos a DOS (2) compañeros antes del domingo a las 11:59 PM MST. ¡Puede escribir en inglés, español o ambos!
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 01)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
