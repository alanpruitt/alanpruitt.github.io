# HLTH-150: Mod 14 Lab And Simulation 03

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 14 Lab & Simulation: Lifespan Meal Plan & Older Adult Protein Audit

- Anabolic Resistance in Older Adults (1.2–1.6 g/kg/day & 25–35 g/Meal): Aging muscle requires a higher per-meal protein and leucine dose (25–35 g high-quality protein per meal) paired with resistance exercise to prevent sarcopenia. En palabras sencillas: Con los años el músculo aprovecha menos la proteína, por lo que un adulto mayor necesita de 25 a 35 gramos de proteína real por comida más ejercicios de fuerza.
- Maternal Trimester Energy & Micronutrient Increments (DGA 2025–2030): Pregnancy requires +0 kcal (1st trimester), +340 kcal/day (2nd trimester), and +452 kcal/day (3rd trimester) alongside critical folate, iron, iodine, and choline from real foods. En palabras sencillas: Durante el embarazo se suman +340 calorías en el segundo trimestre y +452 en el tercero con alimentos ricos en ácido fólico, hierro y colina.
- Youth Peak Bone Mass Accrual (Calcium, Vitamin D & Unrestrictive Fueling): Adolescence is the critical window for building lifetime bone mineral density; restrictive dieting during youth stunts growth and increases fracture risk. En palabras sencillas: En niños y adolescentes nunca se aplican dietas restrictivas; necesitan calcio, vitamina D y energía suficiente para crecer y formar huesos fuertes.

### In Plain English

Before you read the details below, here is the short version: Nutritional needs change across youth growth, pregnancy, and older adulthood. In this lab, you calculate daily protein and hydration targets for an older adult or lifespan client in Yuma County using the 2025–2030 Dietary Guidelines for Americans to prevent muscle loss (sarcopenia).


#### En Palabras Sencillas (Contexto Norteño)

Con los años el cuerpo necesita mejor mantenimiento: los adultos mayores ocupan suficiente proteína de comida real en cada comida para no perder fuerza ni músculo. Si los términos técnicos se ponen pesados, concéntrate primero en repartir bien la proteína y el agua durante el día.

Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) y "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Part A: Select Your Lifespan Nutrition Case Study

Client: 68-year-old retired agricultural supervisor in Yuma, AZ beginning resistance training. Data: Body Mass: 75.0 kg | Current Protein Intake: 48 g/day (0.64 g/kg/day, skewed 70% at dinner) | Target DGA/Clinical Range: 1.2–1.6 g/kg/day evenly distributed (25–30 g/meal).

Client: 29-year-old second-trimester recreational swimmer and elementary teacher in Somerton, AZ. Data: Pre-pregnancy Mass: 64.0 kg | Current Intake: 1,950 kcal/day | Needs +340 kcal/day second-trimester adjustment, 1.1 g/kg/day protein, plus iron, folate, and choline verification.

Athlete: 62-year-old masters cyclist in Imperial Valley / Yuma training 4 days/week in dry heat. Data: Body Mass: 70.0 kg | Current Protein: 60 g/day (0.86 g/kg/day) | Needs 1.4–1.6 g/kg/day whole-food protein distribution and heat-adjusted fluid/electrolyte replacement.


### Part B: Clinical Framing Protocol (Pattern / Rule / Solve) & Four-Part Submission

- Part 1 (The Engine — P-T-C-F Prompt): Wrap your selected client case in triple-hashes ( ### ) and prompt Gemini to calculate daily protein targets (g/day and g/meal across 3–4 meals) and micronutrient priorities under the 2025–2030 Dietary Guidelines for Americans .
- Part 2 (The Clinical Audit — 150 Words): Audit the AI's meal plan using Pattern / Rule / Solve . Verify exact protein math ($ ext{Mass in kg} imes ext{Target g/kg/day}$), leucine/meal distribution thresholds (25–35 g/meal), and real-food affordability for Yuma County families.
- Part 3 (Active Verification — 150 Words): In your own authentic voice, explain to your client why evenly spacing real-food protein (eggs, Greek yogurt, pinto beans, lean poultry, fish) across breakfast, lunch, and dinner protects muscle and bone health better than a single heavy dinner or expensive supplements.
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Exemplar: 10/10 Submission Standard

Pattern: Track 1 client (75.0 kg, 68 y/o) consumes only 48 g/day protein (0.64 g/kg/day), creating anabolic resistance and sarcopenia risk. Rule (2025–2030 DGA): Older adults performing resistance exercise require 1.2–1.6 g/kg/day ($75.0 imes 1.4 = 105 ext{ g/day}$) divided into 3 meals of $pprox 30 ext{–}35 ext{ g}$ whole-food protein plus vitamin D, calcium, and fluid adequacy. Solve: Rebalance intake to 35 g breakfast (eggs, cottage cheese, corn tortillas), 35 g lunch (grilled chicken, pinto beans, greens), and 35 g dinner (baked fish, quinoa, roasted vegetables) with 2.8 L/day baseline fluids.


## Módulo 14 Laboratorio y Simulación: Plan de Alimentación en el Ciclo de Vida y Auditoría de Proteína en el Adulto Mayor

Aplique el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y las Guías Alimentarias 2025–2030 (Enfoque en Comida Real) para calcular y auditar los requerimientos de proteína por comida y micronutrientes clave en el ciclo de vida. Entregue las Partes 1, 2 y 3 en el cuadro de texto de Canvas.

HLTH-150 • Module 14 Quick Return Navigation / Regreso Rápido al Módulo 14:

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 14 (Mod 14 Lab: Lifespan Meal Plan & Older Adult Protein Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
