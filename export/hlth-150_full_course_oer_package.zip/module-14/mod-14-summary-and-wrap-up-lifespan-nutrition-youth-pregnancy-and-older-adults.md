## HLTH-150: Mod 14 Summary And Wrap Up Lifespan Nutrition Youth Pregnancy And Older Adults

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 14 Summary & Wrap-Up: Lifespan Nutrition (Youth, Pregnancy & Older Adults)

Nutrición a lo Largo de la Vida, Pediatría, Embarazo y Prevención de Sarcopenia


### Step 1: Core Lifespan Nutrition Synthesis

Congratulations on completing Module 14! You have successfully mastered the physiological mechanics of nutritional requirements across the human lifespan:

- Maternal & Pediatric Demands: Pregnancy requires caloric increases (+340 to +452 kcal/day) and targeted micronutrients (folate, iron, calcium), while youth development demands balanced fueling aligned with PAGA 2018.
- Geriatric Anabolic Resistance: Sarcopenia involves age-related muscle mass loss requiring elevated protein targets (1.2 to 2.0 g/kg/day) and per-meal leucine triggers (~30 to 40g protein) to stimulate muscle protein synthesis.
- Multicomponent Activity: Combining higher protein intake with progressive resistance training and PAGA 2018 physical activity guidelines preserves functional independence in older adults.

### Step 2: Workplace Intelligence & AI Safety Auditor Protocol

In clinical dietetics and community health coaching, professionals utilize secure AI simulation frameworks to audit lifespan nutrition calculations and protect client health.

- AI-Assisted Protein Calculations: Nutritionists prompt AI preceptors to evaluate daily protein grams, per-meal pacing distributions, and micronutrient densities with absolute mathematical precision.
- Delimiter Security Protocol (###): Client body mass values, life stage scenarios, and protein logs must be enclosed inside triple hashes ( ### ) to maintain strict data boundary isolation during automated preceptor analysis.
- Clinical Auditing: Professionals verify AI outputs against federal SSoT standards (PAGA 2018 / DGA) to guarantee client safety and eliminate nutritional shortfalls.

### Step 3: Module 14 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 15:

English Calculation: Sarcopenia involves progressive age-related loss of muscle mass and 'anabolic resistance,' requiring higher per-meal protein doses and leucine triggers to stimulate muscle protein synthesis.

Cálculo en Español: La sarcopenia implica la pérdida de masa muscular relacionada con la edad y 'resistencia anabólica', requiriendo dosis proteicas mayores y disparadores de leucina.

English Rationale: Older adults should consume 1.2 to 2.0 g/kg/day of high-quality protein, distributed evenly across meals (at least 30g per feeding), to overcome anabolic resistance.

Justificación en Español: Los adultos mayores deben consumir de 1.2 a 2.0 g/kg/día de proteína de alta calidad, distribuida equitativamente en las comidas (al menos 30g por porción).

English Rationale: Additional caloric intake (+340 to +452 kcal/day) supports fetal growth, placental development, maternal blood volume expansion, and increased basal metabolic demands.

Justificación en Español: La ingesta calórica adicional (+340 a +452 kcal/día) apoya el crecimiento fetal, el desarrollo placentario, la expansión del volumen sanguíneo y la tasa metabólica.

English Response: Enclosing client body mass parameters and protein logs inside triple hashes ( ### ) ensures clean data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 standards.

Respuesta en Español: Encapitular los parámetros de masa corporal y registros proteicos del cliente entre delimitadores de tres numerales ( ### ) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con PAGA 2018.

English Response: Combining higher protein intake with progressive resistance training and balance exercises prevents falls, preserves bone mineral density, and mitigates frailty.

Respuesta en Español: Combinar una mayor ingesta proteica con entrenamiento de resistencia y ejercicios de equilibrio previene caídas, preserva la densidad ósea y mitiga la fragilidad.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.


### AI Simulation Workspace • Exam Simulation & Synthesis

Copy the prompt below into Gemini to generate a personalized review sheet comparing RED-S pathology (Module 13) and lifespan nutrition (Module 14):

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 RED-S & Lifespan Synthesis ###:
Role: Clinical Sports Nutritionist and Academic Tutor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: RED-S Pathology (Energy Availability Thresholds, Endocrine Suppression)
   Key Point: Lifespan Nutrition (Geriatric Anabolic Resistance, Maternal Metabolic Demands)
Step 2: Explain how geriatric protein pacing overcomes anabolic resistance compared to younger adult requirements.
Step 3: Provide 3 whole-food nutrition strategies supporting healthy aging and muscle preservation in older adults.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 15 — Capstone Synthesis: Integrated Clinical Nutrition Programming

In plain English, next week in Module 15: Capstone Synthesis — Integrated Clinical Nutrition Programming you will combine macronutrient math, desert hydration, cultural foodways, and grocery budget rules into a unified 7-day nutrition and hydration plan. Why it matters: Module 15 lets you practice integrating every piece of the course right before your final Module 16 portfolio defense.

- Pattern (Context): Synthesizing a client's training load, desert heat exposure, cultural food preferences, and weekly grocery budget.
- Rule (Constraint): Verifying full compliance with the 2025–2030 DGA ('Real Food' Focus) , hydration replacement math, and Scope of Practice.
- Solve (Intervention): Completing Mod 15 Discussion: Integrated Nutrition Case Review and Mod 15 Lab: 7-Day Integrated Nutrition & Hydration Plan .
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 14 (Mod 14 Summary & Wrap-Up: Lifespan Nutrition (Youth, Pregnancy & Older Adults))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 14: Resumen y Comprobación de Conocimientos


### Síntesis del Módulo 14: Nutrición a lo Largo de la Vida y Prevención de Sarcopenia

Esta semana analizamos los requerimientos nutricionales a lo largo de las distintas etapas de la vida humana. Evaluamos el crecimiento pediátrico, las demandas metabólicas del embarazo y la resistencia anabólica en adultos mayores.

Al vincular las normas federales ( pautas de PAGA 2018 / DGA ) con los protocolos de pacing proteico, consolidó una base científica para prescribir estrategias nutricionales en entornos clínicos, comunitarios y deportivos.


### Conclusiones del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) • Patrón, Regla, Solución

Los adultos mayores experimentan resistencia anabólica, requiriendo dosis proteicas mayores y disparadores de leucina para estimular la síntesis muscular.

Consumir de 1.2 a 2.0 g/kg/día de proteína en adultos mayores, combinada con entrenamiento de resistencia para preservar la masa magra.

Distribuir la proteína equitativamente en tres comidas diarias (mínimo 30g cada una) adaptadas a las demandas metabólicas de cada etapa.


### Autoevaluación del Módulo 14 (Verificación Bilingüe)

Presione cada elemento para verificar su comprensión:

Respuesta en Español: La sarcopenia implica la pérdida de masa muscular relacionada con la edad y 'resistencia anabólica', requiriendo dosis proteicas mayores y disparadores de leucina.

English Calculation: Sarcopenia involves progressive age-related loss of muscle mass and 'anabolic resistance,' requiring higher per-meal protein doses and leucine triggers.

Respuesta en Español: Los adultos mayores deben consumir de 1.2 a 2.0 g/kg/día de proteína de alta calidad, distribuida equitativamente en las comidas (al menos 30g por porción).

English Rationale: Older adults should consume 1.2 to 2.0 g/kg/day of high-quality protein, distributed evenly across meals (at least 30g per feeding), to overcome anabolic resistance.

Respuesta en Español: La ingesta calórica adicional (+340 a +452 kcal/día) apoya el crecimiento fetal, el desarrollo placentario, la expansión del volumen sanguíneo y la tasa metabólica.

English Rationale: Additional caloric intake (+340 to +452 kcal/day) supports fetal growth, placental development, maternal blood volume expansion, and increased basal metabolic demands.

Respuesta en Español: Encapitular los parámetros de masa corporal y registros proteicos del cliente entre delimitadores de tres numerales ( ### ) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con PAGA 2018.

English Response: Enclosing client body mass parameters and protein logs inside triple hashes ( ### ) ensures clean data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 standards.

Respuesta en Español: Combinar una mayor ingesta proteica con entrenamiento de resistencia y ejercicios de equilibrio previene caídas, preserva la densidad ósea y mitiga la fragilidad.

English Response: Combining higher protein intake with progressive resistance training and balance exercises prevents falls, preserves bone mineral density, and mitigates frailty.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Review Master Protocol: HLTH-150 Sintesis de RED-S y Nutricion Vital ###:
Rol: Nutriologo Deportivo Clinico y Tutor Academico en la voz del Narrator.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Patologia RED-S (Energy Availability Thresholds, Endocrine Suppression)
   Key Point: Nutricion a lo Largo de la Vida (Geriatric Anabolic Resistance, Maternal Metabolic Demands)
Step 2: Explicar como el pacing proteico geriátrico supera la resistencia anabólica en comparación con los requerimientos de adultos jóvenes.
Step 3: Proponer 3 estrategias de nutrición con alimentos integrales que apoyen el envejecimiento saludable y la preservación muscular en adultos mayores.
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 15 — Síntesis Capstone: Programación Integrada de Nutrición Clínica

En palabras sencillas (Contexto Norteño): la próxima semana en el Módulo 15 unirás todo lo que aprendiste en el semestre (macronutrientes, hidratación en el calor de Yuma, comida tradicional y presupuesto) dentro de un plan completo de 7 días. Esto te servirá como ensayo directo antes de entregar tu portafolio final en el Módulo 16.

- Patrón (Contexto): Integrar la carga de entrenamiento, el calor ambiental, la cultura alimentaria y el presupuesto familiar de un cliente.
- Regla (Restricción): Verificar el cumplimiento total de las Guías Alimentarias 2025–2030 (DGA) , cálculos de sudoración y alcance de práctica.
- Solución (Intervención): Completar el Foro del Mód 15 (Integrated Nutrition Case Review) y el Laboratorio del Mód 15 (7-Day Integrated Nutrition & Hydration Plan) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 14 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 14:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 14)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
