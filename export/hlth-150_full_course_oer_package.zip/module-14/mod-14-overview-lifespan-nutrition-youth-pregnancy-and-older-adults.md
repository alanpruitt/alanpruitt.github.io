# HLTH-150: Mod 14 Overview Lifespan Nutrition Youth Pregnancy And Older Adults

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 14 Overview: Lifespan Nutrition (Youth, Pregnancy & Older Adults)

El Porqué del Módulo 14 (Círculo Dorado — Contexto Norteño): “¿Por qué cambian tanto las necesidades de nutrición en niños, embarazadas y adultos mayores, y cómo la comida real fortalece a cada generación de nuestras familias en Yuma?”


### Module 14 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 14: Lifespan Nutrition (Youth, Pregnancy & Older Adults)

Welcome to Week 14! Building upon our study of clinical pathology and energy availability, this week we examine nutritional requirements across the human lifespan: Pediatrics, Pregnancy, Lactation, and Geriatrics . Nutritional demands shift dynamically from fetal development and childhood growth to maternal-fetal metabolic pacing and the prevention of sarcopenia in older adults.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify developmental nutrition patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and Dietary Guidelines for Americans (DGA) baselines, and design individualized lifecycle nutrition protocols.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, November 17, 2026, at 12:00 AM MST
- Final Course Evaluation / Evaluación Final del Curso: Thursday, November 19, 2026, at 11:59 PM MST[cite: 1.2, 1.3]
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, November 23, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 14 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze nutritional deficiency and metabolic demand patterns across distinct developmental life stages from early childhood to senescence. Analizar patrones de deficiencia nutricional y demanda metabólica en distintas etapas del desarrollo vital.
- CLO 2 (Rule Application): Apply PAGA 2018 and DGA lifespan nutrient standards, maternal caloric requirements, and geriatric protein/hydration baselines. Aplicar las normas nutricionales de PAGA 2018 y DGA para cada etapa vital, requerimientos maternos y bases geriátricas.
- CLO 3 (Problem Solving): Formulate evidence-based nutritional prescriptions tailored to pediatric, prenatal, and geriatric populations exercising or rehabilitating in community settings. Formular prescripciones nutricionales basadas en evidencia adaptadas a poblaciones pediátricas, prenatales y geriátricas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Lab and Evaluation, you will continue working within your chosen career track:

Managing geriatric protein requirements to combat sarcopenia, rehabilitation nutrition in older adults, and clinical prenatal guidelines.

WIC and maternal nutrition programs in Yuma County, childhood obesity prevention, and senior nutrition assistance accessibility.

Nutritional support for adolescent and youth sport development, Masters athlete fueling, and maintaining performance across aging skeletal muscle.


### Module 14 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Pediatric Growth, Pregnancy Demands & Geriatric Sarcopenia Prevention
- Final Student Course Evaluation (Replaces standard discussion board)[cite: 1.2, 1.3]
- Lab Assignment: Lifespan Case Audit, Protein Formulation & Gemini AI Tool Kit
- Knowledge Check & Module Summary

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hydration), Safety Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our HLTH-150 Academic Source of Truth (2025–2030 Dietary Guidelines for Americans ('Real Food' Focus)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Fuel Box (RMR, BMR, TDEE), Biometrics Box, Recovery Box (hidratación), Safety Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de HLTH-150 (Guías Alimentarias para los Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales')) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 14) / Simulación Clínica y Dominio de Resultados (Módulo 14)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 14 (Mod 14 Overview: Lifespan Nutrition (Youth, Pregnancy & Older Adults))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 14 Visión General: Nutrición a lo Largo de la Vida


### Bienvenido al Módulo 14: Pediatría, Embarazo y Nutrición Geriátrica

¡Bienvenido a la Semana 14! Basándonos en nuestro estudio sobre trastornos alimentarios, examinamos los requerimientos nutricionales a lo largo de la vida humana: Pediatría, Embarazo, Lactancia y Geriatría . Las demandas cambian dinámicamente desde el desarrollo fetal hasta la prevención de la sarcopenia en adultos mayores.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones nutricionales en cada etapa vital, aplicarás las normas de PAGA 2018 y DGA, y diseñarás protocolos nutricionales individualizados.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar patrones de deficiencia nutricional y demanda metabólica en distintas etapas del desarrollo vital desde la niñez hasta la senescencia.
- CLO 2 (Regla): Aplicar las normas nutricionales de PAGA 2018 y DGA para cada etapa vital, requerimientos maternos y bases proteicas geriátricas.
- CLO 3 (Solución): Formular prescripciones nutricionales basadas en evidencia adaptadas a poblaciones pediátricas, prenatales y geriátricas en entornos comunitarios.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, continuará trabajando dentro de la ruta profesional que haya seleccionado:

Manejo de requerimientos proteicos en adultos mayores para combatir la sarcopenia, nutrición de rehabilitación y directrices prenatales clínicas.

Programas WIC y nutrición materna en Yuma, prevención de obesidad infantil y accesibilidad a asistencia nutricional para adultos mayores.

Apoyo nutricional para el desarrollo deportivo juvenil, alimentación de atletas veteranos (Masters) y mantenimiento del rendimiento muscular.


### Ruta de Aprendizaje del Módulo 14

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Crecimiento Pediátrico, Demandas de Embarazo y Prevención de Sarcopenia
- Evaluación Final del Curso (Reemplaza el foro de discusión estándar)[cite: 1.2, 1.3]
- Práctica de Laboratorio: Auditoría de Casos Vitales, Formulación de Proteína y Caja de Herramientas de IA
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA. Esta estructura es responsiva en dispositivos móviles, compatible con lectores de pantalla y diseñada para un acceso equitativo.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 14 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 14 Required Readings: Lifespan Nutrition (Youth, Pregnancy & Older Adults) →
- Step 2 — Complete the Student Course Evaluation (Paso 2 — Evaluación del Curso): Mod 14: Final Student Course Evaluation →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 14 Coaching Sprint: Nutrition for Youth, Pregnancy & Older Adults →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 14 Lab: Lifespan Meal Plan & Older Adult Protein Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 14 Summary & Wrap-Up: Lifespan Nutrition (Youth, Pregnancy & Older Adults) →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
