# HLTH-150: Mod 14 Required Readings Lifespan Nutrition Youth Pregnancy And Older Adults

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 14 Required Readings: Lifespan Nutrition (Youth, Pregnancy & Older Adults)

Lecturas Obligatorias: Crecimiento Pediátrico, Embarazo y Prevención de Sarcopenia

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from 2025–2030 Dietary Guidelines for Americans (Real-Food Focus) & PAGA 2018), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 14): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Lifespan nutrition adapts whole-food calorie, protein, calcium, iron, and folate targets for growing youth, pregnancy, and older adults. Each stage of life shifts physiology—from bone growth in teens to fetal development in pregnancy and muscle preservation (fighting sarcopenia) in seniors. Tailoring real-food meals to life stage keeps every generation of a family thriving.


#### En Palabras Sencillas (Norteño Context)

En una comida familiar en Yuma, el niño que está creciendo, la mamá embarazada y el abuelo necesitan porciones y nutrientes distintos. Si los términos técnicos se ponen pesados, concéntrate primero en los nutrientes clave para jóvenes, embarazo y adultos mayores según las Guías Alimentarias 2025–2030.


### Regional Focus: Demographics & Lifespan Health in Yuma County

Enfoque Regional: Demografía y Salud a lo Largo de la Vida en el Condado de Yuma

In Yuma County and southwestern Arizona, diverse demographic populations ranging from pediatric youth sports participants to a prominent retirement community require specialized nutritional governance. Lifespan nutrition addresses the unique metabolic demands of pregnancy, the prevention of pediatric nutritional deficiencies, and the mitigation of age-related muscle mass loss (sarcopenia) through optimized protein pacing and resistance training anchored in federal guidelines (PAGA 2018 and DGA).

En el condado de Yuma y el suroeste de Arizona, poblaciones diversas que van desde jóvenes deportistas hasta una prominente comunidad de adultos mayores requieren gobernanza nutricional especializada. La nutrición a lo largo de la vida aborda la prevención de deficiencias pediátricas y la mitigación de la sarcopenia mediante optimización proteica y PAGA 2018.


### Reading 1: Pediatric Growth & Maternal-Fetal Nutrition

Lectura 1: Crecimiento Pediátrico y Nutrición Materno-Fetal


#### Step 1: Maternal Metabolic Demands During Pregnancy and Lactation

Demandas Metabólicas Maternas Durante el Embarazo y la Lactancia

Pregnancy demands an increased caloric intake (approximately +340 kcal/day in the second trimester and +452 kcal/day in the third trimester) alongside heightened requirements for folate, iron, calcium, and protein (1.1 g/kg/day). Lactation requires even greater energy output (~500 kcal/day) to support milk production, emphasizing hydration and whole-food micronutrient density.

El embarazo exige mayor ingesta calórica (~+340 kcal/día en el segundo trimestre y +452 kcal/día en el tercero) junto con mayores requerimientos de folato, hierro, calcio y proteína (1.1 g/kg/día). La lactancia demanda mayor gasto (~500 kcal/día).


#### Step 2: Pediatric and Adolescent Fueling Requirements

Requerimientos Nutricionales Pediátricos y en la Adolescencia

Pediatric athletes and growing children exhibit high relative energy needs to support skeletal elongation, neurological development, and athletic participation. In alignment with PAGA 2018 youth guidelines, children require at least 60 minutes of daily physical activity paired with balanced macronutrient distributions and calcium-rich foods to optimize peak bone mass accrual.

Los atletas pediátricos y niños en crecimiento exhiben altas necesidades energéticas relativas para apoyar el desarrollo esquelético y la participación deportiva. De acuerdo con PAGA 2018, los niños requieren al menos 60 minutos de actividad diaria.


### Reading 2: Geriatric Nutrition & Sarcopenia Prevention

Lectura 2: Nutrición Geriátrica y Prevención de Sarcopenia


#### Step 1: Pathophysiology of Sarcopenia and Anabolic Resistance

Fisiopatología de la Sarcopenia y Resistencia Anabólica

Sarcopenia is the age-related, progressive loss of skeletal muscle mass, strength, and function. Older adults experience 'anabolic resistance,' meaning their muscles require higher per-meal protein doses (0.40 to 0.45 g/kg per feeding or ~30 to 40g protein) and leucine triggers (~3g leucine) to stimulate muscle protein synthesis comparably to younger populations.

La sarcopenia es la pérdida progresiva de masa muscular y fuerza relacionada con la edad. Los adultos mayores experimentan 'resistencia anabólica', requiriendo dosis proteicas mayores por comida (0.40 a 0.45 g/kg o ~30-40g de proteína).


#### Step 2: Federal Dietary Guidance for Seniors (PAGA 2018 & DGA SSoT)

Directrices Dietéticas Federales para Adultos Mayores (SSoT PAGA 2018 y DGA)

In strict adherence to the Physical Activity Guidelines for Americans (PAGA 2018) and current Dietary Guidelines for Americans (DGA) standards:

En estricto apego a las normas de PAGA 2018 y las directrices federales (DGA):

- Elevated Protein Targets: Older adults should consume 1.2 to 2.0 g/kg/day of high-quality protein to counteract anabolic resistance and preserve functional independence. Metas Proteicas Elevadas: Los adultos mayores deben consumir de 1.2 a 2.0 g/kg/día de proteína para contrarrestar la resistencia anabólica.
- Multicomponent Physical Activity: Combining higher protein intake with progressive resistance training and balance exercises prevents falls, preserves bone density, and mitigates frailty. Actividad Física Multicomponente: Combinar mayor ingesta proteica con entrenamiento de resistencia previene caídas y preserva la densidad ósea.

### Reading 3: Practical Lifespan Nutrition Protocols

Lectura 3: Protocolos Prácticos de Nutrición a lo Largo de la Vida

Designing lifespan nutrition protocols requires addressing unique physiological considerations across generations:

Diseñar protocolos nutricionales a lo largo de la vida requiere abordar consideraciones fisiológicas únicas en cada generación:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Evaluation and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Evaluación y el Laboratorio:

English Response: Sarcopenia involves progressive age-related loss of muscle mass and 'anabolic resistance,' requiring higher per-meal protein doses and leucine triggers to stimulate muscle protein synthesis.

Respuesta en Español: La sarcopenia implica la pérdida de masa muscular relacionada con la edad y 'resistencia anabólica', requiriendo dosis proteicas mayores y disparadores de leucina.

English Response: Older adults should consume 1.2 to 2.0 g/kg/day of high-quality protein, distributed evenly across meals (at least 30g per feeding), to overcome anabolic resistance.

Respuesta en Español: Los adultos mayores deben consumir de 1.2 a 2.0 g/kg/día de proteína de alta calidad, distribuida equitativamente en las comidas (al menos 30g por porción).

English Response: Additional caloric intake (+340 to +452 kcal/day) supports fetal growth, placental development, maternal blood volume expansion, and increased basal metabolic demands.

Respuesta en Español: La ingesta calórica adicional (+340 a +452 kcal/día) apoya el crecimiento fetal, el desarrollo placentario, la expansión del volumen sanguíneo y la tasa metabólica.

HLTH-150 • Module 14 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 14:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 14 (Mod 14 Required Readings: Lifespan Nutrition (Youth, Pregnancy & Older Adults))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```
