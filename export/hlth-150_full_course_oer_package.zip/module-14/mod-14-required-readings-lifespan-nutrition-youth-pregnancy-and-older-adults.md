## HLTH-150: Mod 14 Required Readings Lifespan Nutrition Youth Pregnancy And Older Adults

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 14 Required Readings: Lifespan Nutrition (Youth, Pregnancy & Older Adults)

Lecturas Obligatorias: Crecimiento Pediátrico, Embarazo y Prevención de Sarcopenia

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from 2025–2030 Dietary Guidelines for Americans (Real-Food Focus) & PAGA 2018), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 14): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Lifespan nutrition adapts whole-food calorie, protein, calcium, iron, and folate targets for growing youth, pregnancy, and older adults. Each stage of life shifts physiology—from bone growth in teens to fetal development in pregnancy and muscle preservation (fighting sarcopenia) in seniors. Tailoring real-food meals to life stage keeps every generation of a family thriving.


#### En Palabras Sencillas (Norteño Context)

En una comida familiar en Yuma, el niño que está creciendo, la mamá embarazada y el abuelo necesitan porciones y nutrientes distintos. Si los términos técnicos se ponen pesados, concéntrate primero en los nutrientes clave para jóvenes, embarazo y adultos mayores según las Guías Alimentarias 2025–2030.


### Regional Focus: Demographics & Lifespan Health in Yuma County

Enfoque Regional: Demografía y Salud a lo Largo de la Vida en el Condado de Yuma

In Yuma County and southwestern Arizona, diverse demographic populations ranging from pediatric youth sports participants to a prominent retirement community require specialized nutritional governance. Lifespan nutrition addresses the unique metabolic demands of pregnancy, the prevention of pediatric nutritional deficiencies, and the mitigation of age-related muscle mass loss (sarcopenia) through optimized protein pacing and resistance training anchored in federal guidelines (PAGA 2018 and DGA).

En el condado de Yuma y el suroeste de Arizona, poblaciones diversas que van desde jóvenes deportistas hasta una prominente comunidad de adultos mayores requieren gobernanza nutricional especializada. La nutrición a lo largo de la vida aborda la prevención de deficiencias pediátricas y la mitigación de la sarcopenia mediante optimización proteica y PAGA 2018.


### Reading 1: Pediatric Growth & Maternal-Fetal Nutrition

Lectura 1: Crecimiento Pediátrico y Nutrición Materno-Fetal


#### Step 1: Maternal Metabolic Demands During Pregnancy and Lactation

Demandas Metabólicas Maternas Durante el Embarazo y la Lactancia

Pregnancy demands an increased caloric intake (approximately +340 kcal/day in the second trimester and +452 kcal/day in the third trimester) alongside heightened requirements for folate, iron, calcium, and protein (1.1 g/kg/day). Lactation requires even greater energy output (~500 kcal/day) to support milk production, emphasizing hydration and whole-food micronutrient density.

El embarazo exige mayor ingesta calórica (~+340 kcal/día en el segundo trimestre y +452 kcal/día en el tercero) junto con mayores requerimientos de folato, hierro, calcio y proteína (1.1 g/kg/día). La lactancia demanda mayor gasto (~500 kcal/día).


#### Step 2: Pediatric and Adolescent Fueling Requirements

Requerimientos Nutricionales Pediátricos y en la Adolescencia

Pediatric athletes and growing children exhibit high relative energy needs to support skeletal elongation, neurological development, and athletic participation. In alignment with PAGA 2018 youth guidelines, children require at least 60 minutes of daily physical activity paired with balanced macronutrient distributions and calcium-rich foods to optimize peak bone mass accrual.

Los atletas pediátricos y niños en crecimiento exhiben altas necesidades energéticas relativas para apoyar el desarrollo esquelético y la participación deportiva. De acuerdo con PAGA 2018, los niños requieren al menos 60 minutos de actividad diaria.


### Reading 2: Geriatric Nutrition & Sarcopenia Prevention

Lectura 2: Nutrición Geriátrica y Prevención de Sarcopenia


#### Step 1: Pathophysiology of Sarcopenia and Anabolic Resistance

Fisiopatología de la Sarcopenia y Resistencia Anabólica

Sarcopenia is the age-related, progressive loss of skeletal muscle mass, strength, and function. Older adults experience 'anabolic resistance,' meaning their muscles require higher per-meal protein doses (0.40 to 0.45 g/kg per feeding or ~30 to 40g protein) and leucine triggers (~3g leucine) to stimulate muscle protein synthesis comparably to younger populations.

La sarcopenia es la pérdida progresiva de masa muscular y fuerza relacionada con la edad. Los adultos mayores experimentan 'resistencia anabólica', requiriendo dosis proteicas mayores por comida (0.40 a 0.45 g/kg o ~30-40g de proteína).


#### Step 2: Federal Dietary Guidance for Seniors (PAGA 2018 & DGA SSoT)

Directrices Dietéticas Federales para Adultos Mayores (SSoT PAGA 2018 y DGA)

In strict adherence to the Physical Activity Guidelines for Americans (PAGA 2018) and current Dietary Guidelines for Americans (DGA) standards:

En estricto apego a las normas de PAGA 2018 y las directrices federales (DGA):

- Elevated Protein Targets: Older adults should consume 1.2 to 2.0 g/kg/day of high-quality protein to counteract anabolic resistance and preserve functional independence. Metas Proteicas Elevadas: Los adultos mayores deben consumir de 1.2 a 2.0 g/kg/día de proteína para contrarrestar la resistencia anabólica.
- Multicomponent Physical Activity: Combining higher protein intake with progressive resistance training and balance exercises prevents falls, preserves bone density, and mitigates frailty. Actividad Física Multicomponente: Combinar mayor ingesta proteica con entrenamiento de resistencia previene caídas y preserva la densidad ósea.

### Reading 3: Practical Lifespan Nutrition Protocols

Lectura 3: Protocolos Prácticos de Nutrición a lo Largo de la Vida

Designing lifespan nutrition protocols requires addressing unique physiological considerations across generations:

Diseñar protocolos nutricionales a lo largo de la vida requiere abordar consideraciones fisiológicas únicas en cada generación:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Evaluation and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Evaluación y el Laboratorio:

English Response: Sarcopenia involves progressive age-related loss of muscle mass and 'anabolic resistance,' requiring higher per-meal protein doses and leucine triggers to stimulate muscle protein synthesis.

Respuesta en Español: La sarcopenia implica la pérdida de masa muscular relacionada con la edad y 'resistencia anabólica', requiriendo dosis proteicas mayores y disparadores de leucina.

English Response: Older adults should consume 1.2 to 2.0 g/kg/day of high-quality protein, distributed evenly across meals (at least 30g per feeding), to overcome anabolic resistance.

Respuesta en Español: Los adultos mayores deben consumir de 1.2 a 2.0 g/kg/día de proteína de alta calidad, distribuida equitativamente en las comidas (al menos 30g por porción).

English Response: Additional caloric intake (+340 to +452 kcal/day) supports fetal growth, placental development, maternal blood volume expansion, and increased basal metabolic demands.

Respuesta en Español: La ingesta calórica adicional (+340 a +452 kcal/día) apoya el crecimiento fetal, el desarrollo placentario, la expansión del volumen sanguíneo y la tasa metabólica.

HLTH-150 • Module 14 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 14:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 14 (Mod 14 Required Readings: Lifespan Nutrition (Youth, Pregnancy & Older Adults))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 14)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
