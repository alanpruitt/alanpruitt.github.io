## HLTH-150: Mod 14 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 14) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 14 Coaching Sprint Simulation: Nutrition for Youth, Pregnancy & Older Adults

- Anabolic Resistance in Older Adults (1.2–1.6 g/kg/day & 25–35 g/Meal): Aging muscle requires a higher per-meal protein and leucine dose (25–35 g high-quality protein per meal) paired with resistance exercise to prevent sarcopenia. En palabras sencillas: Con los años el músculo aprovecha menos la proteína, por lo que un adulto mayor necesita de 25 a 35 gramos de proteína real por comida más ejercicios de fuerza.
- Maternal Trimester Energy & Micronutrient Increments (DGA 2025–2030): Pregnancy requires +0 kcal (1st trimester), +340 kcal/day (2nd trimester), and +452 kcal/day (3rd trimester) alongside critical folate, iron, iodine, and choline from real foods. En palabras sencillas: Durante el embarazo se suman +340 calorías en el segundo trimestre y +452 en el tercero con alimentos ricos en ácido fólico, hierro y colina.
- Youth Peak Bone Mass Accrual (Calcium, Vitamin D & Unrestrictive Fueling): Adolescence is the critical window for building lifetime bone mineral density; restrictive dieting during youth stunts growth and increases fracture risk. En palabras sencillas: En niños y adolescentes nunca se aplican dietas restrictivas; necesitan calcio, vitamina D y energía suficiente para crecer y formar huesos fuertes.

### Coach Alan's Weekly Check-In: From Cradle to Senescence

Team, welcome to Week 14! Last week we audited RED-S and clinical eating disorders. This week, we examine nutritional requirements across the entire human lifespan: Pediatrics, Pregnancy, and Geriatric Sarcopenia Prevention .

Additionally, this week features our Final Student Course Evaluation in place of the standard discussion board. As you complete your lifespan case audits and share your course feedback, remember that evidence-based exercise science spans every generation. Let's finish strong!


### Module 14 Tactical Roadmap / Ruta Táctica del Módulo 14

- Step 1: Required Readings: Master pediatric growth needs, maternal-fetal metabolic demands, and geriatric protein pacing (sarcopenia prevention).
- Step 2: Final Course Evaluation: Submit your anonymous student course evaluation by Thursday at 11:59 PM MST.
- Step 3: Lab 14 Audit: Complete your track's lifespan case calculations, verify via the Gemini AI Tool Kit, and submit by Monday at 11:59 PM MST.
- Step 4: Module 14 Knowledge Check: Lock in your mastery of lifespan nutrition baselines.
Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Lifespan Thermoregulatory Hydration & Nutrient Density Auditor (/simulators/desert-sweat-rate) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate lifespan fluid replacement (<2% Body Mass Loss in Yuma heat) alongside age-specific DGA 2025–2030 real-food priorities (youth calcium/vitamin D, pregnancy folate/iron/choline, and older-adult protein 1.0–1.2+ g/kg/day). Copy your VERIFIED simulator receipt or slider values into the submission template below.

Open Lifespan Thermoregulatory Hydration & Nutrient Density Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/desert-sweat-rate y "PAGA"): Calibre la hidratación en cada etapa de vida (<2% pérdida corporal en Yuma) junto con las metas DGA 2025–2030 (calcio/vitamina D juvenil, folato/hierro prenatal y proteína 1.0–1.2+ g/kg/día en adultos mayores). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### The Coach's Playbook: Three Lifespan Nutrition Traps to Avoid

Applying adult male macronutrient targets directly to pregnant individuals, pediatric athletes, or older adults without adjusting for unique metabolic demands.

Relying on outdated RDA protein minimums (0.8 g/kg) for older adults, accelerating anabolic resistance and sarcopenic muscle wasting.

Overlooking blunted thirst sensations and renal concentrating capacity changes among geriatric populations in desert climates.


### AI Study Coach • Quick Concept Check

Want a 60-second quiz on this week's lifespan nutrition before tackling the lab? Copy this prompt into Gemini:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Quiz Master Protocol: HLTH-150 Module 14 Coaching Sprint ###:
Role: Supportive HLTH-150 Study Coach.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Ask the student 3 quick multiple-choice questions testing:
   Section a: Geriatric protein targets (1.2 to 2.0 g/kg) and anabolic resistance mechanisms
   Section b: Maternal caloric demands during the second and third trimesters of pregnancy
   Section c: Pediatric physical activity guidelines (60 minutes daily)
Step 2: Wait for the student's answer after each question before providing feedback.
Step 3: Keep feedback concise, encouraging, and anchored in evidence-based lifespan standards.
End Quiz Master Protocol ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 14 (Mod 14 Coaching Sprint: Nutrition for Youth, Pregnancy & Older Adults)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 14 Sprint de Entrenamiento: Nutrición a lo Largo de la Vida


### Mensaje Semanal del Entrenador Alan: Desde la Niñez hasta la Senescencia

¡Equipo, bienvenidos a la Semana 14! La semana pasada auditamos la patología RED-S. Esta semana examinamos los requerimientos a lo largo de toda la vida humana: Pediatría, Embarazo y Prevención de Sarcopenia Geriátrica .

Además, esta semana presentamos nuestra Evaluación Final del Estudiante del Curso en lugar del foro de discusión habitual. Al completar sus auditorías y compartir su retroalimentación, recuerden que la ciencia del ejercicio abarca cada generación. ¡Terminemos con fuerza!


### Ruta Táctica del Módulo 14

- Step 1: Lecturas Obligatorias: Dominar el crecimiento pediátrico, las demandas metabólicas del embarazo y el pacing proteico geriátrico.
- Step 2: Evaluación Final del Curso: Enviar su evaluación anónima del curso antes del jueves a las 11:59 PM MST.
- Step 3: Laboratorio 14: Completar los cálculos de casos vitales, verificar con Gemini IA y entregar antes del lunes a las 11:59 PM MST.
- Step 4: Comprobación de Conocimientos: Afianzar el dominio sobre las bases nutricionales a lo largo de la vida.

### Estrategia del Entrenador: Tres Errores sobre Nutrición Vital que Debes Evitar

Aplicar metas de macronutrientes de adultos directamente a mujeres embarazadas, jóvenes o adultos mayores sin ajustar demandas metabólicas.

Confiar en mínimos de RDA desactualizados (0.8 g/kg) para adultos mayores, acelerando la resistencia anabólica y la pérdida muscular.

Descuidar la disminución de la sensación de sed y cambios en la concentración renal en adultos mayores en climas desérticos.


### Entrenador de Estudio con IA • Repaso Rápido

¿Desea una autoevaluación rápida de 60 segundos antes de realizar la práctica de laboratorio? Copie este prompt en Gemini:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Quiz Master Protocol: HLTH-150 Modulo 14 Coaching Sprint ###:
Rol: Tutor de Estudio Solidario para HLTH-150.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Hacer al estudiante 3 preguntas rapidas de opcion multiple evaluando:
   Section a: Metas proteicas geriátricas (1.2 a 2.0 g/kg) y resistencia anabólica
   Section b: Demandas calóricas maternas en el segundo y tercer trimestre
   Section c: Pautas de actividad física pediátrica (60 minutos diarios)
Step 2: Esperar la respuesta del estudiante tras cada pregunta antes de retroalimentar.
Step 3: Mantener explicaciones claras, motivadoras y fundamentadas en normas vitales basadas en evidencia.
Fin del Protocolo Quiz Master ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 14 Quick Return Navigation / Regreso Rápido al Módulo 14:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 14)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
