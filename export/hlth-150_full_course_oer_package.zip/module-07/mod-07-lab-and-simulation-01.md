## HLTH-150: Mod 07 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 07 Coaching Sprint Simulation: Post-Workout Recovery Meals

Sesión de Coaching del Módulo 07: Proteína Dietética, Síntesis Proteica y Recuperación Muscular

- Net Protein Balance (Muscle Protein Synthesis vs. Breakdown): Hypertrophy and recovery occur only when daily Muscle Protein Synthesis (MPS) exceeds Muscle Protein Breakdown (MPB) via evenly spaced protein feedings. En palabras sencillas: El músculo se recupera y crece cuando repartes bien tu proteína en 3 a 4 comidas al día en vez de comerla toda junta en la noche.
- Post-Workout Recovery Ratio (Carbohydrate + Protein Synergy): Pairing 1.0–1.2 g/kg carbohydrates with 20–40 g whole-food protein after exhaustive training replenishes glycogen and repairs myofibrillar damage simultaneously. En palabras sencillas: Combinar carbohidratos reales (fruta, avena, tortilla) con 20–40 g de proteína al terminar de entrenar para recargar energía y reparar el músculo.
- Pre-Sleep Slow-Digesting Protein (Overnight Recovery): A whole-food protein feeding before bed (e.g., Greek yogurt, cottage cheese, milk, or legumes) supports overnight muscle remodeling. En palabras sencillas: Una cena ligera o colación rica en proteína natural antes de dormir ayuda a que tus músculos se reparen mientras descansas.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Muscle protein synthesis is the biological process of turning dietary amino acids into new muscle tissue. Eating massive protein doses all at once wastes nutrients because your muscles can only absorb so much at a time. Spacing your protein into moderate servings with 3 grams of leucine every few hours triggers optimal muscle repair.


#### En Palabras Sencillas (Norteño Context)

Echarle toda la proteína del día en una sola sentada es como querer llenar el tanque de la troca echándole gasolina con una cubeta: la mitad se desparrama y se desperdicia. Si los términos técnicos se ponen pesados, concéntrate primero en repartir la comida en porciones parejas a lo largo del día.

- HLTH-150.7.1.AY26-27: Analyze the physiological mechanisms of Muscle Protein Synthesis (MPS), the leucine threshold, and 24-hour protein pacing in athletic and clinical populations. Analizar los mecanismos fisiológicos de la síntesis de proteínas musculares (MPS), el umbral de leucina y la distribución de proteína en 24 horas.
- HLTH-150.7.2.AY26-27: Design evidence-based daily protein distribution and whole-food recovery protocols aligned with ACSM and ISSN standards. Diseñar protocolos de distribución de proteína y recuperación basados en alimentos reales según las pautas de ACSM e ISSN.
- Module Window / Ventana del Módulo: Opens Tuesday, September 29, 2026, at 12:00 AM MST Abre el martes, 29 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 5, 2026, at 11:59 PM MST Lunes, 5 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Coaching Sprint Benchmark (10/7/0 Mastery Scale) Ponderación para sesiones semanales de coaching y simulación

### Your Weekly Win: Protein Timing & Muscle Remodeling

While carbohydrates fuel the workout, dietary protein provides the essential amino acids needed to repair damaged muscle fibers and build lean tissue. Consuming all your protein in a single massive sitting triggers the "muscle-full" effect, oxidizing excess amino acids rather than stimulating new muscle growth. By periodizing protein into balanced feedings that hit the leucine trigger (~2.5 to 3.0g leucine) every 3 to 5 hours, you maximize 24-hour recovery. Choose your coaching track below, chat with your AI Socratic Coach, and master protein distribution science!

¿Cómo optimizar la recuperación muscular? Comer toda la proteína en una sola comida satura la síntesis muscular. Repartir la proteína en tomas estratégicas con suficiente leucina (~2.5 a 3.0 g) estimula la recuperación constante. ¡Elija su ruta y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Selección de Escenario de Simulación Clínica

Scenario: Older adult post-arthroplasty patient (Helena, 68) experiencing quadriceps muscle atrophy and age-related anabolic resistance due to skewed protein intake.

Scenario: High school football athlete (Julian, 17) consuming excessive protein powder shakes (>3.5 g/kg) while cutting carbohydrates, leading to dehydration and fatigue in Yuma heat.

Scenario: Adult powerlifter (Derek, 32) consuming 200g of daily protein in only two massive meals, suffering from prolonged muscle soreness due to the "muscle-full" effect.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client / Ruta y Cliente Seleccionado: State your selected track and client's protein distribution challenge. Indique la ruta y el desafío de distribución de proteína de su cliente.
- Protein & Physiological Analysis / Análisis de Proteína y Fisiología: Explain how the leucine threshold (~2.5g), "muscle-full" effect, or anabolic resistance applies to your client. Explique cómo aplica el umbral de leucina (~2.5 g), el efecto de saturación muscular o la resistencia anabólica.
- My Practical Protein Strategy / Mi Estrategia Práctica de Proteína: Provide 1 clear, evidence-based dietary recommendation to pace protein or substitute whole foods. Escriba 1 recomendación dietética clara y basada en evidencia para distribuir la proteína.
- My Memorable Coaching Takeaway / Mi Frase Inolvidable de Coaching: Write your favorite memorable takeaway sentence in English and Spanish. Escriba su aprendizaje clave en inglés y español.
- Repository Verification / Verificación del Repositorio: Confirm export to EXW_Professional_AI_Repository . Confirme el guardado en su carpeta de Google Drive.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why distributing $20\text{–}40\text{ g}$ of whole-food protein ($2.5\text{–}3.0\text{ g}$ leucine) every 3–4 hours under the 2025–2030 Dietary Guidelines beats megadose protein shakes.

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 07 Coaching Sprint • Track 3 (Strength / Derek)

- Chosen Track & Client: Track 3: Adult Fitness & Strength Coaching (Derek, 32). Challenge: Derek consumes 200g of protein daily on an 80 kg body mass (2.5 g/kg) but eats it in only two massive meals (100g lunch, 100g dinner), leading to chronic DOMS and delayed recovery.
- Track 3: Adult Fitness & Strength Coaching (Derek, 32).
- Challenge: Derek consumes 200g of protein daily on an 80 kg body mass (2.5 g/kg) but eats it in only two massive meals (100g lunch, 100g dinner), leading to chronic DOMS and delayed recovery.
- Protein & Physiological Analysis: The "Muscle-Full" Effect: Ingesting 100g of protein in one sitting saturates muscle protein synthesis (MPS) around ~35–40g (0.40 g/kg). The remaining ~60g per meal is oxidized for energy or excreted as urea. Fasting all morning and overnight leaves his muscles in a catabolic state for 16+ hours a day.
- The "Muscle-Full" Effect: Ingesting 100g of protein in one sitting saturates muscle protein synthesis (MPS) around ~35–40g (0.40 g/kg). The remaining ~60g per meal is oxidized for energy or excreted as urea.
- Fasting all morning and overnight leaves his muscles in a catabolic state for 16+ hours a day.
- My Practical Protein Strategy for Derek: "Redistribute your 160–175g daily protein into 4 balanced meals of ~35–40g every 3 to 4 hours (e.g., eggs for breakfast, chicken for lunch, post-workout whey, and salmon for dinner) plus 30g of Greek yogurt before bed to sustain overnight muscle protein synthesis."
- "Redistribute your 160–175g daily protein into 4 balanced meals of ~35–40g every 3 to 4 hours (e.g., eggs for breakfast, chicken for lunch, post-workout whey, and salmon for dinner) plus 30g of Greek yogurt before bed to sustain overnight muscle protein synthesis."
- My Memorable Coaching Takeaway: EN: "Protein pacing powers the pump—spread your protein evenly to rebuild muscle all day and night!" ES: "¡La distribución de proteína impulsa el músculo: reparte tu proteína para reconstruir el tejido día y noche!"
- EN: "Protein pacing powers the pump—spread your protein evenly to rebuild muscle all day and night!"
- ES: "¡La distribución de proteína impulsa el músculo: reparte tu proteína para reconstruir el tejido día y noche!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M07_Quiz_Sprint.pdf
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, social media fitness influencers who tell Yuma athletes to chug 80-gram whey isolate shakes or eat 70% of their protein at dinner ignore the refractory ceiling of Muscle Protein Synthesis (MPS). Once a meal delivers 20 to 40 grams of high-quality protein containing the 2.5 to 3.0 gram leucine trigger, mTORC1 signaling is saturated and excess amino acids are oxidized into urea, increasing renal water loss in desert heat. Spacing whole-food meals (eggs, Greek yogurt, chicken, or pinto beans with corn tortillas) every 3 to 4 hours under the 2025–2030 Dietary Guidelines maximizes 24-hour muscle remodeling safely. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."

### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 07 (Mod 07 Coaching Sprint: Post-Workout Recovery Meals)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición Deportiva y para el Ejercicio


## Módulo 07 Simulación de Coaching: Proteína Dietética, MPS y Recuperación

Evaluación Rápida y Aprendizaje Práctico de Distribución de Proteína


### Su Logro Semanal: El Poder de la Distribución Proteica

Esta sesión le permitirá comprender cómo la activación repetida del umbral de leucina y la periodización de proteína maximizan la recuperación y evitan el desperdicio de aminoácidos. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Elija UNA de las tres rutas profesionales para su consulta con el Coach de IA:

Escenario: Adulta mayor posquirúrgica (Helena, 68 años) con atrofia de cuádriceps y resistencia anabólica por ingesta proteica desbalanceada.

Escenario: Atleta de fútbol americano (Julian, 17 años) consumiendo exceso de batidos de proteína (>3.5 g/kg), provocando deshidratación y fatiga en el calor de Yuma.

Escenario: Levantador de fuerza (Derek, 32 años) consumiendo 200 g de proteína en solo dos comidas, con agujetas crónicas por saturación muscular.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de distribución de proteína de su cliente.
- Análisis de Proteína y Fisiología: Explique cómo aplica el umbral de leucina (~2.5 g), el efecto de saturación muscular o la resistencia anabólica.
- Mi Estrategia Práctica de Proteína: Escriba 1 recomendación dietética clara y basada en evidencia para distribuir la proteína.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica explicando por qué distribuir de $20\text{–}40\text{ g}$ de proteína de alimentos reales ($2.5\text{–}3.0\text{ g}$ de leucina) cada 3 a 4 horas supera a los batidos de megadosis.

### Rúbrica de Evaluación en Español (Escala de Dominio 10/7/0)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: HLTH-150 Módulo 07 Sesión de Coaching • Ruta 3 (Fuerza / Derek)

- Ruta y Cliente Seleccionado: Ruta 3: Entrenamiento en Adultos y Fuerza (Derek, 32 años). Reto: Derek consume 200 g de proteína al día para un peso de 80 kg (2.5 g/kg), pero la concentra en solo dos comidas masivas (100 g almuerzo, 100 g cena), provocando agujetas (DOMS) crónicas y recuperación lenta.
- Ruta 3: Entrenamiento en Adultos y Fuerza (Derek, 32 años).
- Reto: Derek consume 200 g de proteína al día para un peso de 80 kg (2.5 g/kg), pero la concentra en solo dos comidas masivas (100 g almuerzo, 100 g cena), provocando agujetas (DOMS) crónicas y recuperación lenta.
- Análisis de Proteína y Fisiología: Efecto de Saturación Muscular: Consumir 100 g en una sola comida satura la síntesis de proteínas (MPS) alrededor de ~35–40 g. Los ~60 g restantes se oxidan como energía o se eliminan como urea. Ayunar toda la mañana y noche deja sus músculos en estado catabólico durante más de 16 horas al día.
- Efecto de Saturación Muscular: Consumir 100 g en una sola comida satura la síntesis de proteínas (MPS) alrededor de ~35–40 g. Los ~60 g restantes se oxidan como energía o se eliminan como urea.
- Ayunar toda la mañana y noche deja sus músculos en estado catabólico durante más de 16 horas al día.
- Mi Estrategia de Proteína para Derek: "Redistribuir sus 160–175 g de proteína diaria en 4 comidas balanceadas de ~35–40 g cada 3 a 4 horas (huevos al desayuno, pollo al almuerzo, suero post-entreno y salmón en la cena) más 30 g de yogur griego antes de dormir para mantener la recuperación nocturna."
- "Redistribuir sus 160–175 g de proteína diaria en 4 comidas balanceadas de ~35–40 g cada 3 a 4 horas (huevos al desayuno, pollo al almuerzo, suero post-entreno y salmón en la cena) más 30 g de yogur griego antes de dormir para mantener la recuperación nocturna."
- Mi Frase Inolvidable de Coaching: EN: "Protein pacing powers the pump—spread your protein evenly to rebuild muscle all day and night!" ES: "¡La distribución de proteína impulsa el músculo: reparte tu proteína para reconstruir el tejido día y noche!"
- EN: "Protein pacing powers the pump—spread your protein evenly to rebuild muscle all day and night!"
- ES: "¡La distribución de proteína impulsa el músculo: reparte tu proteína para reconstruir el tejido día y noche!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M07_Quiz_Sprint.pdf
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, consumir batidos de 80 gramos de proteína en una sola toma ignora el techo fisiológico de la síntesis proteica muscular (MPS) y aumenta la excreción renal de urea y la deshidratación en el calor de Yuma. Distribuir de 20 a 40 g de proteína de alimentos reales (alcanzando 2.5–3.0 g de leucina) cada 3 a 4 horas según las DGA 2025–2030 optimiza la recuperación muscular las 24 horas."
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 07)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 07)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
