## HLTH-150: Mod 07 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 07 Lab & Simulation: Daily Protein Timing & Recovery Audit

Laboratorio del Módulo 07: Proteína Dietética, Síntesis Proteica Muscular (MPS) y Auditoría de Periodización Proteica

- Net Protein Balance (Muscle Protein Synthesis vs. Breakdown): Hypertrophy and recovery occur only when daily Muscle Protein Synthesis (MPS) exceeds Muscle Protein Breakdown (MPB) via evenly spaced protein feedings. En palabras sencillas: El músculo se recupera y crece cuando repartes bien tu proteína en 3 a 4 comidas al día en vez de comerla toda junta en la noche.
- Post-Workout Recovery Ratio (Carbohydrate + Protein Synergy): Pairing 1.0–1.2 g/kg carbohydrates with 20–40 g whole-food protein after exhaustive training replenishes glycogen and repairs myofibrillar damage simultaneously. En palabras sencillas: Combinar carbohidratos reales (fruta, avena, tortilla) con 20–40 g de proteína al terminar de entrenar para recargar energía y reparar el músculo.
- Pre-Sleep Slow-Digesting Protein (Overnight Recovery): A whole-food protein feeding before bed (e.g., Greek yogurt, cottage cheese, milk, or legumes) supports overnight muscle remodeling. En palabras sencillas: Una cena ligera o colación rica en proteína natural antes de dormir ayuda a que tus músculos se reparen mientras descansas.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Protein periodization is the strategic timing of dietary protein intake to optimize muscle remodeling and recovery. Muscles need roughly 0.25 to 0.40 grams of high-quality protein per kilogram of body mass per feeding to trigger growth. Spreading your protein across four or five balanced meals delivers far greater muscle repair than skewing intake into a single dinner.


#### En Palabras Sencillas (Norteño Context)

Repartir la proteína es como regar una parcela de alfalfa en el valle: si sueltas toda el agua en una hora encharcas la tierra, pero si la riegas por tandas el cultivo aprovecha todo el líquido. Si los términos técnicos se ponen pesados, concéntrate primero en alcanzar el umbral de leucina en cada comida.


### Muscle Protein Synthesis Kinetics, The Leucine Trigger, & 24-Hour Nitrogen Balance

Skeletal muscle remodeling is dictated by the net balance between Muscle Protein Synthesis (MPS) and Muscle Protein Breakdown (MPB). Simply hitting a total daily protein target is insufficient if distribution is skewed. Consuming 80% of daily protein at dinner triggers the intracellular "muscle-full" refractory threshold, oxidizing excess amino acids into urea while daytime tissues remain catabolic. Achieving optimal recovery requires periodizing protein into boluses of approximately Outcome 0.25: to 0.40 g/kg per feeding (~20 to 40g whole-food protein) containing at least Outcome 2.5: to 3.0g of leucine to activate the mTORC1 signaling pathway. In this lab, you will audit 24-hour protein pacing, evaluate anabolic resistance and renal urea excretion in Yuma desert heat, apply 2025–2030 Dietary Guidelines for Americans (DGA) and ACSM/ISSN standards, and execute a clinical AI simulation using Google Gemini.

En este laboratorio, auditará la distribución de proteína en 24 horas, evaluará la resistencia anabólica y la excreción renal de urea bajo el calor desértico de Yuma, aplicará las Pautas Dietéticas para Estadounidenses (DGA) 2025-2030 y los estándares ACSM/ISSN, y ejecutará una simulación clínica con Google Gemini.

- HLTH-150.7.1.AY26-27: Analyze the physiological mechanisms of Muscle Protein Synthesis (MPS), the leucine threshold, and 24-hour protein pacing in athletic and clinical populations. Analizar los mecanismos fisiológicos de la síntesis de proteínas musculares (MPS), el umbral de leucina y la distribución de proteína en 24 horas.
- HLTH-150.7.2.AY26-27: Design evidence-based daily protein distribution and whole-food recovery protocols aligned with ACSM and ISSN standards. Diseñar protocolos de distribución de proteína y recuperación basados en alimentos reales según las pautas de ACSM e ISSN.
- Module Window / Ventana del Módulo: Opens Tuesday, September 29, 2026, at 12:00 AM MST Abre el martes, 29 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 5, 2026, at 11:59 PM MST Lunes, 5 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Mastery Scale) Ponderación para laboratorios semanales y simulaciones clínicas

### Lab Objectives / Objetivos del Laboratorio

- Calculate per-meal protein targets ($g/kg$ and absolute grams) based on client body mass, age, and metabolic goals.
- Audit 24-hour dietary intake logs to identify skewed bolus feeding, failure to achieve the leucine trigger (~2.5 to 3.0g), and prolonged catabolic fasting windows.
- Structure a 24-hour protein periodization model prioritizing nutrient-dense whole foods (eggs, Greek yogurt, chicken, legumes, dairy) aligned with the 2025–2030 DGA.
- Execute a clinical AI simulation using Google Gemini and audit AI recommendations against ACSM/ISSN SSoT guidelines.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File structure

Fase 1: Seleccione su archivo de caso clínico (haga clic en la caja para copiar los datos delimitados)

Scenario: Older adult post-arthroplasty patient (Helena, 68) with quadriceps muscle atrophy, anabolic resistance, and severely skewed daytime protein intake.

Scenario: Plant-forward community educator (Mateo, 38) in Yuma County on a strict food budget, suffering from low protein intake and incomplete amino acid pairing.

Scenario: Collegiate track and field thrower (Derek, 22) consuming excessive protein in two massive boluses, resulting in GI distress and dehydration in desert heat.


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Paso 2: Copie la plantilla y consulte a Gemini para auditar el caso clínico bajo el protocolo Pattern / Rule / Solve

Paste your chosen Track data wrapped in triple-hashes (###) into Google Gemini, then paste this engineered prompt directly below it:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas (Solo Texto)

Type or paste your complete clinical audit directly into the Canvas text box structured under these five mandatory headings:

- Selected Track & Client Initials: State your chosen track, client initials, age, body mass, and primary clinical protein challenge.
- Part 1: Pattern Recognition (The Engine Audit): Critique the AI's physiological analysis. Identify daily distribution flaws, failure to hit the leucine threshold, and the physiological consequence of skewed intake.
- Part 2: Rule Application (SSoT Benchmark): Cite 2025–2030 DGA guidelines and ACSM/ISSN standards for per-meal protein dosing ($g/kg$), whole-food sourcing, and desert hydration safeguards.
- Part 3: Solving the Gap (Active Verification & Plan): Provide your corrected 24-hour protein pacing schedule across 3 to 5 feedings. In a mandatory 150-word text defense written in your own voice, justify why this distribution stimulates MPS and protects kidney function. Conclude with a 2-sentence bilingual coaching cue card in English and Spanish.
- Repository Verification: Confirm your prompt exchange is archived in Google Drive: EXW_Professional_AI_Repository / EXW150_M07_Protein_Audit.pdf .
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying your 24-hour protein distribution ($0.25\text{–}0.40\text{ g/kg/meal}$), leucine trigger ($2.5\text{–}3.0\text{ g}$), and DGA 2025–2030 whole-food pairing.

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

This high-fidelity exemplar illustrates the depth, mathematical precision, and clinical reasoning required for full mastery points.

Selected Track: Track 1 - Clinical & Chronic Disease Prevention Path (Client: Helena, 68 yrs, 65 kg)

Part 1: Pattern Recognition: Helena's current daily protein intake is severely skewed. At 60g total (0.92 g/kg), she consumes only 5g at breakfast and 10g at lunch, back-loading 45g at dinner. In older adults post-surgery, age-related anabolic resistance elevates the leucine trigger to at least 3.0g (~35–40mg/kg) per feeding to initiate mTORC1 phosphorylation. Helena fails this threshold for over 18 hours each day, resulting in net negative nitrogen balance, blunted myofibrillar protein synthesis, and continued quadriceps atrophy around her surgical knee.

Part 2: Rule Application (SSoT): Under the 2025–2030 Dietary Guidelines for Americans and ACSM/ISSN consensus statements, older clinical populations undergoing post-surgical rehabilitation require 1.2 to 1.5 g/kg/day of protein distributed evenly across meals. For Helena (65 kg), this equals 78 to 98g daily, structured as 25 to 30g of protein per meal, ensuring each feeding delivers at least 3.0g of leucine from nutrient-dense whole foods like dairy, eggs, and poultry.

Part 3: Solving the Gap (Active Verification): I restructured Helena's nutrition into four balanced feedings: Breakfast (7:30 AM): 3 scrambled eggs with 1 cup low-fat Greek yogurt (28g protein, 3.1g leucine). Lunch (12:30 PM): 3.5 oz grilled chicken breast over mixed greens and lentils (30g protein, 3.2g leucine). Afternoon Snack (4:00 PM): 1 cup low-fat cottage cheese with berries (24g protein, 2.7g leucine). Dinner (7:30 PM): 3.5 oz baked salmon with quinoa and broccoli (26g protein, 2.8g leucine). Total protein: 108g (1.66 g/kg), exceeding minimum targets without excessive caloric load. In Yuma's desert climate, increased urea synthesis requires concurrent hydration: she will consume 2.5 liters of water daily. Bilingual Client Instruction Card: "Eat a palm-sized portion of protein like eggs or Greek yogurt at every single meal to trigger continuous muscle repair in your knee. Drink water consistently throughout our hot desert days so your kidneys process nutrients smoothly." "Consuma una porción de proteína del tamaño de la palma de su mano, como huevos o yogur griego, en cada comida para reparar el músculo de su rodilla. Beba suficiente agua en nuestro clima desértico para que sus riñones procesen los nutrientes sin problema."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI diet plan that calculates only total daily protein grams misses the critical kinetics of 24-hour Muscle Protein Synthesis (MPS). When a client eats a 5-gram protein breakfast and a 95-gram steak dinner, they fail to cross the 2.5 to 3.0 gram leucine threshold all morning and afternoon, then oxidize the excess dinner amino acids into urea—accelerating fluid loss in Yuma's heat. By redistributing intake into four evenly spaced whole-food feedings of 0.30 g/kg (25–35 g protein each) under the 2025–2030 Dietary Guidelines, we trigger mTORC1 four separate times per day and protect hydration. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."

Repository Verification: Archived to EXW_Professional_AI_Repository / EXW150_M07_Protein_Audit.pdf


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 07 (Mod 07 Lab: Daily Protein Timing & Recovery Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 07 Práctica de Lab y Simulación: Proteína Dietética, MPS y Periodización Proteica

Auditoría de Síntesis de Proteínas Musculares, Umbral de Leucina y Distribución en 24 Horas


### En Palabras Sencillas: Guía de Navegación

Antes de leer los detalles técnicos, aquí está la versión corta: La periodización proteica es la distribución estratégica de la proteína en el día para reparar los músculos. El músculo necesita entre 0.25 y 0.40 gramos de proteína por kilo de peso en cada comida para activar el crecimiento. Repartir la proteína en cuatro o cinco comidas balanceadas funciona mucho mejor que comerse toda la porción en una sola cena.


#### Contexto Norteño Regional

Repartir la proteína es como regar una parcela de alfalfa en el valle: si sueltas toda el agua en una hora encharcas la tierra, pero si la riegas por tandas el cultivo aprovecha todo el líquido. Si los términos técnicos se ponen pesados, concéntrate primero en alcanzar el umbral de leucina en cada comida.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione uno de los tres escenarios clínicos (Ruta 1 Clínica: Helena 68 años posquirúrgica; Ruta 2 Comunitaria: Mateo 38 años educador a base de plantas; Ruta 3 Rendimiento Deportivo: Derek 22 años lanzador colegial). Copie el bloque con delimitadores ### y consulte a Gemini con la plantilla de auditoría.


### Fase 3: Requisitos de Entrega en Canvas (Solo Texto)

- Ruta Seleccionada e Iniciales del Cliente: Especifique su ruta y datos biométricos.
- Parte 1: Reconocimiento del Patrón: Audite el desbalance diario y el fallo del umbral de leucina.
- Parte 2: Aplicación de Reglas (DGA 2025-2030 / ACSM): Cite los estándares de dosificación por comida y fuentes reales de alimentos.
- Parte 3: Resolución de la Brecha y Tarjeta Bilingüe: Presente su horario de 24 horas y defensa clínica de 150 palabras con tarjeta bilingüe.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
- Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica su distribución proteica de 24 horas ($0.25\text{–}0.40\text{ g/kg/comida}$), el umbral de leucina ($2.5\text{–}3.0\text{ g}$) y el uso de alimentos reales según las DGA 2025–2030.

### Accesibilidad Universal (ARS)

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard). Para adaptaciones académicas, contacte a AccessABILITY Resource Services (ARS), Edificio 3C del Campus de Yuma: access@azwestern.edu .

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:

Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, concentrar casi toda la proteína en la cena desperdicia ventanas clave de síntesis proteica muscular (MPS) durante el día y eleva la carga renal de urea en el clima cálido de Yuma. Al repartir la ingesta en 4 comidas reales de 25 a 35 g de proteína (2.5–3.0 g de leucina por toma) bajo las Pautas DGA 2025–2030, estimulamos la reparación muscular de forma continua y segura."

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 07)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 07)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
