## HLTH-150: Mod 07 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 07) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 07 Discussion: Protein Timing for Muscle Repair


### Protein Pacing, The Leucine Trigger & Muscle Remodeling

Skeletal muscle recovery and hypertrophy depend not only on total daily protein intake, but critically on protein distribution and amino acid quality . Due to the "muscle-full" effect, consuming massive amounts of protein in a single meal leads to oxidation of surplus amino acids rather than enhanced Muscle Protein Synthesis (MPS). To maximize 24-hour muscle remodeling, athletes and clinical populations must strategically pace protein intake into feedings that reach the leucine trigger (~2.5 to 3.0g leucine) . Select your Build Your Own Journey Track below, audit a real-world protein distribution case using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / U.S. Dietary Guidelines / ACSM & ISSN Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #150-07

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Sarcopenia prevention, anabolic resistance, post-surgical muscle recovery, and leucine threshold auditing in older adults.

Focus: Plant-based complementary protein pairing, budget-conscious whole-food pacing, and DGA adherence for working families.

Focus: Protein pacing, "muscle-full" effect resolution, leucine trigger maximization, and pre-sleep casein recovery in strength athletes.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Protein Metrics / Ruta y Métricas de Proteína: State your chosen track and report the client's current total protein intake (grams and g/kg), noting their mealtime distribution and whether each meal clears the leucine threshold (~2.5g). Indique la ruta seleccionada y reporte la ingesta proteica actual (gramos y g/kg), evaluando la distribución en las comidas y el umbral de leucina (~2.5 g).
- Clinical Framing Protocol (Pattern / Rule / Solve) Analysis (Pattern / Rule / Solve) / Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Explain why skewed intake or inadequate leucine compromises muscle recovery due to the "muscle-full" effect (Pattern), cite federal/ACSM protein dosing standards (Rule), and provide the specific 4- to 5-meal protein pacing schedule with whole foods (Solve). Explique por qué una distribución desigual o falta de leucina limita la recuperación por el efecto de saturación muscular (Patrón), cite las pautas ACSM/USDA (Regla) y detalle el horario de 4 a 5 comidas con alimentos reales (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence explanation of the protein pacing and whole-food recovery plan in both English and Spanish so your client can execute it easily. Proporcione una explicación concisa de 2 oraciones sobre la distribución de proteína y recuperación en inglés y español para que su cliente la aplique fácilmente.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 2 Replies Required). Evaluate their protein pacing math, compare leucine thresholds, and discuss how protein strategies must adapt across clinical, community, and strength athletic settings in Yuma.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Athlete D.K. consumes 216g of protein daily on a 90.0 kg body mass (2.40 g/kg/day), which exceeds the ACSM strength guideline (1.6–2.2 g/kg). However, his intake is heavily skewed across only two meals (0g breakfast, 96g lunch, 120g dinner). Due to the physiological "muscle-full" effect, muscle protein synthesis (MPS) is only stimulated twice per 24 hours. The remaining ~130g of surplus protein ingested in those two massive sittings is largely oxidized for energy or converted to urea, failing to accelerate muscle recovery and contributing to his chronic muscle soreness (DOMS).

Rule Application (ACSM / ISSN Standards): According to ACSM and International Society of Sports Nutrition (ISSN) guidelines, optimal muscle hypertrophy and tissue remodeling occur when protein is periodized into Outcome 0.30: to 0.40 g/kg per meal (27g to 36g for a 90 kg athlete) every 3 to 5 hours, with each bolus providing at least 2.5g to 3.0g of leucine to trigger the mTORC1 pathway. Additionally, consuming 30g to 40g of slow-digesting protein pre-sleep sustains overnight amino acid availability.

Solve (Protein Pacing Prescription): We redistribute D.K.'s protein intake into a structured 5-feeding schedule totaling 175g/day (1.94 g/kg/day), cutting unnecessary powder waste while stimulating MPS four separate times throughout the day and overnight:

- Meal 1 (Breakfast - 7:30 AM): 3 whole eggs + 1 cup egg whites with oatmeal & berries (~35g protein, ~3.0g leucine).
- Meal 2 (Lunch - 12:00 PM): 6 oz grilled chicken breast with brown rice, black beans, and avocado (~40g protein, ~3.2g leucine).
- Meal 3 (Post-Workout - 4:30 PM): 1 scoop whey isolate blended with banana and 12 oz skim milk (~35g protein, ~3.5g leucine).
- Meal 4 (Dinner - 7:30 PM): 6 oz lean beef or salmon with sweet potato and roasted vegetables (~35g protein, ~2.8g leucine).
- Meal 5 (Pre-Sleep - 10:30 PM): 1.5 cups Greek yogurt or cottage cheese with walnuts (~30g slow-digesting casein protein, ~2.7g leucine).
EN: "Spread your protein into 35-gram meals every 3 to 4 hours and enjoy Greek yogurt before bed to rebuild your muscles all day and night."

ES: "Divida su proteína en comidas de 35 gramos cada 3 a 4 horas y consuma yogur griego antes de dormir para reparar sus músculos día y noche."


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 07 (Mod 07 Discussion: Protein Timing for Muscle Repair)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 07 Foro de Discusión: Proteína Dietética, MPS y Recuperación


### Distribución de Proteína, Umbral de Leucina y Remodelación Muscular

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar la ingesta y distribución de proteína según las pautas federales y de nutrición deportiva.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Reporte los gramos totales de proteína y la proporción en g/kg del cliente, evaluando si cada comida alcanza el umbral de leucina (~2.5 g).


#### Parte 2: Aplicación de Reglas (Pautas ACSM / ISSN / USDA)

Explique el efecto de saturación muscular y justifique la necesidad de distribuir 0.30 a 0.40 g/kg por comida cada 3 a 5 horas.


#### Parte 3: Resolución de la Brecha (Plan de Distribución y Tarjeta Bilingüe)

Diseñe un horario estructurado de 4 a 5 comidas ricas en alimentos integrales y proporcione una tarjeta de instrucciones en inglés y español.


### Modelo de Respuesta de Alta Fidelidad 10/10

El atleta D.K. consume 216 g de proteína al día para un peso de 90 kg (2.40 g/kg/día). Aunque el total supera las pautas ACSM, su ingesta está concentrada en solo dos comidas masivas (0 g desayuno, 96 g almuerzo, 120 g cena). Debido al efecto de saturación muscular, la síntesis de proteínas (MPS) solo se activa dos veces al día, mientras que los ~130 g restantes se oxidan sin generar mayor recuperación muscular.

Las pautas de ACSM e ISSN recomiendan periodizar la proteína en dosis de Outcome 0.30: a 0.40 g/kg por comida (27 a 36 g para 90 kg) cada 3 a 5 horas, asegurando 2.5 a 3.0 g de leucina por toma para activar la vía mTORC1, además de 30 a 40 g de caseína antes de dormir para la recuperación nocturna.

Horario de Distribución (175 g totales / 1.94 g/kg): Desayuno (35 g con huevos y avena), Almuerzo (40 g con pollo y frijoles negros), Post-entrenamiento (35 g con suero de leche y fruta), Cena (35 g con carne magra y camote) y Antes de dormir (30 g con yogur griego). Tarjeta de Instrucción Bilingüe: "Divida su proteína en comidas de 35 gramos cada 3 a 4 horas y consuma yogur griego antes de dormir para reparar sus músculos día y noche."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 07)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 07)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
