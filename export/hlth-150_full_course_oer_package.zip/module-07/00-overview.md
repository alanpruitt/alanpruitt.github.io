## HLTH-150 (Module 07 Overview): Nutrition for Exercise & Sport: Performance Nutrition & Dietary Guidelines

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 07 Overview: Protein Timing & Post-Workout Muscle Recovery


### Welcome to Module 07: Protein Timing & Post-Workout Muscle Recovery

Welcome to Week 7! This week, we examine the fundamental metabolic pathways that convert dietary macronutrients into mechanical energy (ATP). Before evaluating advanced nutrient timing or dietary supplements, sports nutrition practitioners must master how human energy pathways function across varying intensities and durations of physical activity.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify exercise fuel depletion patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) metabolic concepts alongside Dietary Guidelines for Americans (DGA) macronutrient distribution baselines, and solve real-world fueling challenges across diverse populations.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 29, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 1, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 4, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 5, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 07 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Distinguish the three primary metabolic energy systems (ATP-PCr, anaerobic glycolysis, and oxidative phosphorylation) and identify physiological fuel shift patterns during exercise of varying intensities. Distinguir los tres sistemas metabólicos principales (ATP-PCr, glucólisis anaeróbica y fosforilación oxidativa) e identificar patrones de cambio de combustible durante el ejercicio.
- CLO 2 (Rule Application): Apply PAGA 2018 metabolic equivalent (MET) intensity classifications and DGA Acceptable Macronutrient Distribution Ranges (AMDR) to evaluate substrate utilization and the crossover concept. Aplicar las clasificaciones de intensidad MET de PAGA 2018 y los rangos de distribución de macronutrientes de las DGA para evaluar la utilización de sustratos y el concepto de cruce metabólico.
- CLO 3 (Problem Solving): Formulate an evidence-based whole-food fueling prescription that sustains target metabolic pathways for clinical, community, and athletic populations without reliance on commercial energy stimulants. Formular una prescripción nutricional basada en alimentos integrales que optimice las vías metabólicas para poblaciones clínicas, comunitarias y deportivas sin depender de estimulantes comerciales.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Metabolic flexibility, impaired glucose oxidation in metabolic syndrome/Type 2 diabetes, and prescribing low-intensity fat oxidation exercise for clinical recovery.

Sustained aerobic energy expenditure among agricultural and manual labor workers in Yuma County, preventing glycogen depletion, and affordable whole-food fuel sources.

Substrate crossover dynamics during high-intensity interval training (HIIT) vs. endurance racing, glycogen sparing strategies, and bioenergetic efficiency.


### Module 07 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Human Bioenergetics, Substrate Oxidation & Federal Guidelines
- Discussion Board: Analyzing Fuel Utilization & The Crossover Concept
- Lab Assignment: Metabolic Pathway Audit, Energy Calculation & Gemini AI Simulation
- Knowledge Check & Module Summary

### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 07 (Mod 07 Overview: Protein Timing & Post-Workout Muscle Recovery)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 07 Visión General: Metabolismo Energético y Sistemas de Combustible en el Ejercicio


### Bienvenido al Módulo 07: Bioenergética, Utilización de Sustratos y Vías Metabólicas

¡Bienvenido a la Semana 7! Esta semana examinamos las vías metabólicas fundamentales que transforman los macronutrientes de la dieta en energía mecánica (ATP). Antes de evaluar la sincronización avanzada de nutrientes o los suplementos, es esencial dominar cómo funcionan los sistemas energéticos del cuerpo según la intensidad y duración de la actividad física.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará patrones de agotamiento de combustible en el ejercicio, aplicará los conceptos metabólicos de las pautas federales PAGA 2018 (2.ª ed.) y las Guías Alimentarias para los Estadounidenses (DGA) , y resolverá retos nutricionales reales en diversas poblaciones.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Distinguir los tres sistemas energéticos principales (ATP-PCr, glucólisis anaeróbica y fosforilación oxidativa) e identificar los patrones de utilización de sustratos durante el ejercicio a diferentes intensidades.
- CLO 2 (Regla): Aplicar las clasificaciones de intensidad MET de PAGA 2018 y los rangos de distribución de macronutrientes (AMDR) de las DGA para evaluar el concepto de cruce de combustibles (carbohidratos vs. grasas).
- CLO 3 (Solución): Diseñar una estrategia de alimentación basada en alimentos integrales que optimice las vías metabólicas para poblaciones clínicas, comunitarias y deportivas sin depender de estimulantes comerciales.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, continuará trabajando dentro de la ruta profesional que haya seleccionado:

Flexibilidad metabólica, oxidación alterada de glucosa en síndrome metabólico/diabetes tipo 2 y prescripción de ejercicio de baja intensidad para oxidar grasas en la recuperación clínica.

Gasto energético aeróbico sostenido en trabajadores agrícolas y manuales del condado de Yuma, prevención del agotamiento de glucógeno y fuentes accesibles de alimentos reales.

Dinámica del cruce de sustratos durante el entrenamiento en intervalos de alta intensidad (HIIT) frente a pruebas de resistencia, ahorro de glucógeno y eficiencia bioenergética.


### Ruta de Aprendizaje del Módulo 07

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Bioenergética Humana, Oxidación de Sustratos y Normas Federales
- Foro de Discusión: Análisis de la Utilización de Combustibles y el Concepto de Cruce
- Práctica de Laboratorio: Auditoría de Vías Metabólicas, Cálculo Energético y Simulación con IA
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.2 AA (9:1 Double-Contrast Guard). Esta estructura es responsiva en dispositivos móviles, compatible con lectores de pantalla y diseñada para un acceso equitativo.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 07 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 07 Required Readings: Protein Timing & Post-Workout Muscle Recovery →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 07 Discussion: Protein Timing for Muscle Repair →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 07 Coaching Sprint: Post-Workout Recovery Meals →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 07 Lab: Daily Protein Timing & Recovery Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 07 Summary & Wrap-Up: Protein Timing & Post-Workout Muscle Recovery →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 07)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 07)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
