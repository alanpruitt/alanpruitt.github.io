## HLTH-150: Mod 08 Required Readings Sweat Rate Calculations And Desert Heat Safety

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 08 Required Readings: Sweat Rate Calculations & Desert Heat Safety

Lecturas Obligatorias: Fisiología de Hidratación, Termorregulación y Balance Hídrico


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Sweat-rate math measures exact fluid loss per hour so you can build personalized desert hydration and sodium plans. By weighing a client before and after training and accounting for drink volume, you calculate hourly sweat loss in liters. Accurate sweat math prevents both dehydration and over-drinking plain water (hyponatremia).


#### En Palabras Sencillas (Norteño Context)

En el calor seco de Yuma, el sudor se evapora tan rápido que ni cuenta te das de cuántos litros perdiste hasta que te pesas. Si los términos técnicos se ponen pesados, concéntrate primero en la fórmula de tasa de sudoración por hora y la reposición del 125% al 150% del líquido perdido.


### Regional Focus: Fluid Dynamics in the Sonoran Desert

Enfoque Regional: Dinámica de Fluidos y Estrés Térmico en el Desierto de Sonora

In Yuma County and the lower Colorado River basin, ambient temperatures regularly exceed 105°F to 115°F with dry air that accelerates flash-evaporative cooling. Under these arid conditions, sweat evaporates off the skin surface almost instantly, frequently masking significant fluid and electrolyte deficits among athletes, agricultural workers, and tactical personnel. Mastering fluid replacement balance is a mandatory clinical and occupational safety baseline in our community.

En el condado de Yuma y la cuenca baja del río Colorado, las temperaturas superan constantemente los 40°C a 46°C con aire seco que acelera la evaporación instantánea del sudor. Esta condición oculta el déficit rápido de agua y electrolitos en deportistas, trabajadores agrícolas y personal de campo. Dominar la reposición de líquidos es una prioridad fundamental de salud clínica y laboral en nuestra comunidad.


### Reading 1: Thermoregulatory Physiology & Dehydration Limits

Lectura 1: Fisiología Termorreguladora y Límites Críticos de Deshidratación


#### Step 1: Evaporative Cooling and Cardiovascular Drift

Enfriamiento por Evaporación y Deriva Cardiovascular

Skeletal muscle contraction operates at only 20% to 25% mechanical efficiency, converting the remaining 75% to 80% of metabolized energy into internal heat. To dissipate this heat load and protect central core temperature (less than 104°F / 40°C), the autonomic nervous system routes blood flow to peripheral dermal capillaries and stimulates eccrine sweating. Prolonged sweating without fluid replacement shrinks circulating plasma volume, decreasing venous return and stroke volume. To sustain cardiac output, heart rate climbs steadily at an unchanged workload—a physiological state termed Cardiovascular Drift .

La contracción muscular opera con solo un 20% a 25% de eficiencia mecánica, disipando del 75% al 80% de la energía como calor interno. Para proteger la temperatura central (menos de 40°C), el sistema nervioso autónomo activa el flujo sanguíneo cutáneo y estimula las glándulas ecrinas. La sudoración continua sin reposición reduce el volumen plasmático, disminuyendo el retorno venoso y el volumen sistólico. Para mantener el gasto cardíaco, la frecuencia cardíaca aumenta progresivamente a una misma intensidad de trabajo (Deriva Cardiovascular).


#### Step 2: Body Mass Loss Thresholds (PAGA 2018 SSoT)

Umbrales de Pérdida de Masa Corporal (SSoT PAGA 2018)

In alignment with the Physical Activity Guidelines for Americans (PAGA 2018) and clinical exercise science baselines:

De acuerdo con las Pautas de Actividad Física para los Estadounidenses (PAGA 2018) y los estándares clínicos de las ciencias del ejercicio:

- ≤ 1.0% Body Mass Loss: Well tolerated; negligible impact on cellular bioenergetics or thermal strain. ≤ 1.0% de pérdida de masa corporal: Bien tolerado; impacto insignificante en la bioenergética celular o el estrés térmico.
- > 2.0% Body Mass Loss: Critical clinical threshold. Core temperature elevates 0.2°C to 0.3°C per additional 1% lost, aerobic working capacity decreases by 10% to 20%, and rating of perceived exertion (RPE) rises sharply. > 2.0% de pérdida de masa corporal: Umbral clínico crítico. La temperatura central sube de 0.2°C a 0.3°C por cada 1% adicional perdido, la capacidad de trabajo aeróbico cae del 10% al 20% y el esfuerzo percibido (RPE) se dispara.
- ≥ 5.0% Body Mass Loss: Dangerous state presenting severe risk for heat syncope, cognitive impairment, heat exhaustion, and exertional heat stroke. ≥ 5.0% de pérdida de masa corporal: Estado de alto peligro con riesgo grave de síncope por calor, deterioro cognitivo, agotamiento por calor y golpe de calor por esfuerzo.

### Reading 2: Sweat Rate Auditing & Osmoregulation

Lectura 2: Cálculo de Sudoración, Osmorregulación e Hiponatremia


#### Step 1: Empirical Sweat Rate Formulation

Fórmula Empírica de la Tasa de Sudoración

Sweat rates range from 0.5 L/hr to over 2.5 L/hr depending on environmental temperature, metabolic work rate, and heat acclimatization. Hydration planning requires individualized mass-balance calculations:

Las tasas de sudoración varían entre 0.5 L/h y más de 2.5 L/h según la temperatura ambiental, la intensidad metabólica y la aclimatación al calor. La planificación hídrica exige cálculos individualizados de balance de masa:

*Mass Balance Rule: 1.0 kg of acute body mass lost = 1.0 Liter of net fluid deficit (1.0 lb ≈ 16 oz or ~475 mL).

*Regla de Balance de Masa: 1.0 kg de peso corporal perdido = 1.0 Litro de déficit neto de líquido (1.0 lb ≈ 16 oz o ~475 mL).


#### Step 2: Exercise-Associated Hyponatremia (EAH)

Hiponatremia Asociada al Ejercicio (HAE)

EAH occurs when serum sodium drops below 135 mmol/L. While dehydration is a loss of water volume, EAH is predominantly caused by over-drinking plain, hypotonic fluids (water) well past sweat losses. Diluting extracellular sodium disrupts osmoregulation and drives intracellular water movement, creating risk for cerebral edema (brain swelling). Sodium replacement (300 to 600 mg/hr or whole-food snacks) is critical during continuous exertion lasting more than two hours in severe heat.

La HAE ocurre cuando el sodio sérico desciende por debajo de 135 mmol/L. Mientras que la deshidratación es una pérdida de volumen hídrico, la HAE es causada predominantemente por beber líquidos hipotónicos (agua simple) en exceso superando con creces las pérdidas de sudor. Diluir el sodio extracelular altera la osmorregulación e induce la entrada de agua a las células, generando riesgo crítico de edema cerebral. La reposición de sodio (300 a 600 mg/h o mediante alimentos reales) es indispensable en esfuerzos continuos de más de dos horas en calor intenso.


### Reading 3: Practical Hydration Protocols & Rehydration

Lectura 3: Protocolos Prácticos de Hidratación y Rehidratación

Structured fluid planning addresses three distinct phases using whole foods and standard beverage solutions:

La planificación estructurada de fluidos aborda tres fases específicas utilizando alimentos integrales y soluciones comunes:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Acute weight changes over short exercise durations are almost entirely due to water loss through sweat and respiration, rather than tissue oxidation. Pre- and post-exercise mass measurement provides an immediate, accurate assessment of net dehydration deficit.

Respuesta en Español: Las fluctuaciones agudas de peso en períodos cortos de ejercicio se deben casi exclusivamente a la pérdida de agua por sudoración y respiración, y no a la oxidación de tejidos. Medir el peso antes y después aporta una evaluación inmediata y exacta del déficit de deshidratación.

English Response: Ingesting hypotonic fluids in excess of sweat rate causes Exercise-Associated Hyponatremia (EAH) by diluting vascular sodium levels below 135 mmol/L. This osmotic imbalance forces fluid into tissues, creating danger of cerebral edema and respiratory distress.

Respuesta en Español: Ingerir líquidos hipotónicos en exceso respecto al sudor causa Hiponatremia Asociada al Ejercicio (HAE) al diluir el sodio vascular por debajo de 135 mmol/L. Este desbalance osmótico empuja el agua hacia el interior de los tejidos, creando riesgo grave de edema cerebral y dificultad respiratoria.

English Response: Rehydrating simply to 100% of body mass deficit fails to restore euhydration because ongoing obligate renal filtration (urine production) and residual post-exercise sweating continue to expel fluid during the recovery window.

Respuesta en Español: Rehidratarse solo al 100% del déficit no restablece el estado de euhidratación debido a que la filtración renal obligatoria (producción de orina) y la sudoración residual posterior al ejercicio continúan eliminando líquidos durante la ventana de recuperación.


### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 08 (Mod 08 Required Readings: Sweat Rate Calculations & Desert Heat Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 08 Síntesis en Español: Cálculo de Tasa de Sudoración y Seguridad ante el Calor del Desierto

En el clima extremo del condado de Yuma, una pérdida $\ge 2.0\%$ del peso corporal por sudor compromete la termorregulación y el gasto cardíaco. Calcule la tasa de sudoración por hora ($\text{L/hr}$) pesando antes y después de la actividad y reponga de $16\text{–}24\text{ oz}$ ($500\text{–}750\text{ mL}$) de agua por cada libra perdida ($125\%\text{–}150\%$) acompañada de sodio y potasio provenientes de alimentos reales según las Pautas DGA 2025–2030 .

HLTH-150 • Module 08 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 08:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 08)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 08)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
