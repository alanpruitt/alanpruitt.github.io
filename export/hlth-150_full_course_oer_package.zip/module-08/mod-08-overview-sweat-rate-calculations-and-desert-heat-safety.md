# HLTH-150: Mod 08 Overview Sweat Rate Calculations And Desert Heat Safety

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 08 Overview: Sweat Rate Calculations & Desert Heat Safety


### Welcome to Module 08: Sweat Rate Calculations & Desert Heat Safety

Welcome to Week 8! This week, we examine the physiological mechanisms governing fluid balance, electrolyte homeostasis, and thermoregulation during exercise. In high-heat environments like Yuma County and the Sonoran Desert, managing hydration is a critical health and safety imperative for athletes, agricultural professionals, and clinical populations alike.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify fluid loss patterns and sweat rates, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety baselines alongside Dietary Guidelines for Americans (DGA) fluid recommendations, and design individualized hydration protocols to prevent both dehydration and Exercise-Associated Hyponatremia (EAH).


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 6, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 8, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 11, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 12, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 08 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Quantify individual sweat rates, distinguish signs of voluntary dehydration versus overhydration, and identify cardiovascular drift patterns during exercise in extreme heat. Cuantificar la tasa de sudoración individual, distinguir signos de deshidratación frente a sobrehidratación e identificar la deriva cardiovascular durante el ejercicio en calor extremo.
- CLO 2 (Rule Application): Apply PAGA 2018 and DGA fluid baselines, the 2.0% body mass deficit threshold, and electrolyte replacement standards (sodium and potassium) to prevent exertional heat illness and Exercise-Associated Hyponatremia (EAH). Aplicar las pautas de PAGA 2018 y DGA, el umbral del 2.0% de déficit de masa corporal y los estándares de reposición de electrolitos para prevenir golpes de calor e hiponatremia.
- CLO 3 (Problem Solving): Formulate an evidence-based, whole-food and fluid replacement prescription customized for diverse occupational, clinical, and athletic populations exercising in hot desert climates. Formular una prescripción de reposición de líquidos y electrolitos adaptada a poblaciones laborales, clínicas y deportivas en climas cálidos y desérticos.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Hydration management in renal and cardiovascular patients, diuretic interactions, and preventing orthostatic hypotension and electrolyte imbalances during physical therapy.

Occupational heat stress, OSHA hydration compliance for agricultural harvesters in Yuma County, and affordable community-level electrolyte replenishment.

Pre-hydration loading protocols, intra-event hypotonic/isotonic fluid pacing, post-workout rehydration factors (125-150% volume replacement), and cramping mitigation.


### Module 08 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Thermoregulation, Sweat Rate Formulation & Fluid Safety
- Discussion Board: Dehydration Risk vs. Exercise-Associated Hyponatremia (EAH)
- Lab Assignment: Sweat Rate Calculation, Environmental Stress Auditing & Gemini AI Tool Kit
- Knowledge Check & Module Summary

### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 08 (Mod 08 Overview: Sweat Rate Calculations & Desert Heat Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 08 Visión General: Dinámica de Hidratación y Termorregulación


### Bienvenido al Módulo 08: Balance de Líquidos, Osmorregulación y Seguridad Térmica

¡Bienvenido a la Semana 8! Esta semana examinamos los mecanismos fisiológicos que regulan el equilibrio hídrico, la homeostasis de electrolitos y la termorregulación durante el ejercicio. En regiones de calor extremo como el condado de Yuma y el desierto de Sonora, el manejo adecuado de la hidratación es indispensable para la salud y la seguridad de atletas, trabajadores del campo y poblaciones clínicas.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará patrones de pérdida de líquidos y tasas de sudoración, aplicará los estándares de seguridad de las pautas federales PAGA 2018 (2.ª ed.) y las Guías Alimentarias (DGA) , y diseñará planes de hidratación individualizados para prevenir la deshidratación y la hiponatremia asociada al ejercicio (HAE).


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Cuantificar la tasa de sudoración individual, diferenciar la deshidratación de la sobrehidratación e identificar los patrones de deriva cardiovascular durante el esfuerzo físico en calor extremo.
- CLO 2 (Regla): Aplicar las normas de fluidos de PAGA 2018 y DGA, el umbral clínico del 2.0% de déficit de masa corporal y los estándares de sodio y potasio para evitar enfermedades por calor e hiponatremia.
- CLO 3 (Solución): Diseñar una prescripción de reposición hídrica y de electrolitos con alimentos y bebidas integrales, personalizada para trabajadores, atletas o pacientes en climas desérticos.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, continuará trabajando dentro de la ruta profesional que haya seleccionado:

Control de hidratación en pacientes renales y cardiovasculares, interacciones con diuréticos y prevención de hipotensión ortostática y desequilibrio electrolítico en terapia física.

Estrés térmico ocupacional, cumplimiento de normas de hidratación OSHA para jornaleros agrícolas en el condado de Yuma y alternativas accesibles de electrolitos.

Protocolos de carga pre-hidratación, ritmo de ingesta de líquidos isotónicos/hipotónicos durante la prueba, reposición post-ejercicio (125-150% del peso perdido) y control de calambres.


### Ruta de Aprendizaje del Módulo 08

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Termorregulación, Formulación de Sudor y Seguridad Hídrica
- Foro de Discusión: Riesgo de Deshidratación vs. Hiponatremia Asociada al Ejercicio (HAE)
- Práctica de Laboratorio: Cálculo de Tasa de Sudor, Auditoría Ambiental y Caja de Herramientas de IA
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA. Esta estructura es responsiva en dispositivos móviles, compatible con lectores de pantalla y diseñada para un acceso equitativo.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 08 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 08 Required Readings: Sweat Rate Calculations & Desert Heat Safety →
- Step 2 — Complete the Student Course Evaluation (Paso 2 — Evaluación del Curso): Mod 08: Midterm Student Course Evaluation →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 08 Coaching Sprint: Practical Hydration & Heat Safety Check →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 08 Lab: Sweat Rate & Heat Safety Calculation →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 08 Summary & Wrap-Up: Sweat Rate Calculations & Desert Heat Safety →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
