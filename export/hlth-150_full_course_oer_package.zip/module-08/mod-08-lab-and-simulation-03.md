## HLTH-150: Mod 08 Lab And Simulation 03

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 08 Coaching Sprint Simulation: Practical Hydration & Heat Safety Check

Sesión de Coaching del Módulo 08: Verificación Práctica de Hidratación y Seguridad ante el Calor


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Waiting until you feel thirsty in Yuma's desert heat means you are already dehydrated by nearly 2% of your body weight. In this 3-minute Coaching Sprint, you will use pre- and post-activity scale weights, urine color checks, and the $16 ext{–}24 ext{ oz/lb}$ replacement rule alongside whole-food electrolytes to keep your client safe from heat exhaustion and hyponatremia.

En Palabras Sencillas (Contexto Norteño): En el calorón de Yuma, si esperas a tener sed para tomar agua, ya llevas casi un 2% de deshidratación encima. Si los términos técnicos se ponen pesados, concéntrate primero en pesar antes y después del esfuerzo, reponer de 16 a 24 onzas de agua por cada libra perdida y acompañar el agua con sodio y potasio de comida real.

- Whole-Body Sweat Rate Formula (L/hr): Calculated as ((Pre-Exercise Weight − Post-Exercise Weight in kg) + Fluid Consumed in L − Urine Volume) ÷ Exercise Duration in hours. En palabras sencillas: Restar tu peso antes y después de entrenar más el agua que tomaste para saber exactamente cuántos litros por hora estás sudando en el calor.
- Yuma Thermal Evaporative Demand (100°F–115°F+): In extreme desert heat, sweat rates frequently reach 1.0–2.5 L/hr, requiring scheduled cooling breaks and pre-planned fluid stations. En palabras sencillas: En el verano de Yuma puedes sudar de 1 a más de 2 litros por hora; no basta tomar agua solo cuando sientes sed.
- Gastric Emptying Limit (~1.0–1.2 L/hr Maximum): The human stomach can empty only ~1.0–1.2 L/hr during exercise; chugging massive volumes at once causes bloating rather than faster rehydration. En palabras sencillas: El estómago solo absorbe alrededor de un litro por hora; es mejor tomar tragos constantes cada 15–20 minutos que empinarse toda la botella de golpe.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica


```text
STRUCTURAL_DELIMITER_BOUND_1 ###:
[TRACK]: Track 1 - Clinical & Outpatient Wellness Path
[CLIENT]: Don Arturo, Age 69 (Yuma, AZ; blunted thirst mechanism; morning garden & walking routine in 98°F weather)
[BIOMETRICS]: Pre-walk weight: 175.0 lbs; Post-walk weight: 172.5 lbs (-2.5 lbs = 1.43% loss); Urine color: 6/8 (dark amber); drank only 8 oz plain water.
[GOAL]: Calculate his 16-24 oz/lb replacement target (40-60 oz) and pair with DGA 2025-2030 water-rich whole foods.
STRUCTURAL_DELIMITER_BOUND_1 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_2 ###:
[TRACK]: Track 2 - Occupational & Community Health Path
[CLIENT]: Marisol, Age 36, Harvest Crew Leader (San Luis / Yuma, AZ; 4-hour morning shift in 103°F heat)
[BIOMETRICS]: Drinks 120 oz of plain distilled water rapidly with zero food or sodium; develops headache, nausea, bloating, and muscle twitching (dilutional hyponatremia risk).
[GOAL]: Audit plain-water overconsumption without electrolytes and design a DGA 2025-2030 whole-food sodium/potassium + paced fluid schedule.
STRUCTURAL_DELIMITER_BOUND_2 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_3 ###:
[TRACK]: Track 3 - Sports Performance & Tactical Path
[CLIENT]: Jaden, Age 20, AWC Matador Football Linebacker (Yuma, AZ; 90-minute afternoon turf practice at 105°F)
[BIOMETRICS]: Pre-practice weight: 220.0 lbs; Post-practice weight: 215.0 lbs (-5.0 lbs = 2.27% dehydration); white salt crust on jersey.
[GOAL]: Calculate his 80-120 oz (2.4-3.6 L) post-practice replacement window and whole-food sodium/potassium recovery meal before tomorrow's session.
STRUCTURAL_DELIMITER_BOUND_3 ###:
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Consulta de IA


### Phase 3: Canvas Text Box Submission

- Chosen Track & Hydration Pattern: State your track and quantify the % body-mass sweat loss or electrolyte imbalance.
- Rule Application (DGA 2025–2030 & Sweat Math): State the $16 ext{–}24 ext{ oz/lb}$ replacement target ($125\% ext{–}150\%$ of sweat lost) and whole-food sodium/potassium rules.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why objective scale weight and whole-food electrolytes beat relying on thirst alone or sugary sports drinks in Yuma's heat.
- My Memorable Coaching Takeaway: Write your favorite 1-sentence hydration takeaway in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository / EXW_150_M08_Quiz_Sprint.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

- Chosen Track & Hydration Pattern: Track 3 (Jaden, Age 20, AWC Linebacker, Yuma, AZ). Jaden lost $5.0 ext{ lbs}$ ($220.0 ightarrow 215.0 ext{ lbs} = 2.27\%$ body mass) during a 90-minute $105^\circ ext{F}$ turf practice, exceeding the $\ge 2\%$ dehydration threshold that reduces plasma volume, elevates core temperature, and impairs cardiac stroke volume, with heavy sodium loss visible on his jersey.
- Rule Application (DGA 2025–2030 & Sweat Math): Replacing $16 ext{–}24 ext{ oz}$ per pound lost requires $80 ext{–}120 ext{ oz}$ ($2.4 ext{–}3.6 ext{ L}$) of fluid over the next 2–4 hours, paired with whole-food sodium and potassium sources under the 2025–2030 Dietary Guidelines for Americans so the kidneys retain the fluid rather than excreting dilute urine.
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, telling a 220-pound Yuma football player to 'just drink when thirsty' or chug plain water after losing 5 pounds of salty sweat is a recipe for heat exhaustion or muscle cramping before tomorrow's practice. Thirst lags behind physiological dehydration, and drinking 100 ounces of plain water without sodium dilutes extracellular plasma osmolarity and triggers urine output before intracellular rehydration is complete. By weighing Jaden pre- and post-practice, we prescribe 100 ounces of paced cool water paired with salted lean beef or chicken tacos on corn tortillas, pinto beans, and avocado—restoring water, sodium, and potassium through real food. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."
- My Memorable Coaching Takeaway: EN: "In Yuma's desert heat, the scale never lies—replace every pound of sweat lost with 16 to 24 ounces of water and real-food electrolytes!" ES: "¡En el calor de Yuma la báscula no miente: repón cada libra de sudor perdida con 16 a 24 onzas de agua y electrolitos de comida real!"
- Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M08_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 08 (Mod 08 Coaching Sprint: Practical Hydration & Heat Safety Check)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 08 Simulación de Coaching: Verificación Práctica de Hidratación y Seguridad ante el Calor

- Ruta y Patrón Hídrico: Indique su ruta y calcule el porcentaje de pérdida de peso por sudor o riesgo de hiponatremia.
- Regla DGA 2025–2030 ($16 ext{–}24 ext{ oz/lb}$): Calcule las onzas exactas de reposición hídrica y los electrolitos de alimentos reales.
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica por qué el pesaje objetivo y los electrolitos de alimentos reales superan a guiarse solo por la sed en Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su frase en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository / EXW_150_M08_Quiz_Sprint.pdf .
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 08 Quick Return Navigation / Regreso Rápido al Módulo 08:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 08)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 08)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
