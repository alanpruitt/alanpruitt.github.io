## HLTH-150: Mod 08 Summary And Wrap Up Sweat Rate Calculations And Desert Heat Safety

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 08 Summary & Wrap-Up: Sweat Rate Calculations & Desert Heat Safety

Precisión en la Hidratación, Tasas de Sudoración y Prevención de Hiponatremia en Climas Áridos


### Step 1: Core Fluid Dynamics & Thermoregulation Synthesis

Congratulations on completing Module 08! You have successfully mastered the physiological mechanics of fluid balance, thermoregulation, and mass-balance calculations under extreme Sonoran Desert conditions:

- The Flash Evaporation Pattern: In dry desert heat, sweat evaporates instantly and thirst lags significantly behind fluid deficits, requiring objective mass-balance measurements to detect acute plasma depletion.
- Clinical Thresholds (PAGA / DGA): Body mass deficits exceeding 2.0% compromise thermoregulation and elevate cardiovascular strain, while over-drinking hypotonic plain water past sweat losses dilutes serum sodium (<135 mmol/L).
- Post-Exercise Recovery (125% to 150%): Prescribe 20 to 24 oz (~600 to 750 mL) of fluid per pound of mass lost over 4 to 6 hours post-exercise, combined with dietary sodium from whole foods to restore true euhydration.

### Step 2: Workplace Intelligence & AI Hydration Auditing

In occupational health, sports dietetics, and clinical athletic training, professionals leverage generative AI tools to audit sweat logs, calculate acute mass deficits, and formulate evidence-based rehydration schedules.

- AI-Assisted Hydration Calculations: Sports nutritionists prompt AI preceptors to execute fluid kinetics formulas (percentage mass loss, total sweat volume, hourly sweat rate) with mathematical precision.
- Delimiter Security Protocol (###): Client body mass values, fluid intake volumes, and urine logs must be enclosed inside triple hashes ( ### ) to maintain data isolation during automated preceptor analysis.
- Clinical Auditing: Professionals verify AI outputs against federal standards (ACSM Position Stand & Dietary Guidelines for Americans) to guarantee client safety and eliminate hyponatremia risks.

### Step 3: Module 08 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 09:

English Calculation: $\text{Sweat Rate} = [(3.0\text{ kg}) + 1.0\text{ L} - 0.2\text{ L}] / 4.0\text{ hr} = 3.8\text{ L} / 4.0\text{ hr} = \mathbf{0.95\text{ L/hr}}$ ($950\text{ mL/hr}$).

Cálculo en Español: $\text{Tasa de Sudor} = [(3.0\text{ kg}) + 1.0\text{ L} - 0.2\text{ L}] / 4.0\text{ h} = 3.8\text{ L} / 4.0\text{ h} = \mathbf{0.95\text{ L/h}}$ ($950\text{ mL/h}$).

English Rationale: Obligate renal filtration continues during recovery, and residual post-exercise sweating expels additional fluid. Consuming 125% to 150% of the net mass lost alongside sodium compensates for these ongoing losses.

Justificación en Español: La filtración renal continúa durante la recuperación y persiste una sudoración residual. Consumir del 125% al 150% del peso perdido junto con sodio compensa estas pérdidas continuas.

English Rationale: Ingesting plain hypotonic fluid in excess of total sweat output during prolonged activity. This dilutes extracellular sodium (<135 mmol/L), causing an osmotic fluid shift into cells and dangerous cerebral edema.

Justificación en Español: Ingerir agua simple en exceso por encima del sudor durante esfuerzos prolongados. Esto diluye el sodio plasmático (<135 mmol/L), provocando la entrada osmótica de agua a las células y edema cerebral.

English Response: Enclosing client mass-balance files and sweat rate parameters inside triple hashes (`###`) ensures clean data boundary isolation, prevents instruction drift, and maintains precise alignment with ACSM and DGA standards.

Respuesta en Español: Encapitular los archivos de balance de masa y parámetros de tasa de sudoración del cliente entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas de ACSM y DGA.

English Response: Extreme ambient desert heat elevates sweat rates and electrolyte depletion beyond safe replenishment capacities, making air-conditioned indoor facilities (72°F / 22°C) vital to prevent heat illness and severe dehydration.

Respuesta en Español: El calor extremo del desierto dispara las tasas de sudoración y el agotamiento de electrolitos más allá de las capacidades de reposo seguro, haciendo vitales las instalaciones interiores climatizadas (22 °C) para prevenir enfermedades por calor y deshidratación severa.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.


### AI Simulation Workspace • Exam Simulation & Synthesis

Copy the prompt below into Gemini to generate a personalized review sheet comparing bioenergetics (Module 07) and hydration (Module 08):

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Midterm Synthesis ###:
Role: Clinical Sports Nutritionist and Academic Tutor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Energy Metabolism (ATP-PCr, Glycolysis, Oxidative)
   Key Point: Hydration Dynamics (Sweat Rate, Cardiovascular Drift, EAH)
Step 2: Explain how dehydration accelerates muscle glycogen depletion during exercise.
Step 3: Provide 3 whole-food recovery meals meeting both carbohydrate replenishment and sodium rehydration standards.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 09 — Hydration & Electrolyte Balance for Athletic Performance

In plain English, next week in Module 09: Hydration and Electrolyte Balance for Athletic Performance you will learn why drinking plain water alone during hours of heavy desert sweating can dangerously dilute blood sodium (hyponatremia), and how to build a stage-by-stage electrolyte plan (before, during, and after exercise). Why it matters: this module opens the second half of the semester (Modules 09–16), where you defend your clinical nutrition logic in your own voice.

- Pattern (Context): Distinguishing between hypertonic dehydration (water loss) and exercise-associated hyponatremia (low blood sodium $<135\text{ mmol/L}$ from over-drinking plain water).
- Rule (Constraint): Prescribing pre-exercise (5–7 mL/kg), intra-exercise (sodium + 30–60 g/hr carbohydrate for sessions $>60\text{ min}$), and post-exercise (1.25–1.5 L/kg lost) protocols under 2025–2030 DGA .
- Solve (Intervention): Completing Mod 09 Discussion: Electrolyte Balance vs. Hyponatremia and Mod 09 Lab: Athletic Electrolyte & Fluid Prescription (with your Part 3 Active Verification).

### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 08 (Mod 08 Summary & Wrap-Up: Sweat Rate Calculations & Desert Heat Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 08: Resumen y Comprobación de Conocimientos


### Síntesis del Módulo 08: Hidratación de Precisión en Climas Áridos

Esta semana analizamos la fisiología del balance de fluidos y la termorregulación. Evaluó las tasas empíricas de sudoración, auditó la deriva cardiovascular ante el estrés por calor y diferenció la hipohidratación de los riesgos críticos de la Hiponatremia Asociada al Ejercicio (HAE).

Al vincular las normas federales ( regla del déficit de masa del 2.0% de PAGA 2018 ) con el cálculo de balance hídrico, consolidó una base científica para prescribir líquidos y electrolitos en entornos clínicos, comunitarios y deportivos.


### Conclusiones del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) • Patrón, Regla, Solución

En el calor desértico seco, el sudor se evapora de inmediato. La sed aparece tarde. El pesaje objetivo es indispensable para detectar la pérdida rápida de volumen plasmático.

Perder más del 2.0% del peso corporal compromete la termorregulación y eleva el esfuerzo cardiovascular. Beber agua simple en exceso diluye el sodio en sangre (<135 mmol/L).

Prescribir de 20 a 24 oz (~600–750 mL) por cada libra perdida en las 4 a 6 horas posteriores, combinando líquidos con sodio dietético de alimentos reales.


### Autoevaluación del Módulo 08 (Verificación Bilingüe)

Presione cada elemento para verificar su comprensión:

Respuesta en Español: $\text{Tasa de Sudor} = [(3.0\text{ kg}) + 1.0\text{ L} - 0.2\text{ L}] / 4.0\text{ h} = 3.8\text{ L} / 4.0\text{ h} = \mathbf{0.95\text{ L/h}}$ ($950\text{ mL/h}$).

English Calculation: $\text{Sweat Rate} = [(3.0\text{ kg}) + 1.0\text{ L} - 0.2\text{ L}] / 4.0\text{ hr} = \mathbf{0.95\text{ L/hr}}$ ($950\text{ mL/hr}$).

Respuesta en Español: La filtración renal continúa durante la recuperación y persiste una sudoración residual. Consumir del 125% al 150% del peso perdido junto con sodio compensa estas pérdidas continuas.

English Rationale: Obligate renal filtration continues during recovery, and residual post-exercise sweating expels additional fluid. Consuming 125% to 150% of net mass lost compensates for ongoing losses.

Respuesta en Español: La ingesta excesiva de agua simple por encima de la tasa de sudoración en esfuerzos prolongados. Esto diluye el sodio plasmático (<135 mmol/L), provocando la entrada osmótica de agua a las células y edema cerebral.

English Rationale: Ingesting plain hypotonic fluid in excess of total sweat output during prolonged activity. This dilutes extracellular sodium (<135 mmol/L), causing an osmotic fluid shift into cells and cerebral edema.

Respuesta en Español: Encapitular los archivos de balance de masa y parámetros de tasa de sudoración del cliente entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas de ACSM y DGA.

English Response: Enclosing client mass-balance files and sweat rate parameters inside triple hashes (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with ACSM and DGA standards.

Respuesta en Español: El calor extremo del desierto dispara las tasas de sudoración y el agotamiento de electrolitos más allá de las capacidades de reposo seguro, haciendo vitales las instalaciones interiores climatizadas (22 °C) para prevenir enfermedades por calor y deshidratación.

English Response: Extreme ambient desert heat elevates sweat rates and electrolyte depletion beyond safe replenishment capacities, making air-conditioned indoor facilities (72°F / 22°C) vital to prevent heat illness and severe dehydration.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Review Master Protocol: HLTH-150 Sintesis de Mitad de Semestre ###:
Rol: Nutriologo Deportivo Clinico y Tutor Academico en la voz del Narrator.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Metabolismo Energetico (ATP-PCr, Glycolysis, Oxidative)
   Key Point: Dinamica de Hidratacion (Sweat Rate, Cardiovascular Drift, EAH)
Step 2: Explicar como la deshidratacion acelera el agotamiento de glucogeno muscular durante el esfuerzo.
Step 3: Proponer 3 opciones de alimentos integrales para la recuperacion que cumplan con reposicion de carbohidratos y sodio.
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 09 — Hidratación y Equilibrio de Electrolitos para el Rendimiento Atlético

En palabras sencillas (Contexto Norteño): cuando alguien suda a chorros por horas en Yuma y toma pura agua simple sin nada de sal (sodio), la sangre se diluye peligrosamente (hiponatremia). Si los números clínicos se ponen pesados la próxima semana, concéntrate primero en cómo armar un plan exacto de agua y electrolitos para antes, durante y después del ejercicio y defenderlo con tus propias palabras (Parte 3).

- Patrón (Contexto): Diferenciar la deshidratación por falta de agua de la hiponatremia por tomar exceso de agua simple sin reponer sodio.
- Regla (Restricción): Prescribir protocolos exactos antes (5–7 mL/kg), durante (sodio + carbohidratos en esfuerzos $>60\text{ min}$) y después (1.25–1.5 L/kg perdido) según DGA 2025–2030 .
- Solución (Intervención): Completar el Foro del Mód 09 (Electrolyte Balance vs. Hyponatremia) y el Laboratorio del Mód 09 (Athletic Electrolyte & Fluid Prescription) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 08 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 08:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 08)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 08)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
