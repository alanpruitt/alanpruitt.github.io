# HLTH-150: Mod 08 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 08 Lab & Simulation: Sweat Rate & Heat Safety Calculation

Laboratorio del Módulo 08: Cálculo de Tasa de Sudoración y Seguridad ante el Calor del Desierto


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Sweat rate math tells you exactly how many liters or ounces of water your body loses per hour in Yuma's heat so you never guess at hydration. By weighing before and after exercise, adding fluid consumed during the session, and dividing by hours of activity, you can build an exact hourly drinking and whole-food electrolyte plan that prevents both $\ge 2\%$ dehydration and overhydration.

En Palabras Sencillas (Contexto Norteño): Calcular tu tasa de sudoración por hora es como medir cuántos litros por hora gasta el radiador de tu troca subiendo la cuesta hacia San Diego en pleno agosto. Si los términos técnicos se ponen pesados, concéntrate primero en la fórmula de pérdida de peso más líquido bebido entre las horas de actividad, y en reponer de 16 a 24 onzas por cada libra perdida.

- Whole-Body Sweat Rate Formula (L/hr): Calculated as ((Pre-Exercise Weight − Post-Exercise Weight in kg) + Fluid Consumed in L − Urine Volume) ÷ Exercise Duration in hours. En palabras sencillas: Restar tu peso antes y después de entrenar más el agua que tomaste para saber exactamente cuántos litros por hora estás sudando en el calor.
- Yuma Thermal Evaporative Demand (100°F–115°F+): In extreme desert heat, sweat rates frequently reach 1.0–2.5 L/hr, requiring scheduled cooling breaks and pre-planned fluid stations. En palabras sencillas: En el verano de Yuma puedes sudar de 1 a más de 2 litros por hora; no basta tomar agua solo cuando sientes sed.
- Gastric Emptying Limit (~1.0–1.2 L/hr Maximum): The human stomach can empty only ~1.0–1.2 L/hr during exercise; chugging massive volumes at once causes bloating rather than faster rehydration. En palabras sencillas: El estómago solo absorbe alrededor de un litro por hora; es mejor tomar tragos constantes cada 15–20 minutos que empinarse toda la botella de golpe.

### Lab Objectives & Sweat Rate Equations / Objetivos y Fórmulas de Tasa de Sudoración

- HLTH-150.8.1.AY26-27 (Hourly Sweat Rate Equation): $$ ext{Sweat Rate (L/hr)} = rac{( ext{Pre-Mass kg} - ext{Post-Mass kg}) + ext{Fluid Ingested (L)} - ext{Urine Volume (L)}}{ ext{Exercise Duration (hr)}}$$ (Note: $1 ext{ kg} = 2.2 ext{ lbs} pprox 1.0 ext{ L}$ of sweat; $1 ext{ lb} pprox 16 ext{ oz}$ of sweat lost; post-session replacement target = $16 ext{–}24 ext{ oz}$ per pound lost or $1.25 ext{–}1.5 ext{ L}$ per $ ext{kg}$ lost).
- HLTH-150.8.2.AY26-27 (DGA 2025–2030 & PAGA 2018 Heat Safety): Audit relative body-mass loss ($\ge 2.0\%$ clinical dehydration threshold) and design a food-first sodium/potassium + fluid replacement schedule using the Clinical Framing Protocol (Pattern / Rule / Solve) .
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-08 / Fase 1: Selección de Escenario de Simulación Clínica


```text
STRUCTURAL_DELIMITER_BOUND_1 ###:
[CASE FILE]: #150-08A (Track 1: Clinical & Cardiac Wellness Path)
[CLIENT]: Sr. Miguel C., Age 61 (Yuma East Wetlands Trail; Duration: 1.0 hour brisk walk at 96°F, 22% humidity)
[BIOMETRICS]: Pre-Mass: 80.0 kg (176.0 lbs); Post-Mass: 78.2 kg (172.0 lbs); Net Mass Loss: 1.8 kg (4.0 lbs = 2.25% body mass); Fluid Ingested During Walk: 0.3 L (10 oz); Urine: 0.0 L.
[CLINICAL TASK]: Calculate his hourly sweat rate (1.8 kg + 0.3 L = 2.1 L/hr), audit his 2.25% dehydration (>= 2% threshold), and prescribe his 64-96 oz (2.25-2.70 L) post-walk fluid + DGA 2025-2030 whole-food electrolyte recovery.
STRUCTURAL_DELIMITER_BOUND_1 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_2 ###:
[CASE FILE]: #150-08B (Track 2: Occupational & Public Health Path)
[CLIENT]: Elena V., Age 34, Solar Panel Technician (Wellton / Yuma County, AZ; Duration: 2.0-hour morning installation block at 104°F)
[BIOMETRICS]: Pre-Mass: 68.0 kg (149.6 lbs); Post-Mass: 66.2 kg (145.6 lbs); Net Mass Loss: 1.8 kg (4.0 lbs = 2.65% body mass); Fluid Ingested During 2-hr Block: 1.0 L (34 oz); Urine: 0.2 L.
[CLINICAL TASK]: Calculate her hourly sweat rate ((1.8 + 1.0 - 0.2) / 2.0 hrs = 1.3 L/hr), audit her 2.65% mass loss, and design an occupational work-rest hydration + whole-food lunch protocol.
STRUCTURAL_DELIMITER_BOUND_2 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_3 ###:
[CASE FILE]: #150-08C (Track 3: Sports & Tactical Performance Path)
[CLIENT]: Sebastián R., Age 19, AWC Matador Soccer Midfielder (Yuma, AZ; Duration: 1.5-hour match at 101°F)
[BIOMETRICS]: Pre-Mass: 75.0 kg (165.0 lbs); Post-Mass: 72.7 kg (160.0 lbs); Net Mass Loss: 2.3 kg (5.0 lbs = 3.07% body mass); Fluid Ingested During Match: 0.9 L (30 oz); Urine: 0.0 L.
[CLINICAL TASK]: Calculate his hourly sweat rate ((2.3 + 0.9) / 1.5 hrs = 2.13 L/hr), audit his 3.07% dehydration, and prescribe his 80-120 oz (2.9-3.45 L) post-match rehydration + DGA 2025-2030 whole-food recovery meal.
STRUCTURAL_DELIMITER_BOUND_3 ###:
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Consulta de IA


```text
Safety Auditor Protocol — HLTH-150 Module 08 Lab ###:
Act as my HLTH-150 Clinical Hydration & Thermoregulation Auditor. Evaluate the Yuma client case wrapped in triple-hashes (###) below using the 2025-2030 Dietary Guidelines for Americans and PAGA 2018:
Step 1: PATTERN: Calculate net body-mass loss (kg and lbs), % body-mass dehydration, and exact hourly Sweat Rate (L/hr).
Step 2: RULE: Apply the >= 2.0% dehydration performance/safety threshold, the 16-24 oz per pound (125%-150%) post-activity fluid replacement rule, and DGA 2025-2030 whole-food sodium/potassium guidelines.
Step 3: SOLVE: Design a pre-, intra-, and post-activity hydration + whole-food meal schedule for Yuma, AZ plus a 2-sentence bilingual instruction card (EN/ES). Remind me to write my 150-word minimum Active Verification (Part 3) in my own human voice!
Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Requirements

- Selected Track & Client Initials: Declare your chosen case (#150-08A, #150-08B, or #150-08C).
- Part 1: Pattern Recognition (Sweat Rate & Dehydration Math): Show your step-by-step calculation of % body-mass loss and hourly Sweat Rate ($ ext{L/hr}$).
- Part 2: Rule Application (Replacement Volume & DGA 2025–2030): Calculate the exact $16 ext{–}24 ext{ oz/lb}$ ($1.25 ext{–}1.5 ext{ L/kg}$) replacement window and cite 2025–2030 Dietary Guidelines for Americans whole-food sodium and potassium standards.
- Part 3: Solving the Gap (Hydration & Whole-Food Plan + Bilingual Card): Detail an hourly intra-session drinking pace and post-session whole-food electrolyte meal plus a 2-sentence bilingual client card (EN/ES).
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why your individualized sweat-rate math and whole-food electrolyte pairing protect your Yuma client better than generic "8 glasses a day" advice.
- Part 5: Repository Verification: Confirm archiving in EXW_Professional_AI_Repository / EXW_150_M08_Sweat_Rate_Audit.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Selected Track: Track 2 (#150-08B • Elena V., Age 34, Solar Panel Technician, Wellton / Yuma County, AZ).

Part 1: Pattern Recognition (Sweat Rate & Dehydration Math): Across her $2.0 ext{-hour}$ morning installation block at $104^\circ ext{F}$, Elena's body mass dropped from $68.0 ext{ kg}$ ($149.6 ext{ lbs}$) to $66.2 ext{ kg}$ ($145.6 ext{ lbs}$), a net deficit of $1.8 ext{ kg}$ ($4.0 ext{ lbs}$) or $2.65\%$ body-mass loss ($ rac{1.8}{68.0} imes 100 = 2.65\%$), exceeding the $\ge 2.0\%$ clinical dehydration threshold. Factoring in $1.0 ext{ L}$ fluid ingested and $0.2 ext{ L}$ urine voided, her hourly sweat rate is: $$ ext{Sweat Rate} = rac{1.8 ext{ kg} + 1.0 ext{ L} - 0.2 ext{ L}}{2.0 ext{ hr}} = rac{2.6 ext{ L}}{2.0 ext{ hr}} = 1.30 ext{ L/hr}\ (pprox 44 ext{ oz/hr})$$

Part 2: Rule Application (Replacement Volume & DGA 2025–2030): To restore euhydration after a $4.0 ext{ lb}$ ($1.8 ext{ kg}$) net deficit, Elena requires $16 ext{–}24 ext{ oz/lb}$ lost ($125\% ext{–}150\%$), which equals $64 ext{–}96 ext{ oz}$ ($2.25 ext{–}2.70 ext{ L}$) of fluid paired with whole-food sodium and potassium under the 2025–2030 Dietary Guidelines for Americans .

Part 3: Solving the Gap (Hydration & Whole-Food Plan + Bilingual Card): Key Point — Intra-Shift Pacing: Increase insulated water intake from $0.5 ext{ L/hr}$ to $1.0 ext{–}1.1 ext{ L/hr}$ ($8 ext{–}9 ext{ oz}$ every 15 minutes during shaded rest breaks) so net mass loss stays under $1.0\%$. Key Point — Post-Block Real-Food Recovery: Consume $72 ext{ oz}$ ($2.25 ext{ L}$) of cool water over 2 hours alongside a whole-food lunch of shredded chicken and pinto bean burritos with salted pico de gallo, avocado, and watermelon Slices (providing natural sodium, potassium, magnesium, and food moisture). EN Card: "Your desert sweat rate is 44 ounces per hour, so drink 8 to 9 ounces of cool water every 15 minutes during shaded breaks. Replace your 4-pound morning loss with 72 ounces of water paired with salted beans, avocado, and fruit at lunch." ES Card: "Su tasa de sudoración en el desierto es de 44 onzas por hora, así que tome de 8 a 9 onzas de agua fresca cada 15 minutos en la sombra. Reponga las 4 libras perdidas con 72 onzas de agua acompañadas de frijoles con sal, aguacate y fruta en el almuerzo."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, generic hydration advice telling outdoor workers to 'drink eight glasses of water a day' is dangerously inadequate for a solar technician working in 104°F Yuma County heat. Even though Elena drank 1.0 liter of water during her two-hour shift, our mass-balance equation proves she sweats at 1.30 liters per hour and finished 1.8 kilograms (2.65% body mass) dehydrated—a level that impairs cognitive focus around high-voltage equipment and elevates cardiovascular strain. By pacing her intra-shift intake at 8 to 9 ounces every 15 minutes and pairing her 72-ounce recovery water with whole-food sodium and potassium from pinto beans, avocado, and watermelon under the 2025–2030 Dietary Guidelines, we restore plasma volume safely. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."

Part 5: Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M08_Sweat_Rate_Audit.pdf .


### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 08 (Mod 08 Lab: Sweat Rate & Heat Safety Calculation)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 08 Laboratorio y Simulación: Cálculo de Tasa de Sudoración y Seguridad ante el Calor

- Parte 1 (Patrón): Calcule paso a paso el porcentaje de pérdida de masa corporal y la Tasa de Sudoración por hora ($ ext{L/hr}$).
- Parte 2 (Regla): Aplique el umbral de deshidratación ($\ge 2.0\%$), la regla de reposición de $16 ext{–}24 ext{ oz/lb}$ ($125\% ext{–}150\%$) y las pautas de alimentos reales de las DGA 2025–2030 .
- Parte 3 (Solución): Diseñe un plan de hidratación por hora y comida real de recuperación junto con una tarjeta bilingüe de 2 oraciones (EN/ES).
- Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica cómo el cálculo exacto de tasa de sudoración y los electrolitos de comida real protegen a su cliente en el calor de Yuma.
- Parte 5: Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository / EXW_150_M08_Sweat_Rate_Audit.pdf .
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 08 Quick Return Navigation / Regreso Rápido al Módulo 08:
