# HLTH-150: Mod 05 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 05 Discussion: How Carbs & Fats Fuel Different Workouts

Sistemas Energéticos, Concepto de Cruce y Prescripción de Macronutrientes

Understanding cellular ATP resynthesis pathways, substrate oxidation kinetics (the Brooks Crossover Concept), and carbohydrate availability is essential for optimizing sports performance and metabolic health. Select a career-aligned track below, audit a bioenergetic fueling profile using our academic SSoTs ( Dietary Guidelines for Americans / PAGA 2018 ), and execute an audit with the Gemini AI Preceptor!

Comprender las vías de resíntesis de ATP, la cinética de sustratos (Concepto de Cruce) y la disponibilidad de carbohidratos es fundamental para optimizar el rendimiento y la salud metabólica. ¡Seleccione una ruta profesional, audite un perfil bioenergético y formule su prescripción con el Preceptor de IA Gemini!

- Topic Opens / Apertura del Foro: Tuesday, September 15, 2026, at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday, September 17, 2026, at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 20, 2026, at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday, September 21, 2026, at 11:59 PM MST / Lunes a las 11:59 PM MST
You are warmly encouraged to post in English or Spanish according to your preference. Le animamos a publicar en inglés o en español según su preferencia académica.

To support your clinical sports nutrition skills, instructor evaluations and macronutrient audits are posted in this public community forum as well as in Gradebook.


### Phase 1: Select Your Clinical Simulation Case File #150-05 / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Prediabetic adult (J.R., 48) experiencing metabolic inflexibility, impaired lipid oxidation, and rapid muscular fatigue during walking at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[PATIENT INITIALS]: J.R. | [AGE]: 48 | [SEX]: Male | [LOCATION]: Yuma, AZ
[WEIGHT]: 92 kg (202 lbs) | [HEIGHT]: 5 ft 10 in (178 cm)
[CLINICAL PROFILE]: Prediabetes (HbA1c 6.1%); sedentary office worker initiating a walking program.
[METABOLIC DEFICIT]: Severe metabolic inflexibility; premature crossover to carbohydrate oxidation even at low intensities (RER = 0.92 at 3.0 mph walking), causing rapid glycogen depletion and leg heaviness within 20 minutes.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Lifestyle Medicine.
###
```

Focus: Agricultural machinery technician (S.M., 34) suffering severe afternoon cognitive fatigue and physical exhaustion during extended shifts in Yuma County.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CLIENT INITIALS]: S.M. | [AGE]: 34 | [SEX]: Female | [LOCATION]: Yuma County, AZ
[WEIGHT]: 68 kg (150 lbs) | [HEIGHT]: 5 ft 6 in (168 cm)
[OCCUPATION]: Agricultural Machinery Technician (Field Maintenance)
[NUTRITIONAL CHALLENGE]: Works 9-hour physical shifts in warm ambient temperatures; skips breakfast and consumes only ultra-processed low-carb snacks, causing total glycogen depletion and severe afternoon cognitive fatigue by hour 6.
[COMMUNITY SITE]: Yuma County Public Health Services District & Agricultural Wellness Center.
###
```

Focus: Collegiate soccer midfielder (A.V., 20) experiencing late-match deceleration and glycogen depletion ("hitting the wall") during high-intensity interval matches.


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[ATHLETE INITIALS]: A.V. | [AGE]: 20 | [SEX]: Male | [LOCATION]: Yuma, AZ
[WEIGHT]: 74 kg (163 lbs) | [HEIGHT]: 5 ft 11 in (180 cm)
[SPORT]: Collegiate Soccer Midfielder (AWC Matadors)
[PERFORMANCE DEFICIT]: Covers 10+ km per match with repeated high-intensity sprints; consumes <3 g/kg/day carbohydrate, resulting in severe 75th-minute sprint drop-off, depleted muscle glycogen, and delayed 48-hour recovery.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a bioenergetic and macronutrient audit:


```text
Safety Auditor Protocol: HLTH-150 Bioenergetics & Macronutrient Preceptor ###:
Role: Academic Sports Nutritionist and Exercise Metabolism Specialist in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA / USDA) & Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Review the candidate case file wrapped in triple-hashes (###) below.
Step 2: PATTERN: Identify the primary energy systems powering their activity (Phosphagen, Fast Glycolysis, Oxidative) and analyze their substrate oxidation kinetics using the Brooks Crossover Concept.
Step 3: RULE: Apply federal DGA and sports nutrition standards to calculate target daily carbohydrate availability (in total grams based on g/kg/day guidelines).
Step 4: SOLVE: Detail an acute post-exercise recovery protocol prescribing 1.0 to 1.2 g carbohydrate/kg/hour paired with 0.3 g protein/kg, including whole-food meal options and a 2-sentence bilingual client instruction card (English and Spanish).
Step 5: Maintain all client data wrapped in triple-hash (###) delimiters.

Candidate Data Input ###:
[Paste Your Selected Track Data Block Here]
End Candidate Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Bioenergetic Profile: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance), client initials, and primary energy systems recruited during their activity. Indique la ruta seleccionada, iniciales del cliente y los sistemas energéticos principales reclutados.
- Clinical Framing Protocol (Pattern / Rule / Solve) Analysis (Pattern / Rule / Solve): Detail the metabolic bottleneck or crossover shift (Pattern), apply federal DGA carbohydrate intake ranges in g/kg/day (Rule), and calculate an individualized acute post-workout recovery target in grams (Solve). Detalle el cuello de botella metabólico (Patrón), aplique las pautas DGA de carbohidratos en g/kg/día (Regla) y calcule la meta de recuperación post-ejercicio en gramos (Solución).
- Bilingual Client Takeaway Card: Provide a concise 2-sentence explanation of the fueling strategy in both English and Spanish so your client understands why carbohydrate timing protects performance and recovery. Incluya una explicación concisa de 2 oraciones en inglés y español para educar al cliente sobre la importancia del glucógeno y la recuperación.

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their carbohydrate calculations (g/kg/day and recovery targets), compare their substrate crossover demands, and discuss how nutritional timing differs between clinical, occupational, and athletic settings.

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Evalúe sus cálculos de carbohidratos y compare la demanda de sustratos entre el ámbito clínico, ocupacional y deportivo.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Track & Energy Systems: Track 3 Sports Performance. A.V. relies on Fast Glycolysis for repeated 10-to-30 second high-intensity sprints, interspersed with Oxidative Phosphorylation during recovery intervals to clear lactate and resynthesize phosphocreatine (PCr). Ruta 3 Rendimiento Deportivo. Utiliza glucólisis rápida para sprints repetidos y fosforilación oxidativa durante pausas para resintetizar fosfocreatina.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit: Pattern (Substrate Crossover & Depletion): High-intensity soccer forces the metabolic crossover entirely to carbohydrate oxidation (RER > 0.95). Consuming <3 g/kg/day carbohydrate results in chronically low pre-match glycogen stores, precipitating severe fatigue by minute 75 when glycogen is exhausted. Rule (DGA & Sports Nutrition Standards): High-endurance athletes training 1 to 3 hours/day require 6 to 10 g carbohydrate/kg/day to sustain glycogen stores (74 kg 7 g/kg = 518 grams carbohydrate daily ). Solve (Acute Post-Workout Protocol): Within the 0-to-4 hour recovery window, A.V. must consume 1.0 to 1.2 g carbohydrate/kg/hour (74 kg 1.1 g = 81 grams carbohydrate per hour ) paired with 22 g protein (0.3 g/kg) using whole foods (e.g., chocolate milk, rice bowls with chicken, oatmeal with bananas). Patrón: El juego de alta intensidad depende de carbohidratos. Consumir <3 g/kg agota el glucógeno en el minuto 75. Regla: Requiere 6 a 10 g/kg/día (518 g/día). Solución: 81 g carbohidratos/hora + 22 g proteína en las 4 horas posteriores.
- Bilingual Client Handout Card: EN: "Fueling with 518 grams of daily complex carbohydrates and eating 81 grams of carbs with protein immediately after matches will refill your muscle glycogen tanks and eliminate late-game fatigue." ES: "Consumir 518 gramos de carbohidratos diarios y 81 gramos con proteína inmediatamente después de los partidos recargará su glucógeno muscular y eliminará la fatiga al final del juego."

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 05 (Mod 05 Discussion: How Carbs & Fats Fuel Different Workouts)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Foro de Discusión 05: Cruce Bioenergético y Auditoría de Macronutrientes

Comprender las vías de resíntesis de ATP, el Concepto de Cruce y la disponibilidad de carbohidratos es esencial para el rendimiento físico. Seleccione una ruta profesional y audite el perfil nutricional de su cliente con el Preceptor de IA Gemini.

- Apertura del Foro: Martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 17 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 20 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 21 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta y Perfil Bioenergético: Indique su ruta seleccionada (Ruta 1 Clínica, Ruta 2 Comunitaria o Ruta 3 Deportiva), iniciales del cliente y los sistemas energéticos principales.
- Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Detalle el cuello de botella metabólico en la utilización de sustratos (Patrón), aplique las normas DGA de carbohidratos en g/kg/día (Regla) y calcule la meta de recuperación post-ejercicio en gramos (Solución).
- Tarjeta de Instrucción Bilingüe: Incluya una explicación concisa de 2 oraciones en inglés y español sobre la importancia de la nutrición para recargar glucógeno.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:
