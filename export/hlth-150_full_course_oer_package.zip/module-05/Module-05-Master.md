## HLTH-150: LAB 05 - HYDRATION DYNAMICS / DINÁMICA DE LA HIDRATACIÓN 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## > ###  Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (sports nutrition requirements, hydration audits, and energy demands).

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This module examines the biophysical laws governing fluid shifts, plasma volume changes, and osmotic pressure regulation during sustained athletic exertion. Students will analyze real-world sweat rate indices to engineer precise rehydration schedules that maximize thermodynamic safety and cellular performance. All tracking metrics, fluid volume parameters, and electrolyte limits align exclusively with our dual SSoT: the current **U.S. Dietary Guidelines for Americans** and the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* *Español (Regional): Este módulo examina las leyes biofísicas que rigen los cambios de líquidos, las variaciones del volumen plasmático y la regulación de la presión osmótica durante el esfuerzo deportivo prolongado. Los estudiantes analizarán los índices de tasa de sudoración del mundo real para diseñar programas de rehidratación precisos que maximicen la seguridad termodinámica y el rendimiento celular. Todos los parámetros de volumen de líquido se alinean exclusivamente con nuestro SSoT dual: las **Pautas Dietéticas para Estadounidenses** vigentes y las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.3])** Identify the importance and impact of hydration and electrolytes on performance recovery and thermoregulation.
* *Español (Regional) ([LO 2.3]): Identificar la importancia y el impacto de la hidratación y los electrolitos en la recuperación del rendimiento y la termorregulación.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Audit acute plasma volume depletion markers, hemoconcentration flags, and body mass fluctuations during high-heat exercise protocols.
2. **Rule / Regla:** Apply strict fluid balance limits (preventing a net body mass loss greater than 2 percent via strategic rehydration) matching public health benchmarks found within the dual SSoT.
3. **Solve / Solución:** Engineer a personalized osmotic restoration and sweat-rate replacement timeline to maintain systemic homeostatic thermoregulation safely.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Osmotic Fluid Shift Modeling / Objetivo: Modelado de Cambios de Líquidos Osmónicos

Students will initialize their fluid simulation tracking sheets inside the digital sandbox workspace using the setup values wrapped below.

```text
## METABOLIC_STRATA:
- Pre-Exercise Mass: 75 kg
- Post-Exercise Mass: 73.1 kg (Following 60-minute trial in high heat)
- Fluid Consumed: 250 mL during exertion
###
```

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Input the baseline pre-exercise and post-exercise mass markers into the simulation framework.
2. Calculate total sweat volume metrics and determine the exact percentage of body mass lost.
3. Verify if the calculated fluid loss crosses the restricted 2 percent safety boundary defined by federal standards.

---

## Part B: Practical Application (Onsite Lab) / Aplicación Práctica Presencial (Laboratorio)

## Location: Community College Athletics Track & Localized Prep Kitchen Space

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Build a timed post-exercise rehydration schedule to replace the fluid volume deficits tracked in Part A.
2. Design a fluid restoration plan that balances electrolyte matching parameters without relying on commercial marketing trends.
3. Complete final compliance tracking sheets to ensure absolute alignment with federal guidelines.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This assignment is evaluated using the strict **10/7/0 Mastery Scale** / *Esta asignación se evalúa utilizando la escala estricta de Maestría **10/7/0**:*

* **10 (Exemplary / Ejemplar):**
  * **English:** Zero-drift integration. All core guidelines are applied exactly, target parameters remain securely enclosed within delimiter structures (`###`), and bilingual parity is fully preserved.
  * *Español (Regional): Integración con cero desviaciones. Todas las pautas de referencia se aplican exactamente, los parámetros de configuración permanecen contenidos de forma segura dentro de las estructuras delimitadoras (`###`) y se conserva por completo la paridad bilingüe.*
* **7 (Competent / Competente):**
  * **English:** Core performance metrics are safe, safe thermal boundaries are maintained, and calculations are accurate, but minor regional translation gaps, loose formatting, or structural layout misplacements are flagged.
  * *Español (Regional): Las métricas de rendimiento principales son seguras, se mantienen los límites de seguridad térmica y los cálculos son precisos, pero se señalan brechas menores de traducción regional, formato suelto o desalineaciones en la estructura.*
* **0 (Recalibrate / Recalibrar):**
  * **English:** Critical calculation drift is present, safety thresholds are violated, commercial/fad-based trends are promoted instead of the federal SSoT, or core data inputs are left un-delimited.
  * *Español (Regional): Se presenta una desviación crítica en los cálculos, se violan los límites de seguridad, se promueven tendencias comerciales en lugar de la Fuente Única de Verdad (SSoT) federal, o las entradas de datos clave se dejan sin delimitar.*

---

## HLTH-150 Module Discussion: Fluid Dynamics & Osmotic Balance

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Evaluate the target configuration setup variables to construct your rehydration timeline, and justify your replacement values using federal reference benchmarks.
* **Español (Regional):** Evaluar las variables de configuración para construir su cronograma de rehidratación y justificar sus valores de reemplazo utilizando los estándares federales de referencia.
###



## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
