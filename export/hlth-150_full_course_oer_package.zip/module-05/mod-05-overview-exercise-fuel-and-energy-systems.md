# HLTH-150: Mod 05 Overview Exercise Fuel And Energy Systems

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 05 Overview: Exercise Fuel & Energy Systems


### Welcome to Module 05: Exercise Fuel & Energy Systems

Welcome to Week 5! This week, we examine the bioenergetic pathways responsible for resynthesizing Adenosine Triphosphate (ATP) during physical activity: the immediate phosphagen system (ATP-PCr), fast and slow glycolysis, and oxidative phosphorylation. Anchored in our academic Single Sources of Truth (SSoTs)—the Dietary Guidelines for Americans (DGA / USDA) and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —we analyze substrate oxidation kinetics, the Crossover Concept, and metabolic flexibility across exertion spectrums.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will evaluate client energy demands, apply evidence-based carbohydrate and fat fueling guidelines, and structure localized, whole-food nutritional strategies that optimize glycogen re-synthesis, cellular recovery, and metabolic health across Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 15, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 17, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 20, 2026, at 11:59 PM MST
- Lab 05 Direct Submission / Entrega de Laboratorio: Monday, September 21, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 05 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Differentiate the power (rate of ATP production) and capacity (total ATP potential) of the phosphagen, glycolytic, and oxidative energy systems during varied exercise intensities. Diferenciar la potencia y capacidad de los sistemas de fosfágenos, glucolítico y oxidativo durante diferentes intensidades de ejercicio.
- CLO 2 (Rule Application): Evaluate substrate kinetics using the Crossover Concept, applying DGA and PAGA 2018 principles to determine carbohydrate versus fat reliance as exercise intensity transitions toward the anaerobic threshold. Evaluar la cinética de sustratos mediante el Concepto de Cruce, aplicando las pautas DGA y PAGA 2018 para determinar el uso de carbohidratos vs. grasas.
- CLO 3 (Problem Solving): Formulate an individualized, whole-food macronutrient fueling and recovery plan (targeting 1.0 to 1.2 g carbohydrate/kg/hour post-exercise) to restore muscle glycogen stores and sustain physical capacity. Diseñar un plan de nutrición y recuperación con alimentos reales (1.0 a 1.2 g de carbohidratos/kg/hora post-ejercicio) para restaurar el glucógeno muscular.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit energy systems and macronutrient fueling across your selected career track:

Optimizing fat oxidation, mitochondrial health, and glycemic stability in prediabetic or insulin-resistant patients through low-intensity steady-state exercise at Matador Clinical Partners (MCP).

Designing accessible, budget-friendly complex carbohydrate meal plans and hydration strategies to sustain daily energy expenditure for active workers and families across Yuma County.

Structuring intra-workout exogenous carbohydrate delivery and post-session glycogen replenishment windows for high-intensity interval athletes at Arizona Western College.


### Module 05 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Energy Pathways, Substrate Kinetics & DGA Guidelines
- Discussion Board 05: Bioenergetic Crossover & Macronutrient Auditing
- Lab Assignment 05: Energy System Prescription & Gemini AI Tool Box
- Module 05 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 05 (Mod 05 Overview: Exercise Fuel & Energy Systems)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 05 Visión General: Bioenergética y Metabolismo


### Bienvenido al Módulo 05: Sistemas Energéticos, Bioenergética y Metabolismo del Ejercicio

¡Bienvenido a la Semana 5! Esta semana examinaremos las vías metabólicas que resintetizan el Trifosfato de Adenosina (ATP) durante la actividad física: el sistema de fosfágenos (ATP-PCr), la glucólisis rápida y lenta, y la fosforilación oxidativa. Basados en nuestras Fuentes Únicas de Verdad (SSoT)—las Guías Alimentarias para los Estadounidenses (DGA / USDA) y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) —analizaremos la cinética de oxidación de sustratos y el Concepto de Cruce.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará las demandas energéticas, aplicará pautas de nutrición con carbohidratos y grasas, y diseñará estrategias con alimentos reales para optimizar la resíntesis de glucógeno y la recuperación metabólica en el condado de Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 17 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 20 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 05: Lunes, 21 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Diferenciar la potencia y capacidad de los sistemas de fosfágenos, glucolítico y oxidativo durante intensidades variables de esfuerzo.
- CLO 2 (Regla): Evaluar la cinética de sustratos mediante el Concepto de Cruce, aplicando pautas DGA y PAGA 2018 al aproximarse al umbral anaeróbico.
- CLO 3 (Solución): Formular un plan de alimentación y recuperación con alimentos reales (1.0 a 1.2 g carbohidratos/kg/hora post-ejercicio) para restaurar el glucógeno.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la bioenergética y la nutrición deportiva a través de su ruta profesional:

Optimización de la oxidación de grasas y sensibilidad a la insulina en pacientes con prediabetes en Matador Clinical Partners (MCP).

Diseño de planes accesibles con carbohidratos complejos para sostener el gasto energético diario en familias de Yuma.

Estrategias de ingesta de carbohidratos intra-entrenamiento y recarga de glucógeno para atletas de alta intensidad en AWC.


### Ruta de Aprendizaje del Módulo 05

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Vías Energéticas, Cinética de Sustratos y Guías DGA
- Foro de Discusión 05: Cruce Bioenergético y Auditoría de Macronutrientes
- Laboratorio 05: Prescripción de Sistemas Energéticos y Consulta de IA
- Comprobación de Conocimientos y Resumen del Módulo 05

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 05 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 05 Required Readings: Exercise Fuel & Energy Systems →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 05 Discussion: How Carbs & Fats Fuel Different Workouts →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 05 Coaching Sprint: Matching Food Fuel to Workout Intensity →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 05 Lab: Exercise Fuel & Energy Systems Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 05 Summary & Wrap-Up: Exercise Fuel & Energy Systems →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
