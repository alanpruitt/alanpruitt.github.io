## HLTH-150: Mod 05 Overview Exercise Fuel And Energy Systems

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 05 Overview: Exercise Fuel & Energy Systems


### Welcome to Module 05: Exercise Fuel & Energy Systems

Welcome to Week 5! This week, we examine the bioenergetic pathways responsible for resynthesizing Adenosine Triphosphate (ATP) during physical activity: the immediate phosphagen system (ATP-PCr), fast and slow glycolysis, and oxidative phosphorylation. Anchored in our academic Single Sources of Truth (SSoTs)—the Dietary Guidelines for Americans (DGA / USDA) and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —we analyze substrate oxidation kinetics, the Crossover Concept, and metabolic flexibility across exertion spectrums.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will evaluate client energy demands, apply evidence-based carbohydrate and fat fueling guidelines, and structure localized, whole-food nutritional strategies that optimize glycogen re-synthesis, cellular recovery, and metabolic health across Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 15, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 17, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 20, 2026, at 11:59 PM MST
- Lab 05 Direct Submission / Entrega de Laboratorio: Monday, September 21, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 05 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Differentiate the power (rate of ATP production) and capacity (total ATP potential) of the phosphagen, glycolytic, and oxidative energy systems during varied exercise intensities. Diferenciar la potencia y capacidad de los sistemas de fosfágenos, glucolítico y oxidativo durante diferentes intensidades de ejercicio.
- CLO 2 (Rule Application): Evaluate substrate kinetics using the Crossover Concept, applying DGA and PAGA 2018 principles to determine carbohydrate versus fat reliance as exercise intensity transitions toward the anaerobic threshold. Evaluar la cinética de sustratos mediante el Concepto de Cruce, aplicando las pautas DGA y PAGA 2018 para determinar el uso de carbohidratos vs. grasas.
- CLO 3 (Problem Solving): Formulate an individualized, whole-food macronutrient fueling and recovery plan (targeting 1.0 to 1.2 g carbohydrate/kg/hour post-exercise) to restore muscle glycogen stores and sustain physical capacity. Diseñar un plan de nutrición y recuperación con alimentos reales (1.0 a 1.2 g de carbohidratos/kg/hora post-ejercicio) para restaurar el glucógeno muscular.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit energy systems and macronutrient fueling across your selected career track:

Optimizing fat oxidation, mitochondrial health, and glycemic stability in prediabetic or insulin-resistant patients through low-intensity steady-state exercise at Matador Clinical Partners (MCP).

Designing accessible, budget-friendly complex carbohydrate meal plans and hydration strategies to sustain daily energy expenditure for active workers and families across Yuma County.

Structuring intra-workout exogenous carbohydrate delivery and post-session glycogen replenishment windows for high-intensity interval athletes at Arizona Western College.


### Module 05 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Energy Pathways, Substrate Kinetics & DGA Guidelines
- Discussion Board 05: Bioenergetic Crossover & Macronutrient Auditing
- Lab Assignment 05: Energy System Prescription & Gemini AI Tool Box
- Module 05 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 05 (Mod 05 Overview: Exercise Fuel & Energy Systems)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 05 Visión General: Bioenergética y Metabolismo


### Bienvenido al Módulo 05: Sistemas Energéticos, Bioenergética y Metabolismo del Ejercicio

¡Bienvenido a la Semana 5! Esta semana examinaremos las vías metabólicas que resintetizan el Trifosfato de Adenosina (ATP) durante la actividad física: el sistema de fosfágenos (ATP-PCr), la glucólisis rápida y lenta, y la fosforilación oxidativa. Basados en nuestras Fuentes Únicas de Verdad (SSoT)—las Guías Alimentarias para los Estadounidenses (DGA / USDA) y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) —analizaremos la cinética de oxidación de sustratos y el Concepto de Cruce.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará las demandas energéticas, aplicará pautas de nutrición con carbohidratos y grasas, y diseñará estrategias con alimentos reales para optimizar la resíntesis de glucógeno y la recuperación metabólica en el condado de Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 17 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 20 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 05: Lunes, 21 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Diferenciar la potencia y capacidad de los sistemas de fosfágenos, glucolítico y oxidativo durante intensidades variables de esfuerzo.
- CLO 2 (Regla): Evaluar la cinética de sustratos mediante el Concepto de Cruce, aplicando pautas DGA y PAGA 2018 al aproximarse al umbral anaeróbico.
- CLO 3 (Solución): Formular un plan de alimentación y recuperación con alimentos reales (1.0 a 1.2 g carbohidratos/kg/hora post-ejercicio) para restaurar el glucógeno.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la bioenergética y la nutrición deportiva a través de su ruta profesional:

Optimización de la oxidación de grasas y sensibilidad a la insulina en pacientes con prediabetes en Matador Clinical Partners (MCP).

Diseño de planes accesibles con carbohidratos complejos para sostener el gasto energético diario en familias de Yuma.

Estrategias de ingesta de carbohidratos intra-entrenamiento y recarga de glucógeno para atletas de alta intensidad en AWC.


### Ruta de Aprendizaje del Módulo 05

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Vías Energéticas, Cinética de Sustratos y Guías DGA
- Foro de Discusión 05: Cruce Bioenergético y Auditoría de Macronutrientes
- Laboratorio 05: Prescripción de Sistemas Energéticos y Consulta de IA
- Comprobación de Conocimientos y Resumen del Módulo 05

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 05 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 05 Required Readings: Exercise Fuel & Energy Systems →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 05 Discussion: How Carbs & Fats Fuel Different Workouts →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 05 Coaching Sprint: Matching Food Fuel to Workout Intensity →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 05 Lab: Exercise Fuel & Energy Systems Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 05 Summary & Wrap-Up: Exercise Fuel & Energy Systems →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 05)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
