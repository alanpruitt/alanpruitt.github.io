## HLTH-150: Mod 05 Summary And Wrap Up Exercise Fuel And Energy Systems

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 05 Summary & Wrap-Up: Exercise Fuel & Energy Systems

Bioenergética, Cinética de Sustratos, Concepto de Cruce y Metabolismo del Ejercicio


### Step 1: Core Bioenergetics & Substrate Kinetics Synthesis

Congratulations on completing Module 05! You have mastered the acute bioenergetic pathways (Phosphagen, Fast/Slow Glycolysis, and Oxidative Phosphorylation) governing ATP resynthesis, substrate utilization kinetics, and nutritional recovery standards:

- The Energy Continuum: No metabolic pathway operates in isolation. While the Phosphagen (ATP-PCr) system delivers maximum power for explosive efforts (<10 seconds), Fast Glycolysis sustains high-intensity anaerobic transitions (30 seconds to 2 minutes), and Oxidative Phosphorylation provides high-capacity, sustained ATP output during aerobic exercise.
- Brooks' Crossover Concept: Increasing exercise intensity drives a progressive metabolic shift from lipid oxidation to carbohydrate reliance, dictated by high-threshold Type II fast-twitch muscle fiber recruitment and elevated circulating catecholamines.
- Glycogen Management & DGA Availability: Sustained physical performance requires matching daily carbohydrate availability (6 to 10 g/kg/day for endurance training) to training volume, followed by acute post-exercise replenishment (1.0 to 1.2 g carbohydrate/kg/hour paired with 0.3 g protein/kg) within the initial 4 hours post-workout.

### Step 2: Workplace Intelligence & AI Bioenergetic Auditing

In collegiate athletic departments like Arizona Western College (AWC), metabolic lifestyle clinics at Matador Clinical Partners (MCP), and community sports dietetics facilities, specialists leverage generative AI tools to audit substrate utilization rates, project glycogen depletion thresholds, and design targeted fueling plans.

- AI-Assisted Substrate Modeling: Sports nutritionists prompt AI preceptors to evaluate Respiratory Exchange Ratio (RER = VCO2 / VO2) data, quantify carbohydrate oxidation rates (g/min), and determine daily carbohydrate availability targets based on athlete body mass.
- Delimiter Security Protocol (###): Client biometric files and metabolic metrics (body mass, session duration, intensity, dietary logs) must be enclosed inside triple hashes ( ### ) to ensure clean data boundary isolation during automated preceptor analysis.
- Human-in-the-Loop Clinical Verification: Practitioners verify AI-generated carbohydrate fueling schedules against federal standards (DGA & PAGA 2018) to prevent metabolic fatigue and optimize glycogen resynthesis without gastrointestinal distress.

### Step 3: Module 05 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 06:

English Response: The Phosphagen System (ATP-PCr) . It utilizes intramuscular creatine kinase to rapidly transfer a high-energy phosphate group from phosphocreatine to ADP, resynthesizing ATP at the highest possible rate (maximum power) without requiring oxygen or producing lactate.

Respuesta en Español: El Sistema de Fosfágenos (ATP-PCr) . Utiliza la enzima creatina quinasa para transferir rápidamente un grupo fosfato de la fosfocreatina al ADP, resintetizando ATP a la velocidad más alta posible sin requerir oxígeno ni producir lactato.

English Response: As exercise intensity increases from rest toward maximal exertion, the proportional contribution of lipid oxidation declines while carbohydrate oxidation rises. The point where carbohydrate energy contribution surpasses that of lipids is the Crossover Point, driven by the recruitment of glycolytic Type II fast-twitch muscle fibers and sympathetic epinephrine surges.

Respuesta en Español: Al aumentar la intensidad del ejercicio, la contribución de la oxidación de grasas disminuye y la de carbohidratos aumenta. El Punto de Cruce es donde los carbohidratos superan a las grasas, impulsado por el reclutamiento de fibras rápidas Tipo II y la liberación de adrenalina.

English Response: Endurance athletes training at moderate-to-high intensities for 1 to 3 hours per day require Outcome 6.0: to 10.0 grams of carbohydrate per kilogram of body weight per day (6 to 10 g/kg/day) to maintain saturated muscle and liver glycogen stores and prevent metabolic fatigue.

Respuesta en Español: Los atletas de resistencia que entrenan de 1 a 3 horas diarias requieren de Outcome 6.0: a 10.0 gramos de carbohidratos por kilogramo de peso corporal al día (6 a 10 g/kg/día) para mantener las reservas de glucógeno y evitar la fatiga metabólica.

English Response: Consuming Outcome 1.0: to 1.2 grams of carbohydrate per kilogram of body weight per hour during the initial 4 hours post-exercise capitalizes on elevated non-insulin-dependent GLUT-4 transporter translocation and activated glycogen synthase, maximizing the rate of muscle glycogen storage.

Respuesta en Español: Consumir de Outcome 1.0: a 1.2 gramos de carbohidratos por kilogramo por hora durante las primeras 4 horas aprovecha la activación de la enzima glucógeno sintasa y los transportadores GLUT-4, maximizando la velocidad de almacenamiento de glucógeno.

English Response: Enclosing client biometric files and metabolic metrics inside triple hashes (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with DGA and PAGA 2018 standards.

Respuesta en Español: Encapitular los archivos biométricos y métricas metabólicas del cliente entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas DGA y PAGA 2018.

English Response: Extreme ambient desert heat elevates glycogen utilization rates and accelerates dehydration, making air-conditioned indoor facilities (72°F / 22°C) vital for safe metabolic conditioning and nutrition planning.

Respuesta en Español: El calor extremo del desierto eleva las tasas de utilización de glucógeno y acelera la deshidratación, haciendo vitales las instalaciones climatizadas (22 °C) para el acondicionamiento metabólico y la planificación nutricional segura.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: RER is the ratio of carbon dioxide produced to oxygen consumed ($\text{VCO}_2 / \text{VO}_2$). An RER of 0.70 indicates pure fat oxidation, whereas an RER of 1.00 (or higher) indicates 100% carbohydrate oxidation.

Respuesta en Español: El RER es la relación entre el dióxido de carbono producido y el oxígeno consumido ($\text{VCO}_2 / \text{VO}_2$). Un RER de 0.70 indica oxidación pura de grasas, mientras que un RER de 1.00 indica oxidación exclusiva de carbohidratos.


### AI Simulation Workspace • Bioenergetics & Metabolism Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive synthesis connecting ATP resynthesis rates, substrate crossover kinetics, and federal carbohydrate fueling standards:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Module 05 Bioenergetics Synthesis ###:
Role: Academic Sports Nutritionist and Exercise Metabolism Specialist in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA / USDA) & Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Bioenergetic Energy Systems (Phosphagen ATP-PCr vs. Fast Glycolysis vs. Oxidative Phosphorylation).
   Key Point: Kinetic Parameters (Power / ATP Resynthesis Rate, Capacity / Total Yield, Limiting Fatigue Factor).
   Key Point: Substrate Availability & Fueling (Primary Fuels, Daily Carbohydrate Intake in g/kg/day, Acute Recovery Protocols).
Step 2: Explain the physiological mechanics of the Brooks Crossover Concept and outline an acute post-exercise glycogen resynthesis strategy (1.0 to 1.2 g CHO/kg/hr + 0.3 g protein/kg).
Step 3: Keep all formulas in plain text and wrap all data inputs within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 06 — Micronutrients & Hydration (Vitamins, Minerals & Electrolytes)

In plain English, next week in Module 06: Micronutrients & Hydration you will learn how vitamins and minerals (like iron, calcium, vitamin D, sodium, and potassium) act like spark plugs that let your body carry oxygen, build strong bones, and contract muscles without cramping. Why it matters: heavy sweaters and endurance athletes often run low on iron or electrolytes—knowing how to fix gaps with nutrient-dense real foods prevents fatigue and dangerous supplement overdoses.

- Pattern (Context): Screening for common micronutrient shortfalls (iron-deficiency anemia, low calcium/Vitamin D, and sweat electrolyte losses) in active populations.
- Rule (Constraint): Meeting 2025–2030 DGA Recommended Dietary Allowances (RDAs) through whole foods while respecting Tolerable Upper Intake Levels (ULs).
- Solve (Intervention): Completing Mod 06 Discussion: Micronutrients & Electrolytes and Mod 06 Lab: Micronutrient & Electrolyte Audit .

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 05 (Mod 05 Summary & Wrap-Up: Exercise Fuel & Energy Systems)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 05: Resumen y Evaluación

Bioenergética, Cinética de Sustratos y Metabolismo del Ejercicio


### Step 1: Síntesis de Bioenergética y Cinética de Sustratos

¡Felicitaciones por completar el Módulo 05! Ha establecido los conocimientos fundamentales sobre las vías de resíntesis de ATP (Fosfágenos, Glucólisis y Fosforilación Oxidativa) y las pautas de carbohidratos según las normas DGA y PAGA 2018:

- Continuo Energético: Ninguna vía funciona en aislamiento total. El sistema de fosfágenos aporta máxima potencia inmediata (<10 s), la glucólisis rápida sostiene esfuerzos intensos (30 s a 2 min) y la fosforilación oxidativa aporta energía aeróbica ilimitada.
- Concepto de Cruce de Brooks: El aumento de intensidad desplaza el metabolismo de las grasas a los carbohidratos, impulsado por el reclutamiento de fibras rápidas Tipo II y la liberación de adrenalina.
- Disponibilidad de Glucógeno y Normas Federales: El rendimiento físico exige aportar de 6 a 10 g de carbohidratos/kg/día en entrenamientos de resistencia, y de 1.0 a 1.2 g/kg/hora en la recuperación inmediata.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría Bioenergética con IA

En instalaciones deportivas universitarias de AWC y centros clínicos como Matador Clinical Partners (MCP), los especialistas utilizan IA generativa para auditar tasas de oxidación de sustratos y proyectar la reposición de glucógeno.

- Modelado Asistido por IA: Simulación de valores RER (VCO2 / VO2) y cálculo de metas de disponibilidad de carbohidratos en gramos totales.
- Seguridad con Delimitadores (###): Uso de tres numerales ( ### ) para aislar datos biométricos y registros de ingesta.
- Verificación Clínica Humana: Los profesionales revisan los planes generados por la IA frente a las normas DGA para evitar fatiga metabólica prematura.

### Step 3: Autoevaluación del Módulo 05 (Verificación Bilingüe)

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 06:

Respuesta en Español: El Sistema de Fosfágenos (ATP-PCr) , que utiliza la creatina quinasa para transferir un grupo fosfato de la fosfocreatina al ADP a máxima velocidad sin requerir oxígeno ni producir lactato.

English Response: The Phosphagen System (ATP-PCr) . It utilizes intramuscular creatine kinase to rapidly transfer a high-energy phosphate group from phosphocreatine to ADP, resynthesizing ATP at the highest possible rate.

Respuesta en Español: Al aumentar la intensidad, la oxidación de grasas disminuye y la de carbohidratos aumenta hasta cruzarlo, debido al reclutamiento de fibras rápidas Tipo II y la liberación de adrenalina.

English Response: As exercise intensity increases, the proportional contribution of lipid oxidation declines while carbohydrate oxidation rises. The Crossover Point is driven by the recruitment of glycolytic Type II fibers and sympathetic epinephrine surges.

Respuesta en Español: De Outcome 6.0: a 10.0 gramos por kilogramo de peso corporal al día (6 a 10 g/kg/día) para mantener llenas las reservas de glucógeno y evitar la fatiga metabólica.

English Response: Endurance athletes training at moderate-to-high intensities for 1 to 3 hours per day require Outcome 6.0: to 10.0 grams of carbohydrate per kilogram of body weight per day to maintain saturated glycogen stores.

Respuesta en Español: Consumir de Outcome 1.0: a 1.2 gramos de carbohidratos por kilogramo por hora en las primeras 4 horas aprovecha la activación de los transportadores GLUT-4 y la enzima glucógeno sintasa.

English Response: Consuming Outcome 1.0: to 1.2 grams of carbohydrate per kilogram of body weight per hour during the initial 4 hours post-exercise capitalizes on elevated GLUT-4 translocation and activated glycogen synthase.

Respuesta en Español: Encapitular los archivos biométricos y métricas metabólicas del cliente entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas DGA y PAGA 2018.

English Response: Enclosing client biometric files and metabolic metrics inside triple hashes (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with DGA and PAGA 2018 standards.

Respuesta en Español: El calor extremo del desierto eleva las tasas de utilización de glucógeno y acelera la deshidratación, haciendo vitales las instalaciones climatizadas (22 °C) para el acondicionamiento metabólico y la planificación nutricional segura.

English Response: Extreme ambient desert heat elevates glycogen utilization rates and accelerates dehydration, making air-conditioned indoor facilities (72°F / 22°C) vital for safe metabolic conditioning and nutrition planning.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: El RER es la relación entre el dióxido de carbono producido y el oxígeno consumido ($\text{VCO}_2 / \text{VO}_2$). Un RER de 0.70 indica oxidación pura de grasas, mientras que un RER de 1.00 indica oxidación exclusiva de carbohidratos.

English Response: RER is the ratio of carbon dioxide produced to oxygen consumed ($\text{VCO}_2 / \text{VO}_2$). An RER of 0.70 indicates pure fat oxidation, whereas an RER of 1.00 indicates 100% carbohydrate oxidation.


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: HLTH-150 Sintesis Modulo 05 ###:
Rol: Mentor Academico de Nutricion Deportiva y Metabolismo Energetico.
SSoT: Guias Alimentarias (DGA / USDA) y Pautas de Actividad Fisica (PAGA 2018, 2.a edicion).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Sistemas Bioenergeticos (Fosfagenos ATP-PCr vs. Glucolisis Rapida vs. Fosforilacion Oxidativa).
   Key Point: Parametros Cineticos (Potencia / Tasa de Resintesis, Capacidad / Rendimiento Total, Factor Limitante).
   Key Point: Prescripcion de Carbohidratos (Fuentes Principales, Metas Diarias en g/kg/dia, Protocolo Agudo Post-Ejercicio).
Step 2: Detallar la mecanica fisiologica del Concepto de Cruce de Brooks y estructurar la recuperacion de glucogeno (1.0 a 1.2 g CHO/kg/h + 0.3 g proteina/kg).
Step 3: Mantener todas las formulas en texto plano y los datos entre delimitadores (###).
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 06 — Micronutrientes e Hidratación (Vitaminas, Minerales y Electrolitos)

En palabras sencillas (Contexto Norteño): las vitaminas y los minerales (como el hierro, calcio, sodio y potasio) no tienen calorías, pero son las bujías que hacen que la sangre lleve oxígeno y que los músculos no se acalambren en el sol. Si las tablas de micronutrientes se ponen pesadas la próxima semana, concéntrate primero en cómo cubrir el hierro, el calcio y los electrolitos con comida real (verduras verdes, cítricos, frijoles, lácteos) sin caer en megadosis peligrosas de pastillas.

- Patrón (Contexto): Detectar deficiencias comunes de micronutrientes (hierro, calcio, vitamina D y electrolitos en el sudor) en personas activas.
- Regla (Restricción): Cubrir las recomendaciones de DGA 2025–2030 con alimentos reales respetando los límites máximos seguros (UL).
- Solución (Intervención): Completar el Foro del Mód 06 (Micronutrients & Electrolytes) y el Laboratorio del Mód 06 (Micronutrient & Electrolyte Audit) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 05 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 05:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 05)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
