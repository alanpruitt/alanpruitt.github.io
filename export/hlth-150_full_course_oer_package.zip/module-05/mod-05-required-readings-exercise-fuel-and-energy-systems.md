## HLTH-150: Mod 05 Required Readings Exercise Fuel And Energy Systems

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 05 Required Readings: Exercise Fuel & Energy Systems

Lecturas Obligatorias y Recursos de Estudio: Sistemas Energéticos, Cinética de Sustratos y Metabolismo


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Bioenergetics explains how your cells produce ATP (adenosine triphosphate, the body's immediate chemical energy currency) across different exercise intensities. Short explosive efforts burn stored phosphocreatine and glucose, while longer endurance sessions rely on oxygen, carbohydrates, and fats. Matching whole-food fueling to the active energy system keeps athletes performing safely.


#### En Palabras Sencillas (Norteño Context)

Tu cuerpo tiene tres cambios de velocidad como una transmisión: uno rápido para arrancar pesado y otro constante para aguantar toda la ruta. Si los términos técnicos se ponen pesados, concéntrate primero en qué combustible usa cada sistema de energía según la intensidad y duración del ejercicio.


### Required SSoT Text & Professional Nutrition Guidelines

Primary Single Source of Truth (SSoT): Dietary Guidelines for Americans (DGA / USDA) • Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) .

Federal SSoT Anchor: Macronutrient distribution ranges and carbohydrate availability requirements to sustain hepatic and intramuscular glycogen stores during physical exertion.

- Official Guidelines Portal: Dietary Guidelines for Americans Official Portal: Macronutrients & Energy Balance
Primary Physical Activity Anchor: Chapter 2: Physical Activity Guidelines for Adults • Energy Expenditure, Substrate Utilization, and Metabolic Adaptations.

- Light Activity (low-intensity or skill-based, 30 to 45 min/day): 3 to 5 g/kg/day
- Moderate Training (moderate intensity, approx. 1 hr/day): 5 to 7 g/kg/day
- High-Endurance Program (moderate-to-high intensity, 1 to 3 hrs/day): 6 to 10 g/kg/day
- Extreme Commitment (multi-hour intense training, >4 hrs/day): 8 to 12 g/kg/day

### Regional Focus: Substrate Utilization & Heat Stress in Yuma County

Enfoque Regional: Utilización de Sustratos y Estrés Térmico en el Condado de Yuma

In Yuma County and regional desert border communities, high ambient temperatures accelerate muscle glycogenolysis. Thermal strain elevates circulating catecholamines (epinephrine), which increases reliance on intramuscular glycogen and shifts the bioenergetic crossover point toward carbohydrates even at moderate work rates. For agricultural field harvesters and tactical athletes, premature glycogen depletion accelerates physical exhaustion and impairs decision-making. Sports nutritionists structure accessible, whole-food carbohydrate strategies paired with electrolyte hydration to sustain cellular ATP resynthesis.

En el condado de Yuma y las comunidades del desierto, el calor ambiental acelera la glucogenólisis muscular. El estrés térmico eleva la adrenalina plasmática, aumentando la dependencia de los carbohidratos y acelerando el agotamiento del glucógeno. Para los trabajadores del campo y atletas tácticos, los profesionales de nutrición deportiva estructuran planes con alimentos reales ricos en carbohidratos complejos y electrólitos para sostener la resíntesis de ATP.


### Reading 1: The Bioenergetic Energy Continuum

Lectura 1: El Continuo Bioenergético y Resíntesis de ATP

Adenosine Triphosphate (ATP) is the sole direct chemical currency powering muscular cross-bridge cycling. Because intramuscular ATP concentrations are small (~5 to 6 mmol/kg wet muscle), three integrated metabolic pathways resynthesize ATP to match energy demand:


### Reading 2: The Crossover Concept & Glycogen Replenishment

Lectura 2: El Concepto de Cruce de Sustratos y Resíntesis de Glucógeno


#### Step 1: Brooks Crossover Concept & Substrate Kinetics

Concepto de Cruce de Brooks y Cinética de Combustibles

At rest and during low-intensity aerobic exertion (below 50% VO2max), the body derives the majority of its energy from beta-oxidation of free fatty acids. As exercise intensity increases toward the anaerobic threshold (lactate threshold), relative fat oxidation declines while carbohydrate oxidation rises progressively. The exact exercise intensity where carbohydrate energy contribution surpasses lipid oxidation is defined as the Crossover Point , driven by the recruitment of glycolytic Type II fast-twitch muscle fibers and sympathetic epinephrine release.


#### Step 2: Post-Exercise Glycogen Resynthesis Window

Ventana de Resíntesis de Glucógeno Post-Ejercicio

Because intramuscular glycogen stores are finite (~300 to 500 grams), prolonged or high-intensity activity depletes storage pools, triggering acute fatigue ("hitting the wall"). To maximize glycogen synthase activity during recovery:

- Acute Window (0 to 4 hours post-exercise): Consume 1.0 to 1.2 grams of carbohydrate per kilogram of body weight per hour (1.0 to 1.2 g/kg/hr) during the initial 4 hours.
- Protein Pairing: Co-ingesting 0.25 to 0.40 g protein/kg accelerates glycogen storage rates while initiating muscle protein synthesis and tissue repair.

### Key Terminology / Glosario Clave

The ratio between the volume of carbon dioxide produced and the volume of oxygen consumed (RER = VCO2 / VO2). An RER of 0.70 indicates 100% lipid oxidation, 0.85 reflects a balanced 50/50 mixture of fats and carbohydrates, and 1.00 indicates 100% carbohydrate oxidation.

Relación entre el CO2 producido y el O2 consumido (RER = VCO2 / VO2). Un valor de 0.70 representa 100% de grasas, 0.85 mezcla equilibrada y 1.00 100% de carbohidratos.

The exercise power output or intensity where the proportional contribution of carbohydrate oxidation exceeds that of fat oxidation, governed by fast-twitch fiber recruitment and hormonal epinephrine spikes.

La intensidad de ejercicio donde el aporte energético de los carbohidratos supera al de las grasas debido al reclutamiento de fibras rápidas y la secreción de adrenalina.

An aerobic mitochondrial process requiring 2 to 5 minutes of passive or active recovery to replenish intramuscular phosphocreatine stores following maximal anaerobic exertion.

Proceso mitocondrial aeróbico que requiere de 2 a 5 minutos de descanso para restaurar las reservas de fosfocreatina muscular tras esfuerzos máximos.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Bioenergética

Select each question below to confirm your understanding of metabolic pathways before starting Discussion 05 and Lab 05:

English Response: The Phosphagen system (ATP-PCr) possesses the highest power (fastest rate of ATP resynthesis) but the lowest capacity (<10 seconds). In contrast, Oxidative Phosphorylation possesses the lowest power but the highest capacity (virtually unlimited ATP yield over hours of activity).

Respuesta en Español: El sistema de fosfágenos (ATP-PCr) tiene la mayor potencia (tasa más rápida de resíntesis) pero la menor capacidad (<10 segundos). La fosforilación oxidativa tiene la menor potencia pero la mayor capacidad (ilimitada durante horas).

English Response: As exercise intensity increases, the central nervous system recruits high-threshold Type II fast-twitch muscle fibers (which are rich in glycolytic enzymes) and triggers sympathetic release of epinephrine. Epinephrine stimulates glycogen phosphorylase, accelerating muscle glycogen breakdown and forcing carbohydrates to become the dominant fuel source.

Respuesta en Español: Al elevar la intensidad, se reclutan fibras rápidas Tipo II (ricas en enzimas glucolíticas) y aumenta la adrenalina, estimulando la glucogenólisis y haciendo que los carbohidratos sean el sustrato dominante.

English Response: Sports nutrition guidelines mandate consuming Outcome 1.0: to 1.2 grams of carbohydrate per kilogram of body weight per hour (1.0 to 1.2 g/kg/hr) during the first 4 hours following exhaustive glycogen-depleting exercise, ideally paired with 0.25 to 0.40 g protein/kg.

Respuesta en Español: Se recomienda consumir de Outcome 1.0: a 1.2 gramos de carbohidratos por kilogramo de peso corporal por hora durante las primeras 4 horas posteriores al ejercicio agotador, acompañado de 0.25 a 0.40 g de proteína/kg.


### AI Simulation Workspace • Bioenergetics Simulation

Copy the prompt below into Gemini to audit client energy system demands, calculate macronutrient fueling targets, and structure post-workout glycogen recovery plans:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: HLTH-150 Module 05 Bioenergetics Tool Box ###:
Role: Sports Nutritionist and Exercise Metabolism Specialist in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA / USDA) & Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed).

Instructions:
Step 1: Review the candidate client case data enclosed within triple-hashes (###) below.
Step 2: PATTERN: Identify the primary energy system (Phosphagen, Fast Glycolysis, or Oxidative) powering their target activity duration and intensity, explaining the substrate kinetics (carbohydrate vs. fat oxidation).
Step 3: RULE: Apply federal DGA and sports nutrition standards to determine daily carbohydrate requirements (g/kg/day) based on training volume.
Step 4: SOLVE: Calculate an individualized post-workout recovery target (1.0 to 1.2 g carbohydrate/kg/hr + 0.3 g protein/kg) with whole-food examples.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
Client Body Mass: [e.g., 70 kg / 154 lbs]
Primary Activity / Sport: [e.g., Cross-country runner vs. High-intensity interval lifter]
Session Duration & Intensity: [e.g., 90 minutes at 75% VO2max]
Current Dietary Intake: [e.g., Low-carbohydrate intake, experiencing late-session fatigue]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 05 (Mod 05 Required Readings: Exercise Fuel & Energy Systems)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Lecturas Obligatorias: Bioenergética y Metabolismo del Ejercicio


### Texto Fuente SSoT y Lineamientos de Nutrición Deportiva

Fuente Única de Verdad (SSoT): Guías Alimentarias para los Estadounidenses (DGA / USDA) • Pautas de Actividad Física (PAGA 2018, 2.ª edición) .

Portal Oficial DGA: Macronutrientes y Balance Energético

- Actividad Ligera (30 a 45 min/día): 3 a 5 g/kg/día
- Entrenamiento Moderado (~1 hr/día): 5 a 7 g/kg/día
- Alta Resistencia (1 a 3 hrs/día): 6 a 10 g/kg/día
- Resistencia Extrema (>4 hrs/día): 8 a 12 g/kg/día

### Conceptos Científicos Centrales


#### Step 1: El Continuo Bioenergético y Resíntesis de ATP

El ATP es la moneda energética directa de la contracción muscular. El sistema de fosfágenos (ATP-PCr) aporta energía inmediata de máxima potencia pero capacidad limitada (<10 s); la glucólisis anaeróbica sostiene esfuerzos intensos (30 s a 2 min); y la fosforilación oxidativa aporta energía ilimitada a menor tasa para actividades prolongadas.


#### Step 2: Concepto de Cruce y Recuperación de Glucógeno

Al aumentar la intensidad, el aporte energético de los carbohidratos supera al de las grasas (Punto de Cruce). La recuperación post-ejercicio exige reponer de 1.0 a 1.2 g de carbohidratos/kg/hora durante las primeras 4 horas junto con 0.3 g de proteína/kg para maximizar la síntesis de glucógeno.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 05 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 05:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 05)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
