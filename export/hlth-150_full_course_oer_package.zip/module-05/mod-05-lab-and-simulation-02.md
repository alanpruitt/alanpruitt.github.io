# HLTH-150: Mod 05 Lab And Simulation 02

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición Deportiva y para el Ejercicio


## Mod 05 Coaching Sprint Simulation: Matching Food Fuel to Workout Intensity

Sesión de Coaching del Módulo 05: Sistemas Energéticos y Bioenergética

- Substrate Utilization & The Crossover Concept: At rest and low intensities, fat oxidation predominates; as exercise intensity crosses above ~60–65% VO2max, muscle glycogen becomes the primary fuel. En palabras sencillas: Al caminar suave quemas más grasa, pero cuando subes la intensidad el músculo exige carbohidratos como combustible principal.
- ATP-PCr, Glycolytic, and Oxidative Fuel Matching: Matching whole-food carbohydrate and caloric intake to the dominant energy pathway of the client's sport or occupational workload. En palabras sencillas: Ajustar la cantidad de carbohidratos del plato según la duración e intensidad real del entrenamiento o jornada laboral.
- Fatigue from Glycogen Depletion ('Hitting the Wall'): Exhausting muscle and liver glycogen during prolonged sessions (>60–90 min) forces a sharp drop in pace unless exogenous carbohydrates are supplied. En palabras sencillas: Cuando se vacía el tanque de glucógeno después de más de una hora intensa y el cuerpo ya no puede sostener el ritmo.
- HLTH-150.5.1.AY26-27: Differentiate between ATP-PC (phosphagen), glycolytic, and oxidative energy systems during rest and varying exercise intensities. Diferenciar entre sistemas energéticos (ATP-PC, glucolítico y oxidativo) en reposo y diversas intensidades de ejercicio.
- HLTH-150.5.2.AY26-27: Apply bioenergetic principles and nutrient substrate utilization (carbohydrates vs. fats) to support energy balance and athletic performance. Aplicar principios bioenergéticos y utilización de sustratos para apoyar el balance energético y el rendimiento atlético.

### Your Weekly Win: Powering Human Cellular Energy

How does the human body instantly switch from explosive sprinting power to sustained endurance pacing? Through bioenergetics! The body relies on three distinct energy systems—ATP-PC (phosphagen), glycolysis, and oxidative phosphorylation—depending on exercise intensity and duration, utilizing carbohydrates and fats as metabolic fuel. Choose your coaching track below, chat with your AI Socratic Coach, and master energy system science!

¿Cómo cambia el cuerpo humano de potencia explosiva a resistencia sostenida? ¡A través de la bioenergética! El cuerpo utiliza tres sistemas energéticos distintos según la intensidad y duración. ¡Elija su ruta y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés vocacional

Scenario: Adult with metabolic inflexibility (Arthur, 55) who struggles to transition between fat oxidation at rest and carbohydrate utilization during activity at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Metabolic Health Path
[CLIENT]: Metabolic Inflexibility Patient (Arthur, 55) | [LOCATION]: Yuma, AZ
[SITUATION]: Experiences chronic fatigue and sluggish energy transitions due to impaired mitochondrial substrate oxidation and metabolic inflexibility.
[COACHING GOAL]: Explain bioenergetic pathways (oxidative vs. glycolytic) and dietary strategies to restore metabolic flexibility and cellular energy efficiency.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Lifestyle Medicine.
###
```

Scenario: Youth basketball player (Liam, 14) who plays intense high-speed intervals and gets completely gassed in the fourth quarter due to poor phosphagen system recovery.


```text
###
[TRACK]: Track 2 - Community & Youth Coaching Path
[CLIENT]: Youth Basketball Athlete (Liam, 14) | [LOCATION]: Yuma County, AZ
[SITUATION]: Exhausts phosphagen and glycolytic energy reserves rapidly during high-intensity full-court sprints without adequate nutritional recovery between quarters.
[COACHING GOAL]: Educate the athlete on ATP-PC and glycolytic energy systems, highlighting how quick-acting carbohydrates support repeated sprint performance.
[COMMUNITY SITE]: Yuma County Public Health Services District & Parks Recreation Centers.
###
```

Scenario: Endurance triathlete (Sofia, 29) trying to balance fat adaptation training with carbohydrate oxidation during high-intensity race pace efforts.


```text
###
[TRACK]: Track 3 - Adult Fitness & Endurance Coaching Path
[CLIENT]: Endurance Triathlete (Sofia, 29) | [LOCATION]: Yuma, AZ
[SITUATION]: Balances low-intensity aerobic fat oxidation with high-intensity glycolytic threshold efforts, seeking optimal substrate utilization strategies.
[COACHING GOAL]: Analyze oxidative versus glycolytic bioenergetics and prescribe targeted nutrition to optimize dual-fuel utilization for endurance racing.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: HLTH-150 Energy Systems & Bioenergetics Tool Box ###:
Role: Supportive HLTH-150 Sports Nutrition Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Dietary Guidelines for Americans (DGA / USDA) & Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms the three energy systems (ATP-PC, Glycolytic, Oxidative) and substrate utilization (carbohydrates vs. fats) relative to the client's activity profile.
Step 3: Guide the student to give their client ONE practical nutritional strategy or bioenergetic adjustment to optimize their performance.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how bioenergetics governs cellular energy production.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's bioenergetic challenge or metabolic goal.
- Energy Systems & Bioenergetics Analysis: Explain how the ATP-PC, glycolytic, and oxidative systems operate relative to your client's needs.
- My Practical Bioenergetic Strategy: Provide 1 clear, evidence-based nutritional or metabolic recommendation.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying how the Crossover Concept and 2025–2030 Dietary Guidelines whole-food carbohydrates and fats fuel your Yuma client's workout intensity safely.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 05 Coaching Sprint • Track 3 (Endurance / Sofia)

- Chosen Track & Client: Track 3: Adult Fitness & Endurance Coaching (Sofia, 29). Challenge: Sofia is balancing low-intensity aerobic fat oxidation with high-intensity glycolytic threshold efforts, seeking optimal dual-fuel substrate utilization strategies.
- Track 3: Adult Fitness & Endurance Coaching (Sofia, 29).
- Challenge: Sofia is balancing low-intensity aerobic fat oxidation with high-intensity glycolytic threshold efforts, seeking optimal dual-fuel substrate utilization strategies.
- Energy Systems & Bioenergetics Analysis: Oxidative vs. Glycolytic Pathways: At lower aerobic intensities, the oxidative system predominantly oxidizes fats for sustained ATP production. As intensity increases toward race pace, the glycolytic system scales up to rapidly break down carbohydrates for faster energy output. Balancing substrate utilization requires targeted aerobic base training alongside structured carbohydrate fueling during high-intensity intervals.
- Oxidative vs. Glycolytic Pathways: At lower aerobic intensities, the oxidative system predominantly oxidizes fats for sustained ATP production. As intensity increases toward race pace, the glycolytic system scales up to rapidly break down carbohydrates for faster energy output.
- Balancing substrate utilization requires targeted aerobic base training alongside structured carbohydrate fueling during high-intensity intervals.
- My Practical Bioenergetic Strategy for Sofia: "Incorporate targeted Zone 2 aerobic training to enhance mitochondrial fat oxidation capacity, while introducing 30 to 60 grams of carbohydrates per hour during high-intensity threshold workouts to fuel the glycolytic pathway."
- "Incorporate targeted Zone 2 aerobic training to enhance mitochondrial fat oxidation capacity, while introducing 30 to 60 grams of carbohydrates per hour during high-intensity threshold workouts to fuel the glycolytic pathway."
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, social media keto and zero-carb fads ignore the bioenergetic Crossover Concept: once exercise intensity rises above 65% to 70% VO2max, sympathetic drive and fast-twitch fiber recruitment make muscle glycogen and blood glucose the mandatory fuel source. Under the 2025–2030 Dietary Guidelines for Americans, fueling high-intensity intervals with whole-food complex carbohydrates (oats, pinto beans, corn tortillas, and fruit) prevents glycogen depletion ('bonking'), while low-to-moderate walking relies primarily on aerobic fat oxidation. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- My Memorable Coaching Takeaway: EN: "Bioenergetics teaches us that endurance is fueled by fat, while peak performance is powered by carbohydrates!" ES: "¡La bioenergética nos enseña que la resistencia se alimenta de grasa, mientras que el máximo rendimiento funciona con carbohidratos!"
- EN: "Bioenergetics teaches us that endurance is fueled by fat, while peak performance is powered by carbohydrates!"
- ES: "¡La bioenergética nos enseña que la resistencia se alimenta de grasa, mientras que el máximo rendimiento funciona con carbohidratos!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M05_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 05 (Mod 05 Coaching Sprint: Matching Food Fuel to Workout Intensity)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición Deportiva y para el Ejercicio


## Módulo 05 Simulación de Coaching: Sistemas Energéticos y Bioenergética

Evaluación Rápida y Aprendizaje Práctico de la Bioenergética Celular


### Su Logro Semanal: Impulsando la Energía Celular Humana

Esta sesión le permitirá entender cómo el cuerpo cambia entre sistemas energéticos (ATP-PC, glucolítico y oxidativo) según la intensidad y duración. Aprenda a relacionar la utilización de sustratos con el rendimiento. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: HLTH-150 Sistemas Energeticos y Bioenergetica ###:
Rol: Coach de Nutricion Deportiva de HLTH-150 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Guias Alimentarias (DGA / USDA) y Pautas de Actividad Fisica (PAGA 2018, 2.a edicion).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla los tres sistemas energeticos (ATP-PC, Glucolitico, Oxidativo) y la utilizacion de sustratos (carbohidratos vs. grasas) segun el perfil de actividad.
Step 3: Guiar al estudiante para proponer UNA estrategia nutricional practica o ajuste bioenergetico para optimizar el rendimiento de su cliente.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la bioenergetica rige la produccion de energia celular.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío bioenergético o meta metabólica de su cliente.
- Análisis de Sistemas Energéticos y Bioenergética: Explique cómo operan los sistemas ATP-PC, glucolítico y oxidativo en relación con las necesidades de su cliente.
- Mi Estrategia Bioenergética Práctica: Escriba 1 recomendación nutricional o metabólica clara y basada en evidencia.
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica justificando cómo el Concepto de Cruce (Crossover) y los alimentos reales de las DGA 2025–2030 sostienen la intensidad del ejercicio en Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Ejemplo de La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): "En mi juicio clínico, las dietas extremas sin carbohidratos ignoran el Concepto de Cruce bioenergético: al superar el 65%–70% del esfuerzo máximo, el músculo depende obligatoriamente del glucógeno. Con alimentos reales de las Pautas DGA 2025–2030 como avena, frijoles, tortillas de maíz y fruta, protegemos el rendimiento y evitamos la fatiga aguda en Yuma."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:
