## HLTH-150: Mod 05 Lab And Simulation 01

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 05 Lab & Simulation: Exercise Fuel & Energy Systems Audit

Laboratorio del Módulo 05: Auditoría de Bioenergética y Prescripción de Sustratos

- Substrate Utilization & The Crossover Concept: At rest and low intensities, fat oxidation predominates; as exercise intensity crosses above ~60–65% VO2max, muscle glycogen becomes the primary fuel. En palabras sencillas: Al caminar suave quemas más grasa, pero cuando subes la intensidad el músculo exige carbohidratos como combustible principal.
- ATP-PCr, Glycolytic, and Oxidative Fuel Matching: Matching whole-food carbohydrate and caloric intake to the dominant energy pathway of the client's sport or occupational workload. En palabras sencillas: Ajustar la cantidad de carbohidratos del plato según la duración e intensidad real del entrenamiento o jornada laboral.
- Fatigue from Glycogen Depletion ('Hitting the Wall'): Exhausting muscle and liver glycogen during prolonged sessions (>60–90 min) forces a sharp drop in pace unless exogenous carbohydrates are supplied. En palabras sencillas: Cuando se vacía el tanque de glucógeno después de más de una hora intensa y el cuerpo ya no puede sostener el ritmo.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Bioenergetics describes how human cells convert food into chemical energy (ATP) to power muscle contractions during exercise. Short, explosive sprints burn stored phosphagens and glucose without oxygen, while sustained endurance activities rely on oxygen to burn fats and carbohydrates. Matching carbohydrate intake to training intensity prevents premature glycogen exhaustion and speeds cellular recovery.


#### En Palabras Sencillas (Norteño Context)

Los sistemas de energía del cuerpo son como la transmisión de una troca: metes primera para arrancar con fuerza en una subida, pero cambias a quinta para avanzar parejito en la carretera sin gastar de más. Si los términos técnicos se ponen pesados, concéntrate primero en saber cuándo el cuerpo quema grasa y cuándo necesita carbohidratos de volada.


### Bioenergetic Pathways, Substrate Crossover Kinetics, & Glycogen Replenishment

In this laboratory assignment, you will conduct a qualitative bioenergetic audit and construct an evidence-based substrate prescription. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze ATP resynthesis, crossover substrate kinetics (fats vs. carbohydrates), and metabolic fatigue, apply 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) standards, and execute an AI-driven clinical simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría bioenergética cualitativa y diseñará una prescripción de sustratos basada en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando la resíntesis de ATP y la cinética de sustratos según las Guías Alimentarias para los Estadounidenses 2025-2030.

- HLTH-150.5.3.AY26-27: Differentiate the power and capacity of the phosphagen, glycolytic, and oxidative energy systems during varied exercise intensities. Diferenciar la potencia y capacidad de los sistemas de fosfágenos, glucolítico y oxidativo durante diferentes intensidades de ejercicio.
- HLTH-150.5.4.AY26-27: Design evidence-based macronutrient fueling and glycogen recovery protocols aligned with the 2025-2030 Dietary Guidelines for Americans. Diseñar protocolos de nutrición y recuperación de glucógeno basados en evidencia y alineados con las Guías Alimentarias para los Estadounidenses 2025-2030.
- Module Window / Ventana del Módulo: Opens Tuesday, September 15, 2026, at 12:00 AM MST Abre el martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Submission Window / Ventana de Entrega Actual: Reopened through Monday, October 26, 2026, at 11:59 PM MST Reabierto hasta el lunes, 26 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Mastery Scale) Ponderación de evaluación para laboratorios semanales y simulaciones prácticas (Escala de Dominio 10/7/0)

### Lab Objectives / Objetivos del Laboratorio

Objetivos del Laboratorio

- Audit the ATP resynthesis rates, enzymatic power, and total storage capacities of the phosphagen, anaerobic glycolytic, and aerobic oxidative pathways. Auditar las tasas de resíntesis de ATP, la potencia enzimática y las capacidades de almacenamiento de las vías energéticas.
- Apply the 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) to evaluate substrate utilization shifts across the aerobic-anaerobic crossover threshold. Aplicar las Guías Alimentarias para los Estadounidenses 2025-2030 para evaluar los cambios en la utilización de sustratos en el umbral de cruce.
- Formulate a 4-week bioenergetic nutrition and glycogen replenishment protocol paired with bilingual coaching cue cards in English and Spanish. Formular un protocolo de nutrición bioenergética y reposición de glucógeno de 4 semanas con tarjetas de instrucción bilingües en inglés y español.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-05

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos del Caso Bioenergético

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Metabolic inflexibility; blunted fat oxidation, impaired mitochondrial enzyme activity, and early lactate accumulation in an adult with prediabetes at Matador Clinical Partners.

Focus: Intermittent sprint recovery; ATP-PCr depletion, rapid lactic acidosis, and nutrition fueling for a youth basketball player in Yuma County Parks and Recreation.

Focus: Dual-fuel substrate utilization; glycogen sparing, fat adaptation, and intra-workout fueling for a collegiate triathlete at Arizona Western College.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete bioenergetics audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline bioenergetic profile.
- Part 1: Pattern Recognition: Identify specific energy system limitations (ATP-PCr depletion, premature glycolytic shift, or metabolic inflexibility).
- Part 2: Rule Application: Cite 2025-2030 Dietary Guidelines for Americans whole-food standards, Crossover Concept kinetics, and glycogen resynthesis thresholds.
- Part 3: Solving the Gap: Detail a comprehensive 4-week bioenergetic remediation plan (intensity pacing and real-food fueling) with a 2-sentence bilingual coaching cue card.
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why your whole-food substrate timing and Crossover Concept intensity prescription outperform commercial pre-workout powders or restrictive fad diets.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient A.R. exhibits marked metabolic inflexibility, characterized by impaired mitochondrial beta-oxidation and an inability to utilize fatty acids during low-intensity physical activity. At a slow walking pace (2.5 mph), his Respiratory Exchange Ratio (RER) rises abnormally to 0.94, indicating an almost exclusive reliance on carbohydrate metabolism. This premature shift depletes limited intramuscular glycogen reserves within 20 minutes, driving severe autonomic fatigue, muscle weakness, and post-exercise hypoglycemia.

Part 2: Rule Application (2025-2030 Dietary Guidelines for Americans Standards): Under the 2025-2030 Dietary Guidelines for Americans ("Real Food" Focus) and bioenergetic exercise standards, restoring metabolic flexibility requires anchoring training in the low-intensity oxidative domain (Zone 2, below the lactate threshold, targeting RER 0.75-0.82) to stimulate mitochondrial biogenesis and fat oxidation enzyme capacity. Dietary rules mandate eliminating ultra-processed added sugars and replacing refined starches with nutrient-dense, fiber-rich whole carbohydrates (minimum 35g fiber/day) paired with moderate healthy fats to stabilize insulin kinetics.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): 4-Week Bioenergetic Restoration Protocol (3 Days/Week): Key Point — Weeks 1-2 (Oxidative Zone 2 Base): 25 minutes of continuous recumbent cycling or flat treadmill walking at 55%-60% HRmax (RPE 10-11, conversing without breathlessness), maintaining pure aerobic fat oxidation without triggering glycolytic lactate accumulation. Key Point — Weeks 3-4 (Progressive Aerobic Extension): Advance duration to 35-40 minutes at 60%-65% HRmax; introduce 5-minute warm-up and cool-down ramps. Key Point — Real-Food Fueling Schedule: 90 minutes prior to session, consume 1/2 cup cooked pinto beans with 1 corn tortilla and sliced avocado (approx. 28g slow-digesting complex carbohydrate, 8g fiber, 7g healthy fat). Post-session: 1 cup plain unsweetened kefir with 1/4 cup walnuts to preserve cellular recovery without spiking insulin.

EN: "Keep your walking pace comfortable enough that you can speak in full sentences without gasping, teaching your muscles to burn fat efficiently. Eat a small portion of beans and avocado before your walk to keep your energy steady without causing blood sugar spikes."

ES: "Mantenga un paso cómodo al caminar que le permita hablar en oraciones completas sin sofocarse, enseñando a sus músculos a quemar grasa de manera eficiente. Coma una porción pequeña de frijoles con aguacate antes de caminar para mantener su energía estable sin subir su azúcar."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI nutrition plan frequently prescribes high-glycemic sugary gels or extreme carbohydrate restriction without matching substrate kinetics to the client's actual exercise intensity. By applying the Crossover Concept and the 2025–2030 Dietary Guidelines for Americans, I calibrate fuel directly to bioenergetic demand: low-to-moderate Zone 2 walking (55%–65% HRmax, RPE 10–11) maximizes mitochondrial beta-oxidation of fatty acids, while pairing a pre-session meal of pinto beans, corn tortilla, and avocado stabilizes blood glucose and spares muscle glycogen in Yuma's desert climate. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_150_M05_Bioenergetics_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 05 (Mod 05 Lab: Exercise Fuel & Energy Systems Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 05 Práctica de Lab y Simulación: Auditoría de Bioenergética y Prescripción de Sustratos

Vías Bioenergéticas, Cinética de Cruce de Sustratos y Reposición de Glucógeno


### Vías Bioenergéticas, Cinética de Cruce de Sustratos y Reposición de Glucógeno

En esta práctica de laboratorio, realizará una auditoría bioenergética cualitativa y diseñará una prescripción de sustratos basada en evidencia. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará la resíntesis de ATP, la cinética de cruce de sustratos (grasas vs. carbohidratos) y la fatiga metabólica, aplicando las Guías Alimentarias para los Estadounidenses 2025-2030 ("Enfoque en Alimentos Reales") y ejecutará una simulación con Google Gemini.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Inflexibilidad metabólica; oxidación embotada de grasas, actividad enzimática mitocondrial deficiente y acumulación temprana de lactato en un adulto con prediabetes.

Enfoque: Recuperación de sprints intermitentes; agotamiento de ATP-PCr, acidosis láctica rápida y alimentación para un jugador juvenil de básquetbol.

Enfoque: Utilización de sustratos duales; ahorro de glucógeno, adaptación a las grasas y alimentación intra-entrenamiento para una triatleta universitaria en AWC.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Comunitaria / Ruta 3 Deportiva) e incluya sus iniciales.


#### Parte 1: Reconocimiento de Patrones

Identifique las limitaciones de los sistemas energéticos de su cliente (agotamiento de ATP-PCr, cambio glucolítico prematuro o inflexibilidad metabólica).


#### Parte 2: Aplicación de Reglas (DGA 2025-2030)

Aplique los estándares de alimentos reales de las Guías Alimentarias 2025-2030, la cinética del Concepto de Cruce y los umbrales de resíntesis de glucógeno.


#### Parte 3: Resolución de la Brecha

Detalle el plan de remediación bioenergética de 4 semanas con alimentos integrales, junto con una tarjeta de instrucción bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


#### Parte 4: Verificación Activa (Mínimo 150 Palabras en su Propia Voz Humana)

Escriba de mínimo 150 palabras en su propia voz humana clínica justificando por qué su prescripción de alimentos reales y el Concepto de Cruce superan a los suplementos comerciales o dietas restrictivas.


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: El paciente A.R. presenta una marcada inflexibilidad metabólica, caracterizada por una beta-oxidación mitocondrial deficiente y la incapacidad de oxidar ácidos grasos durante la actividad física de baja intensidad. A un ritmo de caminata lento (2.5 mph), su Cociente de Intercambio Respiratorio (RER) se eleva anormalmente a 0.94, lo que indica una dependencia casi exclusiva del metabolismo de carbohidratos. Este cambio prematuro agota las reservas de glucógeno en 20 minutos, provocando fatiga autonómica, debilidad muscular e hipoglucemia post-ejercicio.

Parte 2: Aplicación de Reglas (Guías Alimentarias 2025-2030): Según las Guías Alimentarias para los Estadounidenses 2025-2030 ("Enfoque en Alimentos Reales") y los estándares bioenergéticos, restaurar la flexibilidad metabólica requiere anclar el entrenamiento en el dominio oxidativo de baja intensidad (Zona 2, por debajo del umbral de lactato, buscando un RER de 0.75 a 0.82) para estimular la biogénesis mitocondrial. En la dieta, se deben eliminar azúcares añadidos ultraprocesados y reemplazar harinas refinadas por carbohidratos integrales densos en fibra (mínimo 35 g fibra/día) combinados con grasas saludables para estabilizar la insulina.

Parte 3: Resolución de la Brecha: Key Point — Semanas 1-2 (Base Oxidativa Zona 2): 25 minutos continuos de caminadora o bicicleta reclinada al 55%-60% de FCmáx (RPE 10-11, manteniendo conversación sin jadear), sosteniendo pura oxidación aeróbica de grasas. Key Point — Semanas 3-4 (Extensión Progresiva): Aumentar a 35-40 minutos al 60%-65% de FCmáx con calentamiento y enfriamiento de 5 minutos. Key Point — Plan de Alimentos Reales: 90 minutos antes, consumir 1/2 taza de frijoles pintos cocidos con 1 tortilla de maíz y aguacate rebanado (aprox. 28 g de carbohidratos complejos, 8 g de fibra, 7 g de grasa saludable). Post-sesión: 1 taza de kéfir natural sin azúcar con 1/4 taza de nueces para favorecer la recuperación celular sin elevar bruscamente la insulina. Tarjeta Bilingüe: "Mantenga un paso cómodo al caminar que le permita hablar en oraciones completas sin sofocarse, enseñando a sus músculos a quemar grasa de manera eficiente. Coma una porción pequeña de frijoles con aguacate antes de caminar para mantener su energía estable sin subir su azúcar."

Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, un plan genérico de IA suele recomendar geles azucarados o dietas cetogénicas extremas sin ajustar el combustible a la intensidad real del ejercicio. Aplicando el Concepto de Cruce y las Pautas Alimentarias DGA 2025–2030, mantenemos la caminata en Zona 2 (55%–65% FCmáx) para optimizar la oxidación aeróbica de grasas y utilizamos frijoles pintos, tortilla de maíz y aguacate para sostener la glucemia estable en el clima de Yuma."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M05_Bioenergetics_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 05)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
