## HLTH-150: Mod 03 Required Readings Whole Food Protein And Muscle Maintenance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Required Readings: Whole-Food Protein & Muscle Maintenance

Lecturas Obligatorias: Calidad Proteica, Cinética de Aminoácidos y Mantenimiento Muscular


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Dietary protein supplies essential amino acids—the building blocks your body uses to repair and grow muscle tissue. After resistance exercise or physical labor, whole-food protein triggers muscle protein synthesis (tissue rebuilding). Distributing quality protein across daily meals preserves lean muscle mass and strength.


#### En Palabras Sencillas (Norteño Context)

Después de entrenar fuerte, tus músculos quedan como una pared de adobe que necesita mezcla nueva de buena calidad para quedar más firme. Si los términos técnicos se ponen pesados, concéntrate primero en la meta diaria de proteína en gramos por kilogramo de peso corporal con alimentos reales.


### Required SSoT Text & Federal Guidelines

Single Source of Truth (SSoT): Dietary Guidelines for Americans (DGA) • Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) • Federal Dietary Reference Intakes (DRI) for Protein.

Dietary Guidelines for Americans: Protein Foods & Nutrient Density Guías Alimentarias para los Estadounidenses: Grupo de Alimentos Proteicos y Densidad Nutricional.

- Protein and Exercise Position Stand: ISSN Position Stand: Protein and Exercise (JISSN Open Access)
- Nutrition & Athletic Performance Consensus: ACSM / AND / DC Joint Position Stand: Nutrition and Athletic Performance
- PAGA 2018 Muscle-Strengthening Mandates: PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev)

### Regional Focus: Lean Mass Preservation in the Desert Southwest

Enfoque Regional: Preservación de Masa Magra y Fuentes Proteicas en el Condado de Yuma

In Yuma County and agricultural border communities, active adults, field harvesters, and tactical personnel face sustained metabolic demands under intense summer heat. While commercial marketing promotes expensive, ultra-processed protein isolates and proprietary blends, clinical evidence demonstrates that accessible, affordable whole foods (eggs, poultry, dairy, legumes, and lean meats) provide complete essential amino acid profiles that stimulate muscle repair, support immune function, and prevent catabolism without costly commercial supplements.

En el condado de Yuma y las comunidades agrícolas de la frontera, los trabajadores de campo y las personas activas enfrentan una alta demanda metabólica bajo el calor extremo. Mientras el marketing comercial promueve costosos polvos y suplementos procesados, la evidencia científica demuestra que los alimentos reales y económicos (huevos, aves, lácteos, legumbres y carnes magras) aportan el perfil completo de aminoácidos esenciales para reparar el tejido muscular y evitar el catabolismo.


### Reading 1: Protein Requirements & Nitrogen Homeostasis

Lectura 1: Requerimientos de Proteína y Homeostasis de Nitrógeno


#### Step 1: Daily Protein Scaling Across Activity Tiers (DGA & PAGA SSoT)

Escalamiento Diario de Proteína según el Nivel de Actividad Física

The standard Recommended Dietary Allowance (RDA) of Outcome 0.8: g/kg/day represents the minimum baseline required to prevent gross clinical deficiency in sedentary populations. For active individuals meeting federal PAGA 2018 guidelines (150–300 minutes of moderate activity plus 2 days of muscle-strengthening work), protein requirements increase to support tissue remodeling and muscular adaptation:

La Ingesta Diaria Recomendada (RDA) de Outcome 0.8: g/kg/día es el mínimo para evitar deficiencias en personas sedentarias. Para individuos activos que cumplen con las pautas PAGA 2018 (150 a 300 minutos de actividad moderada más 2 días de fortalecimiento muscular), los requerimientos aumentan para permitir la adaptación y reparación muscular:

- Sedentary Adults (DGA Baseline): 0.8 g/kg/day (10%–35% AMDR of total daily calories). Adultos Sedentarios (Base DGA): 0.8 g/kg/día (10% a 35% del valor calórico total).
- Endurance Athletes & Active Laborers: 1.2 to 1.4 g/kg/day to compensate for amino acid oxidation during prolonged aerobic work. Atletas de Resistencia y Trabajadores Físicos: 1.2 a 1.4 g/kg/día para reponer la oxidación de aminoácidos durante el esfuerzo aeróbico prolongado.
- Resistance-Trained Athletes & Clinical Hypertrophy: 1.6 to 2.2 g/kg/day to maximize myofibrillar protein synthesis (MPS) and lean mass accrual. Atletas de Fuerza e Hipertrofia Clínica: 1.6 a 2.2 g/kg/día para maximizar la síntesis de proteína miofibrilar (MPS) y la masa magra.

### Reading 2: The Leucine Trigger & Anabolic Signaling

Lectura 2: El Disparador de Leucina y Señalización Celular mTORC1


#### Step 1: The Leucine Threshold & Per-Meal Bolus Pacing

El Umbral de Leucina y Dosificación por Comida

Myofibrillar protein synthesis operates under a "trigger" mechanism governed by the mechanistic target of rapamycin complex 1 (mTORC1). Leucine, an essential branched-chain amino acid (BCAA), acts as the primary molecular key that initiates translation. To trigger maximal MPS in young adults, a single meal must supply approximately Outcome 0.25: to 0.40 g/kg of high-quality protein , containing at least Outcome 2.5: to 3.0 grams of leucine . Consuming protein in evenly distributed boluses every 3 to 4 hours stimulates MPS more effectively than skewing intake toward a single large evening meal.

La síntesis de proteína miofibrilar opera mediante un mecanismo disparador regulado por la vía celular mTORC1. La leucina, un aminoácido esencial de cadena ramificada, actúa como la llave molecular para iniciar la síntesis. Para activar al máximo la MPS en adultos jóvenes, cada comida debe aportar entre Outcome 0.25: y 0.40 g/kg de proteína completa con al menos Outcome 2.5: a 3.0 gramos de leucina . Distribuir la ingesta cada 3 a 4 horas estimula la MPS de forma superior a concentrar toda la proteína en una sola comida nocturna.


#### Step 2: Anabolic Resistance & Sarcopenia in Aging Adults

Resistencia Anabólica y Sarcopenia en Adultos Mayores

As humans age (> 50 years), skeletal muscle tissue becomes less sensitive to circulating amino acids—a clinical phenomenon known as Anabolic Resistance . To overcome this blunt response and stimulate MPS in older adults or clinical patients undergoing orthopedic rehabilitation, per-meal protein targets must increase to Outcome 0.40: to 0.55 g/kg/meal (~35–40 g of high-quality whole-food protein delivering ~3.5–4.0 g leucine).

Con el envejecimiento (> 50 años), el músculo esquelético pierde sensibilidad a los aminoácidos circulantes, un fenómeno denominado Resistencia Anabólica . Para superar este umbral en adultos mayores o pacientes en rehabilitación, la proteína por comida debe elevarse a Outcome 0.40: a 0.55 g/kg/comida (~35 a 40 g de proteína integral que aporte ~3.5 a 4.0 g de leucina).


### Reading 3: Whole-Food Protein Quality & Complementary Proteins

Lectura 3: Calidad Proteica de Alimentos Reales y Complementación Vegetal

Protein quality is determined by essential amino acid completeness and bioavailability (DIAAS / PDCAAS scoring):

La calidad de una proteína se determina por la presencia completa de aminoácidos esenciales y su biodisponibilidad digestiva:


### Key Terminology / Glosario Clave

The cellular metabolic process of building new contractile muscle proteins (actin and myosin) from circulating essential amino acids, stimulated by mechanical resistance training and protein feeding.

Proceso celular que construye nuevas proteínas contráctiles (actina y miosina) a partir de aminoácidos esenciales, activado por el ejercicio de fuerza y la ingesta proteica.

The specific per-meal leucine threshold (~2.5 to 3.0 g in young adults; ~3.5 to 4.0 g in older adults) required to phosphorylate and activate the mTORC1 molecular signaling cascade.

El umbral de leucina por comida (~2.5 a 3.0 g en adultos jóvenes; ~3.5 a 4.0 g en adultos mayores) necesario para activar la vía de señalización molecular mTORC1.

A blunted muscle protein synthesis response to standard protein doses observed in aging populations, clinical bed rest, or severe caloric restriction.

Respuesta atenuada de la síntesis proteica ante dosis estándar de aminoácidos, observada en adultos mayores, reposo prolongado o restricción calórica severa.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of core protein kinetics before starting Discussion 03 and Lab 03:

English Response: The 0.8 g/kg RDA is a minimum baseline designed to prevent clinical nitrogen deficiency in sedentary adults. Resistance exercise causes microtrauma and accelerates protein breakdown; maintaining positive net muscle protein balance and driving hypertrophy requires 1.6 to 2.2 g/kg/day.

Respuesta en Español: La RDA de 0.8 g/kg es el mínimo para evitar deficiencias en personas sedentarias. El entrenamiento de fuerza genera microdaño y aumenta la degradación proteica; lograr un balance positivo y generar hipertrofia exige de 1.6 a 2.2 g/kg/día.

English Response: Muscle protein synthesis requires reaching a critical blood leucine concentration (~2.5–3.0 g leucine, or 20–40 g protein) to activate mTORC1. Ingesting evenly spaced boluses every 3 to 4 hours stimulates MPS multiple times per day, whereas eating small trace amounts fails to trigger the signaling cascade.

Respuesta en Español: La síntesis proteica requiere alcanzar una concentración crítica de leucina (~2.5 a 3.0 g por comida, o 20 a 40 g de proteína) para activar mTORC1. Distribuir estas dosis cada 3 a 4 horas estimula la MPS repetidamente durante el día, a diferencia de dosis pequeñas que no alcanzan el umbral.

English Response: Increasing single-meal protein boluses to 0.40–0.55 g/kg/meal (~35–40 g of high-quality protein supplying ~3.5–4.0 g leucine) overcomes age-related anabolic resistance and triggers robust muscle protein synthesis comparable to younger adults.

Respuesta en Español: Aumentar la proteína por comida a 0.40–0.55 g/kg (~35 a 40 g de proteína completa con ~3.5 a 4.0 g de leucina) supera la resistencia anabólica del envejecimiento y activa la síntesis muscular a niveles similares a los de personas jóvenes.


### AI Simulation Workspace • Protein Kinetics Simulation

Copy the prompt below into Gemini to test your ability to audit daily protein targets and whole-food meal distributions:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: HLTH-150 Module 03 Protein Tool Box ###:
Role: Clinical Sports Dietitian and Performance Nutrition Specialist.
SSoT: Dietary Guidelines for Americans (DGA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Audit the student's daily protein target calculation (g/kg/day) based on their client's activity level.
Step 2: Verify that each proposed meal reaches the leucine threshold (~2.5-3.0 g leucine for young adults; ~3.5-4.0 g for aging adults).
Step 3: Evaluate if the 4-meal distribution relies on accessible, affordable whole foods rather than commercial protein powders.
Step 4: Keep all client case inputs wrapped inside triple-hash (###) delimiters.

Client Data Input ###:
Client Age: [Insert Age]
Body Weight: [Insert kg or lbs]
Activity Level: [Insert Sedentary, Endurance, or Resistance Training]
Daily Protein Target: [Insert g/kg/day and total grams]
Proposed 4-Meal Whole-Food Distribution: [List meals]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 03 (Mod 03 Required Readings: Whole-Food Protein & Muscle Maintenance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Lecturas Obligatorias: Proteína Dietética y Cinética de Aminoácidos


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Guías Alimentarias para los Estadounidenses (DGA) • Pautas de Actividad Física (PAGA 2018, 2.ª ed.) • Ingestas Dietéticas de Referencia (DRI) para Proteína.

Guías Alimentarias para los Estadounidenses: Densidad Nutricional y Proteínas

- Postura de la ISSN sobre Proteína y Ejercicio: ISSN Position Stand: Protein and Exercise (JISSN)
- Consenso de Nutrición Deportiva: Postura Conjunta ACSM / AND / DC sobre Nutrición y Rendimiento Deportivo

### Conceptos Científicos Centrales


#### Step 1: Metas Diarias y Balance de Nitrógeno

La dosis basal de 0.8 g/kg/día evita deficiencias clínicas en personas sedentarias. Para personas activas bajo normas PAGA 2018, la ingesta asciende a 1.2–1.4 g/kg/día en resistencia aeróbica y a 1.6–2.2 g/kg/día en entrenamiento de fuerza para optimizar la masa muscular.


#### Step 2: El Disparador de Leucina y Resistencia Anabólica

Cada comida debe aportar de 2.5 a 3.0 g de leucina (20–40 g de proteína completa) distribuida cada 3 a 4 horas. En adultos mayores de 50 años, la resistencia anabólica exige aumentar la dosis a 0.40–0.55 g/kg por comida (~35–40 g de proteína).


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para asegurar un entorno de aprendizaje inclusivo, equitativo y accesible para toda nuestra comunidad estudiantil.

HLTH-150 • Module 03 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 03:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 03)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
