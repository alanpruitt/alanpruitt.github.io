## HLTH-150: Mod 03 Overview Whole Food Protein And Muscle Maintenance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 03 Overview: Whole-Food Protein & Muscle Maintenance


### Welcome to Module 03: Whole-Food Protein & Muscle Maintenance

Welcome to Week 3! This week, we analyze myofibrillar protein synthesis (MPS), essential amino acid (EAA) profiles, and metabolic nitrogen balance. Rather than relying on commercial powders and proprietary supplements, HLTH-150 establishes a food-first foundation anchored in federal evidence-based guidelines.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify muscle protein breakdown patterns across active populations, apply federal Dietary Guidelines for Americans (DGA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) protein targets (1.2–2.0 g/kg/day across activity tiers), and design practical, whole-food meal distributions meeting the per-meal leucine threshold.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 1, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 3, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 6, 2026, at 11:59 PM MST
- Lab 03 & Wrap-Up Due / Entrega de Laboratorio: Monday, September 7, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 03 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Distinguish between essential, non-essential, and branched-chain amino acids, and evaluate physiological mechanisms driving muscle protein breakdown and anabolic resistance. Distinguir los aminoácidos esenciales y de cadena ramificada, y evaluar los mecanismos de degradación proteica y resistencia anabólica.
- CLO 2 (Rule Application): Apply DGA and PAGA 2018 daily protein standards (0.8 g/kg RDA baseline up to 1.2–2.0 g/kg for exercisers) and the ~2.5–3.0g leucine threshold to optimize muscle protein synthesis. Aplicar estándares de DGA y PAGA 2018 (0.8 g/kg RDA hasta 1.2–2.0 g/kg en personas activas) y el umbral de leucina (~2.5–3.0g) para optimizar la síntesis proteica.
- CLO 3 (Problem Solving): Formulate an evidence-based, 4-meal daily protein distribution using affordable, accessible whole foods customized for clinical recovery, community active adults, or collegiate athletes. Diseñar un esquema de 4 comidas diarias con alimentos integrales y accesibles adaptado a la recuperación clínica, adultos activos o atletas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will apply protein kinetics within your chosen career track:

Combating age-related sarcopenia and anabolic resistance in physical therapy patients (E.V., 47) using leucine-rich whole foods and distributed intake during rehabilitation.

Preserving lean tissue and functional independence in agricultural and community populations in Yuma County through low-cost, complete whole-food protein sources.

Optimizing myofibrillar protein synthesis, per-meal leucine triggers (0.25–0.40 g/kg/meal), and recovery timing for collegiate multi-sport athletes (AWC Athletics).


### Module 03 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Protein Quality, Amino Acid Kinetics & Federal Standards
- Discussion Board 03: Protein Distribution & Leucine Thresholds
- Lab Assignment 03: Dietary Protein Audit, Nitrogen Balance & Gemini AI Tool Kit
- Module 03 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 03 (Mod 03 Overview: Whole-Food Protein & Muscle Maintenance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 03 Visión General: Proteína Dietética y Mantenimiento Muscular


### Bienvenido al Módulo 03: Calidad Proteica, Cinética de Aminoácidos y Síntesis Basada en Alimentos

¡Bienvenido a la Semana 3! Esta semana analizaremos la síntesis de proteína miofibrilar (MPS), el perfil de aminoácidos esenciales (EAA) y el balance de nitrógeno metabólico. En lugar de depender de polvos y suplementos comerciales, HLTH-150 prioriza una filosofía de "alimentos primero" fundamentada en estándares federales basados en evidencia.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará patrones de degradación proteica en personas activas, aplicará las metas de proteína de las Guías Alimentarias (DGA) y PAGA 2018 (2.ª ed.) (1.2 a 2.0 g/kg/día según la actividad), y diseñará esquemas prácticos de alimentación con alimentos integrales que alcancen el umbral de leucina en cada comida.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 1 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 3 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 6 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 03: Lunes, 7 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Distinguir entre aminoácidos esenciales, no esenciales y de cadena ramificada, y evaluar los mecanismos de degradación muscular y resistencia anabólica.
- CLO 2 (Regla): Aplicar los estándares de proteína de DGA y PAGA 2018 (0.8 g/kg basal hasta 1.2–2.0 g/kg en ejercicio) y el umbral de leucina (~2.5–3.0g) para maximizar la síntesis proteica.
- CLO 3 (Solución): Diseñar una distribución de 4 comidas diarias con alimentos integrales accesibles para la recuperación clínica, la salud comunitaria o el rendimiento deportivo.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, aplicará la cinética de proteínas a través de su ruta profesional:

Control de sarcopenia y resistencia anabólica en terapia física (E.V., 47) mediante alimentos ricos en leucina distribuidos estratégicamente.

Preservación de masa muscular y funcionalidad en trabajadores agrícolas y adultos de Yuma con fuentes proteicas integrales y económicas.

Optimización de la síntesis proteica, activación por leucina (0.25–0.40 g/kg/comida) y recuperación muscular para atletas universitarios de AWC.


### Ruta de Aprendizaje del Módulo 03

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Calidad Proteica, Cinética de Aminoácidos y Normas Federales
- Foro de Discusión 03: Distribución de Proteína y Umbrales de Leucina
- Laboratorio 03: Auditoría Dietética de Proteína, Balance de Nitrógeno y Gemini IA
- Comprobación de Conocimientos y Resumen del Módulo 03

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para asegurar un entorno de aprendizaje inclusivo, equitativo y accesible para toda nuestra comunidad estudiantil.


### Module 03 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 03 Required Readings: Whole-Food Protein & Muscle Maintenance →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 03 Discussion: Whole-Food Protein Sources on a Budget →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 03 Coaching Sprint: Spreading Protein Across Daily Meals →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 03 Lab: Daily Protein Needs & Muscle Maintenance Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 03 Summary & Wrap-Up: Whole-Food Protein & Muscle Maintenance →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 03)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
