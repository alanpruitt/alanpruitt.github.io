## HLTH-150: Mod 03 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 03) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Lab & Simulation: Daily Protein Needs & Muscle Maintenance Audit

Laboratorio del Módulo 03: Cinética de Aminoácidos, Umbrales de Leucina y Retención de Masa Magra

- Muscle Protein Synthesis (MPS) & Leucine Trigger (20–40 g/Meal): Consuming 20–40 g of high-quality protein (~0.25–0.40 g/kg, providing ~2.5–3 g leucine) every 3–4 hours maximizes muscle repair and remodeling. En palabras sencillas: Consumir de 20 a 40 gramos de proteína real en cada comida principal para encender la reparación y el mantenimiento muscular.
- Active Adult Protein Target (1.2–2.0 g/kg/day): Physically active individuals and strength/endurance athletes require 1.2–2.0 g/kg/day of protein from whole foods, above the sedentary RDA of 0.8 g/kg/day. En palabras sencillas: Quienes entrenan o hacen trabajo físico pesado necesitan entre 1.2 y 2.0 gramos de proteína por kilo de peso al día.
- Complementary Plant & Animal Real-Food Proteins: Combining legumes and whole grains (e.g., pinto beans + corn tortillas/rice) or lean poultry, eggs, fish, and yogurt to supply all 9 essential amino acids. En palabras sencillas: Combinar frijoles con maíz o arroz, o incluir huevo, pollo, pescado y yogur natural para obtener todos los aminoácidos esenciales.
Welcome to your third practical laboratory assignment in Sports Nutrition. This week, we examine the physiological regulation of Myofibrillar Protein Synthesis (MPS), essential amino acid (EAA) profiles, and metabolic nitrogen balance. You will evaluate a client's protein intake under energy restriction or physical workload demands, and design an evidence-based whole-food protein distribution protocol using our Single Source of Truth (SSoT): the Dietary Guidelines for Americans (DGA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .

Bienvenido a su tercera práctica de laboratorio de nutrición deportiva. Esta semana evaluaremos la síntesis de proteína miofibrilar (MPS), los aminoácidos esenciales y el balance de nitrógeno. Auditará la ingesta de un cliente bajo restricción energética o alta carga física, diseñando un protocolo de distribución con alimentos reales fundamentado en las pautas federales DGA y PAGA 2018 (2.ª ed.).

- HLTH-150.2.1.AY26-27: Calculate individualized daily protein prescriptions (1.2 to 2.2 g/kg) and per-meal leucine thresholds across diverse activity levels. Calcular prescripciones diarias individualizadas de proteína (1.2 a 2.2 g/kg) y umbrales de leucina por comida en diversos niveles de actividad.
- HLTH-150.2.3.AY26-27: Formulate evidence-based whole-food amino acid distribution models to optimize MPS and mitigate muscle protein breakdown (MPB). Formular modelos de distribución de aminoácidos basados en alimentos reales para optimizar la MPS y mitigar la degradación muscular.
- Module Window / Ventana del Módulo: Opens Tuesday, September 1, 2026, at 12:00 AM MST Abre el martes, 1 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, September 7, 2026, at 11:59 PM MST Lunes, 7 de septiembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación: Weekly Labs & Clinical Simulations Benchmark (10 Points) Ponderación para laboratorios semanales y simulaciones clínicas (10 Puntos)

### Lab Objectives / Objetivos del Laboratorio

Competencias clave del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Evaluate physiological mechanisms of anabolic resistance, muscle protein breakdown (MPB), and the leucine trigger threshold across active and aging populations. Evaluar la resistencia anabólica, la degradación proteica y el umbral de leucina en poblaciones activas y de edad avanzada.
- Calculate individualized daily protein requirements (g/kg and total g) and per-meal dosing targets (0.30 to 0.55 g/kg/meal) under specific caloric deficit or training conditions. Calcular requerimientos diarios de proteína (g/kg y g totales) y metas por comida (0.30 a 0.55 g/kg/comida) en déficit calórico o entrenamiento.
- Design an evidence-based, 4-meal whole-food distribution schedule featuring affordable, heat-stable regional protein sources for Yuma County. Diseñar un esquema de 4 comidas con alimentos reales accesibles y resistentes al calor adaptado a la comunidad de Yuma.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-03 / Fase 1: Selección de Escenario de Simulación Clínica

Elija su Ruta y Revise los Datos del Caso

Choose ONE of the three career-aligned tracks below to audit in the Gemini AI Tool Box:

Focus: Post-menopausal female (E.R., 62) experiencing sarcopenia risk and anabolic resistance under energy restriction.


```text
###
[TRACK / RUTA]: Track 1 - Clinical & Chronic Disease Prevention Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: E.R.
[AGE / EDAD]: 62 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma, AZ
[HEIGHT / ESTATURA]: 5 ft 3 in (160 cm) | [WEIGHT / PESO]: 143 lbs (65 kg)
[CLINICAL PROFILE & GOAL]: Post-menopausal female experiencing age-related loss of lean tissue (sarcopenia risk); restricting energy to 1,300 kcal/day for weight loss.
[CURRENT PROTEIN INTAKE]: Consumes 45 grams total protein per day (~0.69 g/kg body weight), primarily as a single large meal at dinner; skips morning protein.
[PRIMARY COMPLAINT]: Muscular weakness, loss of functional grip strength, and persistent physical fatigue during daily activities.
###
```

Focus: Plant-based municipal field worker (J.M., 32) struggling to meet essential amino acid and leucine thresholds in high-heat fieldwork.


```text
###
[TRACK / RUTA]: Track 2 - Community & Public Health Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: J.M.
[AGE / EDAD]: 32 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 5 ft 11 in (180 cm) | [WEIGHT / PESO]: 172 lbs (78 kg)
[OCCUPATION & DIET]: Outdoor Parks Maintenance Specialist; follows a strict vegan (plant-based) pattern.
[CURRENT PROTEIN INTAKE]: Consumes ~65 grams of plant protein per day (~0.83 g/kg body weight), relying on incomplete grain sources without legume pairing.
[PRIMARY COMPLAINT]: Chronic muscle soreness, poor physical recovery between high-heat outdoor work shifts (105°F+), and loss of physical stamina.
###
```

Focus: Master's powerlifting strength athlete (M.C., 55) seeking complete muscle retention and maximal strength during a hypoenergetic weight cut.


```text
###
[TRACK / RUTA]: Track 3 - Sports & Athletic Performance Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: M.C.
[AGE / EDAD]: 55 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 5 ft 4 in (163 cm) | [WEIGHT / PESO]: 154 lbs (70 kg)
[SPORT / DEPORTE]: Masters Powerlifting (Preparing for regional meet in 8 weeks)
[PRIMARY GOAL]: Drop one weight class (cut ~6 lbs / 2.7 kg body fat) while preserving 100% of lean muscle tissue and maximal squat/deadlift strength.
[CURRENT INTAKE & TIMING]: Restricting total energy to 1,500 kcal/day (~500 kcal daily deficit); consumes 70 grams total protein/day (~1.0 g/kg body weight); skips breakfast, light lunch (~15g protein), large dinner (~55g protein).
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


```text
Safety Auditor Protocol: HLTH-150 Module 03 Protein Tool Box ###:
Role: Socratic Sports Nutrition Mentor in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Review the student's selected career track case data enclosed within triple-hashes (###) below.
Step 2: PATTERN: Evaluate why the client's current protein intake is clinically insufficient for their goal, analyzing muscle protein breakdown (MPB), anabolic resistance, or plant-based amino acid completeness.
Step 3: RULE: Calculate target daily protein needs (in g/kg and total daily grams) and establish per-meal dosing targets (in g/kg and grams per meal) using DGA/PAGA standards. Explain the "leucine trigger" threshold (~2.5–3.5g leucine per bolus).
Step 4: SOLVE: Outline an evidence-based 4-meal daily protein distribution schedule utilizing accessible whole foods suitable for Yuma County, including a pre-sleep slow-digesting protein strategy.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Requirements

Plantilla de Entrega en el Cuadro de Texto de Canvas

Copy the template below, populate your responses, and submit directly in Canvas:


```text
HLTH-150 Module 03 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]
Client Initials: [Insert Client Initials]

Step 1: Pattern Recognition (Physiological Gap Analysis):
Key Point: Muscle Protein Breakdown & Anabolic Resistance Analysis:
Key Point: Limitations of Baseline Intake (Quantity & Distribution):

Step 2: Rule Application (Target Calculations via DGA / PAGA):
Key Point: Client Body Mass: ___ kg
Key Point: Target Daily Protein Range: ___ g/kg/day (Total Daily Grams: ___ g/day)
Key Point: Target Per-Meal Protein Dosing: ___ g/kg/meal (Per-Meal Target: ___ g/meal across 4 meals)
Key Point: Per-Meal Leucine Trigger Requirement: ___ g leucine per meal

Step 3: Problem Solving (Whole-Food 4-Meal Schedule & Client Card):
Key Point: Meal 1 (Morning):
Key Point: Meal 2 (Mid-Day):
Key Point: Meal 3 (Afternoon / Post-Activity):
Key Point: Meal 4 & Pre-Sleep Strategy (Slow-Release Casein / Whole Food):
Key Point: Bilingual Client Instruction Card (EN / ES):

Step 4: Part 3 — Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice):
Key Point: [In 150-word minimum (150+ words) written in your own clinical voice, justify why your g/kg/day protein target, 4-meal leucine distribution (0.25-0.40 g/kg/meal), and whole-food selection protect lean muscle mass under DGA 2025-2030 standards]

Step 5: Repository Verification:
AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M03_Protein_Synthesis_Audit.pdf
End Submission ###:
```


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Part 1: Physiological Gap Analysis: Key Point — Anabolic Resistance in Masters Athletes: Aging skeletal muscle (>50 years) exhibits blunted sensitivity to circulating essential amino acids. Overcoming this requires higher per-meal leucine boluses (~3.2–3.6g) to phosphorylate mTORC1 and stimulate MPS. Key Point — Hypoenergetic Muscle Breakdown: In a 500 kcal daily deficit, muscle protein breakdown (MPB) accelerates to supply amino acids for hepatic gluconeogenesis. Inadequate protein triggers contractile degradation, compromising force output. Key Point — Assessment of Current Intake: Consuming only 70 g/day (1.0 g/kg) with an uneven distribution (skipping breakfast, only 15g at lunch) leaves M.C. in negative nitrogen balance for ~20 hours daily.

Part 2: Rule Application & Target Calculations (DGA / PAGA Standards): Key Point — Body Mass: 154 lbs / 2.2 = 70 kg . Age: 55 years. Key Point — Daily Target Rule (2.0 to 2.2 g/kg/day): Target = 70 kg 2.2 g/kg/day = 154 grams protein/day (~616 kcal, representing 41% of her 1,500 kcal allocation). Key Point — Per-Meal Dosing Rule (0.50 to 0.55 g/kg/meal): 70 kg 0.55 g/kg = ~38.5g per meal across 4 boluses to ensure at least 3.2g of leucine per feeding.

Part 3: Solving the Gap (Whole-Food 4-Meal Schedule): Key Point — Meal 1 (Breakfast - 7:30 AM): 3 whole eggs + 1 cup egg whites scrambled with spinach and 1 slice whole-wheat toast ( 38g protein / ~3.3g leucine ). Key Point — Meal 2 (Lunch - 12:30 PM): 5 oz grilled chicken breast over greens, quinoa, and olive oil dressing ( 38g protein / ~3.2g leucine ; packed in an insulated cooler for Yuma heat). Key Point — Meal 3 (Post-Workout - 5:30 PM): 5.5 oz baked salmon with sweet potato and broccoli ( 38g protein / ~3.2g leucine ). Key Point — Meal 4 & Pre-Sleep (Bedtime - 9:30 PM): 1.5 cups low-fat cottage cheese with berries ( 40g slow-digesting casein protein / ~3.6g leucine ) to sustain overnight MPS and suppress nocturnal catabolism.

EN: "To protect your muscle and strength while cutting weight, eat 38 to 40 grams of whole-food protein every 4 to 5 hours. Include a protein-rich snack like cottage cheese before bed so your muscles continue to recover and rebuild overnight."

ES: "Para proteger su masa muscular y fuerza mientras reduce peso, consuma de 38 a 40 gramos de proteína de alimentos reales cada 4 o 5 horas. Incluya una porción de requesón antes de dormir para que sus músculos sigan recuperándose durante la noche."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_150_M03_Protein_Synthesis_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 03 (Mod 03 Lab: Daily Protein Needs & Muscle Maintenance Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 03 Laboratorio y Simulación: Cinética de Proteínas y Umbrales de Leucina

Cinética de Aminoácidos, Umbrales de Leucina y Preservación de Masa Magra

En esta práctica de laboratorio, auditará la ingesta proteica de un cliente utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , calculando la demanda diaria en g/kg, los umbrales de leucina por comida y diseñando un plan de 4 comidas con alimentos integrales según las normas federales DGA y PAGA 2018.

- Apertura del Módulo: Martes, 1 de septiembre de 2026, a las 12:00 AM MST
- Fecha Límite de Entrega: Lunes, 7 de septiembre de 2026, a las 11:59 PM MST
- Ponderación: Puntuación de laboratorios semanales y auditorías clínicas (10 Puntos)

### Paso 1: Consulta en la Caja de Herramientas de IA Gemini

Pegue los datos de la ruta elegida en Gemini IA y copie esta plantilla debajo:


```text
Protocolo Safety Auditor: HLTH-150 Laboratorio 03 ###:
Rol: Mentor Socratico de Nutricion Deportiva con la voz del Narrador.
SSoT: Guias Alimentarias para los Estadounidenses (DGA) y Pautas PAGA 2018 (2.a ed.).

Instrucciones:
Step 1: Revisar los datos del caso de la ruta seleccionada por el estudiante entre delimitadores (###).
Step 2: PATRON: Evaluar por que la ingesta proteica actual es insuficiente, analizando degradacion muscular (MPB), resistencia anabolica o calidad vegetal.
Step 3: REGLA: Calcular los requerimientos diarios (g/kg y g totales) y por comida (0.30 a 0.55 g/kg) con pautas DGA/PAGA. Explicar el umbral de leucina (~2.5 a 3.5g).
Step 4: SOLUCION: Disenar un cronograma de 4 comidas con alimentos integrales accesibles para Yuma, incluyendo proteina lenta antes de dormir.
Step 5: Generar una tarjeta de instruccion bilingue para el cliente (EN / ES).

Entrada de Datos del Cliente ###:
[PEGUE AQUI LOS DATOS DE SU RUTA ENTRE DELIMITADORES]
Fin de Datos del Cliente ###:
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Plantilla de Entrega en Canvas (Solo Texto)


```text
HLTH-150 Entrega de Laboratorio Modulo 03 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clinica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]
Iniciales del Cliente: [Insertar Iniciales]

Step 1: Reconocimiento de Patrones (Brecha Fisiologica):
Key Point: Analisis de Degradacion Muscular y Resistencia Anabolica:
Key Point: Limitaciones de la Ingesta Basal (Cantidad y Distribucion):

Step 2: Aplicacion de Reglas (Calculos con Normas DGA / PAGA):
Key Point: Peso Corporal: ___ kg
Key Point: Meta Diaria Total: ___ g/kg/dia (Gramos Totales: ___ g/dia)
Key Point: Meta por Comida (4 tomas): ___ g/kg/comida (Meta: ___ g/comida)
Key Point: Umbral de Leucina Requerido: ___ g de leucina por comida

Step 3: Resolucion de Problemas (Esquema de 4 Comidas con Alimentos Reales):
Key Point: Comida 1 (Manana):
Key Point: Comida 2 (Mediodia):
Key Point: Comida 3 (Tarde / Post-Actividad):
Key Point: Comida 4 y Estrategia Pre-Sueno (Proteina Lenta / Alimentos Integrales):
Key Point: Tarjeta de Instruccion Bilingue para el Cliente (EN / ES):

Step 4: Verificación Activa Clinica Obligatoria (Mínimo 150 Palabras en su Propia Voz Humana):
Key Point: [En mínimo 150 palabras (150+ palabras) escritas en su propia voz clinica, justifique por que su meta de proteina en g/kg/dia, distribucion en 4 comidas y seleccion de alimentos reales protegen la masa muscular segun DGA 2025-2030]

Step 5: Verificacion del Repositorio:
Intercambio con la IA exportado y guardado en Google Drive: EXW_Professional_AI_Repository / EXW_150_M03_Protein_Synthesis_Audit.pdf
Fin de la Entrega ###:
```

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi razonamiento clínico como arquitecto nutricional, aplicar el mínimo sedentario de 0.8 g/kg/día a una persona activa o adulto mayor en Yuma provoca balance negativo de nitrógeno y pérdida de masa muscular. Por otro lado, los bots comerciales que recetan exceso de batidos sintéticos desplazan a los carbohidratos complejos necesarios en el calor del desierto. Al prescribir 1.4–2.0 g/kg/día dentro del rango AMDR (10–35%) distribuido en 4 comidas de alimentos reales (huevos, frijoles con tortilla de maíz, pollo y lácteos), alcanzamos el umbral de leucina en cada comida para proteger el tejido muscular."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 03)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
