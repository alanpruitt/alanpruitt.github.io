# HLTH-150: Mod 03 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 03 Discussion: Whole-Food Protein Sources on a Budget

Distribución de Proteína Dietética, Umbral de Leucina y Retención de Masa Magra

This week, we analyze myofibrillar protein synthesis (MPS), essential amino acid (EAA) completeness, the per-meal "leucine trigger," and anabolic resistance. Select a career-aligned track below and audit a whole-food daily protein distribution strategy using our SSoT ( Dietary Guidelines for Americans / PAGA 2018, 2nd Ed. ) and the Gemini AI Tool Box!

Esta semana analizamos la síntesis de proteína miofibrilar (MPS), el perfil de aminoácidos esenciales, el "disparador de leucina" y la resistencia anabólica. ¡Seleccione una ruta alineada con su carrera y audite una estrategia de distribución de proteína basada en alimentos reales con nuestras pautas federales DGA / PAGA 2018 y la Caja de Herramientas de IA Gemini!

- Topic Opens / Apertura del Foro: Tuesday, September 1, 2026, at 12:00 AM MST / Martes a las 12:00 AM
- Initial Post Due / Publicación Inicial: Thursday, September 3, 2026, at 11:59 PM MST / Jueves a las 11:59 PM
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 6, 2026, at 11:59 PM MST / Domingo a las 11:59 PM
- Board Closes / Cierre del Foro: Monday, September 7, 2026, at 11:59 PM MST / Lunes a las 11:59 PM
You are warmly encouraged to post in English or Spanish according to your preference. Le animamos a publicar en inglés o en español, según su preferencia académica.

Instructor reviews are published openly in this board as well as in Gradebook. Reading peer threads reinforces leucine dosing thresholds and whole-food meal architecture.


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI Preceptor query:

Focus: Aging post-menopausal client (E.R., 62) experiencing sarcopenia risk, anabolic resistance, and inadequate protein distribution under energy restriction.


```text
###
[TRACK]: Track 1 - Clinical & Chronic Disease Prevention Path
[CLIENT INITIALS]: E.R. | [AGE]: 62 | [SEX]: Female | [WEIGHT]: 65 kg (143 lbs)
[CLINICAL PROFILE]: Post-menopausal, sarcopenia risk; restricting energy to 1,300 kcal/day.
[CURRENT INTAKE]: Consumes 45g protein/day (~0.69 g/kg/day) in a single dinner meal; skips morning protein.
[COMPLAINT]: Functional strength loss, fatigue during daily tasks, progressive muscle mass loss.
###
```

Focus: Plant-based agricultural maintenance worker (J.M., 32) struggling to reach essential amino acid completeness and leucine trigger thresholds during high-heat field shifts.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CLIENT INITIALS]: J.M. | [AGE]: 32 | [SEX]: Male | [WEIGHT]: 78 kg (172 lbs)
[OCCUPATION & DIET]: Yuma Outdoor Parks & Field Worker; plant-forward (vegan) pattern.
[CURRENT INTAKE]: Consumes ~65 g plant protein/day (~0.83 g/kg/day) from incomplete grain sources without legume pairing.
[COMPLAINT]: Chronic muscle soreness, slow physical recovery between 105°F+ shifts, loss of physical stamina.
###
```

Focus: Master's powerlifting athlete (M.C., 55) cutting weight for competition while aiming for complete lean mass retention and neuromuscular force output.


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[CLIENT INITIALS]: M.C. | [AGE]: 55 | [SEX]: Female | [WEIGHT]: 70 kg (154 lbs)
[SPORT]: Masters Powerlifter; 500 kcal daily deficit (~1,500 kcal/day).
[CURRENT INTAKE]: Consumes 70g protein/day (~1.0 g/kg/day); skips breakfast, light lunch (15g), heavy dinner (55g).
[GOAL]: Drop 6 lbs body fat while preserving 100% lean mass and squat/deadlift force output.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a protein kinetics audit:


```text
Safety Auditor Protocol: HLTH-150 Protein Preceptor ###:
Role: Socratic Sports Nutrition Mentor in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Review the student's selected career track case data enclosed within triple-hashes (###) below.
Step 2: Evaluate why the client's current daily protein intake is clinically insufficient for their goal (considering energy deficit, aging, or protein quality).
Step 3: Calculate their target daily protein range (in g/kg and total daily grams) and establish per-meal dosing targets (in g/kg and grams per meal).
Step 4: Explain the "leucine trigger" threshold (~2.5–3.0g leucine in young adults; ~3.5–4.0g in aging adults) and how whole foods satisfy this requirement.
Step 5: Propose a whole-food 4-meal distribution schedule (including a pre-sleep slow-digesting protein option).
Step 6: Maintain all case inputs wrapped within delimiters.

Client Data Input ###:
[Paste Your Selected Track Data Block Here]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Case: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and client initials. Indique la ruta seleccionada y las iniciales del cliente.
- Anabolic Resistance & Deficit Physiology: Explain why your client's specific condition (aging, caloric deficit, or plant-based protein quality) accelerates muscle protein breakdown (MPB). What is the specific per-meal "leucine trigger" threshold needed to stimulate myofibrillar protein synthesis (MPS)? Explique por qué la condición de su cliente eleva la degradación proteica. ¿Cuál es el umbral de leucina por comida necesario para activar la MPS?
- Whole-Food Dosing & Timing Schedule: Calculate total daily protein (g/kg and total g) and per-meal dosing targets (0.30–0.55 g/kg/meal). Design an evidence-based 4-meal whole-food distribution schedule and explain why pre-sleep slow-release protein (cottage cheese, Greek yogurt, or milk) suppresses nocturnal nitrogen losses. Calcule la proteína diaria y por comida con alimentos integrales. Diseñe un esquema de 4 comidas y justifique la ingesta de proteína lenta antes de dormir.

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Verify their per-meal leucine calculations and suggest a heat-stable, portable whole-food protein source for use in the field, clinic, or gym in Yuma County!

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Verifique sus cálculos de leucina y proponga una fuente de proteína integral, portátil y resistente al calor en Yuma.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Anabolic Resistance & Leucine: Aging muscle exhibits blunted sensitivity to hyperaminoacidemia, requiring higher single-meal leucine boluses to trigger the mTORC1 pathway. In a 500 kcal deficit, muscle protein breakdown rises to provide gluconeogenic substrates. Consuming ~3.5 g of leucine per meal satisfies the aging "leucine trigger," overcoming anabolic resistance and driving maximal MPS to preserve contractile tissue. El músculo envejecido presenta una menor sensibilidad a los aminoácidos, requiriendo mayor dosis de leucina para activar mTORC1. En un déficit calórico de 500 kcal, la degradación proteica aumenta; alcanzar ~3.5 g de leucina por comida supera la resistencia anabólica y preserva el tejido contráctil.
- Protein Dosing Calculations (70 kg Lifter): Target daily intake = 70 kg × 2.2 g/kg = 154 g protein/day. Across 4 meals, the per-meal target is 154 g / 4 = 38.5 g protein/meal (0.55 g/kg/meal), providing ~3.2–3.6 g leucine per bolus. Meta diaria = 70 kg × 2.2 g/kg = 154 g proteína/día. En 4 comidas, la meta es 38.5 g de proteína/comida (0.55 g/kg/comida), aportando ~3.2 a 3.6 g de leucina por ingesta.
- Whole-Food 4-Meal Schedule & Pre-Sleep Protein: Meal 1 (7:30 AM): 3 whole eggs + 1 cup egg whites scrambled with spinach (~38g protein, ~3.3g leucine). Meal 2 (12:30 PM): 5 oz grilled chicken breast + quinoa and black beans (~40g protein, ~3.5g leucine). Meal 3 (5:30 PM Post-Training): 5.5 oz baked salmon + sweet potato (~38g protein, ~3.2g leucine). Meal 4 (9:30 PM Pre-Sleep): 1.5 cups low-fat cottage cheese + berries (~38g slow-digesting casein protein, ~3.6g leucine). The slow-digesting casein coagulates in the stomach, providing sustained amino acid release over 7–8 hours to suppress nocturnal nitrogen losses. 4 comidas con alimentos integrales: Desayuno con huevos y claras; Almuerzo con pechuga de pollo; Cena con salmón; Pre-sueño con requesón/cottage (caseína lenta que libera aminoácidos durante 7–8 horas evitando el catabolismo nocturno).

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 03 (Mod 03 Discussion: Whole-Food Protein Sources on a Budget)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Foro de Discusión 03: Distribución de Proteína y Umbrales de Leucina

Esta semana analizamos la síntesis de proteína miofibrilar (MPS), el perfil de aminoácidos esenciales, el "disparador de leucina" y la resistencia anabólica. Seleccione una ruta profesional y audite una estrategia de distribución de proteína basada en alimentos integrales utilizando las normas federales DGA / PAGA 2018.

- Apertura del Foro: Martes, 1 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 3 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 6 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 7 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta y Caso Seleccionado: Indique su ruta (Ruta 1 Clínica, Ruta 2 Comunitaria o Ruta 3 Rendimiento Deportivo) y las iniciales del cliente.
- Resistencia Anabólica y Umbral de Leucina: Explique por qué la condición de su cliente eleva la degradación proteica muscular (MPB). ¿Qué umbral de leucina por comida (~2.5–3.5 g) se requiere para activar la vía mTORC1?
- Esquema de 4 Comidas con Alimentos Reales: Calcule la proteína diaria total (g/kg y g totales) y la meta por comida (0.30–0.55 g/kg). Diseñe una distribución de 4 comidas con alimentos integrales y explique por qué la proteína de absorción lenta antes de dormir evita la degradación muscular nocturna.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:
