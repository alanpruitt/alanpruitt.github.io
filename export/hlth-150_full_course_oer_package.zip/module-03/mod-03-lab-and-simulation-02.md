## HLTH-150: Mod 03 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 03) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 03 Coaching Sprint Simulation: Spreading Protein Across Daily Meals

Sesión de Coaching del Módulo 03: Síntesis Proteica y Retención de Masa Magra

- Muscle Protein Synthesis (MPS) & Leucine Trigger (20–40 g/Meal): Consuming 20–40 g of high-quality protein (~0.25–0.40 g/kg, providing ~2.5–3 g leucine) every 3–4 hours maximizes muscle repair and remodeling. En palabras sencillas: Consumir de 20 a 40 gramos de proteína real en cada comida principal para encender la reparación y el mantenimiento muscular.
- Active Adult Protein Target (1.2–2.0 g/kg/day): Physically active individuals and strength/endurance athletes require 1.2–2.0 g/kg/day of protein from whole foods, above the sedentary RDA of 0.8 g/kg/day. En palabras sencillas: Quienes entrenan o hacen trabajo físico pesado necesitan entre 1.2 y 2.0 gramos de proteína por kilo de peso al día.
- Complementary Plant & Animal Real-Food Proteins: Combining legumes and whole grains (e.g., pinto beans + corn tortillas/rice) or lean poultry, eggs, fish, and yogurt to supply all 9 essential amino acids. En palabras sencillas: Combinar frijoles con maíz o arroz, o incluir huevo, pollo, pescado y yogur natural para obtener todos los aminoácidos esenciales.
- HLTH-150.3.1.AY26-27: Evaluate amino acid profiles, protein turnover, and muscle protein synthesis (MPS) in response to resistance exercise and dietary intake. Evaluar perfiles de aminoácidos, recambio proteico y síntesis de proteínas musculares (MPS) en respuesta al ejercicio y la dieta.
- HLTH-150.3.2.AY26-27: Apply federal Dietary Guidelines (DGA) and sports nutrition standards (PAGA 2018) to calculate appropriate daily protein requirements for hypertrophy and recovery. Aplicar las Guías Dietéticas federales (DGA) y normas de PAGA 2018 para calcular los requerimientos de proteína para hipertrofia y recuperación.

### Your Weekly Win: Transforming Food into Functional Lean Mass

How does dietary protein transform into contractile muscle tissue and functional strength? Dietary proteins break down into essential amino acids (EAAs) that activate the cellular mTORC1 signaling cascade to initiate Myofibrillar Protein Synthesis (MPS) . Rather than falling for commercial hype about massive 100-gram shakes, evidence-based nutrition proves that meeting total daily requirements (1.2–2.2 g/kg/day) and distributing protein evenly across 3 to 5 meals with a ~2.5–3.5g leucine trigger maximizes muscle recovery. Choose your track below, consult your AI Socratic Coach, and master protein distribution science!

¿Cómo se transforman las proteínas en tejido contráctil y fuerza? Las proteínas se descomponen en aminoácidos esenciales que activan la síntesis de proteína muscular (MPS). En lugar de consumir batidos gigantes innecesarios, la ciencia demuestra que distribuir la proteína (1.2 a 2.2 g/kg/día) en 3 a 5 comidas con el umbral de leucina optimiza la recuperación. ¡Elija su caso y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione el caso correspondiente a su trayectoria vocacional

Scenario: Older adult (Margaret, 70) experiencing accelerated muscle loss and anabolic resistance who skips daytime protein and eats a small evening dinner.


```text
###
[TRACK]: Track 1 - Clinical & Geriatric Health Path
[CLIENT]: Sarcopenia Prevention Client (Margaret, 70) | [WEIGHT]: 60 kg (132 lbs) | [LOCATION]: Yuma, AZ
[SITUATION]: Consuming ~40g protein/day (~0.66 g/kg/day) entirely at dinner; struggles with muscle weakness and mobility loss.
[COACHING GOAL]: Overcome anabolic resistance by prescribing 1.2-1.5 g/kg/day (~72-90g total) distributed across 3 meals with >=3.5g leucine per bolus using easy-to-digest whole foods (eggs, Greek yogurt, fish).
###
```

Scenario: High school football athlete (Leo, 17) who consumes 150g of protein in a single giant shake while eating low-protein meals the rest of the day.


```text
###
[TRACK]: Track 2 - Community & Youth Coaching Path
[CLIENT]: High School Athlete (Leo, 17) | [WEIGHT]: 80 kg (176 lbs) | [LOCATION]: Yuma County, AZ
[SITUATION]: Drinks a massive 150g commercial protein shake post-workout but skips breakfast and eats low-protein snacks during school.
[COACHING GOAL]: Educate Leo on the per-meal MPS saturation ceiling (~0.30-0.40 g/kg/meal or 25-35g protein) and redistribute his intake into 4 whole-food meals (~130-160g total/day).
###
```

Scenario: Natural lifter (Derrick, 26) seeking maximal muscle hypertrophy who is confused by contradictory supplement marketing and powder claims.


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Coaching Path
[CLIENT]: Resistance-Trained Lifter (Derrick, 26) | [WEIGHT]: 82 kg (180 lbs) | [LOCATION]: Yuma, AZ
[SITUATION]: Trying to optimize muscle hypertrophy; currently consuming excessive expensive protein powders without a structured timing plan.
[COACHING GOAL]: Calculate an evidence-based target of 1.6-2.2 g/kg/day (~130-180g total), partitioned into 4 whole-food meals of ~35-45g protein (supplying ~3g leucine each), including pre-sleep slow-digesting protein.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: HLTH-150 Protein Synthesis Tool Box ###:
Role: Supportive HLTH-150 Sports Nutrition Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Dietary Guidelines for Americans (DGA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms muscle protein synthesis (MPS), essential amino acid requirements, and the per-meal leucine trigger threshold (~2.5-3.5g leucine).
Step 3: Guide the student to calculate daily protein needs (1.2-2.2 g/kg/day) and structure a 4-meal whole-food distribution plan.
Step 4: Help the student formulate ONE punchy, memorable coaching takeaway sentence (in English and Spanish) about how consistent protein distribution drives recovery.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's protein goal or nutritional hurdle.
- Protein Synthesis & Leucine Analysis: Explain how essential amino acids, MPS, and the leucine trigger function for your client.
- My Practical Whole-Food Strategy: Provide a daily target (g/kg and total grams) and a 4-meal whole-food distribution plan.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why distributing 1.6–2.0 g/kg/day of whole-food protein evenly across 4 daily meals (25–35 g/meal to hit the leucine threshold) outperforms megadosing expensive protein powders under DGA 2025–2030 standards.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: HLTH-150 Module 03 Coaching Sprint • Track 3 (Strength / Derrick)

- Chosen Track & Client: Track 3: Adult Fitness & Strength Coaching (Derrick, 26, 82 kg). Goal: Derrick wants to maximize muscle hypertrophy and needs an evidence-based daily protein target and a 4-meal whole-food distribution plan without relying on commercial supplements.
- Track 3: Adult Fitness & Strength Coaching (Derrick, 26, 82 kg).
- Goal: Derrick wants to maximize muscle hypertrophy and needs an evidence-based daily protein target and a 4-meal whole-food distribution plan without relying on commercial supplements.
- Protein Synthesis & Leucine Analysis: Muscle Protein Synthesis (MPS): Resistance training sensitizes skeletal muscle, but MPS requires a threshold dose of essential amino acids—specifically ~2.5 to 3.5 grams of leucine—to phosphorylate mTORC1. Federal sports nutrition baselines recommend 1.6 to 2.2 g/kg/day partitioned into 3 to 5 meals to stimulate MPS multiple times per day.
- Muscle Protein Synthesis (MPS): Resistance training sensitizes skeletal muscle, but MPS requires a threshold dose of essential amino acids—specifically ~2.5 to 3.5 grams of leucine—to phosphorylate mTORC1.
- Federal sports nutrition baselines recommend 1.6 to 2.2 g/kg/day partitioned into 3 to 5 meals to stimulate MPS multiple times per day.
- My Practical Whole-Food Strategy for Derrick: "Target 1.8 g/kg/day (148g protein total), partitioned into 4 meals containing ~37g of complete whole-food protein (3 whole eggs + 1 cup egg whites at breakfast; chicken breast at lunch; salmon at dinner; 1.5 cups cottage cheese before bed for sustained nocturnal recovery)."
- "Target 1.8 g/kg/day (148g protein total), partitioned into 4 meals containing ~37g of complete whole-food protein (3 whole eggs + 1 cup egg whites at breakfast; chicken breast at lunch; salmon at dinner; 1.5 cups cottage cheese before bed for sustained nocturnal recovery)."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Derrick does not need expensive commercial amino acid powders or a 90-gram single-sitting steak dinner to maximize muscle hypertrophy. Skeletal muscle protein synthesis (MPS) is governed by the refractory 'muscle full' effect: once a meal delivers approximately 2.5 to 3.0 grams of leucine (found in 25–35 grams of high-quality protein), additional protein in that same sitting is oxidized rather than built into myofibrillar tissue. Grounded in the 2025–2030 Dietary Guidelines for Americans, distributing his 148-gram daily target (1.8 g/kg for an 82 kg lifter) across four evenly spaced whole-food meals—eggs and Greek yogurt, chicken and black beans, tuna, and lean beef or tofu—triggers four distinct MPS peaks per day while providing essential micronutrients."
- My Memorable Coaching Takeaway: EN: "Consistent whole-food protein distribution throughout the day keeps muscle protein synthesis working in your favor!" ES: "¡La distribución constante de proteína con alimentos reales a lo largo del día mantiene la síntesis muscular trabajando a tu favor!"
- EN: "Consistent whole-food protein distribution throughout the day keeps muscle protein synthesis working in your favor!"
- ES: "¡La distribución constante de proteína con alimentos reales a lo largo del día mantiene la síntesis muscular trabajando a tu favor!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_150_M03_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 03 (Mod 03 Coaching Sprint: Spreading Protein Across Daily Meals)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 03 Simulación de Coaching: Síntesis Proteica y Retención Muscular

Evaluación Rápida y Aprendizaje Práctico del Metabolismo Proteico


### Su Logro Semanal: Construcción y Reparación del Tejido Muscular

Esta sesión le permitirá entender cómo las proteínas de la dieta activan la Síntesis Proteica Muscular (MPS). Aprenda a calcular requerimientos diarios y a distribuir las ingestas con alimentos reales para maximizar la recuperación. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: HLTH-150 Sintesis Proteica ###:
Rol: Coach de Nutricion Deportiva de HLTH-150 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Guias Alimentarias para los Estadounidenses (DGA) y Pautas PAGA 2018 (2.a ed.).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla la sintesis proteica muscular (MPS), los requisitos de aminoacidos y el umbral de leucina (~2.5-3.5g).
Step 3: Guiar al estudiante para calcular la proteina diaria (1.2-2.2 g/kg/dia) y estructurar un plan de 4 comidas con alimentos integrales.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la distribucion constante de proteinas impulsa la recuperacion.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el objetivo o dilema nutricional de su cliente.
- Análisis de Síntesis Proteica y Leucina: Explique cómo funcionan los aminoácidos y la MPS en relación con su cliente.
- Mi Estrategia de Alimentos Reales: Escriba la meta diaria (g/kg y gramos totales) y la distribución de 4 comidas.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué distribuir 1.6–2.0 g/kg/día de proteína de alimentos reales en 4 comidas diarias (25–35 g/comida para activar el umbral de leucina) supera a los suplementos costosos según las Guías DGA 2025–2030.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, Derrick no necesita polvos comerciales costosos ni comer 90 gramos de proteína en una sola cena. La síntesis de proteína muscular (MPS) depende del umbral de leucina (2.5–3.0 g de leucina, presentes en 25–35 g de proteína de calidad); el exceso en una sola comida se oxida en lugar de formar músculo. Siguiendo las Guías Alimentarias 2025–2030, dividir su meta de 148 g/día (1.8 g/kg) en 4 comidas de alimentos reales—huevos, pollo con frijoles, atún y carne magra—estimula la síntesis muscular cuatro veces al día de forma económica y efectiva."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 03)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
