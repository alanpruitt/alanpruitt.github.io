## HLTH-150: Mod 03 Summary And Wrap Up Whole Food Protein And Muscle Maintenance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 03 Summary & Wrap-Up: Whole-Food Protein & Muscle Maintenance

Síntesis de Proteína Miofibrilar, Umbral de Leucina y Retención de Masa Magra


### Step 1: Core Protein Kinetics & Muscle Maintenance Synthesis

Congratulations on completing Module 03! You have mastered the physiological mechanisms of protein turnover, amino acid delivery kinetics, and whole-food distribution strategies anchored in federal evidence-based standards:

- Daily Protein Requirements (DGA & PAGA SSoT): The 0.8 g/kg RDA represents the minimum to prevent clinical nitrogen deficiency in sedentary adults. Active individuals require 1.2 to 2.2 g/kg/day to repair microtrauma, preserve lean mass, and stimulate muscle protein synthesis (MPS).
- The Leucine Trigger & Bolus Distribution: Maximizing MPS requires a per-meal threshold of 0.25 to 0.40 g/kg (or 20–40g of complete whole-food protein) supplying approximately 2.5 to 3.5 grams of leucine distributed every 3 to 4 hours.
- Anabolic Resistance & Slow-Release Protein: Overcoming age-related anabolic resistance (> 50 years) requires higher per-meal doses (0.40–0.55 g/kg/meal). Ingesting 30 to 40g of slow-digesting protein (casein/dairy) before sleep sustains overnight amino acid availability and suppresses nocturnal muscle protein breakdown (MPB).

### Step 2: Workplace Intelligence & AI Nutritional Auditing

In clinical dietetics, sports performance facilities, and community health centers, nutrition professionals leverage generative AI preceptors to audit dietary records, calculate nitrogen balance, and formulate affordable whole-food meal schedules.

- AI Macronutrient Verification: Specialists utilize AI assistants to audit client dietary logs against federal Dietary Guidelines (DGA) and per-meal leucine triggers.
- Delimiter Security Protocol (###): Enclosing client biometrics (body mass, caloric deficit, protein intake, meal timing) inside triple hashes ( ### ) ensures clean data isolation for clinical preceptor audits.
- Whole-Food Prescription: Practitioners cross-reference AI-generated plans to prioritize affordable, accessible whole foods (eggs, poultry, legumes, dairy) over expensive commercial supplements.

### Step 3: Module 03 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 04:

English Response: Leucine is an essential branched-chain amino acid that acts as the key molecular switch to phosphorylate the mTORC1 pathway. Ingesting ~2.5 to 3.5 grams of leucine in a single meal triggers maximal muscle protein synthesis.

Respuesta en Español: La leucina es un aminoácido esencial que actúa como el interruptor molecular para activar la vía mTORC1. Ingerir entre ~2.5 y 3.5 g de leucina en una comida activa al máximo la síntesis de proteína muscular.

English Response: Skeletal muscle in adults over 50 exhibits reduced sensitivity to hyperaminoacidemia. To overcome this resistance, per-meal protein targets increase to Outcome 0.40: to 0.55 g/kg/meal (~35–40g protein supplying ~3.5–4.0g leucine).

Respuesta en Español: El músculo en adultos mayores presenta menor sensibilidad a los aminoácidos. Para superar esta resistencia, la dosis por comida aumenta a Outcome 0.40: a 0.55 g/kg/comida (~35 a 40 g de proteína con ~3.5 a 4.0 g de leucina).

English Response: Ingesting 30 to 40 grams of slow-digesting protein (such as cottage cheese or Greek yogurt) before sleep releases amino acids gradually over 7 to 8 hours, elevating overnight MPS and suppressing nocturnal muscle protein breakdown.

Respuesta en Español: Consumir de 30 a 40 gramos de proteína de digestión lenta (como requesón o yogur griego) antes de dormir libera aminoácidos durante 7 a 8 horas, elevando la síntesis nocturna y frenando la degradación muscular.

English Response: Enclosing client body mass, protein intake, and meal timing metrics inside triple hashes (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with DGA and PAGA 2018 standards.

Respuesta en Español: Encapitular la masa corporal, la ingesta de proteína y los tiempos de comida del cliente entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas DGA y PAGA 2018.

English Response: Whole foods provide a complete micronutrient matrix (vitamins, minerals, healthy fats) along with high biological value proteins, ensuring broader nutritional adequacy and economic accessibility.

Respuesta en Español: Los alimentos enteros proporcionan una matriz completa de micronutrientes (vitaminas, minerales, grasas saludables) junto con proteínas de alto valor biológico, garantizando una mayor adecuación nutricional y accesibilidad económica.

English Response: Dehydration and electrolyte imbalances impair cellular membrane polarization and intracellular signaling pathways, increasing muscle cramping risks, which makes climate-controlled indoor training essential.

Respuesta en Español: La deshidratación y los desequilibrios electrolíticos alteran la polarización de la membrana celular y las vías de señalización intracelular, aumentando el riesgo de calambres musculares, lo que hace esencial el entrenamiento en interiores climatizados.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: Positive nitrogen balance occurs when dietary protein intake exceeds total nitrogen excretion, indicating an anabolic state where the body is actively retaining amino acids to build and repair skeletal muscle tissue.

Respuesta en Español: El balance de nitrógeno positivo ocurre cuando la ingesta proteica supera la excreción total de nitrógeno, indicando un estado anabólico donde el cuerpo retiene aminoácidos para construir y reparar tejido muscular.


### AI Simulation Workspace • Protein Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive synthesis connecting protein kinetics, leucine thresholds, and whole-food meal planning:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Module 03 Protein Synthesis Synthesis ###:
Role: Academic Sports Nutritionist and Clinical Dietetic Mentor.
SSoT: Dietary Guidelines for Americans (DGA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Sedentary baseline (0.8 g/kg) vs. Active endurance (1.2-1.4 g/kg) vs. Resistance training (1.6-2.2 g/kg).
   Key Point: Per-meal protein dosing thresholds (0.25-0.40 g/kg vs. 0.40-0.55 g/kg in aging adults).
   Key Point: Leucine trigger requirements and cellular mTORC1 activation.
Step 2: Formulate an evidence-based, 4-meal whole-food distribution plan featuring affordable, heat-stable protein sources for Yuma County.
Step 3: Keep all inputs and structured recommendations wrapped within delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 04 — Fluid Dynamics & Heat (Hydration Math)

In plain English, next week in Module 04: Fluid Dynamics & Heat you will learn how to measure a person's exact sweat rate and calculate how much water and sodium they need to drink before, during, and after working or training in Yuma's $105^\circ\text{F}+$ desert heat. Why it matters: losing more than 2% of body weight from sweat causes heart rate to spike and performance to crash—and in the Sonora Desert, dehydration quickly becomes a medical emergency.

- Pattern (Context): Measuring pre- vs. post-exercise body weight changes, fluid intake, and urine color/specific gravity in extreme desert heat.
- Rule (Constraint): Applying the clinical hydration replacement rule ( 1.25–1.5 L of fluid per 1.0 kg / 16–24 oz per lb of weight lost , plus sodium replacement).
- Solve (Intervention): Completing Mod 04 Discussion: Sweat Rate & Desert Hydration and Mod 04 Lab: Sweat Rate & Fluid Replacement Plan .

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 03 (Mod 03 Summary & Wrap-Up: Whole-Food Protein & Muscle Maintenance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 03: Resumen y Evaluación

Proteína Dietética, Umbral de Leucina y Retención de Masa Magra


### Step 1: Síntesis del Metabolismo Proteico y Masa Muscular

¡Felicitaciones por completar el Módulo 03! Ha dominado los mecanismos de la síntesis de proteína miofibrilar (MPS), los umbrales de leucina y la distribución de alimentos reales:

- Requerimientos Diarios (SSoT DGA / PAGA): La dosis de 0.8 g/kg es el mínimo para adultos sedentarios. En personas activas, la ingesta asciende a 1.2–2.2 g/kg/día para reparar tejido y generar adaptaciones.
- Disparador de Leucina y Tomas Diarias: Cada comida debe aportar de 0.25 a 0.40 g/kg de proteína completa (~2.5 a 3.5 g de leucina) distribuida cada 3 a 4 horas para activar la vía mTORC1.
- Resistencia Anabólica y Proteína Nocturna: Superar la resistencia anabólica en mayores de 50 años exige dosis de 0.40 a 0.55 g/kg/comida. Consumir de 30 a 40 g de proteína lenta antes de dormir evita el catabolismo nocturno.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría con IA

Los profesionales de la nutrición deportiva utilizan herramientas de IA generativa para auditar registros dietéticos y estructurar planes de comidas con alimentos integrales.

- Verificación de Macronutrientes: Auditoría de ingestas frente a las Guías Alimentarias federales y umbrales de leucina.
- Seguridad con Delimitadores (###): Uso de tres numerales ( ### ) para estructurar datos clínicos.
- Prescripción de Alimentos Reales: Priorización de fuentes completas y accesibles (huevos, aves, legumbres, lácteos) sobre suplementos costosos.

### Step 3: Autoevaluación del Módulo 03

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 04:


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: HLTH-150 Sintesis Modulo 03 ###:
Rol: Mentor Academico de Nutricion Deportiva y Dietetica Clinica.
SSoT: Guias Alimentarias para los Estadounidenses (DGA) y Pautas PAGA 2018 (2.a ed.).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Dosis basal sedentaria (0.8 g/kg) vs. Resistencia aeróbica (1.2-1.4 g/kg) vs. Fuerza (1.6-2.2 g/kg).
   Key Point: Umbrales por comida (0.25-0.40 g/kg vs. 0.40-0.55 g/kg en adultos mayores).
   Key Point: Disparador de leucina y activacion de mTORC1.
Step 2: Disenar un plan de 4 comidas con alimentos integrales accesibles para Yuma.
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 04 — Dinámica de Fluidos y Calor (Cálculo de Hidratación)

En palabras sencillas (Contexto Norteño): en el calorón de más de 105 °F de Yuma, sudar más del 2% de tu peso corporal hace que el corazón trabaje forzado y te pone en riesgo de agotamiento por calor. Si las ecuaciones de fluidos se ponen pesadas la próxima semana, concéntrate primero en aprender cómo pesar al atleta antes y después de entrenar y reponer de Outcome 1.25: a 1.5 litros de agua con electrolitos por cada kilo perdido .

- Patrón (Contexto): Medir la tasa de sudoración real mediante el cambio de peso antes y después del esfuerzo en el desierto.
- Regla (Restricción): Aplicar la regla clínica de reposición hídrica ( 1.25 a 1.5 L por cada kg perdido o 16–24 oz por libra, incluyendo sodio).
- Solución (Intervención): Completar el Foro del Mód 04 (Sweat Rate & Desert Hydration) y el Laboratorio del Mód 04 (Sweat Rate & Fluid Replacement Plan) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 03 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 03:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 03)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
