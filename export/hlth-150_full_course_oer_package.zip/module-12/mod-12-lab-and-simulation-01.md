## HLTH-150: Mod 12 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 12) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 12 Coaching Sprint Simulation: Safe & Realistic Weight Management

- Safe Rate of Weight Loss (0.5–1.0 lb/Week via 300–500 kcal/Day Deficit): Modest energy deficits preserve lean muscle mass, hormonal health, and training output, whereas crash diets (>1,000 kcal/day deficit) trigger muscle catabolism. En palabras sencillas: Recortar solo 300 a 500 calorías diarias permite bajar de media a una libra por semana cuidando tu músculo y tu energía diaria.
- Resting Metabolic Rate (RMR) Floor Protection: Daily caloric intake should never drop below a client's Resting Metabolic Rate (Mifflin-St Jeor equation) to prevent metabolic adaptation and nutrient deficiencies. En palabras sencillas: Nunca bajes la comida diaria por debajo de las calorías mínimas que el cuerpo necesita en reposo (RMR) para no apagar el metabolismo.
- High-Satiety Protein & Fiber Sparing Strategy (1.6–2.2 g/kg Protein): Elevating whole-food protein (1.6–2.2 g/kg/day) and high-volume vegetables/legumes during fat loss protects fat-free mass and keeps hunger controlled. En palabras sencillas: Subir la proteína real y las verduras/frijoles con fibra cuando buscas bajar grasa te mantiene satisfecho y protege tus músculos.

### Coach Alan's Weekly Check-In: Physics Meets Physiology

Team, welcome to Week 12! Last week we audited ergogenic aids and supplement regulations. This week, we examine the core science of weight management, energy balance, and body composition .

In clinical practice and athletic conditioning, weight management is plagued by crash diets and metabolic slowdown. As exercise professionals, we don't rely on gimmicks—we calculate Total Daily Energy Expenditure (TDEE), account for adaptive thermogenesis, and prescribe moderate deficits that preserve lean muscle mass using federal SSoT baselines (PAGA 2018 / DGA).


### Module 12 Tactical Roadmap / Ruta Táctica del Módulo 12

- Step 1: Required Readings: Master TDEE components (BMR, TEF, EAT, NEAT), adaptive thermogenesis, and body composition assessment methods.
- Step 2: Discussion Board: Audit real-world weight management case files against clinical standards by Thursday at 11:59 PM MST.
- Step 3: Lab 12 Audit: Complete your track's TDEE and deficit calculations, verify via the Gemini AI Tool Kit, and submit by Monday at 11:59 PM MST.
- Step 4: Module 12 Knowledge Check: Lock in your mastery of energy balance and lean tissue preservation.
Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Desert Sweat-Rate, Body Mass Loss (<2% BML) & Safe Weight Auditor (/simulators/desert-sweat-rate) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Distinguish acute dehydration weight loss in Yuma heat (keep Body Mass Loss <2% with 16–24 oz/lb fluid replacement) from safe sustainable energy deficits (300–500 kcal/day; 0.5–1.0 lb/week per DGA 2025–2030). Copy your VERIFIED simulator receipt or slider values into the submission template below • Paired Energy Availability & Safe Deficit route: /simulators/energy-availability-auditor .

Open Desert Sweat-Rate, Body Mass Loss (<2% BML) & Safe Weight Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/desert-sweat-rate y "PAGA"): Distinga la pérdida aguda de peso por sudor en Yuma (mantener <2% de pérdida de masa corporal con 16–24 oz/lb de reposición) de una meta segura de peso (déficit de 300–500 kcal/día según DGA 2025–2030). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile) / Fase 1: Elija su Ruta y Caso Clínico

Select ONE of the three Module 12 client tracks below to use with the embedded simulator above and your 4-Part Blank Submission Template at the bottom of the page:

68-year-old female outpatient physical therapy patient in Yuma with sarcopenic obesity. Data: Mass: 85.0 kg | Height: 160 cm | Activity: Sedentary ( 1.2 ) | Goal: Lose fat safely ( 300–500 kcal/day deficit) while preserving lean muscle mass ( 1.6–2.2 g/kg protein).

45-year-old working parent in Yuma County seeking sustainable weight management. Data: Mass: 95.0 kg | Height: 175 cm | Activity: Lightly Active ( 1.375 ) | Goal: Lose 1.0 lb/week sustainably using affordable whole foods without dropping below RMR.

22-year-old AWC Matador collegiate combat athlete managing a weight-class transition. Data: Mass: 84.0 kg | Height: 178 cm | Activity: Very Active ( 1.725 ) | Goal: Lean out safely without losing power or dehydrating beyond <2% BML in Yuma heat.


### The Coach's Playbook: Three Weight Management Traps to Avoid

Relying on severe caloric restriction (<1,000 kcal/day), triggering adaptive thermogenesis, severe muscle catabolism, and rapid weight regain.

Focusing exclusively on total scale weight while ignoring body composition, resulting in sarcopenic weight loss and lowered resting metabolic rate.

Failing to account for unconscious reductions in daily spontaneous movement (NEAT) during caloric restriction, stalling expected weight loss.


### AI Study Coach • Quick Concept Check

Want a 60-second quiz on this week's energy balance science before tackling the lab? Copy this prompt into Gemini:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Quiz Master Protocol: HLTH-150 Module 12 Coaching Sprint ###:
Role: Supportive HLTH-150 Study Coach.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Ask the student 3 quick multiple-choice questions testing:
   Section a: The four pillars of Total Daily Energy Expenditure (BMR, TEF, EAT, NEAT)
   Section b: The physiological mechanisms of adaptive thermogenesis during caloric restriction
   Section c: Recommended safe weekly weight loss parameters (0.5 to 2.0 lbs/week)
Step 2: Wait for the student's answer after each question before providing feedback.
Step 3: Keep feedback concise, encouraging, and anchored in evidence-based weight management strategies.
End Quiz Master Protocol ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 12 (Mod 12 Coaching Sprint: Safe & Realistic Weight Management)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 12 Sprint de Entrenamiento: Balance Energético y Composición Corporal


### Mensaje Semanal del Entrenador Alan: La Física se Une a la Fisiología

¡Equipo, bienvenidos a la Semana 12! La semana pasada auditamos las ayudas ergogénicas. Esta semana examinamos la ciencia central del control de peso, el balance energético y la composición corporal .

En la práctica clínica y el acondicionamiento, el control de peso está plagado de dietas de choque y desaceleración metabólica. Como profesionales del ejercicio, no dependemos de trucos: calculamos el Gasto Energético Diario Total (TDEE), consideramos la termogénesis adaptativa y prescribimos déficits moderados usando las normas federales (PAGA 2018 / DGA).


### Ruta Táctica del Módulo 12

- Step 1: Lecturas Obligatorias: Dominar los componentes del TDEE (BMR, TEF, EAT, NEAT), la termogénesis adaptativa y los métodos de evaluación corporal.
- Step 2: Foro de Discusión: Auditar casos de control de peso frente a normas clínicas antes del jueves a las 11:59 PM MST.
- Step 3: Laboratorio 12: Completar los cálculos de TDEE y déficit, verificar con Gemini IA y entregar antes del lunes a las 11:59 PM MST.
- Step 4: Comprobación de Conocimientos: Afianzar el dominio sobre balance energético y preservación de tejido magro.

### Estrategia del Entrenador: Tres Errores de Control de Peso que Debes Evitar

Confiar en restricciones calóricas severas (<1,000 kcal/día), desencadenando termogénesis adaptativa, catabolismo muscular y rápido recupero de peso.

Enfocarse exclusivamente en el peso total de la báscula ignorando la composición corporal, provocando pérdida muscular y reducción del metabolismo basal.

No considerar las reducciones inconscientes en el movimiento espontáneo diario (NEAT) durante la restricción, estancando la pérdida de peso.


### Entrenador de Estudio con IA • Repaso Rápido

¿Desea una autoevaluación rápida de 60 segundos antes de realizar la práctica de laboratorio? Copie este prompt en Gemini:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Quiz Master Protocol: HLTH-150 Modulo 12 Coaching Sprint ###:
Rol: Tutor de Estudio Solidario para HLTH-150.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Hacer al estudiante 3 preguntas rapidas de opcion multiple evaluando:
   Section a: Los cuatro pilares del TDEE (BMR, TEF, EAT, NEAT)
   Section b: Los mecanismos fisiológicos de la termogénesis adaptativa durante la restricción
   Section c: Los parámetros semanales recomendados de pérdida segura de peso (0.5 a 2.0 lbs/semana)
Step 2: Esperar la respuesta del estudiante tras cada pregunta antes de retroalimentar.
Step 3: Mantener explicaciones claras, motivadoras y fundamentadas en estrategias de control de peso basadas en evidencia.
Fin del Protocolo Quiz Master ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 12)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 12)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
