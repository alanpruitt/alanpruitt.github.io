# HLTH-150: Mod 12 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 12 Discussion: Fad Diets vs. Sustainable Real-Food Habits

- Safe Rate of Weight Loss (0.5–1.0 lb/Week via 300–500 kcal/Day Deficit): Modest energy deficits preserve lean muscle mass, hormonal health, and training output, whereas crash diets (>1,000 kcal/day deficit) trigger muscle catabolism. En palabras sencillas: Recortar solo 300 a 500 calorías diarias permite bajar de media a una libra por semana cuidando tu músculo y tu energía diaria.
- Resting Metabolic Rate (RMR) Floor Protection: Daily caloric intake should never drop below a client's Resting Metabolic Rate (Mifflin-St Jeor equation) to prevent metabolic adaptation and nutrient deficiencies. En palabras sencillas: Nunca bajes la comida diaria por debajo de las calorías mínimas que el cuerpo necesita en reposo (RMR) para no apagar el metabolismo.
- High-Satiety Protein & Fiber Sparing Strategy (1.6–2.2 g/kg Protein): Elevating whole-food protein (1.6–2.2 g/kg/day) and high-volume vegetables/legumes during fat loss protects fat-free mass and keeps hunger controlled. En palabras sencillas: Subir la proteína real y las verduras/frijoles con fibra cuando buscas bajar grasa te mantiene satisfecho y protege tus músculos.

### Auditing TDEE Components, Caloric Deficits & Adaptive Thermogenesis

Weight management in clinical and community settings requires moving past restrictive fad diets to examine the true physiological components of Total Daily Energy Expenditure (TDEE) and adaptive thermogenesis. Designing a sustainable caloric deficit protects lean muscle mass and prevents metabolic slowdown. Select your Build Your Own Journey Track below, audit a real-world weight management case using Google Gemini, and apply federal and sports nutrition standards ( PAGA 2018 / U.S. Dietary Guidelines / ACSM Position Stands )!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #150-12

Choose ONE of the three career-aligned tracks below to copy into your AI query:

Focus: Managing sarcopenic obesity and preserving lean muscle mass during therapeutic weight loss in older adults.

Focus: Sustainable community wellness programs in Yuma County, addressing chronic disease prevention and energy balance.

Focus: Weight-class management in combat sports or endurance athletes without sacrificing power output or bone density.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Metabolic Error / Ruta y Error Metabólico: State your chosen track and report the client's current weight management errors (e.g., crash dieting, rapid weight cutting, or sarcopenic muscle loss). Indique la ruta seleccionada y reporte los errores de control de peso del cliente (ej. dietas de choque o pérdida rápida de peso).
- Clinical Framing Protocol (Pattern / Rule / Solve) Analysis (Pattern / Rule / Solve) / Análisis del Protocolo de Marco Clínico (Patrón / Regla / Solución): Explain why aggressive restriction compromises metabolic health due to adaptive thermogenesis (Pattern), cite federal/ACSM safe weight loss standards (Rule), and provide the sustainable energy balance protocol (Solve). Explique por qué la restricción agresiva afecta la salud metabólica por termogénesis adaptativa (Patrón), cite las pautas ACSM/USDA (Regla) y detalle el protocolo sostenible (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence explanation of the sustainable weight management plan in both English and Spanish so your client can execute it easily. Proporcione una explicación concisa de 2 oraciones sobre el plan de control de peso en inglés y español para que su cliente la aplique fácilmente.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate their caloric deficit calculations, compare lean mass preservation strategies, and discuss how energy balance protocols must adapt across clinical, community, and athletic settings.


### 10/10 High-Fidelity Student Exemplar / Modelo 10/10

Pattern Recognition: Athlete R.V. attempts to cut 8.0 kg rapidly for wrestling certification using extreme starvation (1,000 kcal/day) and dehydration. This violates safe weight-cutting velocity (>2% body mass/week), triggering severe adaptive thermogenesis, muscle catabolism, and loss of competitive power output.

Rule Application (ACSM / PAGA 2018 Standards): According to ACSM and sports nutrition standards, safe weight loss for athletes should not exceed 0.5% to 1.0% of body mass per week. Maintaining high protein intake (1.6 to 2.0 g/kg) and progressive resistance training preserves lean tissue during a moderate caloric deficit.

Solve (Sustainable Energy Balance Protocol): We restructure R.V.'s weight-class transition:

- Caloric Deficit: Moderate deficit of 500 kcal/day to achieve a safe loss of 1.0 lb/week over an extended timeline.
- Protein Preservation: Elevate daily protein to 2.0 g/kg body weight using lean whole foods (chicken breast, fish, Greek yogurt) to protect muscle tissue.
- Gradual Water Management: Eliminate acute starvation; utilize glycogen management and gradual fluid tapering in the final 24 hours rather than severe dehydration.
EN: "Lose weight gradually with a moderate caloric deficit and high protein intake to protect your strength and athletic power."

ES: "Pierda peso gradualmente con un déficit calórico moderado y alta ingesta de proteína para proteger su fuerza y potencia atlética."

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 12 (Mod 12 Discussion: Fad Diets vs. Sustainable Real-Food Habits)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Mód 12 Foro de Discusión: Dietas de Moda vs. Balance Energético


### Auditoría de TDEE, Déficit Calórico y Termogénesis Adaptativa

Analice el caso seleccionado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) para auditar el control de peso según las pautas federales y de nutrición deportiva.


### Estructura de Entrega para el Foro


#### Parte 1: Reconocimiento de Patrones

Reporte los errores de control de peso del cliente (ej. dietas de choque o corte rápido de peso en deportes).


#### Parte 2: Aplicación de Reglas (Normas PAGA 2018 / ACSM)

Explique la termogénesis adaptativa y justifique la necesidad de un déficit moderado (0.5 a 2.0 lbs/semana) con alta ingesta proteica.


#### Parte 3: Resolución de la Brecha (Protocolo Sostenible y Tarjeta Bilingüe)

Diseñe un protocolo sostenible con alimentos integrales y proporcione una tarjeta de instrucciones en inglés y español.


### Modelo de Respuesta de Alta Fidelidad 10/10

El atleta R.V. intenta cortar 8 kg rápidamente con inanición (1,000 kcal/día) y deshidratación. Esto viola el ritmo seguro de pérdida de peso, desencadenando termogénesis adaptativa, catabolismo muscular y pérdida de potencia.

Las pautas de ACSM establecen que la pérdida segura no debe superar el 0.5% al 1.0% de masa corporal por semana. Mantener una ingesta alta de proteína (1.6 a 2.0 g/kg) preserva el tejido magro durante un déficit moderado.

Protocolo Sostenible: Déficit moderado de 500 kcal/día, elevación de proteína a 2.0 g/kg con alimentos integrales y eliminación de la inanición aguda. Tarjeta de Instrucción Bilingüe: "Pierda peso gradualmente con un déficit calórico moderado y alta ingesta de proteína para proteger su fuerza y potencia atlética."

HLTH-150 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
