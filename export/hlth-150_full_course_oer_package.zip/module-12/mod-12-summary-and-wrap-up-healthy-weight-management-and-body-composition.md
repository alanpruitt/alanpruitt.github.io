## HLTH-150: Mod 12 Summary And Wrap Up Healthy Weight Management And Body Composition

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports & Exercise


## Mod 12 Summary & Wrap-Up: Healthy Weight Management & Body Composition

Balance Energético, Adaptación Metabólica y Control de Peso Sostenible


### Step 1: Core Energy Balance & Body Composition Synthesis

Congratulations on completing Module 12! You have successfully mastered the physiological mechanics of energy expenditure, adaptive thermogenesis, and sustainable body composition management:

- The Four Pillars of TDEE: Total Daily Energy Expenditure comprises Basal Metabolic Rate (BMR), Thermic Effect of Food (TEF), Exercise Activity Thermogenesis (EAT), and Non-Exercise Activity Thermogenesis (NEAT).
- Adaptive Thermogenesis: Prolonged aggressive caloric restriction downregulates thyroid hormones and suppresses NEAT, causing metabolic slowdown and weight loss plateaus.
- Safe Weight Loss Parameters: A moderate caloric deficit of 500 to 750 kcal/day producing 0.5 to 2.0 lbs of weight loss per week, paired with resistance training and high protein intake (1.2 to 2.0 g/kg), preserves lean tissue.

### Step 2: Workplace Intelligence & AI Safety Auditor Protocol

In clinical dietetics and public health coaching, professionals utilize secure AI simulation frameworks to audit energy balance calculations and protect client metabolic health.

- AI-Assisted Metabolic Calculations: Nutritionists prompt AI preceptors to evaluate Mifflin-St Jeor BMR, TDEE, caloric deficits, and protein targets with absolute mathematical precision.
- Delimiter Security Protocol (###): Client demographic variables, anthropometric measurements, and activity factors must be enclosed inside triple hashes ( ### ) to maintain strict data boundary isolation during automated preceptor analysis.
- Clinical Auditing: Professionals verify AI outputs against federal SSoT standards (PAGA 2018 / DGA) to guarantee client safety and eliminate crash-diet risks.

### Step 3: Module 12 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 13:

English Calculation: Basal Metabolic Rate (BMR) accounts for 60% to 75% of total daily energy expenditure, representing the baseline energy required to sustain vital organ function.

Cálculo en Español: La Tasa Metabólica Basal (BMR) representa del 60% al 75% del gasto energético diario total, siendo la energía basal necesaria para sustentar las funciones orgánicas vitales.

English Rationale: Severe caloric restriction suppresses thyroid hormone production, reduces sympathetic nervous system activity, and decreases NEAT to conserve energy, lowering overall caloric burn.

Justificación en Español: La restricción calórica severa suprime la producción de hormonas tiroideas, reduce la actividad simpática y disminuye el NEAT para conservar energía, reduciendo el gasto calórico total.

English Rationale: A sustainable weight loss of 0.5 to 2.0 lbs per week, achieved via a moderate caloric deficit of 500 to 750 kcal/day, preserves lean muscle mass and minimizes metabolic slowdown.

Justificación en Español: Una pérdida sostenible de 0.5 a 2.0 lbs por semana, lograda mediante un déficit moderado de 500 a 750 kcal/día, preserva la masa muscular magra y minimiza la desaceleración metabólica.

English Response: Enclosing client demographic variables and activity logs inside triple hashes ( ### ) ensures clean data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 standards.

Respuesta en Español: Encapitular las variables demográficas y registros de actividad del cliente entre delimitadores de tres numerales ( ### ) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con PAGA 2018.

English Response: This combination provides the necessary mechanical tension and amino acid signaling to stimulate muscle protein synthesis, ensuring weight loss comes from fat mass rather than lean muscle tissue.

Respuesta en Español: Esta combinación proporciona la tensión mecánica y señalización de aminoácidos necesaria para estimular la síntesis proteica, asegurando que la pérdida de peso provenga de la grasa y no del músculo.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.


### AI Simulation Workspace • Exam Simulation & Synthesis

Copy the prompt below into Gemini to generate a personalized review sheet comparing ergogenic aids (Module 11) and energy balance (Module 12):

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: HLTH-150 Supplement & Energy Synthesis ###:
Role: Clinical Sports Nutritionist and Academic Tutor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Ergogenic Aids (Class A Validation, Third-Party Batch Certification)
   Key Point: Energy Balance (TDEE Components, Adaptive Thermogenesis)
Step 2: Explain how adaptive thermogenesis sabotages aggressive caloric restriction.
Step 3: Provide 3 whole-food nutrition strategies that support sustainable weight management and lean tissue preservation.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 13 — Community Nutrition, Food Security & Cultural Foodways

In plain English, next week in Module 13: Community Nutrition, Food Security & Cultural Foodways you will learn how to build nutrient-dense, culturally authentic Sonoran and Borderland meal plans that fit a tight family grocery budget (USDA Thrifty Food Plan / SNAP). Why it matters: AI meal planners love to recommend expensive ingredients like wild salmon and organic berries—you will learn how to honor traditional staples like pinto beans, corn tortillas, calabacitas, eggs, and seasonal produce.

- Pattern (Context): Auditing neighborhood food access, grocery costs, and cultural food preferences in Yuma County and Imperial Valley.
- Rule (Constraint): Applying the 2025–2030 DGA Cultural Foodways framework alongside USDA Thrifty Food Plan / SNAP budget constraints.
- Solve (Intervention): Completing Mod 13 Discussion: Cultural Foodways & Food Security and Mod 13 Lab: Culturally Grounded Budget Meal Plan .
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 12 (Mod 12 Summary & Wrap-Up: Healthy Weight Management & Body Composition)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 12: Resumen y Comprobación de Conocimientos


### Síntesis del Módulo 12: Balance Energético y Composición Corporal

Esta semana analizamos la ciencia fundamental del balance energético y el control de peso. Evaluamos los componentes del TDEE (BMR, TEF, EAT, NEAT), la termogénesis adaptativa y los parámetros seguros de pérdida de peso.

Al vincular las normas federales ( pautas de PAGA 2018 / DGA ) con los protocolos de preservación de masa magra, consolidó una base científica para prescribir estrategias sostenibles en entornos clínicos, comunitarios y deportivos.


### Conclusiones del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) • Patrón, Regla, Solución

Las dietas de choque severas desencadenan termogénesis adaptativa, suprimiendo hormonas tiroideas y NEAT, lo que provoca estancamiento y recuperación de peso.

Establecer un déficit moderado (500 a 750 kcal/día) logrando una pérdida de 0.5 a 2.0 lbs semanales combinada con entrenamiento de resistencia y alta proteína.

Implementar un enfoque basado en alimentos integrales y metas proteicas (1.2 a 2.0 g/kg) para asegurar que la pérdida provenga de la masa grasa.


### Autoevaluación del Módulo 12 (Verificación Bilingüe)

Presione cada elemento para verificar su comprensión:

Respuesta en Español: La Tasa Metabólica Basal (BMR) representa del 60% al 75% del gasto energético diario total, siendo la energía basal necesaria para sustentar las funciones orgánicas vitales.

English Calculation: Basal Metabolic Rate (BMR) accounts for 60% to 75% of total daily energy expenditure, representing the baseline energy required to sustain vital organ function.

Respuesta en Español: La restricción calórica severa suprime la producción de hormonas tiroideas, reduce la actividad simpática y disminuye el NEAT para conservar energía, reduciendo el gasto calórico total.

English Rationale: Severe caloric restriction suppresses thyroid hormone production, reduces sympathetic nervous system activity, and decreases NEAT to conserve energy, lowering overall caloric burn.

Respuesta en Español: Una pérdida sostenible de 0.5 a 2.0 lbs por semana, lograda mediante un déficit moderado de 500 a 750 kcal/día, preserva la masa muscular magra y minimiza la desaceleración metabólica.

English Rationale: A sustainable weight loss of 0.5 to 2.0 lbs per week, achieved via a moderate caloric deficit of 500 to 750 kcal/day, preserves lean muscle mass and minimizes metabolic slowdown.

Respuesta en Español: Encapitular las variables demográficas y registros de actividad del cliente entre delimitadores de tres numerales ( ### ) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con PAGA 2018.

English Response: Enclosing client demographic variables and activity logs inside triple hashes ( ### ) ensures clean data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 standards.

Respuesta en Español: Esta combinación proporciona la tensión mecánica y señalización de aminoácidos necesaria para estimular la síntesis proteica, asegurando que la pérdida de peso provenga de la grasa y no del músculo.

English Response: This combination provides the necessary mechanical tension and amino acid signaling to stimulate muscle protein synthesis, ensuring weight loss comes from fat mass rather than lean muscle tissue.

Respuesta en Español: Las Guías Alimentarias para Estadounidenses vigentes y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal.

English Response: The current U.S. Dietary Guidelines for Americans and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serve as the primary federal Single Source of Truth.


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Review Master Protocol: HLTH-150 Sintesis de Suplementos y Energia ###:
Rol: Nutriologo Deportivo Clinico y Tutor Academico en la voz del Narrator.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Ayudas Ergogenicas (Class A Validation, Third-Party Batch Certification)
   Key Point: Balance Energetico (TDEE Components, Adaptive Thermogenesis)
Step 2: Explicar como la termogenesis adaptativa sabotea la restriccion calorica agresiva.
Step 3: Proponer 3 estrategias de nutricion con alimentos integrales que apoyan el control de peso sostenible y la preservacion magra.
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 13 — Nutrición Comunitaria, Seguridad Alimentaria y Tradiciones Culinarias

En palabras sencillas (Contexto Norteño): comer saludable no significa comprar salmón carísimo ni ingredientes raros; nuestra cocina tradicional con frijoles pintos, tortilla de maíz, calabacitas, huevo y fruta de temporada es oro puro nutricional y cuida el bolsillo. La próxima semana aprenderás a corregir a la IA cuando ignore nuestra cultura o el presupuesto familiar (SNAP / WIC) bajo las guías DGA 2025–2030 .

- Patrón (Contexto): Evaluar el acceso a alimentos, el presupuesto familiar y las tradiciones culinarias del desierto de Sonora y la frontera.
- Regla (Restricción): Aplicar el marco de Tradiciones Culturales de DGA 2025–2030 dentro de un presupuesto realista (Plan Económico de Alimentos del USDA / SNAP).
- Solución (Intervención): Completar el Foro del Mód 13 (Cultural Foodways & Food Security) y el Laboratorio del Mód 13 (Culturally Grounded Budget Meal Plan) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 12 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 12:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 12)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 12)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
