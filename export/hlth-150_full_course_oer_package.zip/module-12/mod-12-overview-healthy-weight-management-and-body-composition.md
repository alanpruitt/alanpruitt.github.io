# HLTH-150: Mod 12 Overview Healthy Weight Management And Body Composition

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 12 Overview: Healthy Weight Management & Body Composition

El Porqué del Módulo 12 (Círculo Dorado — Contexto Norteño): “¿Por qué las dietas extremas de hambre rebotan quitando músculo y frenando el metabolismo, y cómo un déficit moderado con comida real cuida tu salud a largo plazo?”


### Module 12 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 12: Healthy Weight Management & Body Composition

Welcome to Week 12! Building upon our study of dietary regulations and ergogenic aids, this week we examine the foundational science of energy balance and body composition . In clinical practice, public health initiatives, and athletic conditioning, weight management is frequently oversimplified into restrictive fad diets. As exercise professionals, we look past commercial fads to evaluate energy expenditure components (Basal Metabolic Rate, Thermic Effect of Food, Exercise Activity, and Non-Exercise Activity Thermogenesis).

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify energy balance disruption patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and Dietary Guidelines for Americans (DGA) standards, and design sustainable lifestyle intervention protocols.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, November 3, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, November 5, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, November 8, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, November 9, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 12 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze components of total daily energy expenditure (TDEE) and identify metabolic adaptation patterns during caloric restriction. Analizar los componentes del gasto energético diario total (TDEE) e identificar patrones de adaptación metabólica durante la restricción calórica.
- CLO 2 (Rule Application): Apply PAGA 2018 and DGA energy balance baselines, safe weight-loss parameters (0.5 to 2.0 lbs per week), and body composition assessment standards. Aplicar las normas de balance energético de PAGA 2018 y DGA, parámetros seguros de pérdida de peso y estándares de composición corporal.
- CLO 3 (Problem Solving): Formulate an evidence-based, sustainable weight management and body composition protocol incorporating whole foods and physical activity tailored to diverse populations. Formular un protocolo de control de peso y composición corporal sostenible basado en evidencia y adaptado a poblaciones diversas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Managing sarcopenic obesity in older adults, preserving lean muscle mass during therapeutic weight loss, and evaluating metabolic rate changes.

Designing community wellness programs in Yuma County, addressing chronic disease prevention through sustainable lifestyle modifications, and overcoming food insecurity.

Optimizing weight-class management in combat or endurance sports without sacrificing power output, glycogen reserves, or bone mineral density.


### Module 12 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: TDEE Components, Metabolic Adaptation & Body Composition
- Discussion Board: Fad Diets vs. Sustainable Energy Balance Protocols
- Lab Assignment: TDEE Calculation, Caloric Deficit Audit & Gemini AI Tool Kit
- Knowledge Check & Module Summary
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 12 (Mod 12 Overview: Healthy Weight Management & Body Composition)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 12 Visión General: Control de Peso y Composición Corporal


### Bienvenido al Módulo 12: Balance Energético, Tasa Metabólica y Estilo de Vida Sostenible

¡Bienvenido a la Semana 12! Basándonos en nuestro estudio sobre suplementos, esta semana examinamos la ciencia fundamental del balance energético y la composición corporal . En la práctica clínica y la salud pública, el control de peso suele simplificarse con dietas de moda restrictivas. Como profesionales, evaluamos los componentes del gasto energético (BMR, TEF, EAT y NEAT) sin caer en mitos comerciales.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones de alteración energética, aplicarás las normas de PAGA 2018 y DGA, y diseñarás protocolos de intervención sostenibles.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar los componentes del gasto energético diario total (TDEE) e identificar patrones de adaptación metabólica durante la restricción calórica.
- CLO 2 (Regla): Aplicar las normas de balance energético de PAGA 2018 y DGA, parámetros seguros de pérdida de peso (0.5 a 2.0 lbs por semana) y estándares de composición corporal.
- CLO 3 (Solución): Formular un protocolo de control de peso y composición corporal sostenible basado en evidencia e integrado con alimentos integrales.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, continuará trabajando dentro de la ruta profesional que haya seleccionado:

Manejo de la obesidad sarcopénica en adultos mayores, preservación de masa muscular durante pérdida de peso y evaluación de cambios metabólicos.

Diseño de programas comunitarios de bienestar en Yuma, prevención de enfermedades crónicas mediante modificaciones de estilo de vida y seguridad alimentaria.

Optimización del manejo de categorías de peso en deportes de combate o resistencia sin sacrificar potencia, glucógeno o densidad mineral ósea.


### Ruta de Aprendizaje del Módulo 12

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Componentes del TDEE, Adaptación Metabólica y Composición Corporal
- Foro de Discusión: Dietas de Moda vs. Protocolos Sostenibles de Balance Energético
- Práctica de Laboratorio: Cálculo del TDEE, Auditoría de Déficit Calórico y Caja de Herramientas de IA
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en HLTH-150 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA. Esta estructura es responsiva en dispositivos móviles, compatible con lectores de pantalla y diseñada para un acceso equitativo.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 12 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 12 Required Readings: Healthy Weight Management & Body Composition →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 12 Discussion: Fad Diets vs. Sustainable Real-Food Habits →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 12 Coaching Sprint: Safe & Realistic Weight Management →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 12 Lab: Daily Calorie Needs & Safe Weight Goal Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 12 Summary & Wrap-Up: Healthy Weight Management & Body Composition →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
