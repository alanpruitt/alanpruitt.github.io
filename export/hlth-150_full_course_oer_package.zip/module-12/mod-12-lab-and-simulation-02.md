## HLTH-150: Mod 12 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **HLTH-150 (Module 12) trains you to diagnose client movement and health patterns using 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise / Nutrición para el Deporte y el Ejercicio


## Mod 12 Lab & Simulation: Daily Calorie Needs & Safe Weight Goal Audit

- Safe Rate of Weight Loss (0.5–1.0 lb/Week via 300–500 kcal/Day Deficit): Modest energy deficits preserve lean muscle mass, hormonal health, and training output, whereas crash diets (>1,000 kcal/day deficit) trigger muscle catabolism. En palabras sencillas: Recortar solo 300 a 500 calorías diarias permite bajar de media a una libra por semana cuidando tu músculo y tu energía diaria.
- Resting Metabolic Rate (RMR) Floor Protection: Daily caloric intake should never drop below a client's Resting Metabolic Rate (Mifflin-St Jeor equation) to prevent metabolic adaptation and nutrient deficiencies. En palabras sencillas: Nunca bajes la comida diaria por debajo de las calorías mínimas que el cuerpo necesita en reposo (RMR) para no apagar el metabolismo.
- High-Satiety Protein & Fiber Sparing Strategy (1.6–2.2 g/kg Protein): Elevating whole-food protein (1.6–2.2 g/kg/day) and high-volume vegetables/legumes during fat loss protects fat-free mass and keeps hunger controlled. En palabras sencillas: Subir la proteína real y las verduras/frijoles con fibra cuando buscas bajar grasa te mantiene satisfecho y protege tus músculos.

### Lab Overview: TDEE Math, Deficit Formulation & Lean Mass Preservation

In clinical practice, community health initiatives, and athletic conditioning, designing an effective weight management program requires precise calculations of Basal Metabolic Rate, activity factors, caloric deficits, and protein targets anchored in federal standards.

In this lab, you will calculate Basal Metabolic Rate using the Mifflin-St Jeor equation, determine Total Daily Energy Expenditure (TDEE), formulate a safe caloric deficit anchored in PAGA 2018 standards , and use the Gemini AI Tool Kit with secure triple-hash delimiters (###) to audit an individualized weight management protocol across your chosen career track.


### Lab Logistics & Submission Terms / Horario y Condiciones

- Due Date / Fecha Límite: Monday, November 9, 2026, at 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry or Upload (Markdown / PDF)
- Points / Puntos: 50 Total Points (Scored via Rubric)
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 1: Biometrics Box → 3. Fuel Box (RMR, TDEE & Macronutrients) → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against 2025-2030 Dietary Guidelines for Americans (Real-Food Focus) ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Nutrition Coach (DGA 2025–2030) • USOPC Athlete Plates • Activity Audit • My Dashboard → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 3. Fuel Box (Tasa Metabólica y Macronutrientes) → 9. Solve Box ) y "PAGA" ( paga2018.dev → Nutrition Coach (DGA 2025–2030), Platos del Atleta USOPC y Activity Audit) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Part A: Choose Your Career Track & Client Scenario

Select the scenario that corresponds to your chosen professional pathway:

Client: 68-year-old female patient with sarcopenic obesity attending outpatient physical therapy. Data: Age: 68 | Sex: Female | Mass: 85.0 kg | Height: 160 cm | Activity Factor: Sedentary (1.2) | Goal: Preserve muscle while losing fat safely.

Client: 45-year-old working parent in Yuma County seeking sustainable weight management. Data: Age: 45 | Sex: Male | Mass: 95.0 kg | Height: 175 cm | Activity Factor: Lightly Active (1.375) | Goal: Lose 1.0 lb/week sustainably.

Client: 22-year-old collegiate combat athlete (AWC Matadors) managing weight-class transition. Data: Age: 22 | Sex: Male | Mass: 84.0 kg | Height: 178 cm | Activity Factor: Very Active (1.725) | Goal: Lean out safely without losing power output.


### Part B: Clinical Framing Protocol (Pattern / Rule / Solve) Calculations & TDEE Analysis

Perform the following calculations step-by-step for your selected track:

- Basal Metabolic Rate (Mifflin-St Jeor Equation): Calculate BMR using $[10 \times \text{weight (kg)}] + [6.25 \times \text{height (cm)}] - [5 \times \text{age}] + s$ (where $s = +5$ for males and $-161$ for females).
- Total Daily Energy Expenditure (TDEE): Multiply calculated BMR by the appropriate activity factor (1.2 to 1.725).
- Caloric Deficit Target (500 to 750 kcal/day): Establish a target intake to achieve a safe weight loss of 1.0 to 1.5 lbs per week.
- Protein Preservation Target (1.2 to 2.0 g/kg): Calculate daily protein grams required to prevent muscle catabolism during the caloric deficit.

### Part C: Gemini AI Tool Kit & Clinical Audit

Copy the prompt template below into Gemini AI to audit your manual calculations. All clinical inputs must remain enclosed within triple-hash delimiters (###):

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: HLTH-150 Energy Balance Tool Box ###:
Role: Clinical Sports Dietitian and Exercise Physiologist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and U.S. Dietary Guidelines for Americans (DGA).

Instructions:
Step 1: Audit the student's manual calculation of Mifflin-St Jeor BMR, Total Daily Energy Expenditure (TDEE), Caloric Deficit Target, and Protein Preservation Target.
Step 2: Evaluate the client's risk for adaptive thermogenesis, muscle wasting, or metabolic slowdown based on their target deficit.
Step 3: Formulate a sustainable energy balance and body composition protocol (Caloric Target, Macronutrient Distribution, Resistance Training) tailored to the client's setting.

Client Data Input ###:
Career Track: [Insert Track 1, 2, or 3]
Client Age: [Insert Years] | Sex: [Insert Male/Female]
Client Body Mass: [Insert kg] | Height: [Insert cm]
Activity Factor: [Insert 1.2 to 1.725]
Student Calculated BMR: [Insert kcal]
Student Calculated TDEE: [Insert kcal]
Student Calculated Caloric Deficit Target: [Insert kcal/day]
Student Calculated Protein Target: [Insert grams/day]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Submission Template

Copy and paste the template below into the Canvas submission box to complete your Lab assignment:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
HLTH-150 Module 12 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]

Step 1: Pattern Recognition & Energy Calculations:
Key Point: Client Demographics: Age ___ | Sex: ___ | Mass: ___ kg | Height: ___ cm
Key Point: Calculated Basal Metabolic Rate (BMR): ___ kcal
Key Point: Calculated Total Daily Energy Expenditure (TDEE): ___ kcal
Key Point: Target Caloric Intake (Deficit of 500 - 750 kcal): ___ kcal/day
Key Point: Target Daily Protein Intake (1.2 - 2.0 g/kg): ___ grams/day

Step 2: Rule Application (PAGA 2018 / DGA Standards):
Key Point: Analysis of adaptive thermogenesis and safe weight loss parameters for this client:
Key Point: Physiological importance of combining caloric moderation with resistance training:

Step 3: Problem Solving & Customized Weight Management Plan:
Key Point: Sustainable Caloric Deficit & Whole-Food Nutrition Strategy:
Key Point: Lean Mass Preservation Strategy (Protein & Resistance Exercise):
Key Point: Long-Term Behavioral Modification & Plateau Management Strategy:

Step 4: AI Tool Kit Audit Reflection:
Key Point: Summary of Gemini AI's audit of your calculations and delimiter compliance:
Key Point: Adjustments made to your final weight management prescription based on AI feedback:
End Submission ###:
```

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 12 (Mod 12 Lab: Daily Calorie Needs & Safe Weight Goal Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 12 Lab: Cálculo de TDEE y Auditoría de Déficit Calórico


### Visión General del Laboratorio: Matemáticas del TDEE y Preservación Muscular

En la práctica clínica, la salud comunitaria y el deporte, diseñar un programa eficaz de control de peso requiere cálculos precisos de Tasa Metabólica Basal, factores de actividad, déficit calórico y metas de proteína basados en normas federales.

En esta práctica calculará la Tasa Metabólica Basal mediante la ecuación de Mifflin-St Jeor, determinará el TDEE, formulará un déficit calórico seguro anclado en las normas de PAGA 2018 y utilizará la Caja de Herramientas de IA Gemini con delimitadores seguros (###) para auditar un protocolo en su ruta profesional.


### Logística de Laboratorio y Términos de Entrega

- Fecha Límite: Lunes, 9 de noviembre de 2026, a las 11:59 PM MST
- Formato: Entrada de texto directa en Canvas o archivo adjunto (Markdown / PDF)
- Puntaje: 50 Puntos Totales (Evaluados mediante Rúbrica)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Seleccione su Ruta Profesional y Caso Práctico

Elija el escenario correspondiente a su trayectoria vocacional:

Paciente: Mujer de 68 años con obesidad sarcopénica en fisioterapia ambulatoria. Datos: Edad: 68 | Sexo: Femenino | Masa: 85.0 kg | Altura: 160 cm | Factor de Actividad: Sedentaria (1.2) | Meta: Preservar músculo al perder grasa.

Cliente: Padre de familia de 45 años en Yuma buscando control de peso sostenible. Datos: Edad: 45 | Sexo: Masculino | Masa: 95.0 kg | Altura: 175 cm | Factor de Actividad: Ligeramente Activo (1.375) | Meta: Perder 1.0 lb/semana de forma sostenible.

Atleta: Atleta universitario de combate de 22 años (AWC Matadors) manejando transición de categoría de peso. Datos: Edad: 22 | Sexo: Masculino | Masa: 84.0 kg | Altura: 178 cm | Factor de Actividad: Muy Activo (1.725) | Meta: Definir sin perder potencia.


### Parte B: Cálculos del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y Análisis del TDEE

Realice los siguientes cálculos paso a paso para el caso seleccionado:

- Tasa Metabólica Basal (Ecuación de Mifflin-St Jeor): Calcule BMR usando [10 peso (kg)] + [6.25 altura (cm)] - [5 * edad] + s (donde s = +5 para hombres y -161 para mujeres).
- Gasto Energético Diario Total (TDEE): Multiplique el BMR calculado por el factor de actividad apropiado (1.2 a 1.725).
- Meta de Déficit Calórico (500 a 750 kcal/día): Establezca una ingesta objetivo para lograr una pérdida segura de 1.0 a 1.5 lbs por semana.
- Meta de Preservación de Proteína (1.2 a 2.0 g/kg): Calcule los gramos diarios de proteína necesarios para evitar el catabolismo muscular durante el déficit.

### Parte C: Caja de Herramientas de IA Gemini y Auditoría Clínica

Copie la siguiente plantilla en Gemini IA para auditar sus cálculos. Recuerde mantener los datos clínicos cerrados con delimitadores seguros (###):

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Safety Auditor Protocol: HLTH-150 Energy Balance Tool Box ###:
Rol: Dietista Deportivo Clinico y Fisiologo del Ejercicio.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) y Guias Alimentarias (DGA).

Instrucciones:
Step 1: Auditar los calculos manuales del estudiante sobre BMR de Mifflin-St Jeor, TDEE, Meta de Déficit Calórico y Meta de Proteína.
Step 2: Evaluar el riesgo del cliente de sufrir termogénesis adaptativa, pérdida muscular o desaceleración metabólica según su déficit objetivo.
Step 3: Formular un protocolo sostenible de balance energético y composición corporal (Meta calórica, distribución de macronutrientes, entrenamiento de resistencia).

Entrada de Datos del Cliente ###:
Ruta Profesional: [Insertar Ruta 1, 2 o 3]
Edad del Cliente: [Insertar Años] | Sexo: [Insertar Masculino/Femenino]
Masa Corporal del Cliente: [Insertar kg] | Altura: [Insertar cm]
Factor de Actividad: [Insertar 1.2 a 1.725]
BMR Calculado por Estudiante: [Insertar kcal]
TDEE Calculado por Estudiante: [Insertar kcal]
Meta de Déficit Calórico Calculada: [Insertar kcal/día]
Meta de Proteína Calculada: [Insertar gramos/día]
Fin de Datos del Cliente ###:
End Safety Auditor Protocol ###:
```


### Plantilla de Entrega

Copie y pegue la siguiente plantilla en Canvas para enviar su tarea de laboratorio:

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
HLTH-150 Entrega de Laboratorio Módulo 12 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clínica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]

Step 1: Reconocimiento de Patrones y Cálculos Energéticos:
Key Point: Datos del Cliente: Edad ___ | Sexo: ___ | Masa: ___ kg | Altura: ___ cm
Key Point: Tasa Metabólica Basal Calculada (BMR): ___ kcal
Key Point: Gasto Energético Diario Total Calculado (TDEE): ___ kcal
Key Point: Ingesta Calórica Objetivo (Déficit de 500 - 750 kcal): ___ kcal/día
Key Point: Ingesta Diaria de Proteína Objetivo (1.2 - 2.0 g/kg): ___ gramos/día

Step 2: Aplicación de Reglas (Normas PAGA 2018 / DGA):
Key Point: Análisis de termogénesis adaptativa y parámetros seguros de pérdida de peso para este cliente:
Key Point: Importancia fisiológica de combinar la moderación calórica con el entrenamiento de resistencia:

Step 3: Resolución de Problemas y Plan de Control de Peso Personalizado:
Key Point: Estrategia de Déficit Calórico Sostenible y Nutrición con Alimentos Integrales:
Key Point: Estrategia de Preservación de Masa Magra (Proteína y Ejercicio de Resistencia):
Key Point: Estrategia de Modificación Conductual a Largo Plazo y Manejo de Estancamientos:

Step 4: Reflexion de la Auditoria con IA:
Key Point: Resumen de la revisión de cálculos realizada por Gemini IA y cumplimiento de delimitadores:
Key Point: Ajustes aplicados a la prescripción final de control de peso según la retroalimentación de la IA:
Fin de la Entrega ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 12)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 12)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
