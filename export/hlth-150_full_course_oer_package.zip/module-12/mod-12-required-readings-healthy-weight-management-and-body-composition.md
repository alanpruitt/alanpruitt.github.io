## HLTH-150: Mod 12 Required Readings Healthy Weight Management And Body Composition

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 12 Required Readings: Healthy Weight Management & Body Composition

Lecturas Obligatorias: Componentes del TDEE, Adaptación Metabólica y Composición Corporal

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from 2025–2030 Dietary Guidelines for Americans (Real-Food Focus) & PAGA 2018), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 12): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Healthy body composition focuses on preserving lean muscle mass while adjusting daily calorie intake slowly and safely. Extreme crash diets strip away muscle tissue, slow resting metabolism, and undermine physical performance. Using modest calorie adjustments (300–500 kcal/day) and high-satiety whole foods protects long-term health.


#### En Palabras Sencillas (Norteño Context)

Querer bajar de peso dejando de comer de golpe es como quitarle piezas al chasis de tu troca para que pese menos: pierdes fuerza. Si los términos técnicos se ponen pesados, concéntrate primero en cómo lograr cambios graduales cuidando la masa muscular con alimentos ricos en fibra y proteína.


### Regional Focus: Public Health & Metabolic Health in Yuma County

Enfoque Regional: Salud Pública y Salud Metabólica en el Condado de Yuma

In Yuma County and southwestern Arizona, community health initiatives address chronic metabolic conditions, sarcopenic obesity, and energy balance disparities. Sustainable weight management requires understanding Total Daily Energy Expenditure (TDEE) and avoiding predatory commercial fad diets that trigger metabolic adaptation and muscle loss. Grounding clinical interventions in federal standards (PAGA 2018 and DGA) empowers health professionals to foster long-term behavioral change.

En el condado de Yuma y el suroeste de Arizona, las iniciativas de salud comunitaria abordan condiciones metabólicas crónicas y obesidad sarcopénica. El control de peso sostenible requiere comprender el Gasto Energético Diario Total (TDEE) y evitar dietas de moda restrictivas. Fundamentar las intervenciones clínicas en normas federales (PAGA 2018 y DGA) permite fomentar cambios conductuales a largo plazo.


### Reading 1: Components of Total Daily Energy Expenditure (TDEE)

Lectura 1: Componentes del Gasto Energético Diario Total (TDEE)


#### Step 1: The Four Pillars of Energy Expenditure

Los Cuatro Pilares del Gasto Energético

Total Daily Energy Expenditure (TDEE) represents the total number of calories burned by an individual over a 24-hour period. It comprises four distinct metabolic components:

El Gasto Energético Diario Total (TDEE) representa el total de calorías quemadas en un período de 24 horas, compuesto por cuatro elementos metabólicos distintos:

- Basal Metabolic Rate (BMR) / Resting Metabolic Rate (RMR): Accounts for 60% to 75% of TDEE, supporting vital organ function, cellular homeostasis, and core thermogenesis. Tasa Metabólica Basal (BMR): Representa del 60% al 75% del TDEE, sustentando las funciones orgánicas vitales y la homeostasis celular.
- Thermic Effect of Food (TEF): Accounts for 8% to 15% of TDEE, reflecting the energy cost of digesting, absorbing, metabolizing, and storing dietary macronutrients (highest for dietary protein at 20% to 30%). Efecto Térmico de los Alimentos (TEF): Representa del 8% al 15% del TDEE, reflejando el costo energético de procesar los macronutrientes.
- Exercise Activity Thermogenesis (EAT): Encompasses planned, structured physical exercise sessions (e.g., resistance training, running, swimming). Termogénesis por Actividad de Ejercicio (EAT): Abarca las sesiones de ejercicio físico estructurado y planificado.
- Non-Exercise Activity Thermogenesis (NEAT): Energy expended during daily living activities, fidgeting, posture maintenance, and occupational movement; highly variable among individuals. Termogénesis por Actividad sin Ejercicio (NEAT): Energía gastada en actividades de la vida diaria, postura y movimientos ocupacionales.

### Reading 2: Metabolic Adaptation & Safe Weight Loss Parameters

Lectura 2: Adaptación Metabólica y Parámetros Seguros de Pérdida de Peso


#### Step 1: Physiological Mechanisms of Adaptive Thermogenesis

Mecanismos Fisiológicos de la Termogénesis Adaptativa

During prolonged caloric restriction, the human body initiates adaptive thermogenesis—downregulating thyroid hormones (T3/T4), reducing sympathetic nervous system activity, and suppressing NEAT to conserve energy. This metabolic slowdown explains why aggressive crash diets invariably result in weight-loss plateaus and subsequent rebound weight gain.

Durante la restricción calórica prolongada, el cuerpo humano inicia termogénesis adaptativa, reduciendo hormonas tiroideas y suprimiendo el NEAT para conservar energía. Esta desaceleración metabólica explica por qué las dietas de choque generan estancamientos y rebote.


#### Step 2: Federal Weight Loss Standards (PAGA 2018 & DGA SSoT)

Normas Federales de Pérdida de Peso (SSoT PAGA 2018 y DGA)

In strict alignment with the Physical Activity Guidelines for Americans (PAGA 2018) and federal dietary standards:

En estricto apego a las normas de PAGA 2018 y las directrices federales:

- Safe Rate of Loss: A moderate caloric deficit of 500 to 750 kcal/day produces a sustainable weight loss of 0.5 to 2.0 lbs per week, preserving lean skeletal muscle mass and minimizing metabolic slowdown. Ritmo Seguro de Pérdida: Un déficit calórico moderado de 500 a 750 kcal/día produce una pérdida de 0.5 a 2.0 lbs por semana, preservando la masa magra.
- Resistance Training Priority: Combining caloric moderation with progressive resistance training and adequate protein intake (1.2 to 2.0 g/kg/day) is the clinical gold standard for improving body composition. Prioridad de Entrenamiento de Resistencia: Combinar moderación calórica con entrenamiento de resistencia y proteína adecuada es el estándar de oro clínico.

### Reading 3: Body Composition Assessment & Lifestyle Integration

Lectura 3: Evaluación de la Composición Corporal e Integración de Estilo de Vida

Assessing body composition involves quantifying fat mass versus fat-free mass (muscle, bone, water, and organs) using clinical methodologies:

Evaluar la composición corporal implica cuantificar la masa grasa frente a la masa libre de grasa utilizando metodologías clínicas:


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core reading material before proceeding to the Discussion and Lab:

Seleccione cada pregunta a continuación para confirmar su comprensión del material antes de continuar con la Discusión y el Laboratorio:

English Response: Basal Metabolic Rate (BMR) accounts for 60% to 75% of total daily energy expenditure, representing the baseline energy required to sustain vital organ function.

Respuesta en Español: La Tasa Metabólica Basal (BMR) representa del 60% al 75% del gasto energético diario total, siendo la energía basal necesaria para sustentar las funciones orgánicas vitales.

English Response: Severe caloric restriction suppresses thyroid hormone production, reduces sympathetic nervous system activity, and decreases NEAT to conserve energy, lowering overall caloric burn.

Respuesta en Español: La restricción calórica severa suprime la producción de hormonas tiroideas, reduce la actividad simpática y disminuye el NEAT para conservar energía, reduciendo el gasto calórico total.

English Response: A sustainable weight loss of 0.5 to 2.0 lbs per week, achieved via a moderate caloric deficit of 500 to 750 kcal/day, preserves lean muscle mass and minimizes metabolic slowdown.

Respuesta en Español: Una pérdida sostenible de 0.5 a 2.0 lbs por semana, lograda mediante un déficit moderado de 500 a 750 kcal/día, preserva la masa muscular magra y minimiza la desaceleración metabólica.

HLTH-150 • Module 12 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 12:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 12 (Mod 12 Required Readings: Healthy Weight Management & Body Composition)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `HLTH-150` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (HLTH-150 • Module 12)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: HLTH-150 (Module 12)
Client Pattern (Context): An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice.
Governing SSoT Rule: Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a HLTH-150 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### An 18-year-old Yuma distance runner trains at 6:00 AM (92°F, 1.2 L/hr sweat rate), skips breakfast, and relies on ultra-processed sugary energy drinks (46 g added sugar) before practice. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**), I identified two critical clinical errors. First, Per the 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus), active individuals should prioritize nutrient-dense whole carbohydrates, high-quality proteins, and plain water/electrolytes while limiting ultra-processed foods and keeping added sugars below strict daily limits. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)**. For the intervention (**Solve**), Calibrate fluid and macronutrient targets in exwtoolkit.com: replace the sugary energy drink with oatmeal, banana, and Greek yogurt 60–90 minutes pre-run, plus 16–24 oz of water with sodium electrolytes per pound of body-mass sweat loss. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
