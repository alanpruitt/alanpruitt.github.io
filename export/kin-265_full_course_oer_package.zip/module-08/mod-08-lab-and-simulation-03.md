## KIN-265: Mod 08 Lab And Simulation 03

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 08) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 08 Lab & Simulation: Vital Signs & Exercise Monitoring Audit

Laboratorio del Módulo 08: Monitoreo Cardiorrespiratorio y Simulación

- Submaximal Functional Field Testing (6-Minute Walk Test & Sit-to-Stand): Safe, self-paced clinical assessments for older or deconditioned populations that measure functional aerobic endurance and lower-body strength without maximal strain. En palabras sencillas: Pruebas clínicas seguras como la Caminata de 6 Minutos y Sentarse-Pararse en Silla para evaluar la condición física sin exponer al paciente al límite.
- Hemodynamic Exercise Response (Normal vs. Hypotensive/Hypertensive): Systolic BP should rise progressively with workload while diastolic BP remains stable (±10 mmHg); a drop in SBP >10 mmHg or SBP >250 / DBP >115 mmHg requires immediate termination. En palabras sencillas: Al subir el esfuerzo la presión sistólica debe subir de forma gradual; si cae más de 10 puntos o supera 250/115 mmHg, detenemos la prueba al instante.
- Pre- and Post-Session Vital Sign Verification Log: Recording resting heart rate, blood pressure, SpO2, symptoms, and medication timing before and after every clinical conditioning session. En palabras sencillas: Anotar pulso, presión arterial, oxigenación y si el paciente tomó sus medicamentos antes y después de cada sesión.

### Heart Rate Responses, Borg RPE, & PAGA Federal Safety Mandates

In this laboratory assignment, you will build and audit a safe exercise routine for an adult client taking medications that alter heart rate or blood pressure. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will evaluate how beta-blockers affect heart rate, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety rules, use triple-hash delimiters (`###`), and complete an AI-guided simulation using Google Gemini.

En esta práctica de laboratorio, diseñará y auditará una rutina de ejercicio segura para un cliente que toma medicamentos que alteran la frecuencia cardíaca o la presión arterial, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución).

- KIN-265.8.1.AY26-27: Prescribe safe aerobic exercise intensity using the Borg RPE scale for clients with altered heart rate responses. Prescribir intensidad de ejercicio aeróbico segura usando la escala Borg RPE para clientes con respuestas cardíacas alteradas.
- KIN-265.8.2.AY26-27: Audit clinical blood pressure safety limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de seguridad de presión arterial y aplicar protocolos de verificación de IA basados en delimitadores.
- Module Window / Ventana del Módulo: Opens Tuesday, October 6, 2026, at 12:00 AM MST Abre el martes, 6 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 12, 2026, at 11:59 PM MST Lunes, 12 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones clínicas

### Lab Objectives

Objetivos del Laboratorio

- Analyze how beta-blocker medications change resting and exercise heart rate responses. Analizar cómo los medicamentos betabloqueadores cambian las respuestas de la frecuencia cardíaca.
- Apply federal PAGA 2018 rules for blood pressure safety limits (stop test if SBP > 220 or DBP > 105). Aplicar las reglas federales de PAGA 2018 para los límites de seguridad de la presión arterial.
- Formulate a safe 4-week exercise plan using the Safety Auditor protocol (`###`) and a bilingual client instruction card. Formular un plan de ejercicio seguro de 4 semanas usando el protocolo del Auditor de Seguridad y una tarjeta bilingüe.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-08

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos Clínicos

Choose ONE of the client case profiles below:

Focus: Managing controlled hypertension while taking daily beta-blockers; establishing safe walking intensity using the Borg RPE scale.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI, keeping your chosen case profile inside the triple-hash delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

- Client Name: State the client profile you selected.
- Part 1: Pattern Recognition: Explain how beta-blocker medications affect heart rate and why standard heart rate targets do not apply.
- Part 2: Rule Application: Cite PAGA 2018 safety limits for blood pressure stop tests (SBP > 220 or DBP > 105) and Borg RPE intensity targets.
- Part 3: Solving the Gap: Outline a simple 4-week exercise plan and include the 2-sentence bilingual client instruction card.
- Repository Verification: Confirm your AI prompt exchange is saved to EXW_Professional_AI_Repository .
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying your pre-exercise vital-sign clearance gates, Borg RPE / Talk Test monitoring, and absolute stop-exercise criteria in Yuma's climate.

### Grading Rubric (10/7/0 Mastery Scale • Safety Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition: Robert takes a beta-blocker (metoprolol) for high blood pressure, which lowers his resting heart rate and stops his heart rate from rising normally during exercise. Standard heart rate formulas will not work for him, so we must monitor his workout intensity using the Borg RPE scale.

Part 2: Rule Application: According to PAGA 2018 guidelines, trainers must stop an exercise session immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic. We will keep Robert's walking intensity at a light-to-moderate level (Borg RPE 11 to 13) and use triple-hash delimiters (`###`) for our AI verification audit.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): Key Point — Aerobic Routine: Indoor treadmill or neighborhood walking 3 days per week for 30 minutes, maintaining an easy conversation pace (Borg RPE 11–13). Key Point — Strength Routine: Light resistance exercises 2 days per week focusing on major muscle groups, using continuous breathing to avoid breath-holding. Key Point — Safety Rule: Stop exercising if dizzy, short of breath, or if blood pressure crosses safety limits.

EN: "Because your blood pressure medication lowers your heart rate, use your perceived effort scale (RPE 11 to 13) to guide your workout instead of checking your pulse. Always breathe continuously while lifting weights to keep your blood pressure stable."

ES: "Debido a que su medicamento para la presión arterial reduce su frecuencia cardíaca, use su escala de esfuerzo percibido (RPE 11 a 13) para guiar su entrenamiento en lugar del pulso. Respire continuamente al levantar pesas para mantener estable su presión arterial."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI fitness app that pushes a client to 85% age-predicted HRmax ignores both beta-blocker chronotropic blunting and thermal cardiovascular drift in Yuma. As the human clinician, I verify resting blood pressure (<180/110 mmHg), pulse oximetry (>=88%), and blood glucose (100–250 mg/dL) before every session, regulate intensity using Borg RPE 11–13 and the Talk Test, and stand ready to terminate exertion immediately if SBP drops >10 mmHg with increasing workload or exceeds 220/105 mmHg. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M08_Lab_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 08 (Mod 08 Lab: Vital Signs & Exercise Monitoring Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 08 Práctica de Lab y Simulación: Monitoreo Cardiorrespiratorio y Simulación

Frecuencia cardíaca, escala Borg RPE y normas de seguridad PAGA


### Respuestas de la frecuencia cardíaca, escala Borg RPE y normas PAGA

En esta práctica de laboratorio, diseñará y auditará una rutina de ejercicio segura para un cliente que toma medicamentos que alteran la frecuencia cardíaca. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará cómo los betabloqueadores afectan el ritmo cardíaco, aplicará las normas de seguridad de PAGA 2018 (2.ª edición) y completará una simulación con Google Gemini.


### Estructura de Entrega de Texto


#### Nombre del Cliente

Indique el perfil del cliente seleccionado (Robert).


#### Parte 1: Reconocimiento de Patrones

Explique cómo los betabloqueadores afectan la frecuencia cardíaca y por qué las fórmulas tradicionales no funcionan.


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Cite los límites de seguridad de PAGA 2018 para la presión arterial (PAS > 220 / PAD > 105) y las metas de esfuerzo Borg RPE.


#### Parte 3: Resolución de la Brecha

Delinee un plan de ejercicio simple de 4 semanas e incluya la tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: Robert toma un betabloqueador para la presión arterial alta, lo que reduce su frecuencia cardíaca en reposo e impide que su pulso suba normalmente al hacer ejercicio. Las fórmulas estándar no funcionan, por lo que debemos usar la escala RPE de Borg.

Parte 2: Aplicación de Reglas: Según las pautas de PAGA 2018, debemos detener el ejercicio de inmediato si la presión arterial supera los 220 mmHg sistólica o los 105 mmHg diastólica. Mantendremos la intensidad en un nivel moderado (Borg RPE 11 a 13) y usaremos delimitadores de tres numerales (`###`).

Parte 3: Resolución de la Brecha: Caminata en interior o vecindario 3 días por semana durante 30 minutos (RPE 11–13) y ejercicios de fuerza ligeros 2 días por semana. Tarjeta Bilingüe: "Debido a que su medicamento para la presión arterial reduce su frecuencia cardíaca, use su escala de esfuerzo percibido (RPE 11 a 13) para guiar su entrenamiento en lugar del pulso. Respire continuamente al levantar pesas para mantener estable su presión arterial."

Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica sus filtros de signos vitales en reposo, el monitoreo con Borg RPE / prueba del habla y los criterios absolutos para detener el ejercicio en Yuma.

Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, una aplicación de IA que exige alcanzar el 85% de la FCmáx teórica ignora el bloqueo cardíaco por betabloqueadores y la deriva térmica en el calor de Yuma. Como especialista humano, verifico signos vitales en reposo (PA <180/110 mmHg, SpO2 >=88%, glucosa 100–250 mg/dL), regulo la carga con Borg RPE 11–13 y detengo la sesión de inmediato ante cualquier signo de alarma hemodinámica."

Verificación del Repositorio: Registro de auditoría guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M08_Lab_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 08 Quick Return Navigation / Regreso Rápido al Módulo 08:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 08)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 08)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
