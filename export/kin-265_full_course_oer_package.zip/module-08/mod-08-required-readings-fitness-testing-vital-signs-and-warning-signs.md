## KIN-265: Mod 08 Required Readings Fitness Testing Vital Signs And Warning Signs

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 08 Required Readings: Fitness Testing, Vital Signs & Warning Signs

Lecturas Clínicas Obligatorias: Monitoreo Cardiorrespiratorio y Seguridad en el Ejercicio


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Clinical pre-participation screening and vital-sign audits identify hidden cardiovascular or orthopedic risks before a client starts exercising. By checking resting heart rate, blood pressure, medication side effects, and functional walk/balance tests, you establish a safe baseline. Knowing exact stop-exercise red flags ensures immediate action if a client feels dizzy or short of breath.


#### En Palabras Sencillas (Norteño Context)

Antes de sacar una maquinaria a trabajar al campo, primero revisas niveles, frenos y presión para no arriesgar al operador. Si los términos técnicos se ponen pesados, concéntrate primero en los límites seguros de signos vitales en reposo y las señales absolutas para detener la prueba de inmediato.

All required reading chapters, federal safety guidelines, and clinical monitoring principles are embedded directly below. No external textbook purchases or paid downloads are required.

Todos los capítulos de lectura requeridos, las directrices federales de seguridad y los principios de monitoreo clínico están integrados directamente abajo. No se requiere comprar libros de texto externos.


### Required SSoT Text & Federal Guidelines / Texto Fuente SSoT y Lineamientos Federales

Primary Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • Chapter 7: Active Adults with Chronic Health Conditions and Disabilities (Cardiorespiratory Focus).

Fuente Única de Verdad Primaria (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) • Capítulo 7: Adultos Activos con Afecciones Crónicas y Discapacidades (Enfoque Cardiorrespiratorio).

Primary SSoT Anchor: Chapter 7: Safe Physical Activity Prescriptions for Individuals with Cardiorespiratory Limitations.

Referencia Central SSoT: Capítulo 7: Prescripciones Seguras de Actividad Física para Personas con Limitaciones Cardiorrespiratorias.

- Official Federal Guidelines Portal / Portal Federal Oficial: PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev)
- Course Offline Repository Document / Documento del Repositorio: exw265_ssot_special_populations_reference.docx (Download to study offline or upload to your AI Repository / Descargue para estudiar sin conexión o suba a su Repositorio de IA)
Clinical Focus: Monitoring heart rate response, rating of perceived exertion (RPE), and recognizing when to stop a session.

Enfoque Clínico: Monitoreo de la respuesta de la frecuencia cardíaca, la escala de esfuerzo percibido (RPE) y el reconocimiento de cuándo detener una sesión.

- Aerobic Weekly Volume: Aim for 150 to 300 minutes of moderate-intensity aerobic activity each week, spread across multiple days. Volumen Aeróbico Semanal: Acumular de 150 a 300 minutos semanales de actividad aeróbica moderada.
- Absolute Blood Pressure Stop Limits: Stop exercise immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic. Límites Absolutos de Presión Arterial: Suspender el ejercicio de inmediato si la presión sistólica supera 220 mmHg o la diastólica supera 105 mmHg.
- Intensity Regulation via RPE: For clients taking medications that slow heart rate (like beta-blockers), use the Borg 6–20 RPE scale, aiming for an easy-to-moderate level of 11 to 13 ("light" to "somewhat hard"). Regulación de Intensidad por RPE: Para clientes con medicamentos que reducen la frecuencia cardíaca, usar la escala Borg de 6 a 20 (meta 11 a 13).
- Safety Auditor Delimiter Protocol: Always enclose client profile data within triple-hash delimiters (`### BEGIN CLINICAL CASE DATA ###`) when running AI simulations. Protocolo del Auditor de Seguridad: Envolver los datos del perfil del cliente entre delimitadores de tres numerales (`###`).

### Regional Focus: Exercising Safely in Yuma's Desert Climate

Enfoque Regional: Ejercicio Seguro en el Clima Desértico de Yuma

During the hot months in Yuma County, outdoor temperatures frequently climb above 105°F (40.5°C). For individuals managing heart conditions or high blood pressure, exercising in extreme heat places extra physical stress on the heart because the body must pump more blood to the skin for cooling. Exercise specialists at Matador Clinical Partners (MCP) recommend keeping workouts indoors in air-conditioned facilities (72°F / 22°C), staying well-hydrated, and monitoring exertion carefully using perceived effort rather than heart rate alone.

Durante los meses calurosos en el condado de Yuma, las temperaturas exteriores superan los 40.5°C. Para personas con afecciones cardíacas, el calor extremo impone un esfuerzo adicional al corazón. Los especialistas de Matador Clinical Partners (MCP) recomiendan hacer ejercicio en espacios climatizados (22°C) y mantenerse hidratados.


### Reading 1: Understanding Heart Rate Responses & Perceived Exertion

Lectura 1: Comprensión de las Respuestas de la Frecuencia Cardíaca y el Esfuerzo Percibido


#### Step 1: Why Heart Rate Targets Can Change

Por qué las metas de frecuencia cardíaca pueden cambiar

When a person takes common blood pressure medications known as beta-blockers, their heart beats slower both at rest and during exercise. Because standard heart rate formulas do not work for these individuals, fitness professionals rely on the Borg RPE scale. Asking a client how hard they feel they are working (on a scale from 6 to 20) provides a much safer and more accurate measure of exercise intensity.

Cuando una persona toma medicamentos para la presión conocidos como betabloqueadores, su corazón late más lento. Como las fórmulas estándar no funcionan, los profesionales usan la escala RPE de Borg para medir la intensidad del ejercicio de forma segura.


#### Step 2: Recognizing When to Stop

Reconociendo Cuándo Detenerse

Client safety is always the top priority. During any workout or fitness assessment, trainers must watch for warning signs such as chest discomfort, extreme shortness of breath, dizziness, or a sudden drop or sharp spike in blood pressure. If any of these red flags appear, stop the exercise session immediately and follow standard facility safety procedures.

La seguridad del cliente es la prioridad. Durante una sesión, los entrenadores deben vigilar señales de alerta como dolor en el pecho, falta extrema de aire, mareos o cambios bruscos en la presión arterial para detener el ejercicio de inmediato.


### Key Terminology / Glosario Clave

Medications prescribed for high blood pressure and heart conditions that lower heart rate and reduce the workload on the heart.

Medicamentos recetados para la presión arterial alta y afecciones cardíacas que disminuyen la frecuencia cardíaca y reducen el esfuerzo del corazón.

A numerical scale (typically Borg 6 to 20) that allows individuals to subjectively rate how hard they feel their body is working during physical activity.

Escala numérica (típicamente de 6 a 20 de Borg) que permite calificar subjetivamente qué tan duro se siente que trabaja el cuerpo durante la actividad.

A required course protocol where students enclose client case data within triple-hash delimiters (`###`) when interacting with AI tools.

Protocolo del curso en el que los estudiantes encierran los datos del caso clínico entre delimitadores de tres numerales (`###`) al usar herramientas de IA.


### AI Simulation Workspace & Safety Auditor Simulation

Copy the prompt below into Gemini to audit client cardiorespiratory profiles and design safe exercise programs:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy / Haga clic para copiar la plantilla)


```text
Safety Auditor Protocol: KIN-265 Module 08 Tool Box ###:
Role: Clinical Exercise Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chapter 7.

Instructions:
Step 1: Review the client profile enclosed within triple-hashes (###) below.
Step 2: PATTERN: Analyze their blood pressure, heart rate response, and medication considerations.
Step 3: RULE: Apply PAGA 2018 safety limits (stop exercise if SBP > 220 or DBP > 105) and Borg RPE intensity guidelines.
Step 4: SOLVE: Recommend a safe aerobic and strength routine suitable for a community college student to understand.
Step 5: Provide a short 2-sentence bilingual client instruction card in English and Spanish.

BEGIN CLINICAL CASE DATA ###:
Client Profile: [e.g., 58-year-old adult with controlled hypertension taking beta-blockers]
Resting Numbers: [e.g., Resting BP: 138/85 mmHg, Resting HR: 60 bpm]
Goal: [e.g., Build a safe walking and light strength routine]
END CLINICAL CASE DATA ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 08 (Mod 08 Required Readings: Fitness Testing, Vital Signs & Warning Signs)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. Digital OER text is fully accessible to screen readers without downloading external files.

Español: Todos los materiales de lectura de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla sin descargas de pago.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Clínicas Obligatorias: Monitoreo Cardiorrespiratorio y Seguridad

Monitoreo de la Frecuencia Cardíaca, Esfuerzo Percibido y Pautas de Seguridad

Todos los capítulos de lectura requeridos, las directrices federales de seguridad y los principios de monitoreo clínico están integrados directamente abajo. No se requiere comprar libros de texto externos.


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) (Capítulo 7: Adultos Activos con Afecciones Crónicas • Enfoque Cardiorrespiratorio).

Herramienta Interactiva PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev)

Documento sin conexión: exw265_ssot_special_populations_reference.docx

- Volumen Aeróbico Semanal: Acumular de 150 a 300 minutos semanales de actividad moderada.
- Límites de Paro por Presión Arterial: Suspender el ejercicio si la presión sistólica supera 220 mmHg o la diastólica supera 105 mmHg.
- Uso de la Escala RPE: Emplear la escala Borg 6–20 para medir la intensidad cuando los medicamentos alteran la frecuencia cardíaca.

### Enfoque Regional: Ejercicio Seguro en el Clima de Yuma

Durante los meses calurosos en Yuma, con temperaturas superiores a los 40.5°C, el calor extremo impone un esfuerzo adicional al corazón. Se recomienda realizar las rutinas en instalaciones climatizadas (22°C), hidratarse adecuadamente y guiar la intensidad por el esfuerzo percibido.


### Caja de Herramientas de IA • Protocolo de Auditoría Clínica

(Haga clic dentro del recuadro para copiar la plantilla de consulta para Gemini):


```text
Protocolo Safety Auditor: KIN-265 Módulo 08 Caja de Herramientas ###:
Rol: Especialista en Ejercicio Clínico.
SSoT: Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) - Capítulo 7.

Instrucciones:
Step 1: Revisar el perfil del cliente envuelto entre triples numerales (###).
Step 2: PATRÓN: Analizar su presión arterial, respuesta cardíaca y medicamentos.
Step 3: REGLA: Aplicar los límites de seguridad de PAGA 2018 y las directrices de intensidad Borg RPE.
Step 4: SOLUCIÓN: Recomendar una rutina segura y adecuada para un estudiante universitario.
Step 5: Proporcionar una tarjeta bilingüe de 2 oraciones en inglés y español.

BEGIN CLINICAL CASE DATA ###:
[PEGUE AQUÍ LOS DATOS DEL CASO ENTRE DELIMITADORES]
END CLINICAL CASE DATA ###:
End Safety Auditor Protocol ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 08 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 08:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 08)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 08)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
