## KIN-265: Mod 11 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 11) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 11 Discussion: Low-Impact Exercise for Obesity & Joint Comfort

Foro de Discusión del Módulo 11: Salud Metabólica y Seguridad Glucémica

- KIN-265.11.1.AY26-27: Analyze glycemic indicators, insulin sensitivity patterns, and contraindications associated with metabolic pathologies across diverse career tracks. Analizar indicadores glucémicos, patrones de sensibilidad a la insulina y contraindicaciones asociadas con patologías metabólicas en diversas rutas profesionales.
- KIN-265.11.2.AY26-27: Apply PAGA 2018 guidelines and formulate an evidence-based Frequency, Intensity, Time, Type (FITT) prescription incorporating blood glucose screening using secure AI verification protocols. Aplicar las pautas de PAGA 2018 y formular una prescripción FITT incorporando evaluación de glucosa utilizando protocolos seguros de verificación con IA.

### Your Weekly Win: Auditing Metabolic Risk & Prescriptive Safety

How can fitness professionals safely audit metabolic risk and design FITT exercise prescriptions for clients with diabetes mellitus or obesity? Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, exercise specialists identify glycemic bottlenecks, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) thresholds, and formulate safe metabolic conditioning programs. Choose one of the three career tracks below, chat with your AI Safety Auditor using mandatory triple-hash delimiters (`###`), and master metabolic safety auditing!

¿Cómo pueden los profesionales auditar el riesgo metabólico y diseñar prescripciones FITT para clientes con diabetes u obesidad? Utilizando el Protocolo de Encuadre Clínico, aplicamos las pautas de PAGA 2018 y diseñamos programas seguros. ¡Elija una ruta, dialogue con su auditor de seguridad y domine la auditoría metabólica!

- Topic Opens / Apertura: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient metabolic rehabilitation client with insulin-dependent Type 2 diabetes mellitus managing pre-exercise blood glucose screening and continuous glucose monitoring (CGM) trends.

Scenario: Senior community center participant with metabolic syndrome, prediabetes, and mild obesity; formulating a caloric expenditure walking program and lifestyle behavior plan.

Scenario: Law enforcement officer with early insulin resistance and shift-work sleep disorder; designing an adaptive high-intensity interval training (HIIT) and shift nutrition schedule.


### Phase 2: Gemini AI Safety Simulation Workspace

Paso 2: Copie la plantilla y consulte a su auditor de seguridad para evaluar su caso

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST)

- Pattern Recognition & Risk Stratification: State your chosen career track and client profile, identifying key metabolic risk factors, glycemic baselines, and endocrine contraindications. Indique su ruta profesional y perfil de cliente, señalando factores de riesgo metabólico y contraindicaciones endocrinas.
- Rule Application (PAGA 2018 FITT Prescription): Design a 3-phase FITT aerobic and resistance prescription adhering strictly to PAGA 2018 guidelines, blood glucose screening rules, and carbohydrate timing. Diseñe una prescripción FITT de 3 fases adhiriéndose estrictamente a las pautas de PAGA 2018 y protocolos de glucosa.
- Problem Solving & Safety Audit: Explain how you will monitor patient safety (e.g., pre/post blood glucose checks, hypoglycemia symptom recognition, desert hydration) during exercise sessions. Explique cómo monitoreará la seguridad del paciente (niveles de glucosa, síntomas de hipoglucemia) durante las sesiones.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track. Evaluate their metabolic risk stratifications and suggest one additional safety precaution or carbohydrate management check.


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 11 (Mod 11 Discussion: Low-Impact Exercise for Obesity & Joint Comfort)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Foro de Discusión del Módulo 11: Salud Metabólica y Seguridad Glucémica

Auditoría de Riesgo Metabólico y Prescripción Segura


### Su Logro Semanal: Auditando el Riesgo Metabólico y la Seguridad Prescriptiva

¡Bienvenidos a la discusión de la Semana 11! En este foro interactivo, examinará un caso clínico de diabetes o síndrome metabólico, aplicará el Protocolo de Encuadre Clínico y diseñará una prescripción FITT basada en PAGA 2018. ¡Elija una ruta, consulte a su auditor de seguridad y participe!

- Apertura del Foro: Martes a las 12:00 AM MST
- Publicación Inicial: Jueves a las 11:59 PM MST
- Respuestas a Compañeros: Domingo a las 11:59 PM MST
- Cierre del Foro: Lunes a las 11:59 PM MST

### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN caso)

Seleccione el caso para su análisis y participación en el foro:

Paciente con diabetes tipo 2 insulinodependiente. Glucemia en reposo 168 mg/dL. Meta: Establecer rutina glucémica segura con prevención de hipoglucemia.

Participante con síndrome metabólico y prediabetes. Glucemia en ayuno 118 mg/dL. Meta: Implementar caminata de gasto calórico y control de peso.

Oficial con resistencia temprana a la insulina y alteración por turnos de trabajo. Meta: Diseñar entrenamiento a intervalos adaptado al turno.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del caso (en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Tareas del Foro (Jueves 11:59 PM MST)

- Reconocimiento de Patrones y Estratificación: Indique su ruta y señale factores de riesgo metabólico y glucemia.
- Aplicación de Reglas (Prescripción FITT): Diseñe una prescripción FITT de 3 fases adhiriéndose a PAGA 2018 y protocolos de glucosa.
- Resolución y Seguridad: Explique cómo monitoreará la seguridad del paciente (niveles de glucosa, hipoglucemia) durante las sesiones.
KIN-265 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 11)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 11)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
