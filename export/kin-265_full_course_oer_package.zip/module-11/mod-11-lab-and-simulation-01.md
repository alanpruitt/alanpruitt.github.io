## KIN-265: Mod 11 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 11 Coaching Sprint Simulation: Safe Meal & Insulin Timing Around Workouts

Sesión de Coaching del Módulo 11: Salud Metabólica y Seguridad Glucémica

- Exogenous Insulin Peak & Exercise-Induced Hypoglycemia: Exercising during the peak action of rapid-acting insulin accelerates glucose clearance and suppresses hepatic glucose output; schedule workouts away from peak insulin or adjust carbohydrate intake per physician guidance. En palabras sencillas: Evitar hacer ejercicio justo en el pico máximo de acción de la insulina rápida para prevenir un bajón peligroso de azúcar (hipoglucemia).
- Pre-Exercise Blood Glucose Safety Gates (<100 mg/dL vs. >250 mg/dL): If glucose is <100 mg/dL, take 15–30 g fast-acting carbs first; if >250 mg/dL with ketones (or >300 mg/dL without ketones), postpone exercise and hydrate/seek medical care. En palabras sencillas: Si la glucosa está abajo de 100 mg/dL se toman 15–30 g de carbohidrato rápido antes de empezar; si pasa de 250 mg/dL con cetonas (o >300 mg/dL), se suspende el ejercicio.
- Joint Off-Loading & Peripheral Neuropathy Foot Inspection: In diabetes and obesity, use low-impact modalities (aquatic, recumbent bike) and inspect feet daily with proper footwear to prevent neuropathic ulcers. En palabras sencillas: Usar bicicleta reclinada o alberca para cuidar las articulaciones y revisar siempre los pies y el calzado cuando hay neuropatía diabética.
- KIN-265.11.1.AY26-27: Prescribe safe metabolic exercise intensity and blood glucose screening protocols for clients with diabetes mellitus or obesity across diverse career tracks. Prescribir intensidad de ejercicio metabólico segura y protocolos de evaluación de glucosa para clientes con diabetes u obesidad en diversas rutas profesionales.
- KIN-265.11.2.AY26-27: Audit clinical blood glucose stop limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de parada por glucosa en sangre y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering Blood Glucose Screening & Hypoglycemia Prevention

How can fitness professionals safely monitor exercise intensity when a client is managing diabetes mellitus or metabolic syndrome? Because standard metrics do not capture glycemic fluctuations, exercise specialists use pre-exercise blood glucose screening protocols. Following strict PAGA 2018 clinical guidelines, trainers monitor blood sugar stop limits (e.g., pre-exercise thresholds below 100 mg/dL requiring carbohydrate supplementation or above 250 mg/dL with ketones) and prevent acute hypoglycemia. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master metabolic safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente padece diabetes o síndrome metabólico? Usando la evaluación de glucosa en sangre y las pautas de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría metabólica!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient clinical rehabilitation client managing insulin-dependent Type 2 diabetes with pre-exercise blood glucose screening and continuous glucose monitoring (CGM).

Scenario: Senior community participant with metabolic syndrome, prediabetes, and mild obesity; formulating a caloric expenditure walking program and lifestyle behavior plan.

Scenario: Law enforcement officer with early insulin resistance and shift-work sleep disorder; designing an adaptive high-intensity interval training (HIIT) and shift nutrition schedule.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (David, Maria, or Officer Jackson).
- Metabolic Analysis: Explain the key glycemic regulation or insulin sensitivity consideration for your selected client.
- Part 3: Active Verification & Safety Audit: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your pre-exercise blood glucose screening thresholds and exercise intensity adjustments protect client safety, prevent acute hypoglycemia, and align with PAGA 2018 guidelines.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 11 Coaching Sprint • Track 1 (David)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • David (Age 58).
- Metabolic Analysis: David has insulin-dependent Type 2 diabetes mellitus. Because his blood glucose can fluctuate significantly during exercise, pre-exercise screening and continuous glucose monitoring (CGM) are essential to prevent acute hypoglycemia.
- Part 3: Active Verification & Safety Audit for David: "Check David's pre-exercise blood glucose; if readings are below 100 mg/dL, provide a fast-acting carbohydrate snack prior to exercise, and postpone activity if blood glucose exceeds 250 mg/dL with ketones per PAGA 2018 guidelines." Active Verification: In managing David's exercise prescription, relying solely on automated wearable metrics or general cardio guidelines is hazardous because insulin-dependent Type 2 diabetes creates unpredictable glycemic volatility. With his resting glucose at 168 mg/dL and concomitant peripheral neuropathy, our clinical priority must be proactive hypoglycemia avoidance combined with low-impact loading. Under PAGA 2018 standards, maintaining glucose between 100 and 250 mg/dL during exercise improves GLUT4 translocation and insulin sensitivity without risking sudden neuroglycopenic collapse. The mandatory pre-exercise check ensures we never initiate aerobic work during an unbuffered glycemic drop.
- "Check David's pre-exercise blood glucose; if readings are below 100 mg/dL, provide a fast-acting carbohydrate snack prior to exercise, and postpone activity if blood glucose exceeds 250 mg/dL with ketones per PAGA 2018 guidelines."
- Active Verification: In managing David's exercise prescription, relying solely on automated wearable metrics or general cardio guidelines is hazardous because insulin-dependent Type 2 diabetes creates unpredictable glycemic volatility. With his resting glucose at 168 mg/dL and concomitant peripheral neuropathy, our clinical priority must be proactive hypoglycemia avoidance combined with low-impact loading. Under PAGA 2018 standards, maintaining glucose between 100 and 250 mg/dL during exercise improves GLUT4 translocation and insulin sensitivity without risking sudden neuroglycopenic collapse. The mandatory pre-exercise check ensures we never initiate aerobic work during an unbuffered glycemic drop.
- Part 4: My Memorable Coaching Takeaway: EN: "Checking your blood sugar before you move ensures every workout safely builds better metabolic health!" "¡Revisar tu nivel de azúcar en sangre antes de moverte asegura que cada entrenamiento construya una mejor salud metabólica de manera segura!"
- EN: "Checking your blood sugar before you move ensures every workout safely builds better metabolic health!"
- "¡Revisar tu nivel de azúcar en sangre antes de moverte asegura que cada entrenamiento construya una mejor salud metabólica de manera segura!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M11_Quiz_Sprint.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 11 (Mod 11 Coaching Sprint: Safe Meal & Insulin Timing Around Workouts)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 11 Simulación de Coaching: Salud Metabólica y Seguridad Glucémica

Evaluación Rápida y Auditoría de Seguridad Metabólica


### Su Logro Semanal: Dominando la Glucemia y la Prevención de la Hipoglucemia

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para realizar evaluaciones de glucosa en sangre en pacientes con diabetes u obesidad. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente de rehabilitación clínica con diabetes tipo 2 insulinodependiente y monitoreo continuo de glucosa (CGM); establecer evaluación previa y prevención de hipoglucemia.

Escenario: Participante senior con síndrome metabólico, prediabetes y obesidad leve; formular un programa de caminata de gasto calórico y control de peso.

Escenario: Oficial de policía con resistencia temprana a la insulina y alteración del sueño por turnos; diseñar entrenamiento a intervalos adaptado al turno.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (David, Maria o Officer Jackson).
- Análisis Metabólico: Explique la consideración clave de regulación glucémica para su cliente.
- Parte 3: Verificación Activa y Auditoría de Seguridad: En una defensa de texto obligatoria (aprox. mínimo 150 palabras (150+ palabras)) escrita en su propia voz clínica, justifique por qué sus umbrales de glucosa previa y ajustes de ejercicio protegen la seguridad del cliente, previenen la hipoglucemia y cumplen con las pautas de PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 11, Sesión de Coaching • Ruta 1 (David)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • David (58 años).
- Análisis Metabólico: David tiene diabetes tipo 2 insulinodependiente. Como su glucosa en sangre puede fluctuar durante el ejercicio, la evaluación previa es fundamental para prevenir la hipoglucemia.
- Parte 3: Verificación Activa y Auditoría de Seguridad para David: "Revisar la glucosa en sangre de David antes del ejercicio; si está por debajo de 100 mg/dL, proporcionar un carbohidrato de acción rápida, y posponer la actividad si supera los 250 mg/dL con cetonas según PAGA 2018." Verificación Activa: En el manejo del ejercicio de David, confiar únicamente en métricas automatizadas o pautas generales de cardio es peligroso debido a la volatilidad glucémica de la diabetes tipo 2 insulinodependiente. Con una glucosa en reposo de 168 mg/dL y neuropatía periférica asociada, nuestra prioridad clínica es evitar la hipoglucemia aguda combinando ejercicio de bajo impacto. Conforme a las pautas de PAGA 2018, mantener la glucemia entre 100 y 250 mg/dL estimula la translocación de GLUT4 y mejora la sensibilidad a la insulina sin riesgo de colapso neuroglucopénico. La verificación previa obligatoria asegura que no iniciemos la actividad aeróbica durante una caída glucémica no compensada.
- "Revisar la glucosa en sangre de David antes del ejercicio; si está por debajo de 100 mg/dL, proporcionar un carbohidrato de acción rápida, y posponer la actividad si supera los 250 mg/dL con cetonas según PAGA 2018."
- Verificación Activa: En el manejo del ejercicio de David, confiar únicamente en métricas automatizadas o pautas generales de cardio es peligroso debido a la volatilidad glucémica de la diabetes tipo 2 insulinodependiente. Con una glucosa en reposo de 168 mg/dL y neuropatía periférica asociada, nuestra prioridad clínica es evitar la hipoglucemia aguda combinando ejercicio de bajo impacto. Conforme a las pautas de PAGA 2018, mantener la glucemia entre 100 y 250 mg/dL estimula la translocación de GLUT4 y mejora la sensibilidad a la insulina sin riesgo de colapso neuroglucopénico. La verificación previa obligatoria asegura que no iniciemos la actividad aeróbica durante una caída glucémica no compensada.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Checking your blood sugar before you move ensures every workout safely builds better metabolic health!" "¡Revisar tu nivel de azúcar en sangre antes de moverte asegura que cada entrenamiento construya una mejor salud metabólica de manera segura!"
- EN: "Checking your blood sugar before you move ensures every workout safely builds better metabolic health!"
- "¡Revisar tu nivel de azúcar en sangre antes de moverte asegura que cada entrenamiento construya una mejor salud metabólica de manera segura!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M11_Quiz_Sprint.pdf
KIN-265 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 11)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 11)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
