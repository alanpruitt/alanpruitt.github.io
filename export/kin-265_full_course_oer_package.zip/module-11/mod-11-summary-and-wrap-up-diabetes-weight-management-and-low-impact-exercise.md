## KIN-265: Mod 11 Summary And Wrap Up Diabetes Weight Management And Low Impact Exercise

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 11 Summary & Wrap-Up: Diabetes, Weight Management & Low-Impact Exercise


### Congratulations on Completing Module 11!

You have successfully navigated Module 11 and mastered the core principles of metabolic health, glycemic regulation, and exercise prescription for special populations with endocrine conditions. This week, you explored how Type 1 and Type 2 diabetes mellitus and metabolic syndrome affect insulin sensitivity, why fitness professionals rely on pre-exercise blood glucose screening, and how federal guidelines in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) establish safe glycemic threshold tracking.

By combining blood glucose monitoring, hypoglycemia prevention rules, and mandatory triple-hash delimiter protocols (`###`), you are fully prepared to design safe exercise programs for clients with metabolic considerations across clinical and community settings.


### Clinical Framing Protocol Synthesis: Module 11 Key Takeaways

- Pattern (Metabolic Pathophysiology & Insulin Resistance): Impaired glucose uptake and insulin resistance disrupt energy homeostasis, making pre-exercise blood glucose screening and continuous monitoring essential during physical exertion.
- Rule (PAGA 2018 Standards): Exercise intensity must be monitored alongside glycemic screening. Trainers must verify pre-exercise blood glucose levels (requiring carbohydrate supplementation if below 100 mg/dL or postponing exercise if above 250 mg/dL with ketones).
- Solve (Prescription Design): Build customized aerobic and resistance routines while accommodating environmental heat stress, utilizing indoor air-conditioned facilities (72°F / 22°C) and Safety Auditor prompt delimiters (`###`).

### Module 11 Knowledge Check (Self-Check Review)

Click on each question below to check your understanding of metabolic monitoring and safety principles:

English Response: Muscle contraction stimulates insulin-independent glucose uptake via AMPK signaling and GLUT4 transporter translocation.

Respuesta en Español: La contracción muscular estimula la captación de glucosa independiente de la insulina a través de la señalización AMPK y la translocación de transportadores GLUT4.

English Response: To detect potential hypoglycemia or hyperglycemia and ensure safe pre-exercise carbohydrate intake.

Respuesta en Español: Para detectar una posible hipoglucemia o hiperglucemia y garantizar una ingesta segura de carbohidratos antes del ejercicio.

English Response: Provide a fast-acting carbohydrate snack (15 grams) and re-test before commencing exercise.

Respuesta en Español: Proporcionar un bocadillo de carbohidratos de acción rápida (15 gramos) y volver a evaluar antes de comenzar el ejercicio.

English Response: When blood glucose exceeds 250 mg/dL and urinary or blood ketones are present.

Respuesta en Español: Cuando la glucosa en sangre supera los 250 mg/dL y hay presencia de cetonas en orina o sangre.

English Response: 150 to 300 minutes per week of moderate-intensity aerobic activity.

Respuesta en Español: De 150 a 300 minutos por semana de actividad aeróbica de intensidad moderada.

English Response: To prevent extreme heat stress and dehydration, which destabilize cardiovascular function and blood glucose regulation.

Respuesta en Español: Para prevenir el estrés por calor extremo y la deshidratación, que desestabilizan la función cardiovascular y la regulación de la glucosa.

English Response: To enclose metabolic client case data securely, preventing prompt drift and ensuring reliable AI tool performance.

Respuesta en Español: Encerrar de forma segura los datos del caso clínico metabólico, evitando la deriva de instrucciones y garantizando un rendimiento confiable de la IA.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición).

English Response: It increases muscle mass, which serves as a larger metabolic sink for glucose storage and improves long-term insulin sensitivity.

Respuesta en Español: Aumenta la masa muscular, sirviendo como un depósito metabólico más grande para el almacenamiento de glucosa y mejorando la sensibilidad a la insulina.


### Workplace Intelligence & AI Skills Competency Audit

In this Module, you demonstrated professional workforce readiness by leveraging Generative AI (Google Gemini) as a metabolic safety auditing partner. You practiced key workplace AI competencies:

You enclosed metabolic case data within triple-hash delimiters (`###`), maintaining structured data boundaries required in professional AI workflows.

You cross-examined AI recommendations against federal SSoT standards (PAGA 2018), auditing for safe blood glucose screening and hypoglycemia protocols.

You generated bilingual client instruction cards in English and Spanish to support diverse regional populations in Yuma County.

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 12 — Neurological & Neuromuscular Conditions (Stroke, Parkinson's, MS & SCI)

In plain English, next week in Module 12: Neurological & Neuromuscular Conditions you will learn how to program safe balance, gait, and strength training for clients living with stroke hemiparesis, Parkinson's disease, Multiple Sclerosis (MS), or Spinal Cord Injury (SCI). Why it matters: in Yuma's heat, even a small rise in core body temperature can temporarily block nerve signals and blur vision in clients with Multiple Sclerosis (Uhthoff's phenomenon)—active indoor cooling is mandatory.

- Pattern (Context): Recognizing Parkinson's gait freezing/bradykinesia, MS heat sensitivity (Uhthoff's phenomenon), post-stroke one-sided weakness, and SCI autonomic dysreflexia.
- Rule (Constraint): Enforcing precooling/indoor climate control ($<72^\circ\text{F}$) for MS, auditory/visual cueing during 'on-medication' windows for Parkinson's, and immediate medical stop-gates for autonomic dysreflexia (SCI at T6 or above).
- Solve (Intervention): Completing Mod 12 Discussion: Heat Sensitivity & Fall Safety and Mod 12 Lab: Neuromuscular Exercise Prescription .

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 11 (Mod 11 Summary & Wrap-Up: Diabetes, Weight Management & Low-Impact Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All wrap-up materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are fully mobile-responsive and screen-reader compatible.

Español: Todos los materiales de cierre en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 11 Resumen y Cierre del Módulo


### ¡Felicidades por completar el Módulo 11!

Ha completado con éxito el Módulo 11 y dominado los principios de salud metabólica, regulación glucémica y prescripción de ejercicio para afecciones endocrinas. Esta semana exploró cómo la diabetes y el síndrome metabólico afectan la sensibilidad a la insulina, por qué confiamos en la evaluación de glucosa previa al ejercicio y cómo las pautas federales en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) establecen el seguimiento glucémico.

Al combinar el monitoreo de glucosa, las reglas de prevención de hipoglucemia y los protocolos de delimitadores de tres numerales (`###`), usted está preparado para diseñar programas de ejercicio seguros en entornos clínicos y comunitarios.


### Síntesis del Protocolo de Encuadre Clínico: Puntos Clave del Módulo 11

- Patrón (Fisiopatología Metabólica): La resistencia a la insulina altera la captación de glucosa, haciendo vital el monitoreo glucémico antes del ejercicio.
- Regla (Normas PAGA 2018): Verificar la glucosa previa al ejercicio (suministrar carbohidratos si está por debajo de 100 mg/dL o posponer si supera 250 mg/dL con cetonas).
- Solución (Prescripción): Construir rutinas aeróbicas y de fuerza adaptadas al calor de Yuma, usando instalaciones climatizadas (22°C) y delimitadores (`###`).

#### Inteligencia en el Entorno Laboral y Competencia en IA

En este módulo demostró su preparación profesional al utilizar la IA generativa (Google Gemini) como socio en la auditoría de seguridad metabólica:

- Protocolo de Delimitadores: Encerró los datos del cliente entre tres numerales (`###`) para mantener la integridad de los datos.
- Verificación con IA: Verificó las recomendaciones de la IA frente a las normas federales PAGA 2018 y umbrales de glucosa.
- Comunicación Bilingüe: Generó tarjetas de instrucciones bilingües en inglés y español.
PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 12 — Condiciones Neurológicas y Neuromusculares

En palabras sencillas (Contexto Norteño): en pacientes con Esclerosis Múltiple, subir la temperatura del cuerpo en el calor de Yuma empeora temporalmente la vista y el equilibrio (fenómeno de Uhthoff); y en Parkinson, hay que entrenar cuando su medicamento (levodopa) está haciendo efecto máximo. Si los términos neurológicos se ponen pesados la próxima semana, concéntrate primero en el enfriamiento activo, las pistas visuales/auditivas para caminar y la prevención de caídas.

- Patrón (Contexto): Identificar sensibilidad al calor en Esclerosis Múltiple, bloqueos de marcha en Parkinson, hemiparesia post-EVC y disreflexia autonómica en lesión medular.
- Regla (Restricción): Garantizar ambiente fresco ($<72^\circ\text{F}$) en EM, entrenar en ventana 'ON' de medicación en Parkinson y aplicar seguridad anticaídas de PAGA 2018 .
- Solución (Intervención): Completar el Foro del Mód 12 (Heat Sensitivity & Fall Safety) y el Laboratorio del Mód 12 (Neuromuscular Exercise Prescription) .
KIN-265 • Module 11 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 11)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 11)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
