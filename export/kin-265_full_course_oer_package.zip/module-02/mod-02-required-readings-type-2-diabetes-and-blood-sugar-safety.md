## KIN-265: Mod 02 Required Readings Type 2 Diabetes And Blood Sugar Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 02 Required Readings: Type 2 Diabetes & Blood Sugar Safety

Lecturas Obligatorias y Recursos de Estudio: Diabetes Tipo 2 y Control Glucémico


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Exercise acts like natural insulin by helping working muscles absorb glucose (sugar) from the bloodstream even when insulin sensitivity is low. In Type 2 diabetes, checking blood glucose before and after training prevents hypoglycemia (dangerously low blood sugar below 70 mg/dL). Pairing daily aerobic and resistance movement with foot checks and desert hydration protects metabolic health.


#### En Palabras Sencillas (Norteño Context)

El ejercicio mueve el azúcar de la sangre hacia el músculo como abrir la compuerta de un canal de riego en el valle. Si los términos técnicos se ponen pesados, concéntrate primero en la ventana segura de glucosa en sangre antes de entrenar y cómo prevenir una bajada de azúcar (hipoglucemia).


### Required SSoT Text & Professional Guidelines

Primary Single Source of Truth (SSoT): ADA / ACSM Joint Position Statement: Exercise and Type 2 Diabetes (Kanaley et al., 2022). Declaración de Postura Conjunta de la ADA y el ACSM: Ejercicio y Diabetes Tipo 2.

- Tier 1 (Interactive Clinical Journal Article): ACSM & ADA Exercise and Type 2 Diabetes Position Statement (MSSE)
- Tier 2 (PAGA 2018 Chapter 6 - Chronic Health Conditions): PAGA 2018 2nd Edition Official Chapters & Manual ("PAGA" in Course Navigation Bar • paga2018.dev/chapters)
- Tier 3 (Clinical Reference Portal): DOI: 10.1249/MSS.0000000000002800 (PubMed PMID: 35044352)

### Core Scientific Concepts / Conceptos Clave


#### Step 1: Pre-Exercise Glycemic Decision Matrix & Ketone Gating / Matriz Glucémica

Skeletal muscle contraction stimulates non-insulin-mediated GLUT4 glucose transporter translocation to cell membranes. Pre-exercise capillary blood glucose dictates immediate clinical safety protocols:

- <100 mg/dL (<5.6 mmol/L) [Hypoglycemia Action Gate]: Ingest 15 to 30g of fast-acting carbohydrates (e.g., glucose tablets, 4 oz juice). Re-test in 15 minutes (Rule of 15). Delay exercise until blood glucose is safely >100 mg/dL.
- 100 to 250 mg/dL (5.6 to 13.9 mmol/L) [Therapeutic Green Zone]: Safe glycemic window. Initiate aerobic and resistance exercise as planned.
- >250 mg/dL (>13.9 mmol/L) [Hyperglycemia & Ketone Gating]: Test urine/blood for ketones. If ketones are present, POSTPONE exercise immediately due to Diabetic Ketoacidosis (DKA) risk. If ketones are negative and the client is asymptomatic, exercise with caution.
La contracción muscular activa los transportadores GLUT4 sin necesidad de insulina. Si la glucosa es <100 mg/dL, aplicar la Regla del 15. Si es >250 mg/dL con cetonas, POSPONER el ejercicio de inmediato .


#### Step 2: Diabetic Peripheral Neuropathy (DPN) & Foot Safety / Neuropatía Periférica

DPN causes a progressive loss of protective sensation in the lower extremities. High-impact treadmill running or outdoor jogging causes unperceived mechanical shear stress and friction blisters that rapidly progress to non-healing ulcers. Exercise specialists must substitute high-impact activities with non-weight-bearing modalities (recumbent cycling, water aerobics, or arm ergometry) and enforce pre- and post-exercise visual foot inspections using a hand mirror (specifically examining plantar surfaces and interdigital spaces between toes).

La neuropatía provoca pérdida de sensibilidad protectora. El trote genera fricción que causa úlceras silenciosas. Se deben prescribir actividades sin impacto (bici reclinada, natación) e inspecciones diarias de pies con espejo.


#### Step 3: Gellish Heart Rate Reserve (HRR) Math / Fórmula de Gellish y Zonas de FC

The traditional "220 − Age" formula significantly overestimates Max HR in older adults and underestimates it in young populations. In clinical exercise science, we use the Gellish formula: Max HR = 207 − (0.7 × Age) . Target aerobic intensity (40% to 59% HRR for moderate intensity) is calculated via the Karvonen method: Target HR = [(Max HR − Resting HR) × %Intensity] + Resting HR .

La fórmula de Gellish [207 − (0.7 × Edad)] ofrece mayor precisión clínica para la FC Máxima. La intensidad moderada (40%–59% HRR) se calcula con el método de Karvonen sumando la FC en reposo.


### Key Terminology / Glosario Clave

- Diabetic Peripheral Neuropathy (DPN) / Neuropatía Periférica Diabética: Microvascular nerve damage causing sensory loss in the feet, necessitating non-weight-bearing exercise modalities, seamless moisture-wicking socks, and daily visual hand-mirror foot inspections. Daño microvascular que elimina la sensibilidad en los pies; requiere ejercicio sin impacto, calcetines sin costuras e inspección diaria con espejo.
- Diabetic Ketoacidosis (DKA) Gating / Riesgo de Cetoacidosis Diabética: An acute metabolic crisis triggered by exercising in the presence of severe insulin deficiency (>250 mg/dL with ketones); mandates immediate exercise postponement. Crisis metabólica desencadenada por hacer ejercicio con déficit severo de insulina (>250 mg/dL con cetonas); exige posponer el ejercicio de inmediato.
- GLUT4 Translocation / Translocación de GLUT4: The non-insulin-mediated movement of glucose transporter-4 proteins to skeletal muscle cell membranes stimulated directly by muscular contraction during physical activity. Movimiento de proteínas transportadoras de glucosa hacia la membrana del músculo activado directamente por la contracción física sin requerir insulina.

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 02 (Mod 02 Required Readings: Type 2 Diabetes & Blood Sugar Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All course readings and study materials in KIN-265 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers and AI note-taking tools.

Español: Todas las lecturas del curso en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total accesibilidad para lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Study materials and clinical reference guides remain permanently accessible to support self-paced learning, evidence-based prompt engineering, and clinical auditing without testing friction.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Obligatorias y Recursos de Estudio

Diabetes Tipo 2, Puertas Glucémicas y Adaptación Clínica


### Texto Oficial SSoT y Pautas Profesionales

Fuente Única de la Verdad (SSoT): Declaración de Postura Conjunta de ADA / ACSM: Ejercicio y Diabetes Tipo 2 (Kanaley et al., 2022).

- Nivel 1 (Artículo Oficial de Revista MSSE): Postura Conjunta ACSM & ADA: Ejercicio y Diabetes Tipo 2 (MSSE)
- Nivel 2 (Guías Federales PAGA 2018 - Capítulo 6): Manual Oficial y Capítulos PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev/chapters)
- Nivel 3 (Enlace DOI y PubMed): DOI: 10.1249/MSS.0000000000002800 (PubMed PMID: 35044352)

### Conceptos Científicos Clave


#### Step 1: Matriz de Decisión Glucémica y Control de Cetonas

La contracción del músculo esquelético estimula la translocación de GLUT4 sin requerir insulina. La glucemia capilar antes del ejercicio dicta las pautas de seguridad:

- <100 mg/dL [Puerta de Hipoglucemia]: Ingerir 15 a 30 g de carbohidratos rápidos. Reevaluar en 15 minutos (Regla del 15). Posponer el ejercicio hasta que la glucosa esté >100 mg/dL.
- 100 a 250 mg/dL [Zona Terapéutica Segura]: Rango seguro. Iniciar el entrenamiento aeróbico y de fuerza.
- >250 mg/dL [Puerta de Hiperglucemia y Cetonas]: Evaluar cetonas. Si están presentes, POSPONER el ejercicio de inmediato por riesgo de cetoacidosis diabética (CAD).

#### Step 2: Neuropatía Periférica Diabética y Protección de Pies

La neuropatía causa pérdida de sensibilidad protectora. El trote genera fuerzas de cizallamiento que provocan ampollas no percibidas y úlceras graves. Se deben prescribir modalidades sin impacto (bicicleta reclinada, aeróbicos acuáticos) e inspecciones visuales diarias con espejo de mano (revisando plantas y espacios entre los dedos).


#### Step 3: Fórmula de Gellish y Zonas de Reserva de FC (HRR)

La fórmula de Gellish [FC Máx = 207 − (0.7 × Edad)] ofrece precisión superior para poblaciones especiales. La intensidad moderada (40% a 59% HRR) se calcula con Karvonen: FC Meta = [(FC Máx − FC Reposo) × %Intensidad] + FC Reposo .


### Glosario Clave

- Neuropatía Periférica Diabética (NPD): Daño nervioso microvascular que elimina la sensibilidad en los pies; exige ejercicio sin carga de peso, calcetines sin costuras e inspección visual diaria con espejo.
- Cetoacidosis Diabética (CAD): Crisis metabólica aguda provocada por entrenar con déficit severo de insulina (>250 mg/dL con cetonas); exige posponer el ejercicio de inmediato.
- Translocación de GLUT4: Movimiento de transportadores de glucosa hacia la membrana celular activado directamente por la contracción muscular sin depender de la insulina.

### ACCESIBILIDAD Y UDL

Todos los materiales de lectura en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total compatibilidad con lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

KIN-265 • Module 02 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 02:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 02)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
