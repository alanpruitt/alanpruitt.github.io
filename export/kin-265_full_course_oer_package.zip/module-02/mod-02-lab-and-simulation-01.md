## KIN-265: Mod 02 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 02) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Lab & Simulation: Type 2 Diabetes Exercise & Foot-Safety Audit

Laboratorio del Módulo 02: Programación de Ejercicio para Diabetes Tipo 2 y Resistencia a la Insulina

- Insulin-Independent GLUT4 Glucose Uptake: Contracting skeletal muscle translocates GLUT4 transporters to the cell membrane without needing insulin, lowering blood glucose for 24–48 hours post-exercise. En palabras sencillas: Al moverse, el músculo absorbe azúcar de la sangre por sí mismo durante 24 a 48 horas, ayudando a controlar la diabetes tipo 2.
- 48-Hour Maximum Inter-Session Gap (Type 2 Diabetes Rule): Because exercise-induced insulin sensitivity fades within 48 hours, clients with diabetes should never go more than 2 consecutive days without aerobic activity. En palabras sencillas: Como el efecto del ejercicio sobre la glucosa dura unas 48 horas, nunca debemos dejar pasar más de 2 días seguidos sin actividad aeróbica.
- Pre-Exercise Hypoglycemia Safety Gate (<100 mg/dL): If pre-exercise blood glucose is <100 mg/dL (especially on insulin or sulfonylureas), ingest 15–30 g fast-acting carbohydrates and recheck in 15 minutes before starting. En palabras sencillas: Si el azúcar antes de entrenar está abajo de 100 mg/dL, el paciente debe tomar 15–30 g de carbohidrato rápido y volver a medir a los 15 minutos.
Welcome to your second practical laboratory assignment in Special Populations! This week, we analyze exercise prescription parameters for individuals with metabolic dysfunction. You will design a specialized, clinically safe conditioning program for a client with Type 2 Diabetes Mellitus (T2DM) presenting with metabolic complications, utilizing our primary academic Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, Chapter 6) and the ADA/ACSM Joint Position Statement on Exercise and Type 2 Diabetes .

Bienvenido a su segunda práctica de laboratorio de Ejercicio para Poblaciones Especiales. Esta semana analizaremos los parámetros de prescripción de ejercicio para personas con disfunción metabólica y diabetes tipo 2 utilizando las pautas de PAGA 2018 y estándares clínicos de seguridad glucémica de la ADA/ACSM.

- KIN-265.2.3.AY26-27: Formulate physical activity protocols to enhance insulin sensitivity and GLUT4 translocation while mitigating neuropathic foot trauma. Formular protocolos de actividad física para mejorar la sensibilidad a la insulina y la translocación de GLUT4 evitando el trauma neuropático en el pie.
- KIN-265.2.4.AY26-27: Audit clinical hypoglycemia thresholds (glucose <100 mg/dL), ketone gating rules, and pre-exercise carbohydrate strategies under high-heat conditions. Auditar umbrales clínicos de hipoglucemia (glucosa <100 mg/dL), reglas de cetonas y carbohidratos previos en calor extremo.
- Module Window / Ventana del Módulo: Opens Tuesday at 12:00 AM MST / Abre el martes a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday by 11:59 PM MST / Lunes a las 11:59 PM MST
- Submission Format / Formato: Text-only entry typed or pasted directly into the Canvas text box. (No file uploads accepted). / Texto directo en Canvas (No se aceptan archivos adjuntos).

### Lab Objectives / Objetivos del Laboratorio

- Identify critical pre-exercise blood glucose gating thresholds and emergency interventions to prevent exercise-induced hypoglycemia or severe hyperglycemia. Identificar los umbrales críticos de glucosa en sangre previos al ejercicio e intervenciones de emergencia.
- Formulate non-weight-bearing or low-shear alternative activities to bypass mechanical foot injuries or vascular strain in patients presenting with diabetic complications. Formular actividades sin soporte de peso corporal o de bajo cizallamiento para evitar lesiones mecánicas en los pies.
- Calculate target exercise intensity ranges utilizing the Gellish Heart Rate Reserve (HRR) formula for an insulin-resistant client. Calcular los rangos de intensidad de ejercicio objetivo utilizando la fórmula de Gellish y Reserva de Frecuencia Cardíaca (HRR).
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-02

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos Clínicos

Choose ONE of the three career-aligned clinical tracks below before invoking Google Gemini:

Focus: Obese, insulin-dependent T2DM patient (T.M., 49) presenting with advanced diabetic peripheral neuropathy, bilateral mid-calf sensory loss, and prior calcaneus ulcer history.

Focus: Agricultural community worker with T2DM (S.R., 54) managing heat exposure, oral hypoglycemic medication timing, and foot ulcer prevention.

Focus: Masters recreational athlete with T2DM (E.V., 51) optimizing glucose disposal and muscle insulin sensitivity through structured resistance and ergometer training.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI along with your chosen track data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas (Solo Texto Plano)

- Selected Track & Client Baseline: Declare chosen track and baseline clinical profile. Indique la ruta seleccionada y el perfil clínico del cliente.
- Part 1: Pattern Recognition (BMI & Biomechanical Risk): Calculate BMI, classify weight category, and explain the mechanical shear risks of high-impact exercise with peripheral neuropathy or ulcer history. Parte 1: Reconocimiento de Patrones (Calcule el IMC, clasifique el peso y explique los riesgos de impacto ante neuropatía).
- Part 2: Rule Application & Clinical Calculations: Detail pre-exercise blood glucose gating rules (<100, 100–250, >250 mg/dL with ketones) and calculate 40% to 59% HRR range using the Gellish formula. Parte 2: Aplicación de Reglas y Cálculos Clínicos (Compuertas de glucosa y rango de 40% a 59% HRR con Gellish).
- Part 3: Solving the Gap & Bilingual Client Card: Prescribe a 4-week FITT-VP plan (non-weight-bearing modalities, weekly progression, and diabetic foot care protocols) with a 2-sentence bilingual client card in English and Spanish. Parte 3: Resolución Práctica y Tarjeta Bilingüe (Plan FITT-VP de 4 semanas sin impacto y tarjeta bilingüe de 2 oraciones).
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why your non-weight-bearing modality selection, Gellish 40–59% HRR intensity zone, and strict 48-hour gap rule protect this Type 2 Diabetes client from plantar ulceration and glycemic volatility in Yuma. Parte 4: Verificación Activa Obligatoria (mínimo 150 palabras en su propia voz humana justificando la modalidad sin impacto, el rango 40–59% HRR y la regla de no pasar más de 48 horas sin ejercicio).
- Repository Verification: Confirm that your complete AI prompt exchange has been saved to your Google Drive repository ( EXW_Professional_AI_Repository ). Confirmación del Repositorio: Verifique que el registro de IA esté guardado en su carpeta de Google Drive.

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Part 1: Pattern Recognition (Detección de Patrones): Key Point — Biometric Conversions: Weight = 265 lbs / 2.2 = Outcome 120.5: kg . Height = 69 in × 0.0254 = Outcome 1.75: meters . Key Point — BMI Equation: 120.5 / (1.75 × 1.75) = 120.5 / 3.0625 = Outcome 39.35: kg/m² (Class II Obesity) . Key Point — Neuropathic Contraindications: Complete sensory numbness below mid-calf with prior calcaneus ulcer history strictly contraindicates high-impact weight-bearing exercise (treadmill walking/running). Repetitive vertical impact and friction cause undetected skin shear and blisters that rapidly progress to non-healing plantar ulcers or osteomyelitis.

Part 2: Rule Application & Target Calculations (ADA/ACSM & Gellish): Key Point — Pre-Exercise Blood Glucose Gates: Key Point: <100 mg/dL: Ingest 15–30g fast-acting carbs; retest in 15 min; delay exercise until glucose >100 mg/dL. Key Point: 100 to 250 mg/dL: Safe therapeutic zone; proceed with conditioning. Key Point: >250 mg/dL: Test urine ketones. If ketones are present, cancel exercise immediately; if negative, exercise with caution. Key Point — Gellish Max HR (Age 49): 207 − (0.7 × 49) = 207 − 34.3 = Outcome 172.7: bpm (~173 bpm) . Key Point — Heart Rate Reserve (HRR): 173 − 78 (Resting HR) = 95 bpm . Key Point — Target Intensity Range (40% to 59% HRR): (95 × 0.40) + 78 = 116 bpm to (95 × 0.59) + 78 = 134 bpm. Target Zone: 116 to 134 bpm .

Part 3: Solving the Gap (Resolución de Intervención): Key Point — Modalities: Recumbent stationary cycling and seated upper-body arm ergometry to eliminate plantar foot shear forces. Key Point — FITT-VP: 3 non-consecutive days/week at 116 to 134 bpm (RPE 11–13). Begin at 20 mins/session, progressing by 5 mins weekly up to 40 mins. Key Point — Foot Care Protocols: Inspect feet before and after every workout with a hand mirror (specifically examining plantar surfaces and interdigital spaces); wear seamless synthetic socks and professionally fitted wide-toe-box orthotic athletic shoes.

EN: "Check your blood sugar before exercising; if it is under 100, eat a 15-gram carb snack first. Ride a recumbent bike at a moderate pace and check your feet with a mirror after every workout to prevent blisters."

ES: "Revise su glucosa antes de ejercitarse; si está por debajo de 100, consuma 15 gramos de carbohidratos primero. Use una bicicleta reclinada a paso moderado y revise sus pies con un espejo tras cada sesión para evitar ampollas."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M02_Diabetes_Prescription_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 02 (Mod 02 Lab: Type 2 Diabetes Exercise & Foot-Safety Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 follow Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This assignment is text-first, untimed, and screen-reader verified.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 02 Laboratorio y Simulación: Diabetes Tipo 2 y Auditoría Glucémica

Programación de Ejercicio, Control Glucémico y Prevención Neuropática


### Prescripción de Ejercicio en Diabetes Tipo 2 y Resistencia a la Insulina

En este laboratorio, diseñará una prescripción clínica de acondicionamiento para un cliente con diabetes tipo 2 utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , aplicando las compuertas de seguridad glucémica y seleccionando modalidades sin carga de peso.


### Fase 1: Selección de Escenario de Simulación Clínica #265-02

Elija UNA de las tres rutas profesionales para realizar su auditoría:

Paciente con Diabetes Tipo 2 insulino-dependiente (T.M., 49 años) con neuropatía periférica avanzada y antecedente de úlcera calcánea.

Trabajadora agrícola con Diabetes Tipo 2 (S.R., 54 años) bajo calor extremo (42°C / 108°F) tomando sulfonilurea (Glipizida).

Atleta recreativo master con Diabetes Tipo 2 (E.V., 51 años) optimizando la captación de glucosa con entrenamiento aeróbico y fuerza.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


### Fase 3: Estructura de Entrega en Canvas (Solo Texto Plano)

- Ruta y Cliente: Indique la ruta seleccionada y el perfil clínico del cliente.
- Parte 1 (Reconocimiento de Patrones): Calcule el IMC, clasifique el peso y explique los riesgos de impacto ante neuropatía.
- Parte 2 (Reglas y Cálculos): Detalle las compuertas de glucosa y calcule el rango de 40% a 59% HRR con Gellish.
- Parte 3 (Solución y Tarjeta Bilingüe): Prescriba un plan FITT-VP de 4 semanas sin impacto y redacte la tarjeta bilingüe de 2 oraciones.
- Parte 4 (Verificación Activa Obligatoria): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué la modalidad sin impacto, la zona de 40–59% HRR con Gellish y la regla de máximo 48 horas protegen al paciente diabético en Yuma.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Evaluación en Español (Escala 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10 en Español

Parte 1: Reconocimiento de Patrones: Peso = 120.5 kg, Altura = 1.75 m. IMC = 39.35 kg/m² (Obesidad Clase II). La neuropatía periférica con pérdida sensorial distal bajo la pantorrilla y antecedente de úlcera calcánea contraindica estrictamente ejercicios con impacto vertical (caminata/trote en banda) por riesgo de fuerzas de cizallamiento y ampollas no percibidas que progresen a úlceras u osteomielitis.

Parte 2: Aplicación de Reglas y Cálculos Clínicos: Key Point — Compuertas Glucémicas ADA/ACSM: Key Point: <100 mg/dL: Ingerir 15 a 30 g de carbohidratos rápidos; reevaluar en 15 min; posponer ejercicio hasta glucosa >100 mg/dL. Key Point: 100 a 250 mg/dL: Zona segura; proceder con el entrenamiento. Key Point: >250 mg/dL: Medir cetonas. Si están presentes, cancelar de inmediato; si es negativo, ejercitar con precaución. Key Point — FC Máxima (Gellish, Edad 49): 207 − (0.7 × 49) = 172.7 lpm (~173 lpm). Key Point — Reserva de FC (HRR): 173 − 78 (FC Reposo) = 95 lpm . Key Point — Rango Moderado (40% a 59% HRR): (95 × 0.40) + 78 = 116 lpm a (95 × 0.59) + 78 = 134 lpm. Rango Meta: 116 a 134 lpm .

Parte 3: Resolución de la Brecha: Key Point — Modalidades: Bicicleta estacionaria reclinada y ergómetro de brazos en posición sentada para eliminar el cizallamiento en los pies. Key Point — FITT-VP: 3 días no consecutivos/semana a 116–134 lpm (RPE 11–13). Iniciar con 20 min/sesión, progresando 5 min por semana hasta alcanzar 40 min. Key Point — Cuidado del Pie: Inspección visual con espejo antes y después de cada sesión (plantas y entre los dedos); uso de calcetines sintéticos sin costuras y calzado ortopédico con horma ancha. Tarjeta Bilingüe: "Revise su glucosa antes de ejercitarse; si está por debajo de 100, consuma 15 gramos de carbohidratos primero. Use una bicicleta reclinada a paso moderado y revise sus pies con un espejo tras cada sesión para evitar ampollas."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M02_Diabetes_Prescription_Audit.pdf


### ACCESIBILIDAD Y UDL

Todos los materiales de laboratorio en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total accesibilidad para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi criterio clínico, prescribir caminata en banda a un paciente con obesidad y neuropatía periférica representa un peligro biomecánico: el peso corporal multiplica las fuerzas de reacción del suelo mientras la pérdida de sensibilidad oculta microtraumas hasta formar una úlcera plantar. Al descartar las recomendaciones genéricas de caminata de la IA y prescribir bicicleta reclinada sin impacto a 40–59% HRR (fórmula de Gellish), activamos los transportadores GLUT4 para reducir la glucosa sin fricción en los pies. Cumplir la regla de no dejar pasar más de 48 horas entre sesiones mantiene la sensibilidad a la insulina con total seguridad."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 02)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
