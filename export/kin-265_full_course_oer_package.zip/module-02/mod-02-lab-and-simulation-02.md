## KIN-265: Mod 02 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 02) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Coaching Sprint Simulation: Preventing Low Blood Sugar During Workouts

Sesión de Coaching del Módulo 02: Programación de Ejercicio para Diabetes Tipo 2

- Insulin-Independent GLUT4 Glucose Uptake: Contracting skeletal muscle translocates GLUT4 transporters to the cell membrane without needing insulin, lowering blood glucose for 24–48 hours post-exercise. En palabras sencillas: Al moverse, el músculo absorbe azúcar de la sangre por sí mismo durante 24 a 48 horas, ayudando a controlar la diabetes tipo 2.
- 48-Hour Maximum Inter-Session Gap (Type 2 Diabetes Rule): Because exercise-induced insulin sensitivity fades within 48 hours, clients with diabetes should never go more than 2 consecutive days without aerobic activity. En palabras sencillas: Como el efecto del ejercicio sobre la glucosa dura unas 48 horas, nunca debemos dejar pasar más de 2 días seguidos sin actividad aeróbica.
- Pre-Exercise Hypoglycemia Safety Gate (<100 mg/dL): If pre-exercise blood glucose is <100 mg/dL (especially on insulin or sulfonylureas), ingest 15–30 g fast-acting carbohydrates and recheck in 15 minutes before starting. En palabras sencillas: Si el azúcar antes de entrenar está abajo de 100 mg/dL, el paciente debe tomar 15–30 g de carbohidrato rápido y volver a medir a los 15 minutos.
- KIN-265.2.1.AY26-27: Apply PAGA 2018 clinical guidelines to design safe, individualized exercise prescriptions for individuals managing Type 2 Diabetes. Aplicar las pautas clínicas de PAGA 2018 para diseñar prescripciones de ejercicio seguras para personas con diabetes tipo 2.
- KIN-265.2.2.AY26-27: Audit clinical safety parameters, blood glucose management, and hypoglycemia prevention protocols during physical activity. Auditar parámetros de seguridad clínica, control de glucosa y protocolos de prevención de hipoglucemia.

### Your Weekly Win: Exercise as Metabolic Medicine

How does structured physical activity act as powerful medicine for managing blood glucose and improving insulin sensitivity? For individuals with Type 2 Diabetes, muscle contraction enhances glucose uptake independently of insulin through GLUT4 translocation. Following strict PAGA 2018 clinical guidelines, exercise specialists can design safe aerobic and resistance programs that mitigate chronic disease risk. Choose your coaching track below, chat with your AI Clinical Preceptor, and master clinical safety auditing!

¿Cómo actúa el ejercicio como medicina para la glucosa? La contracción muscular mejora la captación de glucosa vía GLUT4 sin depender de la insulina. Siguiendo PAGA 2018, diseñe programas seguros. ¡Elija su ruta y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Selección de Escenario de Simulación Clínica

Scenario: Outpatient clinic patient (Rosa, 58) with uncontrolled Type 2 Diabetes and peripheral neuropathy who wants to start exercising safely.

Scenario: Community wellness center participant (George, 65) taking insulin who experiences unexpected dizzy spells during afternoon group exercise classes.

Scenario: Newly diagnosed gym member (David, 40) wanting to use resistance training to improve HbA1c levels without knowing baseline safety rules.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client / Ruta y Cliente Seleccionado: State your selected track and client's clinical profile or safety risk. Indique la ruta y el perfil clínico o riesgo de seguridad de su cliente.
- Clinical Safety & Programming Analysis / Análisis Clínico: Explain PAGA 2018 guidelines and metabolic management strategies for your client. Explique las directrices de PAGA 2018 y las estrategias de manejo metabólico para su cliente.
- My Clinical Safety Audit / Mi Auditoría de Seguridad Clínica: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment. Escriba 1 parámetro de seguridad claro o ajuste de prescripción basado en evidencia.
- Part 3: Active Verification & Safety Audit (150-Word Minimum in Your Own Human Voice): Provide 1 clear evidence-based safety parameter and a 150-word minimum Active Verification (Part 3) in your own voice justifying your blood glucose gating (100–250 mg/dL) and neuropathy foot-care protections. Parte 3: Verificación Activa (mínimo 150 palabras en su propia voz humana justificando la compuerta de glucosa de 100–250 mg/dL y el cuidado de los pies ante neuropatía).
- My Memorable Coaching Takeaway / Mi Frase Inolvidable de Coaching: Write your favorite memorable takeaway sentence in English and Spanish. Escriba su aprendizaje clave en inglés y español.
- Repository Verification / Verificación del Repositorio: Confirm export to EXW_Professional_AI_Repository . Confirme el guardado en su carpeta de Google Drive.

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 02 Coaching Sprint • Track 1 (Clinical / Rosa)

- Chosen Track & Client: Track 1: Clinical & Hospital Outpatient Path (Rosa, 58). Challenge: Rosa manages Type 2 Diabetes with early peripheral neuropathy and wants to start walking safely without risking foot trauma or glycemic instability.
- Track 1: Clinical & Hospital Outpatient Path (Rosa, 58).
- Challenge: Rosa manages Type 2 Diabetes with early peripheral neuropathy and wants to start walking safely without risking foot trauma or glycemic instability.
- Clinical Safety & Programming Analysis: PAGA 2018 Guidelines for Neuropathy: Peripheral neuropathy impairs protective sensation in the feet. High-impact weight-bearing exercise can cause undetected blisters and ulcers. Clinical protocols mandate non-weight-bearing or low-impact modalities (such as stationary cycling or swimming) alongside rigorous daily foot inspections. Blood glucose must be monitored before and after exercise, avoiding sessions if fasting glucose exceeds clinical safety thresholds without clearance.
- PAGA 2018 Guidelines for Neuropathy: Peripheral neuropathy impairs protective sensation in the feet. High-impact weight-bearing exercise can cause undetected blisters and ulcers. Clinical protocols mandate non-weight-bearing or low-impact modalities (such as stationary cycling or swimming) alongside rigorous daily foot inspections.
- Blood glucose must be monitored before and after exercise, avoiding sessions if fasting glucose exceeds clinical safety thresholds without clearance.
- My Clinical Safety Audit for Rosa: "Transition Rosa from high-impact walking to a recumbent stationary bike program, mandate seamless moisture-wicking socks, and establish pre- and post-exercise foot inspection protocols per PAGA 2018 standards."
- "Transition Rosa from high-impact walking to a recumbent stationary bike program, mandate seamless moisture-wicking socks, and establish pre- and post-exercise foot inspection protocols per PAGA 2018 standards."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical reasoning, Rosa's combination of Type 2 Diabetes and early peripheral neuropathy requires two non-negotiable safety gates that generic AI fitness apps routinely overlook. First, because peripheral neuropathy blunts protective pain sensation in her soles, high-impact outdoor walking on hot Yuma pavement can cause undetected blisters that progress to diabetic foot ulcers; transitioning her to low-impact recumbent cycling and requiring pre- and post-workout visual foot checks eliminates repetitive plantar shear. Second, enforcing the clinical blood glucose gate (administering 15 g of fast-acting carbohydrate if pre-exercise glucose is below 100 mg/dL and postponing exercise if above 250 mg/dL with ketones) allows skeletal muscle GLUT4 translocation to lower her blood sugar safely without risking acute hypoglycemia."
- My Memorable Coaching Takeaway: EN: "For clients with neuropathy, protecting the foundation is the first rule of clinical exercise prescription!" ES: "¡Para clientes con neuropatía, proteger la base es la primera regla de la prescripción de ejercicio clínico!"
- EN: "For clients with neuropathy, protecting the foundation is the first rule of clinical exercise prescription!"
- ES: "¡Para clientes con neuropatía, proteger la base es la primera regla de la prescripción de ejercicio clínico!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M02_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 02 (Mod 02 Coaching Sprint: Preventing Low Blood Sugar During Workouts)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Coaching Sprint prompts and learning activities in KIN-265 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools.

Español: Todas las actividades de Coaching Sprint en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Coaching Sprints are untimed reflections evaluated on a 3-tier scale (10/7/0 pts) to build confidence, clinical safety reasoning, and bilingual communication skills.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 02 Simulación de Coaching: Programación para Diabetes Tipo 2

Evaluación Rápida y Auditoría de Seguridad Clínica


### Su Logro Semanal: El Ejercicio como Medicina Metabólica

Esta sesión le permitirá aplicar las directrices clínicas de PAGA 2018 para diseñar programas seguros para personas con diabetes tipo 2. Aprenda a auditar parámetros de seguridad y control glucémico. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Elija UNA de las tres rutas profesionales para su consulta con el Coach de IA:

Paciente con Diabetes Tipo 2 y neuropatía temprana (Rosa, 58 años) que busca iniciar ejercicio seguro.

Adulto mayor que usa insulina (George, 65 años) con mareos durante clases grupales por la tarde.

Miembro de gimnasio recién diagnosticado (David, 40 años) iniciando entrenamiento de fuerza.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el perfil clínico o riesgo de seguridad de su cliente.
- Análisis de Seguridad Clínica y Programación: Explique las directrices de PAGA 2018 y las estrategias de manejo metabólico para su cliente.
- Mi Auditoría de Seguridad Clínica: Escriba 1 parámetro de seguridad claro y basado en evidencia o ajuste en la prescripción.
- Parte 3: Verificación Activa y Auditoría de Seguridad (Mínimo 150 Palabras en su Propia Voz Humana): Escriba 1 parámetro de seguridad y una defensa de mínimo 150 palabras en su propia voz humana justificando la compuerta de glucosa (100–250 mg/dL) y la protección de los pies.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Evaluación en Español (Escala 10/7/0)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265 Módulo 02 Sesión de Coaching • Ruta 1 (Clínica / Rosa)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Hospitalaria (Rosa, 58 años). Reto: Rosa maneja diabetes tipo 2 con neuropatía periférica temprana y desea comenzar a caminar de forma segura sin arriesgar lesiones en los pies o inestabilidad glucémica.
- Ruta 1: Clínica y Hospitalaria (Rosa, 58 años).
- Reto: Rosa maneja diabetes tipo 2 con neuropatía periférica temprana y desea comenzar a caminar de forma segura sin arriesgar lesiones en los pies o inestabilidad glucémica.
- Análisis de Seguridad Clínica y Programación: Directrices PAGA 2018 para Neuropatía: La neuropatía periférica reduce la sensibilidad protectora en los pies. El ejercicio de alto impacto con carga puede causar ampollas y úlceras no detectadas. Los protocolos clínicos exigen modalidades sin impacto o de bajo impacto (como bicicleta estática reclinada o natación) junto con rigurosas inspecciones diarias de los pies. La glucosa en sangre debe monitorearse antes y después del ejercicio, evitando sesiones si la glucosa en ayunas excede los umbrales de seguridad clínica sin autorización médica.
- Directrices PAGA 2018 para Neuropatía: La neuropatía periférica reduce la sensibilidad protectora en los pies. El ejercicio de alto impacto con carga puede causar ampollas y úlceras no detectadas. Los protocolos clínicos exigen modalidades sin impacto o de bajo impacto (como bicicleta estática reclinada o natación) junto con rigurosas inspecciones diarias de los pies.
- La glucosa en sangre debe monitorearse antes y después del ejercicio, evitando sesiones si la glucosa en ayunas excede los umbrales de seguridad clínica sin autorización médica.
- Mi Auditoría de Seguridad Clínica para Rosa: "Transicionar a Rosa de caminatas de alto impacto a un programa de bicicleta estática reclinada, exigir calcetines sin costuras que absorban la humedad y establecer protocolos de inspección de pies antes y después del ejercicio según los estándares de PAGA 2018."
- "Transicionar a Rosa de caminatas de alto impacto a un programa de bicicleta estática reclinada, exigir calcetines sin costuras que absorban la humedad y establecer protocolos de inspección de pies antes y después del ejercicio según los estándares de PAGA 2018."
- Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi razonamiento clínico, la combinación de diabetes tipo 2 y neuropatía periférica temprana en Rosa exige dos compuertas de seguridad que las aplicaciones genéricas de IA suelen pasar por alto. Primero, dado que la neuropatía reduce la sensibilidad protectora en la planta del pie, caminar con impacto en el pavimento caliente de Yuma puede causar ampollas silenciosas y úlceras diabéticas; usar bicicleta reclinada de bajo impacto e inspeccionar sus pies antes y después del ejercicio elimina la fricción plantar. Segundo, verificar que su glucosa esté entre 100 y 250 mg/dL aprovecha la translocación de GLUT4 sin riesgo de hipoglucemia aguda."
- Mi Frase Inolvidable de Coaching: EN: "For clients with neuropathy, protecting the foundation is the first rule of clinical exercise prescription!" ES: "¡Para clientes con neuropatía, proteger la base es la primera regla de la prescripción de ejercicio clínico!"
- EN: "For clients with neuropathy, protecting the foundation is the first rule of clinical exercise prescription!"
- ES: "¡Para clientes con neuropatía, proteger la base es la primera regla de la prescripción de ejercicio clínico!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M02_Quiz_Sprint.pdf

### ACCESIBILIDAD Y UDL

Todas las actividades de Coaching Sprint en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 02)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
