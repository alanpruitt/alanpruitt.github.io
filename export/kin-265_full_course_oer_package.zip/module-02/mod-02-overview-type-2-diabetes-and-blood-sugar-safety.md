## KIN-265: Mod 02 Overview Type 2 Diabetes And Blood Sugar Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Overview: Type 2 Diabetes & Blood Sugar Safety

Visión General del Módulo 02: Diabetes Tipo 2, Puertas Glucémicas y Adaptación Clínica

Welcome to Module 02 of Exercise for Special Populations! This week, we analyze clinical exercise prescription for Type 2 Diabetes Mellitus (T2DM), pre-activity blood glucose gating thresholds, and sensory peripheral neuropathy adaptations using our academic Single Source of Truth (SSoT): the ADA/ACSM Joint Position Statement on Exercise and Type 2 Diabetes and the 2018 Physical Activity Guidelines for Americans (Chapter 6: Chronic Conditions) .

¡Bienvenido al Módulo 02 de Ejercicio para Poblaciones Especiales! Esta semana analizaremos la prescripción clínica de ejercicio para Diabetes Tipo 2 (DM2), los umbrales de seguridad glucémica y las adaptaciones para neuropatía periférica según la postura conjunta de la ADA y el ACSM.

- KIN-265.2.1.AY26-27: Execute pre-activity clinical screening and evaluate blood glucose safety gates (<100, 100–250, >250 mg/dL with ketones) against ADA/ACSM clinical standards. Ejecutar la evaluación clínica previa y auditar las puertas de seguridad glucémica (<100, 100–250, >250 mg/dL con cetonas) según normas de la ADA/ACSM.
- KIN-265.2.4.AY26-27: Prescribe adapted exercise modalities (non-weight-bearing) and calculate personalized 40%–59% HRR training zones using the Gellish formula for metabolic clients. Prescribir modalidades adaptadas (sin impacto) y calcular zonas de entrenamiento de 40%–59% HRR usando la fórmula de Gellish para clientes metabólicos.

### Learning Objectives / Objetivos de Aprendizaje

- Apply ADA Glycemic Gates: Execute pre-exercise blood glucose screening protocols: enforcing the Rule of 15 for blood glucose <100 mg/dL, clearing the 100–250 mg/dL safe therapeutic window, and testing for ketones if >250 mg/dL to prevent diabetic ketoacidosis (DKA). Aplicar las puertas glucémicas de la ADA: Regla del 15 si es <100 mg/dL, zona segura de 100–250 mg/dL y prueba de cetonas si es >250 mg/dL para evitar cetoacidosis.
- Calculate Gellish HRR Training Zones: Calculate age-predicted Max Heart Rate using the Gellish formula [207 − (0.7 × Age)], determine Heart Rate Reserve (HRR), and establish moderate-intensity (40%–59% HRR) aerobic training zones. Calcular la FC Máx con la fórmula de Gellish [207 − (0.7 × Edad)], determinar la Reserva de Frecuencia Cardíaca (HRR) y fijar zonas de 40%–59% HRR.
- Prescribe Neuropathy Adaptations: Select joint- and skin-protective non-weight-bearing exercise modalities (recumbent cycling, water aerobics) and design daily hand-mirror foot inspection protocols to prevent silent ulcerations. Prescribir modalidades sin impacto (bicicleta reclinada, natación) y protocolos de inspección de pies con espejo para prevenir úlceras por fricción.

### Module Checklist / Lista de Tareas del Módulo:

- Required Clinical Readings: Review the ADA/ACSM Joint Position Statement on Type 2 Diabetes and Gellish HRR formulas. Lecturas Clínicas: Revisar la postura conjunta de ADA/ACSM sobre Diabetes y las fórmulas de Gellish.
- Discussion 02: Post your clinical screening audit by Thursday 11:59 PM MST and submit peer evaluations by Sunday 11:59 PM MST. Discusión 02: Publicación inicial el jueves y respuestas a compañeros el domingo.
- Coaching Sprint 02: Chat with your AI Clinical Preceptor, complete your special populations reflection, and submit plain-text responses. Sesión de Coaching 02: Consultar al Preceptor de IA y entregar respuestas en texto plano.
- Lab 02: Complete the Type 2 Diabetes clinical screening and HRR audit and submit directly into the Canvas text box by Monday 11:59 PM MST. Laboratorio 02: Completar la auditoría de evaluación y HRR en Canvas antes del lunes.

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 02 (Mod 02 Overview: Type 2 Diabetes & Blood Sugar Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Module overview materials and learning activities in KIN-265 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools.

Español: Todos los materiales de descripción del curso en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total accesibilidad para lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Weekly learning objectives and clinical audits emphasize patient safety, glycemic control, and evidence-based clinical reasoning over rote testing pressure.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Visión General del Módulo 02: Diabetes Tipo 2 y Puertas Glucémicas Clínicas

Evaluación Previa, Control Glucémico y Adaptación para Neuropatía

¡Bienvenido al Módulo 02 de Ejercicio para Poblaciones Especiales! Esta semana analizaremos la prescripción clínica de ejercicio para Diabetes Tipo 2 (DM2), los umbrales de seguridad glucémica antes del ejercicio y las adaptaciones para neuropatía sensorial periférica según la postura conjunta de la ADA y el ACSM y las Guías de Actividad Física de 2018 (Capítulo 6: Condiciones Crónicas).


### Objetivos de Aprendizaje

- Aplicar Puertas Glucémicas de la ADA: Aplicar los protocolos de evaluación de glucosa antes de entrenar: ejecutar la Regla del 15 si es <100 mg/dL, verificar la zona segura de 100–250 mg/dL y revisar cetonas si es >250 mg/dL para prevenir la cetoacidosis diabética (CAD).
- Calcular Zonas de Entrenamiento HRR con Gellish: Calcular la Frecuencia Cardíaca Máxima con la fórmula de Gellish [207 − (0.7 × Edad)], determinar la Reserva de Frecuencia Cardíaca (HRR) y establecer zonas aeróbicas moderadas (40%–59% HRR).
- Prescribir Adaptaciones para Neuropatía: Seleccionar modalidades de ejercicio sin impacto (bicicleta reclinada, aeróbicos acuáticos) y estructurar inspecciones diarias de pies con espejo de mano para prevenir úlceras silenciosas.

### Lista de Tareas del Módulo:

- Lecturas Clínicas Obligatorias: Revisar la postura conjunta de ADA/ACSM sobre Diabetes y las fórmulas de Gellish.
- Discusión 02: Publicación inicial antes del jueves y respuestas a compañeros antes del domingo.
- Sesión de Coaching 02: Consultar al Preceptor de IA y enviar respuestas en texto plano.
- Laboratorio 02: Completar la evaluación clínica de Diabetes Tipo 2 y la auditoría de HRR en Canvas antes del lunes 11:59 PM MST.

### ACCESIBILIDAD Y UDL

Todos los materiales de visión general en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando total accesibilidad para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu


### Module 02 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 02 Required Readings: Type 2 Diabetes & Blood Sugar Safety →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 02 Discussion: Exercise & Blood Sugar Control in Type 2 Diabetes →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 02 Coaching Sprint: Preventing Low Blood Sugar During Workouts →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 02 Lab: Type 2 Diabetes Exercise & Foot-Safety Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 02 Summary & Wrap-Up: Type 2 Diabetes & Blood Sugar Safety →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 02)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
