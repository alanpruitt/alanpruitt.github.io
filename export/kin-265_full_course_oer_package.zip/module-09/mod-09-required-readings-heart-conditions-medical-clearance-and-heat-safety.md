## KIN-265: Mod 09 Required Readings Heart Conditions Medical Clearance And Heat Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 09 Required Readings: Heart Conditions, Medical Clearance & Heat Safety


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Cardiovascular pathologies are heart and blood vessel conditions that require strict clinical safety limits during exercise. When medications alter heart rate, we track exertion using the Borg RPE scale (rating effort from 6 to 20). Monitoring blood pressure stop limits and perceived effort protects your clients from dangerous cardiac strain, especially during hot Yuma workouts.


#### En Palabras Sencillas (Norteño Context)

Pensar en el corazón de un cliente hipertenso es como manejar una troca cargada subiendo una cuesta bajo el calor de Yuma; no puedes acelerar a fondo sin vigilar la aguja de la temperatura. Si los términos técnicos se ponen pesados, concéntrate primero en vigilar los límites de presión arterial y escuchar el esfuerzo percibido de la persona.


### Regional Focus: Managing Cardiovascular Risk in Yuma County

Enfoque Regional: Manejo del Riesgo Cardiovascular en el Condado de Yuma

In Yuma County and across Southwest Arizona, exercise specialists frequently encounter aging adults, agricultural workers, and community members managing hypertension, coronary artery disease, and metabolic syndrome. Designing safe activity programs requires strict adherence to federal standards (PAGA 2018) and understanding hemodynamic responses to physical exertion.

En el condado de Yuma y el suroeste de Arizona, los especialistas en ejercicio frecuentemente atienden a adultos mayores y miembros de la comunidad que manejan hipertensión y cardiopatías. Diseñar programas seguros exige apego a las normas federales (PAGA 2018).


### Reading 1: Hemodynamics & Cardiovascular Disease Mechanisms

Lectura 1: Hemodinámica y Mecanismos de las Enfermedades Cardiovasculares


#### Step 1: Blood Pressure Responses and Rate Pressure Product (RPP)

Respuestas de Presión Arterial y Producto de Doble Multiplicación (RPP)

During aerobic exercise, systolic blood pressure (SBP) rises linearly with workload while diastolic blood pressure (DBP) remains relatively stable or decreases slightly. In hypertensive or post-myocardial infarction populations, monitoring the Rate Pressure Product (RPP = Heart Rate × Systolic Blood Pressure) provides a reliable clinical index of myocardial oxygen demand.

Durante el ejercicio aeróbico, la presión sistólica aumenta linealmente mientras la diastólica se mantiene estable. En poblaciones con hipertensión, el RPP proporciona un índice clínico confiable de la demanda de oxígeno miocárdico.


#### Step 2: Absolute and Relative Contraindications to Exercise

Contraindicaciones Absolutas y Relativas para el Ejercicio

Exercise professionals must immediately recognize clinical red flags—such as unstable angina, uncompensated heart failure, or complex arrhythmias—that represent absolute contraindications requiring immediate medical cessation and referral.

Los profesionales del ejercicio deben reconocer de inmediato signos de alarma clínica (como angina inestable o arritmias complejas) que representan contraindicaciones absolutas.


### Reading 2: PAGA 2018 Prescriptive Standards for Cardiac Health

Lectura 2: Normas Prescriptivas de PAGA 2018 para la Salud Cardíaca


#### Step 1: Aerobic Frequency, Intensity, Time, and Type (FITT)

Frecuencia, Intensidad, Tiempo y Tipo Aeróbico (FITT)

In strict alignment with the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , adults with stable cardiovascular disease should accumulate 150 to 300 minutes of moderate-intensity aerobic activity weekly. Intensity must be gauged using individualized heart rate reserve (HRR) or Rating of Perceived Exertion (RPE 11–13 on the 6–20 Borg scale).

En alineación con PAGA 2018, los adultos con cardiopatías estables deben acumular de 150 a 300 minutos de actividad aeróbica semanal de intensidad moderada, usando la escala RPE de Borg.


#### Step 2: Resistance Training Precautions in Hypertension

Precauciones del Entrenamiento de Fuerza en Hipertensión

Resistance training is highly beneficial for metabolic health but requires strict breathing instructions to prevent excessive blood pressure spikes caused by the Valsalva maneuver. Prescribe moderate loads (40–60% of 1-RM) with higher repetitions and continuous exhalation.

El entrenamiento de fuerza es muy beneficioso pero requiere instrucciones estrictas de respiración para evitar picos excesivos de presión arterial causados por la maniobra de Valsalva.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of cardiovascular pathology baselines before proceeding:

English Response: Systolic blood pressure (SBP) rises linearly with workload, while diastolic blood pressure (DBP) remains relatively stable or decreases slightly.

Respuesta en Español: La presión sistólica aumenta linealmente con la carga de trabajo, mientras que la diastólica se mantiene estable o disminuye ligeramente.

English Response: Accumulation of 150 to 300 minutes of moderate-intensity aerobic activity weekly, or 75 to 150 minutes of vigorous-intensity aerobic activity.

Respuesta en Español: Acumulación de 150 a 300 minutos de actividad aeróbica de intensidad moderada semanalmente, o de 75 a 150 minutos de intensidad vigorosa.

English Response: It causes a dramatic, dangerous spike in blood pressure and places excessive acute strain on the cardiovascular system.

Respuesta en Español: Provoca un aumento dramático y peligroso en la presión arterial y ejerce una tensión aguda excesiva sobre el sistema cardiovascular.

KIN-265 • Module 09 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 09 (Mod 09 Required Readings: Heart Conditions, Medical Clearance & Heat Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 09)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
