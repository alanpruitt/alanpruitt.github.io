## KIN-265: Mod 09 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 09) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Coaching Sprint Simulation: Managing Heart Rate, Blood Pressure & Heat

- Chronotropic Incompetence & Pacemaker/ICD Rate Ceilings: Clients with pacemakers or implantable cardioverter-defibrillators (ICDs) have programmed heart-rate limits; target HR must remain ≥10–15 bpm below the ICD shock threshold. En palabras sencillas: En pacientes con marcapasos o desfibrilador (ICD) mantenemos el pulso al menos 10 a 15 latidos por debajo del límite programado por su cardiólogo.
- Sternal & Upper-Limb Lead Precautions: Avoiding vigorous overhead shoulder elevation or heavy chest loading after pacemaker implantation or sternotomy until full surgical clearance is granted. En palabras sencillas: Cuidar los movimientos bruscos de hombro por encima de la cabeza o carga en el pecho tras cirugía cardíaca o colocación de marcapasos.
- Thermal Cardiac Strain in Yuma Heat: High ambient heat forces the heart to pump extra blood to the skin while sweat losses reduce stroke volume; cardiac patients must exercise in climate-controlled indoor spaces. En palabras sencillas: El calor extremo obliga al corazón a trabajar el doble; todo paciente cardíaco en Yuma debe ejercitarse bajo techo con aire acondicionado.
- KIN-265.9.1.AY26-27: Prescribe safe aerobic exercise intensity using the Borg RPE scale for clients with cardiovascular disease and altered heart rate responses across diverse career tracks. Prescribir intensidad de ejercicio aeróbico segura usando la escala Borg RPE para clientes con cardiopatías y respuestas cardíacas alteradas en diversas rutas profesionales.
- KIN-265.9.2.AY26-27: Audit clinical blood pressure safety limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de seguridad de presión arterial y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering Cardiovascular Hemodynamics & RPE Intensity Gating

How can fitness professionals safely monitor exercise intensity when a client is taking medications like beta-blockers that lower heart rate? Because standard age-predicted heart rate formulas do not apply, exercise specialists use the Borg RPE scale (6 to 20) to measure subjective exertion. Following strict PAGA 2018 clinical guidelines, trainers can monitor blood pressure stop limits (SBP > 220 / DBP > 105) and protect client health. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master clinical safety auditing!

¿Cómo pueden los profesionales monitorear la intensidad del ejercicio cuando un cliente toma betabloqueadores? Usando la escala Borg RPE y los límites de presión arterial de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría clínica!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Clinical rehabilitation client post-myocardial infarction managing controlled blood pressure while taking daily beta-blockers; establishing safe aerobic progression using the Borg RPE scale.

Scenario: Senior community center participant with Stage 2 hypertension and mild osteoarthritis; formulating a safe walking group intensity protocol and blood pressure monitoring plan.

Scenario: Law enforcement officer with metabolic syndrome and elevated resting heart rate; designing a preventive occupational conditioning and interval training framework.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Robert, Elena, or Marcus).
- Cardiovascular Analysis: Explain the key hemodynamic or pharmacological consideration for your selected client.
- Part 3: Active Verification & Safety Audit: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your hemodynamic safety parameter, Borg RPE gating, or exercise prescription adjustment protects your client under PAGA 2018 standards.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 09 Coaching Sprint • Track 1 (Robert)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Robert (Age 62).
- Cardiovascular Analysis: Robert is post-myocardial infarction and takes metoprolol (a beta-blocker), which blunts his heart rate response during exertion. Standard heart rate formulas do not work for him, so we use the Borg RPE scale (11–13) to measure perceived exertion while protecting myocardial oxygen demand.
- Part 3: Active Verification & Safety Audit: "Monitor Robert's workout intensity strictly using Borg RPE (11–13) instead of heart rate, and terminate exercise immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic per PAGA 2018." Active Verification: In my clinical reasoning, Robert's post-infarction status combined with metoprolol therapy blunts his chronotropic acceleration. Pushing him to reach an age-predicted pulse target would cause silent ischemia. Instead, gating his workout strictly to Borg RPE 11–13 allows safe cardiorespiratory conditioning without exceeding myocardial oxygen supply. Exercising in an indoor facility avoids Yuma's intense thermal stress, and enforcing continuous exhalation prevents blood pressure spikes from approaching the 220/105 mmHg safety cutoff.
- "Monitor Robert's workout intensity strictly using Borg RPE (11–13) instead of heart rate, and terminate exercise immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic per PAGA 2018."
- Active Verification: In my clinical reasoning, Robert's post-infarction status combined with metoprolol therapy blunts his chronotropic acceleration. Pushing him to reach an age-predicted pulse target would cause silent ischemia. Instead, gating his workout strictly to Borg RPE 11–13 allows safe cardiorespiratory conditioning without exceeding myocardial oxygen supply. Exercising in an indoor facility avoids Yuma's intense thermal stress, and enforcing continuous exhalation prevents blood pressure spikes from approaching the 220/105 mmHg safety cutoff.
- Part 4: My Memorable Coaching Takeaway: EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!" "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!"
- "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M09_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 09 (Mod 09 Coaching Sprint: Managing Heart Rate, Blood Pressure & Heat)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 09 Simulación de Coaching: Patologías Cardiovasculares y Hemodinámica

Evaluación Rápida y Auditoría de Seguridad Cardiovascular


### Su Logro Semanal: Dominando la Hemodinámica y el Esfuerzo Percibido

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar la escala Borg RPE y proteger la demanda miocárdica de oxígeno cuando los medicamentos alteran la frecuencia cardíaca. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente de rehabilitación clínica post-infarto que toma betabloqueadores; establecer una progresión aeróbica segura usando la escala Borg RPE.

Escenario: Participante de centro comunitario con hipertensión Estadio 2 y osteoartritis leve; formular un protocolo seguro de intensidad para caminatas y monitoreo de presión arterial.

Escenario: Oficial de policía con síndrome metabólico y frecuencia cardíaca elevada en reposo; diseñar un marco preventivo de acondicionamiento e intervalos.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Robert, Elena o Marcus).
- Análisis Cardiovascular: Explique la consideración hemodinámica o farmacológica clave para su cliente.
- Parte 3: Verificación Activa y Auditoría de Seguridad: En una defensa de texto obligatoria (aprox. mínimo 150 palabras (150+ palabras)) redactada con su propia voz clínica, justifique por qué su parámetro de seguridad hemodinámica, control de esfuerzo Borg RPE o ajuste de prescripción protege a su cliente bajo los estándares de PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su frase inolvidable de aprendizaje en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 09, Sesión de Coaching • Ruta 1 (Robert)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Robert (62 años).
- Análisis Cardiovascular: Robert es post-infarto y toma metoprolol, lo que reduce su frecuencia cardíaca en reposo y blunts su aumento durante el ejercicio. Usamos la escala Borg RPE (11–13) para medir el esfuerzo protegiendo la demanda miocárdica de oxígeno.
- Parte 3: Verificación Activa y Auditoría de Seguridad para Robert: "Monitorear la intensidad del entrenamiento de Robert usando estrictamente la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca, y suspender el ejercicio si la presión arterial supera 220 mmHg sistólica o 105 mmHg diastólica según PAGA 2018." Verificación Activa: En mi criterio clínico, el estado post-infarto de Robert junto con el metoprolol reduce su respuesta cronotrópica. Forzarlo a alcanzar una frecuencia cardíaca meta calculada por edad provocaría isquemia silente. En su lugar, regular su sesión estrictamente con la escala Borg RPE 11–13 permite un acondicionamiento cardiorrespiratorio seguro sin superar la oferta miocárdica de oxígeno. Realizar el ejercicio en interiores evita el calor extremo de Yuma, y exigir una exhalación continua previene picos de presión arterial que se acerquen al límite de seguridad de 220/105 mmHg.
- "Monitorear la intensidad del entrenamiento de Robert usando estrictamente la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca, y suspender el ejercicio si la presión arterial supera 220 mmHg sistólica o 105 mmHg diastólica según PAGA 2018."
- Verificación Activa: En mi criterio clínico, el estado post-infarto de Robert junto con el metoprolol reduce su respuesta cronotrópica. Forzarlo a alcanzar una frecuencia cardíaca meta calculada por edad provocaría isquemia silente. En su lugar, regular su sesión estrictamente con la escala Borg RPE 11–13 permite un acondicionamiento cardiorrespiratorio seguro sin superar la oferta miocárdica de oxígeno. Realizar el ejercicio en interiores evita el calor extremo de Yuma, y exigir una exhalación continua previene picos de presión arterial que se acerquen al límite de seguridad de 220/105 mmHg.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!" "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!"
- "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M09_Quiz_Sprint.pdf
KIN-265 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 09)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
