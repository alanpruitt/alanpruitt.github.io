## KIN-265: Mod 06 Required Readings High Blood Pressure And Medication Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Required Readings: High Blood Pressure & Medication Safety

Lecturas Clínicas Obligatorias: Cinética Cardiovascular, Regulación Hemodinámica y Control Metabólico


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Hypertension (chronic high blood pressure) forces the heart and arteries to work against elevated resistance. Regular moderate aerobic and dynamic resistance exercise lowers resting blood pressure by 5 to 8 mmHg, provided resting blood pressure starts below the 180/110 mmHg safety ceiling. Exhaling during exertion (never holding your breath in a Valsalva maneuver) and cooling down gradually in Yuma heat prevents blood pressure spikes and dizziness.


#### En Palabras Sencillas (Norteño Context)

Controlar la presión arterial al entrenar es como cuidar la presión de una manguera de riego: nunca dobles la manguera aguantando la respiración. Si los términos técnicos se ponen pesados, concéntrate primero en el límite de seguridad en reposo (< 180/110 mmHg), evitar la maniobra de Valsalva y hacer un enfriamiento gradual.

All required clinical reading chapters, federal safety mandates, and metabolic management protocols are embedded directly below. No external textbook purchases or paid downloads are required.

Todos los capítulos de lectura clínica requeridos, los mandatos federales de seguridad y los protocolos de control metabólico están integrados directamente abajo. No se requiere comprar libros de texto externos ni realizar descargas de pago.


### Required SSoT Text & Federal Guidelines / Texto Fuente SSoT y Lineamientos Federales

Primary Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • Chapter 7: Active Adults with Chronic Health Conditions and Disabilities (Cardiovascular and Metabolic Disease Focus).

Fuente Única de Verdad Primaria (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) • Capítulo 7: Adultos Activos con Afecciones Crónicas y Discapacidades (Enfoque en Enfermedades Cardiovasculares y Metabólicas).

Primary SSoT Anchor: Chapter 7: Physical Activity for Adults with Chronic Health Conditions (Hypertension, CAD & Type 2 Diabetes).

Referencia Central SSoT: Capítulo 7: Actividad Física para Adultos con Afecciones Crónicas (Hipertensión, EAC y Diabetes Tipo 2).

- Official Federal Guidelines Portal / Portal Federal Oficial: PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev)
- Course Offline Repository Document / Documento del Repositorio: exw265_ssot_special_populations_reference.docx (Download to study offline or upload to your AI Repository / Descargue para estudiar sin conexión o suba a su Repositorio de IA)
Clinical Focus: Hemodynamic safety limits, post-exercise hypotension, and non-insulin-mediated glucose uptake (GLUT4 translocation).

Enfoque Clínico: Límites de seguridad hemodinámica, hipotensión post-ejercicio y captación de glucosa no mediada por insulina (translocación de GLUT4).

- Target Aerobic Volume: Accumulate 150 to 300 minutes of moderate-intensity aerobic exercise weekly (40% to 59% VO2R / RPE 11 to 13 on the Borg 6 to 20 scale). Volumen Aeróbico Objetivo: Acumular de 150 a 300 minutos semanales de ejercicio aeróbico de intensidad moderada (40% a 59% VO2R / RPE 11 a 13 en la escala Borg 6 a 20).
- Hemodynamic Safety Stop-Test Criteria: Immediately terminate exercise if Systolic Blood Pressure exceeds 220 mmHg (SBP > 220 mmHg), Diastolic Blood Pressure exceeds 105 mmHg (DBP > 105 mmHg), or if SBP drops by 10 mmHg or more below baseline despite increasing workload. Criterios Hemodinámicos de Parada: Suspender de inmediato el ejercicio si la Presión Arterial Sistólica supera 220 mmHg (PAS > 220 mmHg), la Diastólica supera 105 mmHg (PAD > 105 mmHg), o si la PAS cae 10 mmHg o más respecto al reposo al aumentar la carga.
- Glycemic Control Safety Windows: Pre-exercise blood glucose target is 100 to 250 mg/dL. If blood glucose is less than 100 mg/dL, ingest 15 to 30 grams of fast-acting carbohydrate before starting exertion. If blood glucose exceeds 250 mg/dL with ketones present (or >300 mg/dL without ketones), delay exercise until metabolic control is established. Ventana de Seguridad Glucémica: Rango previo al ejercicio de 100 a 250 mg/dL. Si es <100 mg/dL, ingerir 15 a 30 g de carbohidratos simples antes de iniciar. Si supera 250 mg/dL con cetonas (o >300 mg/dL sin cetonas), posponer hasta normalizar el control metabólico.
- Resistance Training Technique: Mandate continuous breathing cadences (exhale on concentric exertion, inhale on eccentric return) to eliminate Valsalva maneuvers and prevent dangerous intracranial and intra-arterial pressure spikes. Técnica en Entrenamiento de Fuerza: Exigir respiración continua (exhalar en la fase concéntrica, inhalar en la excéntrica) para eliminar la maniobra de Valsalva y prevenir picos de presión intraarterial e intracraneal.

### Regional Focus: Desert Heat Strain & Medication Kinetics in Yuma County

Enfoque Regional: Estrés Térmico del Desierto, Farmacología Cardiovascular y Control Glucémico en Yuma

In Yuma County and regional agricultural border communities, summer ambient temperatures routinely exceed 105°F (40.5°C). For clients with hypertension, coronary artery disease, or Type 2 diabetes, thermal stress compounds cardiovascular strain. Antihypertensive medications (beta-blockers and diuretics) significantly impair normal thermoregulation by blunting maximal heart rate, reducing cutaneous blood flow, and accelerating dehydration. Furthermore, heat stress accelerates subcutaneous insulin absorption rates, predisposing active individuals with diabetes to sudden, severe hypoglycemia during outdoor work. Clinical exercise specialists at Matador Clinical Partners (MCP) mandate indoor climate-controlled environments (72°F / 22°C), RPE-guided intensity (Borg 11 to 13), rapid-acting carbohydrate availability, and strict post-exercise hydration monitoring.

En el condado de Yuma y las comunidades del desierto, el calor de más de 40.5°C altera la fisiología cardiovascular y metabólica. Los betabloqueadores y diuréticos alteran la sudoración y la termorregulación, mientras que el calor acelera la absorción de insulina, aumentando el riesgo de hipoglucemia. Los especialistas de Matador Clinical Partners (MCP) exigen el uso de instalaciones climatizadas (22°C), regulación de intensidad mediante esfuerzo percibido (RPE 11 a 13) y disponibilidad constante de carbohidratos de absorción rápida.


### Reading 1: Hemodynamics, Vascular Resistance & Post-Exercise Hypotension

Lectura 1: Hemodinámica, Resistencia Vascular e Hipotensión Post-Ejercicio


#### Step 1: Vascular Mechanics & Rate-Pressure Product (RPP)

Mecánica Vascular y Doble Producto (Doble Producto = FC * PAS)

Hypertension is characterized by chronic endothelial dysfunction, arterial stiffening, and elevated systemic vascular resistance (SVR). During physical activity, myocardial oxygen demand is clinically evaluated using the Rate-Pressure Product (RPP) , calculated as Heart Rate multiplied by Systolic Blood Pressure (RPP = HR * SBP). In clients with coronary artery disease, angina or ischemic ST-segment depression occurs at a reproducible RPP threshold ("ischemic threshold"). Exercise intensity must be prescribed at least 10 to 15 beats below this ischemic heart rate.

La hipertensión se caracteriza por disfunción endotelial y resistencia vascular sistémica elevada. En el esfuerzo, la demanda miocárdica de oxígeno se evalúa con el Doble Producto (RPP = FC * PAS). En pacientes coronarios, la isquemia o angina surge a un umbral reproducible de RPP; la prescripción debe mantenerse de 10 a 15 latidos por debajo de dicho umbral isquémico.


#### Step 2: Acute Post-Exercise Hypotension (PEH) Kinetics

Cinética de la Hipotensión Post-Ejercicio

Following a single bout of moderate-intensity aerobic exercise (30 to 45 minutes at 40% to 59% VO2R), systemic vascular resistance decreases due to persistent local vasodilation (mediated by nitric oxide and histamine release) and reduced sympathetic vasoconstrictor tone. This results in Post-Exercise Hypotension (PEH) , producing immediate reductions in systolic blood pressure of 5 to 10 mmHg that persist for up to 24 hours. Consequently, daily aerobic physical activity provides a direct, non-pharmacological blood-pressure-lowering therapy.

Tras una sesión de ejercicio aeróbico moderado (30 a 45 minutos), la resistencia vascular disminuye por vasodilatación local (óxido nítrico e histamina) y menor tono simpático. Esto produce Hipotensión Post-Ejercicio (HPE), reduciendo la PAS de 5 a 10 mmHg hasta por 24 horas y convirtiendo el ejercicio diario en una terapia antihipertensiva fundamental.


### Reading 2: Glycemic Windows, Insulin Sensitivity & GLUT4 Kinetics

Lectura 2: Ventanas Glucémicas, Sensibilidad a la Insulina y Translocación de GLUT4


#### Step 1: Contraction-Mediated (Non-Insulin) Glucose Uptake

Captación de Glucosa Mediada por Contracción Muscular

In Type 2 Diabetes, insulin resistance impairs insulin-mediated GLUT4 glucose transporter translocation from intracellular vesicles to the sarcolemma. However, skeletal muscle contraction activates an independent cellular signaling cascade (mediated by calcium-calmodulin dependent protein kinase and 5'-AMP-activated protein kinase, AMPK) that translocates GLUT4 transporters to the cell membrane without requiring insulin. This restores glucose uptake during and up to 48 hours post-exercise, establishing the clinical requirement that individuals with diabetes must not exceed 2 consecutive days without physical activity.

En la diabetes tipo 2, la contracción muscular activa una vía independiente (vía AMPK y calcio-calmodulina) que transloca transportadores GLUT4 a la membrana celular sin necesitar insulina. Esto restaura la captación de glucosa hasta por 48 horas, fundamentando la regla clínica de no dejar pasar más de 2 días consecutivos sin actividad física.


#### Step 2: Clinical Glycemic Safety Decision Matrix

Matriz de Decisión Clínica y Seguridad Glucémica


### Key Terminology / Glosario Clave

An indirect clinical measure of myocardial oxygen consumption, calculated as Heart Rate multiplied by Systolic Blood Pressure (RPP = HR * SBP), used to establish the ischemic threshold in coronary artery disease.

Medida indirecta del consumo miocárdico de oxígeno (Doble Producto = FC * PAS), utilizada para establecer el umbral isquémico en la enfermedad arterial coronaria.

The acute, sustained reduction in systemic blood pressure (typically 5 to 10 mmHg systolic drop) occurring immediately after aerobic exercise and lasting up to 24 hours, driven by persistent peripheral vasodilation.

Disminución aguda y sostenida de la presión arterial (5 a 10 mmHg sistólica) que ocurre tras el ejercicio aeróbico debido a la vasodilatación periférica persistente.

The movement of glucose transporter-4 proteins from intracellular vesicles to the skeletal muscle cell surface, triggered independently by muscle contractions via AMPK signaling to facilitate glucose entry without insulin.

Desplazamiento de los transportadores GLUT4 hacia la membrana muscular activado mecánicamente por la contracción muscular vía señalización AMPK para captar glucosa sin insulina.


### Reading Knowledge Verification / Verificación de Conocimientos

Verificación Rápida de Lectura y Cinética Cardio-Metabólica

Select each question below to confirm your understanding of hemodynamic safety thresholds and glycemic control before starting Discussion 06 and Lab 06:

English Response: Physical activity must be terminated immediately if Systolic Blood Pressure exceeds 220 mmHg (SBP > 220 mmHg) , Diastolic Blood Pressure exceeds 105 mmHg (DBP > 105 mmHg) , or if SBP experiences an exertional drop of 10 mmHg or more below baseline resting values despite an increase in exercise intensity.

Respuesta en Español: El ejercicio debe detenerse de inmediato si la presión sistólica supera los 220 mmHg (PAS > 220 mmHg) , la diastólica supera los 105 mmHg (PAD > 105 mmHg) , o si la PAS cae 10 mmHg o más por debajo del valor de reposo durante el esfuerzo.

English Response: Beta-blockers (e.g., atenolol, metoprolol) competitively block beta-1 adrenergic receptors in the myocardium, blunting normal chronotropic heart rate responses by 20 to 30 bpm at rest and during peak exercise. Because age-predicted heart rate formulas are invalid, intensity must be regulated using the Borg 6 to 20 RPE Scale (targeting 11 to 13: "light" to "somewhat hard") .

Respuesta en Español: Los betabloqueadores bloquean los receptores adrenérgicos y reducen la respuesta cardíaca en 20 a 30 lpm, invalidando las fórmulas de frecuencia cardíaca. Por ello, la intensidad debe regularse mediante la Escala Borg 6 a 20 de RPE (meta 11 a 13) .

English Response: A blood glucose of 88 mg/dL is below the safe pre-exercise threshold (100 mg/dL). The client must ingest 15 to 30 grams of rapidly absorbed simple carbohydrate (e.g., 4 oz fruit juice, 4 glucose tablets, or a small banana) and rest. Retest blood glucose in 15 to 20 minutes; exercise may begin only after blood glucose levels reach or exceed 100 mg/dL.

Respuesta en Español: Al estar por debajo de 100 mg/dL, el cliente debe ingerir 15 a 30 gramos de carbohidratos de absorción rápida (4 oz de jugo o tabletas de glucosa) y esperar 15 a 20 minutos hasta que la glucemia sea igual o superior a 100 mg/dL antes de entrenar.


### AI Simulation Workspace • Cardio-Metabolic Safety Auditor Simulation

Copy the prompt below into Gemini to audit client cardiovascular and glycemic profiles, screen for hemodynamic risks, and construct clinical exercise prescriptions:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy / Haga clic para copiar la plantilla)


```text
Safety Auditor Protocol: KIN-265 Module 06 Cardio-Metabolic Tool Box ###:
Role: Clinical Exercise Specialist and Cardiac Rehabilitation Preceptor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chapter 7 Active Adults with Chronic Conditions.

Instructions:
Step 1: Review the candidate case profile enclosed within triple-hashes (###) below.
Step 2: PATTERN: Analyze their hemodynamic response (blood pressure, Rate-Pressure Product, beta-blocker blunting) and glycemic kinetics (fasting glucose, insulin sensitivity, hypoglycemia risk).
Step 3: RULE: Apply federal PAGA 2018 chronic condition mandates, hemodynamic stop-test criteria (SBP > 220 mmHg, DBP > 105 mmHg, or SBP drop > 10 mmHg), and glycemic safety windows (100 to 250 mg/dL target).
Step 4: SOLVE: Detail an individualized aerobic and resistance conditioning plan (specifying RPE targets, breathing cadence to eliminate Valsalva, and carbohydrate safety protocols) adapted for Yuma County climate conditions.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.
Step 6: Maintain all client data wrapped in triple-hash (###) delimiters.

Client Data Input ###:
Client Age & Primary Diagnosis: [e.g., 62-year-old with Stage 2 Hypertension and Type 2 Diabetes]
Current Medications: [e.g., Metoprolol 50mg daily, Metformin 1000mg daily]
Resting Hemodynamics & Glucose: [e.g., Resting BP: 148/92 mmHg, Resting HR: 62 bpm, Pre-exercise Glucose: 92 mg/dL]
Functional Presentation: [e.g., Desires resistance training but holds breath during exertion; experiences lightheadedness in heat]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 06 (Mod 06 Required Readings: High Blood Pressure & Medication Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. Digital OER text is fully accessible to screen readers without downloading external PDFs.

Español: Todos los materiales de lectura de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla sin descargas de pago.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Clínicas Obligatorias: Cinética Cardiovascular y Control Metabólico

Regulación Hemodinámica, Respuestas Cardiovasculares y Adaptaciones Metabólicas

Todos los capítulos de lectura clínica requeridos, los mandatos federales de seguridad y los protocolos de control metabólico están integrados directamente abajo. No se requiere comprar libros de texto externos ni realizar descargas de pago.


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) (Capítulo 7: Adultos Activos con Afecciones Crónicas y Discapacidades • Enfoque en Enfermedades Cardiovasculares y Metabólicas).

Herramienta Interactiva PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev)

Documento sin conexión: exw265_ssot_special_populations_reference.docx

- Volumen Aeróbico Objetivo: 150 a 300 minutos semanales de actividad de intensidad moderada (40% a 59% VO2R / RPE 11 a 13 en la escala Borg 6 a 20).
- Límites Hemodinámicos de Parada: Suspender el ejercicio de inmediato si la PAS supera 220 mmHg, la PAD supera 105 mmHg o si la PAS cae 10 mmHg o más respecto al reposo al aumentar la carga.
- Ventanas de Glucemia Segura: Rango óptimo de 100 a 250 mg/dL. Suplementar con 15 a 30 g de carbohidratos simples si la glucosa es menor a 100 mg/dL. Si es >250 mg/dL con cetonas (o >300 mg/dL sin cetonas), posponer el esfuerzo.
- Técnica en Fuerza: Exigir respiración continua (exhalar en el esfuerzo, inhalar en el retorno) para evitar la maniobra de Valsalva.

### Enfoque Regional: Estrés Térmico del Desierto y Farmacología en Yuma

En el condado de Yuma y las comunidades del desierto, el calor de más de 40.5°C altera la fisiología cardiovascular y metabólica. Los betabloqueadores y diuréticos alteran la sudoración y la termorregulación, mientras que el calor acelera la absorción subcutánea de insulina, aumentando el riesgo de hipoglucemia. Los especialistas de Matador Clinical Partners (MCP) exigen el uso de instalaciones climatizadas (22°C), regulación de intensidad mediante esfuerzo percibido (RPE 11 a 13) y disponibilidad constante de carbohidratos de absorción rápida.


### Conceptos Clínicos Centrales


#### Step 1: Hipotensión Post-Ejercicio y Doble Producto

El ejercicio aeróbico genera vasodilatación sostenida mediada por óxido nítrico e histamina, reduciendo la presión arterial sistólica de 5 a 10 mmHg durante las 24 horas posteriores. En pacientes coronarios, el Doble Producto (Doble Producto = FC * PAS) permite estimar el consumo de oxígeno miocárdico y programar el entrenamiento de 10 a 15 latidos por debajo del umbral isquémico.


#### Step 2: Translocación de GLUT4 sin Insulina

La contracción muscular activa la enzima AMPK y vías dependientes de calcio-calmodulina, translocando transportadores GLUT4 a la membrana celular sin requerir insulina. Esto restaura la captación de glucosa hasta por 48 horas, lo que exige no dejar pasar más de 2 días consecutivos sin entrenar.


### Caja de Herramientas de IA • Protocolo de Auditoría Clínica

(Haga clic dentro del recuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar en Gemini):


```text
Protocolo Safety Auditor: KIN-265 Modulo 06 Caja de Herramientas ###:
Rol: Especialista en Ejercicio Clinico y Mentor de Rehabilitacion Cardiaca.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Capitulo 7 Adultos con Condiciones Cronicas.

Instrucciones:
Step 1: Revisar el caso del paciente envuelto entre triples numerales (###).
Step 2: PATRON: Analizar la respuesta hemodinamica (presion arterial, Doble Producto, efecto de betabloqueadores) y la cinetica de glucosa (glucemia en ayunas, sensibilidad a la insulina, riesgo de hipoglucemia).
Step 3: REGLA: Aplicar las pautas de PAGA 2018, los criterios de parada hemodinamica (PAS > 220 mmHg, PAD > 105 mmHg o caida de PAS > 10 mmHg) y la ventana de glucemia segura (meta: 100 a 250 mg/dL).
Step 4: SOLUCION: Disenar una rutina individualizada de ejercicio aerobico y de fuerza (especificando metas de RPE, cadencia de respiracion para evitar Valsalva y protocolo de carbohidratos) adaptada al clima de Yuma.
Step 5: Proporcionar una tarjeta de instruccion bilingue de 2 oraciones (ingles y espanol).
Step 6: Mantener todos los datos del cliente delimitados con triples numerales (###).

Entrada de Datos del Cliente ###:
[PEGUE AQUI LOS DATOS DEL CASO ENTRE DELIMITADORES]
Fin de Datos del Cliente ###:
Fin del Protocolo Safety Auditor ###:
```


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 06 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 06:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 06)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
