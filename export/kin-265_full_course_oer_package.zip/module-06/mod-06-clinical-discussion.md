## KIN-265: Mod 06 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Discussion: High Blood Pressure & Medication Safety in Exercise

Foro de Discusión del Módulo 06: Hipertensión Arterial y Seguridad Farmacológica en el Ejercicio


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Blood pressure medications change how the heart and blood vessels respond to exercise, especially in Yuma's heat. Beta-blockers keep heart rate artificially low (so we use the Borg RPE Talk Test instead of heart-rate formulas), vasodilators and diuretics can cause dizziness if a client stops moving suddenly, and holding your breath while lifting (the Valsalva maneuver) causes dangerous blood pressure spikes. Auditing these medication rules keeps every workout safe.

En Palabras Sencillas (Contexto Norteño): Los medicamentos para la presión cambian cómo responden el corazón y las venas durante el ejercicio, sobre todo con el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en tres reglas de oro: usar la prueba del habla (RPE) cuando toman betabloqueadores, exhalar en cada esfuerzo para no aguantar la respiración (Valsalva) y enfriar despacio por 10 minutos para evitar mareos.


### Phase 1: Select Your Clinical Simulation Case File #265-06 / Fase 1: Selección de Escenario de Simulación Clínica


```text
STRUCTURAL_DELIMITER_BOUND_1 ###:
[CASE FILE]: #265-06A (Track 1: Clinical & Cardiac Rehab Path)
[CLIENT]: Sr. Roberto M., Age 62 (Yuma, AZ; Stage 2 Hypertension on Metoprolol 50 mg/day; Resting BP: 136/84 mmHg; Resting HR: 54 bpm)
[CLINICAL PRESENTATION]: Generic smartwatch AI tells him he must reach 135 bpm (80% age-predicted HRmax) to get cardiovascular benefit; he pushes to exhaustion trying to raise his pharmacologically blunted heart rate.
[DISCUSSION TASK]: Audit beta-blocker negative chronotropic/inotropic effects and pivot to Borg RPE 11-13 (6-20 scale) & the Talk Test under PAGA 2018.
STRUCTURAL_DELIMITER_BOUND_1 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_2 ###:
[CASE FILE]: #265-06B (Track 2: Community Wellness & Active Aging Path)
[CLIENT]: Sra. Elena G., Age 66 (Foothills / Yuma, AZ; Hypertension on Lisinopril + Hydrochlorothiazide; Resting BP: 132/80 mmHg)
[CLINICAL PRESENTATION]: Completes brisk walking class in a warm gym and stops abruptly to sit down; experiences lightheadedness and venous pooling (BP drops to 96/60 mmHg).
[DISCUSSION TASK]: Audit vasodilator/diuretic venous pooling + thermal cutaneous vasodilation and prescribe an extended 8-10 minute active cool-down and hydration protocol.
STRUCTURAL_DELIMITER_BOUND_2 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_3 ###:
[CASE FILE]: #265-06C (Track 3: Strength & Conditioning Path)
[CLIENT]: Marcos T., Age 47 (San Luis, AZ; Hypertension; arrives at gym after skipping morning Amlodipine with Resting BP: 184/112 mmHg)
[CLINICAL PRESENTATION]: Wants to perform heavy isometric planks and maximal 1-RM leg presses while holding his breath (Valsalva maneuver).
[DISCUSSION TASK]: Enforce the resting BP contraindication gate (>= 180/110 mmHg = hold exercise & refer) and redesign his future cleared resistance routine using rhythmic exhalation (exhale on concentric effort) and moderate loads (60-70% 1-RM, 12-15 reps).
STRUCTURAL_DELIMITER_BOUND_3 ###:
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Consulta de IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Pattern Diagnosis (Hemodynamic & Medication Audit): State your selected Case File (#265-06A, #265-06B, or #265-06C) and explain the interaction between your client's blood pressure medication (or missed dose), vascular mechanics, and Yuma environmental heat.
- Rule Application (PAGA 2018 & Blood Pressure Gates): Cite PAGA 2018 (2nd Ed.) aerobic + muscle-strengthening guidelines alongside clinical blood pressure safety gates (hold exercise at rest if $\text{SBP} \ge 180\text{ mmHg}$ or $\text{DBP} \ge 110\text{ mmHg}$; terminate exertion if $\text{SBP} > 220\text{ mmHg}$ or $\text{DBP} > 105\text{ mmHg}$; regulate intensity at Borg RPE $11\text{–}13$ on the 6–20 scale).
- Solve (Medication-Safe Modification & Bilingual Cue): Provide a concrete exercise modification (RPE Talk Test pacing, 10-minute active cool-down, or concentric exhalation to prevent the Valsalva maneuver) plus a 2-sentence bilingual client instruction card (EN/ES).
- Peer Reply (Due Sunday 11:59 PM MST): Reply to at least one classmate who selected a different medication track, comparing how beta-blockers, ACE inhibitors/diuretics, and calcium-channel blockers alter exercise monitoring.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Official 10/10 Discussion Post Exemplar

Pattern (#265-06A — Beta-Blocker HR Blunting): Metoprolol competitively blocks $eta_1$-adrenergic receptors on the SA node and myocardium, blunting Sr. Roberto's resting and exercise heart rate. Relying on an unadjusted smartwatch target of $135\text{ bpm}$ ($80\%\ \text{HR}_{\max}$) forces him into severe metabolic overexertion.

Rule (PAGA 2018 & Hemodynamic Gates): Under PAGA 2018 (2nd Ed.) and clinical hypertension standards, once resting blood pressure is verified below $180/110\text{ mmHg}$ ($136/84\text{ mmHg}$ cleared), clients on beta-blockers must regulate moderate aerobic intensity using the Borg 6–20 RPE Scale ($11\text{–}13$, "light to somewhat hard") and the Talk Test , while stopping if exercise BP exceeds $220/105\text{ mmHg}$.

Solve & Bilingual Cue: Disable the smartwatch heart-rate alarm and guide Roberto through 30 minutes of indoor track walking at Borg RPE $12/20$ (able to speak in full sentences without gasping), followed by a 10-minute gradual cool-down and rhythmic exhalation during machine resistance exercises. EN: "Because your beta-blocker medication intentionally keeps your pulse low to protect your heart, ignore your watch's heart-rate alarm and pace your walk at a 12 out of 20 effort where you can speak in full sentences comfortably. Exhale smoothly on every lift and cool down for 10 minutes so your blood pressure stays steady." ES: "Debido a que su medicamento betabloqueador mantiene su pulso bajo para proteger su corazón, ignore la alarma de frecuencia cardíaca de su reloj y camine a un esfuerzo de 12 sobre 20 donde pueda hablar en oraciones completas con comodidad. Exhale suavemente en cada levantamiento y enfríe durante 10 minutos para mantener estable su presión arterial."


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 06 (Mod 06 Discussion: High Blood Pressure & Medication Safety in Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Foro de Discusión del Módulo 06: Hipertensión Arterial y Seguridad Farmacológica en el Ejercicio

- Diagnóstico del Patrón (Jueves 11:59 PM MST): Identifique el riesgo hemodinámico y farmacológico de su caso (#265-06A betabloqueador, #265-06B vasodilatador/diurético e hipotensión post-ejercicio en el calor de Yuma, o #265-06C crisis hipertensiva $\ge 180/110\text{ mmHg}$ y maniobra de Valsalva).
- Aplicación de la Regla (PAGA 2018): Cite PAGA 2018, los límites de presión arterial ($<180/110\text{ mmHg}$ en reposo; $<220/105\text{ mmHg}$ en esfuerzo) y el uso de la escala Borg RPE $11\text{–}13$.
- Solución y Tarjeta Bilingüe: Proponga una adaptación segura (prueba del habla RPE, enfriamiento activo de 10 min o exhalación rítmica sin Valsalva) y una tarjeta bilingüe de 2 oraciones (EN/ES).
- Réplica a un Compañero (Domingo 11:59 PM MST): Responda a un compañero que haya auditado una clase de medicamento distinta.
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 06)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
