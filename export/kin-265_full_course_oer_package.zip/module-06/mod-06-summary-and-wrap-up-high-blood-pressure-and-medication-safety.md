## KIN-265: Mod 06 Summary And Wrap Up High Blood Pressure And Medication Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 06 Summary & Wrap-Up: High Blood Pressure & Medication Safety

Salud Cardiovascular y Metabólica, Cinética de la Glucosa y Normas Federales PAGA


### Step 1: Core Cardio-Metabolic Clinical Synthesis & Hemodynamic Gating

Congratulations on completing Module 06! You have successfully audited the complex hemodynamic and metabolic kinetics governing exercise prescription for individuals with cardiovascular disease, hypertension, and type 2 diabetes based on PAGA 2018 standards:

- Vascular Resistance & Beta-Blocker Heart Rate Blunting: Vascular stiffening increases systemic vascular resistance, while beta-blockers blunt adrenergic responses and mask hypoglycemia. Standard age-predicted heart rate formulas are invalidated, requiring intensity regulation via the Borg RPE scale (11 to 13).
- Glycemic Safety Windows & GLUT4 Translocation: Multi-component activity must maintain blood glucose within the 100 to 250 mg/dL safety window. During muscle contraction, GLUT4 glucose transporters translocate to the cell membrane independently of insulin, driving rapid drops in blood glucose if pre-exercise glucose is below 100 mg/dL.
- Hemodynamic Stop-Test Limits & Valsalva Prevention: Exercise must be terminated immediately if systolic blood pressure exceeds 220 mmHg or diastolic blood pressure exceeds 105 mmHg. Continuous rhythmic breathing during resistance sets prevents dangerous intracranial and intra-arterial pressure spikes.

### Step 2: Workplace Intelligence & AI Clinical Auditing

In hospital outpatient clinics, senior living wellness centers, and specialized athletic facilities, exercise physiologists leverage generative AI preceptors to audit client blood pressure logs, screen for glycemic risk factors, and structure personalized cardio-metabolic protocols.

- AI-Assisted Clinical Verification: Specialists prompt AI assistants to cross-examine patient profiles against federal PAGA 2018 guidelines, auditing for missed blood pressure stop limits or incorrect heart-rate intensity targets.
- Delimiter Security Protocol (###): Client biometric metrics (blood pressure readings, pre-exercise glucose levels, medication profiles) must remain enclosed inside triple hashes ( ### ) for data isolation during AI queries.
- Human-in-the-Loop Safeguard: All AI-generated cardio-metabolic prescriptions must be verified by a certified exercise specialist against PAGA 2018 standards to prevent hemodynamic instability and severe hypoglycemia.

### Step 3: Module 06 Self-Check Knowledge Verification

Select each item below to verify your understanding before progressing to Module 07:

English Response: Physical activity must be terminated immediately if Systolic Blood Pressure exceeds 220 mmHg (SBP > 220 mmHg) , Diastolic Blood Pressure exceeds 105 mmHg (DBP > 105 mmHg) , or if SBP experiences an exertional drop of 10 mmHg or more below baseline resting values.

Respuesta en Español: El ejercicio debe detenerse de inmediato si la presión sistólica supera los 220 mmHg (PAS > 220 mmHg) , la diastólica supera los 105 mmHg (PAD > 105 mmHg) , o si la PAS cae 10 mmHg o más respecto al reposo.

English Response: Beta-blockers block adrenergic receptors and blunt heart rate responses by 20 to 30 bpm, invalidating age-predicted heart rate formulas. Therefore, intensity must be regulated using the Borg 6 to 20 RPE Scale (targeting 11 to 13) .

Respuesta en Español: Los betabloqueadores bloquean los receptores adrenérgicos y reducen la respuesta cardíaca, invalidando las fórmulas de frecuencia cardíaca. Por ello, la intensidad debe regularse mediante la Escala Borg 6 a 20 de RPE (meta 11 a 13) .

English Response: A blood glucose of 88 mg/dL is below the safe pre-exercise threshold (100 mg/dL). The client must ingest 15 to 30 grams of rapidly absorbed simple carbohydrate and rest. Retest blood glucose in 15 to 20 minutes before beginning exertion.

Respuesta en Español: Al estar por debajo de 100 mg/dL, el cliente debe ingerir 15 a 30 gramos de carbohidratos de absorción rápida y esperar 15 a 20 minutos hasta que la glucemia sea igual o superior a 100 mg/dL antes de entrenar.

English Response: Continuous breathing (exhaling on exertion) eliminates the Valsalva maneuver, preventing dangerous intra-thoracic and intra-arterial pressure spikes that threaten hypertensive clients.

Respuesta en Español: La respiración continua (exhalar en el esfuerzo) elimina la maniobra de Valsalva, previniendo picos peligrosos de presión intraarterial e intratorácica en clientes hipertensos.

English Response: PEH is the acute, sustained reduction in blood pressure (5 to 10 mmHg systolic drop) following moderate aerobic exercise lasting up to 24 hours, serving as a non-pharmacological blood pressure therapy.

Respuesta en Español: La hipotensión post-ejercicio es la reducción aguda y sostenida de la presión arterial (caída sistólica de 5 a 10 mmHg) tras el ejercicio aeróbico que dura hasta 24 horas, actuando como terapia antihipertensiva.

English Response: Skeletal muscle contraction activates AMPK signaling and calcium-calmodulin dependent pathways, directly translocating GLUT4 glucose transporters to the cell membrane independently of insulin.

Respuesta en Español: La contracción del músculo esquelético activa la señalización AMPK y vías dependientes de calcio, translocando transportadores GLUT4 a la membrana celular sin requerir insulina.

English Response: Enclosing clinical metrics within triple-hash delimiters (`###`) isolates client data securely, prevents prompt drift, and ensures rigorous compliance with PAGA 2018 standards.

Respuesta en Español: Encerrar las métricas clínicas entre delimitadores de tres numerales (`###`) aísla los datos del cliente de forma segura, evita la deriva de las instrucciones y asegura el cumplimiento de las normas PAGA 2018.

English Response: PAGA 2018 recommends accumulating 150 to 300 minutes of moderate-intensity aerobic activity weekly, ensuring no more than two consecutive days pass without physical activity.

Respuesta en Español: PAGA 2018 recomienda acumular de 150 a 300 minutos semanales de actividad aeróbica de intensidad moderada, sin dejar pasar más de dos días consecutivos sin actividad.

English Response: Antihypertensive medications (like beta-blockers and diuretics) impair normal thermoregulation, reduce cutaneous blood flow, and accelerate dehydration, compounding cardiovascular strain during high heat.

Respuesta en Español: Los medicamentos antihipertensivos alteran la termorregulación normal, reducen el flujo sanguíneo cutáneo y aceleran la deshidratación, agravando el esfuerzo cardiovascular con calor extremo.


### AI Simulation Workspace & Cardio-Metabolic Simulation

Copy the prompt below into Gemini to generate a comprehensive clinical review matrix connecting hemodynamic limits, glycemic windows, and PAGA 2018 standards:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: KIN-265 Module 06 Cardio-Metabolic Synthesis ###:
Role: Clinical Exercise Physiologist and Cardiac Rehabilitation Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chapter 7 Active Adults with Chronic Conditions.

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Cardio-Metabolic Pathophysiological Mechanisms (Endothelial dysfunction, Beta-blocker chronotropic blunting, GLUT4 insulin resistance).
   Key Point: Clinical Monitoring & Contraindications (Failure of %HRmax formulas, SBP > 220 / DBP > 105 stop limits, Pre-exercise blood glucose < 100 mg/dL).
   Key Point: Evidence-Based Exercise Modifications (Borg RPE 11-13 target, 15-30g carbohydrate pre-loads, Continuous rhythmic breathing to prevent Valsalva).
Step 2: Detail pre-exercise glycemic decision matrix actions and explain how indoor climate-controlled facilities prevent heat strain in Yuma County.
Step 3: Keep all formulas in plain text and wrap all data inputs within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 07 — Exercise Prescription for Metabolic Conditions (Obesity & Weight-Neutral Care)

In plain English, next week in Module 07: Exercise Prescription for Metabolic Conditions you will learn how to design joint-friendly, stigma-free movement programs for clients living with obesity, insulin resistance, and dyslipidemia. Why it matters: high-impact jumping on hot concrete hurts knees and discourages adherence—low-impact modalities (aquatics, recumbent cycling, incline walking) paired with resistance training improve insulin sensitivity even before a single pound is lost.

- Pattern (Context): Assessing orthopedic joint loading, thermoregulatory heat retention in higher body mass, and glycemic/lipid profiles.
- Rule (Constraint): Applying PAGA 2018 progressive volume targets (working toward 150–300+ min/week moderate low-impact aerobic + 2 days/week resistance training).
- Solve (Intervention): Completing Mod 07 Discussion: Joint-Friendly Metabolic Training and Mod 07 Lab: Metabolic Condition FITT-VP Plan .

### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 06 (Mod 06 Summary & Wrap-Up: High Blood Pressure & Medication Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 06: Resumen y Cierre del Módulo

Salud Cardiovascular y Metabólica, Cinética de la Glucosa y Normas Federales PAGA


### Step 1: Síntesis Clínica Cardio-Metabólica y Regulación Hemodinámica

¡Felicitaciones por completar el Módulo 06! Ha auditado con éxito las cinéticas hemodinámicas y metabólicas que rigen la prescripción de ejercicio para personas con enfermedad cardiovascular, hipertensión y diabetes tipo 2 según las normas de PAGA 2018:

- Resistencia Vascular y Atenuación Cardíaca por Betabloqueadores: La rigidez arterial aumenta la resistencia vascular, mientras que los betabloqueadores atenúan la respuesta cardíaca. Las fórmulas de frecuencia cardíaca quedan invalidadas, requiriendo regular la intensidad mediante la escala Borg RPE (11 a 13).
- Ventanas de Seguridad Glucémica y Translocación de GLUT4: La actividad física debe mantener la glucemia dentro del rango seguro de 100 a 250 mg/dL . La contracción muscular estimula la translocación de transportadores GLUT4 independientemente de la insulina, provocando descensos rápidos si la glucosa inicial es menor a 100 mg/dL.
- Límites Hemodinámicos y Prevención de Valsalva: El ejercicio debe suspenderse inmediatamente si la presión sistólica supera 220 mmHg o la diastólica supera 105 mmHg. La respiración rítmica continua previene picos peligrosos de presión.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría Clínica con IA

En clínicas ambulatorias, centros de bienestar y complejos deportivos, los especialistas utilizan IA generativa para auditar registros de presión arterial, evaluar riesgos glucémicos y estructurar protocolos cardiorrespiratorios.

- Verificación Clínica Asistida por IA: Contraste de perfiles de pacientes frente a las directrices federales PAGA 2018 para detectar errores en límites de presión arterial o metas de intensidad.
- Protocolo con Delimitadores (###): Las métricas clínicas (lecturas de presión arterial, glucemia previa, perfiles de medicación) deben aislarse entre tres numerales ( ### ) para asegurar el aislamiento de datos.
- Verificación Humana: Todas las prescripciones generadas por IA deben ser verificadas por un especialista certificado para prevenir inestabilidad hemodinámica e hipoglucemia severa.

### Step 3: Autoevaluación del Módulo 06

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 07:


### Caja de Herramientas de IA • Síntesis Cardio-Metabólica

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: KIN-265 Sintesis Modulo 06 ###:
Rol: Fisiologo del Ejercicio Clinico y Especialista en Rehabilitacion Cardiaca en la voz del Narrador.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Capitulo 7 Adultos con Condiciones Cronicas.

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Mecanismos Fisiopatologicos Cardio-Metabolicos (Disfuncion endotelial, Atenuacion por betabloqueadores, Resistencia a la insulina GLUT4).
   Key Point: Monitoreo Clinico y Contraindicaciones (Invalidez de formulas de FC, Limites de parada SBP > 220 / DBP > 105, Glucemia previa < 100 mg/dL).
   Key Point: Modificaciones de Prescripcion Basadas en Evidencia (Meta Borg RPE 11-13, Suplementacion de 15-30g de carbohidratos, Respiracion rítmica continua para evitar Valsalva).
Step 2: Detallar las acciones de la matriz de decision glucemica y explicar como las instalaciones climatizadas previenen el estres termico en Yuma.
Step 3: Mantener todas las formulas en texto plano y los datos entre delimitadores (###).
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 07 — Ejercicio para Condiciones Metabólicas

En palabras sencillas (Contexto Norteño): cuando un cliente tiene obesidad y resistencia a la insulina, ponerlo a brincar en el pavimento caliente le lastima las rodillas y lo aleja del ejercicio. La próxima semana aprenderás a diseñar rutinas de bajo impacto articular (bicicleta reclinada, alberca, caminata controlada y pesas seguras) bajo PAGA 2018 que mejoran la salud metabólica desde la primera semana.

- Patrón (Contexto): Evaluar la carga en rodillas/espalda, la retención de calor corporal y la sensibilidad a la insulina.
- Regla (Restricción): Aplicar la progresión de PAGA 2018 hacia 150–300 min/semana de ejercicio aeróbico de bajo impacto más 2 días/semana de fuerza.
- Solución (Intervención): Completar el Foro del Mód 07 (Joint-Friendly Metabolic Training) y el Laboratorio del Mód 07 (Metabolic Condition FITT-VP Plan) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 06 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 06:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 06)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
