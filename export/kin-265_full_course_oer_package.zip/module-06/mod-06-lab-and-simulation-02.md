## KIN-265: Mod 06 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 06) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Lab & Simulation: Hypertension & Heart Health Exercise Audit

Laboratorio del Módulo 06: Prescripción Cardio-Metabólica, Regulación Hemodinámica y Simulación

- Resting Blood Pressure Contraindication Gate (SBP ≥180 or DBP ≥110 mmHg): If resting systolic BP is ≥180 mmHg or diastolic BP is ≥110 mmHg, do not initiate exercise; refer the client for medical stabilization first. En palabras sencillas: Si antes de empezar la presión en reposo está en 180/110 mmHg o más, no se inicia el ejercicio y se canaliza al médico.
- Beta-Blocker Heart Rate Attenuation (Use Borg RPE 11–13 / Talk Test): Beta-adrenergic blockers (e.g., metoprolol, atenolol) blunt maximal and submaximal heart rate; age-predicted HR formulas are invalid, so use RPE 11–13 and the Talk Test. En palabras sencillas: Los betabloqueadores frenan las pulsaciones; por eso en estos pacientes no usamos fórmulas de pulso sino la Prueba del Habla y el esfuerzo percibido (RPE 11–13).
- Valsalva Avoidance & Antihypertensive Orthostatic Precaution: Exhale on every lifting effort to prevent dangerous blood-pressure spikes, and transition slowly from floor/seated positions to standing to prevent orthostatic dizziness. En palabras sencillas: Soltar siempre el aire al hacer fuerza y levantarse despacio de la silla o piso para evitar mareos por los medicamentos de la presión.

### Hemodynamic Stability, Glycemic Windows, & PAGA Federal Mandates

In this laboratory assignment, you will construct and audit a tailored exercise prescription for a client presenting with chronic cardiovascular or metabolic pathologies (Hypertension, Type 2 Diabetes, or Coronary Artery Disease). Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will evaluate vascular resistance and GLUT4 translocation kinetics, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety rules, and execute an AI-driven simulation using Google Gemini.

En esta práctica de laboratorio, diseñará y auditará una prescripción de ejercicio adaptada para un cliente con patologías cardiovasculares o metabólicas, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando la resistencia vascular y la glucemia.

- KIN-265.6.3.AY26-27: Prescribe multi-component aerobic and resistance exercise based on hemodynamic safety limits (SBP/DBP stop-tests) and glycemic thresholds (100–250 mg/dL). Prescribir ejercicio aeróbico y de fuerza multicomponente dentro de los límites hemodinámicos seguros y de los umbrales de glucosa.
- KIN-265.6.4.AY26-27: Audit clinical antihypertensive/beta-blocker protocols, Valsalva avoidance, and environmental heat stress mitigations for desert clients in Yuma County. Auditar protocolos clínicos de antihipertensivos y betabloqueadores, prevención de la maniobra de Valsalva y mitigación del estrés térmico ambiental.
- Module Window / Ventana del Módulo: Opens Tuesday, September 22, 2026, at 12:00 AM MST Abre el martes, 22 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, September 28, 2026, at 11:59 PM MST Lunes, 28 de septiembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones clínicas

### Lab Objectives

Objetivos del Laboratorio

- Audit the pathophysiological mechanisms of endothelial dysfunction, blunted heart rate response from beta-blockade, extreme Valsalva-induced pressure spikes, and exercise-induced hypoglycemia. Auditar los mecanismos fisiopatológicos de la disfunción endotelial, de la frecuencia cardíaca atenuada por los betabloqueadores, de los picos de Valsalva y de la hipoglucemia por ejercicio.
- Apply federal PAGA 2018 (2nd Ed.) mandates to establish blood pressure stop-test limits (SBP > 220 mmHg, DBP > 105 mmHg), glycemic target ranges (100–250 mg/dL), and 15–30g fast-acting carbohydrate rules for glucose < 100 mg/dL. Aplicar las normas de la PAGA 2018 para establecer los límites de presión arterial (PAS > 220 mmHg, PAD > 105 mmHg) y el rango seguro de glucemia (100–250 mg/dL).
- Formulate a 4-week, multi-component prescription that avoids Valsalva maneuvers and regulates intensity using Borg RPE (11–14), paired with bilingual client instruction cards in English and Spanish. Formular una prescripción de 4 semanas, evitando maniobras de Valsalva, regulando la intensidad con Borg RPE (11–14) y utilizando tarjetas educativas bilingües.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-06

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos Clínicos

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Outpatient cardiac/metabolic rehab; managing Stage 2 Hypertension and Type 2 Diabetes under beta-blocker therapy with pre-exercise glucose at 94 mg/dL.

Focus: Community walking group design for agricultural workers in Yuma County with Type 2 Diabetes experiencing exertional dizziness and heat sensitivity.

Focus: Masters resistance training for clients with essential hypertension; mitigating Valsalva-induced blood pressure spikes during heavy loads.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete clinical audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline cardio-metabolic profile.
- Part 1: Pattern Recognition: Identify specific clinical risks (blunted heart rate, Valsalva pressure spikes, or pre-exercise blood glucose < 100 mg/dL).
- Part 2: Rule Application: Cite PAGA 2018 standards for blood pressure limits (SBP > 220 / DBP > 105), glycemic safety windows (100–250 mg/dL), and RPE intensity gating.
- Part 3: Solving the Gap: Detail a 4-week multi-component exercise plan (carbohydrate pre-loads, breathing cues, and Yuma climate adaptations) with a 2-sentence bilingual client card.
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying your pre-exercise glycemic/BP safety gates, Borg RPE $11\text{–}13$ pacing on beta-blockers, and anti-Valsalva breathing cues.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient M.R. presents with two key clinical risks: beta-blocker therapy (Metoprolol) and pre-exercise blood glucose below the safe window (94 mg/dL). Metoprolol blunts sympathetic chronotropic response, holding resting heart rate at 56 bpm and masking adrenergic signs of acute hypoglycemia (tachycardia, tremors). Because muscle contraction stimulates GLUT4 glucose transporter translocation independently of Insulin during aerobic exercise, initiating exertion at 94 mg/dL will rapidly induce acute hypoglycemia.

Part 2: Rule Application (SSoT PAGA 2018 2nd Ed Standards): Under PAGA 2018 (2nd Ed.), chronic condition mandates that clients with diabetes must maintain blood glucose between 100 and 250 mg/dL before exertion; levels under 100 mg/dL require 15–30g of fast-acting carbohydrates. Because beta-blockade invalidates heart rate formulas, exercise intensity must be gated using Borg Rating of Perceived Exertion (target RPE 11–13, "Light" to "Somewhat Hard" ). Hemodynamic safety rules require session termination if SBP > 220 mmHg or DBP > 105 mmHg.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): Cardio-Metabolic Rehabilitation Protocol (3 Days/Week): Key Point — Carbohydrate Pre-Load: Administer 15g fast-acting carbohydrates (4 oz juice) and re-check blood glucose after 15 minutes to confirm levels exceed 100 mg/dL before walking. Key Point — Aerobic Conditioning: Treadmill interval walking at 2.0 mph for 20 minutes (3 min walk / 1 min rest) maintaining Borg RPE 11–13. Key Point — Resistance Training: Low-intensity machine seated chest press and leg extension (2 sets x 12 reps at RPE 12) with continuous exhalation during concentric effort to prevent Valsalva pressure spikes. Key Point — Safety Threshold: Monitor blood pressure every 5 minutes. Pause exertion if SBP exceeds 220 mmHg or DBP exceeds 105 mmHg.

EN: "Because your blood pressure medication masks low blood sugar symptoms, always check your glucose before starting and have a 15-gram carbohydrate snack if you are below 100 mg/dL. Exhale continuously during every lifting exertion to keep your blood pressure stable."

ES: "Debido a que su medicamento para la presión arterial oculta los síntomas de un nivel bajo de azúcar, siempre mida su glucosa antes de iniciar y consuma 15 gramos de carbohidratos si está por debajo de 100 mg/dL. Exhale continuamente durante cada esfuerzo de fuerza para mantener estable su presión arterial."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI exercise plan fails to recognize that metoprolol blunts both heart rate and the sympathetic warning signs of hypoglycemia (tremor and tachycardia) when pre-exercise blood glucose is 94 mg/dL. Starting aerobic exercise below 100 mg/dL triggers insulin-independent GLUT4 glucose uptake and acute hypoglycemia. As the human clinician, I enforce the 100–250 mg/dL glycemic window with a 15-gram fast-acting carbohydrate pre-load, replace heart-rate formulas with Borg RPE 11–13 and the Talk Test, and mandate continuous exhalation during resistance reps so SBP never exceeds 220 mmHg. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M06_CardioMetabolic_Prescription_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 06 (Mod 06 Lab: Hypertension & Heart Health Exercise Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 06 Práctica de Lab y Simulación: Prescripción Cardio-Metabólica y Simulación

Regulación hemodinámica, ventanas glucémicas y normas PAGA


### Estabilidad hemodinámica, ventanas glucémicas y normas PAGA

En esta práctica de laboratorio, diseñará y auditará una prescripción de ejercicio adaptada para un cliente con patologías cardiovasculares o metabólicas. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará la resistencia vascular, calculará la respuesta a la glucosa, aplicará las normas de seguridad de PAGA 2018 (2.ª edición) y ejecutará una simulación con Google Gemini.


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Comunitaria / Ruta 3 Deportiva) e incluya sus iniciales.


#### Parte 1: Reconocimiento de Patrones

Identifique el riesgo clínico de su cliente (bloqueo de la frecuencia cardíaca por betabloqueadores, picos de la presión arterial por Valsalva o glucemia menor de 100 mg/dL).


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Aplique los estándares de la PAGA 2018 para establecer límites de presión arterial (PAS > 220 / PAD > 105), rango de glucosa (100–250 mg/dL) e intensidad según Borg RPE.


#### Parte 3: Resolución de la Brecha

Detalle un plan de actividad física de 4 semanas (carbohidratos previos, técnica respiratoria y adaptación al clima), junto con una tarjeta de instrucciones bilingüe.


#### Parte 4: Verificación Activa (Mínimo 150 Palabras en su Propia Voz Humana)

Escriba de mínimo 150 palabras en su propia voz humana clínica justificando sus filtros de seguridad de presión arterial y glucosa, el uso de Borg RPE 11–13 con betabloqueadores y la respiración continua sin Valsalva.


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: La paciente M.R. recibe tratamiento con betabloqueadores (metoprolol) y, previo al ejercicio, presenta glucemia por debajo del rango seguro (94 mg/dL). El metoprolol atenúa la respuesta de la FC (56 bpm en reposo), lo que puede ocultar los síntomas de hipoglucemia. Dado que la contracción muscular estimula la translocación de GLUT4 independientemente de la insulina, iniciar el ejercicio con 94 mg/dL provocará una hipoglucemia aguda de forma rápida.

Parte 2: Aplicación de Reglas (PAGA 2018): Según la PAGA 2018 (2.ª edición), los clientes con diabetes deben mantener la glucemia entre 100 y 250 mg/dL antes de ejercitarse; niveles inferiores a 100 mg/dL requieren 15–30 g de carbohidratos. La intensidad debe regularse mediante Borg RPE (meta RPE 11–13 ) y el ejercicio debe detenerse si la PAS > 220 mmHg o la PAD > 105 mmHg.

Parte 3: Resolución de la Brecha: Protocolo de rehabilitación cardiometabólica: administrar 15 g de carbohidratos de acción rápida (jugo) y reevaluar la glucemia a los 15 min. Caminata en caminadora por intervalos (2.0 mph, RPE 11–13) durante 20 min y ejercicios de fuerza livianos (2 series x 12 repeticiones) con exhalación continua durante el esfuerzo. Tarjeta Bilingüe: "Debido a que su medicamento para la presión arterial oculta los síntomas de un nivel bajo de azúcar, siempre mida su glucosa antes de iniciar y consuma 15 gramos de carbohidratos si está por debajo de 100 mg/dL. Exhale continuamente durante cada esfuerzo de fuerza para mantener estable su presión arterial."

Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, un plan de IA sin supervisión no detecta que el metoprolol atenúa tanto el pulso como los síntomas de alerta de hipoglucemia cuando la glucosa inicial está en 94 mg/dL. Como especialista humano, aplico primero 15 g de carbohidratos rápidos para superar el umbral seguro de 100 mg/dL, regulo la intensidad mediante Borg RPE 11–13 en lugar del pulso y exijo exhalación continua en cada repetición de fuerza para evitar la maniobra de Valsalva."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M06_CardioMetabolic_Prescription_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 06)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
