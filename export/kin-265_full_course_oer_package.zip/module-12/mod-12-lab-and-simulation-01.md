## KIN-265: Mod 12 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 12) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 12 Coaching Sprint Simulation: Modifying Exercises for Pain-Free Joints

Sesión de Coaching del Módulo 12: Salud Musculoesquelética y Seguridad Articular

- The Two-Hour Joint Pain Rule (Osteoarthritis & Rheumatoid Arthritis): If joint pain is worse 2 hours after exercising than it was before starting, the session volume or impact was too high and must be scaled back at the next session. En palabras sencillas: La Regla de las Dos Horas: si a las 2 horas de terminar duele más la articulación que antes de empezar, bajamos la carga o duración en la siguiente sesión.
- Acute Inflammatory Flare Gate (Gentle ROM Only): During an acute rheumatoid or osteoarthritic flare (hot, red, swollen joint), avoid heavy resistance or high-impact loading and perform only gentle, pain-free range-of-motion movements. En palabras sencillas: Cuando una articulación amanece caliente, inflamada o en brote agudo, no se le mete peso; solo se mueve suave sin dolor.
- Osteoporosis Spine-Sparing Mechanics & Fall Prevention: Replacing spinal flexion/twisting with neutral-spine hip hinges, posture extensors, weight-bearing walking, and daily balance training. En palabras sencillas: Proteger la columna evitando encorvarse o girar brusco con peso, fortaleciendo espalda, cadera y equilibrio para prevenir caídas.
- KIN-265.12.1.AY26-27: Prescribe safe low-impact and weight-bearing exercise intensity for clients with arthritis or osteoporosis across diverse career tracks. Prescribir intensidad de ejercicio seguro de bajo impacto y con peso para clientes con artritis u osteoporosis en diversas rutas profesionales.
- KIN-265.12.2.AY26-27: Audit clinical pain scale limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de la escala de dolor y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering Joint-Sparing Rules & Bone Loading Protocols

How can fitness professionals safely monitor exercise intensity when a client is managing osteoarthritis or osteoporosis? Because standard metrics do not capture joint stress, exercise specialists use pain monitoring scales (e.g., keeping joint pain below 3/10) and Wolfe's Law bone-loading parameters. Following strict PAGA 2018 clinical guidelines, trainers protect arthritic joints and prevent vertebral compression fractures. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master musculoskeletal safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente padece osteoartritis u osteoporosis? Usando escalas de dolor y parámetros de carga ósea de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría musculoesquelética!

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Joint-Safe Multicomponent & Osteoarthritis ROM Auditor (/simulators/fall-risk-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate >=3 days/week balance, >=2 days/week low-load joint-friendly strength, and 150 min/week low-impact aerobic activity while enforcing the 2-Hour Joint Pain Rule (PAGA 2018 Ch. 5 & 6). Copy your VERIFIED simulator receipt or slider values into the submission template below • Paired Biomechanical Joint-Load & Pain-Free ROM route: /simulators/joint-load-auditor .

Open Joint-Safe Multicomponent & Osteoarthritis ROM Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale)

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/fall-risk-auditor y "PAGA"): Calibre >=3 días/semana de equilibrio, >=2 días/semana de fuerza amigable con las articulaciones y 150 min/semana aeróbicos de bajo impacto respetando la Regla del Dolor de 2 Horas (PAGA 2018 Cap. 5 y 6). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient clinical rehabilitation client with bilateral knee osteoarthritis managing joint pain and stiffness; establishing low-impact aquatic or cycling progression.

Scenario: Senior community center participant with osteoporosis and mild balance impairment; formulating a safe weight-bearing walking and fall-prevention routine.

Scenario: Military veteran and heavy-labor instructor with cumulative lumbar spine strain and degenerative disc disease; designing an ergonomic core stability and unloading framework.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Brenda, Harold, or Sergeant Vance).
- Musculoskeletal Analysis: Explain the key joint limitation or bone loading consideration for your selected client.
- My Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment utilizing the Safety Auditor protocol.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 12 Coaching Sprint • Track 1 (Brenda)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Brenda (Age 64).
- Musculoskeletal Analysis: Brenda has bilateral knee osteoarthritis causing joint pain and stiffness. Because high-impact loading increases joint shear stress, we use low-impact aquatic or stationary cycling exercise and keep joint pain below 3/10.
- My Safety Audit for Brenda: "Monitor Brenda's joint discomfort using the pain scale, ensuring pain does not exceed 3/10 during exercise, and modify range of motion or reduce resistance immediately if sharp pain occurs per PAGA 2018 guidelines."
- "Monitor Brenda's joint discomfort using the pain scale, ensuring pain does not exceed 3/10 during exercise, and modify range of motion or reduce resistance immediately if sharp pain occurs per PAGA 2018 guidelines."
- My Memorable Coaching Takeaway: EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!" "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!"
- "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M12_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 12 (Mod 12 Coaching Sprint: Modifying Exercises for Pain-Free Joints)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 12 Simulación de Coaching: Salud Musculoesquelética y Seguridad Articular

Evaluación Rápida y Auditoría de Seguridad Musculoesquelética


### Su Logro Semanal: Dominando las Reglas Articulares y la Carga Ósea

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar escalas de dolor y parámetros de carga ósea en pacientes con artritis u osteoporosis. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente de rehabilitación clínica con osteoartritis bilateral de rodilla y dolor articular; establecer una progresión acuática o de ciclismo de bajo impacto.

Escenario: Participante senior con osteoporosis y equilibrio levemente alterado; formular una rutina segura de caminata con peso y prevención de caídas.

Escenario: Veterano e instructor con tensión lumbar crónica y discopatía degenerativa; diseñar estabilidad central y marco ergonómico.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Brenda, Harold o Sergeant Vance).
- Análisis Musculoesquelético: Explique la consideración clave articular u ósea para su cliente.
- Mi Auditoría de Seguridad: Escriba 1 parámetro de seguridad claro o ajuste de prescripción usando la escala de dolor.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 12, Sesión de Coaching • Ruta 1 (Brenda)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Brenda (64 años).
- Análisis Musculoesquelético: Brenda tiene osteoartritis bilateral de rodilla. Como el impacto elevado aumenta la tensión articular, usamos ejercicio acuático o bicicleta estática y mantenemos el dolor por debajo de 3/10.
- Mi Auditoría de Seguridad para Brenda: "Monitorear la incomodidad articular de Brenda usando la escala de dolor, asegurando que no exceda 3/10 durante el ejercicio, y modificar el rango de movimiento si ocurre dolor agudo según PAGA 2018."
- "Monitorear la incomodidad articular de Brenda usando la escala de dolor, asegurando que no exceda 3/10 durante el ejercicio, y modificar el rango de movimiento si ocurre dolor agudo según PAGA 2018."
- Mi Frase Inolvidable de Coaching: EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!" "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!"
- "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M12_Quiz_Sprint.pdf
KIN-265 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 12)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 12)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
