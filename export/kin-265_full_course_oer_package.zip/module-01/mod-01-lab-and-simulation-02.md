## KIN-265: Mod 01 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 01) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 01 Lab & Simulation: Heart Recovery & Safe Exercise Limits Audit

Laboratorio del Módulo 01: Rehabilitación Cardíaca Ambulatoria y Programación del Umbral Isquémico

- Rate-Pressure Product (RPP = Heart Rate × Systolic Blood Pressure): Clinical index of myocardial oxygen demand; keeping HR and SBP controlled prevents cardiac ischemia and angina during post-cardiac rehab conditioning. En palabras sencillas: Indicador de cuánto trabajo y oxígeno exige el músculo del corazón; mantener controlados el pulso y la presión evita dolor de pecho (angina).
- Extended Warm-Up & Cool-Down (10–15 Minutes Each): Cardiac patients require a 10–15 minute gradual warm-up to open coronary arteries and a 10–15 minute cool-down to prevent post-exercise hypotension and arrhythmias. En palabras sencillas: En pacientes del corazón dedicamos de 10 a 15 minutos a calentar suave y otros 10 a 15 minutos a enfriar para evitar mareos o arritmias.
- Angina & Hemodynamic Termination Criteria: Immediate exercise stop triggers: chest/jaw/arm discomfort, drop in systolic BP >10 mmHg with increasing workload, dizziness, or unusual shortness of breath. En palabras sencillas: Señales para detener el ejercicio de inmediato: opresión en el pecho o brazo, mareo, falta de aire anormal o caída de la presión arterial.
Welcome to your first practical laboratory assignment in Clinical Exercise Programming. This week, we construct an evidence-based clinical exercise prescription for a post-surgical cardiac patient. We will use our core academic Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) supported by clinical cardiac rehabilitation principles.

Bienvenido a su primera práctica de laboratorio de Programación de Ejercicio Clínico. Esta semana construiremos una prescripción clínica de ejercicio para un paciente cardíaco posquirúrgico utilizando nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) .

- KIN-265.1.1.AY26-27: Audit primary chronic condition prevalences and clinical cardiac disease presentations using PAGA 2018 (2nd Ed) as the Single Source of Truth. Auditar la prevalencia de condiciones crónicas y cuadros cardíacos utilizando PAGA 2018 como única fuente de verdad.
- KIN-265.1.2.AY26-27: Apply the Clinical Framing Protocol (Pattern / Rule / Solve) to differentiate clinical ischemic contraindications from safe, light-to-moderate physical activity modifications. Aplicar el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para diferenciar las contraindicaciones isquémicas de las modificaciones seguras de la actividad física.
- Module Window / Ventana del Módulo: Opens Tuesday, August 18, 2026, at 12:00 AM MST Abre el martes, 18 de agosto de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, August 24, 2026, at 11:59 PM MST Lunes, 24 de agosto de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación: Weekly Labs & Clinical Simulations Benchmark (10 Points) Ponderación para laboratorios semanales y simulaciones clínicas (10 Puntos)

### Lab Objectives / Objetivos del Laboratorio

Competencias clave del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Deconstruct clinical profiles of post-CABG and cardiac intervention patients to establish safe cardiorespiratory envelopes. Desglosar los perfiles clínicos de pacientes posquirúrgicos cardíacos para establecer límites seguros.
- Apply clinical cardiac rehabilitation guidelines to calculate safe heart rate limits based on documented ischemic thresholds. Aplicar pautas de rehabilitación cardíaca para calcular límites seguros basados en umbrales isquémicos.
- Formulate clinical progression programs that balance physical adaptation with cardiovascular and sternal precautions in Yuma's climate. Formular programas de progresión que equilibren la adaptación física con precauciones esternales en el clima de Yuma.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-01 / Fase 1: Selección de Escenario de Simulación Clínica

Elija su Ruta y Revise los Datos Clínicos

Choose ONE of the three career-aligned clinical tracks below before invoking Gemini AI:

Focus: Post-CABG outpatient cardiac rehab patient (L.P., 64) with documented ischemic threshold and sternal healing restrictions.


```text
###
[TRACK / RUTA]: Track 1 - Clinical Rehabilitation Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: L.P.
[AGE / EDAD]: 64 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma County, AZ
[CLINICAL PROFILE / PERFIL CLÍNICO]: Recovering from Coronary Artery Bypass Graft (CABG) surgery (8 weeks post-op). Cleared for Phase III Outpatient Cardiac Rehab.
[RESTING METRICS / MÉTRICAS EN REPOSO]: Resting HR: 72 bpm | Resting BP: 132/84 mmHg (Stage 1 Hypertension)
[STRESS TEST DATA / PRUEBA DE ESFUERZO]: Max HR on test: 128 bpm | Clinical Ischemic Threshold: 115 bpm (ST-segment depression & dyspnea noted).
[ACTIVITY & GOALS / ACTIVIDAD Y OBJETIVOS]: Performs 5-10 min light household walking. Goal: Safely rebuild endurance to resume outdoor yard work and dog walking.
[REFERRAL NETWORK / RED DE REFERENCIA]: Matador Clinical Partners (MCP) Cardiac Rehabilitation Unit.
###
```

Focus: Post-percutaneous coronary intervention (stent placement) community member (R.M., 58) managing hypertension and heat stress in Yuma County.


```text
###
[TRACK / RUTA]: Track 2 - Community & Public Health Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: R.M.
[AGE / EDAD]: 58 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma County, AZ
[CLINICAL PROFILE / PERFIL CLÍNICO]: Post-PCI with 2 drug-eluting stents (12 weeks post-procedure). Managed for Stage 2 Hypertension.
[RESTING METRICS / MÉTRICAS EN REPOSO]: Resting HR: 76 bpm | Resting BP: 138/88 mmHg
[STRESS TEST DATA / PRUEBA DE ESFUERZO]: Max HR on test: 135 bpm | Clinical Ischemic Threshold: 120 bpm (Anginal equivalent symptoms noted).
[ACTIVITY & GOALS / ACTIVIDAD Y OBJETIVOS]: Sedentary. Goal: Safely participate in community walking groups in air-conditioned municipal facilities during 105°F summer heat.
[REFERRAL NETWORK / RED DE REFERENCIA]: Yuma County Public Health Services District & Matador Clinical Partners (MCP) Outpatient Wellness.
###
```

Focus: Master's endurance athlete (G.T., 61) returning to structured training following myocardial infarction and revascularization.


```text
###
[TRACK / RUTA]: Track 3 - Sports & Athletic Performance Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: G.T.
[AGE / EDAD]: 61 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma, AZ
[CLINICAL PROFILE / PERFIL CLÍNICO]: Master's cyclist post-MI with single-vessel stenting (16 weeks post-event). Cleared for Phase III supervised conditioning.
[RESTING METRICS / MÉTRICAS EN REPOSO]: Resting HR: 64 bpm | Resting BP: 126/80 mmHg
[STRESS TEST DATA / PRUEBA DE ESFUERZO]: Max HR on test: 142 bpm | Clinical Ischemic Threshold: 130 bpm (ST-segment depression at 130 bpm).
[ACTIVITY & GOALS / ACTIVIDAD Y OBJETIVOS]: Former 100 mile/week cyclist. Goal: Rebuild aerobic power on a stationary ergometer without crossing the ischemic threshold.
[REFERRAL NETWORK / RED DE REFERENCIA]: AWC High-Performance Lab & Matador Clinical Partners (MCP) Cardiac Rehab.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


```text
Safety Auditor Protocol: KIN-265 Phase III Cardiac Tool Box ###:
Role: Clinical Exercise Physiologist and Cardiac Rehabilitation Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chronic Health Conditions.

Instructions:
Step 1: Review the clinical client profile wrapped in triple-hashes (###) below.
Step 2: PATTERN: Identify the client's physical activity classification and critical clinical boundaries (resting metrics, peak stress test HR, and documented ischemic threshold).
Step 3: RULE: Calculate their maximum safe target heart rate (at least 10 bpm below their documented ischemic threshold) and establish their training heart rate range using the Heart Rate Reserve (HRR) method at a light-to-moderate intensity (40% to 60% HRR).
Step 4: SOLVE: Design a safe weekly progression routine suited for Yuma's indoor, climate-controlled environments and relevant referral network guidelines, including specific post-surgical or sternal precautions (<10 lbs loading).
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Template

Plantilla de Entrega en el Cuadro de Texto de Canvas

Copy the template below, populate your responses, and submit directly in Canvas:


```text
KIN-265 Module 01 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]
Client Initials: [Insert Client Initials]

Step 1: Pattern Recognition (Clinical Risk Markers & Baseline Metrics):
Key Point: Patient Age & Surgical/Intervention Timeline:
Key Point: Resting Baseline Metrics: Resting HR: ___ bpm | Resting BP: ___ mmHg
Key Point: Stress Test Data: Max Test HR: ___ bpm | Ischemic Threshold HR: ___ bpm
Key Point: Baseline Activity Level & Inactivity Classification:

Step 2: Rule Application (Ischemic Gating & HRR Target Calculation):
Key Point: Upper Safe Target HR Ceiling (Ischemic Threshold - 10 bpm): ___ bpm
Key Point: Heart Rate Reserve (HRR) Calculation: [Safe Upper Limit - Resting HR = ___ bpm]
Key Point: Target Intensity Range (40% to 60% HRR):
  Key Point: Lower Limit (40% HRR): (___ * 0.40) + Resting HR = ___ bpm
  Key Point: Upper Limit (60% HRR): (___ * 0.60) + Resting HR = ___ bpm
  Key Point: Clinical Training Heart Rate Zone: ___ to ___ bpm

Step 3: Problem Solving (Phase III Indoor Prescription & Client Card):
Key Point: Phase A & B Exercise Modalities, Frequencies, and Durations (Climate-Controlled):
Key Point: Post-Sternal / Post-Procedure Safety Precautions (<10 lbs limit, no asymmetrical upper-limb pull):
Key Point: Matador Clinical Partners (MCP) Telemetry & Termination Guidelines:
Key Point: Bilingual Client Instruction Card (EN / ES):

Step 4: Part 3 — Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice):
Key Point: [In 150-word minimum (150+ words) written in your own clinical voice, justify why enforcing the 10 bpm ischemic threshold buffer, 40-60% HRR Karvonen zone, and indoor thermal control protects your cardiac rehab patient in Yuma]

Step 5: Repository Verification:
AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M01_Cardiac_Rehabilitation_Audit.pdf
End Submission ###:
```


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Part 1: Pattern Recognition: Key Point — Clinical Profile: L.P. is a 64-year-old male 8 weeks post-CABG surgery. Key Point — Resting Baselines: Resting $\text{HR} = 72\text{ bpm}$, Resting $\text{BP} = 132/84\text{ mmHg}$ (Stage 1 Hypertension). Key Point — Stress Test Data: $\text{Max HR} = 128\text{ bpm}$. Documented Ischemic Threshold = $115\text{ bpm}$ ($\text{ST-segment depression}$ and dyspnea). Key Point — Activity Classification: "Sedentary" (5–10 min light household walking, well below PAGA 150-minute guidelines).

Part 2: Rule Application (PAGA 2018 SSoT & Cardiac Math): Key Point — Upper Safe HR Limit: $\text{Ischemic Threshold } (115\text{ bpm}) - 10\text{ bpm} = \mathbf{105\text{ bpm maximum clinical ceiling}}$. Key Point — Safe Heart Rate Reserve (HRR): $\text{Safe Upper Limit } (105\text{ bpm}) - \text{Resting HR } (72\text{ bpm}) = \mathbf{33\text{ bpm}}$. Key Point — Target Intensity Range (40% to 60% HRR): Key Point: Lower Target (40% HRR): $(33 \times 0.40) + 72 = 13.2 + 72 = \mathbf{85\text{ bpm}}$. Key Point: Upper Target (60% HRR): $(33 \times 0.60) + 72 = 19.8 + 72 = \mathbf{92\text{ bpm}}$. Key Point: Clinical Training Heart Rate Zone: 85 to 92 bpm (ceiling: 105 bpm).

Part 3: Solving the Gap (Prescription & Precautions): Key Point — Phase A (Weeks 1–2): Climate-controlled indoor treadmill walking, 15 minutes/session, 3 days/week at 85 to 92 bpm ($\text{RPE } 11\text{--}12$). Key Point — Phase B (Weeks 3–4): Indoor track walking or recumbent stationary cycling, 25 minutes/session, 4 days/week (100 mins/week total). Key Point — Sternal Precautions: Restrict lifting/pushing/pulling to under 10 lbs; avoid upper-body ergometers or wide chest movements until cleared at week 12 by Matador Clinical Partners (MCP) cardiology.

EN: "Walk in an air-conditioned room keeping your heart rate between 85 and 92 beats per minute. Do not lift anything over 10 pounds to protect your healing chest bone while your heart rebuilds stamina."

ES: "Camine en un espacio con aire acondicionado manteniendo su frecuencia cardíaca entre 85 y 92 latidos por minuto. No levante más de 10 libras para proteger su esternón mientras su corazón recupera resistencia."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M01_Cardiac_Rehabilitation_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 01 (Mod 01 Lab: Heart Recovery & Safe Exercise Limits Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 01 Laboratorio y Simulación: Rehabilitación Cardíaca y Umbral Isquémico

Prescripción Clínica Cardíaca, Cálculo de HRR y Precauciones Esternales

En este laboratorio, diseñará una prescripción clínica de ejercicio para un paciente cardíaco utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , calculando los rangos de frecuencia cardíaca por debajo del umbral isquémico y aplicando las normas PAGA 2018.

- Apertura del Módulo: Martes, 18 de agosto de 2026, a las 12:00 AM MST
- Fecha Límite de Entrega: Lunes, 24 de agosto de 2026, a las 11:59 PM MST
- Ponderación: Puntuación de laboratorios semanales y auditorías clínicas (10 Puntos)

### Paso 1: Consulta en la Caja de Herramientas de IA Gemini

Pegue los datos de la ruta elegida en Gemini IA y copie esta plantilla debajo:


```text
Protocolo Safety Auditor: KIN-265 Laboratorio 01 ###:
Rol: Fisiologo del Ejercicio Clinico y Especialista en Rehabilitacion Cardiaca con la voz del Narrador.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Condiciones Cronicas.

Instrucciones:
Step 1: Revisar los datos del caso de la ruta seleccionada por el estudiante entre delimitadores (###).
Step 2: PATRON: Identificar la clasificacion de actividad fisica y limites clinicos criticos (metricas en reposo, FC maxima en prueba de esfuerzo y umbral isquemico documentado).
Step 3: REGLA: Calcular el limite superior seguro de frecuencia cardiaca (al menos 10 lpm por debajo del umbral isquemico) y establecer el rango meta con el metodo HRR (40% a 60%).
Step 4: SOLUCION: Disenar un programa seguro en interiores climatizados de Yuma con precauciones esternales (<10 lbs de carga) y pautas de referencia de Matador Clinical Partners (MCP).
Step 5: Generar una tarjeta de instruccion bilingue para el cliente (EN / ES).

Entrada de Datos del Cliente ###:
[PEGUE AQUI LOS DATOS DE SU RUTA ENTRE DELIMITADORES]
Fin de Datos del Cliente ###:
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Plantilla de Entrega en Canvas (Solo Texto)


```text
KIN-265 Entrega de Laboratorio Modulo 01 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clinica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]
Iniciales del Cliente: [Insertar Iniciales]

Step 1: Reconocimiento de Patrones (Marcadores de Riesgo Clinico y Metricas Basales):
Key Point: Edad del Paciente y Tiempo de Evolucion Quirurgica:
Key Point: Metricas en Reposo: FC Reposo: ___ lpm | PA Reposo: ___ mmHg
Key Point: Prueba de Esfuerzo: FC Maxima: ___ lpm | Umbral Isquemico: ___ lpm
Key Point: Nivel de Actividad y Clasificacion:

Step 2: Aplicacion de Reglas (Gating Isquemico y Calculo de HRR):
Key Point: Limite Superior Seguro (Umbral Isquemico - 10 lpm): ___ lpm
Key Point: Calculo de Reserva de FC (HRR): [Limite Superior Seguro - FC Reposo = ___ lpm]
Key Point: Rango de Intensidad Meta (40% a 60% HRR):
  Key Point: Limite Inferior (40% HRR): (___ * 0.40) + FC Reposo = ___ lpm
  Key Point: Limite Superior (60% HRR): (___ * 0.60) + FC Reposo = ___ lpm
  Key Point: Zona de Entrenamiento Clinico: ___ a ___ lpm

Step 3: Resolucion de Problemas (Prescripcion Fase III y Tarjeta Bilingue):
Key Point: Modalidades, Frecuencia y Duracion en Interiores Climatizados (Fases A y B):
Key Point: Precauciones Esternales / Posprocedimiento (Carga <10 lbs, evitar traccion asimetrica):
Key Point: Pautas de Telemetria y Finalizacion de Matador Clinical Partners (MCP):
Key Point: Tarjeta de Instruccion Bilingue para el Cliente (EN / ES):

Step 4: Verificación Activa Clinica Obligatoria (Mínimo 150 Palabras en su Propia Voz Humana):
Key Point: [En mínimo 150 palabras (150+ palabras) escritas en su propia voz clinica, justifique por que aplicar el margen de 10 lpm bajo el umbral isquemico, la zona de 40-60% HRR y el control termico en interiores protege a su paciente cardiaco en Yuma]

Step 5: Verificacion del Repositorio:
Intercambio con la IA exportado y guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M01_Cardiac_Rehabilitation_Audit.pdf
Fin de la Entrega ###:
```

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi criterio clínico como especialista en ejercicio, usar una fórmula genérica por edad (220 − edad) en un paciente post-cardíaco con umbral isquémico a los 132 lpm sería un error grave de seguridad. Una IA sin auditar podría llevarlo a 135 lpm, provocando isquemia miocárdica y angina. Al aplicar nuestra compuerta clínica estricta—fijando el límite superior 10 lpm por debajo del umbral isquémico (máximo 122 lpm) dentro del 40–60% de la Reserva de Frecuencia Cardíaca (HRR)—garantizamos que la demanda de oxígeno nunca supere el suministro coronario, entrenando siempre bajo techo en Yuma para evitar la deriva cardíaca por calor."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 01)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
