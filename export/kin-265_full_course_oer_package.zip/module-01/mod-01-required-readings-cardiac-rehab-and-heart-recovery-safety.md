## KIN-265: Mod 01 Required Readings Cardiac Rehab And Heart Recovery Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 01 Required Readings: Cardiac Rehab & Heart Recovery Safety

Lecturas Clínicas Obligatorias: Rehabilitación Cardíaca, Doble Producto y Límites de Seguridad Isquémica


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Outpatient cardiac rehabilitation uses carefully paced aerobic and resistance exercise to strengthen the heart after a cardiac event without triggering ischemia (low blood flow to heart muscle). Because beta-blocker medications lower heart rate, we monitor workload using Rate Pressure Product (heart rate times systolic blood pressure), RPE, and the Talk Test. Respecting angina thresholds and extended warm-ups/cool-downs keeps cardiac clients safe.


#### En Palabras Sencillas (Norteño Context)

Rehabilitar un corazón después de un infarto es como asentar un motor recién reparado: subes las revoluciones poco a poco vigilando la presión y la temperatura. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar la escala RPE, la Prueba del Habla y las señales de paro inmediato en rehabilitación cardíaca.


### Required SSoT Text & Clinical Guidelines

Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • Chapter 2 (Physical Activity Fundamentals) & Chapter 6 (Chronic Health Conditions and Disabilities).

PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev) Pautas Federales PAGA 2018: Prescripción en Enfermedades Crónicas y Discapacidades.

- AHA Clinical Guidelines Portal: AHA Guidelines on Secondary Prevention and Cardiac Rehabilitation
- Interactive PAGA Clinical Calculators ("PAGA" in Left Menu): Activity Audit (2-for-1 Rule) • Intensity & METs • Clinical Case Coach (Pattern / Rule / Solve)
- Offline AI Repository Document: exw265_ssot_special_populations_reference.docx (Local AI Preceptor and study file)

### Regional Focus: Cardiac Hemodynamics & Thermal Strain in the Desert Southwest

Enfoque Regional: Hemodinámica Cardíaca y Estrés Térmico en el Condado de Yuma

In Yuma County and regional desert communities, summer ambient temperatures frequently exceed 105°F (40.5°C). High thermal strain causes peripheral vasodilation, cutaneous blood pooling, and compensatory increases in resting heart rate. For Phase III outpatient cardiac clients, this elevated baseline heart rate dramatically narrows the available ischemic safety window ($\text{Ischemic Threshold} - 10\text{ bpm}$) and increases the Rate Pressure Product ($\text{RPP} = \text{HR} \times \text{SBP}$). Exercise specialists must mandate climate-controlled indoor environments (72°F), continuous telemetry/RPE monitoring, and strict hydration to prevent thermal myocardial ischemia.

En el condado de Yuma y las comunidades del desierto, el calor extremo del verano supera constantemente los 40.5°C (105°F). El estrés térmico provoca vasodilatación periférica y una elevación compensatoria de la frecuencia cardíaca en reposo. En pacientes de rehabilitación cardíaca en Fase III, este incremento reduce drásticamente el margen de seguridad isquémica ($\text{Umbral Isquémico} - 10\text{ lpm}$) y eleva el Doble Producto ($\text{DP} = \text{FC} \times \text{PAS}$). Los especialistas deben exigir entornos climatizados (22°C), monitoreo continuo de RPE y estricta hidratación.


### Reading 1: Ischemic Threshold Safety Gating & Double Product Math

Lectura 1: Umbral de Seguridad Isquémica y Matemáticas del Doble Producto

Myocardial oxygen demand ($M\text{V}\text{O}_2$) is directly proportional to the Double Product (DP) , also known as the Rate Pressure Product (RPP) :

In clinical exercise testing, myocardial ischemia is evidenced by $\ge 1\text{ mm}$ of horizontal or downsloping ST-segment depression, angina onset, or blunted systolic blood pressure response. Exercise prescriptions must establish a strict non-negotiable heart rate ceiling:

La demanda miocárdica de oxígeno es proporcional al Doble Producto. En la prescripción clínica, el límite máximo de frecuencia cardíaca debe mantenerse al menos a 10 lpm por debajo de la frecuencia donde se evidenció isquemia clínica (infradesnivel ST $\ge 1\text{ mm}$ o angina).


### Reading 2: Post-CABG Sternal Precautions & Biomechanical Safety

Lectura 2: Precauciones Esternales Pos-CABG y Seguridad Biomecánica

Following a median sternotomy for Coronary Artery Bypass Graft (CABG) surgery, osseous sternal healing requires 8 to 12 weeks . Exercise physiologists must strictly enforce sternal safety boundaries:

- Upper-Body Load Limit: Restrict all upper-body resistance exercises to $< 10\text{ lbs}$ ($4.5\text{ kg}$) to avoid excessive mechanical stress on healing sternal wire sutures.
- Avoid Asymmetrical Upper-Limb Traction: Prohibit unilateral overhead pulling, aggressive torso rotation, or unilateral push/pull movements that create torsional shearing across the sternal midline.
- Prohibit Sternal Distraction: Substitute push-ups, heavy chest flyes, or seated rows with neutral-spine lower-body axial loading (chair sit-to-stands, recumbent stepping) and low-intensity isometric core bracing.

### Key Terminology / Glosario Clave

The mathematical product of Heart Rate and Systolic Blood Pressure ($\text{DP} = \text{HR} \times \text{SBP}$), serving as a direct clinical estimate of myocardial oxygen consumption and hemodynamic stress.

Producto matemático de la frecuencia cardíaca y la presión arterial sistólica ($\text{DP} = \text{FC} \times \text{PAS}$), que estima el consumo de oxígeno del miocardio.

The specific heart rate or workload at which myocardial oxygen demand exceeds coronary blood supply, triggering clinical signs of ischemia ($\ge 1\text{ mm}$ ST depression or angina).

Frecuencia cardíaca o carga de trabajo en la que la demanda de oxígeno supera el aporte coronario, manifestándose en angina o infradesnivel del segmento ST (≥ 1 mm).

A surgical separation or mechanical instability of the sternal bone margins following median sternotomy; prevented during Phase III rehab by enforcing strict load limits ($< 10\text{ lbs}$) for 8–12 weeks.

Separación quirúrgica de los bordes óseos del esternón tras una esternotomía media; prevenida con límites de carga ($< 10\text{ lbs}$) durante 8 a 12 semanas.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Parámetros Clínicos

Select each question below to confirm your understanding of cardiac rehab gating before starting Discussion 01 and Lab 01:

English Response: The upper target exercise heart rate is strictly capped at least 10 bpm below the heart rate at which clinical ischemia (angina or $\ge 1\text{ mm}$ ST-segment depression) occurred during the graded exercise test ($\text{Max HR} = \text{Ischemic Threshold} - 10\text{ bpm}$).

Respuesta en Español: La frecuencia cardíaca máxima de entrenamiento se fija al menos 10 lpm por debajo del umbral donde ocurrió la isquemia clínica en la prueba de esfuerzo ($\text{FC Máx} = \text{Umbral Isquémico} - 10\text{ lpm}$).

English Response: For 8 to 12 weeks post-surgery, patients must: (1) Limit upper-body lifting to $< 10\text{ lbs}$ ($4.5\text{ kg}$), (2) Avoid unilateral upper-limb traction, reaching behind the back, or aggressive rotational twisting, and (3) Minimize bilateral chest expansion shear.

Respuesta en Español: Durante 8 a 12 semanas poscirugía: (1) Limitar la carga del tren superior a $< 10\text{ lbs}$ ($4.5\text{ kg}$), (2) Evitar tracción unilateral, alcanzar detrás de la espalda o giros bruscos, y (3) Minimizar fuerzas de expansión torácica.

English Response: Extreme ambient temperatures induce cutaneous vasodilation and elevate baseline heart rate to dissipate heat. This cardiovascular drift elevates Double Product prematurely, triggering ischemic thresholds at lower external workloads.

Respuesta en Español: Las altas temperaturas provocan vasodilatación periférica y elevan la frecuencia cardíaca basal. Esta deriva cardiovascular incrementa el Doble Producto de forma prematura, alcanzando el umbral isquémico con menores cargas de trabajo.


### AI Simulation Workspace • Cardiac Safety Auditor Simulation

Copy the prompt below into Gemini to audit Double Product values, establish ischemic safety ceilings, and verify post-CABG sternal gating:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-265 Module 01 Cardiac Tool Box ###:
Role: Clinical Exercise Physiologist and Outpatient Cardiac Rehab Specialist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chronic Health Conditions.

Instructions:
Step 1: Audit the student's clinical case data enclosed within triple-hashes (###) below.
Step 2: Calculate Double Product (DP = HR * SBP) at rest and peak clinical stress test levels.
Step 3: Establish the non-negotiable upper target exercise heart rate ceiling (Ischemic Threshold - 10 bpm).
Step 4: Audit sternal stability restrictions (post-CABG weeks, <10 lbs load limit, prohibition of asymmetrical upper-body pulling).
Step 5: Prescribe a Phase III cardiac exercise protocol (RPE 11-13) adapted for indoor climate-controlled facilities in Yuma County.
Step 6: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
Client Age: [Insert Age]
Cardiac History / Surgery: [e.g., Post-CABG 6 weeks or Post-MI]
Ischemic Threshold Heart Rate: [Insert bpm where ST depression/angina occurred]
Resting Blood Pressure & HR: [Insert Resting SBP/DBP and HR]
Peak Stress Test SBP & HR: [Insert Peak SBP and HR]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 01 (Mod 01 Required Readings: Cardiac Rehab & Heart Recovery Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Clínicas Obligatorias: Rehabilitación Cardíaca e Isquemia


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) • Capítulo 2 (Fundamentos) y Capítulo 6 (Condiciones de Salud Crónicas y Discapacidades).

Herramienta Interactiva PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev)

- Portal de la AHA: Pautas Clínicas de Rehabilitación Cardíaca y Prevención Secundaria

### Conceptos Clínicos Centrales


#### Step 1: Umbral Isquémico y Doble Producto

El Doble Producto ($\text{DP} = \text{FC} \times \text{PAS}$) estima el consumo de oxígeno miocárdico. El límite superior de frecuencia cardíaca de entrenamiento debe fijarse estrictamente a 10 lpm por debajo del umbral isquémico documentado para evitar angina o depresión del segmento ST.


#### Step 2: Precauciones Esternales Pos-CABG

Durante 8 a 12 semanas tras una esternotomía, se debe restringir el levantamiento de peso con el tren superior a $< 10\text{ lbs}$ ($4.5\text{ kg}$) y evitar tracciones asimétricas o rotaciones para prevenir la dehiscencia esternal.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para asegurar un entorno de aprendizaje inclusivo, equitativo y accesible para toda nuestra comunidad estudiantil.

KIN-265 • Module 01 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 01:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 01)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
