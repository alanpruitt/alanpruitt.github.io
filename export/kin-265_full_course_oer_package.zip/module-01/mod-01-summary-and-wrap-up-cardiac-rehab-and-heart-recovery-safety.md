## KIN-265: Mod 01 Summary And Wrap Up Cardiac Rehab And Heart Recovery Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 01 Summary & Wrap-Up: Cardiac Rehab & Heart Recovery Safety

Fundamentos Clínicos, Seguridad Hemodinámica y Pautas PAGA 2018 para Poblaciones Especiales


### Step 1: Core Clinical Safety & Special Populations Foundations Synthesis

Congratulations on completing Module 01! You have established the foundational clinical safety architecture, risk-benefit evaluation models, and overarching PAGA 2018 guidelines for managing special populations and chronic health conditions:

- Universal PAGA 2018 Premise: Some physical activity is significantly better than none. Individuals with chronic health conditions or disabilities should engage in regular physical activity according to their individual abilities, avoiding sedentary inactivity at all costs.
- Hemodynamic Safety Ceilings: In Phase III cardiac and vascular rehabilitation, exercise heart rates must remain at least 10 bpm below documented ischemic thresholds (Max HR = Ischemic Threshold - 10 bpm) with strict sternal healing limits (< 10 lbs) post-CABG.
- Overarching Safety & Adaptation Parameters: When chronic pathology prevents meeting baseline adult guidelines (150–300 min/wk moderate activity), prescriptions must be customized to match functional capacity while avoiding symptom triggers.
- Risk vs. Benefit Continuum: The clinical benefits of physical activity far outweigh the risk of adverse events; progressive, low-to-moderate initial loading ("start low and go slow") minimizes musculoskeletal and cardiovascular risks during early conditioning.

### Step 2: Workplace Intelligence & AI Clinical Safety Auditing

Clinical exercise physiologists, medical fitness specialists, and community health coordinators leverage generative AI preceptors to audit client health histories, screen for contraindications, and structure safety-focused activity protocols.

- AI Clinical Diagnostics: Specialists prompt AI preceptors to cross-examine complex patient profiles (co-morbidities, functional limitations) against federal PAGA 2018 exercise safety rules.
- Delimiter Security Protocol (###): Clinical patient profiles, symptom histories, and medication lists must be wrapped inside triple hashes ( ### ) to maintain data boundaries during automated preceptor analysis.
- Human-in-the-Loop Clinical Verification: AI recommendations never supersede professional clinical judgment. Human verification against PAGA 2018 standards remains mandatory before prescribing physical exertion to special populations.

### Step 3: Module 01 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 02:

English Response: Adults with chronic health conditions or disabilities should engage in regular physical activity according to their individual abilities. If unable to achieve 150 minutes of moderate activity weekly, they should be as physically active as their abilities and conditions allow, avoiding complete sedentary behavior.

Respuesta en Español: Los adultos con afecciones crónicas o discapacidades deben realizar actividad física regular según sus capacidades. Si no pueden alcanzar los 150 minutos semanales de actividad moderada, deben ser tan activos como sus condiciones se lo permitan, evitando la inactividad total.

English Response: The upper target exercise heart rate is strictly capped at least 10 bpm below the heart rate at which clinical ischemia (angina or ≥ 1 mm ST-segment depression) occurred during the graded exercise test (Max HR = Ischemic Threshold - 10 bpm).

Respuesta en Español: La frecuencia cardíaca máxima de entrenamiento se fija al menos 10 lpm por debajo del umbral donde ocurrió la isquemia clínica en la prueba de esfuerzo (FC Máx = Umbral Isquémico - 10 lpm).

English Response: Starting with low-intensity, short-duration bouts and gradually increasing frequency and duration before increasing intensity ("start low and go slow"), combined with proper warm-ups, cool-downs, and climate-controlled environmental monitoring.

Respuesta en Español: Comenzar con bloques de baja intensidad y corta duración e incrementar gradualmente la frecuencia y duración antes de aumentar la intensidad ("comenzar bajo e ir despacio"), combinado con un calentamiento adecuado y control ambiental.

English Response: Sternal precautions protect bone healing following median sternotomy by preventing excessive chest wall tension, sternal separation, or non-union.

Respuesta en Español: Las precauciones esternales protegen la curación ósea tras una esternotomía mediana al prevenir la tensión excesiva en la pared torácica, la separación esternal o la falta de consolidación.

English Response: The triple-hash delimiter protocol securely isolates patient clinical parameters during AI consultations, preventing prompt drift and ensuring reliable auditing against PAGA 2018 guidelines.

Respuesta en Español: El protocolo de delimitadores aísla de forma segura los parámetros clínicos del paciente durante las consultas con IA, previniendo la deriva de instrucciones y asegurando una auditoría confiable frente a las normas PAGA 2018.

English Response: Extreme ambient heat and solar radiation impose high cardiovascular strain through cutaneous vasodilation and dehydration, elevating heart rate at lower workloads and triggering premature ischemia.

Respuesta en Español: El calor extremo y la radiación solar imponen una gran sobrecarga cardiovascular por vasodilatación cutánea y deshidratación, elevando la frecuencia cardíaca y desencadenando isquemia prematura.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth for chronic condition exercise programming.

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal para la programación de ejercicio en condiciones crónicas.

English Response: The clinical benefits of regular physical activity (such as improved functional capacity and reduced mortality) far outweigh the minor risks of adverse cardiovascular events during monitored exertion.

Respuesta en Español: Los beneficios clínicos de la actividad física regular (como mayor capacidad funcional y menor mortalidad) superan ampliamente los riesgos menores de eventos cardiovasculares adversos durante el esfuerzo monitoreado.

English Response: A gradual warm-up increases cardiac output, enhances blood flow to active skeletal muscles, elevates muscle temperature, and reduces the risk of acute myocardial ischemia or arrhythmias.

Respuesta en Español: Un calentamiento gradual aumenta el gasto cardíaco, mejora el flujo sanguíneo hacia los músculos activos, eleva la temperatura muscular y reduce el riesgo de isquemia miocárdica aguda o arritmias.


### AI Simulation Workspace • Special Populations Safety Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive clinical review matrix connecting chronic disease adaptations, ischemic ceilings, and PAGA guidelines:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: KIN-265 Module 01 Clinical Foundations Synthesis ###:
Role: Clinical Exercise Physiologist and Special Populations Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chronic Health Conditions & Disabilities.

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Chronic Condition Baseline (PAGA 2018 adaptation rules).
   Key Point: Hemodynamic Safety Gating (Double Product math & Ischemic Threshold - 10 bpm ceiling).
   Key Point: Sternal and Post-Surgical Restrictions (<10 lbs load limit, avoidance of asymmetrical torque).
Step 2: Detail how climate-controlled exercise prescription in Yuma prevents cardiovascular drift and premature ischemic threshold triggers.
Step 3: Keep all inputs and structured recommendations wrapped within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 02 — Type 2 Diabetes Programming & Glycemic Safety

In plain English, next week in Module 02: Type 2 Diabetes Programming you will learn how working muscles pull sugar out of the bloodstream even without extra insulin, and how to check blood-glucose numbers before exercise so your client never suffers a dangerous low-blood-sugar crash (hypoglycemia). Why it matters: Type 2 diabetes is highly prevalent in Yuma and Imperial Valley—knowing the exact blood-sugar safety floor ($<100\text{ mg/dL}$ requires 15–30 g fast carbs first) saves lives.

- Pattern (Context): Auditing pre-exercise blood glucose, insulin/secretagogue timing, peripheral neuropathy foot care, and desert hydration status.
- Rule (Constraint): Enforcing PAGA 2018 diabetes rules ( no more than 48 hours between aerobic sessions) and strict glycemic safety gates (treat $<100\text{ mg/dL}$ before starting).
- Solve (Intervention): Completing Mod 02 Discussion: Blood Glucose & Exercise Timing and Mod 02 Lab: Type 2 Diabetes Exercise Plan .

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 01 (Mod 01 Summary & Wrap-Up: Cardiac Rehab & Heart Recovery Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 01: Resumen y Evaluación

Fundamentos Clínicos, Seguridad Hemodinámica y Pautas PAGA 2018 para Poblaciones Especiales


### Step 1: Síntesis de Fundamentos Clínicos y Seguridad en Poblaciones Especiales

¡Felicitaciones por completar el Módulo 01! Ha establecido la arquitectura clínica de seguridad, modelos de evaluación de riesgo-beneficio y pautas federales PAGA 2018 para poblaciones especiales:

- Premisa Universal PAGA 2018: Algo de actividad física es significativamente mejor que nada. Las personas con afecciones crónicas o discapacidades deben realizar actividad regular según sus capacidades, evitando el sedentarismo a toda costa.
- Límites de Seguridad Hemodinámica: En la Fase III de rehabilitación cardiovascular, la frecuencia cardíaca debe mantenerse al menos a 10 lpm por debajo del umbral isquémico documentado (FC Máx = Umbral Isquémico - 10 lpm) y con límites esternales (< 10 lbs).
- Parámetros Generales de Adaptación: Cuando una patología impida alcanzar la meta para adultos (150 a 300 min/sem de actividad moderada), la prescripción debe ajustarse a la capacidad funcional y evitar desencadenantes de síntomas.
- Continuo de Riesgo vs. Beneficio: Los beneficios del ejercicio superan ampliamente los riesgos; iniciar con cargas bajas a moderadas ("comenzar bajo e ir despacio") minimiza los riesgos iniciales.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría con IA

Los fisiólogos del ejercicio clínico y especialistas en actividad física médica utilizan IA generativa para auditar historiales clínicos, verificar contraindicaciones y diseñar protocolos de ejercicio seguros.

- Diagnóstico Clínico Asistido por IA: Contraste de perfiles complejos frente a las reglas de seguridad de PAGA 2018.
- Protocolo con Delimitadores (###): Uso de tres numerales ( ### ) para aislar datos del paciente.
- Verificación Clínica Humana: Las sugerencias de IA deben ser verificadas por un clínico frente a PAGA 2018 antes de prescribir esfuerzo físico.

### Step 3: Autoevaluación del Módulo 01

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 02:


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: KIN-265 Sintesis Modulo 01 ###:
Rol: Fisiologo del Ejercicio Clinico y Especialista en Poblaciones Especiales.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Condiciones Cronicas y Discapacidades.

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Lineamientos base para condiciones cronicas (reglas de adaptacion PAGA 2018).
   Key Point: Control de seguridad hemodinamica (Doble Producto y techo de Umbral Isquemico - 10 lpm).
   Key Point: Restricciones esternales posquirurgicas (limite <10 lbs, evitar torsion asimetrica).
Step 2: Detallar como la prescripcion en interiores climatizados de Yuma evita la deriva cardiovascular y el umbral isquemico prematuro.
Step 3: Mantener todos los datos entre delimitadores (###).
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 02 — Programación para Diabetes Tipo 2 y Seguridad Glucémica

En palabras sencillas (Contexto Norteño): cuando los músculos se mueven, chupan el azúcar de la sangre como esponja durante hasta 48 horas; por eso el ejercicio es medicina directa para la diabetes tipo 2. Si los términos metabólicos se ponen pesados la próxima semana, concéntrate primero en las dos reglas de oro: no dejar pasar más de 2 días seguidos sin ejercicio aeróbico y nunca empezar si la glucosa está por debajo de 100 mg/dL sin antes dar 15–30 g de carbohidrato rápido.

- Patrón (Contexto): Revisar la glucosa antes de entrenar, el horario de medicamentos/insulina y el cuidado de los pies en el calor de Yuma.
- Regla (Restricción): Aplicar la regla de PAGA 2018 (máximo 48 horas entre sesiones aeróbicas) y el piso de seguridad glucémica ($<100\text{ mg/dL}$).
- Solución (Intervención): Completar el Foro del Mód 02 (Blood Glucose & Exercise Timing) y el Laboratorio del Mód 02 (Type 2 Diabetes Exercise Plan) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 01 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 01:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 01)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
