## KIN-265: Mod 04 Required Readings Safe Exercise During And After Pregnancy

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 04 Required Readings: Safe Exercise During & After Pregnancy

Lecturas Clínicas Obligatorias: Embarazo, Biomecánica Gestacional y Hemodinámica Materno-Fetal


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Prenatal and postpartum exercise supports maternal heart health, blood sugar control, and mood when adapted for changing anatomy and heat dissipation. Under PAGA 2018, healthy pregnant women aim for 150 minutes per week of moderate aerobic activity while avoiding overheating, contact sports, and flat-on-the-back (supine) positions after the first trimester. Monitoring the Talk Test and Obstetric warning signs protects both mother and baby.


#### En Palabras Sencillas (Norteño Context)

Entrenar durante el embarazo en Yuma requiere sombra, buena hidratación y escuchar la respiración usando la Prueba del Habla. Si los términos técnicos se ponen pesados, concéntrate primero en las adaptaciones por trimestre, evitar el calor extremo y reconocer las señales de alerta obstétrica.


### Required SSoT Text & Clinical Guidelines

Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) (Chapter 6: Active Pregnant and Postpartum Women) • ACOG Committee Opinion No. 804 (Physical Activity and Exercise During Pregnancy and the Postpartum Period).

- Clinical Guidelines Portal: ACOG Clinical Guidance: Physical Activity and Exercise During Pregnancy
- ODPHP Guidelines Portal: PAGA 2018 2nd Edition Official Chapters & Manual ("PAGA" in Course Navigation Bar • paga2018.dev/chapters)
- Interactive PAGA Clinical Calculators ("PAGA" in Left Menu): Activity Audit (2-for-1 Rule) • Intensity & METs • Clinical Case Coach (Pattern / Rule / Solve)
- Offline AI Repository Document: exw265_ssot_special_populations_reference.docx (Upload to your AI Repository or study offline)

### Regional Focus: Maternal Hydration & Thermal Strain in the Desert Southwest

Enfoque Regional: Hidratación Materna y Termorregulación en el Condado de Yuma

In Yuma County and regional desert border communities, summer heat indexes routinely exceed 105°F (40.5°C). Pregnant women experience increased basal metabolic rates, elevated core body temperature set points, and higher plasma volume expansion. Exposure to extreme outdoor heat carries significant teratogenic and maternal risks, including neural tube defect vulnerability during the first trimester, dehydration-induced uterine contractions, and maternal syncope. Clinical exercise prescriptions mandate climate-controlled indoor environments (72°F / 22°C), continuous hydration (16 to 24 oz of fluid per hour of light exertion), and RPE-guided intensity (12 to 14 "somewhat hard") rather than heart rate max formulas.

En el condado de Yuma y las comunidades del desierto, el calor del verano supera los 40.5°C (105°F). Las mujeres embarazadas presentan una tasa metabólica basal más alta y mayor temperatura corporal. El calor extremo eleva el riesgo de contracciones prematuras por deshidratación y síncope materno. Las prescripciones deben exigir instalaciones climatizadas (22°C), hidratación continua (16 a 24 oz de líquido por hora) y monitoreo por RPE (12 a 14) en lugar de fórmulas de frecuencia cardíaca máxima.


### Reading 1: Supine Hypotensive Syndrome & Vascular Mechanics

Lectura 1: Síndrome Hipotensivo Supino y Compresión de la Vena Cava Inferior


#### Step 1: Inferior Vena Cava (IVC) Occlusion After 16 Weeks

Oclusión de la Vena Cava Inferior después de las 16 Semanas

Following 16 weeks of gestation, the enlarged gravid uterus compresses the Inferior Vena Cava (IVC) and descending aorta against the lumbar spine when the patient lies flat in a supine position. This mechanical compression obstructs venous return to the right atrium, triggering a rapid fall in stroke volume, cardiac output, and maternal systemic blood pressure (supine hypotensive syndrome). This sudden hypotension reduces uteroplacental blood flow, compromising fetal oxygen delivery.

Clinical Gating Rule: Exercise physiologists must strictly prohibit all flat supine exercises (e.g., floor crunches, flat bench press, supine leg raises) after 16 weeks gestation. All floor exercises must be substituted with a 45-degree incline bench, side-lying (left lateral decubitus), quadruped, seated, or standing postures.

Después de las 16 semanas, el útero grávido comprime la Vena Cava Inferior contra la columna en posición supina plana, reduciendo el retorno venoso, el volumen sistólico y la presión arterial materna. Se debe prohibir el ejercicio supino plano y reemplazarlo por bancos inclinados a 45 grados, decúbito lateral o posición de pie.


### Reading 2: Relaxin Joint Laxity, Biomechanics & ACOG Termination Signs

Lectura 2: Laxitud Articular por Relaxina y Signos de Detención de ACOG


#### Step 1: Relaxin-Mediated Pelvic Girdle Vulnerability

Vulnerabilidad de la Cintura Pélvica Mediada por Relaxina

Elevated systemic levels of the hormone relaxin soften connective tissue and remodel collagen, increasing ligamentous laxity throughout the sacroiliac (SI) joints and pubic symphysis to prepare the pelvic outlet for delivery. Combined with an anterior shift in the center of gravity and increased lumbar lordosis, joint stability is significantly reduced:

- Prohibit Asymmetrical Pelvic Shear: Avoid deep single-leg lunges, heavy asymmetrical step-ups, and rapid rotational torso loading that induce SI joint subluxation or symphysis pubis dysfunction (SPD).
- Eliminate High-Impact & Contact Hazards: Prohibit activities with contact risk (soccer, basketball) or fall hazards (horseback riding, outdoor trail running, downhill skiing) due to altered balance and impaired joint proprioception.
- Prohibit the Valsalva Maneuver: Heavy isometric straining spikes intra-abdominal and intra-thoracic pressure, acutely restricting venous return and fetal perfusion.

#### Step 2: ACOG Emergency Warning Signs for Exercise Termination

Signos de Alarma de Emergencia de ACOG para la Finalización Inmediata del Ejercicio

Exercise must be stopped immediately and physician evaluation initiated if any of the following clinical warning signs occur:

- Vaginal bleeding or amniotic fluid leakage.
- Dizziness, presyncope, or syncope.
- Shortness of breath prior to exertion.
- Chest pain, severe headache, or sudden muscle weakness affecting balance.
- Calf pain or unilateral swelling (screening for deep vein thrombosis / thrombophlebitis).

### Key Terminology / Glosario Clave

Vascular occlusion of the inferior vena cava (IVC) caused by the weight of the gravid uterus in flat supine positions after 16 weeks gestation, reducing venous return and maternal blood pressure; prevented by utilizing a 45-degree incline or side-lying position.

Oclusión vascular de la vena cava inferior causada por el peso del útero en decúbito supino plano tras 16 semanas de gestación; se previene con inclinación a 45 grados o posición lateral.

A systemic hormone elevation during pregnancy that increases ligamentous joint laxity, particularly within the pubic symphysis and sacroiliac (SI) joints, requiring avoidance of heavy asymmetrical lower-body shear forces.

Elevación hormonal que incrementa la laxitud ligamentosa pélvica, requiriendo evitar fuerzas de cizallamiento asimétricas y ejercicios de impacto.

Clinical warning indicators (vaginal bleeding, amniotic leakage, dizziness, calf swelling, or regular painful contractions) dictating immediate exercise cessation and clinical evaluation.

Indicadores de advertencia clínica (sangrado, fuga de líquido amniótico, mareo, dolor en pantorrillas o contracciones) que exigen detener el ejercicio de inmediato.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Biomecánica Gestacional

Select each question below to confirm your understanding of maternal exercise safety before starting Discussion 04 and Lab 04:

English Response: After 16 weeks, the gravid uterus compresses the Inferior Vena Cava (IVC), severely restricting venous blood return to the maternal heart. This drops cardiac output and arterial blood pressure (supine hypotensive syndrome), compromising oxygen delivery to the fetus.

Respuesta en Español: Después de las 16 semanas, el útero grávido ocluye la Vena Cava Inferior, reduciendo drásticamente el retorno venoso, el gasto cardíaco y la presión arterial materna, comprometiendo la oxigenación fetal.

English Response: Relaxin induces ligamentous joint laxity, especially in the pelvic symphysis and sacroiliac joints. Combined with an anterior shift in the center of gravity, exercise programs must avoid deep asymmetrical lunges, ballistic single-leg loading, and rapid torso twisting to prevent joint subluxation and pelvic girdle pain.

Respuesta en Español: La relaxina genera laxitud en los ligamentos de la sínfisis púbica y articulaciones sacroilíacas. Se deben evitar desplantes profundos asimétricos y giros bruscos para prevenir dolor pélvico e inestabilidad articular.

English Response: Exercise must stop immediately upon onset of: vaginal bleeding, amniotic fluid leakage, dizziness or syncope, pre-exertional dyspnea, chest pain, calf pain or unilateral swelling (DVT risk), or regular painful uterine contractions.

Respuesta en Español: Detener el ejercicio de inmediato ante: sangrado vaginal, fuga de líquido amniótico, mareo o síncope, disnea antes del esfuerzo, dolor de pecho, hinchazón en pantorrillas o contracciones uterinas regulares.


### AI Simulation Workspace • Gestational Safety Auditor Simulation

Copy the prompt below into Gemini to audit gestational exercise parameters, screen for supine contraindications, and construct climate-adapted maternal prescriptions:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-265 Module 04 Gestational Tool Box ###:
Role: Clinical Exercise Physiologist and Maternal-Fetal Exercise Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Active Pregnant and Postpartum Women & ACOG Committee Opinion No. 804.

Instructions:
Step 1: Audit the student's clinical case data enclosed within triple-hashes (###) below.
Step 2: Evaluate gestational age and screen for supine positioning contraindications (mandating 45-degree incline, side-lying, or standing modifications after 16 weeks).
Step 3: Audit biomechanical safety, identifying relaxin-mediated joint laxity risks (avoiding asymmetrical lower-body shear) and eliminating Valsalva maneuvers.
Step 4: Prescribe a PAGA-aligned weekly exercise protocol (150 minutes of moderate-intensity aerobic activity, RPE 12-14) adapted for indoor climate-controlled facilities in Yuma County.
Step 5: List the mandatory ACOG emergency termination warning signs and provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
Client Age: [Insert Age]
Gestational Age: [e.g., 22 weeks gestation]
Clinical Presentation / Symptoms: [e.g., Mild gestational diabetes, SI joint pain, heat sensitivity]
Current Physical Activity Level: [e.g., Sedentary or recreational walking]
Proposed Exercise Modalities: [e.g., Walking, prenatal strength, water aerobics]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 04 (Mod 04 Required Readings: Safe Exercise During & After Pregnancy)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Clínicas Obligatorias: Biomecánica Gestacional y Seguridad


### Texto Fuente SSoT y Lineamientos Gestacionales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) (Capítulo 6: Mujeres Durante el Embarazo y el Posparto) • Opinión del Comité ACOG N.° 804.

ACOG: Actividad Física y Ejercicio Durante el Embarazo y el Posparto

- Portal Federal: Manual Oficial y Capítulos PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev/chapters)

### Conceptos Clínicos Centrales


#### Step 1: Síndrome Hipotensivo Supino

Tras 16 semanas de gestación, la posición supina plana comprime la Vena Cava Inferior, reduciendo el retorno venoso, el gasto cardíaco y la presión arterial materna. Debe sustituirse por inclinación a 45 grados o posición lateral.


#### Step 2: Laxitud por Relaxina y Signos de Alarma ACOG

La hormona relaxina incrementa la laxitud ligamentosa pélvica, requiriendo evitar fuerzas asimétricas pesadas y maniobras de Valsalva. El ejercicio debe suspenderse de inmediato ante sangrado, fuga de líquido amniótico, mareo o contracciones dolorosas.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 04 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 04:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 04)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
