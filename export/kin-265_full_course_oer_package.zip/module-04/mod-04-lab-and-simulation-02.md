## KIN-265: Mod 04 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 04) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 04 Coaching Sprint Simulation: Posture, Balance & Warning Signs in Pregnancy

Sesión de Coaching del Módulo 04: Embarazo, Biomecánica Gestacional y Seguridad

- PAGA 2018 Maternal Benchmark (≥150 Min/Week Moderate Aerobic): Pregnant and postpartum women without medical/obstetric contraindications should accumulate at least 150 minutes/week of moderate-intensity aerobic activity. En palabras sencillas: Durante el embarazo sin complicaciones médicas se recomiendan al menos 150 minutos semanales de actividad aeróbica moderada.
- Supine Hypotensive Syndrome (Avoid Flat Back Position After 1st Trimester): Lying flat on the back after week 16–20 allows the gravid uterus to compress the inferior vena cava, reducing venous return and causing dizziness; use incline or side-lying positions. En palabras sencillas: Después del primer trimestre evitamos ejercicios acostada boca arriba para que el peso del bebé no presione la vena cava ni cause mareo.
- Absolute Obstetric Warning Signs to Terminate Exercise: Stop exercise immediately and seek medical evaluation for vaginal bleeding, regular painful contractions, amniotic fluid leakage, dyspnea before exertion, or dizziness. En palabras sencillas: Detener la sesión de inmediato y acudir al médico si hay sangrado, contracciones dolorosas, salida de líquido, mareo o falta de aire en reposo.
- KIN-265.4.1.AY26-27: Apply PAGA 2018 clinical guidelines for maternal-fetal safety, postural adaptations, and biomechanical shifts during pregnancy. Aplicar las pautas clínicas de PAGA 2018 para la seguridad materno-fetal, adaptaciones posturales y cambios biomecánicos durante el embarazo.
- KIN-265.4.2.AY26-27: Audit clinical safety parameters, supine position restrictions, and intensity regulations for prenatal exercise prescriptions. Auditar parámetros de seguridad clínica, restricciones en decúbito supino y regulación de intensidad para prescripciones de ejercicio prenatal.

### Your Weekly Win: Navigating Prenatal Biomechanics

How do shifting centers of gravity, joint laxity from relaxin, and cardiovascular adaptations alter exercise prescription during pregnancy? Prenatal physical activity supports maternal health and fetal development, but requires careful auditing of postural changes, core stability, and supine positioning after 16 weeks. Following strict PAGA 2018 clinical guidelines and ACOG standards, exercise specialists design safe, adaptive fitness programs. Choose your coaching track below, chat with your AI Socratic Coach, and master clinical safety auditing!

¿Cómo alteran los cambios en el centro de gravedad y la laxitud articular la prescripción de ejercicio durante el embarazo? El ejercicio prenatal apoya la salud materna y fetal auditando la postura y la posición supina según las normas PAGA 2018. ¡Elija su ruta y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés vocacional

Scenario: Prenatal patient (Laura, 32) in her second trimester experiencing pelvic girdle pain and lumbar lordosis who wants guidance on safe core and stability exercises at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Hospital Outpatient Path
[CLIENT]: Second-Trimester Prenatal Patient (Laura, 32) | [LOCATION]: Yuma, AZ
[SITUATION]: Experiencing pelvic girdle discomfort and increased anterior pelvic tilt. She wants to maintain core strength without aggravating diastasis recti or lower back pain.
[COACHING GOAL]: Apply PAGA 2018 clinical guidelines to audit core stabilization exercises, eliminate unsafe abdominal movements, and support pelvic alignment.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Physical Therapy & Women's Health.
###
```

Scenario: Community wellness instructor (Coach Sarah, 29) leading prenatal group fitness classes who needs to adjust floor routines for clients past their first trimester.


```text
###
[TRACK]: Track 2 - Community & Senior Wellness Path
[CLIENT]: Community Wellness Instructor (Coach Sarah, 29) | [LOCATION]: Yuma County, AZ
[SITUATION]: Leading group classes containing pregnant participants. She needs guidance regarding supine exercise restrictions and venous compression risks.
[COACHING GOAL]: Audit supine position safety protocols, teaching instructors how to modify flat-lying movements into inclined or seated alternatives.
[COMMUNITY SITE]: Yuma County Public Health Services District & Parks Recreation Centers.
###
```

Scenario: Experienced recreational lifter (Jessica, 30) continuing resistance training through pregnancy while managing intra-abdominal pressure and heavy loading limits.


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Conditioning Path
[CLIENT]: Active Recreational Lifter (Jessica, 30) | [LOCATION]: Yuma, AZ
[SITUATION]: Wants to continue barbell resistance training during pregnancy but is unsure about Valsalva maneuver risks, intra-abdominal pressure, and load scaling.
[COACHING GOAL]: Audit resistance training parameters, breathing mechanics (exhaling on exertion), and intensity modulation aligned with PAGA 2018 standards.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-265 Pregnancy & Biomechanics Tool Box ###:
Role: Supportive KIN-265 Clinical Exercise Specialist Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Active Pregnant and Postpartum Women & ACOG Committee Opinion No. 804.

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms PAGA 2018 clinical guidelines for prenatal exercise prescription, including postural shifts, relaxin joint laxity, and supine positioning safety after 16 weeks gestation.
Step 3: Guide the student to provide ONE clinical safety protocol or exercise prescription adjustment for their client.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how adaptive exercise supports safe, healthy prenatal conditioning.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's prenatal profile or safety risk.
- Clinical Safety & Programming Analysis: Explain PAGA 2018 pregnancy guidelines and biomechanical adaptations for your client.
- My Clinical Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why eliminating motionless supine postures after 16–20 weeks gestation, avoiding Valsalva breath-holding, and training in climate-controlled indoor spaces protect maternal-fetal perfusion in Yuma's heat under PAGA 2018 prenatal standards.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 04 Coaching Sprint • Track 1 (Clinical / Laura)

- Chosen Track & Client: Track 1: Clinical & Hospital Outpatient Path (Laura, 32). Challenge: Laura is in her second trimester experiencing pelvic girdle discomfort and lumbar lordosis, seeking safe core stabilization guidance.
- Track 1: Clinical & Hospital Outpatient Path (Laura, 32).
- Challenge: Laura is in her second trimester experiencing pelvic girdle discomfort and lumbar lordosis, seeking safe core stabilization guidance.
- Clinical Safety & Programming Analysis: PAGA 2018 Guidelines for Pregnancy: Relaxin hormone increases joint laxity while a shifting center of gravity accentuates lumbar lordosis, predisposing prenatal clients to lower back and pelvic girdle pain. High-load core exercises that strain the linea alba (such as traditional crunches or planks) increase risk of diastasis recti. Clinical protocols require deep transversus abdominis activation, neutral spine alignment, and avoidance of excessive spinal extension. Exercise intensity should be regulated using the "talk test" or moderate RPE scale (12 to 14) to maintain safe core body temperature and fetal oxygen delivery.
- PAGA 2018 Guidelines for Pregnancy: Relaxin hormone increases joint laxity while a shifting center of gravity accentuates lumbar lordosis, predisposing prenatal clients to lower back and pelvic girdle pain. High-load core exercises that strain the linea alba (such as traditional crunches or planks) increase risk of diastasis recti. Clinical protocols require deep transversus abdominis activation, neutral spine alignment, and avoidance of excessive spinal extension.
- Exercise intensity should be regulated using the "talk test" or moderate RPE scale (12 to 14) to maintain safe core body temperature and fetal oxygen delivery.
- My Clinical Safety Audit for Laura: "Replace traditional crunches with quadruped bird-dogs and modified side-planks to stabilize the deep core without intra-abdominal overpressure, and incorporate hip mobility stretches to alleviate lumbar strain per PAGA 2018."
- "Replace traditional crunches with quadruped bird-dogs and modified side-planks to stabilize the deep core without intra-abdominal overpressure, and incorporate hip mobility stretches to alleviate lumbar strain per PAGA 2018."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Laura's second-trimester core and pelvic floor conditioning requires three mandatory physiological modifications that generic AI ab routines miss. First, after 16–20 weeks gestation, lying flat on the back (supine) allows the gravid uterus to compress the inferior vena cava, triggering Supine Hypotensive Syndrome, reduced maternal venous return, and decreased uteroplacental blood flow. Second, relaxin-induced ligamentous laxity and anterior center-of-gravity shifts destabilize the sacroiliac joint. By replacing supine crunches with incline, side-lying, and quadruped bird-dog stabilization while enforcing continuous breathing (no Valsalva) and indoor climate control below 90°F in Yuma, we meet the PAGA 2018 150-minute moderate prenatal standard safely."
- My Memorable Coaching Takeaway: EN: "During pregnancy, training the core is about stability and posture, not flat abs!" ES: "¡Durante el embarazo, entrenar el núcleo se trata de estabilidad y postura, no de abdominales planos!"
- EN: "During pregnancy, training the core is about stability and posture, not flat abs!"
- ES: "¡Durante el embarazo, entrenar el núcleo se trata de estabilidad y postura, no de abdominales planos!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M04_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 04 (Mod 04 Coaching Sprint: Posture, Balance & Warning Signs in Pregnancy)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 04 Simulación de Coaching: Embarazo y Biomecánica

Evaluación Rápida y Auditoría de Seguridad Prenatal


### Su Logro Semanal: Navegando la Biomecánica Prenatal

Esta sesión le permitirá aplicar las directrices clínicas de PAGA 2018 para auditar cambios posturales, laxitud articular y posicionamiento supino durante el embarazo. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-265 Embarazo y Biomecanica ###:
Rol: Coach Especialista en Ejercicio Clinico de KIN-265 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) y Opinion N. 804 de ACOG.

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla las directrices clinicas de PAGA 2018 para la prescripcion de ejercicio prenatal, incluyendo cambios posturales, laxitud articular y seguridad en posicion supina tras 16 semanas.
Step 3: Guiar al estudiante para proponer UN protocolo de seguridad clinica o ajuste en la prescripcion de ejercicio para su cliente.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como el ejercicio adaptativo apoya un acondicionamiento prenatal seguro.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el perfil prenatal o riesgo de seguridad de su cliente.
- Análisis de Seguridad Clínica y Programación: Explique las directrices de PAGA 2018 sobre embarazo y biomecánica para su cliente.
- Mi Auditoría de Seguridad Clínica: Escriba 1 parámetro de seguridad claro y basado en evidencia o ajuste en la prescripción.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué eliminar las posturas boca arriba después de las semanas 16–20, evitar la maniobra de Valsalva y entrenar en interiores climatizados protege la perfusión materno-fetal en el calor de Yuma según PAGA 2018.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, el entrenamiento de Laura en el segundo trimestre requiere tres compuertas fisiológicas que las rutinas genéricas de IA ignoran. Primero, después de las semanas 16–20, acostarse boca arriba comprime la vena cava inferior, provocando el Síndrome Hipotensivo Supino y reduciendo el flujo sanguíneo placentario. Segundo, la hormona relaxina aumenta la laxitud articular pélvica. Al cambiar los ejercicios supinos por posturas inclinadas o en cuatro puntos sin maniobra de Valsalva y bajo techo climatizado en Yuma, cumplimos con los 150 minutos prenatales de PAGA 2018 con total seguridad."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 04)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
