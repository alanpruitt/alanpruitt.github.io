## KIN-265: Mod 13 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 13) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 13 Coaching Sprint Simulation: Preventing Falls & Heat Fatigue in Nerve Conditions

Sesión de Coaching del Módulo 13: Patologías del Sistema Nervioso Central y Seguridad en el Movimiento

- Uhthoff's Phenomenon in Multiple Sclerosis (Thermosensitivity Gate): Even a 0.5°C rise in core body temperature temporarily blocks demyelinated nerve conduction in MS, worsening vision, balance, and weakness; mandate <72°F indoor AC, cooling vests/fans, and cool water in Yuma. En palabras sencillas: En Esclerosis Múltiple el calor empeora de inmediato la fuerza y el equilibrio (Fenómeno de Uhthoff); es obligatorio entrenar bajo techo frío (<72°F) con ventilador y agua fresca en Yuma.
- Parkinson's Freezing of Gait & External Rhythmic Cueing: Using visual floor lines, metronome beats, wide-stance stepping, and big-amplitude movements (LSVT BIG principles) to bypass basal ganglia gait freezing. En palabras sencillas: Usar líneas visuales en el piso, ritmo con palmadas o metrónomo y pasos amplios para ayudar al paciente con Parkinson a destrabar la marcha.
- Post-Stroke Hemiparesis & Fall-Safe Seated/Recumbent Ergometry: Securing the affected limb (foot straps/grip assist) on a recumbent stepper or cycle ergometer and training task-specific sit-to-stand and balance transfers. En palabras sencillas: Usar bicicleta reclinada o aparatos con soporte seguro para el lado afectado tras una embolia (EVC), cuidando siempre el equilibrio.
- KIN-265.13.1.AY26-27: Prescribe safe dual-task and neuroplasticity-focused exercise intensity for clients recovering from stroke, Parkinson's disease, or multiple sclerosis across diverse career tracks. Prescribir intensidad de ejercicio seguro de doble tarea y enfocado en la neuroplasticidad para clientes con ACV, Parkinson o esclerosis múltiple en diversas rutas profesionales.
- KIN-265.13.2.AY26-27: Audit neurological RPE/stability limits and apply delimiter-based AI verification protocols. Auditar límites neurológicos de RPE/estabilidad y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering Neuroplasticity Rules & Thermal Safety Protocols

How can fitness professionals safely monitor exercise intensity when a client is managing central nervous system pathologies? Because standard metrics do not capture autonomic or thermal strain, exercise specialists use Rating of Perceived Exertion (RPE) tracking, balance stability rules, and climate-controlled environments (72°F / 22°C). Following strict PAGA 2018 clinical guidelines, trainers promote neuroplasticity while mitigating fall and heat-stress risks. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master neurological safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente padece patologías del sistema nervioso central? Usando seguimiento de RPE, reglas de estabilidad y ambientes climatizados (22°C) de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría neurológica!

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Neurological Fall-Risk, Gait Stability & Uhthoff's Heat Safety Auditor (/simulators/fall-risk-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate >=3 days/week balance/proprioceptive training, seated/supported safety transitions, and <80°F indoor cooling for Stroke, Parkinson's, and Multiple Sclerosis (PAGA 2018 Ch. 6). Copy your VERIFIED simulator receipt or slider values into the submission template below.

Open Neurological Fall-Risk, Gait Stability & Uhthoff's Heat Safety Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale)

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/fall-risk-auditor y "PAGA"): Calibre >=3 días/semana de equilibrio, soporte seguro contra caídas y ambiente fresco (<80°F) para EVC, Parkinson y Esclerosis Múltiple (PAGA 2018 Cap. 6). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Post-stroke outpatient rehabilitation client experiencing left-sided hemiparesis and balance deficits; establishing neuroplasticity-focused functional conditioning.

Scenario: Community center participant with early-stage Parkinson's Disease (Hoehn and Yahr Stage 2); formulating a dual-task agility and stability routine.

Scenario: First responder recovering from mild traumatic brain injury with vestibular and thermal sensitivity; designing a climate-controlled conditioning protocol.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Marcus, Elena, or Officer Davis).
- Neurological Analysis: Explain the key central nervous system or thermal regulation consideration for your selected client.
- My Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment utilizing the Safety Auditor protocol.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 13 Coaching Sprint • Track 1 (Marcus)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Marcus (Age 58).
- Neurological Analysis: Marcus is 6 months post-stroke with left hemiparesis and balance deficits. Because cortical reorganization relies on task-specific repetition, we use progressive gait re-education and monitor exertion using RPE rather than traditional heart rate alone.
- My Safety Audit for Marcus: "Monitor Marcus's movement stability and keep RPE between 3–5/10 during gait retraining, ensuring adequate rest intervals to prevent fatigue-induced form breakdown per PAGA 2018 guidelines."
- "Monitor Marcus's movement stability and keep RPE between 3–5/10 during gait retraining, ensuring adequate rest intervals to prevent fatigue-induced form breakdown per PAGA 2018 guidelines."
- My Memorable Coaching Takeaway: EN: "Rewiring the brain after a stroke takes consistent practice and careful balance support!" "¡Reconectar el cerebro después de un derrame cerebral requiere práctica constante y apoyo cuidadoso del equilibrio!"
- EN: "Rewiring the brain after a stroke takes consistent practice and careful balance support!"
- "¡Reconectar el cerebro después de un derrame cerebral requiere práctica constante y apoyo cuidadoso del equilibrio!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M13_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 13 (Mod 13 Coaching Sprint: Preventing Falls & Heat Fatigue in Nerve Conditions)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 13 Simulación de Coaching: Patologías del SNC y Seguridad en el Movimiento

Evaluación Rápida y Auditoría de Seguridad Neurológica


### Su Logro Semanal: Dominando la Neuroplasticidad y los Protocolos de Seguridad Térmica

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar seguimiento de RPE, estabilidad y ambientes climatizados en pacientes neurológicos. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Paciente post-ACV con hemiparesia izquierda; establecer reeducación de marcha enfocada en neuroplasticidad.

Escenario: Participante con Parkinson (Etapa 2); formular movimientos de amplitud y rutina de estabilidad de doble tarea.

Escenario: Primer respondedor con síndrome postconmoción y sensibilidad al calor; diseñar protocolo de estabilización en clima controlado.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Marcus, Elena u Officer Davis).
- Análisis Neurológico: Explique la consideración clave del sistema nervioso central o la regulación térmica para su cliente.
- Mi Auditoría de Seguridad: Escriba 1 parámetro de seguridad claro o ajuste de prescripción usando la escala de RPE.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 13, Sesión de Coaching • Ruta 1 (Marcus)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Marcus (58 años).
- Análisis Neurológico: Marcus está post-ACV con hemiparesia. Como la neuroplasticidad requiere práctica repetitiva, usamos reeducación de marcha y monitoreamos el esfuerzo con RPE.
- Mi Auditoría de Seguridad para Marcus: "Monitorear la estabilidad de Marcus y mantener el RPE entre 3–5/10 durante el entrenamiento de marcha, asegurando descansos para prevenir fatiga según PAGA 2018."
- "Monitorear la estabilidad de Marcus y mantener el RPE entre 3–5/10 durante el entrenamiento de marcha, asegurando descansos para prevenir fatiga según PAGA 2018."
- Mi Frase Inolvidable de Coaching: EN: "Rewiring the brain after a stroke takes consistent practice and careful balance support!" "¡Reconectar el cerebro después de un derrame cerebral requiere práctica constante y apoyo cuidadoso del equilibrio!"
- EN: "Rewiring the brain after a stroke takes consistent practice and careful balance support!"
- "¡Reconectar el cerebro después de un derrame cerebral requiere práctica constante y apoyo cuidadoso del equilibrio!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M13_Quiz_Sprint.pdf
KIN-265 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 13)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 13)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
