## KIN-265: Mod 14 Summary And Wrap Up Cancer Recovery And Fatigue Management

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 14 Summary & Wrap-Up: Cancer Recovery & Fatigue Management


### Congratulations on Completing Module 14!

You have successfully navigated Module 14 and mastered the core principles of exercise oncology, cancer survivorship, fatigue management, and exercise prescription for special populations with oncological histories. This week, you explored how cancer treatments impact energy levels and skeletal integrity, why fitness professionals rely on energy envelope pacing and bone-loading precautions, and how federal guidelines in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) establish safe survivorship threshold tracking.

By combining oncological risk auditing, symptom-guided Frequency, Intensity, Time, Type (FITT) prescription rules, and mandatory triple-hash delimiter protocols (`###`), you are fully prepared to design safe exercise programs for cancer survivors across clinical and community settings.


### Clinical Framing Protocol (Pattern / Rule / Solve) Synthesis: Module 14 Key Takeaways

- Pattern (Oncological Pathophysiology & Fatigue): Cancer treatments induce chronic fatigue, cardiotoxicity, and skeletal fragility, making energy envelope pacing and skeletal loading precautions essential during physical exertion.
- Rule (PAGA 2018 Standards): Exercise intensity must be monitored alongside symptom-guided RPE tracking. Trainers must avoid heavy loading on compromised bone metastasis sites and utilize compression garments for upper-extremity lymphedema.
- Solve (Prescription Design): Build customized aerobic and resistance routines while accommodating environmental comfort, utilizing climate-controlled indoor facilities (72°F / 22°C) and Safety Auditor prompt delimiters (`###`).

### Module 14 Knowledge Check (Self-Check Review)

Click on each question below to check your understanding of oncology monitoring and safety principles:

English Response: CRF is disproportionate to recent activity and does not resolve with standard rest, making structured physical activity necessary to restore energy.

Respuesta en Español: La CRF es desproporcionada a la actividad reciente y no se resuelve con el descanso estándar, lo que hace necesaria la actividad física estructurada.

English Response: Avoid high-impact loading, heavy resistance, and twisting or spinal flexion forces on compromised skeletal sites to prevent pathological fractures.

Respuesta en Español: Evitar cargas de alto impacto, resistencia pesada y fuerzas de torsión o flexión espinal en sitios óseos comprometidos para prevenir fracturas patológicas.

English Response: They provide external support that assists lymphatic drainage and prevents excessive fluid accumulation in the affected arm.

Respuesta en Español: Proporcionan soporte externo que ayuda al drenaje linfático y previene la acumulación excesiva de líquido en el brazo afectado.

English Response: It is a pacing framework that ensures daily physical activity stays within the client's available energy reserve to avoid post-exertional malaise.

Respuesta en Español: Es un marco de regulación que asegura que la actividad física diaria se mantenga dentro de la reserva de energía disponible del cliente.

English Response: They protect clients from extreme desert heat stress and environmental contaminants while supporting safe conditioning.

Respuesta en Español: Protegen a los clientes del estrés extremo por calor desértico y contaminantes ambientales mientras apoyan un acondicionamiento seguro.

English Response: To enclose oncology client case data securely, preventing prompt drift and ensuring reliable AI tool performance.

Respuesta en Español: Encerrar de forma segura los datos del caso clínico oncológico, evitando la deriva de instrucciones y garantizando un rendimiento confiable de la IA.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición).

English Response: Moderate physical activity enhances immune surveillance, reduces systemic inflammation, and improves overall cellular immune response.

Respuesta en Español: La actividad física moderada mejora la vigilancia inmunológica, reduce la inflamación sistémica y mejora la respuesta inmune celular general.

English Response: To identify undisclosed metastasis sites, evaluate cardiac function following chemotherapy, and establish safe hematological thresholds.

Respuesta en Español: Para identificar sitios de metástasis no divulgados, evaluar la función cardíaca tras la quimioterapia y establecer umbrales hematológicos seguros.


### Workplace Intelligence & AI Skills Competency Audit

In this Module, you demonstrated professional workforce readiness by leveraging Generative AI (Google Gemini) as an oncology safety auditing partner. You practiced key workplace AI competencies:

You enclosed oncology case data within triple-hash delimiters (`###`), maintaining structured data boundaries required in professional AI workflows.

You cross-examined AI recommendations against federal SSoT standards (PAGA 2018), auditing for safe fatigue pacing and bone metastasis rules.

You generated bilingual client instruction cards in English and Spanish to support diverse regional populations in Yuma County.

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 15 — Comorbidities, Polypharmacy & Integrated Case Management

In plain English, next week in Module 15: Comorbidities, Polypharmacy & Integrated Case Management you will learn what to do when a real-world client walks in with three or four conditions at the same time (for example, Hypertension + Type 2 Diabetes + Knee Osteoarthritis) and takes multiple daily medications. Why it matters: you will master the 'Most Restrictive Safety Gate' rule so that fixing one condition never triggers an emergency in another.

- Pattern (Context): Auditing multi-morbid client cases and polypharmacy interactions (e.g., beta-blockers + insulin/secretagogues + diuretics in Yuma heat).
- Rule (Constraint): Governing every session by the most restrictive clinical safety gate across all conditions while maintaining PAGA 2018 multi-domain benefits.
- Solve (Intervention): Completing Mod 15 Discussion: Multi-Condition Safety Prioritization and Mod 15 Lab: Multi-Condition & Polypharmacy Plan .
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 14 (Mod 14 Summary & Wrap-Up: Cancer Recovery & Fatigue Management)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All wrap-up materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are fully mobile-responsive and screen-reader compatible.

Español: Todos los materiales de cierre en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 14 Resumen y Cierre del Módulo


### ¡Felicidades por completar el Módulo 14!

Ha completado con éxito el Módulo 14 y dominado los principios de oncología del ejercicio, supervivencia al cáncer, manejo de la fatiga y prescripción para poblaciones con antecedentes oncológicos. Esta semana exploró cómo los tratamientos afectan los niveles de energía y la integridad esquelética, por qué confiamos en el ritmo de reserva energética y precauciones óseas, y cómo las pautas federales en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) establecen el seguimiento de umbrales.

Al combinar la auditoría de riesgo oncológico, las reglas de prescripción FITT guiadas por síntomas y los protocolos de delimitadores de tres numerales (`###`), usted está preparado para diseñar programas seguros para sobrevivientes de cáncer en entornos clínicos y comunitarios.


### Síntesis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Puntos Clave del Módulo 14

- Patrón (Fisiopatología Oncológica y Fatiga): Los tratamientos oncológicos inducen fatiga crónica, cardiotoxicidad y fragilidad esquelética, haciendo vital el ritmo de reserva energética y las precauciones óseas.
- Regla (Normas PAGA 2018): Monitorear la intensidad con seguimiento de RPE guiado por síntomas, evitando cargas pesadas en sitios de metástasis y usando prendas de compresión para linfedema.
- Solución (Prescripción): Construir rutinas aeróbicas y de fuerza adaptadas al entorno de Yuma, usando instalaciones climatizadas (22°C) y delimitadores (`###`).

#### Inteligencia en el Entorno Laboral y Competencia en IA

En este módulo demostró su preparación profesional al utilizar la IA generativa (Google Gemini) como socio en la auditoría de seguridad oncológica:

- Protocolo de Delimitadores: Encerró los datos del cliente entre tres numerales (`###`) para mantener la integridad de los datos.
- Verificación con IA: Verificó las recomendaciones de la IA frente a las normas federales PAGA 2018 y umbrales de fatiga.
- Comunicación Bilingüe: Generó tarjetas de instrucciones bilingües en inglés y español.
PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 15 — Comorbilidades, Polifarmacia y Manejo Integrado de Casos

En palabras sencillas (Contexto Norteño): en la vida real rara vez llega un paciente con un solo diagnóstico; lo normal en nuestra clínica es atender a alguien que tiene presión alta, diabetes tipo 2 y dolor de rodillas al mismo tiempo y toma varias medicinas (polifarmacia). La próxima semana aprenderás a aplicar siempre la regla de seguridad más estricta como preparación directa para tu defensa final del Módulo 16.

- Patrón (Contexto): Auditar casos con múltiples condiciones crónicas e interacciones de medicamentos (betabloqueadores, insulina y diuréticos) en el calor.
- Regla (Restricción): Regir cada sesión por el límite de seguridad clínica más estricto de todas las condiciones bajo PAGA 2018 .
- Solución (Intervención): Completar el Foro del Mód 15 (Multi-Condition Safety Prioritization) y el Laboratorio del Mód 15 (Multi-Condition & Polypharmacy Plan) .
KIN-265 • Module 14 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 14:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 14)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
