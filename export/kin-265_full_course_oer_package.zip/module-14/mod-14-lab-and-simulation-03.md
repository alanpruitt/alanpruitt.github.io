## KIN-265: Mod 14 Lab And Simulation 03

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 14) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 14 Lab & Simulation: Cancer Survivorship Exercise Plan Audit

- Cancer-Related Fatigue (CRF) & Daily Autoregulated Pacing: Unlike normal fatigue, CRF is not relieved by rest alone; short, light-to-moderate bouts (10–30 min at RPE 11–12) reduce CRF when volume is adjusted daily to treatment cycles. En palabras sencillas: La fatiga por tratamiento de cáncer mejora con caminatas y fuerza suave de 10 a 30 minutos (RPE 11–12), ajustando la sesión según cómo amanezca el paciente cada día.
- Lymphedema & Post-Surgical Resistance Progression: Gradual, low-load progressive resistance training is safe and does not trigger lymphedema when progressed slowly while monitoring for limb heaviness or swelling (compression sleeve if prescribed). En palabras sencillas: El ejercicio de fuerza progresivo y suave es seguro tras cirugía de cáncer; subimos peso poco a poco vigilando que no haya inflamación en el brazo o pierna.
- Chemotherapy/Radiation Safety Gates (Anemia, Neutropenia & Cardiotoxicity): Avoid public pools/crowded gyms during severe neutropenia (infection risk), avoid swimming over irradiated skin, and monitor HR/RPE closely after cardiotoxic chemotherapy. En palabras sencillas: Si las defensas están bajas por quimioterapia, evitar albercas públicas o gimnasios llenos para prevenir infecciones y vigilar de cerca el corazón.

### Lab Overview: Oncology Risk Audit & PAGA 2018 Prescription Formulation

In this laboratory practical, you will execute a comprehensive oncology risk audit and formulate an evidence-based exercise prescription for a client presenting with cancer-related fatigue, bone metastases, or post-treatment deconditioning.

You will apply the Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in federal standards ( PAGA 2018 ) and use the Gemini AI Tool Kit with secure triple-hash delimiters (###) to audit your clinical safety.


### Lab Logistics & Deadlines / Logística y Fechas Límite

- Due Date / Fecha Límite: Monday, November 23, 2026, at 11:59 PM MST / Lunes 23 de noviembre de 2026 a las 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry / Entrada de texto directa en Canvas
- Points / Puntos: 30 Total Points (10/7/0 Exemplary / Competent / Recalibrate Scale)
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Part A: Choose Your Career Track & Clinical Case File / Seleccione su Ruta y Caso Clínico

Client: 52-year-old female, breast cancer survivor with persistent CRF and mild left-arm lymphedema. Prescribe gradual aerobic and compression-supported strength routine. Cliente: Mujer de 52 años, sobreviviente de cáncer de mama con CRF y linfedema leve. Prescriba rutina aeróbica gradual y fuerza con compresión.

Client: 70-year-old male in prostate cancer remission with stable thoracic bone metastases and osteopenia. Implement spine-safe aerobic walking and balance routine. Cliente: Varón de 70 años en remisión de próstata con metástasis óseas estables. Implemente caminata aeróbica segura y equilibrio.

Client: 48-year-old fire captain in lymphoma remission with peripheral neuropathy and deconditioning. Design a graduated occupational work-hardening protocol. Cliente: Capitán de bomberos de 48 años en remisión de linfoma con neuropatía. Diseñe protocolo de endurecimiento ocupacional.


### Part B: Clinical Framing Protocol (Pattern

Rule / Solve) Clinical Audit / Auditoría del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Pattern Recognition / Reconocimiento de Patrones: Identify all cancer-related fatigue markers, skeletal metastasis sites, and treatment contraindications. Identifique marcadores de fatiga, sitios de metástasis ósea y contraindicaciones de tratamiento.
- Rule Application / Aplicación de Reglas: Apply PAGA 2018 oncology parameters, energy envelope pacing, and skeletal loading rules. Aplique parámetros oncológicos de PAGA 2018, ritmo de reserva energética y reglas de carga esquelética.
- Problem Solving / Resolución de Problemas: Formulate a 3-phase Frequency, Intensity, Time, Type (FITT) prescription and oncological safety monitoring plan. Formule una prescripción FITT de 3 fases y un plan de monitoreo de seguridad oncológica.

### Part C: Gemini AI Tool Kit & Safety Auditor Protocol


```text
Safety Auditor Protocol: KIN-265 Module 14 Lab ###:
Role: Clinical Exercise Physiologist and Oncology Safety Auditor.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Audit the student's oncology case audit and FITT prescription.
Step 2: Evaluate adherence to PAGA 2018 standards, fatigue pacing, and bone/lymphedema safety rules.
Step 3: Verify secure delimiter usage (###).

Client Data Input ###:
Career Track: [Insert Track 1, 2, or 3]
Client Case Summary: [Insert summary]
Student Clinical Framing Protocol (Pattern / Rule / Solve) Analysis: [Insert student analysis]
Student FITT Prescription: [Insert prescription]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Submission Template / Plantilla de Entrega


```text
KIN-265 Module 14 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Tactical]

Step 1: Pattern Recognition (Oncology Risk Audit):
Key Point: Client Profile & Treatment Baselines (Resting BP/HR, CRF/Bone/Neuropathy notes):
Key Point: Absolute/Relative Contraindications Identified:

Step 2: Rule Application (PAGA 2018 Standards):
Key Point: FITT Oncology & Pacing Parameters:
Key Point: Intensity Monitoring (Energy Envelope & Skeletal Loading Precautions):

Step 3: Problem Solving (Prescription & Safety Plan):
Key Point: 3-Phase Prescription:
Key Point: Oncological Modifications & Emergency Stop Limits:

Step 4: AI Tool Kit Audit Reflection:
Key Point: Summary of Gemini AI Safety Auditor feedback and delimiter compliance:
End Submission ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric / Rúbrica de Calificación (30 Points Total • 10/7/0 Scale)

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 14 (Mod 14 Lab: Cancer Survivorship Exercise Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard).

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 14 Lab: Prescripción de Ejercicio Oncológico y Auditoría


### Visión General del Laboratorio: Auditoría de Riesgo Oncológico y PAGA 2018

En esta práctica de laboratorio, ejecutarás una auditoría integral de riesgo oncológico y formularás una prescripción de ejercicio para un cliente con fatiga, metástasis óseas o desentrenamiento.

Aplicarás el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) anclado en normas federales ( PAGA 2018 ) y usarás la Caja de Herramientas Gemini con delimitadores seguros (###).


### Logística de Laboratorio y Fechas Límite

- Fecha Límite: Lunes 23 de noviembre de 2026 a las 11:59 PM MST
- Formato: Entrada de texto directa en Canvas
- Puntaje: 30 Puntos Totales (Escala 10/7/0 Exemplary / Competent / Recalibrate)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Seleccione su Ruta y Caso Clínico

Elija la ruta profesional correspondiente a su enfoque:

Mujer de 52 años, sobreviviente de cáncer de mama con CRF y linfedema leve. Prescriba rutina aeróbica gradual y fuerza con compresión.

Varón de 70 años en remisión de próstata con metástasis óseas estables. Implemente caminata aeróbica segura y equilibrio.

Capitán de bomberos de 48 años en remisión de linfoma con neuropatía. Diseñe protocolo de endurecimiento ocupacional.


### Parte B: Auditoría del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Reconocimiento de Patrones: Identifique marcadores de fatiga y precauciones óseas.
- Aplicación de Reglas: Aplique parámetros de PAGA 2018 y ritmo de reserva energética.
- Resolución de Problemas: Formule una prescripción FITT de 3 fases y un plan de monitoreo.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 14 Quick Return Navigation / Regreso Rápido al Módulo 14:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 14)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
