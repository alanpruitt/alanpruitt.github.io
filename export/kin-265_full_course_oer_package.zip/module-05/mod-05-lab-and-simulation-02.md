## KIN-265: Mod 05 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 05) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 05 Coaching Sprint Simulation: Pacing & Breathing Tips for COPD & Asthma

Sesión de Coaching del Módulo 05: Patologías Pulmonares (EPOC y Asma)

- Modified Borg Dyspnea Scale (0–10 Shortness of Breath Target: 3–4): In COPD and asthma, exercise intensity is titrated to a moderate dyspnea rating of 3 to 4 on the 0–10 scale alongside pulse oximetry monitoring. En palabras sencillas: En pacientes con EPOC o asma regulamos el paso usando la escala de falta de aire (manteniéndola en nivel moderado de 3 a 4 sobre 10).
- Pursed-Lip Breathing (1:2 Inhale-to-Exhale Ratio): Inhaling through the nose for 2 seconds and exhaling slowly through pursed lips for 4 seconds creates positive airway pressure that prevents small-airway collapse and air trapping. En palabras sencillas: Inhalar por la nariz y soltar el aire despacio con los labios fruncidos (el doble de tiempo al exhalar) para vaciar bien los pulmones y calmar la falta de aire.
- Exercise-Induced Bronchoconstriction (EIB) & Warm-Up Gate: Gradual 10–15 minute warm-ups, indoor climate control away from dust/pollen/dry heat, and keeping a prescribed rescue bronchodilator inhaler within arm's reach. En palabras sencillas: Calentar suave de 10 a 15 minutos bajo techo libre de polvo y tener siempre a la mano el inhalador de rescate del paciente.
- KIN-265.5.1.AY26-27: Apply PAGA 2018 clinical guidelines for oxygen saturation monitoring, dyspnea scaling, and exercise prescription in chronic pulmonary conditions. Aplicar las pautas clínicas de PAGA 2018 para la monitorización de oxígeno, escalas de disnea y prescripción en afecciones pulmonares.
- KIN-265.5.2.AY26-27: Audit clinical safety parameters, bronchodilator protocols, and environmental trigger mitigations for clients with COPD and asthma. Auditar parámetros de seguridad clínica, protocolos de broncodilatadores y mitigación de desencadenantes ambientales.

### Your Weekly Win: Breathing Freedom Through Exercise

How can structured exercise improve functional capacity and reduce breathlessness for individuals managing chronic obstructive pulmonary disease (COPD) or asthma? Pulmonary conditioning strengthens respiratory accessory muscles, improves peripheral oxygen extraction efficiency, and relieves exercise anxiety. Following strict PAGA 2018 clinical guidelines, exercise specialists audit environmental triggers, monitor SpO2 levels, and design safe interval protocols. Choose your coaching track below, chat with your AI Socratic Coach, and master clinical safety auditing!

¿Cómo puede el ejercicio estructurado mejorar la capacidad funcional y reducir la falta de aire en EPOC o asma? La rehabilitación pulmonar fortalece los músculos respiratorios y mejora la extracción de oxígeno. ¡Elija su ruta y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés vocacional

Scenario: Pulmonary rehabilitation patient (Arthur, 68) with moderate COPD who experiences rapid oxygen desaturation and severe dyspnea during walking at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Hospital Outpatient Path
[CLIENT]: Pulmonary Rehab Patient with COPD (Arthur, 68) | [LOCATION]: Yuma, AZ
[SITUATION]: Diagnosed with moderate COPD (GOLD Stage II). Experiences breathlessness and SpO2 drops below 88% during light aerobic walking, causing exercise anxiety.
[COACHING GOAL]: Apply PAGA 2018 clinical guidelines to audit oxygen saturation monitoring, dyspnea rating scales (Modified Borg 0-10 Scale), and interval pacing strategies for Arthur.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Pulmonary Rehabilitation.
###
```

Scenario: High school student with exercise-induced asthma (Maya, 16) who avoids physical education class due to fear of sudden bronchospasm attacks in Yuma County.


```text
###
[TRACK]: Track 2 - Community & Senior Wellness Path
[CLIENT]: High School Student with Asthma (Maya, 16) | [LOCATION]: Yuma County, AZ
[SITUATION]: Experiences exercise-induced bronchospasm (EIB) during dry, dusty outdoor sports. She skips workouts to avoid acute wheezing and coughing.
[COACHING GOAL]: Audit bronchodilator inhaler protocols (rescue SABA timing 15 minutes prior), environmental trigger awareness (AQI), and extended interval warm-up strategies for asthma management.
[COMMUNITY SITE]: Yuma County Public Health Services District & High School Athletic Centers.
###
```

Scenario: Adult fitness client with mild persistent asthma (David, 35) wanting to start high-intensity interval training (HIIT) without triggering respiratory distress.


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Conditioning Path
[CLIENT]: Adult Fitness Client with Asthma (David, 35) | [LOCATION]: Yuma, AZ
[SITUATION]: Wants to perform high-intensity workouts but lacks understanding of ventilatory thresholds, humidity/dust triggers, and pacing mechanics.
[COACHING GOAL]: Audit intensity regulation, breathing mechanics (pursed-lip breathing), and environmental modifications to ensure safe cardiorespiratory conditioning.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-265 Pulmonary Pathologies Tool Box ###:
Role: Supportive KIN-265 Clinical Exercise Specialist Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chapter 7 Active Adults with Chronic Conditions (Pulmonary Focus).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms PAGA 2018 clinical guidelines for pulmonary conditioning, including oxygen saturation monitoring, dyspnea rating (Modified Borg 0-10 Scale), and bronchodilator safety.
Step 3: Guide the student to give their client ONE clinical safety protocol or exercise prescription adjustment.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how controlled breathing and structured pacing restore exercise confidence.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's pulmonary condition or respiratory risk.
- Clinical Safety & Programming Analysis: Explain PAGA 2018 pulmonary guidelines, SpO2 thresholds, and dyspnea monitoring for your client.
- My Clinical Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying why Borg CR10 dyspnea gating ($3\text{–}4/10$), $\text{SpO}_2 \ge 88\%$ monitoring, and pursed-lip breathing intervals protect your Yuma client with COPD or asthma.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 05 Coaching Sprint • Track 1 (Clinical / Arthur)

- Chosen Track & Client: Track 1: Clinical & Hospital Outpatient Path (Arthur, 68). Challenge: Arthur has moderate COPD (GOLD Stage II), experiences rapid oxygen desaturation and severe breathlessness during walking, and has developed exercise anxiety.
- Track 1: Clinical & Hospital Outpatient Path (Arthur, 68).
- Challenge: Arthur has moderate COPD (GOLD Stage II), experiences rapid oxygen desaturation and severe breathlessness during walking, and has developed exercise anxiety.
- Clinical Safety & Programming Analysis: PAGA 2018 Guidelines for COPD: Chronic obstructive pulmonary disease leads to air trapping, dynamic hyperinflation, and inefficient gas exchange. Clinical exercise protocols require continuous pulse oximetry monitoring, maintaining SpO2 at or above 88% to 90%. Dyspnea must be monitored using the Modified Borg 0 to 10 Scale, keeping exertion between 3 ("moderate") and 4 ("somewhat severe"). Interval training (e.g., 2 minutes walking followed by 2 minutes of seated rest) is superior to continuous exertion. Incorporate pursed-lip breathing mechanics to prolong exhalation, reduce dynamic hyperinflation, and ease respiratory distress.
- PAGA 2018 Guidelines for COPD: Chronic obstructive pulmonary disease leads to air trapping, dynamic hyperinflation, and inefficient gas exchange. Clinical exercise protocols require continuous pulse oximetry monitoring, maintaining SpO2 at or above 88% to 90%. Dyspnea must be monitored using the Modified Borg 0 to 10 Scale, keeping exertion between 3 ("moderate") and 4 ("somewhat severe"). Interval training (e.g., 2 minutes walking followed by 2 minutes of seated rest) is superior to continuous exertion.
- Incorporate pursed-lip breathing mechanics to prolong exhalation, reduce dynamic hyperinflation, and ease respiratory distress.
- My Clinical Safety Audit for Arthur: "Implement continuous SpO2 monitoring with a hard stop threshold of 88%, structure interval walking bouts paired with rest, and coach Arthur in pursed-lip breathing techniques in a seated tripod position to manage breathlessness per PAGA 2018."
- "Implement continuous SpO2 monitoring with a hard stop threshold of 88%, structure interval walking bouts paired with rest, and coach Arthur in pursed-lip breathing techniques in a seated tripod position to manage breathlessness per PAGA 2018."
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, generic fitness plans that prescribe continuous high-intensity cardio by heart rate alone are unsafe for Yuma clients with COPD or asthma because dynamic hyperinflation and dry desert dust rapidly trigger air trapping and hypoxemia. By anchoring our session in PAGA 2018 pulmonary guidelines, we regulate effort strictly at 3 to 4 out of 10 on the Borg CR10 Dyspnea Scale, verify pulse oximetry stays at or above 88% SpO2, and use 1:2 pursed-lip exhalation during interval walking to keep small airways open. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- My Memorable Coaching Takeaway: EN: "With pulmonary conditions, controlled breathing and interval pacing turn impossible endurance into achievable wins!" ES: "¡Con afecciones pulmonares, la respiración controlada y el ritmo por intervalos convierten la resistencia imposible en logros alcanzables!"
- EN: "With pulmonary conditions, controlled breathing and interval pacing turn impossible endurance into achievable wins!"
- ES: "¡Con afecciones pulmonares, la respiración controlada y el ritmo por intervalos convierten la resistencia imposible en logros alcanzables!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M05_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 05 (Mod 05 Coaching Sprint: Pacing & Breathing Tips for COPD & Asthma)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 05 Simulación de Coaching: Patologías Pulmonares (EPOC y Asma)

Evaluación Rápida y Auditoría de Seguridad Pulmonar


### Su Logro Semanal: Respirando con Libertad a Través del Ejercicio

Esta sesión le permitirá aplicar las directrices clínicas de PAGA 2018 para monitorizar la saturación de oxígeno, escalar la disnea y estructurar la rehabilitación pulmonar segura. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-265 Patologias Pulmonares ###:
Rol: Coach Especialista en Ejercicio Clinico de KIN-265 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Capitulo 7 Adultos con Condiciones Cronicas (Enfoque Pulmonar).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla las directrices clinicas de PAGA 2018 para el acondicionamiento pulmonar, incluyendo la monitorizacion de la saturacion de oxigeno, la escala de disnea (Escala Modificada de Borg 0-10) y la seguridad con broncodilatadores.
Step 3: Guiar al estudiante para dar a su cliente UN protocolo de seguridad clinica o ajuste en la prescripcion de ejercicio.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la respiracion controlada y el ritmo restauran la confianza en el ejercicio.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y la condición pulmonar o riesgo respiratorio de su cliente.
- Análisis de Seguridad Clínica y Programación: Explique las directrices de PAGA 2018 sobre umbrales de SpO2 y control de disnea para su cliente.
- Mi Auditoría de Seguridad Clínica: Escriba 1 parámetro de seguridad claro y basado en evidencia o ajuste en la prescripción.
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica justificando por qué la escala de disnea Borg CR10 ($3\text{–}4/10$), el límite $\text{SpO}_2 \ge 88\%$ y la respiración con labios fruncidos protegen a su cliente con EPOC o asma en Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Ejemplo de La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): "En mi juicio clínico, guiar el ejercicio solo por frecuencia cardíaca en pacientes con EPOC o asma en Yuma es riesgoso por el atrapamiento aéreo y el polvo del desierto. Aplicando PAGA 2018, regulamos el esfuerzo en 3 a 4 sobre 10 de la escala Borg CR10, vigilamos que la oximetría se mantenga en $\text{SpO}_2 \ge 88\%$ y aplicamos respiración con labios fruncidos (1:2) por intervalos."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 05)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
