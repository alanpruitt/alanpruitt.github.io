## KIN-265 (Module 05 Overview): Exercise for Special Populations: Adapted Physical Activity & Chronic Conditions

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 05 Overview: Breathing & Lung Conditions (COPD & Asthma)


### Welcome to Module 05: Breathing & Lung Conditions (COPD & Asthma)

Welcome to Week 5! This week, we evaluate respiratory pathologies, focusing on Chronic Obstructive Pulmonary Disease (COPD) and Exercise-Induced Bronchospasm (EIB) using our academic Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) . Unlike healthy populations where heart rate reserve dictates cardiovascular intensity, pulmonary exercise prescription relies strictly on subjective ventilatory strain (Modified 0 to 10 Borg Dyspnea Scale) and pulse oximetry thresholds (SpO2).

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will audit dynamic hyperinflation, apply federal chronic condition safety mandates (terminating exercise if arterial oxygen saturation drops below 88%), and construct interval-based conditioning protocols featuring pursed-lip breathing cues tailored to clinical, community, and athletic populations across Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 15, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 17, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 20, 2026, at 11:59 PM MST
- Lab 05 Direct Submission / Entrega de Laboratorio: Monday, September 21, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 05 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze the pathophysiological mechanisms of air trapping, dynamic hyperinflation, dyspnea onset, and arterial oxygen desaturation (SpO2) during physical exertion. Analizar los mecanismos fisiopatológicos de atrapamiento de aire, hiperinsuflación dinámica y desaturación de oxígeno (SpO2).
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) chronic condition mandates, utilizing the Modified 0 to 10 Borg Dyspnea Scale (targeting 3 to 4) and safety stop-test thresholds (SpO2 less than 88%). Aplicar normas de PAGA 2018 regulando la intensidad mediante la escala de disnea de Borg (3 a 4) y límites de seguridad (SpO2 menor a 88%).
- CLO 3 (Problem Solving): Formulate an individualized, interval-based physical activity prescription incorporating pursed-lip breathing cues, environmental air quality monitoring, and bilingual patient education cards. Diseñar una prescripción de ejercicio por intervalos con respiración con labios fruncidos y tarjetas educativas bilingües.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit pulmonary exercise prescription across your chosen career track:

Outpatient pulmonary rehabilitation, continuous pulse oximetry monitoring, supplemental oxygen titrations, and GOLD Stage II COPD management at Matador Clinical Partners (MCP).

Auditing Air Quality Index (AQI) levels, managing particulate triggers, and organizing indoor climate-controlled walking groups for retired agricultural workers in Yuma County.

Managing Exercise-Induced Bronchospasm (EIB), structuring refractory period interval warm-ups, and optimizing inhaler timing for athletes in arid desert climates.


### Module 05 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Clinical Readings: Respiratory Kinetics & PAGA Standards
- Discussion Board 05: Dyspnea Rating Scales vs. Heart Rate Limits
- Lab Assignment 05: Pulmonary Prescription & Gemini AI Simulation
- Module 05 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 05 (Mod 05 Overview: Breathing & Lung Conditions (COPD & Asthma))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 05 Visión General: Patologías Pulmonares (EPOC/Asma)


### Bienvenido al Módulo 05: Cinética Respiratoria y Prescripción Guiada por Disnea

¡Bienvenido a la Semana 5! Esta semana estudiamos las patologías respiratorias, enfocándonos en la Enfermedad Pulmonar Obstructiva Crónica (EPOC) y el Broncoespasmo Inducido por el Ejercicio (BIE) . A diferencia de las personas sanas, la prescripción de ejercicio pulmonar se guía estrictamente por la escala de disnea percibida y los límites de saturación de oxígeno por pulsioximetría (SpO2).

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , auditará el atrapamiento de aire, aplicará las normas de PAGA 2018 (2.ª edición) para condiciones crónicas (detener el ejercicio si la SpO2 cae por debajo del 88%) y diseñará rutinas por intervalos adaptadas a su ruta profesional.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 17 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 20 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 05: Lunes, 21 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar los mecanismos fisiopatológicos del atrapamiento de aire, la hiperinsuflación dinámica y la desaturación de oxígeno (SpO2).
- CLO 2 (Regla): Aplicar las normas de PAGA 2018 regulando la intensidad con la escala de disnea de Borg (3 a 4) y límites de seguridad (SpO2 menor al 88%).
- CLO 3 (Solución): Diseñar prescripciones de ejercicio por intervalos con respiración con labios fruncidos y tarjetas educativas bilingües.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la prescripción pulmonar a través de su ruta profesional:

Rehabilitación pulmonar ambulatoria, monitoreo de pulsioximetría, titulación de oxígeno y manejo de EPOC en Matador Clinical Partners (MCP).

Auditoría del Índice de Calidad del Aire (AQI), control de alérgenos y grupos de caminata climatizados para trabajadores agrícolas retirados en Yuma.

Manejo del broncoespasmo inducido por el ejercicio (BIE), calentamiento con intervalos refractarios y uso de inhaladores en clima desértico.


### Ruta de Aprendizaje del Módulo 05

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Clínicas Obligatorias: Cinética Respiratoria y Pautas PAGA 2018
- Foro de Discusión 05: Escalas de Disnea vs. Límites de Frecuencia Cardíaca
- Laboratorio 05: Prescripción de Ejercicio Pulmonar y Consulta de IA
- Comprobación de Conocimientos y Resumen del Módulo 05

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 05 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 05 Required Readings: Breathing & Lung Conditions (COPD & Asthma) →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 05 Discussion: Using the Breathlessness Scale for COPD & Asthma →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 05 Coaching Sprint: Pacing & Breathing Tips for COPD & Asthma →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 05 Lab: COPD & Asthma Exercise Safety Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 05 Summary & Wrap-Up: Breathing & Lung Conditions (COPD & Asthma) →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 05)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
