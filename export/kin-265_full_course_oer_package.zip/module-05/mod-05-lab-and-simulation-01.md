## KIN-265: Mod 05 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 05 Lab & Simulation: COPD & Asthma Exercise Safety Audit

Laboratorio del Módulo 05: Auditoría de Seguridad del Ejercicio en EPOC y Asma


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Clients with COPD or asthma often stop moving because breathlessness feels scary, which weakens their muscles and makes breathing even harder. In this lab, you will use the Borg 0–10 breathlessness scale ($3\text{–}4/10$), a finger pulse oximeter ($\text{SpO}_2 \ge 88\%$), and pursed-lip breathing intervals so your Yuma client can build stamina safely without trapping air in the lungs.

En Palabras Sencillas (Contexto Norteño): Cuando alguien tiene EPOC o asma, sentir que le falta el aire da miedo y hace que deje de moverse, pero quedarse quieto debilita más el cuerpo. Si los términos técnicos se ponen pesados, concéntrate primero en vigilar que el oxímetro no baje de $88\%$, mantener la falta de aire en $3\text{–}4$ sobre $10$ y enseñar a soplar despacio con los labios fruncidos.

- Modified Borg Dyspnea Scale (0–10 Shortness of Breath Target: 3–4): In COPD and asthma, exercise intensity is titrated to a moderate dyspnea rating of 3 to 4 on the 0–10 scale alongside pulse oximetry monitoring. En palabras sencillas: En pacientes con EPOC o asma regulamos el paso usando la escala de falta de aire (manteniéndola en nivel moderado de 3 a 4 sobre 10).
- Pursed-Lip Breathing (1:2 Inhale-to-Exhale Ratio): Inhaling through the nose for 2 seconds and exhaling slowly through pursed lips for 4 seconds creates positive airway pressure that prevents small-airway collapse and air trapping. En palabras sencillas: Inhalar por la nariz y soltar el aire despacio con los labios fruncidos (el doble de tiempo al exhalar) para vaciar bien los pulmones y calmar la falta de aire.
- Exercise-Induced Bronchoconstriction (EIB) & Warm-Up Gate: Gradual 10–15 minute warm-ups, indoor climate control away from dust/pollen/dry heat, and keeping a prescribed rescue bronchodilator inhaler within arm's reach. En palabras sencillas: Calentar suave de 10 a 15 minutos bajo techo libre de polvo y tener siempre a la mano el inhalador de rescate del paciente.

### Lab Objectives / Objetivos del Laboratorio

- KIN-265.5.1.AY26-27: Audit dynamic hyperinflation (air trapping), oxyhemoglobin desaturation ($\text{SpO}_2 < 88\%$), and Exercise-Induced Bronchoconstriction (EIB) against PAGA 2018 (2nd Ed.) pulmonary standards.
- KIN-265.5.2.AY26-27: Prescribe interval aerobic/resistance conditioning, Borg CR10 dyspnea gating ($3\text{–}4/10$), and pursed-lip breathing ($1:2$ ratio) using the Clinical Framing Protocol (Pattern / Rule / Solve) .
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-05 / Fase 1: Selección de Escenario de Simulación Clínica


```text
STRUCTURAL_DELIMITER_BOUND_1 ###:
[CASE FILE]: #265-05A (Track 1: Clinical & Pulmonary Rehab Path)
[CLIENT]: Sr. Ernesto V., Age 68 (Yuma, AZ; Gold Stage II-III COPD; Resting SpO2: 93% on room air; Resting HR: 84 bpm)
[CLINICAL PRESENTATION]: Attempting continuous 20-minute treadmill walking at 2.4 mph causes rapid shallow breathing, accessory neck muscle recruitment, Borg CR10 dyspnea spike to 7/10 at minute 6, and SpO2 drop to 86%. Generic AI workout told him to "push through to 75% HRmax for 20 continuous minutes."
[CLINICAL TASK]: Audit the AI error, enforce the SpO2 >= 88% and Borg CR10 3-4/10 safety gates, and redesign using interval walking + pursed-lip breathing.
STRUCTURAL_DELIMITER_BOUND_1 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_2 ###:
[CASE FILE]: #265-05B (Track 2: Community Wellness & Active Aging Path)
[CLIENT]: Doña Lucía R., Age 63 (Somerton, AZ; Mild COPD + Adult-Onset Asthma; Resting SpO2: 95%)
[CLINICAL PRESENTATION]: Avoids walking outdoors during Yuma's agricultural harvest season due to dust and wind; quadriceps deconditioning causes early leg fatigue and breathlessness (Borg CR10 5/10) when climbing steps. Generic AI plan prescribed outdoor noon walking and overhead high-rep shoulder presses without breathing cues.
[CLINICAL TASK]: Audit environmental triggers and upper-extremity accessory muscle fatigue, and design an indoor PAGA 2018 interval + lower-body resistance program.
STRUCTURAL_DELIMITER_BOUND_2 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_3 ###:
[CASE FILE]: #265-05C (Track 3: Sports & Tactical Conditioning Path)
[CLIENT]: Diego M., Age 20, Collegiate Soccer Midfielder (Yuma, AZ; Exercise-Induced Bronchoconstriction; Albuterol SABA prescribed)
[CLINICAL PRESENTATION]: Launches directly into maximal 400m dry-air sprints (12% humidity, PM10 dust advisory) with zero warm-up and leaves rescue inhaler in locker room; develops wheezing, chest tightness, and Borg CR10 dyspnea 7/10 within 8 minutes.
[CLINICAL TASK]: Audit evaporative airway cooling/dehydration triggers, enforce the 15-minute progressive warm-up refractory period and rescue inhaler readiness, and design a PAGA-compliant conditioning session.
STRUCTURAL_DELIMITER_BOUND_3 ###:
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Consulta de IA


```text
Safety Auditor Protocol — KIN-265 Module 05 Lab ###:
Act as my KIN-265 Clinical Pulmonary Exercise Specialist Preceptor. Evaluate the client case wrapped in triple-hashes (###) below using PAGA 2018 (2nd Ed.) and pulmonary rehabilitation safety standards:
Step 1: PATTERN: Identify the respiratory limitation (dynamic hyperinflation, SpO2 desaturation < 88%, or dry-air Exercise-Induced Bronchoconstriction) and critique the unsafe AI recommendation.
Step 2: RULE: Cite PAGA 2018 pulmonary guidelines, the Borg CR10 Dyspnea Scale (3-4/10 target), and the SpO2 >= 88% stop gate.
Step 3: SOLVE: Design a 4-week interval aerobic + resistance protocol with pursed-lip breathing (1:2 ratio), warm-up refractory pacing, Yuma air-quality safeguards, and a 2-sentence bilingual instruction card (EN/ES). Remind me to write my 150-word minimum Active Verification (Part 3) in my own human voice!
Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Requirements

- Selected Track & Client Initials: State your chosen case (#265-05A, #265-05B, or #265-05C).
- Part 1: Pattern Recognition (Pulmonary & AI Error Audit): Diagnose the respiratory mechanism (dynamic hyperinflation, $\text{SpO}_2$ desaturation, or EIB bronchospasm) and identify why the generic AI workout is clinically unsafe.
- Part 2: Rule Application (PAGA 2018 & Pulmonary Safety Gates): Cite PAGA 2018 (2nd Ed.) , the Borg CR10 Dyspnea target ($3\text{–}4/10$) , and the $\text{SpO}_2 \ge 88\%$ pulse oximetry safety gate.
- Part 3: Solving the Gap (Interval Prescription & Bilingual Card): Provide a 4-week interval aerobic + resistance plan with pursed-lip breathing ($1:2$ ratio), warm-up pacing, Yuma air-quality modifications, and a 2-sentence bilingual client card (EN/ES).
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying why Borg CR10 dyspnea gating, $\text{SpO}_2 \ge 88\%$ monitoring, and pursed-lip intervals protect your Yuma client.
- Part 5: Repository Verification: Confirm archiving in EXW_Professional_AI_Repository / EXW_265_M05_Pulmonary_Safety_Audit.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Selected Track: Track 1 (#265-05A • Sr. Ernesto V., Age 68, Gold Stage II–III COPD, Yuma, AZ).

Part 1: Pattern Recognition: Continuous treadmill walking at 2.4 mph shortens Ernesto's expiratory window, trapping air in his alveoli (dynamic hyperinflation), escalating his Borg CR10 dyspnea score to $7/10$, and dropping his oxyhemoglobin saturation to $\text{SpO}_2\ 86\%$. The generic AI recommendation to "push through to 75% HRmax for 20 continuous minutes" is dangerous because ventilatory mechanics—not cardiac output—limit COPD exertion, and exercising below $\text{SpO}_2\ 88\%$ induces acute hypoxemia and right-ventricular strain.

Part 2: Rule Application (PAGA 2018 & Pulmonary Safety Gates): Under PAGA 2018 (2nd Ed.) and pulmonary rehabilitation guidelines, intensity must be gated at $3\text{–}4/10$ on the Borg CR10 Dyspnea Scale (moderate breathlessness), and exertion must stop immediately if pulse oximetry drops below $\text{SpO}_2\ 88\%$ . Interval bouts ($1\text{–}3\text{ minutes}$) accumulate total PAGA weekly volume without triggering air trapping.

Part 3: Solving the Gap (4-Week Interval Prescription & Bilingual Card): Key Point — Aerobic Intervals (3–5 days/week, indoor climate-controlled facility): 10 cycles of 2 minutes walking at 1.8 mph followed by 1 minute seated recovery leaning slightly forward on the console (tripod recovery), keeping Borg CR10 at $3\text{–}4/10$ and $\text{SpO}_2 \ge 90\%$. Key Point — Breathing Mechanics: Continuous pursed-lip breathing ($1:2$ ratio) —inhale 2 seconds through the nose, exhale 4 seconds gently through pursed lips. Key Point — Peripheral Resistance (2 days/week): Seated leg press, seated row, and chair sit-to-stands (2 sets of 10 reps, exhaling through pursed lips on exertion) to improve peripheral muscle oxygen extraction. EN Card: "Walk in two-minute intervals and breathe out slowly through pursed lips for four counts so trapped air leaves your lungs easily. Pause and rest whenever your breathlessness reaches 4 out of 10 or your finger oximeter reads below 88 percent." ES Card: "Camine en intervalos de dos minutos y sople despacio con los labios fruncidos contando hasta cuatro para vaciar el aire atrapado en sus pulmones. Descanse siempre que su falta de aire llegue a 4 sobre 10 o si su oxímetro de dedo baja de 88 por ciento."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI workout treats COPD like standard cardiovascular deconditioning by prescribing 20 continuous minutes at 75% HRmax. For Sr. Ernesto, continuous walking shortens exhalation time, traps air in damaged bronchioles, spikes dyspnea to 7/10, and drops his SpO2 to an unsafe 86%. As his human clinician, I enforce the PAGA 2018 and pulmonary rehab safety gates: we stop immediately below SpO2 88% and cap dyspnea at 3 to 4 on the Borg CR10 scale. Switching to two-minute indoor walking intervals with 1:2 pursed-lip exhalation generates back-pressure that keeps his small airways open, allowing him to build lower-body strength safely in Yuma. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."

Part 5: Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M05_Pulmonary_Safety_Audit.pdf .


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 05 (Mod 05 Lab: COPD & Asthma Exercise Safety Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 05 Laboratorio y Simulación: Auditoría de Seguridad del Ejercicio en EPOC y Asma

- Parte 1 (Patrón): Diagnostique la limitación respiratoria (hiperinflación dinámica en EPOC, desaturación $\text{SpO}_2 < 88\%$ o broncoespasmo por aire seco y polvo en Yuma) y el error de la IA.
- Parte 2 (Regla): Cite PAGA 2018, la escala de disnea Borg CR10 ($3\text{–}4/10$) y el límite de oximetría de pulso ($\text{SpO}_2 \ge 88\%$).
- Parte 3 (Solución): Diseñe un plan de 4 semanas por intervalos con respiración de labios fruncidos ($1:2$) y tarjeta bilingüe (EN/ES).
- Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica cómo el control por intervalos, Borg CR10 y $\text{SpO}_2 \ge 88\%$ protegen a su paciente en Yuma.
- Parte 5: Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository / EXW_265_M05_Pulmonary_Safety_Audit.pdf .
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 05)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
