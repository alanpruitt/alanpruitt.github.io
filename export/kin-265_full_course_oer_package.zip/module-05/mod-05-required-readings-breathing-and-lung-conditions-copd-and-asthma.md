## KIN-265: Mod 05 Required Readings Breathing And Lung Conditions Copd And Asthma

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 05 Required Readings: Breathing & Lung Conditions (COPD & Asthma)

Lecturas Clínicas Obligatorias: Cinética Respiratoria, Patologías Pulmonares y Prescripción Guiada por Disnea


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Chronic Obstructive Pulmonary Disease (COPD) and asthma narrow airways and trap air, making breathing during exertion feel exhausting. Using interval walking, pursed-lip breathing, and a pulse oximeter (keeping blood oxygen saturation SpO2 at or above 88–90%) allows clients to build stamina without severe breathlessness. Avoiding dry dust, high pollen, and extreme heat protects sensitive lungs.


#### En Palabras Sencillas (Norteño Context)

Cuando el aire pasa por un filtro tapado cuesta más trabajo acelerar; por eso usamos intervalos cortos y respiración con labios fruncidos. Si los términos técnicos se ponen pesados, concéntrate primero en el uso de la escala de disnea, la saturación de oxígeno (SpO2 >= 88%) y el calentamiento prolongado.


### Required SSoT Text & Federal Guidelines

Primary Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) (Chapter 7: Active Adults with Chronic Health Conditions and Disabilities • Pulmonary Special Populations Focus).

Primary SSoT Anchor: Chapter 7: Physical Activity for Adults with Chronic Health Conditions (COPD, Asthma & Pulmonary Rehabilitation).

- Official Federal Guidelines Portal: PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev)
- Course Offline Repository Document: exw265_ssot_special_populations_reference.docx (Download to study offline or upload to your AI Repository)
Clinical Focus: Ventilatory threshold gating, dynamic hyperinflation relief, and pulse oximetry stop-test limits.

- Target Volume: Accumulate 150 to 300 minutes of moderate physical activity weekly as tolerated, divided into short interval bouts.
- Intensity Gating: Intensity MUST be regulated via the Modified 0 to 10 Borg Dyspnea Scale (target 3 to 4: "moderate" to "somewhat severe") rather than target heart rate formulas.
- Stop-Test Safety Limit: Exercise must be terminated immediately if arterial oxygen saturation drops below 88% (SpO2 < 88%) on room air.
- Active Recovery: Pursed-lip breathing in a forward-leaning seated tripod position allows complete exhalation and active diaphragm recovery.

### Regional Focus: Air Quality & Thermal Strain in Yuma County

Enfoque Regional: Calidad del Aire, Polvo Agrícola y Prescripción en el Desierto

In Yuma County and regional agricultural border communities, ambient summer temperatures routinely exceed 105°F (40.5°C), often paired with low relative humidity and seasonal agricultural dust/pollen particulate spikes (elevated Air Quality Index, AQI). For individuals with COPD, chronic bronchitis, or Exercise-Induced Bronchospasm (EIB), inhaling hot, dry, dusty air accelerates airway mucosal dehydration and triggers severe bronchial constriction. Exercise specialists at Matador Clinical Partners (MCP) mandate indoor climate-controlled facilities (72°F / 22°C), AQI monitoring, extended refractory warm-ups (10 to 15 minutes of low-intensity intervals), and pre-exercise administration of short-acting beta2-agonists (SABA 15 minutes prior to exertion).

En el condado de Yuma y las comunidades agrícolas del desierto, el calor de más de 40.5°C (105°F) combinado con polvo y polen eleva el riesgo de broncoespasmo y descompensación en pacientes con EPOC y asma. Los especialistas de Matador Clinical Partners (MCP) exigen el uso de instalaciones climatizadas (22°C), monitoreo del índice de calidad del aire (AQI), calentamientos prolongados con intervalos refractarios y el uso de broncodilatadores (SABA) 15 minutos antes de la sesión.


### Reading 1: Pathophysiology of COPD & Dynamic Hyperinflation

Lectura 1: Fisiopatología de la EPOC y Atrapamiento Aéreo Dinámico


#### Step 1: Expiratory Airflow Limitation

Limitación del Flujo Aéreo Espiratorio

Chronic Obstructive Pulmonary Disease (COPD) is characterized by persistent, progressive airflow limitation resulting from a combination of chronic bronchitis (airway inflammation, mucus hypersecretion, and luminal narrowing) and emphysema (destruction of alveolar septa, loss of elastic recoil, and premature airway collapse during exhalation). Unlike healthy individuals who expire passively through elastic recoil, patients with COPD must recruit expiratory abdominal muscles, dramatically increasing baseline metabolic work.


#### Step 2: Dynamic Hyperinflation Mechanics

Mecánica de la Hiperinsuflación Dinámica

During physical exertion, increased metabolic demand elevates breathing frequency, which drastically shortens the expiratory time available for air to exit narrowed airways. Because exhalation is incomplete before the next breath begins, air progressively accumulates within the lungs (air trapping). This raises the end-expiratory lung volume (dynamic hyperinflation), pushing breathing mechanics toward total lung capacity:

- Diaphragmatic Flattening: High thoracic volumes push the diaphragm into a flattened, mechanically disadvantaged curvature, impairing its force-generating capacity and triggering accessory neck muscle recruitment.
- Ventilatory Panic Cycle: Increased work of breathing elevates sensory feedback to the cerebral cortex, precipitating severe dyspnea, anxiety, and early task termination long before true cardiovascular limits are reached.
- Pursed-Lip Breathing Countermeasure: Exhaling slowly through puckered lips creates positive back-pressure within the airways, preventing premature bronchiolar collapse, slowing respiratory frequency, and permitting complete alveolar emptying.

### Reading 2: Dyspnea Scale Gating & Pulse Oximetry Safety

Lectura 2: Regulación por Escala de Disnea y Seguridad en Pulsioximetría


#### Step 1: Modified Borg 0 to 10 Rating of Perceived Dyspnea (RPD) Scale


#### Step 2: Pulse Oximetry (SpO2) Safety Gating Rules

Reglas de Seguridad y Monitoreo de Pulsioximetría (SpO2)

- Resting Baseline: Document SpO2 on room air prior to exertion (Normal: 95% or higher; Mild COPD: 92% to 94%; Moderate/Severe COPD: 89% to 91%).
- Absolute Stop-Test Threshold: Immediately halt physical activity if arterial oxygen saturation drops below 88% (SpO2 < 88%) on room air (or below 90% in patients with pulmonary hypertension).
- Active Rest Interval Protocol: Have the client sit upright, lean slightly forward resting forearms on knees (tripod position to stabilize shoulder girdle and assist accessory inspiratory muscles), and execute pursed-lip breathing until SpO2 recovers to 90% or higher and dyspnea drops to 2 or below.

### Key Terminology / Glosario Clave

The progressive accumulation of air trapped in the lungs during exertion due to shortened exhalation time, which increases end-expiratory lung volume and severely limits inspiratory capacity.

Acumulación progresiva de aire atrapado en los pulmones durante el esfuerzo debido a un tiempo de espiración insuficiente, aumentando el volumen pulmonar y limitando la inspiración.

A breathing technique involving inhaling through the nose and exhaling slowly against puckered lips, creating positive end-expiratory pressure that splints open airways and facilitates complete lung emptying.

Técnica respiratoria que genera presión positiva espiratoria para evitar el colapso de las vías aéreas y facilitar el vaciado alveolar.

Acute, transient airway narrowing resulting from rapid thermal and water loss across the respiratory mucosa during high-ventilation exertion in dry or cold environments.

Estrechamiento agudo y transitorio de las vías aéreas por evaporación de agua y enfriamiento de la mucosa respiratoria durante el esfuerzo.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Cinética Respiratoria

Select each question below to confirm your understanding of pulmonary exercise mechanics before starting Discussion 05 and Lab 05:

English Response: In COPD, ventilatory limitations, dynamic hyperinflation, and impaired gas exchange cause patients to reach their ventilatory threshold and severe breathlessness long before achieving their age-predicted cardiovascular maximum heart rate. Furthermore, pulmonary medications (beta2-agonists, anticholinergics) alter baseline heart rate, making the Modified Borg 0 to 10 Dyspnea Scale (target 3 to 4) the sole reliable intensity standard.

Respuesta en Español: En la EPOC, la limitación ventilatoria y la hiperinsuflación dinámica hacen que el paciente alcance el agotamiento respiratorio antes de llegar a su frecuencia cardíaca máxima cardiovascular. Por ello, la intensidad DEBE regularse con la Escala Modificada de Disnea de Borg (meta 3 a 4) .

English Response: Under clinical safety standards, physical exercise must be stopped immediately if arterial oxygen saturation drops below 88% (SpO2 < 88%) on room air. The patient must be transitioned to a seated tripod position and execute pursed-lip breathing until SpO2 recovers to 90% or higher.

Respuesta en Español: El ejercicio debe detenerse de inmediato si la saturación arterial de oxígeno cae por debajo del 88% (SpO2 < 88%) en aire ambiente, requiriendo descanso sentado en posición de trípode con respiración con labios fruncidos hasta recuperar el 90% o más.

English Response: Short exercise bouts (1 to 2 minutes) paired with equal or longer structured rest intervals give the client time to lower their breathing frequency and fully expire trapped air, preventing the progressive buildup of end-expiratory lung volume and preserving diaphragmatic force generation.

Respuesta en Español: Los intervalos cortos (1 a 2 minutos) con descansos estructurados permiten reducir la frecuencia respiratoria y expulsar el aire atrapado, evitando la hiperinsuflación dinámica y preservando la función del diafragma.


### AI Simulation Workspace • Pulmonary Safety Auditor Simulation

Copy the prompt below into Gemini to audit pulmonary client profiles, screen for oxygen desaturation risks, and construct interval-based exercise prescriptions:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-265 Module 05 Pulmonary Tool Box ###:
Role: Clinical Exercise Physiologist and Pulmonary Rehabilitation Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chapter 7 Active Adults with Chronic Health Conditions.

Instructions:
Step 1: Audit the student's clinical case data enclosed within triple-hashes (###) below.
Step 2: PATTERN: Analyze their expiratory airflow limitation, dynamic hyperinflation mechanics, and arterial oxygen desaturation risks (SpO2).
Step 3: RULE: Apply federal PAGA 2018 chronic condition mandates, utilizing the Modified 0 to 10 Borg Dyspnea Scale (target 3 to 4) and absolute safety stop-test thresholds (SpO2 < 88%).
Step 4: SOLVE: Prescribe an interval-based aerobic and resistance conditioning plan adapted for indoor climate-controlled environments in Yuma County, incorporating pursed-lip breathing cues.
Step 5: Provide a 2-sentence bilingual patient instruction card in English and Spanish.

Client Data Input ###:
Client Age & Diagnosis: [e.g., 66-year-old with GOLD Stage II COPD]
Resting Metrics: [e.g., Resting SpO2: 91% on room air, Resting HR: 78 bpm]
Occupational / Environmental Background: [e.g., Retired agricultural supervisor in Yuma County]
Current Exercise Tolerance: [e.g., Reports severe dyspnea Borg 6 after 3 minutes continuous walking]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 05 (Mod 05 Required Readings: Breathing & Lung Conditions (COPD & Asthma))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. Digital OER text is fully accessible to screen readers without downloading external PDFs.

Español: Todos los materiales de lectura de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla sin descargas de pago.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Clínicas Obligatorias: Cinética Respiratoria y Normas PAGA


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) (Capítulo 7: Adultos con Enfermedades Crónicas • Patologías Pulmonares).

Herramienta Interactiva PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev)

- Regulación por Disnea: Regular la intensidad mediante la Escala Modificada de Borg (meta 3 a 4).
- Límite de Seguridad: Detener el ejercicio de inmediato si la saturación cae por debajo del 88% (SpO2 < 88%).
- Entrenamiento por Intervalos: Intervalos cortos de 1 a 2 minutos para evitar la hiperinsuflación dinámica.

### Conceptos Clínicos Centrales


#### Step 1: Hiperinsuflación Dinámica y Mecánica Diafragmática

El aumento de la frecuencia respiratoria durante el esfuerzo acorta el tiempo de espiración. El aire queda atrapado en los alvéolos, aplanando el diafragma y provocando disnea severa. La respiración con labios fruncidos genera presión positiva que mantiene abiertas las vías aéreas y facilita el vaciado pulmonar.


#### Step 2: Monitoreo de Pulsioximetría y Desaturación

El ejercicio debe suspenderse si la saturación de oxígeno cae por debajo del 88%. El paciente debe descansar sentado en posición de trípode con respiración con labios fruncidos hasta que la SpO2 se recupere a 90% o más.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 05 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 05:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 05)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
