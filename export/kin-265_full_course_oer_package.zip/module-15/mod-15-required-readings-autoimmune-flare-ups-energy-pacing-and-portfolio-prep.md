## KIN-265: Mod 15 Required Readings Autoimmune Flare Ups Energy Pacing And Portfolio Prep

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 15 Required Readings: Autoimmune Flare-Ups, Energy Pacing & Portfolio Prep

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from PAGA 2018 (2nd Ed., Chapters 5 & 6) & ACSM 12th Ed.), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 15): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Autoimmune and chronic fatigue conditions fluctuate between stable remission days and unpredictable inflammatory flare-ups. Energy-envelope pacing keeps exertion inside a safe daily ceiling so a workout today does not trigger post-exertional malaise (a severe energy crash tomorrow). Designing flexible Green / Yellow / Red day plans empowers clients to stay active year-round.


#### En Palabras Sencillas (Norteño Context)

Con las condiciones autoinmunes hay días verdes, amarillos y rojos: el buen entrenador ajusta la marcha sin vaciar la batería de reserva. Si los términos técnicos se ponen pesados, concéntrate primero en el sistema de semáforo (días verdes, amarillos y rojos) para evitar recaídas por agotamiento post-esfuerzo.


### Core Literature & Federal Standards (SSoT)

To successfully complete Module 15 workflows, portfolio synthesis, and laboratory assignments during Thanksgiving week, review the core readings below. All instructional materials are anchored strictly in our Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .

Examine how low-impact loading manages joint osteoarthritis, how systemic inflammation in autoimmune conditions alters pain management, and how to structure your terminal capstone portfolio.


### Reading 1: PAGA 2018 (2nd Ed.) & Joint Mechanics • Managing Arthritis Through Low-Impact Exercise

Learn how movement lubricates joints and reduces pain in osteoarthritis and rheumatoid arthritis. Contrary to the misconception that activity wears down arthritic joints, PAGA 2018 guidelines prove that appropriate low-impact aerobic and strengthening exercise reduces joint stiffness, strengthens supporting muscles, and lowers systemic inflammation.

Study Tip: Use the traffic-light pain scale during workouts to ensure joint discomfort remains within safe, manageable limits.

Lectura 1: PAGA 2018 (2.ª ed.) y mecánica articular • Manejo de la artritis mediante ejercicio de bajo impacto: Aprenda cómo el movimiento lubrica las articulaciones y reduce el dolor.


### Reading 2: Clinical Guidelines & Flare-Up Rules • Autoimmune Conditions and Fibromyalgia Pacing

Understand energy envelope theory and pacing strategies for managing fibromyalgia and autoimmune fatigue. Clients with widespread musculoskeletal pain and chronic fatigue require careful activity regulation to prevent symptom flare-ups. Trainers must apply gradual progression rules, monitor perceived exertion closely, and prioritize restorative recovery intervals.

Study Tip: Teach clients to stay within their daily energy envelope to avoid post-exertional malaise.

Lectura 2: Pautas clínicas y reglas de brotes • Condiciones autoinmunes y modulación de la fibromialgia: Comprenda la teoría de la reserva energética y las estrategias de ritmo.


### Reading 3: Capstone Synthesis & Portfolio Integration • Assembling Your Terminal Clinical Audit Package

Review the structural requirements for compiling your comprehensive Capstone Portfolio. Module 15 represents the heavy lift of course synthesis, requiring you to organize and audit all clinical case designs, prescription templates, and Clinical Framing Protocol (Pattern / Rule / Solve) problem sets accumulated across Modules 1 through 15 into a unified professional deliverable.

Study Tip: Double-check that every case study references PAGA 2018 standards and strict delimiter wrappers.

Lectura 3: Síntesis y integración de portafolio • Ensamblaje de su paquete de auditoría clínica terminal: Revise los requisitos estructurales para compilar su portafolio final.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 15 (Mod 15 Required Readings: Autoimmune Flare-Ups, Energy Pacing & Portfolio Prep)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading texts in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards.

Español: Todos los textos de lectura obligatoria en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard).

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Obligatorias del Módulo 15: Artritis, Autoinmunidad y Portafolio Final


### Literatura Principal y Normas Federales (SSoT)

Para completar con éxito las actividades del Módulo 15 y el portafolio durante la semana de Acción de Gracias, revise las lecturas ancladas en nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) .

Examine cómo el ejercicio de bajo impacto maneja la osteoartritis, cómo la inflamación sistémica afecta la fibromialgia y cómo estructurar su portafolio final.


### Lectura 1: PAGA 2018 (2.ª ed.) y mecánica articular • Manejo de la artritis

Aprenda cómo el movimiento adecuado reduce la rigidez articular, fortalece los músculos de soporte y disminuye la inflamación sistémica sin dañar el cartílago.

Consejo de estudio: Utilice la escala de dolor de semáforo durante los entrenamientos para mantener las molestias en niveles seguros.


### Lectura 2: Pautas clínicas • Condiciones autoinmunes y fibromialgia

Comprenda la teoría de la reserva energética y el uso de un ritmo adecuado para prevenir brotes de fatiga y dolor generalizado en clientes con fibromialgia.

Consejo de estudio: Enseña a los clientes a mantenerse dentro de su límite energético diario para evitar el malestar posejercicio.


### Lectura 3: Síntesis de portafolio • Integración del trabajo final

Revise los requisitos para organizar y auditar todas sus plantillas de casos clínicos y problemas del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) acumulados en los módulos 1 al 15.

Consejo de estudio: Compruebe que cada estudio de caso haga referencia a las normas PAGA 2018 y delimitadores estrictos.

KIN-265 • Module 15 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 15:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 15)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 15)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
