## KIN-265: Mod 15 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 15) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 15 Coaching Sprint Simulation: Daily Energy Pacing & Joint Protection

Sesión de Coaching del Módulo 15: Preservación Articular y Protocolos de Ritmo

- Energy Envelope Pacing & Preventing Post-Exertional Malaise (PEM): In fibromyalgia and chronic fatigue conditions, keeping session exertion within the client's available daily energy envelope prevents delayed 24–48 hour symptom crashes ('boom-and-bust' cycle). En palabras sencillas: Dosificar la energía para terminar la sesión sintiéndose con reserva, evitando el error de excederse un día y caer agotado o adolorido los siguientes dos días.
- Central Sensitization & Low-Threshold Warm-Water / Aerobic Onboarding: Starting at light-to-moderate intensity (Borg RPE 9–11, 10–15 min bouts) in warm water (83–88°F) or indoor walking to calm hyperexcitable pain pathways without triggering flares. En palabras sencillas: Empezar suave (10 a 15 minutos en RPE 9–11, en agua templada o caminata bajo techo) para bajar la sensibilidad al dolor sin provocar brotes.
- Special Populations Portfolio Triage & Documentation: Organizing multi-condition client cases by screening red flags first, mapping medication interactions second, and prescribing modified FITT-VP parameters third. En palabras sencillas: Ordenar tu portafolio clínico revisando primero señales de alerta, segundo medicamentos y tercero el plan FITT-VP adaptado.
- KIN-265.15.1.AY26-27: Prescribe safe low-impact and energy-paved exercise intensity for clients with arthritis or fibromyalgia across diverse career tracks. Prescribir intensidad de ejercicio seguro de bajo impacto para clientes con artritis o fibromialgia en diversas rutas.
- KIN-265.15.2.AY26-27: Audit clinical pain and flare-up limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de dolor y aplicar protocolos de verificación con IA basados en delimitadores.

### Your Weekly Win: Mastering Joint-Sparing Rules & Autoimmune Pacing

How can fitness professionals safely monitor exercise intensity when a client is managing arthritic joint effusion or fibromyalgia flare-ups? Because standard metrics do not capture joint stress or systemic inflammation, exercise specialists use traffic-light pain scales and energy envelope pacing. Following strict PAGA 2018 clinical guidelines, trainers protect joints while maintaining functional capacity during Thanksgiving week. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master musculoskeletal safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente padece derrame articular o brotes de fibromialgia? Usando escalas de dolor de semáforo y ritmo de reserva energética de PAGA 2018. ¡Elija una ruta, dialogue con su coach de IA y domine la auditoría musculoesquelética!

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Master Class Autoimmune Flare-Up & Daily Energy Pacing Auditor (/simulators/master-class-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate daily energy-envelope pacing, acute flare-up volume reductions (switching to gentle ROM when joints are hot/swollen), and KNYL heat-stress limits (PAGA 2018 Ch. 6). Copy your VERIFIED simulator receipt or slider values into the submission template below • Paired Autoimmune Energy Pacing route: /simulators/fatigue-pacing-auditor .

Open Master Class Autoimmune Flare-Up & Daily Energy Pacing Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale)

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/master-class-auditor y "PAGA"): Calibre el presupuesto diario de energía, la reducción de carga durante brotes inflamatorios agudos y la protección contra el calor KNYL (PAGA 2018 Cap. 6). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient clinical rehabilitation client with severe knee osteoarthritis and joint effusion; establishing aquatic therapy progression.

Scenario: Community center participant with fibromyalgia and chronic widespread fatigue; formulating an energy envelope pacing routine.

Scenario: Military instructor with rheumatoid arthritis flare-ups and joint inflammation; designing a symptom-guided adaptive strength protocol.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Clara, Margaret, or Master Sergeant Torres).
- Musculoskeletal/Autoimmune Analysis: Explain the key joint limitation or energy pacing consideration for your selected client.
- My Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment utilizing the Safety Auditor protocol.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 15 Coaching Sprint • Track 1 (Clara)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Clara (Age 65).
- Musculoskeletal Analysis: Clara has severe knee osteoarthritis with chronic effusion and pain (5/10). Because high-impact loading increases joint shear stress and irritation, we use aquatic therapy and stationary cycling to maintain conditioning while protecting the joint.
- My Safety Audit for Clara: "Monitor Clara's joint effusion and pain scale during aquatic workouts, ensuring joint discomfort remains below 3/10, and reduce range of motion immediately if swelling increases per PAGA 2018 guidelines."
- "Monitor Clara's joint effusion and pain scale during aquatic workouts, ensuring joint discomfort remains below 3/10, and reduce range of motion immediately if swelling increases per PAGA 2018 guidelines."
- My Memorable Coaching Takeaway: EN: "Unloading painful joints with aquatic exercise preserves mobility without adding wear and tear!" "¡Descargar las articulaciones dolorosas con ejercicio acuático preserva la movilidad sin añadir desgaste!"
- EN: "Unloading painful joints with aquatic exercise preserves mobility without adding wear and tear!"
- "¡Descargar las articulaciones dolorosas con ejercicio acuático preserva la movilidad sin añadir desgaste!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M15_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 15 (Mod 15 Coaching Sprint: Daily Energy Pacing & Joint Protection)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 15 Simulación de Coaching: Preservación Articular y Protocolos de Ritmo

Evaluación Rápida y Auditoría de Seguridad Articular


### Su Logro Semanal: Dominando las Reglas Articulares y el Ritmo Autoinmune

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar escalas de dolor y ritmo de reserva energética en pacientes con artritis o fibromialgia. ¡Elija una ruta, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Paciente con osteoartritis severa de rodilla y derrame; establecer terapia acuática y ciclismo de bajo impacto.

Escenario: Participante con fibromialgia y dolor generalizado; formular ritmo de reserva energética y movilidad restaurativa.

Escenario: Instructor con brotes de artritis reumatoide; diseñar protocolo adaptativo guiado por síntomas.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Clara, Margaret o Master Sergeant Torres).
- Análisis Musculoesquelético: Explique la consideración clave articular o de ritmo para su cliente.
- Mi Auditoría de Seguridad: Escriba 1 parámetro de seguridad claro o ajuste usando la escala de dolor.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 15, Sesión de Coaching • Ruta 1 (Clara)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Clara (65 años).
- Análisis Musculoesquelético: Clara tiene osteoartritis severa con derrame. Usamos terapia acuática para descargar la articulación mientras mantenemos condición física.
- Mi Auditoría de Seguridad para Clara: "Monitorear la inflamación y el dolor de Clara, asegurando que se mantenga por debajo de 3/10 durante el ejercicio acuático según PAGA 2018."
- "Monitorear la inflamación y el dolor de Clara, asegurando que se mantenga por debajo de 3/10 durante el ejercicio acuático según PAGA 2018."
- Mi Frase Inolvidable de Coaching: EN: "Unloading painful joints with aquatic exercise preserves mobility without adding wear and tear!" "¡Descargar las articulaciones dolorosas con ejercicio acuático preserva la movilidad sin añadir desgaste!"
- EN: "Unloading painful joints with aquatic exercise preserves mobility without adding wear and tear!"
- "¡Descargar las articulaciones dolorosas con ejercicio acuático preserva la movilidad sin añadir desgaste!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M15_Quiz_Sprint.pdf
KIN-265 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 15)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 15)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
