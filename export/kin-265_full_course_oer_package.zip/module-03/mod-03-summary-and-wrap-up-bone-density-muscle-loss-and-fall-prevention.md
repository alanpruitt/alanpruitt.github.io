## KIN-265: Mod 03 Summary And Wrap Up Bone Density Muscle Loss And Fall Prevention

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 03 Summary & Wrap-Up: Bone Density, Muscle Loss & Fall Prevention

Osteoporosis, Sarcopenia, Ley de Wolff y Prescripción Multicomponente PAGA 2018


### Step 1: Core Bone Remodeling & Geriatric Kinematics Synthesis

Congratulations on completing Module 03! You have mastered the clinical mechanics of bone remodeling under Wolff's Law, DXA T-score risk stratification, and multicomponent exercise programming tailored to older adults and individuals with compromised bone mineral density:

- Wolff's Law & Axial Mechanical Loading: Bone tissue remodels along lines of applied physical stress. Progressive axial gravitational resistance and muscle tensile forces stimulate osteoblast bone formation and counteract osteoclastic resorption.
- DXA T-Score Risk Stratification: Differentiated between normal bone density (T-score ≥ -1.0 SD), osteopenia (-1.0 to -2.49 SD), and osteoporosis (T-score ≤ -2.5 SD), identifying individuals at high risk for catastrophic fractures.
- Absolute Biomechanical Contraindications: Strictly prohibited loaded anterior spinal flexion (e.g., traditional sit-ups, toe touches), dynamic torso rotation with flexion, and high-impact ballistic landings to prevent vertebral wedge compression fractures.
- PAGA 2018 Multicomponent Mandate: Formulated comprehensive exercise routines combining progressive resistance training (≥2 days/week), dedicated balance training (≥3 days/week), and moderate aerobic activity (150–300 min/week) adapted for indoor climate-controlled spaces.

### Step 2: Workplace Intelligence & AI Clinical Auditing

In hospital outpatient clinics, senior living wellness centers, and specialized athletic facilities, exercise physiologists leverage generative AI preceptors to audit client DXA logs, screen for spinal movement contraindications, and structure personalized multicomponent balance protocols.

- AI-Assisted Biomechanical Screening: Specialists prompt AI assistants to audit exercise routines against strict spinal safety rules, replacing hazardous forward flexion with neutral-spine core stabilization.
- Delimiter Security Protocol (###): Client biometric metrics (DXA T-scores, TUG fall-risk time, kyphosis severity, medication profile) must remain enclosed inside triple hashes ( ### ) for data isolation during AI queries.
- Human-in-the-Loop Safeguard: All AI-generated progressions must be verified by a clinician against PAGA 2018 older adult standards to prevent orthostatic hypotension, environmental heat stress, and acute fracture risks.

### Step 3: Module 03 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 04:

English Response: Osteopenia represents low bone mass with a T-score between -1.0 and -2.49 SD below the young adult mean. Osteoporosis is defined by a T-score ≤ -2.5 SD , indicating severe bone demineralization and significantly elevated fracture risk requiring strict movement contraindications.

Respuesta en Español: La Osteopenia representa masa ósea baja con una puntuación T entre -1.0 y -2.49 DE . La Osteoporosis se define con una puntuación T ≤ -2.5 DE , lo que indica desmineralización severa y un riesgo elevado de fracturas que exige contraindicaciones estrictas.

English Response: Anterior trunk flexion shifts mechanical compressive loads directly onto the weakened anterior portion of the vertebral body. In osteoporotic bone, these forces generate catastrophic anterior shearing that triggers acute vertebral wedge compression fractures .

Respuesta en Español: La flexión anterior del tronco traslada las cargas de compresión hacia la parte anterior debilitada del cuerpo vertebral. En hueso osteoporótico, estas fuerzas generan un cizallamiento que provoca fracturas vertebrales por compresión en cuña .

English Response: PAGA 2018 mandates integrating: (1) Balance training (≥3 days/week) to reduce fall risk, (2) Muscle-strengthening / axial resistance training (≥2 days/week) to maintain bone mineral density and combat sarcopenia, and (3) Moderate aerobic activity (150–300 min/week) for cardiorespiratory health.

Respuesta en Español: PAGA 2018 exige combinar: (1) Entrenamiento de equilibrio (≥3 días/sem) para evitar caídas, (2) Fortalecimiento muscular y carga axial (≥2 días/sem) para preservar la densidad ósea y frenar la sarcopenia, y (3) Actividad aeróbica moderada (150 a 300 min/sem).

English Response: Wolff's Law states that bone tissue grows and remodels in response to the mechanical forces placed upon it, where mechanical stress stimulates osteoblast activity to increase bone density.

Respuesta en Español: La Ley de Wolff establece que el tejido óseo crece y se remodela en respuesta a las fuerzas mecánicas aplicadas, donde el estrés mecánico estimula la actividad osteoblástica para aumentar la densidad ósea.

English Response: Sarcopenia is the age-related loss of muscle mass and function. Progressive resistance training counters it by stimulating muscle protein synthesis and neuromuscular recruitment.

Respuesta en Español: La sarcopenia es la pérdida de masa y función muscular relacionada con la edad. El entrenamiento de resistencia progresiva la contrarresta estimulando la síntesis de proteínas musculares y el reclutamiento neuromuscular.

English Response: High-impact ballistic landings create rapid, high-magnitude ground reaction forces that fragile, demineralized trabecular bone cannot absorb, risking immediate fractures.

Respuesta en Español: Los impactos balísticos de alta intensidad generan fuerzas de reacción del suelo rápidas y de gran magnitud que el hueso trabecular frágil y desmineralizado no puede absorber, arriesgándose a fracturas inmediatas.

English Response: The triple-hash delimiter protocol securely encloses client biometric data and case parameters, preventing prompt drift and ensuring strict compliance with clinical safety guidelines.

Respuesta en Español: El protocolo de delimitadores de tres numerales encierra de forma segura los datos biométricos del cliente y los parámetros del caso, evitando la deriva de las instrucciones y asegurando el cumplimiento de las guías clínicas.

English Response: Balance training improves neuromuscular reaction time and postural stability, directly reducing the incidence of falls which are the primary triggering mechanism for osteoporotic fractures.

Respuesta en Español: El entrenamiento del equilibrio mejora el tiempo de reacción neuromuscular y la estabilidad postural, reduciendo directamente la incidencia de caídas, que son el mecanismo desencadenante principal de las fracturas osteoporóticas.

English Response: Extreme desert heat and high ambient temperatures accelerate dehydration and elevate cardiovascular strain, making indoor air-conditioned facilities (72°F / 22°C) vital for safe older adult training.

Respuesta en Español: El calor extremo del desierto acelera la deshidratación y eleva la sobrecarga cardiovascular, haciendo que las instalaciones climatizadas (22°C) sean vitales para el entrenamiento seguro de adultos mayores.


### AI Simulation Workspace • Bone Health Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive clinical review matrix connecting DXA classifications, contraindications, and multicomponent exercise design:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: KIN-265 Module 03 Bone Health Synthesis ###:
Role: Clinical Exercise Physiologist and Geriatric Mobility Specialist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) - Active Older Adults & Chronic Conditions.

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: DXA T-score ranges (Normal vs. Osteopenia vs. Osteoporosis).
   Key Point: Biomechanical loading targets under Wolff's Law (site-specific axial compression).
   Key Point: Absolute movement contraindications and safe neutral-spine exercise substitutes.
Step 2: Outline a 4-week multicomponent exercise progression (balance, axial strength, aerobic) for an older adult with elevated fall risk (TUG > 12.0s) in an indoor climate-controlled setting.
Step 3: Keep all inputs and structured recommendations wrapped within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 04 — Pregnancy & Postpartum Biomechanics

In plain English, next week in Module 04: Pregnancy & Biomechanics you will learn how to modify posture, core exercises, and temperature safety for pregnant and postpartum clients across all three trimesters. Why it matters: lying flat on the back after the first trimester can compress major blood vessels, and overheating in Yuma's summer sun is unsafe for fetal development—simple positioning and indoor cooling adjustments keep mom and baby thriving.

- Pattern (Context): Assessing trimester-specific center-of-gravity shifts, joint laxity (relaxin hormone), and core/pelvic-floor mechanics.
- Rule (Constraint): Applying PAGA 2018 Pregnancy & Postpartum Guidelines (150 min/week moderate aerobic activity, avoiding supine positions after Trimester 1, and avoiding extreme heat/contact risk).
- Solve (Intervention): Completing Mod 04 Discussion: Prenatal & Postpartum Modifications and Mod 04 Lab: Prenatal Exercise Prescription .

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 03 (Mod 03 Summary & Wrap-Up: Bone Density, Muscle Loss & Fall Prevention)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 03: Resumen y Evaluación

Osteoporosis, Sarcopenia, Ley de Wolff y Prescripción Multicomponente PAGA 2018


### Step 1: Síntesis de Remodelación Ósea y Cinemática Geriátrica

¡Felicitaciones por completar el Módulo 03! Ha dominado los principios de remodelación ósea bajo la Ley de Wolff, la estratificación del riesgo con puntuaciones T en DXA y la prescripción multicomponente para adultos mayores:

- Ley de Wolff y Carga Mecánica Axial: El tejido óseo se remodela según la tensión mecánica aplicada. La resistencia gravitacional axial y la tracción muscular estimulan la formación ósea osteoblástica y frenan la reabsorción osteoclástica.
- Estratificación de Riesgo con DXA: Diferenciación entre densidad ósea normal (T ≥ -1.0 DE), osteopenia (-1.0 a -2.49 DE) y osteoporosis (T ≤ -2.5 DE) para identificar el riesgo de fractura.
- Contraindicaciones Biomecánicas Absolutas: Prohibición estricta de la flexión espinal anterior con carga (abdominales tradicionales), torsión de tronco combinada con flexión e impacto balístico para prevenir fracturas vertebrales en cuña.
- Mandato Multicomponente de PAGA 2018: Diseño de rutinas integrales que combinan fuerza progresiva (≥2 días/sem), equilibrio dinámico (≥3 días/sem) y actividad aeróbica (150 a 300 min/sem) en interiores climatizados.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría con IA

En clínicas de rehabilitación, centros de bienestar para adultos mayores y gimnasios especializados, los fisiólogos del ejercicio utilizan IA generativa para auditar registros de DXA, verificar contraindicaciones espinales y diseñar protocolos de equilibrio personalizados.

- Detección Biomecánica Asistida por IA: Auditoría de rutinas frente a reglas de seguridad espinal, sustituyendo la flexión anterior por estabilización isométrica con columna neutra.
- Protocolo con Delimitadores (###): Las métricas clínicas (puntuaciones T, prueba TUG, cifosis) deben aislarse entre tres numerales ( ### ) para estructurar consultas de IA.
- Salvaguarda Clínica Humana: Todas las progresiones generadas por IA deben verificarse frente a PAGA 2018 para evitar hipotensión ortostática, estrés por calor y riesgos de fractura.

### Step 3: Autoevaluación del Módulo 03

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 04:


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: KIN-265 Sintesis Modulo 03 ###:
Rol: Fisiologo del Ejercicio Clinico y Especialista en Movilidad Geriatrica.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) - Adultos Mayores y Condiciones Cronicas.

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Rangos de puntuacion T en DXA (Normal vs. Osteopenia vs. Osteoporosis).
   Key Point: Metas de carga mecanica segun la Ley de Wolff (compresion axial especifica).
   Key Point: Contraindicaciones de movimiento y ejercicios sustitutos con columna neutra.
Step 2: Disenar una progresion de ejercicio multicomponente de 4 semanas (equilibrio, fuerza axial, aerobico) para un adulto mayor con riesgo de caidas (TUG > 12.0s) en interiores climatizados.
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 04 — Embarazo y Biomecánica Posparto

En palabras sencillas (Contexto Norteño): durante el embarazo el centro de gravedad cambia, los ligamentos se vuelven más flexibles y después del primer trimestre no se debe hacer ejercicio acostada boca arriba ni bajo el calor extremo de Yuma. Si los cambios fisiológicos se ponen pesados la próxima semana, concéntrate primero en la meta de 150 minutos semanales de actividad moderada de PAGA 2018 y en las señales de alerta obstétrica para detener la sesión.

- Patrón (Contexto): Evaluar cambios posturales por trimestre, laxitud articular, piso pélvico y termorregulación materna.
- Regla (Restricción): Aplicar las guías de PAGA 2018 para Embarazo y Posparto (150 min/semana moderados, evitar posición supina tras el 1.er trimestre y evitar hipertermia).
- Solución (Intervención): Completar el Foro del Mód 04 (Prenatal & Postpartum Modifications) y el Laboratorio del Mód 04 (Prenatal Exercise Prescription) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 03 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 03:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 03)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
