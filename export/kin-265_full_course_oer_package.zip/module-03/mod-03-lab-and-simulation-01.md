## KIN-265: Mod 03 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 03) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Lab & Simulation: Bone-Building & Fall-Safe Exercise Audit

Módulo 03 Laboratorio: Auditoría de Densidad Ósea (DXA), Sarcopenia y Prevención de Caídas

- Osteogenic Weight-Bearing & Resistance Loading (Wolff's Law): Bone remodels in response to mechanical strain; controlled weight-bearing aerobic and multi-joint resistance training stimulate osteoblast bone formation. En palabras sencillas: El hueso se fortalece cuando recibe carga segura de caminatas y ejercicios de fuerza bien controlados.
- Spinal Flexion & Twisting Contraindication in Osteoporosis: Loaded forward spinal flexion (sit-ups, toe touches) and rapid trunk rotation create excessive anterior vertebral compression and fracture risk. En palabras sencillas: En personas con osteoporosis quedan prohibidos los abdominales tradicionales o doblar la espalda con peso porque pueden causar fracturas vertebrales.
- Multicomponent Fall-Prevention Triad (Balance + Strength + Gait): Pairing tandem/single-leg balance drills with lower-extremity strength (chair sit-to-stands, step-ups) to reduce fall and hip-fracture incidence in older adults. En palabras sencillas: Combinar ejercicios de equilibrio con fuerza de piernas (levantarse de la silla, subir escalón) para evitar caídas y fracturas de cadera.
- Pattern (DXA & Fall Risk Stratification): Classify WHO DXA T-score (Osteopenia −1.0 to −2.4; Osteoporosis ≤ −2.5), 30-second Chair Stand / TUG fall risk (≥12.0 sec = elevated fall risk), and identify hazardous movements in the AI draft.
- Rule (PAGA 2018 & Wolff's Law Gate): Apply PAGA 2018 older adult multicomponent guidelines (150 min aerobic + ≥2 days resistance + ≥3 days balance) and enforce the strict contraindication against weighted spinal flexion , explosive high-impact jumps, and unsupported dynamic hazards.
- Solve & Mandatory Active Verification: Prescribe a 4-week neutral-spine osteogenic FITT-VP plan, a 2-sentence bilingual patient card (EN / ES), and a 150-word minimum Active Verification (Part 3) in your own voice.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-03


### Phase 2: Gemini AI Clinical Simulation Workspace


### Phase 3: Canvas Text Box Submission Requirements

- Part 1: Pattern Recognition (DXA, TUG & AI Error Audit): State the client's WHO DXA classification, TUG fall risk status, and explain why the AI-suggested exercises are biomechanically dangerous.
- Part 2: Rule Application (PAGA 2018 & Spinal Safety Gate): Cite the PAGA 2018 multicomponent older adult rules (aerobic + resistance + balance ≥3 days/week), Wolff's Law, and the strict prohibition on weighted spinal flexion/twisting.
- Part 3: Solve (FITT-VP Plan & Bilingual Patient Card): Provide a safe neutral-spine resistance, weight-bearing aerobic, and balance prescription plus a 2-sentence bilingual card (EN / ES).
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify how overriding the AI's spinal flexion and high-impact errors prevents vertebral compression fractures and falls in Yuma.
- Repository Verification: Confirm archive to EXW_Professional_AI_Repository / EXW_265_M03_Bone_Audit.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track: Track 1 — Clinical Outpatient Path (Elena M., Age 71, Lumbar T-Score −2.9, TUG 14.6s)

- Part 1: Pattern Recognition: Elena's lumbar DXA T-score of −2.9 places her in WHO-classified Osteoporosis (≤ −2.5), while her femoral neck (−2.4) is at the severe boundary of osteopenia. Her TUG score of 14.6 seconds (>12.0s threshold) and recent fall confirm high fall risk and lower-limb sarcopenia. The AI draft's medicine-ball crunches and toe touches create extreme anterior vertebral compressive shear, while box jumps risk catastrophic fall and fracture.
- Part 2: Rule Application (PAGA 2018 & Wolff's Law): Under PAGA 2018 (2nd Ed.) , older adults require multicomponent exercise: 150 min/week moderate weight-bearing aerobic activity, ≥2 days/week progressive resistance training, and ≥3 days/week balance training. Per Wolff's Law, osteogenic loading must be applied through a strictly neutral spine , with an absolute contraindication against weighted spinal flexion or ballistic rotation.
- Part 3: Solve & Bilingual Patient Card: Resistance (2 days/wk, RPE 12–13, Neutral Spine): Chair-supported hip-hinge sit-to-stands, seated cable/band scapular rows (strengthening thoracic extensors), and standing heel raises holding a sturdy rail (2 sets × 10–12 reps). Balance (4 days/wk): Supported tandem stands and weight-shifts. Aerobic (5 days/wk): 30 min indoor brisk walking (150 min/wk). Bilingual Card (EN / ES): EN: "Keep your back straight and hinge at your hips during strength exercises—never do weighted sit-ups or rounded-back toe touches." / ES: "Mantenga siempre la espalda recta e inclínese desde la cadera al hacer fuerza; nunca realice abdominales con peso ni flexiones encorvando la columna."
- Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment as Elena's exercise specialist, accepting the AI's unverified recommendation of weighted medicine-ball crunches and box jumps for a 71-year-old with a −2.9 lumbar T-score would be malpractice. Trabecular bone loss in the anterior vertebral body makes the lumbar spine uniquely vulnerable to wedge compression fractures under flexed loading, and her 14.6-second TUG score proves she lacks the neuromuscular control for plyometric landings. By overriding the AI and anchoring her protocol in PAGA 2018 multicomponent guidelines and Wolff's Law, we apply safe axial and muscular pull through chair-supported sit-to-stands and thoracic extension rows while maintaining a neutral spine. Pairing this with indoor climate-controlled walking and rail-supported tandem balance drills stimulates bone remodeling while eliminating fall and heat risks in Yuma. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."
- Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M03_Bone_Audit.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 03 (Mod 03 Lab: Bone-Building & Fall-Safe Exercise Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 03 Laboratorio y Simulación: Auditoría de Densidad Ósea y Prevención de Caídas

- Parte 1 (Patrón DXA y TUG): Clasifique el puntaje T de DXA, el riesgo de caídas (TUG ≥ 12 s) y señale los errores peligrosos de la IA.
- Parte 2 (Regla PAGA 2018 y Ley de Wolff): Cite las reglas multicomponente de PAGA 2018 y la prohibición absoluta de la flexión espinal con carga.
- Parte 3 (Solución FITT-VP y Tarjeta Bilingüe): Presente su prescripción con columna neutra y tarjeta bilingüe (EN / ES).
- Parte 4 (La Verificación Activa Obligatoria (Parte 3 • Mínimo 150 Palabras)): Justifique en su propia voz clínica cómo su intervención previene fracturas por compresión vertebral y caídas en Yuma.
- Verificación del Repositorio: Confirme el archivo en EXW_Professional_AI_Repository / EXW_265_M03_Bone_Audit.pdf .
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 03)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
