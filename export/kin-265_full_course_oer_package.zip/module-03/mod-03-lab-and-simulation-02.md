## KIN-265: Mod 03 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-265 (Module 03) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 03 Coaching Sprint Simulation: Spine-Safe Movements & Fall Prevention

Sesión de Coaching del Módulo 03: Osteoporosis, Sarcopenia y Seguridad de Carga Axial

- Osteogenic Weight-Bearing & Resistance Loading (Wolff's Law): Bone remodels in response to mechanical strain; controlled weight-bearing aerobic and multi-joint resistance training stimulate osteoblast bone formation. En palabras sencillas: El hueso se fortalece cuando recibe carga segura de caminatas y ejercicios de fuerza bien controlados.
- Spinal Flexion & Twisting Contraindication in Osteoporosis: Loaded forward spinal flexion (sit-ups, toe touches) and rapid trunk rotation create excessive anterior vertebral compression and fracture risk. En palabras sencillas: En personas con osteoporosis quedan prohibidos los abdominales tradicionales o doblar la espalda con peso porque pueden causar fracturas vertebrales.
- Multicomponent Fall-Prevention Triad (Balance + Strength + Gait): Pairing tandem/single-leg balance drills with lower-extremity strength (chair sit-to-stands, step-ups) to reduce fall and hip-fracture incidence in older adults. En palabras sencillas: Combinar ejercicios de equilibrio con fuerza de piernas (levantarse de la silla, subir escalón) para evitar caídas y fracturas de cadera.
- KIN-265.3.1.AY26-27: Apply PAGA 2018 clinical guidelines for bone mineral density loading and resistance training to counteract osteoporosis and age-related muscle loss (sarcopenia). Aplicar las pautas clínicas de PAGA 2018 para la carga de densidad mineral ósea y contrarrestar la osteoporosis y la sarcopenia.
- KIN-265.3.2.AY26-27: Audit clinical safety parameters, spinal flexion contraindications, and progressive overload parameters for aging populations. Auditar parámetros de seguridad clínica, contraindicaciones de flexión espinal y sobrecarga progresiva en poblaciones mayores.

### Your Weekly Win: Rebuilding Bone Architecture and Muscular Power

How can targeted mechanical loading and progressive resistance training reverse bone demineralization and muscle wasting in aging adults? Skeletal and muscular tissues remodel dynamically in response to applied physical stress (Wolff's Law). Following strict PAGA 2018 (2nd Ed.) clinical multicomponent guidelines, exercise specialists design high-safety axial-loading programs that protect against vertebral wedge fractures and functional decline. Choose your coaching track below, consult your AI Socratic Coach, and master clinical safety auditing!

¿Cómo pueden la carga mecánica y el entrenamiento de fuerza revertir la pérdida ósea y muscular en adultos mayores? Los huesos y músculos responden al estrés físico remodelando tejido (Ley de Wolff). Siguiendo las pautas de PAGA 2018 (2.ª ed.), los especialistas diseñan programas seguros de carga axial que evitan fracturas vertebrales en cuña y el deterioro funcional. ¡Elija su caso y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione el caso correspondiente a su trayectoria vocacional

Scenario: Post-menopausal patient (Linda, 66) diagnosed with lumbar osteoporosis who wants to build bone density but fears spinal compression fractures from lifting weights.


```text
###
[TRACK]: Track 1 - Clinical & Hospital Outpatient Path
[CLIENT]: Post-Menopausal Osteoporosis Patient (Linda, 66) | [LOCATION]: Yuma, AZ
[SITUATION]: Diagnosed with low bone mineral density in lumbar spine (T-score: -2.8). Wants to improve skeletal strength but fears heavy axial loading and spinal flexion.
[COACHING GOAL]: Apply PAGA 2018 clinical guidelines to audit spinal flexion contraindications and prescribe safe neutral-spine axial loading drills for bone remodeling.
###
```

Scenario: Senior center fitness leader (Carlos, 60) working with older adults exhibiting sarcopenia and balance deficits who need functional power training.


```text
###
[TRACK]: Track 2 - Community & Senior Wellness Path
[CLIENT]: Senior Wellness Coordinator (Carlos, 60) | [LOCATION]: Yuma County, AZ
[SITUATION]: Coaching adults aged 70+ experiencing muscle wasting and fall risks; wants to introduce progressive resistance exercises without overwhelming fragile participants.
[COACHING GOAL]: Design progressive multicomponent balance and functional power protocols using bodyweight and resistance bands aligned with PAGA 2018 senior guidelines.
###
```

Scenario: Masters lifter (Brian, 50) managing localized lumbar osteopenia while transitioning into heavy compound lifting to maximize skeletal density.


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Conditioning Path
[CLIENT]: Masters Strength Lifter (Brian, 50) | [LOCATION]: Yuma, AZ
[SITUATION]: Training for powerlifting with mild lumbar osteopenia (T-score: -1.8); needs to balance heavy axial loading for bone density with spinal safety.
[COACHING GOAL]: Audit progressive overload parameters, spinal neutrality mechanics, and recovery intervals to stimulate bone remodeling without spinal shear injury.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-265 Bone Remodeling Tool Box ###:
Role: Supportive KIN-265 Clinical Exercise Specialist Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) - Active Older Adults & Chronic Conditions.

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms PAGA 2018 clinical guidelines for bone mineral density loading and sarcopenia mitigation, emphasizing spinal neutrality and progressive overload.
Step 3: Guide the student to identify ONE absolute biomechanical contraindication (e.g., loaded spinal flexion) and prescribe ONE safe axial loading exercise.
Step 4: Help the student formulate ONE punchy, memorable coaching takeaway sentence (in English and Spanish) about how safe mechanical loading builds lifelong bone strength.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's skeletal or muscular health risk.
- Clinical Safety & Programming Analysis: Explain PAGA 2018 bone loading and sarcopenia guidelines for your client.
- My Clinical Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why replacing spinal flexion (sit-ups/toe touches) with neutral-spine hip hinging and multicomponent balance training protects your osteoporotic client under PAGA 2018 standards.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 03 Coaching Sprint • Track 1 (Clinical / Linda)

- Chosen Track & Client: Track 1: Clinical & Hospital Outpatient Path (Linda, 66). Challenge: Linda has diagnosed osteoporosis in her lumbar spine (T-score: -2.8) and wants to improve bone density without risking spinal compression fractures from lifting weights.
- Track 1: Clinical & Hospital Outpatient Path (Linda, 66).
- Challenge: Linda has diagnosed osteoporosis in her lumbar spine (T-score: -2.8) and wants to improve bone density without risking spinal compression fractures from lifting weights.
- Clinical Safety & Programming Analysis: PAGA 2018 Guidelines for Osteoporosis: In osteoporosis, osteoclast resorption exceeds osteoblast bone deposition. Loaded spinal flexion (e.g., traditional sit-ups, toe touches) shifts compressive forces anteriorly onto fragile vertebral bodies, dramatically increasing compression fracture risk. Clinical protocols mandate neutral-spine axial loading (e.g., standing overhead presses, chair sit-to-stands, wall-supported squats) 2 to 3 days per week to stimulate osteogenesis safely per Wolff's Law.
- PAGA 2018 Guidelines for Osteoporosis: In osteoporosis, osteoclast resorption exceeds osteoblast bone deposition. Loaded spinal flexion (e.g., traditional sit-ups, toe touches) shifts compressive forces anteriorly onto fragile vertebral bodies, dramatically increasing compression fracture risk.
- Clinical protocols mandate neutral-spine axial loading (e.g., standing overhead presses, chair sit-to-stands, wall-supported squats) 2 to 3 days per week to stimulate osteogenesis safely per Wolff's Law.
- My Clinical Safety Audit for Linda: "Eliminate all loaded spinal flexion and rotational machines; prescribe chair sit-to-stands with strict neutral lumbar spine and introduce standing neutral-spine dumbbell farmer carries to stimulate axial bone remodeling safely per PAGA 2018."
- "Eliminate all loaded spinal flexion and rotational machines; prescribe chair sit-to-stands with strict neutral lumbar spine and introduce standing neutral-spine dumbbell farmer carries to stimulate axial bone remodeling safely per PAGA 2018."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Linda's lumbar DXA T-score of −2.8 represents a critical structural redline where standard core workouts become dangerous. A generic AI fitness prompt for 'back and core strengthening' routinely recommends sit-ups, crunches, or seated forward toe-touches—movements that apply intense anterior compressive shear across demineralized lumbar vertebrae and cause wedge compression fractures. By enforcing our strict neutral-spine safety gate and applying PAGA 2018 older adult multicomponent rules, we teach Linda the hip-hinge pattern, chair-supported sit-to-stands, and thoracic extension band rows. This applies safe longitudinal mechanical strain under Wolff's Law to stimulate osteoblast activity while building lower-extremity balance to prevent falls in Yuma."
- My Memorable Coaching Takeaway: EN: "Bones adapt to mechanical stress—lift safely with a neutral spine to build lifelong skeletal strength!" ES: "¡Los huesos se adaptan al estrés mecánico; levanta peso con seguridad y columna neutra para construir fuerza esquelética!"
- EN: "Bones adapt to mechanical stress—lift safely with a neutral spine to build lifelong skeletal strength!"
- ES: "¡Los huesos se adaptan al estrés mecánico; levanta peso con seguridad y columna neutra para construir fuerza esquelética!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M03_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 03 (Mod 03 Coaching Sprint: Spine-Safe Movements & Fall Prevention)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 03 Simulación de Coaching: Osteoporosis, Sarcopenia y Carga Axial

Evaluación Rápida y Auditoría de Seguridad Esquelética


### Su Logro Semanal: Reconstrucción de la Fuerza Ósea y Muscular

Esta sesión le permitirá aplicar las directrices clínicas de PAGA 2018 para contrarrestar la osteoporosis y la sarcopenia mediante carga mecánica segura. Aprenda a auditar contraindicaciones de flexión espinal. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-265 Remodelacion Osea ###:
Rol: Coach Especialista en Ejercicio Clinico de KIN-265 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.) - Adultos Mayores y Condiciones Cronicas.

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla las directrices clinicas de PAGA 2018 para la carga de densidad mineral osea y la mitigacion de la sarcopenia, incluyendo la seguridad espinal y la sobrecarga progresiva.
Step 3: Pedir al estudiante UN protocolo de seguridad clinica o ajuste en la prescripcion de ejercicio.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la carga mecanica con columna neutra construye huesos y musculos fuertes.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el riesgo de salud esquelética o muscular de su cliente.
- Análisis de Seguridad Clínica y Programación: Explique las directrices de PAGA 2018 sobre carga ósea para su cliente.
- Mi Auditoría de Seguridad Clínica: Escriba 1 parámetro de seguridad claro y basado en evidencia o ajuste en la prescripción.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué sustituir la flexión espinal (abdominales/toques de punta) por bisagra de cadera con columna neutra y equilibrio multicomponente protege a su cliente con osteoporosis según PAGA 2018.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, el puntaje T lumbar de −2.8 de Linda exige una compuerta estricta de seguridad espinal. Una IA genérica suele recomendar abdominales tradicionales o tocarse la punta de los pies, lo cual concentra presión en la parte anterior de las vértebras osteoporóticas y provoca fracturas por acuñamiento. Al aplicar las normas multicomponente de PAGA 2018 y la Ley de Wolff con columna neutra—usando bisagra de cadera, sentadillas desde silla y remos con banda—estimulamos la densidad ósea y el equilibrio sin riesgo de fractura."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 03)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
