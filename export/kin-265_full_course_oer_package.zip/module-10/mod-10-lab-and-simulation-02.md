## KIN-265: Mod 10 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Lab & Simulation: Chronic Lung Condition Exercise Plan Audit

Laboratorio del Módulo 10: Prescripción de Ejercicio Pulmonar y Auditoría

- Pursed-Lip & Diaphragmatic Breathing (Preventing Dynamic Hyperinflation): Slowing expiration through pursed lips (1:2 inhale-to-exhale ratio) keeps airways open longer, reduces trapped air in COPD, and relieves exercise dyspnea. En palabras sencillas: Respirar con los labios fruncidos soltando el aire el doble de lento que al inhalar para vaciar el aire atrapado y calmar la sensación de ahogo.
- Pulse Oximetry Safety Gate (Maintain SpO2 ≥88–90%): Continuous or interval monitoring of arterial oxygen saturation; if SpO2 drops below 88–90%, pause exercise, cue pursed-lip breathing, and follow supplemental O2 orders. En palabras sencillas: Vigilar con el oxímetro de dedo que la saturación de oxígeno (SpO2) se mantenga en 88–90% o más durante toda la sesión.
- Interval Aerobic Pacing & Dyspnea Borg 3–4/10 Target: Alternating short bouts of walking/cycling (e.g., 2–5 minutes) with active recovery rest intervals so shortness of breath stays at a manageable 3–4 on the 0–10 Borg Dyspnea Scale. En palabras sencillas: Dividir la caminata o bicicleta en bloques cortos de 2 a 5 minutos con pausas de recuperación para que la falta de aire nunca pase de nivel 3 a 4 sobre 10.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Pulmonary exercise prescription adapts aerobic and resistance training to strengthen ventilatory muscles while managing breathlessness in clients with lung disease. Pursed-lip breathing and interval work-to-rest pacing prevent air trapping in compromised lungs during exertion. Monitoring oxygen saturation ensures training remains safe by keeping blood oxygen levels at or above eighty-eight percent.


#### En Palabras Sencillas (Norteño Context)

Hacer ejercicio con problemas en los pulmones es como subir una cuesta en una troca con el filtro de aire tapado: hay que meterle cambios despacio para que no se ahogue el motor. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar la respiración con labios fruncidos y cuidar que el oxígeno no baje del 88%.


### Pulmonary Mechanics, Exertional Dyspnea, & PAGA 2018 Prescriptions

In this laboratory assignment, you will conduct a qualitative pulmonary clinical audit and construct an evidence-based exercise prescription. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze ventilatory mechanics, dynamic hyperinflation, and oxygen desaturation baselines, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) chronic condition standards, and execute an AI-driven clinical simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría clínica cualitativa de patologías pulmonares y diseñará una prescripción de ejercicio basada en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando la mecánica ventilatoria y los límites de desaturación de oxígeno según la PAGA 2018.

- KIN-265.10.3.AY26-27: Analyze respiratory mechanics, gas exchange deficits, and ventilatory limitations associated with COPD and asthma across clinical scenarios. Analizar la mecánica respiratoria, los déficits de intercambio gaseoso y las limitaciones ventilatorias asociadas con la EPOC y el asma en escenarios clínicos.
- KIN-265.10.4.AY26-27: Design evidence-based pulmonary rehabilitation prescriptions, breathing interval pacing protocols, and bilingual coaching cue cards aligned with PAGA 2018 standards. Diseñar prescripciones de rehabilitación pulmonar basadas en evidencia, protocolos de ritmo de intervalos y tarjetas de instrucción bilingües alineadas con la PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, October 20, 2026, at 12:00 AM MST Abre el martes, 20 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 26, 2026, at 11:59 PM MST Lunes, 26 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Mastery Scale) Ponderación de evaluación para laboratorios semanales y simulaciones prácticas (Escala de Dominio 10/7/0)

### Lab Objectives / Objetivos del Laboratorio

Objetivos del Laboratorio

- Audit the physiological mechanisms of dynamic hyperinflation, ventilatory limitations, and arterial oxygen desaturation during physical exertion. Auditar los mecanismos fisiológicos de la hiperinsuflación dinámica, las limitaciones ventilatorias y la desaturación de oxígeno arterial durante el esfuerzo físico.
- Apply federal PAGA 2018 (2nd Ed.) chronic condition guidelines, Borg CR10 dyspnea rating scales, and pulse oximetry thresholds to structure safe pulmonary exercise programs. Aplicar las pautas de PAGA 2018 para afecciones crónicas, escalas de disnea Borg CR10 y umbrales de oximetría para estructurar programas de ejercicio pulmonar seguros.
- Formulate a 4-week pulmonary conditioning remediation plan incorporating pursed-lip breathing paired with bilingual coaching cue cards in English and Spanish. Formular un plan de acondicionamiento pulmonar de 4 semanas con respiración con labios fruncidos y tarjetas de instrucción bilingües en inglés y español.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-10

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos del Caso Clínico Pulmonar

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Clinical pulmonary rehabilitation; managing moderate-to-severe COPD, supplemental oxygen titration, and exertional desaturation avoidance (SpO2 >= 88%).

Focus: Community-dwelling older adults; exercise-induced bronchospasm (EIB), environmental air quality monitoring, and indoor walking protocols in Yuma County.

Focus: Occupational particulate exposure; mild restrictive ventilatory impairment, inspiratory muscle training (IMT), and tactical conditioning for active service members.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete pulmonary exercise audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline respiratory profile.
- Part 1: Pattern Recognition: Identify specific ventilatory limitations (dynamic hyperinflation, resting SpO2, and exertional breathlessness).
- Part 2: Rule Application: Cite PAGA 2018 chronic condition standards, Borg CR10 dyspnea safety limits, and pulse oximetry stop thresholds.
- Part 3: Solving the Gap (Active Verification & Rehabilitation Plan): In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your 4-week pulmonary rehabilitation plan protects client safety and aligns with PAGA 2018 standards. Detail your interval pacing structure, SpO2 safety limits, pursed-lip breathing cues, and 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient M.V. presents with GOLD Stage II moderate COPD characterized by chronic expiratory airflow limitation (FEV1/FVC 0.58) and dynamic hyperinflation. During continuous exertion, incomplete lung emptying traps air, elevating functional residual capacity and precipitating severe exertional dyspnea (Borg CR10 score 6/10) with rapid oxygen desaturation to 87% within 4 minutes on room air.

Part 2: Rule Application (SSoT PAGA 2018 2nd Ed Standards): Under PAGA 2018 (2nd Ed.) guidelines for adults with chronic conditions and clinical pulmonary rehabilitation benchmarks, exercise intensity must be prescribed using dyspnea scales (targeting Borg CR10 3 to 4, moderate) rather than heart rate alone. Oxygen saturation must be maintained at or above 88% at all times; any sustained drop below 88% mandates immediate session pause, supplemental oxygen titration or pursed-lip recovery breathing until SpO2 recovers to >= 90%.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): 4-Week Pulmonary Rehabilitation Protocol (3 Days/Week): Key Point — Weeks 1-2 (Interval Base): Interval treadmill walking alternating 2 minutes at 1.8 mph (flat) with 1 minute seated pursed-lip rest, accumulating 16 total active minutes (RPE 11-12, Borg CR10 3/10). Supplemental nasal cannula oxygen at 2 L/min to keep SpO2 >= 90%. Key Point — Weeks 3-4 (Work-to-Rest Progression): Advance walking interval to 3 minutes at 2.0 mph with 1 minute active recovery, accumulating 24 total active minutes; introduce seated cycle ergometry at 25 Watts. Key Point — Breathing & Safety: Continuous pulse oximetry monitoring; mandatory session halt if SpO2 drops < 88% or Borg CR10 exceeds 5. Active Verification (Own Voice): In my clinical assessment, patient M.V.'s acute exertional desaturation to 87% within four minutes demonstrates that continuous aerobic protocols are clinically contraindicated. His expiratory airflow limitation causes rapid air trapping and dynamic hyperinflation under sustained workloads. By structuring an interval walking regimen with short 2-minute work bouts alternating with 1-minute seated recovery periods, we allow his lungs to completely empty, blunting hyperinflation and stabilizing functional residual capacity. Enforcing a strict 1:2 pursed-lip breathing ratio provides continuous airway stenting to support alveolar ventilation. Titrating supplemental nasal cannula oxygen at 2 L/min keeps SpO2 safely above 90%, preventing pulmonary arterial hypertensive spikes and adhering rigorously to PAGA 2018 clinical rehabilitation benchmarks.

EN: "Breathe in slowly through your nose for two counts, then breathe out gently through pursed lips for four counts as if blowing out a candle. Pace your steps with your breath and pause immediately if your dyspnea rating rises above four."

ES: "Inhale despacio por la nariz contando dos tiempos, y luego exhale suavemente con los labios fruncidos contando cuatro tiempos como si soplara una vela. Coordine sus pasos con su respiración y deténgase de inmediato si su nivel de falta de aire sube de cuatro."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M10_Pulmonary_Audit.pdf


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 10 (Mod 10 Lab: Chronic Lung Condition Exercise Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 10 Práctica de Lab y Simulación: Prescripción de Ejercicio Pulmonar y Auditoría

Mecánica Pulmonar, Disnea de Esfuerzo y Prescripciones PAGA 2018


### Mecánica Pulmonar, Disnea de Esfuerzo y Prescripciones PAGA 2018

En esta práctica de laboratorio, realizará una auditoría clínica cualitativa de patologías pulmonares y diseñará una prescripción de ejercicio basada en evidencia. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará la mecánica ventilatoria, la hiperinsuflación dinámica y los límites de desaturación de oxígeno, aplicando las normas de la PAGA 2018 (2.ª edición) y ejecutará una simulación con Google Gemini.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Rehabilitación pulmonar clínica; manejo de EPOC moderada a grave, titulación de oxígeno suplementario y prevención de desaturación (SpO2 >= 88%).

Enfoque: Adultos mayores comunitarios; broncoespasmo inducido por el ejercicio (BIE), monitoreo de calidad del aire y caminata en interiores en el condado de Yuma.

Enfoque: Exposición ocupacional a partículas; deterioro ventilatorio restrictivo leve, entrenamiento muscular inspiratorio (IMT) y acondicionamiento táctico militar.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Comunitaria / Ruta 3 Táctica) e incluya sus iniciales.


#### Parte 1: Reconocimiento de Patrones

Identifique las limitaciones ventilatorias de su cliente (hiperinsuflación dinámica, SpO2 en reposo y disnea de esfuerzo).


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Aplique los estándares para condiciones crónicas de la PAGA 2018, los límites Borg CR10 y el umbral de oximetría de pulso.


#### Parte 3: Resolución de la Brecha

Detalle el plan de ejercicio pulmonar de 4 semanas con ritmo de intervalos y respiración con labios fruncidos, junto con una tarjeta de instrucción bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: El paciente M.V. presenta EPOC moderada Estadio GOLD II con limitación crónica del flujo espiratorio (FEV1/FVC 0.58) e hiperinsuflación dinámica. Durante el esfuerzo continuo, el vaciado pulmonar incompleto atrapa aire, elevando la capacidad residual funcional y provocando disnea severa (escala Borg CR10 6/10) con rápida desaturación a 87% tras 4 minutos al aire ambiente.

Parte 2: Aplicación de Reglas (Guías PAGA 2018 2.ª Ed.): Según las pautas de PAGA 2018 (2.ª ed.) para adultos con afecciones crónicas y los estándares clínicos, la intensidad debe prescribirse mediante escalas de disnea (rango 3 a 4, moderado) y no solo con frecuencia cardíaca. La saturación de oxígeno debe mantenerse en o por encima del 88% en todo momento; cualquier caída por debajo de 88% exige una pausa inmediata, titulación de oxígeno o respiración con labios fruncidos hasta recuperar SpO2 >= 90%.

Parte 3: Resolución de la Brecha: Key Point — Semanas 1-2 (Base de Intervalos): Caminata en caminadora en intervalos de 2 minutos a 1.8 mph alternados con 1 minuto de descanso sentado con labios fruncidos, acumulando 16 minutos activos (RPE 11-12, Borg CR10 3/10). Oxígeno suplementario por cánula nasal a 2 L/min para mantener SpO2 >= 90%. Key Point — Semanas 3-4 (Progresión de Trabajo y Descanso): Aumentar el intervalo a 3 minutos a 2.0 mph con 1 minuto de recuperación activa, acumulando 24 minutos; incorporar cicloergómetro sentado a 25 vatios. Key Point — Monitoreo de Seguridad: Oximetría de pulso continua; detención obligatoria si SpO2 cae por debajo de 88% o Borg CR10 supera 5. Verificación Activa (Voz Propia): En mi juicio clínico, la desaturación rápida de M.V. al 87% demuestra que el ejercicio aeróbico continuo está contraindicado. Su limitación crónica del flujo espiratorio atrapa aire e incrementa la hiperinsuflación dinámica. Al estructurar caminatas en intervalos de 2 minutos con 1 minuto de recuperación sentada, permitimos el vaciado pulmonar completo y estabilizamos la capacidad residual funcional. Exigir la respiración con labios fruncidos en relación 1:2 actúa como férula neumática bronquiolar, mientras que el oxígeno suplementario a 2 L/min mantiene la SpO2 arriba de 90%, respetando estrictamente PAGA 2018. Tarjeta Bilingüe: "Inhale despacio por la nariz contando dos tiempos, y luego exhale suavemente con los labios fruncidos contando cuatro tiempos como si soplara una vela. Coordine sus pasos con su respiración y deténgase de inmediato si su nivel de falta de aire sube de cuatro."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M10_Pulmonary_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 10)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
