## KIN-265: Module 00 Summary And Wrap Up Slash Resumen Y Cierre

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 00 Summary & Wrap-Up: Orientation / Resumen y Cierre


### Step 1: Core Special Populations Orientation Synthesis

Welcome to KIN-265! You have completed the Course Orientation. You are now equipped with our clinical auditing architecture, academic integrity policies, and special populations exercise framework:

- Exclusive Single Source of Truth (SSoT): All clinical activity guidelines, condition-specific considerations, and safety parameters derive strictly from the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .
- The Clinical Framing Protocol: You will evaluate clinical safety and audit exercise prescriptions using the Pattern → Rule → Solve clinical framework.
- Cadence & Deadlines: Coursework follows a strict weekly cadence, with all weekly case audits and discussion board submissions closing Mondays at 11:59 PM MST.

### Step 2: Workplace Intelligence & AI Skills Competency

Adapting exercise for individuals with chronic conditions or unique physiological needs requires high clinical acumen, structured auditing, and responsible AI integration.

- Structured Prompt Engineering: Clinical exercise specialists utilize AI preceptors (like Google Gemini) to simulate complex client case audits and evaluate safety precautions.
- Delimiter Protocol (###): You will enclose clinical client profiles and health histories inside triple hashes ( ### ) to ensure strict data boundary isolation during AI queries.
- Clinical Verification: AI never replaces clinical judgment. Human-in-the-loop verification against federal standards (PAGA 2018) remains the mandatory professional standard when working with special populations.

### Step 3: Orientation Self-Check (Bilingual Companion Knowledge Verification)

Click each item below to verify your readiness before beginning Module 01:

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) strictly serves as our exclusive authority. External clinical standards are discarded unless they fully align with PAGA.

Respuesta en Español: Las Guías de Actividad Física para Estadounidenses (PAGA 2018, 2.ª ed.) sirven estrictamente como nuestra autoridad exclusiva. Las normas clínicas externas se descartan a menos que se alineen por completo con PAGA.

English Response: Monday at 11:59 PM MST for all weekly clinical audits, self-checks, and discussion board submissions.

Respuesta en Español: Los lunes a las 11:59 PM MST para todas las auditorías clínicas, autoevaluaciones y entregas de foros de discusión semanales.

English Response: Each assignment requires a 3-part submission: Part 1: Pattern Recognition (Auditing clinical limitations and contraindications), Part 2: Rule Application (Applying PAGA guidelines), and Part 3: Solving the Gap (Formulating a safe activity prescription).

Respuesta en Español: Cada asignación requiere una entrega de 3 partes: Parte 1: Reconocimiento de Patrones (Auditoría de limitaciones clínicas y contraindicaciones), Parte 2: Aplicación de Reglas (Aplicación de normativas PAGA) y Parte 3: Resolución de la Brecha (Formulación de una prescripción de actividad segura).

English Response: To enclose client case data securely, preventing prompt drift and ensuring strict compliance with clinical data isolation standards during AI interactions.

Respuesta en Español: Encerrar los datos del caso del cliente de manera segura para prevenir la deriva de las instrucciones y asegurar el cumplimiento estricto de las normas de aislamiento de datos clínicos durante las interacciones con IA.

English Response: AI tools can hallucinate or miss subtle clinical contraindications. Certified specialists must verify all outputs against federal SSoT standards to protect client safety.

Respuesta en Español: Las herramientas de IA pueden alucinar u omitir contraindicaciones clínicas sutiles. Los especialistas certificados deben verificar todos los resultados frente a los estándares SSoT federales para proteger la seguridad del cliente.

English Response: In the student's designated Google Drive repository folder named EXW_Professional_AI_Repository .

Respuesta en Español: En la carpeta del repositorio de Google Drive designada por el estudiante llamada EXW_Professional_AI_Repository .

English Response: By providing zero-cost, screen-reader compatible, and responsive digital layouts directly inside the learning management system, removing financial barriers to textbooks.

Respuesta en Español: Al proporcionar diseños digitales sin costo, compatibles con lectores de pantalla y adaptables directamente dentro del sistema de gestión de aprendizaje, eliminando las barreras financieras de los libros de texto.

English Response: WCAG 2.1 and 2.2 AA standards, ensuring a minimum 4.5:1 contrast ratio for normal text and full screen-reader accessibility.

Respuesta en Español: Los estándares WCAG 2.1 y 2.2 AA, garantizando una relación de contraste mínima de 4.5:1 para el texto normal y total accesibilidad para lectores de pantalla.


### Looking Ahead: Module 01

In Module 01: Foundations of Exercise for Special Populations & Clinical Safety , we begin evaluating chronic disease epidemiology, risk-benefit ratios, and PAGA 2018 overarching principles for individuals with health conditions.

KIN-265 • Ejercicio para Poblaciones Especiales


## Mód 00 Resumen y Cierre: Orientación / Resumen y Cierre


### Step 1: Síntesis de Orientación para Poblaciones Especiales

¡Bienvenidos a KIN-265! Ha completado la Orientación del Curso. Ahora está equipado con nuestra arquitectura de auditoría clínica, políticas de integridad académica y marco de ejercicio para poblaciones especiales:

- Fuente Única de Verdad Exclusiva (SSoT): Todas las pautas de actividad y seguridad se derivan estrictamente de las Guías de Actividad Física para Estadounidenses (PAGA 2018, 2.ª ed.) .
- El Protocolo de Encuadre Clínico: Evaluará la seguridad clínica y auditará prescripciones utilizando el marco Patrón → Regla → Solución .
- Plazos de Entrega: Las tareas semanales y foros cierran los lunes a las 11:59 PM MST.

### Step 2: Inteligencia en el Entorno Laboral y Competencia en IA

Adaptar el ejercicio para personas con condiciones crónicas o necesidades fisiológicas únicas exige juicio clínico, auditoría estructurada e integración responsable de la inteligencia artificial.

- Ingeniería de Consultas Estructuradas: Los especialistas utilizan preceptores de IA (como Google Gemini) para simular auditorías de casos clínicos y evaluar precauciones de seguridad.
- Protocolo de Delimitadores (###): Aprenderá a encerrar perfiles clínicos de clientes entre tres numerales ( ### ) para proteger la estructura de los datos durante las consultas.
- Verificación Clínica Humana: La IA nunca reemplaza el criterio clínico. La verificación humana basada en normas federales (PAGA 2018) es obligatoria al trabajar con poblaciones especiales.

### Step 3: Autoevaluación de Orientación (Verificación Bilingüe)

Presione cada elemento para verificar su preparación antes de comenzar el Módulo 01:

Respuesta en Español: Las Guías de Actividad Física para Estadounidenses (PAGA 2018, 2.ª ed.) sirven estrictamente como nuestra autoridad exclusiva. Las normas clínicas externas se descartan a menos que se alineen por completo con PAGA.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) strictly serves as our exclusive authority. External clinical standards are discarded unless they fully align with PAGA.

Respuesta en Español: Los lunes a las 11:59 PM MST para todas las auditorías clínicas, autoevaluaciones y entregas de foros de discusión semanales.

English Response: Monday at 11:59 PM MST for all weekly clinical audits, self-checks, and discussion board submissions.

Respuesta en Español: Cada asignación requiere una entrega de 3 partes: Parte 1: Reconocimiento de Patrones (Auditoría de limitaciones clínicas y contraindicaciones), Parte 2: Aplicación de Reglas (Aplicación de normativas PAGA) y Parte 3: Resolución de la Brecha (Formulación de una prescripción de actividad segura).

English Response: Each assignment requires a 3-part submission: Part 1: Pattern Recognition (Auditing clinical limitations and contraindications), Part 2: Rule Application (Applying PAGA guidelines), and Part 3: Solving the Gap (Formulating a safe activity prescription).

Respuesta en Español: Encerrar los datos del caso del cliente de manera segura para prevenir la deriva de las instrucciones y asegurar el cumplimiento estricto de las normas de aislamiento de datos clínicos durante las interacciones con IA.

English Response: To enclose client case data securely, preventing prompt drift and ensuring strict compliance with clinical data isolation standards during AI interactions.

Respuesta en Español: Las herramientas de IA pueden alucinar u omitir contraindicaciones clínicas sutiles. Los especialistas certificados deben verificar todos los resultados frente a los estándares SSoT federales para proteger la seguridad del cliente.

English Response: AI tools can hallucinate or miss subtle clinical contraindications. Certified specialists must verify all outputs against federal SSoT standards to protect client safety.

Respuesta en Español: En la carpeta del repositorio de Google Drive designada por el estudiante llamada EXW_Professional_AI_Repository .

English Response: In the student's designated Google Drive repository folder named EXW_Professional_AI_Repository .

Respuesta en Español: Al proporcionar diseños digitales sin costo, compatibles con lectores de pantalla y adaptables directamente dentro del sistema de gestión de aprendizaje, eliminando las barreras financieras de los libros de texto.

English Response: By providing zero-cost, screen-reader compatible, and responsive digital layouts directly inside the learning management system, removing financial barriers to textbooks.

Respuesta en Español: Los estándares WCAG 2.1 y 2.2 AA, garantizando una relación de contraste mínima de 4.5:1 para el texto normal y total accesibilidad para lectores de pantalla.

English Response: WCAG 2.1 and 2.2 AA standards, ensuring a minimum 4.5:1 contrast ratio for normal text and full screen-reader accessibility.


### Mirando Hacia Adelante: Módulo 01

En el Módulo 01: Fundamentos del Ejercicio para Poblaciones Especiales y Seguridad Clínica , iniciamos la evaluación de la epidemiología de enfermedades crónicas, relaciones riesgo-beneficio y principios generales de PAGA 2018.

Semester-Long Ready Reference / Guía de Consulta Permanente: Module 00 remains unlocked all semester long. Bookmark this section and return whenever you want to check the 150-word minimum Active Verification (Part 3) Exemplar or the 4-Step Remedy Roadmap for upgrading a grade to 10 / 10.


### ACTIVE VERIFICATION (PART 3): WHAT IT IS, WHY WE USE IT, & 10/10 STUDENT EXEMPLARS


#### Step 1: What is "Active Verification"? / ¿Qué es la "Verificación Activa"?

In Plain English: The Active Verification is Part 3 of every Lab and Coaching Sprint submission under our Four-Part Submission Standard (following Part 1: The Engine Prompt with ### Delimiters and Part 2: The 150-Word Minimum Clinical Audit , and verified against Part 4: The 10/10 Student Exemplar ). It is a mandatory 150-word minimum paragraph written entirely in your own human voice (never written or polished by AI) where you justify why your clinical intervention is safe and realistic for a real person in Yuma, Arizona or the Imperial Valley , backed by our Academic Source of Truth ( Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6 ).

En Palabras Sencillas (Norteño-Spanish): La Verificación Activa es la Parte 3 de cada Laboratorio y Sprint de Entrenamiento (después de la Parte 1: Instrucción con Delimitadores ### y la Parte 2: Auditoría Clínica de 150 Palabras ). Es un párrafo obligatorio de mínimo 150 palabras escrito totalmente con tu propia voz humana (nunca redactado por IA) donde justificas por qué tu plan es seguro y realista para una persona real en Yuma o el Valle Imperial , respaldado por nuestra Fuente Única de Verdad.


#### Step 2: Why Do We Use It? (The Clinical Framework: Pattern / Rule / Solve) / ¿Por qué la usamos?

In Plain English: In modern healthcare and kinesiology, AI is the calculator (The Engine), and you are the Architect (The Pilot) . An AI chatbot has never stood on a 112°F (44.4°C) Yuma sidewalk, has never coached an early-morning agricultural worker in San Luis or Somerton, and cannot take legal or ethical responsibility for a patient's safety. We use the Active Verification (Part 3) so you prove that a real human professional audited the local environment, checked the federal safety rules, and made the final clinical decision using Pattern / Rule / Solve (Patrón / Regla / Solución) .

En Palabras Sencillas (Norteño-Spanish): En la salud y el entrenamiento moderno, la IA es la calculadora (El Motor) y tú eres el Arquitecto Clínico (El Piloto) . Un chatbot de IA nunca ha sentido el calor de 112°F en una banqueta de Yuma ni conoce el ritmo de trabajo agrícola de nuestra gente en San Luis o Somerton. Usamos la Verificación Activa (Parte 3) para demostrar que un profesional humano real tomó la decisión final de seguridad aplicando Patrón / Regla / Solución .


#### Step 3: What It Looks Like: Your Course 10 / 10 Active Verification Exemplar

"In my own words, I corrected the AI's output because it used a standard heart-rate zone formula (220 - age) for a 67-year-old Foothills retiree taking a daily beta-blocker (metoprolol) for hypertension and living with knee osteoarthritis. Under Pattern / Rule / Solve, the Pattern is an older adult whose medication blunts heart-rate response and creates orthostatic dizziness risk, especially when walking outdoors in 105°F (40.6°C) Yuma heat. The Rule from the 2018 Physical Activity Guidelines for Americans (Chapters 5 and 6) requires multicomponent physical activity—combining aerobic, muscle-strengthening, and balance training—while regulating intensity via Rating of Perceived Exertion (RPE 11 to 13 on the 6–20 Borg scale, or the Talk Test) whenever beta-blockers invalidate heart-rate targets. My Solve moves her sessions into an indoor pool and air-conditioned studio at 8:00 AM, pairing low-impact aquatic walking with seated chair-stand strength and tandem-stance balance drills plus a 10-minute gradual cool-down."

Español (Regional): "En mis propias palabras, corregí el resultado de la IA porque utilizó una fórmula estándar de frecuencia cardíaca (220 - edad) para una jubilada de 67 años en los Foothills que toma un betabloqueador diario (metoprolol) para la hipertensión y vive con osteoartritis de rodilla. Bajo Patrón / Regla / Solución, el Patrón es una adulta mayor cuyo medicamento atenúa la respuesta del pulso y crea riesgo de mareo ortostático, especialmente bajo el calor de 105°F (40.6°C) en Yuma. La Regla de PAGA 2018 (Capítulos 5 y 6) exige actividad física multicomponente—combinando ejercicio aeróbico, fuerza muscular y equilibrio—regulando la intensidad mediante el Esfuerzo Percibido (RPE 11 a 13 o la Prueba del Habla) cuando los betabloqueadores invalidan las fórmulas de pulso. Mi Solución traslada sus sesiones a una alberca bajo techo y estudio con aire acondicionado a las 8:00 AM, con enfriamiento gradual de 10 minutos."

"In my own words, I rejected the AI's suggestion to have my 54-year-old Yuma construction client jog outdoors at 4:00 PM because the ambient temperature is still 108°F (42.2°C), which creates an immediate heat-illness hazard. Following the Pattern / Rule / Solve protocol, the Pattern is a deconditioned outdoor worker with high occupational heat exposure and zero structured aerobic history. The Rule from the 2018 Physical Activity Guidelines for Americans (PAGA, Chapter 4) states that adults should accumulate 150 to 300 minutes per week of moderate-intensity aerobic activity (3.0 to 5.9 METs), and that starting with shorter, tolerable bouts is safest for inactive adults. My Solve moves his brisk walking sessions indoors to the air-conditioned AWC track or mall before work for 25 minutes, six days a week (150 minutes/week total), using the Talk Test (able to speak in full sentences) to keep his intensity safely moderate."

Español (Regional): "En mis propias palabras, rechacé la sugerencia de la IA de poner a mi cliente de construcción de 54 años en Yuma a trotar al aire libre a las 4:00 PM porque la temperatura ambiente sigue en 108°F (42.2°C), lo que crea un peligro inmediato de golpe de calor. Siguiendo el protocolo Patrón / Regla / Solución, el Patrón es un trabajador al aire libre desacondicionado con alta exposición al calor ocupacional. La Regla de las Pautas de Actividad Física para Estadounidenses de 2018 (PAGA, Capítulo 4) establece que los adultos deben acumular de 150 a 300 minutos por semana de actividad aeróbica moderada (3.0 a 5.9 METs). Mi Solución traslada sus caminatas a paso rápido bajo techo con aire acondicionado antes del trabajo durante 25 minutos, seis días a la semana (150 minutos/semana en total), usando la Prueba del Habla para mantener una intensidad moderada y segura."

"In my own words, I modified the AI's 8-week accelerated training plan for our 46-year-old San Luis elementary teacher because it scheduled 75-minute outdoor runs on back-to-back afternoons at 104°F (40.0°C) with zero strength training. Using the Pattern / Rule / Solve clinical framework, the Pattern is an inactive commuter experiencing afternoon heat fatigue and mild lower-back stiffness from standing on concrete classrooms all day. The Rule from the 2018 Physical Activity Guidelines for Americans (PAGA, 2nd Edition, Chapter 4) mandates 150 to 300 minutes per week of moderate-intensity aerobic activity (3.0 to 5.9 METs) paired with muscle-strengthening activities involving all major muscle groups on 2 or more days per week. My Solve splits her weekly movement into five 30-minute indoor brisk walks at 6:00 AM (150 minutes/week at Borg RPE 12) plus Tuesday and Friday 20-minute resistance-band core and lower-body circuits in air conditioning."

Español (Regional): "En mis propias palabras, modifiqué el plan acelerado de 8 semanas que generó la IA para nuestra maestra de primaria de 46 años en San Luis porque programaba carreras al aire libre de 75 minutos por la tarde a 104°F (40.0°C) sin nada de fuerza muscular. Usando el protocolo Patrón / Regla / Solución, el Patrón es una trabajadora sedentaria con fatiga por el calor vespertino y rigidez lumbar. La Regla de las Pautas de Actividad Física para Estadounidenses de 2018 (PAGA, 2.ª ed., Capítulo 4) exige acumular de 150 a 300 minutos semanales de actividad aeróbica moderada (3.0 a 5.9 METs) más al menos 2 días por semana de fortalecimiento muscular en todos los grupos principales. Mi Solución organiza cinco caminatas rápidas bajo techo de 30 minutos a las 6:00 AM (150 minutos/semana en RPE 12) más dos sesiones semanales de 20 minutos con ligas de resistencia en clima fresco."

"In my own words, I overrode the AI's meal plan because it recommended expensive commercial pre-workout powders and sweetened sports drinks that violate our client's budget and blood sugar goals here in Somerton. Using Pattern / Rule / Solve, the Pattern is a 38-year-old agricultural packing-shed worker experiencing afternoon fatigue, high sodium intake from fast food, and chronic dehydration during 106°F (41.1°C) shifts. The Rule under the 2025–2030 Dietary Guidelines for Americans ('Real Food' Focus) prioritizes whole, nutrient-dense foods, plain water as the primary beverage, and limiting added sugars to less than 10% of daily calories. My Solve replaces her sugary afternoon energy drink and ultra-processed snack bar with 24 ounces of ice water, a homemade pinto bean and grilled chicken burrito on a whole-corn tortilla, and sliced jicama with lime—giving her steady complex carbohydrates, complete protein, and natural electrolytes from affordable local groceries."

Español (Regional): "En mis propias palabras, corregí el plan de comidas de la IA porque recomendaba polvos comerciales caros y bebidas deportivas azucaradas que afectan el presupuesto y la glucosa de nuestra clienta en Somerton. Usando Patrón / Regla / Solución, el Patrón es una trabajadora de empaque agrícola de 38 años con fatiga vespertina, alto consumo de sodio en comida rápida y deshidratación durante turnos a 106°F (41.1°C). La Regla de las Pautas Dietéticas para Estadounidenses 2025–2030 (Enfoque en 'Alimentos Reales') prioriza alimentos integrales ricos en nutrientes, agua natural como bebida principal y limitar los azúcares añadidos a menos del 10% de las calorías diarias. Mi Solución reemplaza su bebida energética azucarada con 24 onzas de agua fría, un burrito casero de frijoles pintos y pollo asado en tortilla de maíz integral, y jícama con limón."

"In my own words, I rejected the AI's Phase 4 heavy barbell back-squat prescription for our 36-year-old Yuma client in Gymnasium (GY) Room 116 because it ignored his Overhead Squat Assessment (OHSA) compensations. Applying Pattern / Rule / Solve, the Pattern observed during his Overhead Squat Assessment (OHSA) shows medial knee valgus and an excessive low-back arch driven by overactive adductors and hip flexors paired with underactive gluteus medius and intrinsic core stabilizers. The Rule integrating the NASM Optimum Performance Training (OPT) Model, ACSM 12th Edition, and PAGA 2018 mandates beginning in Phase 1 Stabilization Endurance (12–20 reps at a controlled 4-2-1 tempo) with Corrective Flexibility before heavy loading. My Solve coaches 30-second foam rolling and static stretching of his calves, adductors, and hip flexors, followed by lateral tube walks and 4-2-1 goblet box squats in air-conditioned GY Room 116 using external cues ('push the floor apart') to lock in safe knee alignment."

Español (Regional): "En mis propias palabras, rechacé la rutina de sentadilla pesada con barra en Fase 4 que sugirió la IA para nuestro cliente de 36 años en el Gimnasio (GY) Salón 116 porque ignoró sus compensaciones en la Evaluación de Sentadilla con Brazos Arriba (OHSA). Aplicando Patrón / Regla / Solución, el Patrón observado durante su Evaluación de Sentadilla (OHSA) muestra valgo medial de rodilla y arco lumbar excesivo por aductores y flexores de cadera hiperactivos junto con glúteo medio y core hipoactivos. La Regla del Modelo OPT de NASM, ACSM 12.ª Edición y PAGA 2018 exige iniciar en la Fase 1 de Estabilización (12 a 20 repeticiones con tempo controlado 4-2-1) y flexibilidad correctiva antes de cargar peso máximo. Mi Solución aplica 30 segundos de rodillo de espuma y estiramiento estático seguidos de caminatas laterales con liga y sentadillas goblet a cajón 4-2-1 en el GY 116."

"In my own words, the AI made a dangerous physiological error by prescribing high-intensity interval sprints on day one and miscalculating target heart rate using standard age-predicted formulas without accounting for the client's resting vitals. Applying Pattern / Rule / Solve, the Pattern is a 49-year-old sedentary Yuma office manager (BMI 31.2 kg/m², resting BP 134/86 mmHg, Resting Heart Rate 78 bpm) with no signs or symptoms of cardiovascular, metabolic, or renal disease. The Rule under the ACSM Guidelines for Exercise Testing and Prescription (12th Edition, Chapter 2 Preparticipation Screening & Chapter 5 FITT-VP) requires starting sedentary, asymptomatic individuals at light-to-moderate intensity (40% to 59% HRR) before progressing to vigorous work. Using the Karvonen formula with an estimated HRmax of 171 bpm (220 - 49), his Heart Rate Reserve is 93 bpm (171 - 78). My Solve sets his initial indoor treadmill walking target between 115 and 133 bpm for 30 minutes, 5 days per week."

Español (Regional): "En mis propias palabras, la IA cometió un error fisiológico peligroso al prescribir sprints de alta intensidad desde el primer día y calcular mal la frecuencia cardíaca objetivo sin considerar los signos vitales en reposo. Aplicando Patrón / Regla / Solución, el Patrón es un gerente de oficina sedentario de 49 años en Yuma (IMC 31.2 kg/m², PA en reposo 134/86 mmHg, FCR 78 lpm) sin síntomas de enfermedad cardiovascular, metabólica o renal. La Regla según las Pautas de ACSM (12ª Edición, Capítulos 2 y 5 FITT-VP) exige iniciar a personas sedentarias asintomáticas en intensidad ligera a moderada (40% a 59% FCR/HRR). Usando la fórmula de Karvonen con una FCmáx estimada de 171 lpm (220 - 49), su Reserva de Frecuencia Cardíaca es 93 lpm (171 - 78). Mi Solución fija su caminata inicial en caminadora bajo techo entre 115 y 133 lpm durante 30 minutos, 5 días por semana."


### HOW TO REMEDY A 0 / 10 OR UPGRADE A 7 / 10 GRADE / CÓMO RECUPERAR UN 0 / 10 O SUBIR UN 7 / 10

In Plain English: In our courses, a score of 0 / 10 (Recalibrate) is never a permanent punishment—it is a clinical safety pause and an open invitation to fix and resubmit your work for full 10 / 10 (Exemplary) credit. Similarly, if you earn 7 / 10 (Competent) , you can revise the minor gap and resubmit for 10 / 10 . All Labs and Coaching Sprints have Unlimited Attempts and stay unlocked through the end of the semester.

En Palabras Sencillas (Norteño-Spanish): En nuestros cursos, un 0 / 10 (Recalibrar) nunca es un castigo definitivo; es una pausa de seguridad clínica y una invitación abierta para corregir y volver a entregar por el 10 / 10 completo. Igualmente, si sacas 7 / 10 (Competente) , puedes corregir el detalle señalado y subir a 10 / 10 . Todos los Laboratorios y Sprints tienen Intentos Ilimitados abiertos hasta el final del semestre.


#### Why an Assignment Receives 0 / 10 (Recalibrate) / ¿Por qué se asigna un 0 / 10?

- Unverified AI Copy-Paste: Submitting raw AI output without auditing its errors (Part 2) or omitting your 150-word minimum human Active Verification (Part 3) . / Entregar texto copiado de la IA sin auditar sus errores o sin tu Verificación Activa de mínimo 150 palabras.
- Clinical Safety Breach: Prescribing an unsafe intervention (e.g., midday outdoor running in 110°F Yuma heat, or ignoring client medications/contraindications). / Recomendar algo clínicamente peligroso (ej. correr al mediodía a 110°F en Yuma o ignorar medicamentos/contraindicaciones).
- Missing Required Section: Leaving out Part 1 (Engine Prompt with ### ), Part 2 (150-Word Clinical Audit), or Part 3 (150-Word Minimum Active Verification). / Omitir alguna de las partes obligatorias de la entrega.

#### The 4-Step Remedy Roadmap / Los 4 Pasos para Subir tu Calificación a 10 / 10

- Step 1 — Open Your Grades Tab in Canvas (Not the To-Do List): Once an assignment has a 0 / 10 or 7 / 10 score, Canvas removes it from your "To-Do" sidebar. Click Grades in the left course menu and click the assignment title directly. Paso 1 — Abre la pestaña Grades (Calificaciones): Cuando una tarea ya tiene calificación, desaparece de tu lista "Por hacer" (To-Do). Entra a Grades en el menú izquierdo y haz clic en el nombre de la tarea.
- Step 2 — Read Coach Alan's In Plain English SpeedGrader Feedback: Read the specific comment left on your submission (starting with "In plain English:" or "En palabras sencillas:" ) that tells you the exact clinical rule, calculation, or missing section to fix. Paso 2 — Lee el comentario de Coach Alan en SpeedGrader: Revisa la nota específica donde te indico exactamente qué regla clínica, cálculo o sección necesitas completar.
- Step 3 — Revise Only What Was Flagged: Update your submission using Pattern / Rule / Solve (Patrón / Regla / Solución) , cite our Academic Source of Truth, and verify that your Part 3 Active Verification is at least 150 words in your own human voice. Paso 3 — Corrige lo señalado: Ajusta tu entrega aplicando Patrón / Regla / Solución , cita la guía oficial y confirma que tu Verificación Activa tenga mínimo 150 palabras en tu propia voz.
- Step 4 — Click New Attempt and Resubmit: Click New Attempt (or Try Again ), paste or upload your updated work, and submit. Your revision automatically enters Coach Alan's grading queue to be upgraded to 10 / 10 (Exemplary) ! Paso 4 — Haz clic en New Attempt (Nuevo Intento) y envía: Tu entrega actualizada entra automáticamente a revisión para subir tu nota a 10 / 10 (Ejemplar) .
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-265` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-265 • Module 00)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-265 (Module 00)
Client Pattern (Context): A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13).
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-265 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 68-year-old Yuma Foothills older adult with medically cleared controlled hypertension (BP 132/82 mmHg) presents with a Timed Up-and-Go (TUG) score of 13.4 seconds and avoids outdoor heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018, Chapter 6: Older Adults), older adults should perform multicomponent physical activity combining balance training, muscle-strengthening (2+ days/week, rhythmic breathing without Valsalva), and moderate aerobic activity regulated by the Talk Test (RPE 11–13). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate fall-risk and intensity thresholds in exwtoolkit.com: prescribe 3 days/week of indoor climate-controlled multicomponent sessions (10 min tandem/single-leg supported balance + 2 sets x 12 sit-to-stands and row bands exhaling on effort + 20 min RPE 12 walking). Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
