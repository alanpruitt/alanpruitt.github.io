# KIN-101: Mod 03 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Lab & Simulation: Community Fitness & Cultural Trends Audit

Módulo 03 Laboratorio: Auditoría de Cultura Física y Tendencias Comunitarias

- Occupational Physical Activity Transition: Historical shift from high-expenditure agricultural/manual labor to mechanized, screen-based shifts requiring intentional leisure-time movement. En palabras sencillas: El cambio de trabajar físicamente en el campo a pasar el turno sentado frente a pantallas, lo que nos obliga a planear el movimiento diario.
- Social Determinants of Health (SDOH) & Built Environment: Neighborhood shade, park lighting, sidewalk access, and work schedules in Yuma / Imperial Valley that directly shape whether a client can safely reach 150 min/week. En palabras sencillas: Factores reales del barrio—como banquetas, sombra, horarios de empaque y calor—que debemos tomar en cuenta antes de recetar ejercicio.
- Preventive Exercise Medicine (Primary vs. Secondary Prevention): Using PAGA 2018 activity volumes to prevent chronic disease before it starts (primary) or halt progression after diagnosis (secondary). En palabras sencillas: Usar el movimiento a tiempo para evitar que aparezca la diabetes o presión alta, o para controlarlas sin que empeoren.
- KIN-101.2.1.AY26-27: Compare historical physical culture systems (Swedish Medical Gymnastics, German Turnen, and 20th-century epidemiological shifts) to modern Kinesiology subdisciplines.
- KIN-101.3.1.AY26-27: Audit contemporary commercial fitness fads against federal PAGA 2018 (2nd Ed.) public health standards for Yuma County communities.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-03

Outpatient rehab clinic in Yuma, AZ auditing a viral '7-Day Extreme Detox & High-Impact Jump Challenge' being used by a 56-year-old patient with knee osteoarthritis.

Yuma County community recreation program auditing a legacy 1960s 'Elimination Dodgeball & Military Sit-Up Test' curriculum where 70% of youth sit on the sidelines.

High school strength coach in Yuma auditing a social-media 'Daily Max-Out Lifting Trend' (7 days/week heavy lifting with zero aerobic conditioning or rest).


### Phase 2: Gemini AI Clinical Simulation Workspace


### Phase 3: Canvas Text Box Submission Requirements

- Part 1: Pattern Recognition: Diagnose the historical/cultural trend or credentialing/scope scenario for your selected track.
- Part 2: Rule Application (PAGA 2018 & NCCA SSoT): Cite the exact federal PAGA 2018 or NCCA Scope of Practice rules that govern this scenario.
- Part 3: Solve & Bilingual Card (EN / ES): Provide your structured action plan and a 2-sentence bilingual card in English and Spanish.
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify how your professional judgment protects client safety in Yuma County.
- Repository Verification: Confirm archive to EXW_Professional_AI_Repository / EXW_101_M03_Cultural_Trends_Audit.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track: Track 1: Clinical & Allied Health Path (Sofia M., Age 56, Yuma, AZ)

- Part 1: Pattern Recognition: Sofia was drawn to a viral '7-Day High-Impact Jump Challenge' promising rapid weight loss. Historically, this mirrors unregulated commercial fitness fads that ignore Pehr Henrik Ling's Swedish Medical Gymnastics principle of individualized anatomical dosing, exposing her osteoarthritic knees to excessive vertical ground reaction forces and acute thermal strain in Yuma.
- Part 2: Rule Application: Under the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , adults with chronic joint conditions require 150–300 minutes/week of moderate-intensity, low-impact aerobic activity plus 2 or more days/week of multicomponent muscle-strengthening progressed gradually according to joint tolerance.
- Part 3: Solve & Bilingual Card: Replace the jump challenge with 30 minutes of indoor recumbent cycling or aquatic walking 5 days/week (150 min/week at RPE 12) plus 2 days/week of closed-chain chair sit-to-stands, band rows, and hip abduction. Bilingual Card (EN / ES): EN: "Skip high-impact jump fads and protect your knees with 30 minutes of low-impact cycling five days a week plus twice-weekly strength training." / ES: "Evite las modas de saltos de alto impacto y proteja sus rodillas con 30 minutos de bicicleta de bajo impacto cinco días por semana más dos días de fuerza."
- Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment as Sofia's movement architect, viral social media challenges exploit short-term motivation while ignoring articular biomechanics and Yuma's environmental reality. An unverified AI workout generator that echoes 'high-intensity plyometrics for fast calorie burn' would subject Sofia's osteoarthritic tibiofemoral joint to destructive compressive shear, causing an acute inflammatory flare and complete exercise abandonment. By reclaiming the clinical lineage of Swedish Medical Gymnastics and enforcing PAGA 2018 adult standards, we transition her to low-impact indoor cycling and progressive quadriceps/gluteal strengthening. This builds peri-articular muscular support, lubricates synovial cartilage, and sustains lifelong mobility. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M03_Cultural_Trends_Audit.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 03 (Mod 03 Lab: Community Fitness & Cultural Trends Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 03 Laboratorio y Simulación: Auditoría de Cultura Física y Tendencias Comunitarias

- Parte 1 (Patrón): Diagnostique la tendencia o el escenario de alcance profesional de su ruta.
- Parte 2 (Regla SSoT): Cite las reglas exactas de PAGA 2018 o del Alcance de la Práctica NCCA.
- Parte 3 (Solución y Tarjeta Bilingüe): Presente su plan estructurado y tarjeta bilingüe (EN / ES).
- Parte 4 (La Verificación Activa Obligatoria (Parte 3 • Mínimo 150 Palabras)): Justifique en su propia voz clínica cómo su criterio protege al cliente en el condado de Yuma.
- Verificación del Repositorio: Confirme el archivo en EXW_Professional_AI_Repository / EXW_101_M03_Cultural_Trends_Audit.pdf .

### Modelo de Verificación Activa 10/10 (Español)

"En mi criterio clínico como arquitecto del movimiento de Sofía, los retos virales de redes sociales ignoran la biomecánica articular y el clima de Yuma. Si una IA sin verificar recomienda saltos pliométricos a una paciente de 56 años con osteoartritis de rodilla, provocará inflamación aguda y abandono total. Al recuperar la tradición clínica de la Gimnasia Médica Sueca y aplicar los estándares de PAGA 2018 (150 minutos aeróbicos de bajo impacto más 2 días de fortalecimiento muscular), fortalecemos el soporte muscular alrededor de su rodilla de forma segura y sostenible."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:
