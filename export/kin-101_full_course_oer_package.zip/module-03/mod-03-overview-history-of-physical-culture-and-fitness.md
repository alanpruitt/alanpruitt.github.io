# KIN-101: Mod 03 Overview History Of Physical Culture And Fitness

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology


## Mod 03 Overview: History of Physical Culture & Fitness


### Welcome to Module 03: History of Physical Culture & Fitness

Welcome to Week 3! This week, we analyze the historical foundation of physical education, kinesiology, and exercise science. We examine the transition from early European gymnastics systems—Ling’s Swedish Medical Gymnastics (therapeutic alignment) and Jahn’s German Turnen system (nationalist apparatus strength)—to 20th-century militaristic physical readiness testing and modern public health movement science.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework and our SSoT ( PAGA 2018, 2nd Ed. ), you will identify historical movement patterns, apply federal public health activity rules, and solve contemporary inactivity challenges across diverse community, occupational, and clinical environments.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 1, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 3, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 6, 2026, at 11:59 PM MST
- Lab 03 Direct Submission / Entrega de Laboratorio: Monday, September 7, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 03 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Contrast the philosophical objectives, mechanical loading, and cultural origins of Swedish Medical Gymnastics versus the German Turnen apparatus system. Contrastar los objetivos filosóficos, la carga mecánica y los orígenes culturales de la Gimnasia Médica Sueca frente al sistema Turnen alemán.
- CLO 2 (Rule Application): Trace the evolution of 20th-century militaristic readiness testing into modern evidence-based PAGA 2018 federal public health guidelines. Rastrear la evolución de las pruebas de aptitud militar del siglo XX hacia las pautas federales de salud pública PAGA 2018.
- CLO 3 (Problem Solving): Synthesize an integrated physical culture and movement prescription that addresses posture, functional strength, and sedentary compensation for modern agricultural and desk-bound workers in Yuma County. Sintetizar una prescripción de cultura física que aborde la postura, fuerza funcional y sedentarismo en trabajadores agrícolas y de oficina en Yuma.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will evaluate historical physical culture through your selected professional track:

Ling’s Swedish Medical Gymnastics as the precursor to modern physical therapy, postural restoration, corrective exercise, and neuromuscular re-education.

The shift from military readiness to population-level physical activity, school physical education mandates, and community movement equity in rural settings.

Jahn’s Turnen gymnastics apparatus as the lineage for modern calisthenics, progressive overload, barbell physical culture, and athletic performance.


### Module 03 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: European Gymnastics Systems, Military Readiness & PAGA Evolution
- Discussion Board 03: Swedish Alignment vs. German Turnen Strength
- Lab 03: Historical & Philosophical Perspectives in Modern Kinesiology
- Module 03 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 03 (Mod 03 Overview: History of Physical Culture & Fitness)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando un acceso equitativo, compatible con lectores de pantalla y optimizado para dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Módulo 03 Visión General: Historia de la Cultura Física


### Bienvenido al Módulo 03: Evolución Histórica de las Ciencias del Movimiento

¡Bienvenido a la Semana 3! Esta semana analizaremos las raíces históricas de la educación física, la kinesiología y las ciencias del ejercicio. Examinaremos la transición de los primeros sistemas europeos de gimnasia—la Gimnasia Médica Sueca de Ling (alineación terapéutica) y el sistema Turnen alemán de Jahn (fuerza y aparatos)—hacia las pruebas de preparación física militar del siglo XX y la ciencia moderna de la salud pública.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y nuestra fuente SSoT ( PAGA 2018, 2.ª ed. ), identificará patrones históricos de movimiento, aplicará las normas federales de actividad física y resolverá desafíos modernos de inactividad física en entornos comunitarios, laborales y clínicos.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 1 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 3 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 6 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 03: Lunes, 7 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Contrastar los objetivos filosóficos, las cargas mecánicas y el contexto cultural de la Gimnasia Médica Sueca frente al sistema de aparatos Turnen alemán.
- CLO 2 (Regla): Rastrear la transición de las pruebas militaristas de aptitud física del siglo XX hacia las pautas federales de salud pública de PAGA 2018.
- CLO 3 (Solución): Diseñar un programa integral de cultura física que atienda la postura, la fuerza funcional y la compensación del sedentarismo en trabajadores agrícolas y de oficina en el condado de Yuma.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, evaluará la cultura física histórica a través de su ruta profesional:

La Gimnasia Sueca de Ling como precursora de la terapia física moderna, la restauración postural, el ejercicio correctivo y la reeducación neuromuscular.

La transición del acondicionamiento militar a la actividad física poblacional, las leyes de educación física escolar y la equidad comunitaria en zonas rurales.

El sistema Turnen alemán como base de la calistenia moderna, la sobrecarga progresiva, el entrenamiento con barras y el rendimiento atlético.


### Ruta de Aprendizaje del Módulo 03

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Sistemas Europeos de Gimnasia, Preparación Militar y PAGA
- Foro de Discusión 03: Alineación Sueca vs. Fuerza Turnen Alemana
- Laboratorio 03: Perspectivas Históricas y Filosóficas en la Kinesiología
- Comprobación de Conocimientos y Resumen del Módulo 03

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen con los estándares WCAG 2.1 AA para garantizar un aprendizaje accesible, inclusivo y sin barreras en nuestra comunidad.


### Module 03 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 03 Required Readings: History of Physical Culture & Fitness →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 03 Discussion: How Physical Culture Shapes Modern Fitness →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 03 Coaching Sprint: History of Exercise & Community Health →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 03 Lab: Community Fitness & Cultural Trends Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 03 Summary & Wrap-Up: History of Physical Culture & Fitness →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
