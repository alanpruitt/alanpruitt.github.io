# KIN-101: Mod 03 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Discussion: How Physical Culture Shapes Modern Fitness

This week, we evaluate Per Henrik Ling's therapeutic Swedish Medical Gymnastics (corrective alignment) against Friedrich Ludwig Jahn's high-intensity German Turnen apparatus system (mass discipline and strength). Select a career-aligned track below and explore how these 19th-century physical culture philosophies continue to shape modern kinesiology, physical therapy, strength and conditioning, and local Yuma community movement infrastructure!

Esta semana evaluamos la Gimnasia Médica Sueca terapéutica de Per Henrik Ling (alineación correctiva) frente al sistema Turnen alemán de aparatos de alta intensidad de Friedrich Ludwig Jahn (disciplina masiva y fuerza). ¡Seleccione una ruta alineada con su carrera y explore cómo estas filosofías del siglo XIX moldean la kinesiología moderna, la terapia física, la fuerza y el acondicionamiento, y los programas comunitarios en el condado de Yuma!

- Topic Opens / Apertura del Foro: Tuesday, September 1, 2026, at 12:00 AM MST / Martes a las 12:00 AM
- Initial Post Due / Publicación Inicial: Thursday, September 3, 2026, at 11:59 PM MST / Jueves a las 11:59 PM
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 6, 2026, at 11:59 PM MST / Domingo a las 11:59 PM
- Board Closes / Cierre del Foro: Monday, September 7, 2026, at 11:59 PM MST / Lunes a las 11:59 PM
You are warmly encouraged to post in English or Spanish according to your professional comfort. Le animamos a publicar en inglés o en español según su preferencia académica.

Instructor feedback is published openly in this board and in the Gradebook. Reading these threads provides valuable historical context and clinical insights for your learning.


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI Study Preceptor prompt:

Focus: Lineage from Ling's Swedish Medical Gymnastics to modern Physical Therapy, joint mobilization, and postural restoration for desk workers (E.V., 47).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[CASE SUBJECT]: Postural Restoration & Swedish Medical Gymnastics Lineage
[HISTORICAL BASE]: Swedish Medical Gymnastics (Per Henrik Ling) — Anatomical alignment and joint mobilization.
[CLINICAL APPLICATION]: Outpatient Physical Therapy for desk worker (E.V., 47) with thoracic hyperkyphosis.
###
```

Focus: Lineage from Jahn's German Turnen apparatus physical culture to public outdoor fitness stations, adapted for Yuma's high summer heat indices.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CASE SUBJECT]: Public Physical Culture Infrastructure & German Turnen Lineage
[HISTORICAL BASE]: German Turnen Gymnastics (Friedrich Ludwig Jahn) — Open-air apparatus calisthenics.
[COMMUNITY APPLICATION]: Yuma Parks & Recreation adapting outdoor Turnplatz stations to climate-controlled indoor community hubs.
###
```

Focus: Hybridization of Swedish postural joint control and German apparatus power in collegiate Strength & Conditioning (AWC Athletics).


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[CASE SUBJECT]: Hybrid Athletic Conditioning Systems & 19th-Century Synthesis
[HISTORICAL BASE]: Swedish Precision (Ling) + German Apparatus Power (Jahn).
[ATHLETIC APPLICATION]: Collegiate S&C for multi-sport athlete (C.J., 20) merging joint stability with multi-planar power.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a historical kinesiology audit:


```text
Safety Auditor Protocol: KIN-101 Historical Preceptor ###:
Role: Socratic Kinesiology Mentor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and Historical Physical Culture Framework.

Instructions:
Step 1: Review the student's selected career track case data provided in triple-hash (###) delimiters below.
Step 2: Contrast Ling's Swedish Medical Gymnastics with Jahn's German Turnen across philosophy, mechanics, and apparatus use.
Step 3: Trace how these systems directly influenced the modern sub-discipline in the student's track (Physical Therapy, PE, or Strength & Conditioning).
Step 4: Propose a climate-adapted movement solution for Yuma County populations under high summer heat (105°F+).
Step 5: Maintain all case inputs wrapped within delimiters.

Client Data Input ###:
[Paste Your Selected Track Data Block Here]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Historical Contrast: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance). Contrast why Ling prioritized joint alignment and medical calisthenics, while Jahn prioritized national military readiness, discipline, and heavy apparatus. Indique su ruta seleccionada. Resuma por qué Ling priorizó la alineación articular y la gimnasia médica, mientras que Jahn priorizó la disciplina militar y los aparatos.
- Modern Sub-Disciplinary Echoes: Trace how your selected track directly connects 19th-century physical culture to modern professions (e.g., Physical Therapy rehab vs. Strength & Conditioning vs. Public Health/School PE). ¿Cómo se conecta su ruta elegida con las profesiones modernas (p. ej., terapia física, fuerza y acondicionamiento o salud pública/educación física)?
- Community Application (Yuma Regional Context): For your target population in Yuma County facing extreme summer heat indices (105°F+), explain how you adapt these historical movement philosophies for safe, climate-controlled, or indoor execution. Para su población en Yuma ante el calor extremo (105°F+), ¿cómo adapta estas filosofías para una ejecución segura en interiores climatizados?

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Compare their choice of community movement system with yours, and discuss how environmental heat safety affects outdoor group conditioning.

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Compare su elección de sistema de movimiento con la suya y debata sobre la seguridad frente al calor extremo.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Historical Contrast: Per Henrik Ling developed Swedish Gymnastics as a scientific, medical framework prioritizing anatomical alignment, respiratory expansion, and low-impact calisthenics to restore physiological symmetry. In contrast, Friedrich Ludwig Jahn created German Turnen during a national crisis, emphasizing outdoor heavy apparatus (parallel bars, vaulting horses), physical toughness, and mass military discipline for national defense. Per Henrik Ling desarrolló la Gimnasia Sueca como un marco médico que priorizaba la alineación anatómica, la respiración y la calistenia suave para restaurar la simetría fisiológica. En contraste, Friedrich Ludwig Jahn creó el Turnen alemán enfatizando aparatos pesados al aire libre, resistencia y disciplina militar para la defensa nacional.
- Modern Sub-Disciplinary Echoes: Ling's Swedish Medical Gymnastics is the direct predecessor to modern Physical Therapy, clinical gait analysis, and corrective exercise screening. Jahn's German Turnen echoes strongly in modern Strength & Conditioning, gymnastics conditioning, and high-intensity functional training. La Gimnasia Médica de Ling es la antecesora directa de la Terapia Física moderna, el análisis clínico de la marcha y el ejercicio correctivo. El Turnen de Jahn se refleja en la fuerza y el acondicionamiento modernos, la gimnasia y el entrenamiento funcional.
- Yuma Community Application: For Yuma desk worker E.V. (47) suffering from chronic thoracic hyperkyphosis, Ling's Swedish Medical Gymnastics offers greater immediate physiological benefit. High-impact Turnen apparatus work in Yuma's 105°F summer heat imposes extreme thermal and joint stress. Free-standing, climate-controlled Swedish posture drills safely retract the scapulae, strengthen the rhomboids, and relieve lumbar strain without triggering hyperthermia. Para la trabajadora de escritorio E.V. (47) de Yuma con hipercifosis torácica, la Gimnasia Sueca ofrece un beneficio clínico inmediato superior. Los ejercicios posturales suecos en interiores climatizados retraen las escápulas y alivian la tensión lumbar sin exponer al paciente al calor extremo de 105°F.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 03 (Mod 03 Discussion: How Physical Culture Shapes Modern Fitness)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Foro de Discusión 03: Historia de la Cultura Física

Esta semana evaluamos la Gimnasia Médica Sueca de Per Henrik Ling frente al sistema Turnen alemán de Friedrich Ludwig Jahn. Seleccione una ruta profesional y explore cómo estas filosofías históricas siguen vigentes en las ciencias del ejercicio y en el condado de Yuma.

- Apertura del Foro: Martes, 1 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 3 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 6 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 7 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta y Contraste Histórico: Indique su ruta (Ruta 1 Clínica, Ruta 2 Comunitaria, Ruta 3 Rendimiento). Resuma por qué Ling priorizó la alineación anatómica y Jahn la fuerza y aparatos con fines patrióticos.
- Ecos Subdisciplinarios Modernos: Explique cómo su ruta conecta estas escuelas del siglo XIX con profesiones modernas (Terapia Física, Fuerza y Acondicionamiento o Educación Física Escolar).
- Aplicación en Yuma: Proponga adaptaciones seguras en interiores climatizados para la población de Yuma ante el calor extremo de verano (105°F+).

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:
