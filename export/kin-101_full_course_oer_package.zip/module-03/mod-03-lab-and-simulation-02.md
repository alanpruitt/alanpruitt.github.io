# KIN-101: Mod 03 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Coaching Sprint Simulation: History of Exercise & Community Health

Sesión de Coaching del Módulo 03: Historia de la Cultura Física y Salud Comunitaria

- Occupational Physical Activity Transition: Historical shift from high-expenditure agricultural/manual labor to mechanized, screen-based shifts requiring intentional leisure-time movement. En palabras sencillas: El cambio de trabajar físicamente en el campo a pasar el turno sentado frente a pantallas, lo que nos obliga a planear el movimiento diario.
- Social Determinants of Health (SDOH) & Built Environment: Neighborhood shade, park lighting, sidewalk access, and work schedules in Yuma / Imperial Valley that directly shape whether a client can safely reach 150 min/week. En palabras sencillas: Factores reales del barrio—como banquetas, sombra, horarios de empaque y calor—que debemos tomar en cuenta antes de recetar ejercicio.
- Preventive Exercise Medicine (Primary vs. Secondary Prevention): Using PAGA 2018 activity volumes to prevent chronic disease before it starts (primary) or halt progression after diagnosis (secondary). En palabras sencillas: Usar el movimiento a tiempo para evitar que aparezca la diabetes o presión alta, o para controlarlas sin que empeoren.

### Your Weekly Win: From Historical Gymnastics to Modern Public Health

How did two 19th-century European movement traditions—Pehr Henrik Ling's Swedish Medical Gymnastics (therapeutic, anatomical, rehabilitative movement) and Friedrich Ludwig Jahn's German Turnen System (apparatus strength, calisthenics, and athletic conditioning)—shape modern physical therapy, PE, and strength coaching? And how did the 20th-century epidemiological revolution (starting with Dr. Jeremy Morris's London bus study) lead to today's Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) ? Pick your track below and audit a real-world Yuma scenario with your AI Coach!

¿Cómo dieron forma la Gimnasia Médica Sueca y el Sistema Turnen Alemán a la fisioterapia, la educación física y el entrenamiento moderno hasta llegar a las pautas federales de PAGA 2018? ¡Elija su ruta y consulte a su coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Scenario: Outpatient rehabilitation client (Carlos, 58, Yuma postal driver) recovering from shoulder stiffness and sedentary deconditioning.

Scenario: Yuma middle school PE class transitioning away from exclusionary military-style elimination drills toward inclusive PAGA 2018 lifelong wellness.

Scenario: Adult fitness client (David, 30, Yuma, AZ) seduced by a viral "30-Day Extreme Military Bootcamp" social media fad that ignores recovery and PAGA 2018 progression.


### Phase 2: Gemini AI Clinical Simulation Workspace / Consulta de IA


### Phase 3: Canvas Text Box Submission

- Chosen Track & Historical Pattern: State your selected track and explain whether it stems from Swedish Medical Gymnastics, the German Turnen System, or Public Health Epidemiology.
- PAGA 2018 Rule Application: State how federal PAGA 2018 (2nd Ed.) guidelines modernize this historical tradition for lifelong health.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why evidence-based PAGA 2018 progression protects your Yuma client better than outdated militaristic drills or unverified social media fitness fads.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository / EXW_101_M03_Quiz_Sprint.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

- Chosen Track & Historical Pattern: Track 1 (Clinical Path — Carlos, 58, Yuma postal driver). Carlos's rehabilitation draws directly from Pehr Henrik Ling's Swedish Medical Gymnastics (prescribing targeted anatomical range-of-motion movement to heal joint stiffness) combined with Dr. Jeremy Morris's occupational epidemiology showing that sedentary sitting jobs elevate cardiovascular risk compared to active walking roles.
- PAGA 2018 Rule Application: Under PAGA 2018 (2nd Ed.) , modern public health translates these historical discoveries into a clear standard: 150–300 minutes/week of moderate aerobic activity plus at least 2 days/week of multicomponent muscle-strengthening across all major muscle groups.
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, Carlos's shoulder stiffness and sedentary fatigue cannot be solved by a generic internet 'no-pain, no-gain' calisthenics routine, which risks rotator cuff impingement and heat exhaustion after his Yuma postal route. By honoring the clinical heritage of Swedish Medical Gymnastics—where every movement is dosed for anatomical restoration rather than exhaustion—and grounding his weekly target in PAGA 2018 guidelines, we prescribe controlled scapular retraction and resistance-band rows twice a week alongside 30 minutes of brisk early-morning walking five days a week. This evidence-based progression restores glenohumeral mobility and protects his cardiovascular health. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- Part 4: My Memorable Coaching Takeaway: EN: "From 19th-century Swedish Medical Gymnastics to PAGA 2018, the smartest exercise is purposeful movement dosed for lifelong health, not exhaustion!" ES: "¡Desde la Gimnasia Médica Sueca hasta PAGA 2018, el mejor ejercicio es el movimiento con propósito dosificado para la salud de por vida, no para el agotamiento!"
- Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M03_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 03 (Mod 03 Coaching Sprint: History of Exercise & Community Health)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 03 Simulación de Coaching: Historia de la Cultura Física y Salud Comunitaria

- Ruta y Raíz Histórica (Patrón): Indique su ruta y cómo se conecta con la Gimnasia Médica Sueca, el Sistema Turnen Alemán o la Epidemiología de Salud Pública.
- Regla PAGA 2018: Explique cómo las pautas federales de PAGA 2018 actualizan esta tradición histórica.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica por qué la progresión basada en PAGA 2018 protege a su cliente en Yuma frente a modas extremas de internet.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su frase en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:
