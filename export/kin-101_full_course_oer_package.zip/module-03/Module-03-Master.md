## KIN-101 MODULE-03: MOVEMENT MECHANICS / Master Content Loop

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## > ###  Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (Kinesiology disciplines and foundational physical activity rules).

## KIN-101: MODULE 03 - INTRODUCTION TO HUMAN MOVEMENT MECHANICS / INTRODUCCIÓN A LA MECÁNICA DEL MOVIMIENTO HUMANO 

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module introduces the foundational principles of biomechanics and human movement mechanics. Students will analyze kinematics, levers, torque, and force vectors to understand how the musculoskeletal system manages workloads. All mechanical baselines and structural limits align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo introduce los principios fundamentales de la biomecánica y la mecánica del movimiento humano. Los estudiantes analizarán la cinemática, las palancas, el torque y los vectores de fuerza para comprender cómo el sistema musculoesquelético maneja las cargas de trabajo. Todos los puntos de referencia mecánicos y límites estructurales se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.13]):** Analyze foundational human movement mechanics across multiple planes of motion and apply kinetic safety rules to optimize community-level physical activity progressions.
* **Español (Regional) ([LO 2.13]):** Analizar la mecánica fundamental del movimiento humano a través de múltiples planos de movimiento y aplicar reglas de seguridad cinética para optimizar las progresiones de actividad física a nivel comunitario.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Identify and document mechanical variations, including joint tracking deviations and improper center-of-mass displacements during basic movement patterns.
   * **Patrón (Español):** Identificar y documentar variaciones mecánicas, incluyendo desviaciones en el alineamiento articular y desplazamientos inadecuados del centro de masa durante patrones de movimiento básicos.
2. **Rule (English):** Apply foundational kinetic boundaries and physical loading limits detailed in the PAGA 2018 framework to protect musculoskeletal longevity.
   * **Regla (Español):** Aplicar los límites cinéticos fundamentales y las cargas físicas detalladas en el marco de PAGA 2018 para proteger la longevidad musculoesquelética.
3. **Solve (English):** Engineer a modified mechanical coaching framework or physical layout modification that balances joint loading and restores alignment vectors.
   * **Solución (Español):** Diseñar un marco de entrenamiento mecánico modificado o una modificación del diseño físico que equilibre la carga articular y restaure los vectores de alineación.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Andamiaje

## Part A: Gemini AI Simulation (Kinematic Analysis) / Parte A: Simulación por IA de Gemini (Análisis Cinemático)

## English

Students will initialize the virtual mechanics auditing setup within their sandbox workspace. Ensure your simulated mechanical profile inputs remain fully wrapped inside the required layout delimiters below.

```text
## [PASTE SIMULATED MUSCULOSKELETAL JOINT VECTOR DATA HERE]
###
```

1. Use the sandbox environment to audit a simulated mechanical dataset, tracking angular velocity alterations across sagittal and frontal plane profiles.
2. Cross-examine observed joint stress configurations against the physiological adaptation pathways established in the federal PAGA source documentation.
3. Execute an automated audit script within the sandbox to verify that proposed exercise modifications lower localized peak joint shear forces safely.

## Español (Regional)

Los estudiantes inicializarán la configuración de la auditoría mecánica virtual dentro de su espacio de trabajo sandbox. Asegúrese de que las entradas de perfiles mecánicos simulados permanezcan completamente envueltas dentro de los delimitadores de diseño requeridos a continuación.

```text
## [PEGUE LOS DATOS SIMULADOS DE VECTORES ARTICULARES MUSCULOESQUELÉTICOS AQUÍ]
###
```

1. Utilizar el entorno de pruebas (sandbox) para auditar un conjunto de datos mecánicos simulados, rastreando alteraciones de la velocidad angular en los perfiles de los planos sagital y frontal.
2. Evaluar de forma cruzada las configuraciones de estrés articular observadas frente a las vías de adaptación fisiológica establecidas en la documentación oficial de PAGA.
3. Ejecutar un guión de auditoría automatizado dentro del sandbox para verificar que las modificaciones de ejercicio propuestas reduzcan las fuerzas de cizallamiento articulares máximas localizadas de forma segura.

## Part B: Practical Field Application (Biomechanical Assessment)

## English

Students will transition into their immediate regional spaces to execute a practical, zero-cost qualitative movement screen with a peer.

1. Complete a visual movement monitoring log of a functional activity set, tracking alignment markers at the ankle, knee, and hip joints.
2. Map observed movement mechanics onto their respective anatomical axes, documenting any structural breakdown or compensations.
3. Document true structural indicators: record real-time joint tracking vectors and cross-examine modifications against the health targets in the federal PAGA guidelines.

## Español (Regional)

Los estudiantes harán la transición a sus espacios regionales inmediatos para ejecutar una evaluación de movimiento cualitativa práctica y de costo cero con un compañero.

1. Completar un registro de monitoreo visual de un conjunto de actividades funcionales, rastreando marcadores de alineación en las articulaciones del tobillo, la rodilla y la cadera.
2. Mapear la mecánica de movimiento observada en sus respectivos ejes anatómicos, documentando cualquier falla estructural o compensación.
3. Documentar los indicadores estructurales reales: registrar vectores de seguimiento articular en tiempo real y evaluar de forma cruzada las modificaciones frente a las metas de salud en las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This mechanical module assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación del módulo mecánico se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):
  * **English:** Zero-drift integration. All movement corrections match PAGA safety criteria exactly; all simulation log data entries remain fully fenced within required delimiters.
  * **Español (Regional):** Integración sin desviaciones. Todas las correcciones de movimiento coinciden exactamente con los criterios de seguridad de PAGA; todas las entradas de datos del registro de simulación permanecen completamente delimitadas dentro de los rangos requeridos.
* **7 (Competent) / (Competente):
  * **English:** Minor refactoring required. Core Clinical Framing Protocol steps and biomechanical rules are appropriately applied, but minor formatting gaps are flagged in the final repository file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los pasos del Protocolo de Encuadre Clínico y las reglas biomecánicas se aplican adecuadamente, pero se identifican pequeñas brechas de formato en el archivo final del repositorio.
* **0 (Recalibrate) / (Recalibrar):
  * **English:** Critical safety calculation failure or un-fenced joint stress metrics that violate primary movement integrity parameters. Complete rewrite required.
  * **Español (Regional):** Falla crítica en el cálculo de seguridad o métricas de estrés articular sin delimitar que violan los parámetros primarios de integridad del movimiento. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.


<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>


## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
