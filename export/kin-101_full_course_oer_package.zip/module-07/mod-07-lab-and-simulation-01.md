# KIN-101: Mod 07 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 07 Coaching Sprint Simulation: Joint Alignment & Safe Movement

Sesión de Coaching del Módulo 07: Kinesiología y Movimiento

- Dynamic Knee Valgus (Medial Knee Collapse): Inward caving of the knees during squats or landings, typically caused by underactive gluteus medius/maximus and tight adductors. En palabras sencillas: Cuando las rodillas se meten hacia adentro al bajar en sentadilla; se corrige activando la cadera y el glúteo con buena técnica.
- Neutral Spine & Lumbo-Pelvic-Hip Complex (LPHC) Stability: Maintaining natural spinal curves without excessive lower-back overarching (anterior pelvic tilt) or rounding (flexion) under load. En palabras sencillas: Mantener la espalda firme y derechita desde el abdomen y los glúteos para proteger los discos lumbares al cargar peso.
- Length-Tension Relationship & Muscle Imbalance: Tight, overactive muscles inhibit their opposite underactive muscles (altered reciprocal inhibition), pulling joints out of safe alignment. En palabras sencillas: Cuando un músculo está muy tenso por pasar horas sentado, apaga al músculo contrario y desalinea la postura.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Kinesiology studies how anatomical muscles contract to move the human skeleton through space. Adjusting your joint angle or foot stance changes the muscular torque required to lift a load. Delivering direct coaching cues helps clients lift with mechanical advantage and avoid joint strain.


#### En Palabras Sencillas (Norteño Context)

Piénsalo como usar una barra de acero para mover un tronco pesado en el rancho: si apoyas bien el fulcro, haces la mitad del esfuerzo. Si los términos técnicos se ponen pesados, concéntrate primero en corregir la postura con una sola indicación clara y sencilla.

- KIN-101.7.1.AY26-27: Apply PAGA 2018 musculoskeletal guidelines to analyze anatomical planes, lever classes, and joint torques in human movement. Aplicar las pautas musculoesqueléticas de la PAGA 2018 para analizar planos anatómicos, clases de palancas y torques articulares.
- KIN-101.7.2.AY26-27: Audit movement patterns, kinetic chain sequencing, and mechanical efficiency across physical education, clinical, and athletic coaching contexts. Auditar patrones de movimiento, la secuenciación de la cadena cinética y la eficiencia mecánica en contextos educativos, clínicos y deportivos.
- Module Window / Ventana del Módulo: Opens Tuesday, September 29, 2026, at 12:00 AM MST Abre el martes, 29 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 5, 2026, at 11:59 PM MST Lunes, 5 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Coaching Sprint Benchmark (10/7/0 Mastery Scale) Ponderación para sesiones semanales de coaching y simulación

### Your Weekly Win: Mastering Movement Mechanics & Lever Efficiency

How does understanding biomechanics and kinesiology empower physical educators, therapists, and coaches to enhance human movement? Analyzing anatomical planes, lever systems, and joint moment arms allows practitioners to eliminate energy leaks, protect vulnerable connective tissues, and maximize force production. Following strict PAGA 2018 musculoskeletal guidelines, exercise leaders can audit kinetic chain alignment and design injury-resistant movement patterns. Choose your coaching track below, chat with your AI Socratic Coach, and master movement analysis!

¿Cómo ayuda la biomecánica a educadores, terapeutas y entrenadores a optimizar el movimiento humano? Comprender las palancas y los planos anatómicos previene lesiones y mejora la eficiencia. ¡Elija su ruta y dialogue con su coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Selección de Escenario de Simulación Clínica

Scenario: Physical therapy client (Marcus, 23) demonstrating severe dynamic knee valgus and tibial internal rotation during bilateral squatting 6 months after ACL reconstruction.

Scenario: High school physical education student (Sofia, 15) rounding her lumbar spine during deadlifts, creating a large spinal resistance moment arm.

Scenario: College track athlete (Darius, 20) popping upright out of starting blocks, losing acceleration force vectors and kinetic chain triple extension.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's movement limitation or biomechanical deficit.
- Biomechanical & Movement Analysis: Explain anatomical planes, lever classes, and PAGA 2018 musculoskeletal concepts for your client.
- My Biomechanical Correction: Provide 1 clear, evidence-based movement cue or mechanical correction.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying how correcting dynamic knee valgus or shortening external moment arms protects joint alignment during PAGA 2018 strength training in Yuma.

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 07 Coaching Sprint • Track 1 (Clinical / Marcus)

- Chosen Track & Client: Track 1: Clinical & Allied Health Path (Marcus, 23). Challenge: Marcus is 6 months post-ACL reconstruction and displays severe dynamic knee valgus (frontal plane collapse) and internal tibial rotation during bodyweight squats.
- Track 1: Clinical & Allied Health Path (Marcus, 23).
- Challenge: Marcus is 6 months post-ACL reconstruction and displays severe dynamic knee valgus (frontal plane collapse) and internal tibial rotation during bodyweight squats.
- Biomechanical & Movement Analysis: PAGA 2018 Musculoskeletal Guidelines & Lever Mechanics: In a bilateral squat, movement should occur primarily in the sagittal plane (hip flexion, knee flexion, ankle dorsiflexion). Marcus exhibits uncontrolled frontal plane hip adduction and transverse internal rotation because his hip abductors (gluteus medius) fail to stabilize the 3rd-class lever arm of the femur. This misalignment places dangerous tensile strain on the healing ACL graft and patellofemoral joint. Restoring kinetic chain integrity requires multi-joint alignment cueing before progressive mechanical load is added.
- PAGA 2018 Musculoskeletal Guidelines & Lever Mechanics: In a bilateral squat, movement should occur primarily in the sagittal plane (hip flexion, knee flexion, ankle dorsiflexion). Marcus exhibits uncontrolled frontal plane hip adduction and transverse internal rotation because his hip abductors (gluteus medius) fail to stabilize the 3rd-class lever arm of the femur. This misalignment places dangerous tensile strain on the healing ACL graft and patellofemoral joint.
- Restoring kinetic chain integrity requires multi-joint alignment cueing before progressive mechanical load is added.
- My Biomechanical Correction for Marcus: "Place a light resistance loop around Marcus's distal thighs to provide tactile feedback, instructing him to actively abduct against the band to keep the patella tracking over the second toe throughout the squat."
- "Place a light resistance loop around Marcus's distal thighs to provide tactile feedback, instructing him to actively abduct against the band to keep the patella tracking over the second toe throughout the squat."
- My Memorable Coaching Takeaway: EN: "Aligning your kinetic chain and controlling your levers turns vulnerable joints into powerful movement foundations!" ES: "¡Alinear la cadena cinética y controlar las palancas convierte las articulaciones vulnerables en bases de movimiento poderosas!"
- EN: "Aligning your kinetic chain and controlling your levers turns vulnerable joints into powerful movement foundations!"
- ES: "¡Alinear la cadena cinética y controlar las palancas convierte las articulaciones vulnerables en bases de movimiento poderosas!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M07_Quiz_Sprint.pdf
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, a generic AI workout prescribes high-rep jump squats or heavy barbell lifts without auditing frontal-plane knee alignment or moment-arm torque. When a client exhibits dynamic knee valgus (femoral internal rotation and adduction from weak gluteus medius control), adding load magnifies ACL and patellofemoral shear stress. As the human coach, I regress the movement to a goblet squat with a mini-band around the knees, shorten the external moment arm by keeping the weight at the chest, and build multi-joint PAGA 2018 lower-body strength safely. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 07 (Mod 07 Coaching Sprint: Joint Alignment & Safe Movement)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 07 Simulación de Coaching: Kinesiología y Movimiento

Evaluación Rápida y Auditoría Biomecánica del Movimiento


### Su Logro Semanal: Dominando la Mecánica del Movimiento y la Eficiencia de Palancas

Esta sesión le permitirá aplicar los conceptos biomecánicos y las pautas musculoesqueléticas de PAGA 2018 para analizar planos anatómicos, optimizar las palancas articulares y corregir patrones motrices. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Paciente de fisioterapia (Marcus, 23 años) que presenta valgo dinámico severo de rodilla y rotación tibial interna en sentadilla tras cirugía de LCA.

Escenario: Estudiante de educación física de preparatoria (Sofía, 15 años) que redondea la columna lumbar en el peso muerto, aumentando el brazo de momento de resistencia.

Escenario: Atleta universitario de pista (Darius, 20 años) que se yergue prematuramente durante la aceleración, perdiendo el vector horizontal y la triple extensión.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el déficit biomecánico de su cliente.
- Análisis Biomecánico y del Movimiento: Explique los planos anatómicos, las palancas y los conceptos de la PAGA 2018 para su cliente.
- Mi corrección biomecánica: Escriba 1 corrección motriz clara y basada en evidencia.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica justificando cómo corregir el valgo dinámico de rodilla y acortar el brazo de momento protege las articulaciones según PAGA 2018.

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 07 Sesión de Coaching • Ruta 1 (Clínica / Marcus)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Profesiones de la Salud (Marcus, 23 años). Reto: Marcus está a 6 meses post-reconstrucción de LCA y presenta valgo dinámico severo de rodilla (colapso en plano frontal) y rotación tibial interna en sentadillas libres.
- Ruta 1: Clínica y Profesiones de la Salud (Marcus, 23 años).
- Reto: Marcus está a 6 meses post-reconstrucción de LCA y presenta valgo dinámico severo de rodilla (colapso en plano frontal) y rotación tibial interna en sentadillas libres.
- Análisis Biomecánico y del Movimiento: Pautas Musculoesqueléticas de PAGA 2018 y Palancas: En la sentadilla bilateral, el movimiento debe producirse predominantemente en el plano sagital. Marcus presenta una aducción no controlada en el plano frontal y una rotación interna transversal, debido a que el glúteo medio no estabiliza la palanca de 3.ª clase del fémur, lo que somete al injerto de LCA a una tensión lesiva. Restablecer la integridad de la cadena cinética requiere corregir la alineación articular antes de progresar con la sobrecarga mecánica.
- Pautas Musculoesqueléticas de PAGA 2018 y Palancas: En la sentadilla bilateral, el movimiento debe producirse predominantemente en el plano sagital. Marcus presenta una aducción no controlada en el plano frontal y una rotación interna transversal, debido a que el glúteo medio no estabiliza la palanca de 3.ª clase del fémur, lo que somete al injerto de LCA a una tensión lesiva.
- Restablecer la integridad de la cadena cinética requiere corregir la alineación articular antes de progresar con la sobrecarga mecánica.
- Mi corrección biomecánica para Marcus: "Colocar una banda de resistencia ligera alrededor de los muslos distales para brindar retroalimentación táctil, indicándole empujar hacia afuera para mantener la rótula alineada con el segundo dedo del pie."
- "Colocar una banda de resistencia ligera alrededor de los muslos distales para brindar retroalimentación táctil, indicándole empujar hacia afuera para mantener la rótula alineada con el segundo dedo del pie."
- Mi Frase Inolvidable de Coaching: EN: "Aligning your kinetic chain and controlling your levers turns vulnerable joints into powerful movement foundations!" ES: "¡Alinear la cadena cinética y controlar las palancas convierte las articulaciones vulnerables en bases de movimiento poderosas!"
- EN: "Aligning your kinetic chain and controlling your levers turns vulnerable joints into powerful movement foundations!"
- ES: "¡Alinear la cadena cinética y controlar las palancas convierte las articulaciones vulnerables en bases de movimiento poderosas!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M07_Quiz_Sprint.pdf
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, un plan genérico de IA prescribe saltos o cargas pesadas sin evaluar el valgo dinámico de rodilla ni el brazo de momento. Al fortalecer el glúteo medio, mantener la carga cerca del centro de masa y aplicar progresiones seguras bajo PAGA 2018, protegemos la articulación de la rodilla y la columna lumbar."
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:
