# KIN-101: Mod 07 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 07 Lab & Simulation: Everyday Movement & Posture Audit

Laboratorio del Módulo 07: Análisis Biomecánico, Cinemática Articular y Simulación del Movimiento

- Dynamic Knee Valgus (Medial Knee Collapse): Inward caving of the knees during squats or landings, typically caused by underactive gluteus medius/maximus and tight adductors. En palabras sencillas: Cuando las rodillas se meten hacia adentro al bajar en sentadilla; se corrige activando la cadera y el glúteo con buena técnica.
- Neutral Spine & Lumbo-Pelvic-Hip Complex (LPHC) Stability: Maintaining natural spinal curves without excessive lower-back overarching (anterior pelvic tilt) or rounding (flexion) under load. En palabras sencillas: Mantener la espalda firme y derechita desde el abdomen y los glúteos para proteger los discos lumbares al cargar peso.
- Length-Tension Relationship & Muscle Imbalance: Tight, overactive muscles inhibit their opposite underactive muscles (altered reciprocal inhibition), pulling joints out of safe alignment. En palabras sencillas: Cuando un músculo está muy tenso por pasar horas sentado, apaga al músculo contrario y desalinea la postura.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Biomechanics analyzes how muscles, bones, and joints function as mechanical levers to generate motion. When joints lose alignment during lifting, moment arms lengthen and increase physical stress across connective tissues. Learning to detect movement faults protects your clients from chronic joint wear and builds functional physical resilience.


#### En Palabras Sencillas (Norteño Context)

Mover el cuerpo con mala postura es como querer aflojar una tuerca barrida con una llave chueca: terminas amolando la herramienta y no sacas la chamba. Si los términos técnicos se ponen pesados, concéntrate primero en alinear las rodillas con los pies antes de meterle más peso a la barra.


### Anatomical Levers, Multi-Planar Motion, & Kinetic Chain Mechanics

In this laboratory assignment, you will conduct a qualitative biomechanical movement audit and construct an evidence-based movement remediation protocol. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze joint angles, moment arms, and lever mechanics, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) musculoskeletal development standards, and execute an AI-driven simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría biomecánica cualitativa y diseñará un protocolo de corrección motriz basado en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando palancas y alineación articular.

- KIN-101.7.3.AY26-27: Evaluate multi-planar movement efficiency, joint actions, and resistance moment arms during foundational exercise patterns. Evaluar la eficiencia del movimiento multiplanar, de las acciones articulares y de los brazos de momento en patrones de ejercicio fundamentales.
- KIN-101.7.4.AY26-27: Design qualitative biomechanical corrections and bilingual coaching cue cards aligned with PAGA 2018 musculoskeletal guidelines. Diseñar correcciones biomecánicas cualitativas y tarjetas de instrucción bilingües alineadas con las pautas de la PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, September 29, 2026, at 12:00 AM MST Abre el martes, 29 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 5, 2026, at 11:59 PM MST lunes, 5 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones prácticas

### Lab Objectives

Objetivos del Laboratorio

- Audit the biomechanical mechanisms of kinetic chain dysfunction, lever inefficiencies, and aberrant joint torques during human movement. Auditar los mecanismos biomecánicos de disfunción de la cadena cinética, las fallas de palanca y los torques articulares anómalos.
- Apply federal PAGA 2018 (2nd Ed.) musculoskeletal guidelines to structure multi-joint progressive loading that preserves connective tissue integrity and optimizes functional movement patterns. Aplicar las pautas de la PAGA 2018 para estructurar sobrecargas progresivas multiarticulares que protejan los tejidos conectivos.
- Formulate a 4-week qualitative movement remediation plan paired with bilingual coaching cue cards in English and Spanish. Formular un plan de corrección motriz de 4 semanas con tarjetas de instrucción bilingües en inglés y español.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-07

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos Biomecánicos

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Physical therapy rehabilitation; auditing dynamic knee valgus, tibial internal rotation, and hip abductor lever mechanics in post-ACL reconstruction.

Focus: High school physical education and movement literacy; correcting excessive lumbar moment arms and establishing proper hip-hinge mechanics during lifting.

Focus: Sprint acceleration mechanics; optimizing horizontal ground reaction force vectors, positive shin angles, and triple extension out of start blocks.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete biomechanical audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline movement profile.
- Part 1: Pattern Recognition: Identify specific kinematic flaws (anatomical planes, lever moment arms, aberrant joint actions).
- Part 2: Rule Application: Cite PAGA 2018 musculoskeletal standards for multi-joint functional strength and kinetic alignment.
- Part 3: Solving the Gap: Detail a 4-week movement remediation plan (progressive drills and corrective exercises) with a 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why your kinetic-chain alignment and lever modification prevent joint injury better than generic AI exercise lists.

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient J.M. demonstrates severe dynamic knee valgus (frontal plane hip adduction and internal rotation) during bilateral squatting. The femur operates as a 3rd-class lever; weakness in the gluteus medius fails to produce sufficient counter-torque to stabilize the hip joint. Simultaneously, restricted talocrural dorsiflexion forces compensatory foot pronation and tibial internal rotation, creating excessive lateral patellofemoral shear forces and hazardous tensile load across the reconstructed ACL graft.

Part 2: Rule Application (SSoT PAGA 2018 2nd Ed Standards): Under PAGA 2018 (2nd Ed.) musculoskeletal guidelines, progressive multi-joint resistance training must develop balanced strength across major muscle groups while reinforcing safe kinematic alignment. Mechanical overload must not be progressed until closed-chain joint alignment (hip-knee-ankle tracking in the sagittal plane) is fully mastered under submaximal loading.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): 4-Week Biomechanical Remediation Protocol (3 Days/Week): Key Point — Joint Mobility Preparation: Half-kneeling talocrural wall mobilization (3 sets x 10 reps per side) to restore sagittal ankle dorsiflexion. Key Point — Closed-Chain Alignment: Goblet squats with a distal mini-band loop (3 sets x 10 reps) enforcing external hip rotation and keeping patellae tracked over the second toe. Key Point — Unilateral Loading Progression: Isometric split squats transitioning to reverse lunges (3 sets x 8 reps per leg) to eliminate bilateral asymmetrical compensation.

EN: "Push your knees outward against the band to keep them tracking directly over your second toe throughout the squat. Keep your chest tall and drive evenly through the full foot."

ES: "Empuje las rodillas hacia afuera contra la banda para mantenerlas alineadas con el segundo dedo del pie durante toda la sentadilla. Mantenga el pecho erguido y empuje de manera uniforme con toda la planta del pie."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI exercise generator cannot see kinetic-chain compensations such as ankle dorsiflexion restriction driving pronation and medial knee collapse, or thoracic kyphosis causing scapular dyskinesis during overhead pressing. By auditing the entire kinetic chain from the ground up, restoring ankle and thoracic mobility first, and shortening external lever arms during PAGA 2018 twice-weekly resistance sessions, I eliminate destructive joint shear forces while building real-world postural endurance for my Yuma client. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_101_M07_Biomechanics_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 07 (Mod 07 Lab: Everyday Movement & Posture Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 07 Práctica de Lab y Simulación: Análisis Biomecánico y Simulación

Palancas Anatómicas, Movimiento Multiplanar y Mecánica de la Cadena Cinética


### Palancas Anatómicas, Movimiento Multiplanar y Mecánica de la Cadena Cinética

En esta práctica de laboratorio, realizará una auditoría biomecánica cualitativa y diseñará un protocolo de corrección motriz. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará ángulos articulares, brazos de momento, aplicará normas de desarrollo musculoesquelético de PAGA 2018 (2.ª edición) y ejecutará una simulación con Google Gemini.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Rehabilitación en fisioterapia; análisis del valgo dinámico de rodilla, de la rotación tibial interna y de la palanca del glúteo medio tras la cirugía de LCA.

Enfoque: educación física en la preparatoria; corrección del brazo de momento lumbar y enseñanza de la bisagra de cadera al levantar peso.

Enfoque: Mecánica de la aceleración de la velocidad; optimización del vector de fuerza horizontal, del ángulo de la tibia y de la triple extensión.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Educación / Ruta 3 Deportiva) e incluya sus iniciales.


#### Parte 1: Reconocimiento de Patrones

Identifique la falla cinemática de su cliente (planos anatómicos, brazos de momento de palancas o acciones articulares anómalas).


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Aplique los estándares de la PAGA 2018 para fortalecer los grandes grupos musculares, preservando la alineación articular y la cadena cinética.


#### Parte 3: Resolución de la Brecha

Detalle un plan de corrección motriz de 4 semanas (con ejercicios progresivos y retroalimentación técnica), junto con una tarjeta de instrucción bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: La paciente J.M. presenta valgo dinámico severo de rodilla (aducción y rotación interna de la cadera en el plano frontal) al realizar sentadillas. El fémur actúa como una palanca de 3.ª clase; la debilidad del glúteo medio no genera un torque suficiente para estabilizar la cadera. A su vez, la dorsiflexión limitada del tobillo obliga a una pronación compensatoria del pie, lo que provoca cizallamiento femororrotuliano y tensión sobre el injerto de LCA.

Parte 2: Aplicación de Reglas (PAGA 2018): Según la PAGA 2018 (2.ª edición), el entrenamiento de fuerza debe desarrollar la fuerza funcional, protegiendo la alineación cinemática. No se debe aumentar la carga mecánica hasta que el control en cadena cerrada (alineación cadera-rodilla-tobillo en plano sagital) esté dominado.

Parte 3: Resolución de la Brecha: Protocolo de 4 semanas: movilización talocrural en pared (3 series x 10 reps), sentadillas goblet con banda elástica distal (3 series x 10 reps) y sentadillas divididas isométricas (3 series x 8 reps). Tarjeta Bilingüe: "Empuje las rodillas hacia afuera contra la banda para mantenerlas alineadas con el segundo dedo del pie durante toda la sentadilla. Mantenga el pecho erguido y empuje de manera uniforme con toda la planta del pie."

Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica cómo la alineación de la cadena cinética y el ajuste de palancas previenen lesiones articulares bajo PAGA 2018.

Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, una IA no puede observar compensaciones en la cadena cinética como la falta de dorsiflexión de tobillo que provoca colapso medial de la rodilla. Al corregir la alineación desde la base de sustentación y acortar las palancas externas bajo las pautas de PAGA 2018, prevenimos lesiones articulares en nuestro cliente en Yuma."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M07_Biomechanics_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:
