# KIN-101: Mod 11 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 11 Coaching Sprint Simulation: Adapting Exercise for Different Ages

Sesión de Coaching del Módulo 11: Actividad Física a lo Largo de la Vida y Poblaciones Especiales

- Youth 60-Minute Daily Activity Triad (PAGA 2018 Ch. 3): Children and adolescents (ages 6–17) require ≥60 minutes/day of moderate-to-vigorous activity, including vigorous aerobic, muscle-strengthening, and bone-strengthening (impact/jumping) ≥3 days/week each. En palabras sencillas: Niños y jóvenes necesitan 60 minutos diarios de movimiento activo que incluyan juegos vigorosos, fuerza y saltos para fortalecer los huesos al menos 3 días por semana.
- Older Adult Multicomponent Training (PAGA 2018 Ch. 5): Adults ≥65 years require weekly multicomponent physical activity combining balance training, muscle-strengthening (≥2 days/wk), and aerobic movement (150–300 min/wk as abilities allow) to prevent falls. En palabras sencillas: En adultos mayores combinamos tres piezas cada semana—equilibrio, fuerza y caminata—para evitar caídas y mantener su independencia diaria.
- Sarcopenia & Relative Intensity (0–10 Perceived Effort Scale): Age-related loss of skeletal muscle mass and strength; PAGA 2018 specifies judging older adults' moderate intensity (5–6 out of 10) relative to their own current fitness level. En palabras sencillas: La pérdida de músculo con la edad se frena con fuerza segura, midiendo el esfuerzo (5 a 6 de 10) según la capacidad real de cada persona mayor.
- KIN-101.11.1.AY26-27: Apply PAGA 2018 lifespan activity standards and physiological aging markers to analyze sarcopenia and functional independence. Aplicar las normas de actividad a lo largo de la vida de la PAGA 2018 y los marcadores de envejecimiento fisiológico para analizar la sarcopenia.
- KIN-101.11.2.AY26-27: Audit adapted exercise programming and balance protocols across physical education, clinical rehabilitation, and sports coaching contexts. Auditar la programación de ejercicio adaptado y los protocolos de equilibrio en contextos educativos, clínicos y deportivos.

### Your Weekly Win: Mastering Lifespan Activity & Adapted Exercise

How does understanding physiological aging empower physical educators, therapists, and coaches to guide lifelong functional independence? Examining sarcopenia, proprioceptive decline, and special population constraints allows practitioners to design safe, modified exercise protocols. Following federal PAGA 2018 lifespan standards, exercise leaders can structure evidence-based balance and strength interventions tailored to diverse demographics. Choose your coaching track below, chat with your AI Socratic Coach, and master adapted exercise analysis!

¿Cómo ayuda la comprensión del envejecimiento fisiológico a educadores, terapeutas y entrenadores a guiar la independencia funcional? Examinar la sarcopenia y las restricciones de poblaciones especiales permite diseñar protocolos de ejercicio seguros. ¡Elija su ruta y dialogue con su coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Scenario: Geriatric participant (M.G., 74) exhibiting age-related sarcopenia, severe balance instability, and fear of falling following a recent minor slip.

Scenario: Senior center mobility cohort (Average Age, 72) experiencing joint stiffness, reduced functional mobility, and social isolation.

Scenario: Master's competitive runner (R.V., 52) experiencing age-related declines in explosive power and running economy.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission / Fase 3: Entrega en Canvas (Solo Texto)

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's functional challenge.
- Lifespan & Aging Analysis: Explain sarcopenia, balance needs, and PAGA 2018 lifespan standards for your client.
- Part 3: Active Verification & Adapted Exercise Strategy: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your multicomponent balance training and progressive resistance loading protect client safety and prevent fall hazards under PAGA 2018 lifespan standards.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 11 Coaching Sprint • Track 1 (Clinical / M.G.)

- Chosen Track & Client: Track 1: Clinical & Allied Health Path (M.G., 74). Challenge: M.G. exhibits age-related sarcopenia, loss of proprioceptive feedback, severe balance instability, and a fear of falling following a recent minor slip.
- Track 1: Clinical & Allied Health Path (M.G., 74).
- Challenge: M.G. exhibits age-related sarcopenia, loss of proprioceptive feedback, severe balance instability, and a fear of falling following a recent minor slip.
- Lifespan & Aging Analysis: PAGA 2018 Lifespan Standards & Balance: Older adults require multicomponent physical activity combining moderate aerobic exercise, progressive resistance training, and specific balance training on 3 or more days per week to mitigate fall risks and preserve functional autonomy. Targeting neuromuscular responsiveness counters age-related motor unit loss.
- PAGA 2018 Lifespan Standards & Balance: Older adults require multicomponent physical activity combining moderate aerobic exercise, progressive resistance training, and specific balance training on 3 or more days per week to mitigate fall risks and preserve functional autonomy.
- Targeting neuromuscular responsiveness counters age-related motor unit loss.
- Part 3: Active Verification & Adapted Exercise Strategy: "Implement daily progressive static and dynamic balance drills paired with 2 days/week of seated resistance training to improve lower-limb strength and prevent falls." Active Verification: In my clinical reasoning, M.G.'s primary barrier to recovery is not simply chronological age, but the psychological fear of falling that triggered severe physical deconditioning and quadriceps wasting. Prescribing walking alone would be hazardous given her 14.8-second TUG score. By grounding her intervention in PAGA 2018 older adult standards—integrating chair-supported static balance drills before advancing to dynamic heel-to-toe gait, and strengthening lower-limb extensors—we systematically retrain proprioceptive pathways and rebuild physical autonomy while eliminating unsupervised fall risks.
- "Implement daily progressive static and dynamic balance drills paired with 2 days/week of seated resistance training to improve lower-limb strength and prevent falls."
- Active Verification: In my clinical reasoning, M.G.'s primary barrier to recovery is not simply chronological age, but the psychological fear of falling that triggered severe physical deconditioning and quadriceps wasting. Prescribing walking alone would be hazardous given her 14.8-second TUG score. By grounding her intervention in PAGA 2018 older adult standards—integrating chair-supported static balance drills before advancing to dynamic heel-to-toe gait, and strengthening lower-limb extensors—we systematically retrain proprioceptive pathways and rebuild physical autonomy while eliminating unsupervised fall risks.
- Part 4: My Memorable Coaching Takeaway: EN: "Integrating multicomponent balance training and progressive resistance exercise preserves functional autonomy and dramatically reduces fall risks in older adults!" ES: "¡Integrar entrenamiento de equilibrio multicomponente y resistencia progresiva preserva la autonomía funcional y reduce drásticamente el riesgo de caídas en adultos mayores!"
- EN: "Integrating multicomponent balance training and progressive resistance exercise preserves functional autonomy and dramatically reduces fall risks in older adults!"
- ES: "¡Integrar entrenamiento de equilibrio multicomponente y resistencia progresiva preserva la autonomía funcional y reduce drásticamente el riesgo de caídas en adultos mayores!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M11_Quiz_Sprint.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 11 (Mod 11 Coaching Sprint: Adapting Exercise for Different Ages)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 11 Simulación de Coaching: Actividad a lo Largo de la Vida

Evaluación Rápida y Auditoría de Ejercicio Adaptado


### Su Logro Semanal: Dominando la Actividad a lo Largo de la Vida y el Ejercicio Adaptado

Esta sesión le permitirá aplicar los marcadores de envejecimiento fisiológico y las pautas de PAGA 2018 para analizar la sarcopenia y estructurar estrategias de ejercicio adaptado. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Participante geriátrico (M.G., 74 años) con sarcopenia relacionada con la edad, inestabilidad de equilibrio y miedo a las caídas.

Escenario: Cohorte de movilidad de adultos mayores (Edad promedio, 72 años) con rigidez articular y movilidad funcional reducida.

Escenario: Corredor máster competitivo (R.V., 52 años) con descensos en potencia explosiva y economía de carrera.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío funcional de su cliente.
- Análisis de Envejecimiento y Vida: Explique la sarcopenia, las necesidades de equilibrio y las normas de PAGA 2018 para su cliente.
- Parte 3: Verificación Activa y Estrategia Adaptada: En una defensa de texto obligatoria (aprox. mínimo 150 palabras (150+ palabras)) escrita en su propia voz clínica, justifique por qué su entrenamiento de equilibrio multicomponente y carga de resistencia protegen la seguridad y previenen caídas según las pautas de PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 11 Sesión de Coaching • Ruta 1 (Clínica / M.G.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Profesiones de la Salud (M.G., 74 años). Reto: M.G. exhibe sarcopenia relacionada con la edad, pérdida de retroalimentación propioceptiva, inestabilidad severa de equilibrio y miedo a las caídas.
- Ruta 1: Clínica y Profesiones de la Salud (M.G., 74 años).
- Reto: M.G. exhibe sarcopenia relacionada con la edad, pérdida de retroalimentación propioceptiva, inestabilidad severa de equilibrio y miedo a las caídas.
- Análisis de Envejecimiento y Vida: Normas de PAGA 2018 y Equilibrio: Los adultos mayores requieren actividad física multicomponente combinando ejercicio aeróbico moderado, entrenamiento de resistencia progresiva y entrenamiento de equilibrio específico en 3 o más días por semana para mitigar riesgos de caídas y preservar la autonomía funcional. Contrarrestar la pérdida de unidades motoras preserva la estabilidad postural.
- Normas de PAGA 2018 y Equilibrio: Los adultos mayores requieren actividad física multicomponente combinando ejercicio aeróbico moderado, entrenamiento de resistencia progresiva y entrenamiento de equilibrio específico en 3 o más días por semana para mitigar riesgos de caídas y preservar la autonomía funcional.
- Contrarrestar la pérdida de unidades motoras preserva la estabilidad postural.
- Parte 3: Verificación Activa y Estrategia Adaptada: "Implementar ejercicios diarios de equilibrio estático y dinámico progresivo combinados con 2 días/semana de entrenamiento de resistencia sentado para mejorar la fuerza de las extremidades inferiores y prevenir caídas." Verificación Activa: En mi criterio clínico, el obstáculo principal de M.G. no es simplemente su edad, sino el miedo psicológico a caerse que causó desentrenamiento severo y atrofia en cuádriceps. Prescribir caminata sola sería peligroso con su tiempo TUG de 14.8 segundos. Al anclar su intervención en las normas de PAGA 2018—integrando equilibrio estático con apoyo antes de avanzar a la marcha dinámica y fortaleciendo extensores inferiores—reentrenamos de manera segura las vías propioceptivas sin exponerla a riesgos de caídas desatendidas.
- "Implementar ejercicios diarios de equilibrio estático y dinámico progresivo combinados con 2 días/semana de entrenamiento de resistencia sentado para mejorar la fuerza de las extremidades inferiores y prevenir caídas."
- Verificación Activa: En mi criterio clínico, el obstáculo principal de M.G. no es simplemente su edad, sino el miedo psicológico a caerse que causó desentrenamiento severo y atrofia en cuádriceps. Prescribir caminata sola sería peligroso con su tiempo TUG de 14.8 segundos. Al anclar su intervención en las normas de PAGA 2018—integrando equilibrio estático con apoyo antes de avanzar a la marcha dinámica y fortaleciendo extensores inferiores—reentrenamos de manera segura las vías propioceptivas sin exponerla a riesgos de caídas desatendidas.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Integrating multicomponent balance training and progressive resistance exercise preserves functional autonomy and dramatically reduces fall risks in older adults!" ES: "¡Integrar entrenamiento de equilibrio multicomponente y resistencia progresiva preserva la autonomía funcional y reduce drásticamente el riesgo de caídas en adultos mayores!"
- EN: "Integrating multicomponent balance training and progressive resistance exercise preserves functional autonomy and dramatically reduces fall risks in older adults!"
- ES: "¡Integrar entrenamiento de equilibrio multicomponente y resistencia progresiva preserva la autonomía funcional y reduce drásticamente el riesgo de caídas en adultos mayores!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M11_Quiz_Sprint.pdf
KIN-101 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
