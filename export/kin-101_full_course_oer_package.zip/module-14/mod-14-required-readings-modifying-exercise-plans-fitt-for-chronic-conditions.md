# KIN-101: Mod 14 Required Readings Modifying Exercise Plans Fitt For Chronic Conditions

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 14 Required Readings: Modifying Exercise Plans (FITT) for Chronic Conditions

Poblaciones Especiales y Modificaciones FITT Avanzadas

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from PAGA 2018 (2nd Ed.)), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 14): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Exercise helps almost everyone, including people with diabetes or high blood pressure. The plan just needs to fit the person. First check for warning signs, then adjust how often, how hard, how long, and what type of exercise (the FITT principle).


#### En Palabras Sencillas (Norteño Context)

Piensa en el plan de ejercicio como la receta de la abuela: la base es la misma, pero se ajusta para cada persona. Si los términos técnicos se ponen pesados, concéntrate primero en la seguridad.

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)

This week's advanced clinical literature examines the comprehensive physiological responses, risk stratification frameworks, and precise FITT (Frequency, Intensity, Time, Type) prescription modifications required when working with special populations and individuals managing chronic clinical conditions. By deeply analyzing how metabolic pathologies, cardiovascular limitations, and neuromuscular disorders alter acute and chronic exercise tolerance, practitioners learn to engineer safe, therapeutic, and evidence-based activity programs.

Grounded in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , these readings establish that promoting physical activity across vulnerable or chronically ill cohorts requires rigorous medical clearance frameworks, symptom-limited intensity monitoring, and equitable community access.


### 1. Clinical Pathology, Pre-Participation Screening & Risk Stratification

Before prescribing physical activity to individuals with chronic disease or unique functional limitations, practitioners must perform systematic clinical audits and risk assessments:

- Evidence-Based Health Screening: Utilizing standardized pre-participation screening algorithms (such as self-guided PAR-Q+ models and professional medical clearance pathways) to identify known cardiovascular, metabolic, or renal disease symptoms.
- Hemodynamic & Metabolic Pathophysiology: Understanding how chronic conditions like Type 2 diabetes mellitus, hypertension, and metabolic syndrome blunt normal vascular reactivity, impair insulin-stimulated glucose disposal, and alter chronotropic heart rate responses during exertion.
- Absolute and Relative Contraindications: Recognizing clinical warning signs—such as unstable angina, complex dysrhythmias, resting systolic blood pressure exceeding 200 mmHg, or severe acute systemic illness—that mandate immediate exercise cessation and physician referral.
Clinical Rule Verified (Use This in Your Lab & Sprint): Systematically adjusting Frequency, Intensity, Time, Type, Volume, and Progression (PAGA 2018 Ch. 6) so clients with hypertension, diabetes, or arthritis exercise safely.

En palabras sencillas (Para tu Laboratorio y Sprint): Adaptar frecuencia, intensidad, tiempo y tipo de ejercicio para que una persona con presión alta, diabetes o dolor articular entrene sin riesgo.


### 2. Advanced FITT Principle Modifications for Chronic Metabolic & Cardiovascular Conditions

Standard healthy adult exercise prescriptions are clinically unsafe or ineffective for special populations and must be systematically recalibrated across all FITT parameters:

- Frequency & Time (Accumulated Bouts): For individuals with severe deconditioning or chronic fatigue, continuous 30-minute bouts are broken down into manageable 10-minute accumulated bouts (e.g., 3 times daily) to optimize glycemic regulation without triggering excessive orthopedic or cardiovascular strain.
- Intensity Regulation via RPE: Because many patients take medications (such as beta-blockers) that blunt heart rate responses, exercise intensity must be prescribed using the Borg Rate of Perceived Exertion (RPE 6–20 or 0–10 scales) and symptom-limited thresholds.
- Type (Modality Selection): Prioritizing low-impact, weight-supported aerobic modalities (e.g., recumbent stationary cycling, water aerobics, seated elliptical training) alongside controlled pneumatic or machine-based resistance training to protect vulnerable joints and minimize fall risks.
- Progressive Overload & Volume Scaling: Ensuring that initial progression focuses on increasing session duration and frequency before advancing mechanical intensity.
Clinical Rule Verified (Use This in Your Lab & Sprint): Swapping high-impact running/jumping for aquatic, recumbent cycling, or brisk flat walking so osteoarthritic joint discomfort never worsens 2 hours post-session.

En palabras sencillas (Para tu Laboratorio y Sprint): Cambiar saltos o impactos fuertes por bici fija, alberca o caminata controlada para cuidar rodillas y caderas sin dejar dolor después.


### 3. PAGA 2018 Special Populations Guidance, Inactivity Avoidance & Health Equity

The federal framework establishes specific operational mandates for adults with chronic conditions and disabilities:

- The "Avoid Inactivity" Mandate: Adults with chronic conditions who are unable to meet the standard 150-minute aerobic guideline should be encouraged to engage in regular physical activity according to their abilities, explicitly avoiding complete physical inactivity.
- Consultation and Safety Alignment: Recommending that individuals consult health care professionals or physical activity specialists to understand how their specific chronic conditions affect their ability to safely execute structured exercise programs.
- Community Health Equity: Designing inclusive public health initiatives that dismantle architectural, financial, and cultural barriers, ensuring that vulnerable borderland populations have equitable access to supervised wellness programs.
Clinical Rule Verified (Use This in Your Lab & Sprint): Blood pressure drops after aerobic work; clients on blood-pressure medications require a 5–10 minute gradual cool-down to prevent venous pooling and dizziness.

En palabras sencillas (Para tu Laboratorio y Sprint): Bajar el ritmo poco a poco durante 5 a 10 minutos al terminar para que la sangre no se estanque en las piernas ni dé mareo.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 14 (Mod 14 Required Readings: Modifying Exercise Plans (FITT) for Chronic Conditions)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas en Línea: Poblaciones Especiales y Modificaciones FITT

La literatura clínica avanzada de esta semana examina las respuestas fisiológicas integrales, los marcos de estratificación de riesgo y las modificaciones precisas de FITT (Frecuencia, Intensidad, Tiempo, Tipo) necesarias al trabajar con poblaciones especiales y personas que manejan condiciones clínicas crónicas. Al analizar profundamente cómo las patologías metabólicas y los trastornos neuromusculares alteran la tolerancia al ejercicio, los profesionales aprenden a diseñar programas seguros y terapéuticos.

Fundamentadas en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) , estas lecturas establecen que promover la actividad física en cohortes vulnerables requiere rigurosos protocolos de autorización médica y seguimiento limitado por síntomas.


### 1. Patología Clínica, Tamizaje Preparticipación y Estratificación de Riesgo

- Tamizaje de Salud Basado en Evidencia: Utilizar algoritmos estandarizados para identificar síntomas de enfermedad antes de iniciar actividad física vigorosa.
- Fisiopatología Hemodinámica y Metabólica: Comprender cómo las condiciones crónicas (como diabetes tipo 2 e hipertensión) alteran la reactividad vascular y la respuesta de la frecuencia cardíaca.
- Contraindicaciones Absolutas y Relativas: Identificar signos y síntomas clínicos que exigen la interrupción inmediata del ejercicio y derivación médica.

### 2. Modificaciones Avanzadas del Principio FITT para Condiciones Crónicas

Las prescripciones estándar deben adaptarse sistemáticamente en todos los parámetros FITT:

- Frecuencia y Tiempo (Bouts Acumulados): Dividir las sesiones continuas en bloques de 10 minutos para optimizar el control glucémico y manejar la fatiga.
- Regulación de la Intensidad (RPE): Utilizar escalas de esfuerzo percibido (RPE) y umbrales limitados por síntomas para pacientes medicados.
- Selección de Modalidad (Tipo): Priorizar modalidades aeróbicas de bajo impacto (ciclismo reclinado, acuática) y resistencia controlada en máquinas.

### 3. Orientación de PAGA 2018 para Poblaciones Especiales, Inactividad y Equidad

- El Mandato de "Evitar el Sedentarismo": Animar a los adultos con condiciones crónicas a realizar actividad física según sus habilidades, evitando la inactividad total.
- Equidad en Salud Comunitaria: Diseñar programas inclusivos que eliminen barreras arquitectónicas y socioeconómicas para poblaciones vulnerables.
KIN-101 • Module 14 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 14:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
