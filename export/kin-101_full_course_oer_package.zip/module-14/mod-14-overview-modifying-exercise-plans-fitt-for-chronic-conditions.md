# KIN-101: Mod 14 Overview Modifying Exercise Plans Fitt For Chronic Conditions

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 14 Overview: Modifying Exercise Plans (FITT) for Chronic Conditions

El Porqué del Módulo 14 (Círculo Dorado — Contexto Norteño): “¿Por qué quedarse quieto es mucho más peligroso que hacer ejercicio cuando hay condiciones crónicas, y cómo adaptamos la rutina FITT para que cada persona se mueva segura?”


### Module 14 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 14: Modifying Exercise Plans (FITT) for Chronic Conditions

Welcome to Week 14! In this Module, we focus on special populations, clinical field audits, and advanced FITT (Frequency, Intensity, Time, Type) modifications. Building upon our foundational exercise prescription rules, we examine how chronic conditions, metabolic adaptations, and unique physiological needs require precise clinical adjustments to ensure safety and therapeutic efficacy.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will audit clinical case data, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety standards, and design evidence-based FITT prescription modifications tailored to your career track.


### Weekly Schedule & Deadlines

- Module Opens: Tuesday, November 17, 2026, at 12:00 AM MST
- Initial Discussion Post: Thursday, November 19, 2026, at 11:59 PM MST
- Peer Replies: Sunday, November 22, 2026, at 11:59 PM MST
- Lab & Course Evaluation Due: Monday, November 23, 2026, at 11:59 PM MST

### Course Learning Objectives

Upon successful completion of Module 14 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze clinical presentation patterns, physiological risk factors, and functional limitations across diverse special populations. Analizar los patrones de presentación clínica, los factores de riesgo fisiológico y las limitaciones funcionales.
- CLO 2 (Rule Application): Audit FITT exercise prescriptions against federal PAGA 2018 (2nd Ed.) standards and clinical safety protocols. Auditar las prescripciones de ejercicio FITT frente a las normas de la PAGA 2018 y los protocolos de seguridad clínica.
- CLO 3 (Problem Solving): Formulate an evidence-based clinical modification plan and complete institutional course evaluations tailored to professional tracks. Formular un plan de modificación clínica basado en evidencia y completar las evaluaciones institucionales del curso.

### 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will work within your chosen career track:

Cardiometabolic disease management, physician clearance protocols, and clinical FITT adjustments for chronic conditions.

Inclusive community wellness programming, adaptive physical education, and barrier-free health advocacy.

Managing returning athletes with chronic orthopedic or metabolic limitations through modified periodization frameworks.


### Module 14 Learning Roadmap

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Special Populations & FITT Modifications
- Discussion Board: Clinical Field Audits & Final Course Evaluation
- Lab Assignment: Special Populations FITT Modification Simulation
- Knowledge Check & Module Summary

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 14) / Simulación Clínica y Dominio de Resultados (Módulo 14)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 14 (Mod 14 Overview: Modifying Exercise Plans (FITT) for Chronic Conditions)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 14 Visión General


### Introducción al Módulo 14

¡Bienvenido a la Semana 14! En este módulo, nos centramos en las auditorías clínicas de campo para poblaciones especiales y las modificaciones avanzadas FITT (Frecuencia, Intensidad, Tiempo, Tipo). Basándonos en nuestras reglas de prescripción, examinamos cómo las condiciones crónicas y las necesidades fisiológicas únicas requieren ajustes clínicos precisos.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , auditará datos de casos clínicos, aplicará las normas federales de PAGA 2018 (2.ª ed.) y diseñará modificaciones FITT basadas en evidencia.


### Objetivos de Aprendizaje del Curso

- CLO 1 (Patrón): Analizar los patrones de presentación clínica, los factores de riesgo y las limitaciones funcionales en poblaciones especiales. Analyze clinical presentation patterns, physiological risk factors, and functional limitations.
- CLO 2 (Regla): Auditar prescripciones de ejercicio FITT frente a los estándares de la PAGA 2018 (2.ª ed.) y protocolos de seguridad. Audit FITT exercise prescriptions against PAGA 2018 standards and clinical safety protocols.
- CLO 3 (Solución): Formular un plan de modificación clínica basado en evidencia y completar las evaluaciones institucionales del curso. Formulate an evidence-based clinical modification plan and complete institutional course evaluations.

### Ruta de Aprendizaje

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Poblaciones Especiales y Modificaciones FITT
- Foro de Discusión: Auditorías Clínicas y Evaluación del Curso
- Práctica de Laboratorio: Simulación de Modificación FITT
- Comprobación de Conocimientos y Resumen del Módulo

### Module 14 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 14 Required Readings: Modifying Exercise Plans (FITT) for Chronic Conditions →
- Step 2 — Complete the Student Course Evaluation (Paso 2 — Evaluación del Curso): Mod 14: Final Student Course Evaluation →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 14 Coaching Sprint: Adjusting Workouts for Chronic Conditions →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 14 Lab: Modified Exercise Plan (FITT) Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 14 Summary & Wrap-Up: Modifying Exercise Plans (FITT) for Chronic Conditions →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
