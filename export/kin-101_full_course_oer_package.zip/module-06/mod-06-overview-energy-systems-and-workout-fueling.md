# KIN-101: Mod 06 Overview Energy Systems And Workout Fueling

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 06 Overview: Energy Systems & Workout Fueling


### Welcome to Module 06: Energy Systems & Workout Fueling

Welcome to Week 6! Building upon our neuromuscular foundation from Module 05, we now investigate the biochemical engine powering all physical activity: Human Movement Bioenergetics . Every muscular contraction—from explosive Olympic lifting to steady-state distance walking—relies on adenosine triphosphate (ATP) resynthesis through three integrated metabolic pathways: the Immediate Phosphagen System (ATP-PCr), Fast/Slow Glycolysis, and Oxidative Phosphorylation.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in our Single Source of Truth (SSoT)—the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —you will audit metabolic transition zones, analyze substrate oxidation kinetics, apply federal energy expenditure standards, and formulate work-to-rest interval conditioning prescriptions tailored for diverse populations across Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 22, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 24, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 27, 2026, at 11:59 PM MST
- Lab 06 Direct Submission / Entrega de Laboratorio: Monday, September 28, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 06 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze the metabolic transition zones, ATP resynthesis rates (power vs. capacity), and fatigue kinetics between the phosphagen, fast glycolytic, and oxidative energy systems during varied movement intensities. Analizar las zonas de transición metabólica, tasas de resíntesis de ATP y cinéticas de fatiga entre los sistemas de fosfágenos, glucolítico y oxidativo.
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) federal mandates regarding aerobic vs. anaerobic training thresholds, target MET-minutes, and total weekly energy expenditure standards (500 to 1,000 MET-minutes/week) for community and clinical health. Aplicar mandatos de PAGA 2018 sobre umbrales aeróbicos y anaeróbicos y gasto energético semanal (500 a 1,000 MET-minutos/semana).
- CLO 3 (Problem Solving): Formulate an individualized, interval-based conditioning prescription utilizing precise work-to-rest ratios (1:3 to 1:5 for ATP-PCr; 1:2 to 1:3 for glycolysis; 1:1 or 2:1 for oxidative) paired with bilingual client education cards. Diseñar una prescripción de acondicionamiento por intervalos con relaciones precisas de trabajo-descanso y tarjetas educativas bilingües.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit human bioenergetics across your selected career track:

Cardiorespiratory and metabolic reconditioning, mitochondrial density restoration post-bedrest, and fatigue threshold management for deconditioned clients at Matador Clinical Partners (MCP).

Energy expenditure tracking (METs), heat-adapted physical activity scheduling, and metabolic health interventions for agricultural workers and families across Yuma County.

Optimizing high-intensity interval work-to-rest ratios, phosphocreatine resynthesis kinetics, and lactate threshold buffering in collegiate athletes at Arizona Western College.


### Module 06 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Metabolic Pathways, Substrate Kinetics & PAGA Standards
- Discussion Board 06: Bioenergetic Transition Zones & Fatigue Auditing
- Lab Assignment 06: Metabolic Auditing & Gemini AI Tool Box Simulation
- Module 06 Knowledge Check & Summary Wrap-Up

### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 06 (Mod 06 Overview: Energy Systems & Workout Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Visión General del Módulo 06: Sistemas Energéticos y Bioenergética


### Bienvenido al Módulo 06: Vías Metabólicas y Bioenergética del Movimiento Humano

¡Bienvenido a la Semana 6! Tras analizar la fisiología neuromuscular en el Módulo 05, ahora nos enfocamos en el motor metabólico del movimiento: la Bioenergética del Movimiento Humano . Toda contracción muscular depende de la resíntesis de ATP mediante tres vías principales: Fosfágenos (ATP-PCr), Glucólisis Rápida y Fosforilación Oxidativa.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y nuestras Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) , auditará zonas de transición metabólica, aplicará normas de gasto calórico y diseñará protocolos de intervalos adaptados a las necesidades del condado de Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 22 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 24 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 27 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 06: Lunes, 28 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar las zonas de transición metabólica, la tasa de resíntesis de ATP y la fatiga entre los sistemas de fosfágenos, glucolítico y oxidativo.
- CLO 2 (Regla): Aplicar normas de PAGA 2018 sobre umbrales aeróbicos y anaeróbicos y gasto energético (500 a 1,000 MET-minutos/semana).
- CLO 3 (Solución): Formular prescripciones de intervalos de trabajo y descanso y reacondicionamiento metabólico con tarjetas bilingües.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la bioenergética humana a través de su ruta profesional:

Reacondicionamiento metabólico cardiorrespiratorio y recuperación de densidad mitocondrial en Matador Clinical Partners (MCP).

Patrones de gasto calórico (METs) y actividad física adaptada al calor para trabajadores agrícolas en el condado de Yuma.

Optimización de intervalos de trabajo-descanso, resíntesis de fosfocreatina y amortiguación de lactato en atletas de AWC.


### Ruta de Aprendizaje del Módulo 06

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Vías Metabólicas, Cinética de Sustratos y Pautas PAGA
- Foro de Discusión 06: Zonas de Transición Bioenergética y Auditoría de Fatiga
- Laboratorio 06: Auditoría Metabólica y Simulación con la IA de Gemini
- Comprobación de Conocimientos y Resumen del Módulo 06

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 06 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 06 Required Readings: Energy Systems & Workout Fueling →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 06 Discussion: How the Body Fuels Short vs. Long Workouts →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 06 Coaching Sprint: Fueling Exercise & Managing Fatigue →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 06 Summary & Wrap-Up: Energy Systems & Workout Fueling →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
