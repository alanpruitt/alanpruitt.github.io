# KIN-101: Mod 06 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología


## Mod 06 Discussion: How the Body Fuels Short vs. Long Workouts

Zonas de Transición Bioenergética, Cinética del Oxígeno y Normas de Gasto Energético PAGA


### ATP Resynthesis, Oxygen Deficit, & PAGA Energy Expenditure Mandates

Human movement requires continuous ATP resynthesis across three metabolic systems: Phosphagen (ATP-PCr), Fast Glycolytic, and Oxidative Phosphorylation. While elite athletic performance requires precise work-to-rest intervals to clear lactate or rebuild phosphocreatine, public health and clinical settings focus on aerobic metabolic efficiency, reducing oxygen deficit, and satisfying weekly MET-minute energy expenditure targets.

El movimiento humano depende de la resíntesis constante de ATP mediante los sistemas de fosfágenos, glucolítico y oxidativo. En este foro, aplicará el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar zonas de transición metabólica, aplicar las normas de las Pautas de Actividad Física (PAGA 2018, 2.ª edición) y diseñar una intervención bioenergética adaptada a su ruta profesional.

- Topic Opens / Apertura del Foro: Tuesday, September 22, 2026, at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday, September 24, 2026, at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 27, 2026, at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday, September 28, 2026, at 11:59 PM MST / Lunes a las 11:59 PM MST
You are warmly encouraged to post in English or Spanish according to your preference. Le animamos a publicar en inglés o en español según su preferencia académica.

To support your bioenergetic auditing skills, instructor evaluations and metabolic transition analyses are posted in this public forum as well as in Gradebook.


### Phase 1: Select Your Clinical Simulation Case File #101-06 / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Cardiorespiratory reconditioning for a deconditioned client post-bedrest experiencing prolonged oxygen deficit and early metabolic fatigue during mild exertion at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[PATIENT INITIALS]: J.M. | [AGE]: 58 | [SEX]: Female | [LOCATION]: Yuma, AZ
[PRESENTATION]: Recovering from 3 weeks of strict bedrest; experiences acute muscular heaviness and breathlessness after 2 minutes of light treadmill walking (2.0 mph).
[METABOLIC LIMITATION]: Severe oxygen deficit due to reduced mitochondrial enzyme density; relies heavily on the fast glycolytic pathway during light exertion, generating early metabolic acidosis and leg fatigue.
[GOAL]: Design a low-intensity aerobic interval protocol (1:2 work-to-rest ratio) to gradually restore oxidative capacity and mitochondrial density.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Cardiorespiratory Rehabilitation.
###
```

Focus: Community physical activity initiative in Yuma County promoting daily energy expenditure (MET-minutes) for sedentary agricultural workers during extreme summer months.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CLIENT INITIALS]: J.M. | [AGE]: 52 | [SEX]: Male | [LOCATION]: Yuma County, AZ
[COMMUNITY PROFILE]: Sedentary agricultural worker seeking to meet federal physical activity guidelines without triggering severe heat-related metabolic fatigue.
[PUBLIC HEALTH LIMITATION]: Daily physical activity falls below 500 MET-minutes/week due to extreme summer temperatures (>105°F) and lack of accessible climate-controlled facilities.
[GOAL]: Establish an indoor/climate-controlled walking strategy targeting 150 to 300 minutes/week of moderate-intensity oxidative activity (3.0 to 4.0 METs).
[COMMUNITY SITE]: Yuma County Public Health Services District & Parks Recreation Centers.
###
```

Focus: Bioenergetic interval training for a 400-meter track athlete experiencing severe metabolic power loss during repeat high-intensity sprint intervals.


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[ATHLETE INITIALS]: J.M. Jr. | [AGE]: 20 | [SEX]: Male | [LOCATION]: Yuma, AZ
[ATHLETIC PROFILE]: Track athlete competing in 400m sprint events experiencing sharp velocity drop-offs during third and fourth repeat intervals.
[PERFORMANCE LIMITATION]: Inadequate rest intervals (1:1 work-to-rest ratio) prevent phosphocreatine (PCr) resynthesis and cause excessive hydrogen ion accumulation during fast glycolysis.
[GOAL]: Restructure work-to-rest interval ratios (1:3 to 1:5 for glycolytic buffering; 1:12 for phosphagen power) to optimize power output and lactate clearance.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a bioenergetic and metabolic audit:


```text
Safety Auditor Protocol: KIN-101 Bioenergetics Preceptor ###:
Role: Academic Kinesiology Mentor and Exercise Physiologist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Energy Expenditure & Aerobic Mandates.

Instructions:
Step 1: Review the candidate case file wrapped in triple-hashes (###) below.
Step 2: PATTERN: Identify the primary energy systems powering their physical movement (Phosphagen, Fast Glycolysis, Oxidative) and analyze their ATP resynthesis rate, oxygen deficit, and fatigue kinetics.
Step 3: RULE: Apply federal PAGA 2018 guidelines to evaluate target MET-minutes and weekly aerobic energy expenditure standards (500 to 1,000 MET-minutes/week).
Step 4: SOLVE: Detail an individualized interval conditioning routine prescribing appropriate work-to-rest ratios (1:12 to 1:20 for ATP-PCr; 1:3 to 1:5 for glycolysis; 1:1 to 1:3 for oxidative) adapted for Yuma County climate conditions.
Step 5: Provide a 2-sentence bilingual client instruction card formatted in English and Spanish.
Step 6: Maintain all client data wrapped in triple-hash (###) delimiters.

Candidate Data Input ###:
[Paste Your Selected Track Data Block Here]
End Candidate Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Metabolic Profile: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and identify the primary energy pathway limiting your client's physical exertion. Indique la ruta seleccionada e identifique el sistema energético principal que limita a su cliente.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit (Pattern / Rule / Solve): Detail the bioenergetic mechanisms of oxygen deficit, fatigue, or ATP resynthesis (Pattern), apply PAGA 2018 weekly aerobic volume or MET-minute standards (Rule), and outline your structured work-to-rest interval protocol (Solve). Detalle los mecanismos bioenergéticos (Patrón), aplique las normas de PAGA 2018 sobre volumen semanal o MET-minutos (Regla) y describa su protocolo de intervalos (Solución).
- Bilingual Client Instruction Card: Provide a concise 2-sentence explanation of pacing, rest intervals, or aerobic exertion in English and Spanish so your client understands how bioenergetics governs their stamina. Proporcione una explicación concisa de 2 oraciones sobre el ritmo y los descansos en inglés y español para educar a su cliente.

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Compare how ATP resynthesis demands, work-to-rest ratios, and oxygen deficit kinetics differ between clinical reconditioning, community public health, and athletic performance settings.

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Compare cómo difieren las demandas de resíntesis de ATP y los descansos entre entornos clínicos, comunitarios y deportivos.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Track & Metabolic Limitation: Track 1 Clinical Rehabilitation. Patient J.M. suffers from severe aerobic deconditioning following 3 weeks of strict bedrest, resulting in an exaggerated oxygen deficit upon initiating light treadmill walking (2.0 mph). Ruta 1 Rehabilitación Clínica. La paciente presenta un déficit de oxígeno pronunciado debido a la pérdida de enzimas oxidativas tras 3 semanas de reposo en cama.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit: Pattern (Oxygen Deficit & Glycolytic Acidosis): Due to reduced peripheral capillary density and decreased mitochondrial enzyme activity, the oxidative phosphorylation pathway cannot ramp up rapidly to meet the ATP demand of walking. Consequently, fast glycolysis compensates prematurely, generating rapid intracellular hydrogen ion accumulation and severe muscular heaviness within 2 minutes. Rule (PAGA 2018 Standards): Under PAGA 2018 (2nd Ed., Chapter 2) guidelines, adults should accumulate 150 to 300 minutes of moderate-intensity (3.0 to 5.9 METs) physical activity weekly. In severely deconditioned clinical populations, activity must be fractionated into short aerobic intervals to prevent severe glycolytic fatigue while accumulating target volume. Solve (Clinical Interval Plan): Implement a 1:2 work-to-rest aerobic walking protocol on an indoor treadmill at 1.8 mph (approx. 2.8 METs). J.M. walks for 1 minute followed by 2 minutes of seated rest, repeated for 6 cycles (18 minutes total duration, 3 days/week) to stimulate mitochondrial biogenesis without triggering anaerobic fatigue. Patrón: La falta de mitocondrias fuerza a la glucólisis rápida a compensar, acumulando fatiga. Regla: PAGA 2018 exige 150 a 300 min/semana. Solución: Intervalos 1:2 (1 min caminata / 2 min descanso) para estimular la biogénesis mitocondrial.
- Bilingual Client Handout Card: EN: "Walk at a comfortable pace for 1 minute, then rest seated for 2 minutes to allow your oxidative energy system to recover. Short rest breaks help rebuild your stamina without causing heavy leg fatigue." ES: "Camine a un ritmo cómodo durante 1 minuto, luego descanse sentado durante 2 minutos para permitir que su sistema oxidativo se recupere. Los descansos cortos ayudan a desarrollar su resistencia sin causar fatiga muscular intensa."

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 06 (Mod 06 Discussion: How the Body Fuels Short vs. Long Workouts)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 06 Foro de Discusión: Zonas de Transición Metabólica y Fatiga

Analice el caso del cliente J.M. utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) según la ruta profesional seleccionada y envíe sus respuestas en Canvas.

- Apertura del Foro: Martes, 22 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 24 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 27 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 28 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta y Perfil Metabólico: Indique la ruta seleccionada (Ruta 1 Clínica, Ruta 2 Comunitaria o Ruta 3 Deportiva) e identifique el sistema energético principal que limita a su cliente.
- Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Detalle los mecanismos bioenergéticos de déficit de oxígeno y fatiga (Patrón), aplique las normas de PAGA 2018 sobre volumen aeróbico semanal o MET-minutos (Regla) y describa su protocolo de intervalos con relaciones de trabajo y descanso (Solución).
- Tarjeta de Instrucción Bilingüe: Incluya una explicación concisa de 2 oraciones en inglés y español sobre el ritmo de entrenamiento y los descansos.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:
