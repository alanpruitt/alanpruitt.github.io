## KIN-101 MODULE-06: SPORT PSYCHOLOGY / Master Content Loop

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## > ###  Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (Kinesiology disciplines and foundational physical activity rules).

## KIN-101: MODULE 06 - INTRODUCTION TO SPORT & EXERCISE PSYCHOLOGY

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module explores the psychological variables influencing physical activity adherence, exercise behavior modification, and the cognitive benefits of regular human movement. Students will examine behavioral models, motivational constructs, and psychological barriers that impact community-wide active lifestyle choices. All psychological metrics and behavioral frameworks align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo explora las variables psicológicas que influyen en la adherencia a la actividad física, la modificación de la conducta de ejercicio y los beneficios cognitivos del movimiento humano regular. Los estudiantes examinarán modelos conductuales, constructos motivacionales y barreras psicológicas que impactan las elecciones de estilo de vida activo en la comunidad. Todos los parámetros psicológicos y los marcos conductuales se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.16]):** Evaluate behavioral adherence patterns across diverse communities and apply federal psychological guidelines to design sustainable exercise motivation frameworks.
* **Español (Regional) ([LO 2.16]):** Evaluar los patrones de adherencia conductual en diversas comunidades y aplicar las pautas psicológicas federales para diseñar marcos sostenibles de motivación para el ejercicio.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Identify and document negative behavior patterns, including drop-out rates, low self-efficacy indicators, and perceived cognitive barriers to physical activity within a community demographic.
   * **Patrón (Español):** Identificar y documentar los patrones de conducta negativos, incluyendo las tasas de abandono, los indicadores de baja autoeficacia y las barreras cognitivas percibidas para la actividad física dentro de una demografía comunitaria.
2. **Rule (English):** Apply the psychological well-being data and mental health guidelines detailed in the federal PAGA 2018 framework to establish target behavior parameters.
   * **Regla (Español):** Aplicar los datos de bienestar psicológico y las pautas de salud mental detalladas en el marco federal de PAGA 2018 para establecer parámetros de conducta objetivo.
3. **Solve (English):** Engineer an evidence-based behavioral intervention strategy using structured goal-setting and social-support networks to improve long-term exercise adherence safely.
   * **Solución (Español):** Diseñar una estrategia de intervención conductual basada en la evidencia utilizando el establecimiento de metas estructuradas y redes de apoyo social para mejorar de forma segura la adherencia al ejercicio a largo plazo.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Andamiaje

## Part A: Gemini AI Simulation (Behavioral Adherence Simulation)

## English

Students will initialize the virtual psychological mapping environment within their sandbox workspace. Ensure your simulated behavioral profile inputs remain completely wrapped within the required layout delimiters below.

```text
## [PASTE SIMULATED COMMUNITY ADHERENCE AND EXERCISE MOTIVATION DATA HERE]
###
```

1. Use the sandbox environment to audit a simulated behavioral dataset, tracking dropout risk timelines and self-efficacy dips.
2. Cross-examine virtual behavioral resistance markers against the cognitive health benefits established in the primary chapters of the federal PAGA source documentation.
3. Execute an automated data validation pass within the sandbox to verify that proposed motivational strategies align with long-term activity volume targets.

## Español (Regional)

Los estudiantes inicializarán la configuración del mapeo psicológico virtual dentro de su espacio de trabajo sandbox. Asegúrese de que las entradas de perfiles conductuales simulados permanezcan completamente envueltas dentro de los delimitadores de diseño requeridos a continuación.

```text
## [PEGUE LOS DATOS SIMULADOS DE ADHERENCIA COMUNITARIA Y MOTIVACIÓN PARA EL EJERCICIO AQUÍ]
###
```

1. Utilizar el entorno de pruebas (sandbox) para auditar un conjunto de datos conductuales simulados, rastreando los cronogramas de riesgo de abandono y las disminuciones en la autoeficacia.
2. Evaluar de forma cruzada los marcadores virtuales de resistencia conductual frente a los beneficios de salud cognitiva establecidos en los capítulos principales de la documentación oficial de PAGA.
3. Ejecutar un pase de validación de datos automatizado dentro del sandbox para verificar que las estrategias motivacionales propuestas se alineen con los objetivos de volumen de actividad a largo plazo.

## Part B: Practical Field Application (Exercise Adherence Barrier Log)

## English

Students will transition into their immediate personal environments to complete a practical, zero-cost qualitative physical activity barrier assessment with a peer.

1. Complete a visual behavior interview and tracking log assessing a peer's historical barriers to exercise, recording specific indicators of amotivation, extrinsic motivation, or intrinsic drive.
2. Map observed cognitive obstacles onto structured behavioral change models, identifying the precise stage of change.
3. Document true psychological indicators: record qualitative motivation indices and cross-examine your field findings against the targets outlined in the federal PAGA guidelines.

## Español (Regional)

Los estudiantes harán la transición a sus entornos personales inmediatos para completar una evaluación cualitativa práctica y de costo cero sobre las barreras para la actividad física con un compañero.

1. Completar una entrevista de conducta visual y un registro de seguimiento que evalúe las barreras históricas de un compañero para el ejercicio, registrando indicadores específicos de amotivación, motivación extrínseca o impulso intrínseco.
2. Mapear los obstáculos cognitivos observados en modelos estructurados de cambio de conducta, identificando la etapa precisa del cambio.
3. Documentar los indicadores psicológicos reales: registrar los índices cualitativos de motivación y evaluar de forma cruzada sus hallazgos de campo con las metas descritas en las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This behavioral module assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación del módulo conductual se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):
  * **English:** Zero-drift integration. All proposed behavior modification interventions align perfectly with PAGA data parameters; all simulation logs remain completely wrapped within delimiters.
  * **Español (Regional):** Integración sin desviaciones. Todas las intervenciones de modificación de conducta propuestas se alinean perfectamente con los parámetros de datos de PAGA; todos los registros de simulación permanecen completamente delimitados dentro de los delimitadores.
* **7 (Competent) / (Competente):
  * **English:** Minor refactoring required. Core Clinical Framing Protocol steps and psychological rules are appropriately applied, but minor formatting gaps are flagged in the final file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los pasos del Protocolo de Encuadre Clínico y las reglas psicológicas se aplican adecuadamente, pero se identifican pequeñas brechas de formato en el archivo final.
* **0 (Recalibrate) / (Recalibrar):
  * **English:** Critical error in identifying behavior modification stages or un-fenced community profiling metrics that violate federal guidelines. Complete rewrite required.
  * **Español (Regional):** Error crítico en la identificación de las etapas de modificación de conducta o métricas de perfil comunitario sin delimitar que violan las pautas federales. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.


<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>


## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
