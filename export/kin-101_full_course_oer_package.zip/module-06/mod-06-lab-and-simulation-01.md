# KIN-101: Mod 06 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Coaching Sprint Simulation: Fueling Exercise & Managing Fatigue

Sesión de Coaching del Módulo 06: Bioenergética, Vías Metabólicas y Relaciones de Trabajo-Descanso

- Three Bioenergetic Pathways (ATP-PCr, Glycolytic, Oxidative): ATP-PCr fuels 0–10 sec explosive efforts, glycolysis powers 30 sec–2 min high-intensity bouts, and the oxidative system sustains long aerobic sessions. En palabras sencillas: Las tres fuentes de energía del músculo: explosiva para pocos segundos, rápida para esfuerzos intensos cortos y aeróbica para caminatas o trotes largos.
- Muscle & Liver Glycogen Depletion: Stored carbohydrate reserves that fuel moderate-to-vigorous exercise; low glycogen causes premature fatigue and heavy legs. En palabras sencillas: El tanque de carbohidratos guardado en tus músculos; si llegas sin comer bien, te quedas sin fuerza a mitad de la rutina.
- Euhydration & Pre-Exercise Fluid Baseline: Starting exercise well-hydrated (pale yellow urine) and replacing sweat losses so desert heat does not degrade cardiovascular output. En palabras sencillas: Empezar a entrenar bien hidratado desde horas antes para que el calor del desierto no tumbe tu rendimiento.
- KIN-101.6.1.AY26-27: Differentiate between the phosphagen (ATP-PCr), fast glycolytic, and oxidative phosphorylation pathways during varied movement intensities. Diferenciar entre los sistemas de fosfágenos (ATP-PCr), glucolítico rápido y fosforilación oxidativa según la intensidad del movimiento.
- KIN-101.6.2.AY26-27: Apply PAGA 2018 energy expenditure standards and work-to-rest interval principles to optimize stamina and prevent premature fatigue. Aplicar normas de gasto energético de PAGA 2018 y relaciones de trabajo y descanso para optimizar la resistencia y evitar la fatiga prematura.

### Your Weekly Win: Powering Movement Through Metabolic Science

Ever wonder how the human body instantly transitions from explosive sprinting to sustained endurance pacing? Through human movement bioenergetics! Every physical action relies on continuous ATP resynthesis across three primary systems: the Immediate Phosphagen System (ATP-PCr), Fast Glycolysis, and Oxidative Phosphorylation. By matching work intervals with appropriate rest periods (such as 1:12 to 1:20 for phosphagen or 1:3 to 1:5 for glycolysis), we optimize metabolic recovery. Choose your coaching track below, chat with your AI Socratic Coach, and master bioenergetic conditioning!

¿Cómo cambia el cuerpo humano de potencia explosiva a resistencia sostenida? ¡A través de la bioenergética del movimiento! Cada acción depende de la resíntesis de ATP mediante tres sistemas metabólicos. ¡Elija su ruta, dialogue con su Coach de IA y domine el acondicionamiento metabólico!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija el escenario que más se alinee con su interés vocacional

Scenario: Deconditioned client (Brenda, 58) recovering from prolonged bedrest who experiences severe oxygen deficit and early muscular burning during light walking at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[CLIENT]: Deconditioned Patient (Brenda, 58) | [LOCATION]: Yuma, AZ
[SITUATION]: Recovering from extended hospital bedrest. Experiences acute leg fatigue and dyspnea within 2 minutes of continuous light walking (2.0 mph) due to blunted mitochondrial oxidative capacity and an exaggerated oxygen deficit.
[COACHING GOAL]: Educate Brenda on how oxidative ATP production adapts to training, and prescribe an aerobic interval walking protocol (1:2 work-to-rest ratio) to rebuild stamina safely per PAGA 2018.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Cardiorespiratory Rehabilitation.
###
```

Scenario: Youth soccer coach (Team, 14-16) attempting to condition players through continuous non-stop running, causing premature glycolytic exhaustion and poor tactical execution.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CLIENT]: Youth Soccer Team (Ages 14-16) | [LOCATION]: Yuma County, AZ
[SITUATION]: Athletes are subjected to continuous 20-minute maximal running drills with zero rest, resulting in severe lactic acidosis, heavy legs, and diminished skill execution during the second half of practices.
[COACHING GOAL]: Educate the coaching staff on the bioenergetic continuum, applying structured fast-glycolytic interval ratios (1:3 to 1:5 work-to-rest) to improve lactate buffering and match-specific conditioning.
[COMMUNITY SITE]: Yuma County Parks & Recreation Youth Sports Complex.
###
```

Scenario: Adult powerlifter (Jason, 32) resting only 30 seconds between heavy maximum effort barbell sets, leading to severe power drops and missed lifts.


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Coaching Path
[CLIENT]: Adult Powerlifter (Jason, 32) | [LOCATION]: Yuma, AZ
[SITUATION]: Performs maximal 90%+ 1RM deadlifts and squats with only 30 to 45 seconds of rest between working sets, causing incomplete phosphocreatine (PCr) resynthesis and technical failure.
[COACHING GOAL]: Apply phosphagen bioenergetic principles (ATP-PCr), prescribing complete 1:12 to 1:20 work-to-rest recovery windows (3 to 5 minutes) to ensure complete intramuscular PCr replenishment.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-101 Bioenergetics & Energy Systems Tool Box ###:
Role: Supportive KIN-101 Kinesiology Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Energy Expenditure & Metabolic Adaptation Mandates.

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms the three primary energy systems (Phosphagen ATP-PCr, Fast Glycolysis, Oxidative Phosphorylation) and identify which metabolic pathway is the primary bottleneck for the client.
Step 3: Guide the student to give their client ONE practical work-to-rest ratio or interval conditioning adjustment to optimize energy recovery.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how bioenergetics and rest intervals unlock sustained physical performance.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's bioenergetic bottleneck or recovery challenge.
- Energy Systems & Fatigue Analysis: Compare the three metabolic pathways (ATP-PCr, Fast Glycolysis, Oxidative) in your own words, explaining the physiological reason for your client's fatigue.
- My Corrective Interval Strategy: Provide 1 clear, actionable work-to-rest ratio or pacing guideline to optimize ATP resynthesis for your client.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining how matching work-to-rest intervals to the dominant energy system (ATP-PCr, Glycolytic, or Oxidative) and PAGA 2018 standards prevents premature fatigue in Yuma's heat.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 06 Coaching Sprint • Track 3 (Strength / Jason)

- Chosen Track & Client: Track 3: Adult Fitness & Strength Coaching (Jason, 32). Challenge: Jason is resting only 30 to 45 seconds between near-maximal (90%+ 1RM) squat and deadlift attempts, causing incomplete phosphocreatine (PCr) resynthesis and acute power drop-offs.
- Track 3: Adult Fitness & Strength Coaching (Jason, 32).
- Challenge: Jason is resting only 30 to 45 seconds between near-maximal (90%+ 1RM) squat and deadlift attempts, causing incomplete phosphocreatine (PCr) resynthesis and acute power drop-offs.
- Energy Systems & Fatigue Analysis: Phosphagen System (ATP-PCr): Maximal explosive efforts under 10 seconds rely almost exclusively on stored ATP and phosphocreatine. PCr resynthesis is an aerobic mitochondrial process that takes 3 to 5 minutes to reach 95% to 100% recovery. Fast Glycolysis: When rest is cut short, the body is forced into fast glycolysis, which cannot match the peak power output of the phosphagen system and leads to rapid hydrogen ion accumulation. Oxidative Phosphorylation: Operates during the rest interval to aerobically resynthesize phosphocreatine and clear metabolic byproducts.
- Phosphagen System (ATP-PCr): Maximal explosive efforts under 10 seconds rely almost exclusively on stored ATP and phosphocreatine. PCr resynthesis is an aerobic mitochondrial process that takes 3 to 5 minutes to reach 95% to 100% recovery.
- Fast Glycolysis: When rest is cut short, the body is forced into fast glycolysis, which cannot match the peak power output of the phosphagen system and leads to rapid hydrogen ion accumulation.
- Oxidative Phosphorylation: Operates during the rest interval to aerobically resynthesize phosphocreatine and clear metabolic byproducts.
- My Corrective Interval Strategy for Jason: "Rest a full 3 to 5 minutes between maximal heavy working sets (applying a 1:12 to 1:20 work-to-rest ratio). Your muscles require this time window to fully recharge phosphocreatine stores so you can express 100% force on every attempt."
- "Rest a full 3 to 5 minutes between maximal heavy working sets (applying a 1:12 to 1:20 work-to-rest ratio). Your muscles require this time window to fully recharge phosphocreatine stores so you can express 100% force on every attempt."
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, generic workouts often confuse anaerobic glycolysis with aerobic conditioning, turning every session into a breathless 60-second sprint with 15-second rests that floods muscles with hydrogen ions ($\text{H}^+$) and causes rapid heat exhaustion in Yuma. By distinguishing the three bioenergetic pathways—granting 1:12 to 1:20 rest for 8-second ATP-PCr power efforts, 1:3 to 1:5 rest for glycolytic intervals, and steady conversational pacing for oxidative PAGA 2018 endurance—we target the exact metabolic adaptation our client needs without premature fatigue. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- My Memorable Coaching Takeaway: EN: "Maximal strength requires maximal recovery; respect your rest intervals to recharge your cellular power!" ES: "¡La fuerza máxima requiere una recuperación máxima; respete sus descansos para recargar su energía celular!"
- EN: "Maximal strength requires maximal recovery; respect your rest intervals to recharge your cellular power!"
- ES: "¡La fuerza máxima requiere una recuperación máxima; respete sus descansos para recargar su energía celular!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M06_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 06 (Mod 06 Coaching Sprint: Fueling Exercise & Managing Fatigue)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 06 Simulación de Coaching: Bioenergética y Vías Metabólicas

Evaluación Rápida y Aprendizaje Práctico de los Sistemas Energéticos


### Su Logro Semanal: Impulsando el Movimiento con la Ciencia Metabólica

Esta sesión le permitirá entender cómo el cuerpo utiliza los tres sistemas energéticos (ATP-PCr, glucolítico y oxidativo) y cómo estructurar los descansos para optimizar la recuperación celular. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-101 Bioenergetica y Sistemas Energeticos ###:
Rol: Coach de Kinesiologia de KIN-101 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Gasto Energetico y Adaptaciones Metabolicas.

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla los tres sistemas energeticos (Fosfagenos ATP-PCr, Glucolisis Rapida, Fosforilacion Oxidativa) e identificar el cuello de botella metabolico de su cliente.
Step 3: Guiar al estudiante para proponer UNA relacion de trabajo-descanso o protocolo de intervalos para optimizar la resintesis de ATP.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la bioenergetica y los descansos potencian el rendimiento.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío bioenergético o limitación de su cliente.
- Análisis de Sistemas Energéticos y Fatiga: Compare las tres vías metabólicas con sus propias palabras, explicando la causa fisiológica de la fatiga.
- Mi Estrategia de Intervalos de Recuperación: Escriba 1 relación de trabajo-descanso clara y aplicable para optimizar la resíntesis de ATP.
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica explicando cómo ajustar los tiempos de trabajo y descanso al sistema energético dominante (ATP-PCr, Glucolítico u Oxidativo) previene la fatiga prematura en Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Ejemplo de La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): "En mi juicio clínico, las rutinas genéricas mezclan esfuerzos explosivos sin descanso suficiente, acumulando iones de hidrógeno ($\text{H}^+$) y agotamiento térmico en Yuma. Al respetar la relación trabajo-descanso de cada vía bioenergética (ATP-PCr, glucólisis y sistema oxidativo bajo PAGA 2018), logramos adaptaciones seguras y sostenibles."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:
