# KIN-101: Mod 00 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## COMM CHECK: SQUAD Q&A / CONTROL DE COMUNICACIÓN: PREGUNTAS Y RESPUESTAS

- Triple-Hash Delimiter Protocol (###): Wrapping client case profiles inside ### code fences so the AI calculator processes only verified clinical data without prompt bleed. En palabras sencillas: Encerrar los datos de tu cliente entre símbolos ### para que la calculadora de IA no mezcle ni invente información.
- PAGA 2018 Core Adult Benchmark (150–300 Min/Week + ≥2 Days Strength): Federal standard requiring 150–300 minutes/week of moderate-intensity aerobic activity (or 75–150 min vigorous) plus muscle-strengthening on 2 or more days/week. En palabras sencillas: La meta oficial de salud: 150 a 300 minutos por semana de cardio moderado más mínimo 2 días de fuerza en todo el cuerpo.
- Centaur Clinical Audit (Architect vs. Engine): Treating AI as a fast calculator while you—the human coach—verify every safety threshold, Yuma heat adjustment, and guideline citation. En palabras sencillas: Usar la IA solo como calculadora rápida mientras tú tomas la decisión final de seguridad para tu gente en Yuma.

### Open Frequency / Frecuencia Abierta

- English: Got a question? Someone else probably has the same one. This discussion board is our open forum for course-related questions. If you are confused about an instruction, can't find a reading, or found a technical glitch, post it here.
- Español (Regional): ¿Tiene alguna pregunta? Es probable que alguien más tenga la misma duda. Este foro de discusión es nuestro espacio abierto para preguntas relacionadas con el curso. Si tiene dudas sobre alguna instrucción, no encuentra una lectura o detecta una falla técnica, publíquela aquí.

### Ghost Mode Enabled / Modo Fantasma Activado

- English: Anonymous Posting is enabled. To encourage open communication, you can ask questions without attaching your name. (Though remember: there are no dumb questions, only unchecked errors).
- Español (Regional): La publicación anónima está activada. Para fomentar una comunicación abierta, puede realizar preguntas sin vincular su nombre. (Recuerde: no hay preguntas tontas, solo errores que no se reportan).

### Rules of Engagement / Reglas de Participación

- English (Check the Map First): Before you call for support, check the Syllabus and the Module onboarding pages. Español (Regional - Verifique el Mapa Primero): Antes de solicitar asistencia, revise el Plan de Estudios y las páginas de introducción del Módulo.
- English (No Personal Intel): Do not post about your specific grades here. Message Coach Alan Pruitt directly via Canvas Inbox for private matters. Español (Regional - Sin Datos Personales): No publique información sobre sus calificaciones específicas aquí. Envíe un mensaje directo a Coach Alan Pruitt a través de la Bandeja de Entrada de Canvas para asuntos privados.
- English (Help Your Squad): If you see a question and know the solution, jump in! Crowd-sourced intelligence makes the squad stronger. Español (Regional - Ayude a su Grupo): Si ve una pregunta y conoce la solución, ¡participe! El conocimiento colectivo fortalece a todo el grupo.
Pro Tip: Click "Subscribe" / Consejo Profesional: Haga clic en "Suscribirse"

English: Click the Subscribe button at the top of this thread to get notified when questions are answered.

Español (Regional): Haga clic en el botón de Suscribirse en la parte superior de este hilo para recibir notificaciones cuando se respondan las preguntas.

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
