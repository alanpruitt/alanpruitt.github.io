## KIN-101: Module 00 — Course Orientation & Ready Reference Guide / Orientación del Curso y Guía de Referencia Permanente

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you read the details below, here is the short version: **Module 00 is your permanent, semester-long reference guide for how to succeed in KIN-101.** It explains how we pair AI tools with your own human judgment, how the 10 / 7 / 0 grading scale works, and how to revise any assignment for full 10 / 10 credit. Because this module stays open all semester, bookmark it and return whenever you need a refresher or an example.

## En Palabras Sencillas (Norteño Context)
Piensa en el Módulo 00 como el manual de guantera de tu troca: siempre está abierto y a la mano durante todo el semestre por si ocupas checar cómo defender tu trabajo o cómo subir una calificación a 10 / 10. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar tu propio criterio humano (`Patrón / Regla / Solución`) para proteger la seguridad de tu cliente.
:::

---

## Course Orientation & Permanent Reference Grounding / Orientación del Curso

* **English:** Welcome to **KIN-101: Foundations of Exercise Science & Coaching**. This zero-cost Open Educational Resource (OER) portal serves as your launchpad for exploring the historical, sociological, and physiological foundations of human movement in the **Yuma, Arizona and Imperial Valley** region. **Best Practice Note:** Module 00 remains unlocked the entire 16-week semester so you can reference our grading rules, AI workflow, and 10/10 exemplars at any time.
* **Español (Regional):** Bienvenido a **KIN-101: Fundamentos de la Ciencia del Ejercicio y Entrenamiento**. Este portal OER sin costo sirve como tu plataforma de lanzamiento para explorar los fundamentos históricos, sociológicos y fisiológicos del movimiento humano en la región de **Yuma, Arizona y el Valle Imperial**. **Nota Práctica:** El Módulo 00 permanece abierto durante las 16 semanas del semestre como tu guía de consulta rápida.

---

## Targeted Learning Objectives / Objetivos de Aprendizaje

* **([LO 2.1]):** Identify foundational historical, sociological, and physiological concepts of human movement. / Identificar los conceptos fundacionales históricos, sociológicos y fisiológicos del movimiento humano.
* **([LO 2.2]):** Apply the federal rules and clinical boundaries of the **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** using the Clinical Framing Protocol. / Aplicar las reglas federales de las **Pautas de Actividad Física para Estadounidenses (PAGA), 2ª Edición (2018)** mediante el Protocolo de Encuadre Clínico.

---

## The Clinical Framing Protocol (`Pattern

In the **Matador Wellness Center Clinical AI Residency**, you are the **Architect / Pilot** (Problem Framing and Clinical Judgment) and the AI is the **Engine / Calculator** (Processing). Throughout the semester, every Discussion, Coaching Sprint, and Lab uses our three-part **Clinical Framing Protocol**:

1. **Pattern (`Patrón` — Context):** Diagnose the client case, regional environmental stressors (such as $105^\circ\text{F}\text{ to }115^\circ\text{F}$ Yuma ambient heat or shift-work schedules), baseline vitals, and movement presentation.
2. **Rule (`Regla` — Constraint):** Define the clinical boundaries, safety gates, and federal benchmarks from our Academic Source of Truth (**PAGA 2018, 2nd Edition**).
3. **Solve (`Solución` — Intervention):** Execute a safe, localized physical activity prescription, patient education plan, and human **Active Verification**.

---

## Plain-English Guide: Simulations & Simulators (`paga2018.dev` + `exwtoolkit.com`)

* **In Plain English:** Throughout KIN-101, you use two free, zero-login web apps located right in your left-hand Canvas Course Navigation menu—**`paga2018.dev` ("PAGA")** and **`exwtoolkit.com` ("Toolkit")**—to test client scenarios against **PAGA 2018 (2nd Edition)** and build your weekly assignments:
  1. **`paga2018.dev` ("PAGA" in Left Course Menu):**
     * **Activity Audit (`paga2018.dev/activity-audit`):** Enter a client's weekly moderate and vigorous minutes plus muscle-strengthening days to see if they meet the federal PAGA 2018 benchmark ($150\text{ to }300\text{ min/week}$ moderate or $75\text{ to }150\text{ min/week}$ vigorous + $\ge 2\text{ days/week}$ strength).
     * **Case Coach (`paga2018.dev/case-coach`):** Step-by-step `Pattern / Rule / Solve` clinical coaching sandbox for testing real Yuma and Imperial Valley client scenarios.
     * **Interactive Case Modals (`###` Copy Blocks):** Pre-built client profiles wrapped in triple-hash (`###`) delimiters. Click **"Copy Case (`###`)"** to copy the clean data block without formatting clutter.
     * **Bilingual EN / ES Toggle:** Switch any simulator or federal PAGA rule between English and Norteño-grounded Spanish with one click.
  2. **`exwtoolkit.com` ("Toolkit" in Left Course Menu):**
     * **Stage 1 — Weekly Coaching Sprint:** Uses the embedded micro-simulator right on the Canvas assignment page (`Pattern / Rule / Solve` + 150-word Active Verification).
     * **Stage 2 — Weekly Clinical Lab:** Uses **`paga2018.dev`** + the **`exwtoolkit.com` 9-Box Clinical Architecture** (`1. Biometrics Box` $\rightarrow$ `6. PAGA Cardio Box` $\rightarrow$ `9. Solve Box` *"Copy for Canvas Submission"*).
* **En Palabras Sencillas (Contexto Norteño):** *Durante todo KIN-101 usamos dos herramientas gratuitas y sin contraseña que están directo en el menú izquierdo de Canvas: **"PAGA"** (`paga2018.dev`, con **Activity Audit**, **Case Coach** y **Cuadros de Casos `###`**) y **"Toolkit"** (`exwtoolkit.com`). El micro-simulador integrado en la página es para tu **Coaching Sprint (Etapa 1)**, y las aplicaciones completas son para tu **Laboratorio Clínico (Etapa 2)**.*

---

## Active Verification (`Part 3`): What It Is, Why We Use It, & 10/10 Student Exemplars (Harmonized Across `KIN-101 •...

## 1. What is "Active Verification"?
Every Lab and Coaching Sprint requires the **Four-Part Submission Standard**:
* **Part 1 (The Engine):** Your P-T-C-F Engineered Prompt (Persona, Task, Context, Format).
* **Part 2 (The Clinical Audit):** A 150-word critique of the AI's output against the PAGA 2018 Source of Truth, catching any hallucinations or safety errors.
* **Part 3 (Active Verification):** A **mandatory 150-word minimum verbatim text defense written entirely in your own human voice** justifying why your clinical intervention is safe and appropriate for your specific client.
* **Part 4 (Comparison against the 10/10 Exemplar):** Verifying your work against the module model before submitting.

## 2. Why Do We Use Active Verification? (The Clinical Framework: Pattern / Rule / Solve)
* **In Plain English:** An AI chatbot has never stood on a $112^\circ\text{F}$ ($44.4^\circ\text{C}$) Yuma sidewalk, has never worked an early-morning agricultural harvest shift in San Luis or Somerton, and cannot take ethical responsibility for a human life. We require the 150-word **Active Verification** in your own words to prevent automated copy-pasting and to prove that **you**—the human professional—audited the environmental risks and made the final safety decision.
* **En Palabras Sencillas (Norteño-Spanish):** *La Verificación Activa (mínimo 150 palabras en tu propia voz) demuestra que tú eres el piloto clínico y la IA es solo la calculadora. La IA nunca ha sentido el calor de $112^\circ\text{F}$ en Yuma ni conoce el ritmo de trabajo de nuestra gente en el Valle. Aquí explicas con tus propias palabras cómo aplicaste `Patrón / Regla / Solución` y las reglas de PAGA 2018 para cuidar la salud real de tu cliente.*

## 3. What It Looks Like: KIN-101 Student Exemplar (`10 / 10 Standard`)

> ### Exemplar: KIN-101 Part 3 — Active Verification (158 words, PAGA 2018 Grounded)
> "In my own words, I rejected the AI's suggestion to have my 54-year-old Yuma construction client jog outdoors at 4:00 PM because the ambient temperature is still $108^\circ\text{F}$ ($42.2^\circ\text{C}$), which creates an immediate heat-illness hazard. Following the `Pattern / Rule / Solve` protocol, the **Pattern** is a deconditioned outdoor worker with high occupational heat exposure and zero structured aerobic history. The **Rule** from the 2018 Physical Activity Guidelines for Americans (PAGA, Chapter 4) states that adults should accumulate 150 to 300 minutes per week of moderate-intensity aerobic activity ($3.0\text{ to }5.9\text{ METs}$), and that starting with shorter, tolerable bouts is safest for inactive adults. My **Solve** moves his brisk walking sessions indoors to the air-conditioned AWC track or mall before work for 25 minutes, six days a week ($150\text{ minutes/week}$ total), using the Talk Test (able to speak in full sentences) to keep his intensity safely moderate."

---

## The 10-7-0 Mastery Grading Scale & How to Remedy a `Recalibrate (0 / 10)` Score

All Discussions, Coaching Sprints, and Labs in KIN-101 use **The 10-7-0 Mastery Grading Scale**:

* **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against PAGA 2018 with zero safety errors and a complete 150-word human Active Verification.
* **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes, with minor gaps in detail, word count, or PAGA guideline citations. **You can revise and resubmit to reach 10 / 10.**
* **0 / 10 (Recalibrate):** Missing a required section (such as the 150-word Active Verification), unverified AI copy-paste, or unsafe clinical advice (such as prescribing outdoor midday running in $110^\circ\text{F}$ heat). **`0 / 10` is never a permanent punishment—it is a clinical safety pause and an open invitation to fix the issue and resubmit for full `10 / 10` credit.**

## The 4-Step Remedy Roadmap: How to Fix a `0 / 10 (Recalibrate)` or Upgrade a `7 / 10 (Competent)` Grade

1. **Step 1 — Open Your `Grades` Tab in Canvas (Not the To-Do List):**
   Once an assignment is graded `0 / 10` or `7 / 10`, Canvas removes it from your "To-Do" sidebar. Click **`Grades`** in the left course navigation menu and click the assignment title directly.
2. **Step 2 — Read Coach Alan's *In Plain English* SpeedGrader Note:**
   Every returned assignment includes a specific comment starting with *"In plain English:"* (or *"En palabras sencillas:"*) explaining the exact clinical rule, safety gate, or missing section you need to address.
3. **Step 3 — Revise Only What Was Flagged:**
   Update your submission using **`Pattern / Rule / Solve` (`Patrón / Regla / Solución`)**, cite **PAGA 2018**, and verify that your **Part 3 Active Verification** is at least 150 words in your own human voice.
4. **Step 4 — Click `New Attempt` and Resubmit (Unlimited Attempts Open All Semester):**
   All Labs and Coaching Sprints have **Unlimited Attempts** enabled and remain unlocked through the end of the semester. Click **New Attempt**, submit your updated work, and Coach Alan will re-audit and upgrade your score to **`10 / 10 (Exemplary)`**.

## En Palabras Sencillas: Cómo Recuperar un `0 / 10 (Recalibrate)` o Subir un `7 / 10` a `10 / 10`
*Un `0 / 10 (Recalibrate)` nunca es un castigo definitivo; es una pausa de seguridad clínica y una invitación abierta para corregir y volver a entregar por el `10 / 10` completo. Entra a la pestaña **Grades (Calificaciones)** en Canvas, lee el comentario de Coach Alan en SpeedGrader, corrige el `Patrón / Regla / Solución` o tu Verificación Activa de 150 palabras, y haz clic en **New Attempt (Nuevo Intento)**. Tienes intentos ilimitados durante todo el semestre.*

---

## Check for Understanding
* Before starting Module 01, explain in your own words: Why does a raw AI copy-paste receive a `0 / 10 (Recalibrate)` score, and what four steps do you take in Canvas to upgrade that score to `10 / 10 (Exemplary)`?


###CASE_DATA_START###
Clinical Case Profile / Student Activity Parameters
###CASE_DATA_END###
