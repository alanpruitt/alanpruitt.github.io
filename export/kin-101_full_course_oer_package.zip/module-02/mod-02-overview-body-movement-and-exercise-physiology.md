# KIN-101: Mod 02 Overview Body Movement And Exercise Physiology

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 02 Overview: Body Movement & Exercise Physiology


### Welcome to Mod 02 Overview: Body Movement & Exercise Physiology

Welcome to Module 02! This week, we connect two core subdisciplines of Kinesiology: Biomechanics (how the body moves across the Sagittal, Frontal, and Transverse planes) and Exercise Physiology (how the ATP-PCr, Glycolytic, and Oxidative bioenergetic systems fuel muscle contraction and adapt to training).

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will differentiate mechanical joint alignment breakdown from metabolic substrate depletion (Pattern), apply federal PAGA 2018 (2nd Ed.) multi-planar movement and intensity standards (Rule), and prescribe balanced 3-plane conditioning and heat-safe recovery strategies for Yuma County participants (Solve).


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday at 11:59 PM MST
- Coaching Sprint & Lab Simulations / Entrega de Simulaciones de Sprint y Laboratorio: Monday at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje

- CLO 1 (Pattern Recognition): Differentiate biomechanical movement patterns across the Sagittal, Frontal, and Transverse planes from acute physiological energy system demands. Diferenciar los patrones biomecánicos en los planos Sagital, Frontal y Transversal de las demandas fisiológicas de los sistemas energéticos.
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) intensity guidelines, Talk Test / RPE rules, and multi-planar joint alignment standards. Aplicar las normas de intensidad de la PAGA 2018, la Prueba del Habla / RPE y las reglas de alineación articular multiplanar.
- CLO 3 (Problem Solving): Design an evidence-based 3-plane movement and energy recovery intervention defended in your own clinical voice. Diseñar una intervención de movimiento en los 3 planos y recuperación energética defendida en su propia voz clínica.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

Correcting single-plane joint overuse and frontal-plane hip/knee instability in outpatient rehabilitation.

Structuring multi-planar agility, balance, and aerobic pacing games for youth and community wellness.

Auditing anaerobic ATP-PCr / glycolytic fatigue vs. biomechanical throwing and sprinting mechanics in Yuma heat.


### Module 02 Learning Roadmap / Ruta de Aprendizaje

- Mod 02 Overview: Body Movement & Exercise Physiology (You are here!)
- Mod 02 Required Readings: Body Movement & Exercise Physiology
- Mod 02 Discussion: How the Body Moves vs. How It Adapts (Initial Post Thu / Peer Reply Sun)
- Mod 02 Coaching Sprint: The 3 Planes of Daily Movement (Due Monday 11:59 PM MST)
- Mod 02 Lab: Body Movement & Energy Systems Audit (Due Monday 11:59 PM MST)
- Mod 02 Summary & Wrap-Up: Body Movement & Exercise Physiology

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 02 (Mod 02 Overview: Body Movement & Exercise Physiology)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 contrast override) standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (contraste 9:1), garantizando un acceso digital equitativo y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 02 Visión General: Movimiento Corporal y Fisiología del Ejercicio


### Introducción al Módulo 02

¡Bienvenido al Módulo 02! Esta semana conectamos dos subdisciplinas esenciales de la Kinesiología: la Biomecánica (cómo se mueve el cuerpo en los planos Sagital, Frontal y Transversal) y la Fisiología del Ejercicio (cómo los sistemas energéticos ATP-PCr, Glucolítico y Oxidativo producen energía).

Utilizando el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , distinguirás las fallas mecánicas articulares de la fatiga metabólica (Patrón), aplicarás las normas de intensidad y movimiento multiplanar de la PAGA 2018 (2.ª ed.) (Regla), y prescribirás acondicionamiento en los 3 planos adaptado al clima de Yuma (Solución).


### Module 02 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 02 Required Readings: Body Movement & Exercise Physiology →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 02 Discussion: How the Body Moves vs. How It Adapts →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 02 Coaching Sprint: The 3 Planes of Daily Movement →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 02 Lab: Body Movement & Energy Systems Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 02 Summary & Wrap-Up: Body Movement & Exercise Physiology →
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
