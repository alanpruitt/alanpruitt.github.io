## KIN-101 Module 02: History & Sociology of Human Movement / Historia y Sociología

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

> ### Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (Kinesiology disciplines and foundational physical activity rules).

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module explores the historical milestones and sociological structures that shape human movement, physical activity access, and kinesiology as an academic discipline. Students will analyze how cultural trends, socioeconomic factors, and public health frameworks influence community-wide movement behaviors. All historical baselines and sociological data parameters align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo explora los hitos históricos y las estructuras sociológicas que dan forma al movimiento humano, el acceso a la actividad física y la kinesiología como disciplina académica. Los estudiantes analizarán cómo las tendencias culturales, los factores socioeconómicos y los marcos de salud pública influyen en los comportamientos de movimiento a nivel comunitario. Todos los puntos de referencia históricos y los parámetros de datos sociológicos se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.12]):** Evaluate historical and sociological factors influencing community-level physical inactivity and apply public health frameworks to map equitable physical activity interventions.
* **Español (Regional) ([LO 2.12]):** Evaluar los factores históricos y sociológicos que influyen en la inactividad física a nivel comunitario y aplicar marcos de salud pública para trazar intervenciones de actividad física equitativas.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Identify and document historical shifts in occupational labor and sociological patterns of physical inactivity across diverse community demographics.
   * **Patrón (Español):** Identificar y documentar los cambios históricos en el trabajo laboral y los patrones sociológicos de la inactividad física a través de diversas demografías comunitarias.
2. **Rule (English):** Apply the federal guidelines and population metrics outlined in the PAGA 2018 framework to establish a baseline criteria for public health interventions.
   * **Regla (Español):** Aplicar las pautas federales y las métricas de población descritas en el marco de PAGA 2018 para establecer los criterios de referencia para las intervenciones de salud pública.
3. **Solve (English):** Engineer a community-level health intervention blueprint that eliminates socioeconomic barriers and promotes sustainable, equitable access to physical activity environments.
   * **Solución (Español):** Diseñar un plan de intervención de salud a nivel comunitario que elimine las barreras socioeconómicas y promueva el acceso sostenible y equitativo a los entornos de actividad física.

---

## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Andamiaje

## Part A: Gemini AI Simulation (Sociological Trend Mapping)

## English

Students will initialize the virtual demographic auditing setup within their sandbox workspace. Ensure your simulated community dataset inputs remain fully wrapped inside the required layout delimiters below.

```text
## [PASTE SIMULATED COMMUNITY DEMOGRAPHIC AND INACTIVITY DATA HERE]
###
```

1. Use the sandbox environment to audit a simulated municipal dataset, identifying historical and infrastructure trends linked to declining leisure-time physical activity blocks.
2. Cross-examine community physical inactivity patterns against the baseline population risk categories established by the historical sections of the federal PAGA document.
3. Execute an automated audit script within the sandbox to verify that proposed community interventions address specific localized infrastructure gaps safely and equitably.

## Español (Regional)

Los estudiantes inicializarán la configuración de la auditoría demográfica virtual dentro de su espacio de trabajo sandbox. Asegúrese de que las entradas de datos simulados de la comunidad permanezcan completamente envueltas dentro de los delimitadores de diseño requeridos a continuación.

```text
## [PEGUE LOS DATOS SIMULADOS DEMOGRÁFICOS Y DE INACTIVIDAD COMUNITARIA AQUÍ]
###
```

1. Utilizar el entorno de pruebas (sandbox) para auditar un conjunto de datos municipales simulados, identificando tendencias históricas y de infraestructura vinculadas a la disminución de bloques de actividad física en el tiempo libre.
2. Evaluar de forma cruzada los patrones de inactividad física de la comunidad frente a las categorías de riesgo de la población de referencia establecidas por las secciones históricas del documento federal PAGA.
3. Ejecutar un guión de auditoría automatizado dentro del sandbox para verificar que las intervenciones comunitarias propuestas aborden las brechas de infraestructura localizadas específicas de manera segura y equitativa.

## Part B: Practical Field Application (Community Audit Log)

## English

Students will transition into their immediate regional spaces to complete an active, zero-cost physical activity accessibility audit.

1. Complete a visual environment screening of a local park, public workspace, or neighborhood perimeter, documenting physical activity barriers (such as missing sidewalks or poorly lit spaces).
2. Analyze immediate community access metrics through a sociological lens, checking how local layout features support or hinder movement across variable age and income blocks.
3. Document true environmental indicators: record accessibility factors and cross-examine your field findings against the target physical activity solutions established in the federal PAGA guidelines.

## Español (Regional)

Los estudiantes harán la transición a sus espacios regionales inmediatos para completar una auditoría activa y de costo cero sobre la accesibilidad de la actividad física.

1. Completar una evaluación visual del entorno de un parque local, espacio de trabajo público o perímetro del vecindario, documentando las barreras para la actividad física (como la falta de aceras o espacios mal iluminados).
2. Analizar las métricas de acceso comunitario inmediato a través de una lente sociológica, verificando cómo las características del diseño local apoyan o dificultan el movimiento a través de variables bloques de edad e ingresos.
3. Documentar los indicadores ambientales reales: registrar los factores de accesibilidad y evaluar de forma cruzada sus hallazgos de campo con las soluciones de actividad física objetivo establecidas en las pautas federales de PAGA.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This foundational module assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación del módulo fundamental se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):**
  * **English:** Zero-drift integration. Community intervention strategies and sociological pattern audits align perfectly with PAGA data specifications; all simulation log records remain fully wrapped with no structural layout gaps.
  * **Español (Regional):** Integración sin desviaciones. Las estrategias de intervención comunitaria y las auditorías de patrones sociológicos se alinean perfectamente con las especificaciones de datos de PAGA; todos los registros de simulación permanecen completamente envueltos sin brechas estructurales de diseño.
* **7 (Competent) / (Competente):**
  * **English:** Minor refactoring required. Core Clinical Framing Protocol phases and historical concepts are appropriately applied, but minor formatting gaps or delimiter omissions are flagged in the final file.
  * **Español (Regional):** Se requiere una reestructuración menor. Las fases del Protocolo de Encuadre Clínico y los conceptos históricos se aplican adecuadamente, pero se identifican pequeñas brechas de formato u omisiones de delimitadores en el archivo final.
* **0 (Recalibrate) / (Recalibrar):**
  * **English:** Critical misunderstanding of epidemiological data or un-fenced community profiling metrics that fail to apply federal PAGA guidelines correctly. Complete rewrite required.
  * **Español (Regional):** Comprensión crítica errónea de los datos epidemiológicos o métricas de perfil comunitario sin delimitar que no aplican correctamente las pautas federales de PAGA. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.


<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>


## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
