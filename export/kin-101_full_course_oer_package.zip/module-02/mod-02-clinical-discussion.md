# KIN-101: Mod 02 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Discussion: How the Body Moves vs. How It Adapts

This week, we deconstruct the breakdown of athletic and functional performance into mechanical joint forces (Biomechanics) versus energy substrate depletion and thermoregulatory fatigue (Exercise Physiology). Select a career-aligned track below and audit a real-world movement breakdown using Google Gemini!

Esta semana, desglosamos el colapso del rendimiento deportivo y funcional en términos de fuerzas mecánicas articulares (Biomecánica), frente al agotamiento de los sustratos energéticos y de la fatiga termorreguladora (Fisiología del Ejercicio). ¡Seleccione una ruta alineada con su carrera y audite una falla de movimiento con Google Gemini!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM / Martes a las 12:00 AM
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM / Jueves a las 11:59 PM
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM / Domingo a las 11:59 PM
- Board Closes / Cierre del Foro: Monday at 11:59 PM / Lunes a las 11:59 PM
I review every initial submission and post my clinical analyses directly in this public thread as well as inside SpeedGrader. Be sure to check back to see my detailed Feedback on your post and your peers' posts to sharpen your sub-disciplinary auditing skills!

Reviso cada publicación inicial y publico mis análisis clínicos directamente en este hilo público, así como en SpeedGrader. ¡Asegúrese de regresar para ver mis comentarios detallados en su publicación y en la de sus compañeros, para perfeccionar sus habilidades de auditoría!


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI Preceptor query:

Focus: Post-rotator cuff surgery patient experiencing acute shoulder impingement and muscular fatigue during overhead rehabilitation exercises.

Focus: Outdoor municipal park maintenance worker suffering repetitive lifting spinal strain and heat-induced metabolic fatigue in Yuma summer conditions.

Focus: Collegiate starting right-handed baseball pitcher experiencing a sharp fastball velocity drop and anterior shoulder pain after 50 pitches.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM):

- Identify Selected Track & Case / Identifique la Ruta y Caso Seleccionado: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and client initials. Indique la ruta seleccionada y las iniciales del cliente.
- Isolate Biomechanical Factors / Aísle los Factores Biomecánicos: What kinetic forces, lever lengths, joint alignment errors, or shearing vectors contributed to the physical movement breakdown? ¿Qué fuerzas cinéticas, longitudes de palanca, errores de alineación articular o vectores de cizallamiento contribuyeron a la falla mecánica?
- Isolate Exercise Physiology Factors / Aísle los Factores de Fisiología del Ejercicio: What metabolic energy depletion (ATP-CP, glycogen), neuromuscular firing degradation, or heat-induced cardiorespiratory drift caused systemic exhaustion? ¿Qué agotamiento de energía metabólica (ATP-PC, glucógeno), degradación de la activación neuromuscular o fatiga cardiorrespiratoria inducida por el calor causó el agotamiento sistémico?

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate whether they accurately separated mechanical forces from metabolic fatigue in their case example, or suggest an additional corrective exercise drill or physiological recovery intervention!


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Case Selection / Selección de Caso: A starting right-handed baseball pitcher experiencing a sharp fastball velocity drop (from 90 mph down to 82 mph) and anterior shoulder pain after 50 pitches during an afternoon game in Yuma heat. Un lanzador abridor diestro de béisbol que experimenta una caída drástica en la velocidad de su bola rápida (de 90 mph a 82 mph) y dolor anterior en el hombro después de 50 lanzamientos durante un partido por la tarde en el calor de Yuma.
- Biomechanical Audit / Auditoría Biomecánica: During the late cocking and acceleration phases, the pitcher displays insufficient scapular upward rotation and serratus anterior weakness. This allows the humeral head to translate excessively anteriorly, causing subacromial impingement of the supraspinatus tendon. The mechanical error is a joint-alignment vector failure at high angular velocity (τ = F · d). Durante las fases de preparación tardía y aceleración, el lanzador muestra una rotación escapular superior insuficiente y debilidad del serrato anterior. Esto permite que la cabeza humeral se traslade excesivamente hacia adelante, lo que provoca un pinzamiento subacromial del tendón del supraespinoso. El error mecánico es una falla en el vector de alineación articular bajo alta velocidad angular (τ = F · d).
- Exercise Physiology Audit / Auditoría de Fisiología del Ejercicio: High-velocity pitching relies on rapid ATP-CP phosphagen breakdown backed by anaerobic glycolysis. By pitch 50, intramuscular phosphagen depletion and metabolite accumulation reduce the rate of force development. Furthermore, playing in Yuma's 102°F heat triggers severe cardiovascular drift—elevating heart rate to maintain cardiac output as plasma volume drops through sweating—which accelerates central nervous system fatigue and degrades motor unit recruitment. El picheo de alta velocidad depende de la rápida descomposición de fosfágenos (ATP-PC), respaldada por la glucólisis anaerobia. Para el lanzamiento 50, el agotamiento de los fosfágenos intramusculares y la acumulación de metabolitos reducen la tasa de desarrollo de la fuerza. Además, jugar en el calor de 102 °F de Yuma desencadena una severa deriva cardiovascular —elevando la frecuencia cardíaca para mantener el gasto cardíaco a medida que disminuye el volumen plasmático por la sudoración— lo que acelera la fatiga del sistema nervioso central y degrada el reclutamiento de unidades motoras.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 02 (Mod 02 Discussion: How the Body Moves vs. How It Adapts)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Resumen de Navegación en Español (KIN-101 • Conceptos de Kinesiología y Educación Física • Módulo 02)

Este recurso incluye traducción bilingüe integrada en cada sección bajo el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y nuestra Fuente Única de Verdad (Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.)). Usted puede participar y entregar sus análisis en inglés, español o ambos.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:
