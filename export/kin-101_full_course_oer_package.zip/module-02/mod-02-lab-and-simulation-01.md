# KIN-101: Mod 02 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Lab & Simulation: Body Movement & Energy Systems Audit

Módulo 02 Laboratorio: Auditoría de Planos de Movimiento y Sistemas Energéticos

- Cardiac Output (Q = Heart Rate × Stroke Volume): Total volume of blood pumped by the heart per minute (L/min), which rises during exercise to deliver oxygen to working skeletal muscle. En palabras sencillas: La cantidad de sangre por minuto que bombea el corazón para llevar oxígeno a los músculos cuando empiezas a moverte.
- Acute Response vs. Chronic Physiological Adaptation: Acute responses are immediate changes during a single workout (higher HR, sweating); chronic adaptations are long-term gains after weeks of training (lower resting HR, higher capillary density). En palabras sencillas: Lo agudo pasa durante la sesión (sube el pulso y sudas); la adaptación crónica es el beneficio duradero tras semanas de constancia.
- Thermoregulatory Heat Strain (Yuma Desert Environment): In ambient temperatures >100°F, blood flow diverts to the skin for cooling, accelerating heart rate and dehydration during outdoor work or exercise. En palabras sencillas: En el calor de Yuma el cuerpo desvía sangre a la piel para enfriarse, lo que sube las pulsaciones más rápido y exige hidratación y sombra.
- KIN-101.2.1.AY26-27: Analyze human movement across the Sagittal, Frontal, and Transverse planes and identify acute bioenergetic pathway demands (ATP-PCr, Glycolytic, Oxidative).
- KIN-101.3.1.AY26-27: Prescribe a multi-planar movement and metabolic recovery protocol grounded in PAGA 2018 standards and defended in your own clinical voice.
- Pattern (Context): Diagnose single-plane biomechanical overuse or dynamic joint misalignment alongside the dominant bioenergetic pathway (ATP-PCr, Anaerobic Glycolysis, or Oxidative Phosphorylation).
- Rule (SSoT Benchmark): Apply PAGA 2018 (2nd Ed.) multicomponent exercise guidelines, anatomical plane/axis mechanics, and work-to-rest bioenergetic recovery ratios.
- Solve (Intervention & Active Verification): Prescribe a balanced 3-plane exercise intervention (Sagittal, Frontal, Transverse), a metabolic pacing/hydration plan for Yuma conditions, a 2-sentence bilingual client card (EN / ES), and a 150-word minimum Active Verification (Part 3).
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-02 / Fase 1: Selección de Escenario de Simulación Clínica

Select ONE of the three career-aligned case files below (wrapped in triple-hash ### delimiters):

Outpatient rehab client (Elena R., 42, Yuma, AZ) who only walks straight ahead on a treadmill (Sagittal plane) and exhibits medial knee collapse (Frontal-plane valgus) and early lower-limb fatigue when climbing stairs.

High school PE cohort in Yuma County performing repetitive straight-line laps in 98°F morning warmth, showing poor lateral agility and rapid fatigue during 30-second shuttle drills.

Collegiate soccer midfielder (Diego V., 19, AWC Matadors) experiencing loss of rotational passing accuracy (Transverse plane) and slow repeat-sprint recovery (ATP-PCr / Glycolytic depletion) in the second half.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paste your chosen Case File data wrapped in triple-hashes ( ### ) into Google Gemini, then paste this P-T-C-F prompt directly below it:

AI Disclosure: This workflow uses Google Gemini as a Clinical Calculator. Residents must audit all AI claims against the PAGA 2018 Source of Truth. AI can make mistakes.


### Phase 3: Canvas Text Box Submission Requirements / Fase 3: Requisitos de Entrega en Canvas (Solo Texto)

- Selected Track & Client Baseline: State your chosen track and client case profile.
- Part 1: Pattern Recognition (Context & Deficit Audit): Diagnose the client's movement/plane or activity volume deficit and regional Yuma environmental stressors.
- Part 2: Rule Application (PAGA 2018 SSoT Audit): Cite the exact federal PAGA 2018 (2nd Ed.) volume, frequency, intensity (Talk Test / RPE), and biomechanical/physiological rules that govern this case.
- Part 3: Solve & Bilingual Client Card (EN / ES): Provide your structured weekly prescription and a 2-sentence bilingual instruction card in English and Spanish.
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own authentic clinical voice, justify why your specific adjustments protect this client better than a generic, unverified AI workout plan in Yuma's climate.
- Repository Verification: Confirm archive to EXW_Professional_AI_Repository / EXW_101_M02_Planes_Energy_Lab.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track & Case: Track 1: Clinical & Allied Health Path (Elena R., Age 42, Yuma, AZ)

- Part 1: Pattern Recognition: Biomechanical & Bioenergetic Pattern: Elena's exercise routine is trapped exclusively in the Sagittal plane (forward treadmill walking), leaving her Frontal plane hip abductors (gluteus medius) and Transverse plane hip external rotators undertrained—which causes medial knee valgus during stair ascent. Bioenergetically, her 45-second continuous stair climb shifts rapidly from the ATP-PCr system (0–10 sec) into Anaerobic Glycolysis (10–90 sec), causing localized hydrogen-ion accumulation and premature quad fatigue.
- Part 2: Rule Application (PAGA 2018 SSoT): PAGA 2018 & Physiological Rules: Under PAGA 2018 (2nd Ed.) , adults require multicomponent muscle-strengthening across all major muscle groups ≥2 days/week alongside 150–300 minutes/week of moderate oxidative aerobic activity. Biomechanically, preventing frontal-plane knee valgus requires strengthening lateral hip stabilizers and transverse-plane trunk/pelvic control. Bioenergetically, 30–45 second glycolytic bouts require a 1:3 to 1:4 work-to-rest ratio (90–120 seconds rest) to clear metabolic byproducts and restore force production.
- Part 3: Solve & Bilingual Client Card: 3-Plane Exercise & Bioenergetic Prescription: Sagittal Plane (Forward/Back): Supported Step-Ups (2 sets × 10 reps, 30 sec work : 90 sec rest to allow phosphagen/glycolytic recovery). Frontal Plane (Side-to-Side): Lateral Mini-Band Monster Walks (2 sets × 12 steps/side to activate gluteus medius and prevent knee valgus). Transverse Plane (Rotational): Standing Pallof Cable Press with Thoracic Rotation (2 sets × 10 reps/side for core anti-rotation). Oxidative Conditioning: 30 minutes brisk indoor/early-morning walking 5 days/week (150 min/week total). Bilingual Client Card (EN / ES): EN: "Train your hips in all three planes using step-ups, side band walks, and torso rotations twice a week, resting 90 seconds between sets so your muscles recover fully." ES: "Entrene sus caderas en los tres planos con subidas al escalón, pasos laterales con banda y giros de torso dos veces por semana, descansando 90 segundos entre series para recuperar su energía."
- Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical reasoning as Elena's movement architect, a generic AI workout generator often misdiagnoses stair-climbing knee pain as simple 'weak quads' and prescribes high-repetition sagittal lunges with 15-second rest intervals. For Elena, that error would worsen her frontal-plane medial knee collapse while trapping her muscles in unrecovered anaerobic glycolysis. By separating her biomechanical pattern (frontal and transverse hip instability) from her bioenergetic pattern (glycolytic fatigue during 45-second stair bouts), I prioritized lateral band walks and rotational core control alongside a strict 1:3 work-to-rest ratio (90 seconds rest). Grounded in PAGA 2018 multicomponent strength standards, this 3-plane progression protects her patellofemoral joint and builds real-world stair endurance. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."
- Repository Verification: AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M02_Planes_Energy_Lab.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 02 (Mod 02 Lab: Body Movement & Energy Systems Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 02 Laboratorio y Simulación: Auditoría de Planos de Movimiento y Sistemas Energéticos


### Fase 3: Requisitos de Entrega en Canvas (Solo Texto en Español o Inglés)

- Ruta y Caso Seleccionado: Indique la ruta profesional y el perfil del cliente.
- Parte 1: Reconocimiento de Patrones (Patrón): Diagnostique el déficit de movimiento/planos o volumen aeróbico y las barreras de calor en Yuma.
- Parte 2: Aplicación de Reglas (Regla PAGA 2018): Cite las reglas exactas de volumen, frecuencia, intensidad (Prueba del Habla / RPE) y biomecánica/fisiología de PAGA 2018.
- Parte 3: Solución y Tarjeta Bilingüe (Solución): Presente su prescripción semanal y una tarjeta bilingüe de 2 oraciones (EN / ES).
- Parte 4: Verificación Activa Obligatoria (Mínimo 150 Palabras en su Propia Voz Humana): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué sus ajustes protegen la seguridad del cliente frente a los errores comunes de la IA en el clima de Yuma.
- Verificación del Repositorio: Confirme el archivo en EXW_Professional_AI_Repository / EXW_101_M02_Planes_Energy_Lab.pdf .

### Modelo de Verificación Activa 10/10 (En Palabras Sencillas / Norteño)

"En mi razonamiento clínico como arquitecto del movimiento de Elena, un generador genérico de IA suele confundir el dolor de rodilla al subir escaleras con simple debilidad de cuádriceps y receta desplantes sagitales con solo 15 segundos de descanso. En el caso de Elena, ese error agravaría su colapso medial de rodilla en el plano frontal y saturaría sus músculos en glucólisis anaeróbica sin recuperación. Al separar su patrón biomecánico (inestabilidad frontal y transversal de cadera) de su patrón bioenergético, prioricé pasos laterales con banda y control rotacional con una relación trabajo-descanso de 1:3 (90 segundos). Alineado con PAGA 2018, este diseño en 3 planos protege su articulación patelofemoral."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:
