# KIN-101: Mod 02 Required Readings Body Movement And Exercise Physiology

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Required Readings: Body Movement & Exercise Physiology


### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 02 (Mod 02 Required Readings: Body Movement & Exercise Physiology)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Resumen de Navegación en Español (KIN-101 • Conceptos de Kinesiología y Educación Física • Módulo 02)

Este recurso incluye traducción bilingüe integrada en cada sección bajo el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y nuestra Fuente Única de Verdad (Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.)). Usted puede participar y entregar sus análisis en inglés, español o ambos.


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Exercise physiology explains how your heart, lungs, and muscles turn oxygen and food into movement energy. During physical work, your heart rate and breathing rise to deliver oxygen while muscle fibers contract and adapt. Understanding these acute responses lets you set safe exercise intensity using the Talk Test and RPE.


#### En Palabras Sencillas (Norteño Context)

Igual que un aire acondicionado en Yuma trabaja más fuerte a las tres de la tarde, tu corazón y tus pulmones ajustan su potencia cuando empiezas a entrenar. Si los términos técnicos se ponen pesados, concéntrate primero en cómo usar la Prueba del Habla y la escala RPE para medir el esfuerzo seguro.


### Required SSoT Text & Professional Guidelines

Primary Single Source of Truth (SSoT): LibreTexts Kinesiology Framework & NIH / PMC Biomechanics and Physiology Review. Marco de Subdisciplinas de Kinesiología y Revisión de Biomecánica y Fisiología de NIH / PMC.

- Subdisciplines Overview: Kinesiology and its Subdisciplines (LibreTexts)
- Full-Text Article (PMC): Exercise Biomechanics and Physiology Review (PMC7921909)
- Official DOI Link: DOI: 10.3390/life11020159
- PubMed Portal: PubMed Reference (PMID: 33669578)
- Exercise Physiology & Mechanical Load Adaptations: NCBI Bookshelf StatPearls: Exercise Physiology & Mechanical Loading

### Core Scientific Concepts / Conceptos Clave


#### 1. Biomechanical Vectors vs. Physiological Fatigue / Biomecánica vs. Fisiología

Biomechanics examines internal/external force vectors, lever mechanics, joint torques (τ = F · d), and movement kinematics. Exercise Physiology examines metabolic energy pathways (ATP-PC, anaerobic glycolysis, oxidative phosphorylation), thermoregulatory strain, and neuromuscular fatigue.

La Biomecánica examina fuerzas internas/externas y momentos de fuerza (τ = F · d). La Fisiología del Ejercicio examina rutas metabólicas, termorregulación y fatiga neuromuscular.


#### 2. Sub-Disciplinary Separation in Performance / Separación Subdisciplinaria

Isolating mechanical joint breakdown (e.g., scapular dyskinesis or glenohumeral anterior shear during throwing) from metabolic substrate depletion (e.g., phosphagen depletion during repeated high-intensity efforts) allows clinicians to target corrective exercises and energy recovery strategies independently.

Aislar las fallas mecánicas articulares del agotamiento metabólico permite a los profesionales diseñar ejercicios correctivos y estrategias de recuperación de forma independiente.


### Key Terminology / Glosario Clave

- Kinematics / Cinemática: The branch of mechanics that describes the motion of points, bodies, and systems without considering the forces that cause the motion (e.g., velocity, acceleration, joint angles). La rama de la mecánica que describe el movimiento de puntos, cuerpos y sistemas sin considerar las fuerzas que lo causan (ej. velocidad, aceleración, ángulos articulares).
- Kinetics / Cinética: The study of forces that cause, modify, or arrest human motion (e.g., ground reaction forces, muscular joint torques, friction). El estudio de las fuerzas que causan, modifican o detienen el movimiento humano (ej. fuerzas de reacción del suelo, momentos articulares musculares, fricción).
- Cardiovascular Drift / Deriva Cardiovascular: A progressive increase in heart rate during prolonged steady-state exercise in warm environments, driven by decreased stroke volume secondary to cutaneous vasodilation and plasma fluid loss. Un aumento progresivo en la frecuencia cardíaca durante el ejercicio prolongado en estado estable en ambientes cálidos, impulsado por la disminución del volumen de eyección secundaria a la vasodilatación cutánea y pérdida de plasma.
KIN-101 • Module 02 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 02:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
