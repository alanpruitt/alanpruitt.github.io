# KIN-101: Mod 02 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Coaching Sprint Simulation: The 3 Planes of Daily Movement

Sesión de Coaching del Módulo 02: Los 3 Planos del Movimiento Cotidiano

- Cardiac Output (Q = Heart Rate × Stroke Volume): Total volume of blood pumped by the heart per minute (L/min), which rises during exercise to deliver oxygen to working skeletal muscle. En palabras sencillas: La cantidad de sangre por minuto que bombea el corazón para llevar oxígeno a los músculos cuando empiezas a moverte.
- Acute Response vs. Chronic Physiological Adaptation: Acute responses are immediate changes during a single workout (higher HR, sweating); chronic adaptations are long-term gains after weeks of training (lower resting HR, higher capillary density). En palabras sencillas: Lo agudo pasa durante la sesión (sube el pulso y sudas); la adaptación crónica es el beneficio duradero tras semanas de constancia.
- Thermoregulatory Heat Strain (Yuma Desert Environment): In ambient temperatures >100°F, blood flow diverts to the skin for cooling, accelerating heart rate and dehydration during outdoor work or exercise. En palabras sencillas: En el calor de Yuma el cuerpo desvía sangre a la piel para enfriarse, lo que sube las pulsaciones más rápido y exige hidratación y sombra.
- KIN-101.2.1.AY26-27: Classify foundational human movements across the three cardinal planes: Sagittal, Frontal, and Transverse. Clasificar los movimientos humanos básicos en los tres planos cardinales: sagital, frontal y transversal.
- KIN-101.2.2.AY26-27: Identify basic joint actions in everyday physical activities and practical fitness settings. Identificar acciones articulares básicas en actividades cotidianas y entornos de ejercicio.

### Your Weekly Win: Unlocking Multi-Planar Movement

This weekly sprint is designed to give you a quick, satisfying mastery "win." Instead of memorizing abstract physics, you will explore how the human body moves in 3D space: Forward/Back (Sagittal), Side-to-Side (Frontal), and Twisting (Transverse). Pick your career track below, chat with your AI Coach, and walk away with a memorable insight you can share with future clients!

Esta sesión semanal está diseñada para brindarle un logro claro y motivador. Elegirá su ruta profesional, conversará con su Coach de IA y obtendrá un aprendizaje clave para aplicarlo en el mundo real.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Elija la ruta que más se alinee con sus metas profesionales

Scenario: Desk worker with stiff lower back who only exercises on a treadmill (forward-only movement) and feels pain when reaching to the side.

Scenario: Senior center walking club member who wants to improve balance and avoid tripping over curbs in Yuma.

Scenario: High school soccer athlete who is strong in straight sprints but slow and uncoordinated when cutting and changing directions.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client situation.
- The 3-Plane Breakdown: Name 1 simple exercise for Sagittal (Forward/Back), 1 for Frontal (Side-to-Side), and 1 for Transverse (Twisting).
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why integrating Frontal (side-to-side) and Transverse (rotational) plane exercises protects your client's joints from single-plane overuse injuries under PAGA 2018 multicomponent standards.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 02 Coaching Sprint • Track 1 (Clinical / Elena)

- Chosen Track & Client: Track 1: Clinical Path (Elena, 42, desk worker). Problem: Elena only walks straight ahead on a treadmill (Sagittal plane). Because she never trains side-to-side or twisting, her hip stabilizers are weak and her lower back hurts when stepping out of her car.
- Track 1: Clinical Path (Elena, 42, desk worker).
- Problem: Elena only walks straight ahead on a treadmill (Sagittal plane). Because she never trains side-to-side or twisting, her hip stabilizers are weak and her lower back hurts when stepping out of her car.
- The 3-Plane Breakdown: Step 1: Sagittal Plane (Forward & Back): Bodyweight Squats (builds knee and hip extension for standing up from her desk). Step 2: Frontal Plane (Side-to-Side): Lateral Resistance Band Steps (strengthens her gluteus medius so she has stable hips when stepping sideways). Step 3: Transverse Plane (Twisting): Standing Torso Rotations with light cable or bodyweight (restores thoracic spine mobility for turning safely).
- Step 1: Sagittal Plane (Forward & Back): Bodyweight Squats (builds knee and hip extension for standing up from her desk).
- Step 2: Frontal Plane (Side-to-Side): Lateral Resistance Band Steps (strengthens her gluteus medius so she has stable hips when stepping sideways).
- Step 3: Transverse Plane (Twisting): Standing Torso Rotations with light cable or bodyweight (restores thoracic spine mobility for turning safely).
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical reasoning, Elena's lower-back and hip discomfort stems directly from sagittal-plane dominance: she sits forward at a desk all day and only walks straight ahead on a treadmill. An unverified AI workout that simply adds more forward walking or sagittal lunges leaves her frontal-plane hip abductors (gluteus medius) and transverse-plane thoracic rotators weak, leaving her lumbar spine vulnerable the moment she twists to step out of her car. By applying PAGA 2018 multicomponent muscle-strengthening guidelines across all three anatomical planes—combining bodyweight squats with lateral band walks and standing torso rotations—we restore 3D pelvifemoral stability and protect her spine during everyday life in Yuma."
- My Memorable Coaching Takeaway: EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!" ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!"
- ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M02_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 02 (Mod 02 Coaching Sprint: The 3 Planes of Daily Movement)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología


## Módulo 02 Simulación de Coaching: Los 3 Planos del Movimiento

Evaluación Rápida y Aprendizaje Práctico del Movimiento Funcional


### Su Logro Semanal: Dominar el Movimiento en 3D

Esta sesión está diseñada para brindarle un logro rápido y motivador. Aprenderá cómo el cuerpo se mueve en 3 dimensiones: Hacia adelante/atrás (sagital), De lado a lado (frontal) y Giros (transversal). ¡Elija su ruta profesional, converse con su Coach de IA y obtenga una enseñanza inolvidable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el cliente elegido.
- Desglose de los 3 Planos: Nombre 1 ejercicio para el plano Sagital, 1 para el Frontal y 1 para el Transversal.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué integrar ejercicios en los planos Frontal y Transversal protege las articulaciones del cliente contra lesiones por sobreuso en un solo plano según PAGA 2018.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 02 Sesión de Coaching • Ruta 1 (Elena)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica (Elena, 42 años, oficinista). Problema: Solo camina en cinta hacia adelante (plano sagital). Como nunca entrena de lado o girando, sus caderas están débiles y le duele la espalda al bajarse del carro.
- Ruta 1: Clínica (Elena, 42 años, oficinista).
- Problema: Solo camina en cinta hacia adelante (plano sagital). Como nunca entrena de lado o girando, sus caderas están débiles y le duele la espalda al bajarse del carro.
- Desglose de los 3 Planos: Step 1: Plano Sagital (Adelante y Atrás): Sentadillas con peso corporal (fortalece piernas para levantarse de la silla). Step 2: Plano Frontal (Lado a Lado): Pasos laterales con banda de resistencia (fortalece glúteo medio para dar pasos de lado sin dolor). Step 3: Plano Transversal (Giros): Rotaciones de torso de pie (devuelve movilidad a la columna para girar con seguridad).
- Step 1: Plano Sagital (Adelante y Atrás): Sentadillas con peso corporal (fortalece piernas para levantarse de la silla).
- Step 2: Plano Frontal (Lado a Lado): Pasos laterales con banda de resistencia (fortalece glúteo medio para dar pasos de lado sin dolor).
- Step 3: Plano Transversal (Giros): Rotaciones de torso de pie (devuelve movilidad a la columna para girar con seguridad).
- Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi criterio clínico, el dolor de espalda y cadera de Elena proviene de moverse únicamente en el plano sagital: pasa el día sentada frente al escritorio y solo camina hacia adelante en la caminadora. Si una IA genérica le receta más caminata lineal, sus estabilizadores laterales en el plano frontal (glúteo medio) y rotadores en el plano transversal seguirán débiles al girar para bajarse del carro. Al aplicar las pautas de fuerza multicomponente de PAGA 2018 en los tres planos—sumando pasos laterales con banda y rotaciones de torso—devolvemos la estabilidad tridimensional a su cadera y protegemos su columna lumbar."
- Mi Frase Inolvidable de Coaching: EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!" ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!"
- ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M02_Quiz_Sprint.pdf
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:
