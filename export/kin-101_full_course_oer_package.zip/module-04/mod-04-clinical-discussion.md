# KIN-101: Mod 04 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology / Conceptos de Kinesiología


## Mod 04 Discussion: Choosing Your Exercise Science Career Path

Alineación de Rutas Profesionales, Credenciales y Alcance de la Práctica

Navigating credentials in movement science requires clear knowledge of legal scopes of practice and educational prerequisites. Select a career-aligned track below and audit professional certifications, exam prerequisites, and scope boundaries using our academic SSoT ( Physical Activity Guidelines for Americans, PAGA 2018, 2nd Edition ) and the Gemini AI Preceptor!

Navegar por las credenciales en las ciencias del movimiento requiere un conocimiento claro de los alcances legales de la práctica y los requisitos académicos. ¡Seleccione una ruta profesional y audite certificaciones, prerrequisitos de examen y límites legales con las pautas federales PAGA 2018 y el Preceptor de IA Gemini!

- Topic Opens / Apertura del Foro: Tuesday, September 8, 2026, at 12:00 AM MST / Martes a las 12:00 AM
- Initial Post Due / Publicación Inicial: Thursday, September 10, 2026, at 11:59 PM MST / Jueves a las 11:59 PM
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 13, 2026, at 11:59 PM MST / Domingo a las 11:59 PM
- Board Closes / Cierre del Foro: Monday, September 14, 2026, at 11:59 PM MST / Lunes a las 11:59 PM
You are warmly encouraged to post in English or Spanish according to your preference. Le animamos a publicar en inglés o en español según su preferencia académica.

To support your professional pathway development, instructor evaluations and career guidance notes are posted in this public community board as well as in Gradebook.


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI Preceptor query:

Focus: Clinical Exercise Physiology (ACSM-EP / CEP) candidate S.K. targeting hospital-based cardiopulmonary rehab and outpatient prescription at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[CANDIDATE INITIALS]: S.K. | [AGE]: 22 | [LOCATION]: Yuma County, AZ
[TARGET CREDENTIAL]: ACSM Certified Clinical Exercise Physiologist (ACSM-CEP)
[TARGET SITE]: Matador Clinical Partners (MCP) Cardiac Rehabilitation Unit
[SCOPE FOCUS]: Clinical ECG telemetry, cardiac rehab Phase II/III, chronic disease risk stratification.
###
```

Focus: Community Health & Inclusive Fitness Specialist (ACSM-GEI / NCHPAD CIFT) candidate M.R. targeting municipal wellness and inclusive exercise in Yuma County.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CANDIDATE INITIALS]: M.R. | [AGE]: 24 | [LOCATION]: Yuma County, AZ
[TARGET CREDENTIAL]: ACSM Group Exercise Instructor (ACSM-GEI) & NCHPAD CIFT
[TARGET SITE]: Yuma County Public Health Services District & Parks Recreation Centers
[SCOPE FOCUS]: Population health promotion, inclusive adaptive fitness, heat-adapted group conditioning.
###
```

Focus: Strength & Conditioning Specialist (NSCA-CSCS) candidate J.T. targeting collegiate athletic power periodization at AWC Athletics.


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[CANDIDATE INITIALS]: J.T. | [AGE]: 23 | [LOCATION]: Yuma, AZ
[TARGET CREDENTIAL]: NSCA Certified Strength and Conditioning Specialist (NSCA-CSCS)
[TARGET SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center
[SCOPE FOCUS]: Athletic power development, Olympic lifting mechanics, periodization, injury reduction.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a credential and scope-of-practice audit:


```text
Safety Auditor Protocol: KIN-101 Scope & Career Preceptor ###:
Role: Academic Kinesiology Advisor and Credentialing Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) & Professional Scopes (ACSM, NSCA, NASM).

Instructions:
Step 1: Review the candidate case file wrapped in triple-hashes (###) below.
Step 2: Analyze the target credential scope of practice, minimum degree requirements, and clinical/field hour prerequisites.
Step 3: Analyze a real-world scope violation scenario where a practitioner in this track operates outside their legal boundaries in Yuma County.
Step 4: Construct a 2-year strategic career roadmap detailing degree completion at AWC/partner institutions, CPR/BLS certification, local Yuma internship sites, and exam scheduling.
Step 5: Maintain all client data wrapped in triple-hash (###) delimiters.

Candidate Data Input ###:
[Paste Your Selected Track Data Block Here]
End Candidate Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Target Credential: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and target credential (e.g., ACSM-CEP, ACSM-GEI/NCHPAD CIFT, or NSCA-CSCS). Indique la ruta seleccionada y la credencial profesional objetivo.
- Prerequisite & Scope Audit: Detail the degree requirements, accreditation standards (e.g., CAAHEP), clinical/internship hours, and legally allowed client populations governing your target credential. Detalle los requisitos académicos, horas de internado clínico y poblaciones permitidas que la credencial autoriza atender legalmente.
- Scope Violation Case Scenario: Describe a real-world scenario where a practitioner in your chosen track exceeds their legal scope of practice (e.g., an uncertified trainer prescribing medical diets or training uncleared cardiac patients). Explain why this creates civil liability. Describa un escenario donde un profesional excede su alcance legal de práctica en su área y explique por qué esto genera responsabilidad civil.

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Verify their credential prerequisites and suggest a local internship or clinical site in Yuma County (e.g., Matador Clinical Partners [MCP], Yuma County Public Health, or AWC Athletics) that offers relevant hands-on hours.

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Verifique los prerrequisitos de su credencial y sugiera un centro de pasantías local en el condado de Yuma.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Target Credential: ACSM Certified Clinical Exercise Physiologist (ACSM-CEP). Credencial Objetivo: Fisiólogo del Ejercicio Clínico Certificado por ACSM (ACSM-CEP).
- Prerequisite & Scope Audit: Candidates must hold a Bachelor of Science in Exercise Science or Kinesiology from a CAAHEP-accredited program, hold current BLS/ACLS certification, and document 1,200 hours of clinical internship experience (or 500 hours if graduating directly from a CAAHEP-accredited curriculum). The CEP scope includes diagnostic stress testing, telemetry ECG interpretation, and outpatient Phase II/III exercise prescription for clients diagnosed with cardiovascular, pulmonary, or metabolic disease under physician collaboration. Los candidatos deben poseer una Licenciatura en Ciencias del Ejercicio de un programa acreditado por CAAHEP, certificación BLS/ACLS y acreditar 1,200 horas de internado clínico. El alcance incluye pruebas de esfuerzo, telemetría y rehabilitación de Fase II/III en enfermedades crónicas.
- Scope Violation Scenario: An entry-level commercial CPT accepts a client who is 6 weeks post-CABG surgery without physician clearance and attempts to conduct a maximal treadmill test while prescribing specialized meal plans for the client's end-stage renal disease. This severe scope violation creates extreme civil liability, risks acute myocardial ischemia or electrolyte collapse, and violates national certification ethical codes. Un CPT comercial principiante atiende a un paciente a 6 semanas de un bypass cardíaco sin alta médica e intenta realizar una prueba de esfuerzo máxima mientras prescribe dietas para insuficiencia renal. Esta violación genera responsabilidad civil grave y peligro de isquemia miocárdica.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 04 (Mod 04 Discussion: Choosing Your Exercise Science Career Path)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Foro de Discusión 04: Rutas Profesionales y Credenciales

Navegar por las credenciales en las ciencias del movimiento requiere un conocimiento claro de los alcances legales de la práctica. Seleccione una ruta profesional y audite certificaciones, requisitos académicos y límites de práctica con el Preceptor de IA Gemini.

- Apertura del Foro: Martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 10 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 13 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 14 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta y Credencial Objetivo: Indique su ruta seleccionada (Ruta 1 Clínica, Ruta 2 Comunitaria o Ruta 3 Deportiva) y la credencial que desea obtener.
- Auditoría de Prerrequisitos y Alcance: Detalle los requisitos de titulación, horas de internado clínico y poblaciones autorizadas para atender legalmente.
- Escenario de Violación de Alcance: Describa un caso real donde un profesional excede su alcance legal y explique la responsabilidad civil generada.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:
