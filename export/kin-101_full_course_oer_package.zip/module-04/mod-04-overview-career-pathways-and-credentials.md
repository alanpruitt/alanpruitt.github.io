# KIN-101: Mod 04 Overview Career Pathways And Credentials

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology


## Mod 04 Overview: Career Pathways & Credentials


### Welcome to Module 04: Career Pathways & Credentials

Welcome to Week 4! This week, we transition from exercise physiology fundamentals to professional career architecture and legal scope-of-practice boundaries across the movement sciences. Using our academic Single Source of Truth (SSoT)—the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —alongside national credentialing boards (ACSM, NSCA, NASM, and CAAHEP), we audit the professional credentials required to prescribe exercise safely and legally across diverse populations.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify scope-of-practice boundary patterns, apply federal and accreditation rules (differentiating Certified Personal Trainers from Clinical Exercise Physiologists and Physical Therapists), and map your academic transfer pathway from Arizona Western College to university completion and clinical internship placement.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 8, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 10, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 13, 2026, at 11:59 PM MST
- Lab 04 Direct Submission / Entrega de Laboratorio: Monday, September 14, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 04 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Differentiate the legal scopes of practice, educational prerequisites, and supervisory roles across Certified Personal Trainers (CPT), Certified Strength and Conditioning Specialists (CSCS), and Clinical Exercise Physiologists (CEP). Diferenciar los alcances de la práctica legal, requisitos académicos y roles de supervisión entre CPT, CSCS y Fisiólogos del Ejercicio Clínico (CEP).
- CLO 2 (Rule Application): Audit ethical and legal scope-of-practice boundaries, identifying violations in clinical, post-rehabilitation, and athletic populations based on PAGA 2018 and professional accreditation guidelines. Auditar los límites éticos y legales del alcance de la práctica, identificando infracciones en poblaciones clínicas y deportivas según PAGA 2018 y normas de acreditación.
- CLO 3 (Problem Solving): Construct a personalized 4-year academic degree map from Arizona Western College to university transfer (NAU-Yuma / UArizona) that incorporates credential examination milestones and clinical internship hours. Diseñar un plan de estudios de 4 años desde AWC hacia la transferencia universitaria que integre exámenes de certificación e internados clínicos.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit career credentials and professional scopes through your selected track:

Auditing clinical exercise physiology (ACSM-CEP), Physical Therapy (DPT), and Occupational Therapy (OT) pathways, clinical shadowing prerequisites, and hospital credentialing.

Mapping health promotion specialist, wellness director, and community fitness leadership credentials to advance physical activity equity across Yuma County.

Evaluating NSCA-CSCS certification requirements, collegiate strength coaching pathways, tactical performance standards, and athletic liability governance.


### Module 04 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Professional Credentials, Scopes of Practice & Transfer Mapping
- Discussion Board 04: Career Pathway Alignment & Ethical Scope Auditing
- Lab Assignment 04: Academic Degree Roadmap & Gemini AI Tool Box
- Module 04 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 04 (Mod 04 Overview: Career Pathways & Credentials)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Módulo 04 Visión General: Rutas Profesionales y Credenciales


### Bienvenido al Módulo 04: Credenciales Profesionales, Planificación Académica y Alcances de la Práctica

¡Bienvenido a la Semana 4! Esta semana pasaremos de los fundamentos fisiológicos a la arquitectura profesional y los límites legales del alcance de la práctica en las ciencias del movimiento. Utilizando nuestra Fuente Única de Verdad (SSoT)—las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) —y los estándares de los organismos de certificación (ACSM, NSCA, NASM, CAAHEP), auditaremos los requisitos necesarios para prescribir ejercicio de forma segura y ética.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará límites profesionales, aplicará reglas de acreditación (diferenciando entrenadores personales de fisiólogos clínicos y fisioterapeutas) y diseñará su ruta de transferencia académica desde Arizona Western College hacia la graduación universitaria.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 10 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 13 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 04: Lunes, 14 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Diferenciar los alcances de la práctica legal, requisitos académicos y funciones entre CPT, CSCS y Fisiólogos del Ejercicio Clínico (CEP).
- CLO 2 (Regla): Auditar los límites éticos y legales de la práctica, identificando infracciones en poblaciones clínicas y atléticas según PAGA 2018.
- CLO 3 (Solución): Diseñar un plan de estudios de 4 años desde AWC hacia la transferencia universitaria (NAU-Yuma / UArizona) que integre certificaciones e internados.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará credenciales y alcances legales a través de su ruta profesional:

Auditoría de rutas en fisiología clínica (ACSM-CEP), Fisioterapia (DPT) y Terapia Ocupacional (OT), requisitos de internado y acreditación hospitalaria.

Planificación de credenciales en promoción de la salud y liderazgo comunitario para impulsar la equidad en la actividad física en el condado de Yuma.

Evaluación de requisitos de certificación NSCA-CSCS, entrenamiento de fuerza universitario, rendimiento táctico y responsabilidad legal deportiva.


### Ruta de Aprendizaje del Módulo 04

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Credenciales Profesionales, Alcances de la Práctica y Transferencia
- Foro de Discusión 04: Alineación de Rutas Profesionales y Auditoría Ética
- Laboratorio 04: Mapa de Grado Académico y Consulta de IA
- Comprobación de Conocimientos y Resumen del Módulo 04

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar un acceso equitativo, inclusivo y sin barreras en nuestra comunidad estudiantil.


### Module 04 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 04 Required Readings: Career Pathways & Credentials →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 04 Discussion: Choosing Your Exercise Science Career Path →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 04 Coaching Sprint: Certifications & Scope of Practice →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 04 Lab: Professional Career & Certification Plan →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 04 Summary & Wrap-Up: Career Pathways & Credentials →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
