# KIN-101: Mod 04 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 04 Lab & Simulation: Professional Career & Certification Plan

Módulo 04 Laboratorio: Plan de Carrera Profesional, Credenciales NCCA y Alcance de la Práctica

- Kinesiology Scope of Practice (Fitness Coaching vs. Medical Care): Exercise professionals design PAGA-aligned movement and habit programs, but never diagnose medical disease, prescribe medications, or override physician restrictions. En palabras sencillas: Como entrenadores diseñamos planes de movimiento seguro, pero nunca diagnosticamos enfermedades ni cambiamos recetas médicas.
- Preparticipation Health Screening (PAR-Q+ & Red-Flag Symptoms): Identifying chest pain, unexplained dizziness, or uncontrolled cardiometabolic conditions that require medical clearance before vigorous exercise. En palabras sencillas: Revisar señales de alerta como mareo, dolor de pecho o presión descontrolada para saber cuándo pedir autorización médica primero.
- Interprofessional Allied Health Referral: Coordinating client transitions between Certified Personal Trainers (CPT), Physical Therapists (PT), Registered Dietitians (RD), and primary care physicians. En palabras sencillas: Trabajar en equipo con fisioterapeutas, nutriólogos y médicos cuando el cliente necesita atención clínica especializada.
- KIN-101.2.1.AY26-27: Differentiate academic degrees, NCCA-accredited certifications (ACSM, NSCA, NASM, ACE), and state-licensed clinical professions (PT, PTA, AT, RD).
- KIN-101.4.1.AY26-27: Enforce legal Scope of Practice boundaries and referral gates when applying PAGA 2018 guidelines in Yuma County.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-04

Future Physical Therapist (DPT) / Physical Therapist Assistant (PTA) or Clinical Exercise Physiologist (ACSM-CEP) serving Yuma Regional Medical Center.

Future Certified K–12 Physical Educator (AZ Department of Education) or Public Health Wellness Coordinator (CHES / ACSM-EP) in Yuma County.

Future Collegiate Strength & Conditioning Coach (NSCA-CSCS) or NCCA-Accredited Personal Trainer (ACSM-CPT / NSCA-CPT) in Yuma, AZ.


### Phase 2: Gemini AI Clinical Simulation Workspace


### Phase 3: Canvas Text Box Submission Requirements

- Part 1: Pattern Recognition: Diagnose the historical/cultural trend or credentialing/scope scenario for your selected track.
- Part 2: Rule Application (PAGA 2018 & NCCA SSoT): Cite the exact federal PAGA 2018 or NCCA Scope of Practice rules that govern this scenario.
- Part 3: Solve & Bilingual Card (EN / ES): Provide your structured action plan and a 2-sentence bilingual card in English and Spanish.
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify how your professional judgment protects client safety in Yuma County.
- Repository Verification: Confirm archive to EXW_Professional_AI_Repository / EXW_101_M04_Career_Certification_Plan.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track: Track 1: Clinical & Allied Health Path (Future PTA / ACSM-CEP in Yuma, AZ)

- Part 1: Pattern Recognition: A client arriving for a general fitness session reports acute radiating lower-back pain and numbness down the left leg (radiculopathy). While a weekend non-accredited trainer might attempt manual spine manipulation or prescribe heavy deadlifts, doing so without clinical licensure violates state law and risks permanent neurological injury.
- Part 2: Rule Application: Under NCCA-accredited Scope of Practice standards (ACSM / NSCA) and PAGA 2018 safety guidelines , exercise professionals may screen for risk, coach preventative physical activity (150–300 min/week aerobic + 2 days strength), and modify non-painful movement, but they must never diagnose medical pathology, treat acute neurological pain, or prescribe clinical medical nutrition therapy . Immediate referral to a licensed Physician (MD/DO) or Physical Therapist (DPT) is mandatory.
- Part 3: Solve & Bilingual Card: 4-Step AWC-to-Career Blueprint: (1) Complete Associate of Arts in Exercise & Wellness at Arizona Western College; (2) Earn NCCA-accredited ACSM-CPT while completing clinical observation hours in Yuma; (3) Transfer to complete B.S. in Kinesiology / PTA licensure; (4) Sit for the NPTE/ACSM-CEP exam. Bilingual Scope Card (EN / ES): EN: "For your safety, radiating nerve pain requires evaluation by a licensed physician or physical therapist before we resume structured exercise." / ES: "Por su seguridad, el dolor nervioso radiante requiere evaluación de un médico o fisioterapeuta con licencia antes de retomar el ejercicio estructurado."
- Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, legal Scope of Practice is the ethical backbone of Kinesiology. When an unverified AI chatbot is asked how to fix radiating leg numbness, it frequently outputs a list of sciatic nerve stretches and back extensions without warning the user of acute lumbar disc herniation red flags. If an exercise professional applies that raw AI output without enforcing the clinical referral gate, they expose the client to cauda equina or motor nerve damage and face severe legal liability. By pausing the workout, documenting the neurological symptom pattern, and referring the client to a licensed Yuma physical therapist or physician, we uphold NCCA standards and protect client safety. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."
- Repository Verification: Archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M04_Career_Certification_Plan.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 04 (Mod 04 Lab: Professional Career & Certification Plan)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 04 Laboratorio y Simulación: Plan de Carrera Profesional, Credenciales NCCA y Alcance de la Práctica

- Parte 1 (Patrón): Diagnostique la tendencia o el escenario de alcance profesional de su ruta.
- Parte 2 (Regla SSoT): Cite las reglas exactas de PAGA 2018 o del Alcance de la Práctica NCCA.
- Parte 3 (Solución y Tarjeta Bilingüe): Presente su plan estructurado y tarjeta bilingüe (EN / ES).
- Parte 4 (La Verificación Activa Obligatoria (Parte 3 • Mínimo 150 Palabras)): Justifique en su propia voz clínica cómo su criterio protege al cliente en el condado de Yuma.
- Verificación del Repositorio: Confirme el archivo en EXW_Professional_AI_Repository / EXW_101_M04_Career_Certification_Plan.pdf .

### Modelo de Verificación Activa 10/10 (Español)

"En mi criterio clínico, el Alcance Legal de la Práctica es la base ética de la Kinesiología. Cuando se le pregunta a una IA sin auditar cómo aliviar el entumecimiento radiante en la pierna, suele generar estiramientos del nervio ciático sin advertir sobre una posible hernia discal aguda. Si un entrenador aplica esa respuesta sin referir al paciente a un médico o fisioterapeuta licenciado (PT/MD) en Yuma, pone en riesgo la integridad neurológica del cliente e incurre en negligencia legal. Detener la sesión y canalizar oportunamente demuestra verdadero profesionalismo."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:
