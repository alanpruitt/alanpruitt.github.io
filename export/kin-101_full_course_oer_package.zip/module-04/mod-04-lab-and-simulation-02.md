# KIN-101: Mod 04 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology / Conceptos de Kinesiología


## Mod 04 Coaching Sprint Simulation: Certifications & Scope of Practice

Sesión de Coaching del Módulo 04: Carreras Profesionales, Credenciales y Alcances de la Práctica

- Kinesiology Scope of Practice (Fitness Coaching vs. Medical Care): Exercise professionals design PAGA-aligned movement and habit programs, but never diagnose medical disease, prescribe medications, or override physician restrictions. En palabras sencillas: Como entrenadores diseñamos planes de movimiento seguro, pero nunca diagnosticamos enfermedades ni cambiamos recetas médicas.
- Preparticipation Health Screening (PAR-Q+ & Red-Flag Symptoms): Identifying chest pain, unexplained dizziness, or uncontrolled cardiometabolic conditions that require medical clearance before vigorous exercise. En palabras sencillas: Revisar señales de alerta como mareo, dolor de pecho o presión descontrolada para saber cuándo pedir autorización médica primero.
- Interprofessional Allied Health Referral: Coordinating client transitions between Certified Personal Trainers (CPT), Physical Therapists (PT), Registered Dietitians (RD), and primary care physicians. En palabras sencillas: Trabajar en equipo con fisioterapeutas, nutriólogos y médicos cuando el cliente necesita atención clínica especializada.
- KIN-101.4.1.AY26-27: Evaluate professional career trajectories and specialization tracks within kinesiology, exercise science, and allied health. Evaluar trayectorias profesionales y especializaciones dentro de la kinesiología y la salud aliada.
- KIN-101.4.2.AY26-27: Identify accredited national certification bodies (e.g., ACSM, NSCA, NASM) and educational prerequisites for industry credentials. Identificar organismos de certificación nacional acreditados y requisitos educativos para credenciales de la industria.

### Your Weekly Win: Mapping Your Professional Blueprint

Where can a degree in kinesiology take you? From clinical rehabilitation and strength coaching to community wellness and physical therapy, the options are vast! Navigating your career requires understanding industry-standard NCCA-accredited certifications and academic transfer milestones. Choose your coaching track below, chat with your AI Socratic Coach, and map out your professional future!

¿A dónde puede llevarle un título en kinesiología? Desde la rehabilitación clínica y el acondicionamiento de fuerza hasta la salud comunitaria y la terapia física, ¡las opciones son amplias! Elija su ruta, dialogue con su Coach de IA y trace su plan profesional.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés vocacional

Scenario: Community college student (Elena, 20) aspiring to become a Doctor of Physical Therapy (DPT) wondering about undergraduate coursework and clinical observation hours.


```text
###
[TRACK]: Track 1 - Clinical & Physical Therapy Path
[CLIENT]: Pre-PT Student (Elena, 20) | [LOCATION]: Yuma, AZ
[SITUATION]: Planning a transition from Arizona Western College to a university DPT program. Overwhelmed by prerequisite science courses and required clinical observation hours.
[COACHING GOAL]: Map out the educational trajectory and prerequisite milestones required for competitive entry into clinical graduate programs.
###
```

Scenario: Kinesiology student (Marcus, 21) looking to lead youth wellness programs and wondering which certifications carry weight in public school and community settings.


```text
###
[TRACK]: Track 2 - Community & Youth Coaching Path
[CLIENT]: Community Wellness Aspirant (Marcus, 21) | [LOCATION]: Yuma County, AZ
[SITUATION]: Wants to work in local community youth programs but is confused about whether to pursue general coaching certificates or specialized youth fitness credentials.
[COACHING GOAL]: Identify community-focused credentialing bodies and practical networking strategies for regional public health and youth sports roles.
###
```

Scenario: Student entrepreneur (Sarah, 22) planning to open a private training studio who needs to choose between major NCCA-accredited personal training certifications (ACSM, NSCA, NASM).


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Coaching Path
[CLIENT]: Future Strength Coach & Entrepreneur (Sarah, 22) | [LOCATION]: Yuma, AZ
[SITUATION]: Preparing to enter the commercial fitness industry and debating which NCCA-accredited credential (such as ACSM-CPT or NSCA-CSCS) best aligns with her business goals.
[COACHING GOAL]: Compare major NCCA-accredited national certifications and outline the professional standards required for elite coaching practice.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-101 Career & Credentialing Tool Box ###:
Role: Supportive KIN-101 Kinesiology Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) & Professional Credentialing Scopes (ACSM, NSCA, NASM).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms the landscape of kinesiology career tracks and major NCCA-accredited credentialing bodies (such as ACSM, NSCA, NASM) relevant to the client's goals.
Step 3: Guide the student to outline ONE actionable next step or educational milestone the client should pursue right now.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how intentional credentialing unlocks professional opportunity.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected career track and client's professional goal or dilemma.
- Career Pathway & Credentials Analysis: Explain the relevant industry pathways and NCCA-accredited certifications associated with your chosen track.
- My Actionable Next Step: Provide 1 clear, strategic educational or professional milestone for your client.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why holding an NCCA-accredited credential (ACSM, NSCA, NASM, ACE) and respecting legal Scope of Practice referral boundaries protects clients in Yuma County.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 04 Coaching Sprint • Track 3 (Strength / Sarah)

- Chosen Track & Client: Track 3: Adult Fitness & Strength Coaching (Sarah, 22). Dilemma: Sarah is preparing to open a private training studio and needs to select the right NCCA-accredited certification to establish instant professional credibility and client trust.
- Track 3: Adult Fitness & Strength Coaching (Sarah, 22).
- Dilemma: Sarah is preparing to open a private training studio and needs to select the right NCCA-accredited certification to establish instant professional credibility and client trust.
- Career Pathway & Credentials Analysis: Industry Pathway: Commercial fitness and private strength coaching entrepreneurship. Credential Options: Comparing ACSM-CPT, NASM-CPT, and NSCA-CSCS. For advanced athletic strength, the NSCA-CSCS is the gold standard; for general adult coaching and health club management, ACSM or NASM provide robust foundational standards.
- Industry Pathway: Commercial fitness and private strength coaching entrepreneurship.
- Credential Options: Comparing ACSM-CPT, NASM-CPT, and NSCA-CSCS. For advanced athletic strength, the NSCA-CSCS is the gold standard; for general adult coaching and health club management, ACSM or NASM provide robust foundational standards.
- My Actionable Next Step for Sarah: "Register for an NCCA-accredited prep course, schedule her CPR/AED certification, and map out her 90-day exam study timeline before launching her studio."
- "Register for an NCCA-accredited prep course, schedule her CPR/AED certification, and map out her 90-day exam study timeline before launching her studio."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, earning an NCCA-accredited certification like the NSCA-CPT or ACSM-CPT is not just a resume credential—it is a public safety safeguard. Unregulated online weekend certificates and generic AI workout bots routinely cross legal Scope of Practice boundaries by attempting to diagnose joint pain or prescribe restrictive clinical diets. For Sarah opening a training studio in Yuma, NCCA accreditation proves competency in pre-participation risk screening, PAGA 2018 exercise progression, and emergency referral protocols. When a client presents with acute orthopedic pain or metabolic red flags, knowing exactly when to pause training and refer to a licensed Physical Therapist or Registered Dietitian protects client health and builds lasting community trust."
- My Memorable Coaching Takeaway: EN: "An accredited certification isn't just a piece of paper—it's your professional passport to trust and authority!" ES: "¡Una certificación acreditada no es solo un papel; es su pasaporte profesional hacia la confianza y la autoridad!"
- EN: "An accredited certification isn't just a piece of paper—it's your professional passport to trust and authority!"
- ES: "¡Una certificación acreditada no es solo un papel; es su pasaporte profesional hacia la confianza y la autoridad!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M04_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 04 (Mod 04 Coaching Sprint: Certifications & Scope of Practice)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Módulo 04 Simulación de Coaching: Carreras Profesionales y Credenciales

Evaluación Rápida y Planificación de Trayectorias en Kinesiología


### Su Logro Semanal: Mapeando Su Futuro Profesional

Esta sesión le permitirá conocer las diferentes trayectorias profesionales en kinesiología, desde la rehabilitación clínica hasta el entrenamiento de fuerza y la salud comunitaria. Aprenda a identificar certificaciones acreditadas por la NCCA. ¡Elija su caso, dialogue con su Coach de IA y trace su ruta profesional!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-101 Carreras y Credenciales ###:
Rol: Coach de Kinesiologia de KIN-101 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) y Alcances Profesionales (ACSM, NSCA, NASM).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla el panorama de carreras en kinesiologia y los principales organismos de certificacion acreditados por la NCCA relevantes para las metas del cliente.
Step 3: Guiar al estudiante para delinear UN siguiente paso u hito educativo que el cliente deba realizar ahora mismo.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la certificacion intencional abre oportunidades profesionales.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta profesional y el objetivo o dilema de su cliente.
- Análisis de Carrera y Credenciales: Explique las trayectorias de la industria y certificaciones acreditadas por la NCCA para la ruta elegida.
- Mi Siguiente Paso Accionable: Describa 1 hito educativo o profesional claro para su cliente.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué contar con una certificación acreditada por la NCCA y respetar los límites legales del Alcance de la Práctica protege a los clientes en el condado de Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, obtener una certificación acreditada por la NCCA como NSCA-CPT o ACSM-CPT es una garantía de seguridad pública. Los certificados rápidos sin acreditación y los bots genéricos de IA suelen invadir el Alcance Legal de la Práctica intentando diagnosticar lesiones o recetar dietas clínicas. Para Sarah en Yuma, la acreditación NCCA respalda el filtro previo de seguridad, la aplicación de PAGA 2018 y la referencia oportuna a un fisioterapeuta (PT) o nutriólogo registrado (RD) cuando surgen señales de alerta."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:
