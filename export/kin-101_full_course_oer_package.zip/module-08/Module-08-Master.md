## KIN-101: MODULE 08 - MIDTERM EVALUATION & CONTENT SYNTHESIS BOUNDARY

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module serves as a structural content boundary and mid-semester pause within the KIN-101 curriculum fleet. Standard laboratory workflows, simulation inputs, and discussion arrays are temporarily suspended. Instead, students will engage in a comprehensive synthesis review of the five primary sub-disciplinary pillars covered in Modules 02 through 07, while completing the mandatory institutional Midterm Student Course Evaluation. All review parameters track back exclusively to our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo sirve como un límite estructural de contenido y una pausa de mitad de semestre dentro de la flota curricular de KIN-101. Los flujos de trabajo de laboratorio estándar, las entradas de simulación y las matrices de discusión se suspenden temporalmente. En su lugar, los estudiantes participarán en una revisión de síntesis integral de los cinco pilares subdisciplinarios principales cubiertos en los Módulos 02 al 07, al mismo tiempo que completan la Evaluación de Mitad de Semestre de los Estudiantes obligatoria de la institución. Todos los parámetros de revisión se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.18]):** Synthesize core kinesiology concepts across foundational history, sociology, biomechanics, physiology, and motor pathways to evaluate community-level physical activity outcomes.
* **Español (Regional) ([LO 2.18]):** Sintetizar los conceptos centrales de la kinesiología a través de la historia fundamental, la sociología, la biomecánica, la fisiología y las vías motoras para evaluar los resultados de la actividad física a nivel comunitario.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Review, track, and cross-examine intersecting community inactivity patterns and physical limitations analyzed across the first half of the semester.
   * **Patrón (Español):** Revisar, registrar y examinar de forma cruzada los patrones de inactividad comunitaria interconectados y las limitaciones físicas analizadas a lo largo de la primera mitad del semestre.
2. **Rule (English):** Apply overlapping federal PAGA 2018 health metrics to audit multi-system wellness baselines, validating safety parameters across diverse population segments.
   * **Regla (Español):** Aplicar las métricas de salud federales superpuestas de PAGA 2018 para auditar las líneas de base de bienestar de múltiples sistemas, validando los parámetros de seguridad en diversos segmentos de la población.
3. **Solve (English):** Formulate a comprehensive personal mastery synthesis statement that unifies sub-disciplinary kinesiology theories into an actionable, community-facing advocacy blueprint.
   * **Solución (Español):** Formular una declaración de síntesis de maestría personal integral que unifique las teorías subdisciplinarias de la kinesiología en un plan de acción de promoción orientado a la comunidad.

---
## Institutional Midterm Notice / Aviso Institucional de Mitad de Semestre

> ### REQUIRED CHECKPOINT: MIDTERM STUDENT COURSE EVALUATION / COMPROBACIÓN OBLIGATORIA: EVALUACIÓN DE MITAD DE SEMESTRE DE LOS ESTUDIANTES
>
> * **English:** The standard laboratory and discussion structures are closed for this module block. Students are required to log into the Canvas LMS portal, navigate to the Institutional Evaluations tab, and complete the official Midterm Student Course Evaluation. Your anonymous, constructive feedback ensures continuous refinement and operational agility across our kinesiology course architecture.
> * **Español (Regional):** Las estructuras estándar de laboratorio y discusión están cerradas para este bloque de módulos. Se requiere que los estudiantes inicien sesión en el portal de Canvas LMS, naveguen a la pestaña de Evaluaciones Institucionales y completen la Evaluación de Mitad de Semestre de los Estudiantes oficial. Sus comentarios anónimos y constructivos garantizan el perfeccionamiento continuo y la agilidad operativa en nuestra arquitectura de cursos de kinesiología.

---
## Midterm Synthesis Checkpoint / Punto de Verificación de Síntesis de Mitad de Semestre

## English

To satisfy this boundary module block, students will provide a comprehensive synthesis overview within their sandbox environment. Ensure your written responses are fully enclosed within the structural layout delimiters below.

```text
## [PASTE YOUR CORE KINESIOLOGY KNOWLEDGE SYNTHESIS REFLECTION HERE]
###
```

1. **Sub-Disciplinary Integration:** Summarize how historical milestones, sociological access barriers, mechanical parameters, and bioenergetic adaptation lines intersect to dictate physical performance limits.
2. **Federal Metric Audit:** Justify how your current physical activity design philosophy mirrors the long-term epidemiological health outcomes targeted by the federal PAGA guidelines.

## Español (Regional)

Para satisfacer este bloque de módulo de límite, los estudiantes proporcionarán una descripción general de síntesis integral dentro de su entorno sandbox. Asegúrese de que sus respuestas escritas estén completamente cerradas dentro de los delimitadores de diseño estructural a continuación.

```text
## [PEGUE SU REFLEXIÓN DE SÍNTESIS DE CONOCIMIENTOS CENTRALES DE KINESIOLOGÍA AQUÍ]
###
```

1. **Integración Subdisciplinaria:** Resumir cómo se cruzan los hitos históricos, las barreras de acceso sociológicas, los parámetros mecánicos y las líneas de adaptación bioenergética para dictar los límites del rendimiento físico.
2. **Auditoría de Métricas Federales:** Justificar cómo su filosofía actual de diseño de actividad física refleja los resultados de salud epidemiológicos a largo plazo previstos por las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This boundary synthesis checkpoint is evaluated using the strict 10/7/0 institutional scale:
Este punto de verificación de síntesis se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):
  * **English:** Zero-drift integration. Core sub-disciplinary paradigms and public health data lines match PAGA criteria perfectly; all canvas evaluation confirmation parameters are verified, and sandbox text limits remain completely fenced.
  * **Español (Regional):** Integración sin desviaciones. Los paradigmas subdisciplinarios centrales y las líneas de datos de salud pública coinciden perfectamente con los criterios de PAGA; todos los parámetros de confirmación de la evaluación de Canvas están verificados y los límites de texto de sandbox permanecen completamente delimitados.
* **7 (Competent) / (Competente):
  * **English:** Minor refactoring required. Main historical and physiological concepts are integrated appropriately, but minor formatting gaps or delimiter omissions are flagged in the final repository file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los conceptos históricos y fisiológicos principales se integran adecuadamente, pero se identifican pequeñas brechas de formato u omisiones de delimitadores en el archivo final del repositorio.
* **0 (Recalibrate) / (Recalibrar):
  * **English:** Critical omission of core sub-disciplinary links or un-fenced data entries that ignore federal public health frameworks. Complete rewrite required.
  * **Español (Regional):** Omisión crítica de los vínculos subdisciplinarios centrales o entradas de datos sin delimitar que ignoran los marcos federales de salud pública. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Midterm Clinical Audit & Synthesis

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review your midterm synthesis submission and verify your course evaluation confirmation in Canvas before the module closes.

<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>


## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
