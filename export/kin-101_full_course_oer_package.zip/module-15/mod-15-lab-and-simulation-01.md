# KIN-101: Mod 15 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 15 Lab & Simulation: Coaching Portfolio Prep & Career Roadmap Audit

Laboratorio del Módulo 15: Repositorio Final de IA y Simulación Capstone

- Longitudinal Periodization & 10% Volume Progression Rule: Structuring multi-week training phases where weekly aerobic duration or resistance load increases by no more than ~5–10% per week to prevent overuse injury. En palabras sencillas: Subir los minutos o el peso poquito a poco (máximo 5 a 10% por semana) para que tendones y músculos se adapten sin lesionarse.
- Evidence-Based Practice (EBP) & SSoT Citation Standard: Integrating federal PAGA 2018 guidelines, client cultural/environmental realities in Yuma, and human clinical judgment into a defensible coaching portfolio. En palabras sencillas: Unir las reglas oficiales de PAGA 2018 con la realidad diaria de tu cliente en Yuma para respaldar cada decisión de tu portafolio.
- Credentialing & Allied Health Referral Boundaries: Distinguishing the role of an exercise/wellness coach from licensed physical therapy, medical nutrition therapy, and physician clearance gates. En palabras sencillas: Reconocer hasta dónde llega nuestro rol como entrenadores y cuándo canalizar al cliente con el médico, fisioterapeuta o nutriólogo.

### Cumulative Portfolio Audit, Repository Verification, & Professional Roadmaps

In this final laboratory assignment, you will compile and verify your master professional AI repository ( EXW_Professional_AI_Repository ) containing all semester audit logs, lab simulations, and bilingual cue cards. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will synthesize your cumulative professional competencies, verify compliance with federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) standards, and formulate an evidence-based professional development roadmap.

En esta práctica de laboratorio final, compilará y verificará su repositorio maestro de IA profesional, sintetizando sus competencias y formulando una hoja de ruta de desarrollo profesional.

- KIN-101.15.1.AY26-27: Synthesize cumulative kinesiological science, clinical audit portfolios, and professional growth across career-aligned tracks. Sintetizar la ciencia cinesiológica acumulativa, los portafolios de auditoría clínica y el crecimiento profesional.
- KIN-101.15.2.AY26-27: Finalize professional AI repositories and evidence-based career development roadmaps aligned with PAGA 2018 SSoT standards. Finalizar los repositorios de IA profesionales y las hojas de ruta de desarrollo profesional alineadas con PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, November 24, 2026, at 12:00 AM MST Abre el martes, 24 de noviembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Tuesday, December 1, 2026, at 11:59 PM MST (Post-holiday grace period) martes, 1 de diciembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Capstone Lab & Final Portfolio Benchmark Ponderación de evaluación para el laboratorio capstone y portafolio final

### Lab Objectives

Objetivos del Laboratorio

- Compile, organize, and verify master professional AI repositories containing all semester coursework artifacts. Compilar, organizar y verificar repositorios maestros de IA profesionales que contengan todos los artefactos del semestre.
- Evaluate cumulative clinical audit portfolios against federal PAGA 2018 (2nd Ed.) standards and SSoT governance. Evaluar los portafolios de auditoría clínica acumulativa frente a las normas de la PAGA 2018 y la gobernanza SSoT.
- Formulate a comprehensive professional development roadmap and bilingual career synthesis in English and Spanish. Formular una hoja de ruta de desarrollo profesional integral y una síntesis de carrera bilingüe en inglés y español.
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-15

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos del Portafolio Capstone

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Comprehensive clinical audit portfolio synthesis, patient rehabilitation case reviews, and allied health career planning.

Focus: Community wellness campaign portfolio, inclusive PE curriculum design, and public health leadership mapping.

Focus: Elite athletic periodization portfolio, advanced training analytics, and coaching methodology capstone synthesis.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría capstone en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete capstone synthesis directly into the Canvas text box structured under the following headers:

- Selected Track & Reviewer Details: Declare chosen track and baseline portfolio focus.
- Part 1: Pattern Recognition: Synthesize primary kinesiological competencies and professional growth achieved across coursework.
- Part 2: Rule Application: Cite federal PAGA 2018 standards and SSoT governance principles.
- Part 3: Solving the Gap: Detail an evidence-based professional development roadmap and repository maintenance plan with a 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Throughout KIN-101, clinical track coursework successfully synthesized cardiorespiratory conditioning, biomechanical torque optimization, and special population clinical audits into a rigorous, verifiable professional framework.

Part 2: Rule Application (SSoT PAGA 2018 Safety Standards): Grounding every clinical case audit and portfolio artifact in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) ensured absolute clinical rigor and adherence to federal health benchmarks.

Part 3: Solving the Gap (Roadmap Plan & Bilingual Card): Professional Development Roadmap & Repository Maintenance Plan: Key Point — Repository Maintenance: Archiving all AI audit logs, lab simulations, and bilingual cue cards in EXW_Professional_AI_Repository . Key Point — Career Progression: Pursuing advanced clinical certifications in exercise physiology and bilingual health communication.

EN: "Synthesizing federal kinesiological standards and secure AI workflows empowers modern practitioners to deliver safe, evidence-based healthcare."

ES: "Sintetizar normas cinesiológicas federales y flujos de trabajo seguros de IA empodera a los profesionales modernos para brindar atención médica segura y basada en evidencia."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_101_M15_Capstone_Simulation.pdf

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 15 (Mod 15 Lab: Coaching Portfolio Prep & Career Roadmap Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 15 Práctica de Lab y Simulación: Repositorio Final de IA y Simulación Capstone

Auditoría de Portafolio Acumulativo, Verificación de Repositorio y Hojas de Ruta Profesionales


### Auditoría de Portafolio Acumulativo, Verificación de Repositorio y Hojas de Ruta

En esta práctica de laboratorio final, compilará y verificará su repositorio maestro de IA profesional que contiene todos los artefactos del semestre. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , sintetizará sus competencias profesionales acumulativas, verificará el cumplimiento de las normas federales de PAGA 2018 (2.ª edición) y formulará una hoja de ruta de desarrollo profesional.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Síntesis de portafolio de auditoría clínica integral, revisión de casos de rehabilitación y planificación de carrera en salud.

Enfoque: Portafolio de campaña de bienestar comunitario, diseño curricular inclusivo y mapeo de liderazgo en salud pública.

Enfoque: Portafolio de periodización atlética de élite, analítica avanzada de entrenamiento y síntesis metodológica.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría capstone en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada y Detalles del Revisor

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Educación / Ruta 3 Deportiva) e incluya los detalles del enfoque del portafolio.


#### Parte 1: Reconocimiento de Patrones

Sintetice las competencias cinesiológicas principales y el crecimiento profesional alcanzado a lo largo del curso.


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Cite las normas federales de PAGA 2018 y los principios de gobernanza SSoT.


#### Parte 3: Resolución de la Brecha

Detalle una hoja de ruta de desarrollo profesional y un plan de mantenimiento del repositorio, junto con una tarjeta bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: A lo largo de KIN-101, el trabajo de la ruta clínica sintetizó con éxito la rehabilitación cardiorrespiratoria, la optimización del torque biomecánico y las auditorías clínicas de poblaciones especiales en un marco profesional riguroso.

Parte 2: Aplicación de Reglas (PAGA 2018): Fundamentar cada auditoría de caso clínico y artefacto de portafolio en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) garantizó el rigor clínico absoluto.

Parte 3: Resolución de la Brecha: Hoja de ruta de desarrollo profesional: Key Point — Mantenimiento del Repositorio: Archivar todos los registros de auditoría de IA y simulaciones en EXW_Professional_AI_Repository . Key Point — Progresión de Carrera: Cursar certificaciones clínicas avanzadas en fisiología del ejercicio y comunicación bilingüe en salud. Tarjeta Bilingüe: "Sintetizar normas cinesiológicas federales y flujos de trabajo seguros de IA empodera a los profesionales modernos para brindar atención médica segura y basada en evidencia."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M15_Capstone_Simulation.pdf

KIN-101 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
