# KIN-101: Mod 15 Overview Coaching Portfolio Prep And Career Roadmaps

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 15 Overview: Coaching Portfolio Prep & Career Roadmaps

El Porqué del Módulo 15 (Círculo Dorado — Contexto Norteño): “¿Por qué las clínicas y escuelas contratan a quienes saben diagnosticar y resolver problemas reales, y cómo demuestra tu portafolio que estás listo para el campo laboral?”


### Module 15 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 15: Coaching Portfolio Prep & Career Roadmaps

Welcome to Week 15 and our final capstone Module in KIN-101! In this concluding week, we synthesize cumulative learning across kinesiology science, biomechanics, special populations, and professional career roadmaps. Building upon our semester-long investigations, you will finalize your professional AI repository and present a comprehensive clinical audit portfolio.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will audit your cumulative professional growth, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) standards, and establish an ongoing career development plan tailored to your chosen professional track.


### Weekly Schedule & Deadlines (Thanksgiving Holiday Adjusted)

- Module Opens: Tuesday, November 24, 2026, at 12:00 AM MST
- Initial Discussion Post: Tuesday, November 24, 2026, at 11:59 PM MST (Adjusted pre-holiday)
- Peer Replies: Monday, November 30, 2026, at 11:59 PM MST (Extended past Thanksgiving break)
- Capstone Lab & Final Portfolio Due: Tuesday, December 1, 2026, at 11:59 PM MST (Post-holiday grace period)

### Course Learning Objectives

Upon successful completion of Module 15 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Synthesize cumulative kinesiological science, biometric data, and professional growth across career-aligned tracks. Sintetizar la ciencia cinesiológica acumulativa, los datos biométricos y el crecimiento profesional.
- CLO 2 (Rule Application): Evaluate clinical audit portfolios against federal PAGA 2018 (2nd Ed.) standards and data governance protocols. Evaluar los portafolios de auditoría clínica frente a las normas de la PAGA 2018 y los protocolos de gobernanza.
- CLO 3 (Problem Solving): Establish an evidence-based professional development roadmap and finalize your master AI repository. Establecer una hoja de ruta de desarrollo profesional basada en evidencia y finalizar el repositorio de IA.

### 3-Track Clinical Simulation Preview

In this final Module's Discussion and Lab, you will complete your chosen career track capstone:

Comprehensive clinical audit portfolio, patient rehabilitation case syntheses, and allied health career pathway planning.

Community wellness campaign portfolio, inclusive PE curriculum design, and public health leadership mapping.

Elite athletic periodization portfolio, advanced training analytics, and coaching methodology capstone synthesis.


### Module 15 Learning Roadmap

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Capstone Synthesis & Professional Roadmaps
- Discussion Board: Professional Portfolio & Career Roadmap
- Lab Assignment: Final AI Repository & Capstone Simulation
- Knowledge Check & Course Completion Summary
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 15 (Mod 15 Overview: Coaching Portfolio Prep & Career Roadmaps)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 15 Visión General


### Introducción al Módulo 15

¡Bienvenido a la Semana 15 y nuestro módulo capstone final en KIN-101! En esta semana de síntesis, unimos el aprendizaje acumulativo en kinesiología, biomecánica, poblaciones especiales y hojas de ruta profesionales. Finalizará su repositorio de IA y presentará un portafolio de auditoría clínica integral.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , auditará su crecimiento profesional, aplicará las normas federales de PAGA 2018 (2.ª ed.) y establecerá un plan de desarrollo de carrera adaptado a su ruta.


### Objetivos de Aprendizaje del Curso

- CLO 1 (Patrón): Sintetizar la ciencia cinesiológica acumulativa, los datos biométricos y el crecimiento profesional. Synthesize cumulative kinesiological science, biometric data, and professional growth.
- CLO 2 (Regla): Evaluar los portafolios de auditoría frente a los estándares de la PAGA 2018 (2.ª ed.) y protocolos de gobernanza. Evaluate clinical audit portfolios against PAGA 2018 standards and data governance protocols.
- CLO 3 (Solución): Establecer una hoja de ruta de desarrollo profesional basada en evidencia y finalizar el repositorio de IA. Establish an evidence-based professional development roadmap and finalize your master AI repository.

### Ruta de Aprendizaje

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Síntesis Capstone y Hojas de Ruta Profesionales
- Foro de Discusión: Portafolio Profesional y Hoja de Ruta
- Práctica de Laboratorio: Repositorio Final de IA y Simulación Capstone
- Comprobación de Conocimientos y Resumen del Curso

### Module 15 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 15 Required Readings: Coaching Portfolio Prep & Career Roadmaps →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 15 Discussion: Sharing Your Coaching Portfolio & Next Steps →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 15 Lab: Coaching Portfolio Prep & Career Roadmap Audit →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 15 Summary & Wrap-Up: Coaching Portfolio Prep & Career Roadmaps →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
