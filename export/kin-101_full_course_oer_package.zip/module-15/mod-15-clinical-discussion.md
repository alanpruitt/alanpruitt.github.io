# KIN-101: Mod 15 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 15 Discussion: Sharing Your Coaching Portfolio & Next Steps

Foro de Discusión del Módulo 15: Portafolio Profesional y Hoja de Ruta

- Longitudinal Periodization & 10% Volume Progression Rule: Structuring multi-week training phases where weekly aerobic duration or resistance load increases by no more than ~5–10% per week to prevent overuse injury. En palabras sencillas: Subir los minutos o el peso poquito a poco (máximo 5 a 10% por semana) para que tendones y músculos se adapten sin lesionarse.
- Evidence-Based Practice (EBP) & SSoT Citation Standard: Integrating federal PAGA 2018 guidelines, client cultural/environmental realities in Yuma, and human clinical judgment into a defensible coaching portfolio. En palabras sencillas: Unir las reglas oficiales de PAGA 2018 con la realidad diaria de tu cliente en Yuma para respaldar cada decisión de tu portafolio.
- Credentialing & Allied Health Referral Boundaries: Distinguishing the role of an exercise/wellness coach from licensed physical therapy, medical nutrition therapy, and physician clearance gates. En palabras sencillas: Reconocer hasta dónde llega nuestro rol como entrenadores y cuándo canalizar al cliente con el médico, fisioterapeuta o nutriólogo.

### Discussion Overview: Professional Portfolio & Career Roadmap

In this week's Discussion, we synthesize cumulative learning across kinesiology science, wellness informatics, and professional career planning. Operating within your chosen career track, you will review your capstone portfolio audits, evaluate SSoT governance, and present your evidence-based professional development roadmap.

En la discusión de esta semana, sintetizamos el aprendizaje acumulativo en kinesiología, informática del bienestar y planificación de carrera. Trabajando dentro de su ruta elegida, presentará su portafolio capstone y su hoja de ruta profesional.


### Discussion Deadlines (Thanksgiving Holiday Adjusted)

- Initial Discussion Post: Tuesday, November 24, 2026, at 11:59 PM MST (Adjusted pre-holiday)
- Peer Replies: Monday, November 30, 2026, at 11:59 PM MST (Extended past Thanksgiving break)
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Build Your Own Journey • Choose Your Clinical Simulation Track / Elija su Ruta

Select ONE of the three career-aligned tracks below to guide your initial discussion post and AI preceptor consultation:

Comprehensive clinical audit portfolio, patient rehabilitation case syntheses, and allied health career pathway planning. Portafolio de auditoría clínica integral, síntesis de casos y planificación de carrera en salud.

Community wellness campaign portfolio, inclusive PE curriculum design, and public health leadership mapping. Portafolio de campañas de bienestar comunitario, diseño curricular inclusivo y liderazgo en salud pública.

Elite athletic periodization portfolio, advanced training analytics, and coaching methodology capstone synthesis. Portafolio de periodización atlética de élite, analítica avanzada de entrenamiento y síntesis metodológica.


### Phase 2: Gemini AI Clinical Simulation Consultation / Consulta de IA

Paso 2: Copie la plantilla y consulte a Gemini para auditar su síntesis capstone

Paste your chosen Track case data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Initial Post & Clinical Framing Protocol (Pattern / Rule / Solve) / Requisitos de la Publicación Inicial

Your initial discussion post must address the following four structured components:

- Step 1: Pattern Recognition: Synthesize primary kinesiological competencies and professional growth achieved across coursework for your chosen track. Sintetice las competencias cinesiológicas principales y el crecimiento profesional alcanzado.
- Step 2: Rule Application: Cite the federal PAGA 2018 (2nd Ed.) standards and SSoT governance principles governing your portfolio. Cite los estándares federales de la PAGA 2018 (2.ª ed.) y los principios SSoT.
- Step 3: Solution Formulation: Detail an evidence-based professional development roadmap and repository maintenance plan. Detalle una hoja de ruta de desarrollo profesional y un plan de mantenimiento del repositorio.
- Step 4: Bilingual Summary: Include a 1-sentence bilingual takeaway summarizing your capstone synthesis in English and Spanish. Incluya una conclusión bilingüe de una oración que resuma su síntesis capstone.
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Official Student Exemplar / Modelo de Ejemplar Estudiantil

Selected Assessment: KIN-101 Module 15 Discussion • Track 1 (Clinical & Allied Health Path)

- Step 1: Pattern Recognition: Throughout KIN-101, clinical track work synthesized cardiorespiratory rehabilitation, thermodynamic energy balance, and geriatric balance programming into a rigorous auditing framework. Integrating generative artificial intelligence via secure data governance enabled seamless scaling of clinical case analyses.
- Step 2: Rule Application: Grounding every client audit in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) ensured absolute clinical safety, while the Safety Auditor protocol maintained strict prompt data isolation.
- Step 3: Solution Formulation (Roadmap & Maintenance): Repository Maintenance: Archiving all AI audit logs and lab simulations in EXW_Professional_AI_Repository . Career Growth: Pursuing advanced clinical certifications in exercise physiology and bilingual health communication.
- Repository Maintenance: Archiving all AI audit logs and lab simulations in EXW_Professional_AI_Repository .
- Career Growth: Pursuing advanced clinical certifications in exercise physiology and bilingual health communication.
- Step 4: Bilingual Summary / Resumen Bilingüe: EN: "Synthesizing federal kinesiological standards and secure AI workflows empowers modern practitioners to deliver safe, evidence-based healthcare." ES: "Sintetizar normas cinesiológicas federales y flujos de trabajo seguros de IA empodera a los profesionales modernos para brindar atención médica segura y basada en evidencia."

### Safety Auditor Protocol & Peer Response Guidelines / Protocolo del Auditor de Seguridad

When drafting your post or auditing peer responses, you must enclose any simulated portfolio data or AI preceptor notes within triple-hash delimiters to maintain professional data governance standards:


```text
Discussion Peer Audit: Capstone Track 1 ###:
Student Auditor: Clinical Track Peer Review
Review Focus: Evaluating professional synthesis and repository maintenance plans against PAGA 2018 standards.
End Audit ###:
```

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 15 (Mod 15 Discussion: Sharing Your Coaching Portfolio & Next Steps)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Foro de Discusión del Módulo 15


### Descripción General de la Discusión: Portafolio Profesional y Hoja de Ruta

En la discusión de esta semana, sintetizamos el aprendizaje acumulativo en kinesiología, informática del bienestar y planificación de carrera. Trabajando dentro de su ruta elegida, revisará sus portafolios capstone, evaluará la gobernanza SSoT y presentará su hoja de ruta de desarrollo profesional.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , auditará su síntesis profesional, aplicará las normas federales de PAGA 2018 (2.ª ed.) y participará en la revisión por pares utilizando el protocolo del Auditor de Seguridad.


### Requisitos para la Publicación Inicial

- Step 1: Reconocimiento de Patrones: Sintetice las competencias cinesiológicas principales y el crecimiento profesional alcanzado.
- Step 2: Aplicación de Reglas: Cite los estándares federales de la PAGA 2018 (2.ª ed.) y los principios SSoT.
- Step 3: Formulación de Soluciones: Detalle una hoja de ruta de desarrollo profesional y un plan de mantenimiento del repositorio.
- Resumen Bilingüe: Incluya una conclusión bilingüe de una oración que resuma su síntesis capstone en inglés y español.
KIN-101 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
