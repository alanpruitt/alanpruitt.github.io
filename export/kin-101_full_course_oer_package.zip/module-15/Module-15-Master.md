## KIN-101: MODULE 15 - FINAL ASSESSMENT PHASE & COMPREHENSIVE CAPSTONE / FASE DE EVALUACIÓN FINAL Y PROYECTO INTEGRADOR 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

> ### Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (Kinesiology disciplines and foundational physical activity rules).

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This final module marks the summative evaluation boundary for the KIN-101 curriculum fleet. Students will synthesize core sub-disciplinary paradigms across the lifespan to construct a comprehensive, community-level physical activity advocacy blueprint. Standard weekly laboratory and discussion structures are concluded. All engineering lines, population targets, and safety thresholds must align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo final marca el límite de la evaluación sumativa para la flota curricular de KIN-101. Los estudiantes sintetizarán los paradigmas subdisciplinarios centrales a lo largo de la vida para construir un plan integral de promoción de la actividad física a nivel comunitario. Las estructuras estándar de laboratorio semanal y discusión han concluido. Todas las líneas de diseño, objetivos de población y límites de seguridad deben alinearse con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.25]):** Synthesize comprehensive kinesiology theories and public health standards across the lifespan to engineer an evidence-based, community-facing physical activity intervention that addresses systemic inactivity barriers.
* **Español (Regional) ([LO 2.25]):** Sintetizar teorías integrales de kinesiología y estándares de salud pública a lo largo de la vida para diseñar una intervención de actividad física orientada a la comunidad basada en la evidencia que aborde las barreras sistémicas de inactividad.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Synthesize and audit multidimensional population inactivity patterns, integrating historical, mechanical, and physiological data barriers across all age cohorts.
   * **Patrón (Español):** Sintetizar y auditar patrones multidimensionales de inactividad poblacional, integrando barreras de datos históricos, mecánicos y fisiológicos en todas las cohortes de edad.
2. **Rule (English):** Apply overlapping federal PAGA 2018 dosage, safety, and multi-sector rules to validate the compliance guidelines of a macro-level community program.
   * **Regla (Español):** Aplicar las reglas superpuestas de dosificación, seguridad y multisectoriales de PAGA 2018 para validar las pautas de cumplimiento de un programa comunitario a nivel macro.
3. **Solve (English):** Formulate an exhaustive, population-level physical activity intervention proposal designed to clear socioeconomic access gaps and optimize long-term health outcomes.
   * **Solución (Español):** Formular una propuesta de intervención de actividad física exhaustiva a nivel de población diseñada para eliminar las brechas de acceso socioeconómico y optimizar los resultados de salud a largo plazo.

---

## Comprehensive Capstone Submission Checkpoint / Punto de Entrega del Proyecto Integrador Final

## English

To fulfill the final assessment requirement, students will deliver their comprehensive capstone proposal within the designated portal. Ensure your complete written project components remain fully enclosed within the required layout delimiters below.

::: {.callout-note}
## Worked Example: Step-by-Step Guidance / Ejemplo Práctico Paso a Paso
**Context & Application:** When completing this lab assignment, follow this structured three-step approach based on our Single Sources of Truth (PAGA 2018 / ACSM 12th Ed.):

1. **Step 1 (Identify Pattern):** Review the client or case profile parameters for baseline activity, physiological constraints, or nutritional markers.
2. **Step 2 (Apply Rule):** Cross-reference the specific federal guidelines, volume targets, or physiological formulas required for the assessment.
3. **Step 3 (Solve):** Formulate your final recommendation or calculation clearly within the submission template below.
:::

```text
## [PASTE YOUR COMPREHENSIVE CAPSTONE PROPOSAL HERE]
###
```

1. **Theoretical Unification:** Document how your proposed intervention synthesizes biomechanical safety limits and behavioral adaptation tracks to ensure movement longevity.
2. **Federal Alignment Audit:** Provide explicit data tracking justifications confirming that your project components satisfy the baseline multi-sector directives of the federal PAGA framework.

## Español (Regional)

Para cumplir con el requisito de evaluación final, los estudiantes entregarán su propuesta de proyecto integrador dentro del portal designado. Asegúrese de que los componentes escritos completos del proyecto permanezcan completamente cerrados dentro de los delimitadores de diseño a continuación.

```text
## [PEGUE SU PROPUESTA DE PROYECTO INTEGRADOR FINAL AQUÍ]
###
```

1. **Unificación Teórica:** Documentar cómo la intervención propuesta sintetiza los límites de seguridad biomecánicos y las vías de adaptación conductual para garantizar la longevidad del movimiento.
2. **Auditoría de Alineación Federal:** Proporcionar justificaciones explícitas de seguimiento de datos que confirmen que los componentes de su proyecto cumplen con las directivas multisectoriales del marco federal de PAGA.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría
This final summative capstone assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación final sumativa se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):**
  * **English:** Zero-drift integration. The capstone unifies all sub-disciplinary tracks perfectly; intervention models match federal PAGA safety indices exactly, and all workspace entries remain fully fenced.
  * **Español (Regional):** Integración sin desviaciones. El proyecto unifica perfectamente todas las vías subdisciplinarias; los modelos de intervención coinciden exactamente con los índices de seguridad de PAGA y todas las entradas permanecen delimitadas.
* **7 (Competent) / (Competente):**
  * **English:** Minor refactoring required. Main public health frameworks and Clinical Framing Protocol stages are correctly integrated, but minor citation gaps or text formatting errors are flagged in the final file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los principales marcos de salud pública y las etapas del Protocolo de Encuadre Clínico están correctamente integrados, pero se identifican pequeñas brechas de citas o errores de formato de texto.
* **0 (Recalibrate) / (Recalibrar):**
  * **English:** Critical omissions in core safety metrics or un-fenced data sheets that ignore baseline federal guidelines or compromise community wellness vectors. Complete rewrite required.
  * **Español (Regional):** Omisiones críticas en las métricas de seguridad central o páginas de datos sin delimitar que ignoran las pautas federales de referencia o comprometen los vectores de bienestar comunitario. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.


<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
