# KIN-101: Mod 10 Overview Body Composition And Energy Balance

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 10 Overview: Body Composition & Energy Balance


### Welcome to Module 10: Body Composition & Energy Balance

Welcome to Week 10! This week, we examine the physiological mechanisms of body composition assessment and energy balance. We explore the laws of thermodynamics governing energy intake versus expenditure, basal metabolic rate (BMR), total daily energy expenditure (TDEE), and body composition assessment methods such as DXA, skinfolds, and bioelectrical impedance.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will audit energy balance patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) weight management standards, and design individualized body composition protocols tailored to your career track.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 20, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 22, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 25, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 26, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 10 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze body composition assessment techniques, energy balance equations, and metabolic rate factors across diverse populations. Analizar las técnicas de evaluación de la composición corporal y las ecuaciones de balance energético.
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) weight management standards and thermodynamic principles to structure progressive lifestyle interventions. Aplicar las normas de control de peso de la PAGA 2018 y los principios termodinámicos.
- CLO 3 (Problem Solving): Formulate an evidence-based body composition and energy balance plan tailored to clinical, educational, or athletic coaching tracks. Formular un plan de composición corporal y balance energético basado en evidencia adaptado a diferentes rutas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Clinical obesity management, DXA body fat distribution analysis, and metabolic syndrome risk reduction protocols.

School-based body composition screening, youth metabolic health education, and community weight management initiatives.

Weight-class optimization for combat sports, lean mass preservation during caloric deficits, and body fat percentage tracking.


### Module 10 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Body Composition Assessment & Energy Balance
- Discussion Board: Energy Balance vs. Weight Management Outcomes
- Lab Assignment: Body Composition Audit & Gemini AI Simulation
- Knowledge Check & Module Summary

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 10 (Mod 10 Overview: Body Composition & Energy Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 10 Visión General: Composición Corporal


### Bienvenido al Módulo 10: Composición Corporal, Balance Energético y Principios Termodinámicos

¡Bienvenido a la Semana 10! Esta semana examinaremos los mecanismos fisiológicos de la evaluación de la composición corporal y el balance energético. Exploraremos las leyes de la termodinámica que rigen la ingesta frente al gasto de energía, la tasa metabólica basal (TMB), el gasto energético diario total (TDEE) y los métodos de evaluación como DXA, pliegues cutáneos e impedancia bioeléctrica.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , auditarás los patrones de balance energético, aplicarás las normas federales de PAGA 2018 (2.ª ed.) y diseñarás protocolos de composición corporal adaptados a tu ruta profesional.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar las técnicas de evaluación de la composición corporal, las ecuaciones de balance energético y los factores de la tasa metabólica en diversas poblaciones. Analyze body composition assessment techniques and energy balance equations.
- CLO 2 (Regla): Aplicar las normas de control de peso de la PAGA 2018 y los principios termodinámicos para estructurar intervenciones de estilo de vida progresivas. Apply PAGA 2018 weight management standards and thermodynamic principles.
- CLO 3 (Solución): Formular un plan de composición corporal y balance energético basado en evidencia adaptado a rutas clínicas, educativas o deportivas. Formulate an evidence-based body composition plan tailored to coaching tracks.

### Ruta de Aprendizaje del Módulo 10

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Evaluación de la Composición Corporal y Balance Energético
- Foro de Discusión: Balance Energético vs. Resultados de Control de Peso
- Práctica de Laboratorio: Auditoría de Composición Corporal y Simulación con IA
- Comprobación de Conocimientos y Resumen del Módulo
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.


### Module 10 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 10 Required Readings: Body Composition & Energy Balance →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 10 Discussion: Healthy Body Composition & Energy Balance →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 10 Coaching Sprint: Practical Habits for Energy Balance →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 10 Lab: Body Composition & Healthy Weight Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 10 Summary & Wrap-Up: Body Composition & Energy Balance →
