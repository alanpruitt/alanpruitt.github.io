# KIN-101: Mod 10 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 10 Discussion: Healthy Body Composition & Energy Balance

Foro de Discusión del Módulo 10: Balance Energético vs. Resultados de Control de Peso


### Discussion Overview: Thermodynamic Principles & Body Composition Auditing

In this week's discussion, we explore the laws of thermodynamics governing energy balance, basal metabolic rate, and body composition assessment. Operating within your chosen career track, you will examine how caloric intake versus expenditure and fat-free mass preservation influence long-term metabolic health and weight management.

En la discusión de esta semana, exploramos las leyes de la termodinámica que rigen el balance energético, la tasa metabólica basal y la evaluación de la composición corporal. Trabajando dentro de su ruta profesional elegida, examinará cómo la ingesta frente al gasto calórico influyen en la salud metabólica.


### Build Your Own Journey • Choose Your Clinical Simulation Track / Elija su Ruta Profesional

Select ONE of the three career-aligned tracks below to guide your initial discussion post and AI preceptor consultation:

Clinical obesity management, DXA body fat distribution analysis, and metabolic syndrome risk reduction protocols. Manejo clínico de la obesidad, análisis de distribución de grasa corporal por DXA y protocolos de reducción de riesgo metabólico.

School-based body composition screening, youth metabolic health education, and community weight management initiatives. Evaluación de composición corporal escolar, educación sobre salud metabólica juvenil e iniciativas comunitarias.

Weight-class optimization for combat sports, lean mass preservation during caloric deficits, and body fat percentage tracking. Optimización de categoría de peso para deportes de combate, preservación de masa magra y seguimiento de grasa corporal.


### Phase 2: Gemini AI Clinical Simulation Consultation / Consulta de IA

Paso 2: Copie la plantilla y consulte a Gemini para auditar su balance energético

Paste your chosen Track case data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Initial Post Prompt & Clinical Framing Protocol Requirements / Requisitos de la Publicación Inicial

Your initial discussion post must address the following four structured components:

- Step 1: Pattern Recognition: Identify the thermodynamic, metabolic, or body composition limitation within your chosen track case profile. Identifique la limitación termodinámica, metabólica o de composición corporal en su perfil de ruta.
- Step 2: Rule Application: Cite the specific weight management and physical activity benchmarks outlined in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) . Cite los estándares específicos de control de peso de la PAGA 2018 (2.ª ed.) .
- Step 3: Solution Formulation: Propose an evidence-based energy balance and lean mass preservation strategy tailored to your track's client. Proponga una estrategia de balance energético y preservación de masa magra adaptada al cliente de su ruta.
- Step 4: Bilingual Summary: Include a 1-sentence bilingual takeaway summarizing your body composition strategy in English and Spanish. Incluya una conclusión bilingüe de una oración que resuma su estrategia de composición corporal.

### Official Student Exemplar / Modelo de Ejemplar Estudiantil

Selected Track: Track 1 (Clinical & Allied Health Path) • Participant J.M. (Age 42)

- Step 1: Pattern Recognition: Participant J.M. exhibits metabolic syndrome risk factors and experienced severe lean mass depletion during prior unguided caloric restriction due to adaptive thermogenesis.
- Step 2: Rule Application: Under PAGA 2018 (2nd Ed.) guidelines, sustainable weight loss maintenance requires >300 minutes of weekly moderate-to-vigorous physical activity paired with muscle-strengthening exercises on 2 or more days per week to preserve Fat-Free Mass.
- Step 3: Solution Formulation (Energy Balance Strategy): Energy Deficit: Moderate 500 kcal/day deficit to prevent extreme metabolic down-regulation. Resistance Training: 3 days per week of progressive compound movements to provide the mechanical stimulus necessary to protect Fat-Free Mass. Aerobic Activity: 250 minutes per week of moderate-intensity activity to support total daily energy expenditure.
- Energy Deficit: Moderate 500 kcal/day deficit to prevent extreme metabolic down-regulation.
- Resistance Training: 3 days per week of progressive compound movements to provide the mechanical stimulus necessary to protect Fat-Free Mass.
- Aerobic Activity: 250 minutes per week of moderate-intensity activity to support total daily energy expenditure.
- Step 4: Bilingual Summary / Resumen Bilingüe: EN: "Preserving fat-free mass through resistance training during a moderate caloric deficit prevents adaptive thermogenesis and ensures sustainable weight loss." ES: "Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible."

### Safety Auditor Protocol & Peer Response Guidelines / Protocolo del Auditor de Seguridad

When drafting your post or auditing peer responses, you must enclose any simulated client profile data or AI preceptor notes within triple-hash delimiters to maintain professional data governance standards:


```text
Discussion Peer Audit: Body Composition Track 1 ###:
Student Auditor: Clinical Track Peer Review
Review Focus: Evaluating TDEE calculations and lean mass preservation protocols against PAGA 2018 standards.
End Audit ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 10 (Mod 10 Discussion: Healthy Body Composition & Energy Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Foro de Discusión del Módulo 10: Balance Energético vs. Resultados de Control de Peso


### Descripción General de la Discusión: Principios Termodinámicos y Composición Corporal

En la discusión de esta semana, exploramos las leyes de la termodinámica que rigen el balance energético, la tasa metabólica basal y la evaluación de la composición corporal. Trabajando dentro de su ruta profesional elegida, examinará cómo la ingesta frente al gasto calórico y la preservación de la masa libre de grasa influyen en la salud metabólica a largo plazo.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , auditará un escenario de balance energético, aplicará las normas federales de PAGA 2018 (2.ª ed.) y participará en la revisión por pares utilizando el protocolo del Auditor de Seguridad.


### Requisitos para la Publicación Inicial

- Step 1: Reconocimiento de Patrones: Identifique la limitación termodinámica, metabólica o de composición corporal descrita en su perfil de ruta.
- Step 2: Aplicación de Reglas: Cite los estándares específicos de control de peso de la PAGA 2018 (2.ª ed.) .
- Step 3: Formulación de Soluciones: Proponga una estrategia de balance energético y preservación de masa magra adaptada al cliente de su ruta.
- Step 4: Resumen Bilingüe: Incluya una frase bilingüe que resuma su estrategia de composición corporal en inglés y español.
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:
