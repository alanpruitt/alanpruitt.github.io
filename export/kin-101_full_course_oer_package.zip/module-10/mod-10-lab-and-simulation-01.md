# KIN-101: Mod 10 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Coaching Sprint Simulation: Practical Habits for Energy Balance

Sesión de Coaching del Módulo 10: Composición Corporal y Balance Energético

- Total Daily Energy Expenditure (TDEE) & PAGA Weight-Maintenance Volume: Total 24-hour calorie burn (Resting Metabolic Rate + Physical Activity + Thermic Effect of Food); PAGA 2018 notes that weight stability and fat loss often require 250–300+ minutes/week of moderate aerobic activity. En palabras sencillas: Toda la energía que tu cuerpo gasta al día; para cuidar el peso de forma saludable en Yuma sin dietas extremas, apuntamos a 250–300+ minutos semanales de movimiento moderado.
- Waist-to-Hip Ratio (WHR) & Visceral Adiposity (vs. BMI Alone): Body Mass Index (BMI = kg/m²) cannot distinguish lean muscle from fat; waist circumference (>40 in men / >35 in women) and WHR track deep visceral fat around vital organs. En palabras sencillas: El IMC por sí solo puede confundir músculo con grasa; medir la cintura nos muestra si hay grasa profunda alrededor de los órganos que sube el riesgo cardíaco y metabólico.
- Fat-Free Mass (FFM) Preservation (Resistance Training ≥2 Days/Week): Caloric restriction without resistance training strips away lean muscle and depresses resting metabolism; PAGA 2018 mandates ≥2 days/week of muscle-strengthening across all major muscle groups to preserve FFM. En palabras sencillas: Bajar de peso sin entrenar fuerza te quita músculo y frena el metabolismo; por eso incluimos mínimo 2 días por semana de fuerza para proteger el músculo.
- KIN-101.10.1.AY26-27: Apply PAGA 2018 weight management guidelines and thermodynamic principles to analyze energy balance and fat-free mass preservation. Aplicar las pautas de control de peso de la PAGA 2018 y los principios termodinámicos para analizar el balance energético y la preservación de la masa libre de grasa.
- KIN-101.10.2.AY26-27: Audit body composition assessment methods and energy expenditure calculations across physical education, clinical rehabilitation, and sports coaching contexts. Auditar los métodos de evaluación de la composición corporal y los cálculos de gasto energético en contextos educativos, clínicos y deportivos.

### Your Weekly Win: Mastering Energy Balance & Lean Mass Preservation

How does understanding thermodynamic principles empower physical educators, therapists, and coaches to guide healthy weight management? Examining basal metabolic rate, total daily energy expenditure, and fat-free mass preservation allows practitioners to combat adaptive thermogenesis and design sustainable lifestyle interventions. Following federal PAGA 2018 weight management guidelines, exercise leaders can structure evidence-based body composition protocols tailored to diverse populations. Choose your coaching track below, chat with your AI Socratic Coach, and master energy balance analysis!

¿Cómo ayuda la comprensión de los principios termodinámicos a educadores, terapeutas y entrenadores a guiar un control de peso saludable? Examinar la tasa metabólica basal y la preservación de masa magra permite combatir la termogénesis adaptativa. ¡Elija su ruta y dialogue con su coach de IA!


### The Clinical Framing Protocol (Pattern / Rule / Solve | Patrón / Regla / Solución)

Pattern / Patrón: Identify client energy expenditure baselines, body composition markers, or lean mass trends.

Rule / Regla: Apply PAGA 2018 energy balance baselines and safe caloric deficit boundaries preserving fat-free mass.

Solve / Solución: Formulate evidence-based physical activity and resistance training prescriptions that sustain metabolic health.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Scenario: Clinical obesity participant (J.M., 42) exhibiting metabolic syndrome markers and accelerated lean mass loss during prior unguided caloric restriction.

Scenario: Middle school health cohort (Grade 8, Age 13) experiencing rising adolescent adiposity trends and widespread misconceptions regarding fad diets.

Scenario: Collegiate wrestler (T.K., 19) engaging in severe pre-competition rapid weight cutting resulting in strength losses and dehydration.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission / Fase 3: Entrega en Canvas (Solo Texto)

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's body composition challenge.
- Thermodynamic & Energy Balance Analysis: Explain BMR, TDEE, energy flux, and PAGA 2018 weight management standards for your client.
- Part 3: Active Verification & Energy Balance Strategy: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your energy balance strategy and resistance training overload protect fat-free mass and prevent adaptive thermogenesis under PAGA 2018 standards.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 10 Coaching Sprint • Track 1 (Clinical / J.M.)

- Chosen Track & Client: Track 1: Clinical & Allied Health Path (J.M., 42). Challenge: J.M. exhibits metabolic syndrome markers and experienced severe lean mass depletion during prior unguided caloric restriction due to adaptive thermogenesis.
- Track 1: Clinical & Allied Health Path (J.M., 42).
- Challenge: J.M. exhibits metabolic syndrome markers and experienced severe lean mass depletion during prior unguided caloric restriction due to adaptive thermogenesis.
- Thermodynamic & Energy Balance Analysis: PAGA 2018 Weight Management Standards & Thermodynamics: Sustainable weight loss maintenance requires high energy flux (>300 minutes weekly of moderate-to-vigorous physical activity) combined with concurrent resistance training to protect Fat-Free Mass against metabolic down-regulation. Preserving lean tissue maintains Basal Metabolic Rate and prevents the rebound effect.
- PAGA 2018 Weight Management Standards & Thermodynamics: Sustainable weight loss maintenance requires high energy flux (>300 minutes weekly of moderate-to-vigorous physical activity) combined with concurrent resistance training to protect Fat-Free Mass against metabolic down-regulation.
- Preserving lean tissue maintains Basal Metabolic Rate and prevents the rebound effect.
- Part 3: Active Verification & Energy Balance Strategy: "Implement a moderate 500 kcal/day caloric deficit paired with 3 days/week of progressive resistance training and 250 minutes of weekly aerobic activity to protect Fat-Free Mass." Active Verification: In my clinical reasoning, J.M.'s history of severe rebound weight gain is rooted in aggressive, unguided calorie restriction that stripped his lean muscle tissue and precipitated adaptive thermogenesis. Merely prescribing another deficit without protecting fat-free mass would repeat this physiological failure. By prioritizing progressive resistance training 3 days weekly and maintaining high energy flux with 250 minutes of weekly activity, we sustain his basal metabolic rate, preserve muscle protein synthesis, and create a sustainable, protective metabolic environment aligned with PAGA 2018 guidelines.
- "Implement a moderate 500 kcal/day caloric deficit paired with 3 days/week of progressive resistance training and 250 minutes of weekly aerobic activity to protect Fat-Free Mass."
- Active Verification: In my clinical reasoning, J.M.'s history of severe rebound weight gain is rooted in aggressive, unguided calorie restriction that stripped his lean muscle tissue and precipitated adaptive thermogenesis. Merely prescribing another deficit without protecting fat-free mass would repeat this physiological failure. By prioritizing progressive resistance training 3 days weekly and maintaining high energy flux with 250 minutes of weekly activity, we sustain his basal metabolic rate, preserve muscle protein synthesis, and create a sustainable, protective metabolic environment aligned with PAGA 2018 guidelines.
- Part 4: My Memorable Coaching Takeaway: EN: "Preserving fat-free mass through resistance training during a moderate caloric deficit prevents adaptive thermogenesis and ensures sustainable weight loss!" ES: "¡Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible!"
- EN: "Preserving fat-free mass through resistance training during a moderate caloric deficit prevents adaptive thermogenesis and ensures sustainable weight loss!"
- ES: "¡Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M10_Quiz_Sprint.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 10 (Mod 10 Coaching Sprint: Practical Habits for Energy Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 10 Simulación de Coaching: Composición Corporal y Balance Energético

Evaluación Rápida y Auditoría Termodinámica


### Su Logro Semanal: Dominando el Balance Energético y la Preservación de Masa Magra

Esta sesión le permitirá aplicar los principios termodinámicos y las pautas de control de peso de PAGA 2018 para analizar la tasa metabólica basal, el TDEE y estructurar estrategias de composición corporal. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Participante de obesidad clínica (J.M., 42 años) con marcadores de síndrome metabólico y pérdida acelerada de masa magra previa.

Escenario: Cohorte de salud de secundaria (Grado 8, 13 años) con tendencias crecientes de adiposidad y conceptos erróneos sobre dietas de moda.

Escenario: Luchador universitario (T.K., 19 años) con cortes de peso rápidos previos a competencias que causan pérdida de fuerza y deshidratación.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de composición corporal de su cliente.
- Análisis Termodinámico y de Balance Energético: Explique la TMB, el TDEE, el flujo energético y las normas de control de peso de PAGA 2018 para su cliente.
- Parte 3: Verificación Activa y Estrategia de Balance: En una defensa obligatoria (aprox. mínimo 150 palabras (150+ palabras)) con su propia voz clínica, justifique por qué su estrategia de balance energético y sobrecarga de resistencia protegen la masa libre de grasa y previenen la termogénesis adaptativa según PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 10 Sesión de Coaching • Ruta 1 (Clínica / J.M.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Profesiones de la Salud (J.M., 42 años). Reto: J.M. exhibe marcadores de síndrome metabólico y experimentó una severa depleción de masa magra durante restricciones calóricas previas debido a la termogénesis adaptativa.
- Ruta 1: Clínica y Profesiones de la Salud (J.M., 42 años).
- Reto: J.M. exhibe marcadores de síndrome metabólico y experimentó una severa depleción de masa magra durante restricciones calóricas previas debido a la termogénesis adaptativa.
- Análisis Termodinámico y de Balance Energético: Normas de Control de Peso de PAGA 2018 y Termodinámica: El mantenimiento de la pérdida de peso sostenible requiere un alto flujo energético (>300 minutos semanales de actividad moderada a vigorosa) combinado con entrenamiento de resistencia concurrente para proteger la masa libre de grasa frente a la regulación metabólica a la baja. Preservar el tejido magro mantiene la tasa metabólica basal y previene el efecto rebote.
- Normas de Control de Peso de PAGA 2018 y Termodinámica: El mantenimiento de la pérdida de peso sostenible requiere un alto flujo energético (>300 minutos semanales de actividad moderada a vigorosa) combinado con entrenamiento de resistencia concurrente para proteger la masa libre de grasa frente a la regulación metabólica a la baja.
- Preservar el tejido magro mantiene la tasa metabólica basal y previene el efecto rebote.
- Parte 3: Verificación Activa y Estrategia de Balance: "Implementar un déficit calórico moderado de 500 kcal/día combinado con 3 días/semana de entrenamiento de resistencia progresiva y 250 minutos de actividad aeróbica semanal para proteger la masa libre de grasa." Verificación Activa: En mi juicio clínico, el historial de efecto rebote de J.M. se debe a restricciones calóricas agresivas que consumieron su tejido muscular y activaron la termogénesis adaptativa. Prescribir otro déficit sin proteger la masa libre de grasa repetiría este fracaso fisiológico. Al priorizar el entrenamiento de resistencia progresivo 3 días por semana y un alto flujo energético con 250 minutos semanales de actividad aeróbica, sostenemos su tasa metabólica basal, preservamos la síntesis proteica muscular y creamos un entorno metabólico sostenible y protector según las directrices de la PAGA 2018.
- "Implementar un déficit calórico moderado de 500 kcal/día combinado con 3 días/semana de entrenamiento de resistencia progresiva y 250 minutos de actividad aeróbica semanal para proteger la masa libre de grasa."
- Verificación Activa: En mi juicio clínico, el historial de efecto rebote de J.M. se debe a restricciones calóricas agresivas que consumieron su tejido muscular y activaron la termogénesis adaptativa. Prescribir otro déficit sin proteger la masa libre de grasa repetiría este fracaso fisiológico. Al priorizar el entrenamiento de resistencia progresivo 3 días por semana y un alto flujo energético con 250 minutos semanales de actividad aeróbica, sostenemos su tasa metabólica basal, preservamos la síntesis proteica muscular y creamos un entorno metabólico sostenible y protector según las directrices de la PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Preserving fat-free mass through resistance training during a moderate caloric deficit prevents adaptive thermogenesis and ensures sustainable weight loss!" ES: "¡Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible!"
- EN: "Preserving fat-free mass through resistance training during a moderate caloric deficit prevents adaptive thermogenesis and ensures sustainable weight loss!"
- ES: "¡Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M10_Quiz_Sprint.pdf
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:
