# KIN-101: Mod 10 Required Readings Body Composition And Energy Balance

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 10 Required Readings: Body Composition & Energy Balance

Composición Corporal, Balance Energético y Principios Termodinámicos


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Body composition is what your body weight is made of: muscle, bone, and fat. The scale shows your total weight, but not what is inside. Muscle uses energy even while you rest, so strength training protects your health over time.


#### En Palabras Sencillas (Norteño Context)

Piensa en tu cuerpo como una casa: la báscula dice cuánto pesa, pero no si es de ladrillo o de cartón. El músculo es el ladrillo. Si los términos técnicos se ponen pesados, concéntrate primero en cuidar tu músculo.

This week's advanced literature explores the precise physiological mechanisms governing body composition assessment and energy balance. By deeply examining the First Law of Thermodynamics as it applies to human energy flux, we uncover how Total Daily Energy Expenditure (TDEE) and the preservation of Fat-Free Mass (FFM) directly dictate metabolic health and longevity.

Anchored in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , these readings establish that sustainable weight management requires more than caloric restriction; it demands strategic resistance and aerobic programming to combat adaptive thermogenesis and prevent the loss of metabolically active tissue.


### 1. The First Law of Thermodynamics, Energy Flux & TDEE

Body weight regulation is strictly governed by the First Law of Thermodynamics (energy cannot be created or destroyed, only transferred). Total Daily Energy Expenditure (TDEE) is comprised of three distinct physiological components:

- Basal Metabolic Rate (BMR): Representing 60–75% of TDEE, BMR is the energy required to maintain cellular homeostasis at rest. It is highly correlated with Fat-Free Mass (FFM). Severe caloric restriction without resistance training accelerates FFM loss, leading to a metabolic down-regulation known as adaptive thermogenesis .
- Thermic Effect of Food (TEF): Accounting for ~10% of TDEE, TEF is the energy expended digesting, absorbing, and storing nutrients. Protein exerts the highest TEF (20-30% of ingested calories) compared to carbohydrates (5-10%) and fats (0-3%).
- Activity Energy Expenditure (AEE): Comprising 15–30% of TDEE, this includes structured Exercise Activity Thermogenesis (EAT) and Non-Exercise Activity Thermogenesis (NEAT)—the spontaneous daily movements that can vary by up to 2,000 kcal/day between individuals.

### 2. Compartmental Models & Assessment Modalities (DXA, BIA, Anthropometry)

Accurate body composition analysis requires separating total body mass into distinct physiological compartments. The efficacy of an assessment depends heavily on the model utilized:

- Dual-Energy X-ray Absorptiometry (DXA): The clinical gold standard utilizing a 3-compartment model. By passing high and low-energy X-ray beams through the body, DXA distinctly measures Bone Mineral Content (BMC), Fat Mass (FM), and Lean Soft Tissue (LST) based on photon attenuation rates.
- Bioelectrical Impedance Analysis (BIA): A 2-compartment field method measuring tissue resistance to a low-frequency alternating electrical current. It capitalizes on the principle that hydrated, electrolyte-rich skeletal muscle is a strong conductor, while anhydrous adipose tissue is an insulator. Clinical note: BIA is highly sensitive to hydration status and recent exercise.
- Skinfold Anthropometry: Measures subcutaneous adipose tissue thickness at standardized anatomical sites to predict systemic body density using population-specific equations (e.g., Jackson-Pollock). It is highly dependent on operator technical proficiency.

### 3. PAGA 2018 Mandates for Weight Management & Lean Mass Preservation

Federal standards explicitly differentiate between physical activity for general health versus activity required for clinical weight management. The PAGA 2018 (2nd Ed.) establishes critical thresholds:

- Weight Loss Maintenance: While 150 minutes of moderate aerobic activity yields robust cardiovascular benefits, clinically significant weight loss and the long-term maintenance of that loss frequently require >300 minutes per week of moderate-to-vigorous physical activity to sustain a favorable energy flux.
- The Resistance Training Mandate: PAGA strictly requires muscle-strengthening activities on 2 or more days a week . During periods of caloric deficit (negative energy balance), concurrent resistance training provides an essential mechanical stimulus to preserve Fat-Free Mass, mitigating the drop in Basal Metabolic Rate and preventing the "rebound effect" of rapid fat regain.

### Workplace Intelligence & AI Security Protocol ()

In modern health, kinesiology, and wellness informatics, generative artificial intelligence functions as an automated auditing partner. However, relying on unconstrained prompts risks hallucinated calculations, formula errors, and a complete breakdown of professional data integrity. To enforce rigorous institutional and clinical standards, the Safety Auditor Protocol requires you to structure all AI-driven prompt engineering using mandatory triple-hash delimiters ( ### ).

Wrapping variable inputs, equations, and parameters within triple-hashes achieves three critical operational objectives:

- Data Boundary Isolation: It cleanly separates variable calculation parameters from rigid system instructions, preventing prompt injection and instruction drift.
- Strict SSoT Alignment: It forces the AI model to cross-examine mathematical outputs and physiological recommendations directly against federal benchmarks like PAGA 2018 (2nd Ed.) rather than unverified internet forums or commercial fitness fads.
- Reproducible Archiving: It creates standardized, version-controlled text blocks that can be exported instantly to your EXW_Professional_AI_Repository for institutional compliance and portfolio review.
Example of a properly structured, production-grade security wrapper for thermodynamic and metabolic calculations:


```text
SYSTEM DIRECTIVE & SECURITY PROTOCOL ###:
[ROLE]: Expert Kinesiology Preceptor & Clinical Metrologist.
[SSoT COMPLIANCE]: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).
[CALCULATION PARAMETERS]: Mifflin-St Jeor Equation, TDEE Multipliers, 4-Compartment Mass Models.
[DATA INTEGRITY]: All computational inputs must remain strictly isolated within these delimiters.
END PROTOCOL ###:
```


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 10 (Mod 10 Required Readings: Body Composition & Energy Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas en Línea: Composición Corporal y Balance Energético

La literatura avanzada de esta semana explora los mecanismos fisiológicos precisos que rigen la evaluación de la composición corporal y el balance energético. Al examinar a profundidad la Primera Ley de la Termodinámica aplicada al flujo energético humano, descubrimos cómo el Gasto Energético Diario Total (TDEE) y la preservación de la Masa Libre de Grasa (FFM) dictan la salud metabólica.

Fundamentadas en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) , estas lecturas establecen que el control de peso sostenible requiere más que restricción calórica; exige programación aeróbica y de resistencia estratégica para combatir la termogénesis adaptativa y prevenir la pérdida de tejido metabólicamente activo.


### 1. La Primera Ley de la Termodinámica, Flujo Energético y TDEE

- Tasa Metabólica Basal (TMB): Representando el 60–75% del TDEE, es la energía requerida para la homeostasis celular en reposo y está altamente correlacionada con la Masa Libre de Grasa (FFM). La restricción calórica severa sin entrenamiento de resistencia acelera la pérdida de FFM, provocando una regulación metabólica a la baja conocida como termogénesis adaptativa .
- Efecto Térmico de los Alimentos (TEF): Representa ~10% del TDEE por digestión y absorción. La proteína ejerce el mayor TEF (20-30%) frente a carbohidratos y grasas.
- Gasto Energético por Actividad (AEE): Comprende el 15–30% del TDEE e incluye el ejercicio estructurado (EAT) y la termogénesis por actividad sin ejercicio (NEAT), que puede variar hasta 2,000 kcal/día entre individuos.

### 2. Modelos Compartimentales y Modalidades de Evaluación

El análisis preciso requiere separar la masa corporal total en compartimentos fisiológicos distintos:

- Absorciometría Dual de Rayos X (DXA): Estándar de oro clínico de 3 compartimentos. Mide contenido mineral óseo, masa grasa y tejido blando magro basándose en la atenuación de fotones.
- Análisis de Impedancia Bioeléctrica (BIA): Método de campo de 2 compartimentos que mide la resistencia a una corriente eléctrica. Aprovecha que el músculo hidratado es un conductor, mientras que el tejido adiposo es un aislante. Nota: BIA es muy sensible a la hidratación.
- Antropometría de Pliegues Cutáneos: Mide el tejido adiposo subcutáneo para predecir la densidad corporal mediante ecuaciones. Depende en gran medida de la habilidad técnica del operador.

### 3. Control de Peso y Alineación con PAGA 2018

- Mantenimiento de la Pérdida de Peso: Mientras que 150 minutos logran beneficios de salud, la pérdida de peso clínicamente significativa y su mantenimiento a largo plazo frecuentemente requieren >300 minutos por semana de actividad física moderada-vigorosa para sostener un flujo energético favorable.
- El Mandato del Entrenamiento de Resistencia: La PAGA exige actividades de fortalecimiento muscular 2 o más días por semana . Durante un déficit calórico, esto proporciona un estímulo mecánico esencial para preservar la Masa Libre de Grasa, previniendo la caída de la TMB y el "efecto rebote".
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 10 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 10:
