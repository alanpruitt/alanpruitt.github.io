# KIN-101: Mod 05 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología


## Mod 05 Coaching Sprint Simulation: Building Muscle Strength Safely

Sesión de Coaching del Módulo 05: Fuerza Muscular y Fisiología

- Agonist vs. Antagonist Muscle Balance: Pairing prime movers (e.g., quadriceps/pectorals) with opposing stabilizers (hamstrings/upper-back) to maintain healthy joint centration. En palabras sencillas: Entrenar parejo los músculos que empujan y los que jalan para que las articulaciones trabajen alineadas y sin dolor.
- Foundational Movement Pillars (Push, Pull, Hinge, Squat): Multi-joint compound patterns that train all major muscle groups ≥2 days/week as required by PAGA 2018 Chapter 4. En palabras sencillas: Los cuatro movimientos base del cuerpo humano—empujar, jalar, bisagra de cadera y sentadilla—para cumplir los 2 días semanales de fuerza.
- Progressive Overload & 48-Hour Muscle Recovery Window: Gradually increasing resistance or repetitions over time while allowing ~48 hours between heavy sessions for the same muscle group to repair. En palabras sencillas: Subir el reto poco a poco dejando descansar unas 48 horas el mismo grupo muscular para que se recupere más fuerte.
- KIN-101.5.1.AY26-27: Analyze skeletal muscle structure, sliding filament theory, and fiber-type adaptations under resistance training loads. Analizar la estructura del músculo esquelético, la teoría de filamentos deslizantes y las adaptaciones de tipos de fibra.
- KIN-101.5.2.AY26-27: Apply physiological principles of muscular hypertrophy, strength, and endurance to safe coaching practices. Aplicar principios fisiológicos de hipertrofia muscular, fuerza y resistencia a prácticas de entrenamiento seguras.

### Your Weekly Win: How Muscles Build Power

Ever wonder how lifting heavy weights actually transforms muscle tissue at a cellular level? Through microscopic sarcomere contractions (sliding filaments) and progressive overload, human tissue adapts to become stronger, denser, and more resilient! Choose your coaching track below, chat with your AI Socratic Coach, and master how to explain muscle physiology to everyday clients.

¿Se ha preguntado cómo el levantamiento de pesas transforma el tejido muscular a nivel celular? A través de contracciones del sarcómero y sobrecarga progresiva, el tejido se adapta para ser más fuerte. ¡Elija su ruta y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés vocacional

Scenario: Older adult (Arthur, 68) experiencing age-related muscle loss (sarcopenia) who is afraid that lifting light dumbbells will injure his joints.


```text
###
[TRACK]: Track 1 - Clinical & Physical Therapy Path
[CLIENT]: Older Adult Sarcopenia Patient (Arthur, 68) | [LOCATION]: Yuma, AZ
[SITUATION]: Experiencing age-related muscle wasting. He wants to rebuild functional strength but fears that resistance exercise will damage his arthritic joints.
[COACHING GOAL]: Explain muscle adaptation and safe resistance loading to help Arthur understand how progressive strength training reverses sarcopenia safely.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Physical Therapy.
###
```

Scenario: High school athlete (Mia, 15) who believes lifting weights will make her "bulky" and slow down her soccer performance.


```text
###
[TRACK]: Track 2 - Community & Youth Coaching Path
[CLIENT]: High School Soccer Player (Mia, 15) | [LOCATION]: Yuma County, AZ
[SITUATION]: Hesitant to join the strength training conditioning program because she thinks heavy lifting causes excessive muscle bulk and ruins speed.
[COACHING GOAL]: Debunk common myths about neuromuscular adaptations, highlighting how strength training improves power output and injury resilience in youth athletes.
[COMMUNITY SITE]: Yuma County Public Health Services District & Parks Recreation Centers.
###
```

Scenario: Fitness beginner (Marcus, 28) who lifts to failure on every single set every day and is experiencing chronic soreness and plateauing.


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Coaching Path
[CLIENT]: Hypertrophy-Focused Lifter (Marcus, 28) | [LOCATION]: Yuma, AZ
[SITUATION]: Trains to absolute failure daily, feels constantly fatigued, and is frustrated by a lack of muscle growth and strength gains.
[COACHING GOAL]: Educate Marcus on muscle protein synthesis, recovery windows, and physiological rest requirements for optimal hypertrophy.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-101 Muscular Strength & Physiology Tool Box ###:
Role: Supportive KIN-101 Kinesiology Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Adult Muscle-Strengthening Guidelines.

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms muscle contraction physiology and how resistance training drives cellular adaptation (hypertrophy or neuromuscular coordination) relevant to the client.
Step 3: Guide the student to give their client ONE physiological tip or corrective strategy to optimize training safety and results.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how muscle tissue adapts intelligently to stress.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's physiological challenge or misconception.
- Muscle Physiology & Adaptation: Explain in simple terms how muscle tissue responds and adapts to resistance loading for your client.
- My Physiological Coaching Tip: Provide 1 clear, scientifically grounded tip to help your client train smarter and safer.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying why progressive overload, Henneman's Size Principle, and multi-joint PAGA 2018 resistance training (at least 2 days/week) protect your Yuma client's joints and muscle strength.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 05 Coaching Sprint • Track 3 (Strength / Marcus)

- Chosen Track & Client: Track 3: Adult Fitness & Strength Coaching (Marcus, 28). Challenge: Marcus trains to absolute muscular failure daily, resulting in chronic fatigue, prolonged soreness, and stunted muscle hypertrophy.
- Track 3: Adult Fitness & Strength Coaching (Marcus, 28).
- Challenge: Marcus trains to absolute muscular failure daily, resulting in chronic fatigue, prolonged soreness, and stunted muscle hypertrophy.
- Muscle Physiology & Adaptation: Protein Synthesis & Recovery: Muscle growth (hypertrophy) does not occur during the workout itself; lifting creates micro-tears and metabolic stress. Real tissue remodeling and protein synthesis happen during post-exercise recovery and sleep. Constant failure without adequate recovery overloads the central nervous system and depletes glycogen stores, stalling gains.
- Protein Synthesis & Recovery: Muscle growth (hypertrophy) does not occur during the workout itself; lifting creates micro-tears and metabolic stress. Real tissue remodeling and protein synthesis happen during post-exercise recovery and sleep.
- Constant failure without adequate recovery overloads the central nervous system and depletes glycogen stores, stalling gains.
- My Physiological Coaching Tip for Marcus: "Leave 1 to 2 reps in reserve (RIR) on your working sets instead of training to total failure every time. Your muscles need recovery capacity to trigger protein synthesis!"
- "Leave 1 to 2 reps in reserve (RIR) on your working sets instead of training to total failure every time. Your muscles need recovery capacity to trigger protein synthesis!"
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified internet workout often pushes older or deconditioned Yuma clients into high-velocity ego lifting or daily single-joint exhaustion without respecting tendon adaptation or recovery. By applying Henneman's Size Principle and PAGA 2018 muscle-strengthening guidelines, we recruit low-threshold Type I motor units first and progressively recruit higher-threshold Type IIa fibers through controlled, multi-joint movements like goblet squats and seated rows twice a week with 48 hours of recovery between sessions. This human-led progression builds functional sarcomere force and protects joint alignment. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- My Memorable Coaching Takeaway: EN: "Resistance training provides the stimulus, but intelligent recovery builds the muscle!" ES: "¡El entrenamiento de resistencia proporciona el estímulo, pero la recuperación inteligente construye el músculo!"
- EN: "Resistance training provides the stimulus, but intelligent recovery builds the muscle!"
- ES: "¡El entrenamiento de resistencia proporciona el estímulo, pero la recuperación inteligente construye el músculo!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M05_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 05 (Mod 05 Coaching Sprint: Building Muscle Strength Safely)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 05 Simulación de Coaching: Fuerza Muscular y Fisiología

Evaluación Rápida y Aprendizaje Práctico de la Fisiología Muscular


### Su Logro Semanal: Cómo los Músculos Desarrollan Potencia

Esta sesión le permitirá entender cómo las contracciones musculares y la sobrecarga progresiva transforman el tejido celular. Aprenda a explicar la fisiología de la hipertrofia y la recuperación de forma sencilla. ¡Elija su caso, dialogue con su Coach de IA y obtenga una lección memorable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-101 Fuerza Muscular y Fisiologia ###:
Rol: Coach de Kinesiologia de KIN-101 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Fortalecimiento Muscular en Adultos.

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla la fisiologia de la contraccion muscular y como el entrenamiento de resistencia impulsa la adaptacion celular (hipertrofia o coordinacion neuromuscular) para el cliente.
Step 3: Guiar al estudiante para dar a su cliente UN consejo fisiologico o estrategia correctiva para optimizar su seguridad y resultados.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como el tejido muscular se adapta inteligentemente al estres.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío fisiológico o concepto erróneo de su cliente.
- Fisiología Muscular y Adaptación: Explique con sus propias palabras cómo responde el tejido muscular a la carga de resistencia.
- Mi Consejo Fisiológico de Coaching: Escriba 1 sugerencia clara y científica para ayudar a su cliente a entrenar mejor.
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica justificando por qué la sobrecarga progresiva y las pautas de fuerza de PAGA 2018 (mínimo 2 días/semana) protegen las articulaciones de su cliente en Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Ejemplo de La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): "En mi juicio clínico, las rutinas genéricas de internet suelen exigir levantamientos pesados sin descanso, arriesgando lesiones tendinosas. Al aplicar el Principio del Tamaño de Henneman y las pautas PAGA 2018 de fortalecimiento muscular al menos 2 días por semana con 48 horas de recuperación, reclutamos unidades motoras de forma progresiva y segura para fortalecer las articulaciones de nuestro cliente en Yuma."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:
