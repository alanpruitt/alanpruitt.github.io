## KIN-101 MODULE-13: EXERCISE BASICS / Master Content Loop

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## KIN-101: MODULE 13 - FITNESS, WELLNESS, AND EXERCISE PRESCRIPTION BASICS

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module introduces the core components of physical fitness, general wellness design, and the fundamental principles of safe exercise prescription. Students will explore basic cardiorespiratory, resistance, and flexibility training variables to understand how individuals safely adapt to mechanical and physiological workloads. All programming baselines, safety screenings, and adaptation timelines align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo introduce los componentes clave de la aptitud física, el diseño del bienestar general y los principios fundamentales de la prescripción segura de ejercicio. Los estudiantes explorarán variables básicas de entrenamiento cardiorrespiratorio, de fuerza y de flexibilidad para comprender cómo las personas se adaptan de manera segura a las cargas de trabajo mecánicas y fisiológicas. Todos los puntos de referencia de programación, evaluaciones de seguridad y cronogramas de adaptación se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.23]):** Evaluate introductory fitness profiles and apply federal physical activity thresholds to design safe, basic cardiorespiratory and muscular development prescriptions.
* **Español (Regional) ([LO 2.23]):** Evaluar perfiles introductorios de aptitud física y aplicar umbrales federales de actividad física para diseñar prescripciones básicas y seguras de desarrollo muscular y cardiorrespiratorio.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Identify and document client physical limitations, tracking baseline aerobic capacities, strength deficits, or chronic musculoskeletal tightness profiles in sedentary populations.
   * **Patrón (Español):** Identificar y documentar las limitaciones físicas del cliente, rastreando capacidades aeróbicas iniciales, déficits de fuerza o perfiles de tensión musculoesquelética crónica en poblaciones sedentarias.
2. **Rule (English):** Apply the federal exercise dose-response ranges, target frequencies, and safe progression limits detailed in the PAGA 2018 framework to establish loading boundaries.
   * **Regla (Español):** Aplicar los rangos federales de dosis-respuesta de ejercicio, frecuencias objetivo y límites de progresión segura detallados en el marco de PAGA 2018 para establecer los límites de carga.
3. **Solve (English):** Engineer a balanced, entry-level weekly physical fitness layout that optimizes cardiorespiratory volume and muscular strength factors without crossing population injury risks.
   * **Solución (Español):** Diseñar un esquema de aptitud física semanal equilibrado y de nivel inicial que optimice el volumen cardiorrespiratorio y los factores de fuerza muscular sin cruzar los riesgos de lesiones de la población.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Andamiaje

## Part A: Gemini AI Simulation (Fitness Profile Simulation)

## English

Students will initialize the virtual fitness profile auditing workspace. Ensure your simulated client assessment data blocks remain completely wrapped inside the layout delimiters below.

::: {.callout-note}
## Worked Example: Step-by-Step Guidance / Ejemplo Práctico Paso a Paso
**Context & Application:** When completing this lab assignment, follow this structured three-step approach based on our Single Sources of Truth (PAGA 2018 / ACSM 12th Ed.):

1. **Step 1 (Identify Pattern):** Review the client or case profile parameters for baseline activity, physiological constraints, or nutritional markers.
2. **Step 2 (Apply Rule):** Cross-reference the specific federal guidelines, volume targets, or physiological formulas required for the assessment.
3. **Step 3 (Solve):** Formulate your final recommendation or calculation clearly within the submission template below.
:::

```text
## [PASTE SIMULATED CLIENT PHYSICAL FITNESS ASSESSMENT AND RECREATIONAL BACKGROUND DATA HERE]
###
```

1. Use the sandbox environment to audit a simulated personal fitness profile, analyzing target heart rate zones and muscular training capacities.
2. Cross-examine virtual client physical capabilities against the active health baseline brackets highlighted in the adult conditioning chapters of the federal PAGA source documentation.
3. Execute an automated data validation pass within the sandbox to verify that proposed weekly exercise volumes satisfy federal physical wellness thresholds cleanly.

## Español (Regional)

Los estudiantes inicializarán el espacio de trabajo de auditoría de perfiles de aptitud física virtual. Asegúrese de que los bloques de datos de evaluación de clientes simulados permanezcan completamente cerrados dentro de los delimitadores de diseño a continuación.

```text
## [PEGUE LOS DATOS SIMULADOS DE EVALUACIÓN DE APTITUD FÍSICA Y ANTECEDENTES RECREATIVOS DEL CLIENTE AQUÍ]
###
```

1. Utilizar el entorno de pruebas (sandbox) para auditar un conjunto de datos de un perfil de aptitud física personal simulado, analizando las zonas de frecuencia cardíaca objetivo y las capacidades de entrenamiento muscular.
2. Evaluar de forma cruzada las capacidades físicas del cliente virtual frente a los rangos de referencia de salud activa destacados en los capítulos de acondicionamiento de adultos del documento oficial de PAGA.
3. Ejecutar un pase de validación de datos automatizado dentro del sandbox para verificar que los volúmenes de ejercicio semanales propuestos cumplan limpiamente con los umbrales federales de bienestar físico.

## Part B: Practical Field Application (Qualitative Movement Screening)

## English

Students will transition into their immediate spaces to complete a practical, zero-cost qualitative physical conditioning field log with a peer.

1. Complete a visual movement monitoring screening tracking simple functional tasks, recording joint alignment markers and tracking deviations under bodyweight restrictions.
2. Chart real-time exertion responses alongside self-reported mobility markers, documenting physical execution adjustments.
3. Document true conditioning indicators: record raw balance and alignment indicators and cross-examine your field findings against the basic physiological health suggestions in the federal PAGA guidelines.

## Español (Regional)

Los estudiantes harán la transición a sus espacios inmediatos para completar un registro de campo práctico, de costo cero y de carácter cualitativo sobre acondicionamiento físico con un compañero.

1. Completar un registro de evaluación visual del movimiento rastreando tareas funcionales simples, anotando marcadores de alineación articular y desviaciones de seguimiento bajo restricciones de peso corporal.
2. Registrar las respuestas de esfuerzo en tiempo real junto con los marcadores de movilidad autoreportados, documentando los ajustes de ejecución física.
3. Documentar los indicadores de acondicionamiento reales: registrar los indicadores brutos de equilibrio y alineación y evaluar de forma cruzada sus hallazgos de campo con las sugerencias básicas de salud fisiológica en las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This introductory conditioning module assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación del módulo de acondicionamiento introductorio se evalúa utilizando la estricta escala institucional 10/7/0:\n

* **10 (Exemplary) / (Ejemplar):**
  * **English:** Zero-drift integration. All proposed workout progressions and volume equations match PAGA health targets exactly; all simulation log entries remain fully fenced inside layout delimiters.
  * **Español (Regional):** Integración sin desviaciones. Todas las progresiones de entrenamiento y ecuaciones de volumen propuestas coinciden exactamente con los objetivos de salud de PAGA; todos los registros de simulación permanecen completamente delimitados dentro de los delimitadores de diseño.
* **7 (Competent) / (Competente):**
  * **English:** Minor refactoring required. Core Clinical Framing Protocol steps and physical fitness boundaries are appropriately applied, but minor formatting gaps or bilingual structural omissions are flagged in the repository file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los pasos del Protocolo de Encuadre Clínico y los límites de la aptitud física se aplican adecuadamente, pero se identifican pequeñas brechas de formato u omisiones de estructura bilingüe en el archivo del repositorio.
* **0 (Recalibrate) / (Recalibrar):**
  * **English:** Critical error in load safety screening or un-fenced training metrics that violate primary volume constraints or compromise client physical parameters. Complete rewrite required.
  * **Español (Regional):** Error crítico en la evaluación de seguridad de carga o métricas de entrenamiento sin delimitar que violan las restricciones primarias de volumen o comprometen los parámetros físicos del cliente. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.



<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>


## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
