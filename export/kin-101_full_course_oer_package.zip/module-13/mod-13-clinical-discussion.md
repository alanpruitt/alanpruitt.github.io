# KIN-101: Mod 13 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 13 Discussion: Protecting Joints During Heavy Lifting & Work

In Plain English Before you read the details below, here is the short version: Torque is the turning force on a joint. When a load moves farther from the joint, the turning force grows. You will spot this in a real movement and suggest a safer way to do it.

En Palabras Sencillas (Norteño) Es como cargar una cubeta de agua: pegada al cuerpo se siente ligera, con el brazo estirado pesa un montón. Si los términos técnicos se ponen pesados, concéntrate primero en mantener la carga cerca del cuerpo.


### The Mission (Initial Post): Due Thursday @ 11:59 PM

Choose one everyday or job movement from the Yuma area: lifting a produce crate in the fields, loading a truck bed, carrying a child, or a gym lift.

Write 150–200 words using the Clinical Framing Protocol (Pattern / Rule / Solve):

- Pattern: Describe the movement. Where is the load compared with the joint (hip, knee, low back, or shoulder)?
- Rule: Use T = F × d to explain why the joint works harder when the load is farther away. Connect it to the PAGA 2018 safety guidance on gradual progression and good technique.
- Solve: Suggest one change that shortens the moment arm or improves stability (keep the center of mass over the base of support).

### Peer Replies: Due Sunday @ 11:59 PM

Reply to two classmates. In each reply:

- Name one more way to reduce joint load in their movement, or
- Name one tissue (bone, tendon, ligament, muscle) at risk and explain why, using the stress-strain idea from the readings.

### Final Inspection: Closes Monday @ 11:59 PM

Read any replies to your post and answer at least one question.


### Español (Regional)

Publicación inicial (jueves): Elige un movimiento diario o de trabajo en Yuma (cargar una caja en el campo, subir cosas a la troca, cargar a un niño o un levantamiento en el gimnasio). Usa Patrón / Regla / Solución en 150–200 palabras y la fórmula T = F × d . Propón un cambio que acerque la carga al cuerpo. Respuestas (domingo): Responde a dos compañeros con otra forma de reducir la carga o con un tejido en riesgo y por qué.

KIN-101 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 13 (Mod 13 Discussion: Protecting Joints During Heavy Lifting & Work)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
