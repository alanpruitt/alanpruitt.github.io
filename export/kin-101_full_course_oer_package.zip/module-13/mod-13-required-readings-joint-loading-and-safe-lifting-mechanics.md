## KIN-101: Mod 13 Required Readings Joint Loading And Safe Lifting Mechanics

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 13 Required Readings: Joint Loading & Safe Lifting Mechanics

Biomecánica Aplicada y Carga Tisular

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from PAGA 2018 (2nd Ed.)), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 13): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Biomechanics explains how forces push and pull on your body when you move. The farther a weight is from a joint, the harder that joint must work. Good form keeps you balanced and protects your bones, tendons, and muscles from injury.


#### En Palabras Sencillas (Norteño Context)

Piensa en cargar una cubeta de agua: pegada al cuerpo se siente ligera, pero con el brazo estirado pesa un montón. Si los términos técnicos se ponen pesados, concéntrate primero en mantener la carga cerca del cuerpo.

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)

This week's advanced literature explores the precise mechanical principles, force vectors, and tissue loading characteristics governing human movement efficiency. By deeply examining how internal and external forces act upon musculoskeletal structures during physical activity, we uncover how practitioners mitigate orthopedic stress and optimize movement execution across diverse modalities.

Anchored in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , these readings establish that safe exercise programming requires integrating sound biomechanical principles to prevent injury while maximizing cardiorespiratory and neuromuscular adaptations.


### 1. Biomechanical Principles, Force Vectors & Torque Mechanics

Human movement is strictly governed by Newtonian mechanics and internal/external force interactions:

- Force Vectors & Line of Pull: Muscle force operates along a specific vector relative to joint rotation axes. Understanding the line of pull allows practitioners to predict joint torque and movement efficiency.
- Moment Arms & Torque (T = F x d): The rotational force (torque) produced around a joint is determined by the magnitude of the applied force and the perpendicular distance from the axis of rotation. Altering lever arms changes joint loading profiles significantly.
- Center of Mass (COM) & Stability: Maintaining postural equilibrium requires keeping the body's center of mass within its base of support, a critical factor in both dynamic exercise and fall prevention.
Clinical Rule Verified (Use This in Your Lab & Sprint): As a weight drifts forward away from the body's center of mass, the horizontal moment arm lengthens and multiplies shear stress on the lumbar intervertebral discs.

En palabras sencillas (Para tu Laboratorio y Sprint): Entre más se aleja la barra o caja de tu cuerpo al levantarla, más palanca y presión peligrosa recibe la espalda baja.


### 2. Tissue Loading, Stress-Strain Properties & Injury Mitigation

Biological tissues (bone, tendon, ligament, and skeletal muscle) exhibit complex viscoelastic properties under mechanical load:

- Elastic vs. Plastic Region: Under controlled loads, tissues deform elastically and return to resting length. Excessive or repetitive loads push tissue into the plastic region, causing microtrauma and eventual structural failure.
- Wolff's Law & Mechanotransduction: Bone and soft tissue remodel along lines of mechanical stress. Progressive overload stimulates structural reinforcement, while disuse leads to tissue atrophy.
- Shear vs. Compressive Stress: Minimizing excessive joint shear forces during compound movements protects articular cartilage and ligamentous stability.
Clinical Rule Verified (Use This in Your Lab & Sprint): Driving movement through the hips and glutes while keeping a neutral spine braced, preventing disc herniation risk caused by rounding the lower back under load.

En palabras sencillas (Para tu Laboratorio y Sprint): Doblar desde la cadera empujando las pompis hacia atrás con la espalda derechita, en vez de encorvar la cintura al cargar peso.


### 3. PAGA 2018 Safety Standards & Biomechanical Efficiency

Federal standards emphasize that achieving recommended physical activity volumes must be balanced with injury prevention. The PAGA 2018 (2nd Ed.) outlines vital safety mandates:

- Injury Risk Mitigation: Progressing frequency, intensity, and time gradually allows musculoskeletal tissues adequate recovery time to adapt to mechanical stress without incurring overuse injuries.
- Technique & Movement Quality: Ensuring proper biomechanical execution during aerobic and strengthening activities maximizes physiological benefit while safeguarding joint integrity.
Clinical Rule Verified (Use This in Your Lab & Sprint): Stiffening the core 360° while exhaling through the sticking point of a lift, preventing dangerous blood-pressure spikes caused by breath-holding (Valsalva).

En palabras sencillas (Para tu Laboratorio y Sprint): Apretar el abdomen soltando el aire al hacer el esfuerzo, sin aguantar la respiración para que no se dispare la presión arterial.


### Workplace Intelligence & Clinical Informatics Competency

In this Module, you practiced advanced workforce competencies that translate directly to modern clinical, educational, and athletic training environments:

You deployed the Safety Auditor protocol ( ### ) to prevent prompt drift and simulate secure electronic health record (EHR) data partitioning during biomechanical case audits.

You acted as the primary clinical authority, stress-testing AI-generated movement prescriptions against federal PAGA 2018 standards to eliminate unverified fitness myths.

You engineered bilingual coaching cues in English and Norteño Spanish to bridge communication gaps for diverse borderland patient populations.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 13 (Mod 13 Required Readings: Joint Loading & Safe Lifting Mechanics)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas en Línea: Biomecánica Aplicada y Carga Tisular

La literatura avanzada de esta semana explora los principios mecánicos precisos, los vectores de fuerza y las características de carga tisular que rigen la eficiencia del movimiento humano. Al examinar a profundidad cómo las fuerzas internas y externas actúan sobre las estructuras musculoesqueléticas, descubrimos cómo los profesionales mitigan el estrés ortopédico y optimizan la ejecución del movimiento.

Fundamentadas en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) , estas lecturas establecen que la programación de ejercicio seguro requiere integrar principios biomecánicos sólidos para prevenir lesiones.


### 1. Principios Biomecánicos, Vectores de Fuerza y Torque

- Vectores de Fuerza y Línea de Tracción: La fuerza muscular opera a lo largo de un vector específico relativo a los ejes de rotación articular.
- Brazos de Momento y Torque: La fuerza rotacional producida alrededor de una articulación está determinada por la magnitud de la fuerza aplicada y la distancia perpendicular al eje de rotación.
- Centro de Masa y Estabilidad: Mantener el equilibrio postural requiere mantener el centro de masa dentro de la base de soporte.

### 2. Carga Tisular, Propiedades de Estrés-Deformación y Mitigación de Lesiones

Los tejidos biológicos exhiben propiedades viscoelásticas complejas bajo carga mecánica:

- Región Elástica vs. Plástica: Bajo cargas controladas, los tejidos se deforman elásticamente. Cargas excesivas conducen a la región plástica y microtraumatismos.
- Ley de Wolff: El hueso y el tejido blando se remodelan según el estrés mecánico. La sobrecarga progresiva estimula el reforzamiento.
- Estrés de Cizallamiento vs. Compresión: Minimizar las fuerzas de cizallamiento excesivas protege el cartílago articular.

### 3. Normas de Seguridad de la PAGA 2018 y Eficiencia Biomecánica

- Mitigación del Riesgo de Lesiones: Progresar gradualmente la frecuencia, intensidad y tiempo permite a los tejidos musculoesqueléticos un tiempo de recuperación adecuado.
- Calidad de Movimiento: Asegurar una ejecución biomecánica adecuada maximiza el beneficio fisiológico mientras salvaguarda la integridad articular.
KIN-101 • Module 13 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 13:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 13)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 13)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
