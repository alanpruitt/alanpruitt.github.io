# KIN-101: Mod 13 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 13 Lab & Simulation: Joint Load & Safe Lifting Audit

Laboratorio del Módulo 13: Auditoría de Movimiento Biomecánico y Simulación

- Moment Arm & Lumbar Shear vs. Compressive Load: As a weight drifts forward away from the body's center of mass, the horizontal moment arm lengthens and multiplies shear stress on the lumbar intervertebral discs. En palabras sencillas: Entre más se aleja la barra o caja de tu cuerpo al levantarla, más palanca y presión peligrosa recibe la espalda baja.
- Hip Hinge Mechanics vs. Loaded Spinal Flexion: Driving movement through the hips and glutes while keeping a neutral spine braced, preventing disc herniation risk caused by rounding the lower back under load. En palabras sencillas: Doblar desde la cadera empujando las pompis hacia atrás con la espalda derechita, en vez de encorvar la cintura al cargar peso.
- Intra-Abdominal Bracing & Avoiding the Valsalva Maneuver: Stiffening the core 360° while exhaling through the sticking point of a lift, preventing dangerous blood-pressure spikes caused by breath-holding (Valsalva). En palabras sencillas: Apretar el abdomen soltando el aire al hacer el esfuerzo, sin aguantar la respiración para que no se dispare la presión arterial.

### Applied Biomechanics, Torque Optimization, & Tissue Loading

In this laboratory assignment, you will conduct a qualitative biomechanical movement and tissue loading audit and construct an evidence-based movement remediation protocol. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze force vectors, joint torque, and viscoelastic properties, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety standards, and execute an AI-driven simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría cualitativa del movimiento biomecánico y la carga tisular, diseñando un protocolo de remediación basado en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución).

- KIN-101.13.3.AY26-27: Evaluate applied biomechanical patterns, force vectors, and tissue loading characteristics across diverse movement modalities. Evaluar los patrones biomecánicos aplicados, los vectores de fuerza y las características de carga tisular en diversas modalidades.
- KIN-101.13.4.AY26-27: Design movement remediation protocols and bilingual coaching cue cards aligned with PAGA 2018 safety standards. Diseñar protocolos de remediación de movimiento y tarjetas de instrucción bilingües alineadas con las normas de seguridad de PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, November 10, 2026, at 12:00 AM MST Abre el martes, 10 de noviembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, November 16, 2026, at 11:59 PM MST lunes, 16 de noviembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones prácticas

### Lab Objectives

Objetivos del Laboratorio

- Audit the mechanical principles of force vectors, torque production, and viscoelastic tissue loading across human movement. Auditar los principios mecánicos de los vectores de fuerza, la producción de torque y la carga tisular viscoelástica en el movimiento humano.
- Apply federal PAGA 2018 (2nd Ed.) safety standards to structure progressive movement remediation programs that mitigate orthopedic stress. Aplicar las normas de seguridad de la PAGA 2018 para estructurar programas progresivos de remediación que mitiguen el estrés ortopédico.
- Formulate a 4-week movement remediation plan paired with bilingual coaching cue cards in English and Spanish. Formular un plan de remediación de movimiento de 4 semanas con tarjetas de instrucción bilingües en inglés y español.
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-13

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos de Auditoría Biomecánica

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Post-rehabilitation gait mechanics; auditing joint shear forces, patellofemoral stress, and torque optimization protocols.

Focus: Youth posture education; designing ergonomic movement curriculums addressing spinal loading and movement quality.

Focus: Athletic power output optimization; managing force vector leakage and ground reaction force application in sprinters.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete biomechanical audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline functional profile.
- Part 1: Pattern Recognition: Identify specific force vectors, torque imbalances, or tissue loading constraints.
- Part 2: Rule Application: Cite PAGA 2018 safety standards and movement quality principles.
- Part 3: Solving the Gap: Detail a 4-week movement remediation plan (torque optimization and progressive loading) with a 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient K.L. exhibits patellofemoral joint stress and excessive shear forces during open-chain knee extensions, driven by unfavorable moment arms and high quadriceps tension at terminal extension.

Part 2: Rule Application (SSoT PAGA 2018 Safety Standards): Under PAGA 2018 (2nd Ed.) safety guidelines, exercise prescriptions must prioritize joint integrity and tissue loading thresholds by shifting from high shear open-chain movements to closed-chain kinetic exercises that promote compressive joint stability.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): 4-Week Movement Remediation Protocol (Torque Optimization & Progressive Loading): Key Point — Kinetic Chain Adjustment: Replace terminal knee extension open-chain drills with controlled leg presses and mini-squats to distribute joint forces across multiple articulation points. Key Point — Torque Minimization: Adjust resistance profiles to minimize patellofemoral stress peaks between 0 and 45 degrees of flexion. Key Point — Tissue Conditioning: Progressive isometric loading to enhance patellar tendon viscoelasticity.

EN: "Optimizing joint torque mechanics and transitioning to closed-chain kinetic exercises protects articular cartilage and mitigates orthopedic stress."

ES: "Optimizar la mecánica del torque articular y hacer la transición a ejercicios cinéticos de cadena cerrada protege el cartílago articular y mitiga el estrés ortopédico."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_101_M13_Biomechanical_Movement_Audit.pdf

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 13 (Mod 13 Lab: Joint Load & Safe Lifting Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 13 Práctica de Lab y Simulación: Auditoría de Movimiento Biomecánico

Biomecánica Aplicada, Optimización de Torque y Carga Tisular


### Biomecánica Aplicada, Optimización de Torque y Carga Tisular

En esta práctica de laboratorio, realizará una auditoría cualitativa del movimiento biomecánico y la carga tisular, diseñando un protocolo de remediación. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , evaluará vectores de fuerza, torque articular y propiedades viscoelásticas, aplicando normas de seguridad de PAGA 2018 (2.ª edición) .


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Mecánica de la marcha post-rehabilitación; auditoría de fuerzas de cizallamiento y protocolos de optimización de torque.

Enfoque: Educación postural juvenil; diseño de currículos de movimiento ergonómico abordando la carga espinal.

Enfoque: Optimización de potencia atlética; manejo de pérdida de vectores de fuerza y aplicación de fuerza de reacción en velocistas.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Educación / Ruta 3 Deportiva) e incluya las iniciales del cliente.


#### Parte 1: Reconocimiento de Patrones

Identifique vectores de fuerza específicos, desequilibrios de torque o restricciones de carga tisular.


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Cite las normas de seguridad de PAGA 2018 y los principios de calidad de movimiento.


#### Parte 3: Resolución de la Brecha

Detalle un plan de remediación de 4 semanas (optimización de torque y carga progresiva), junto con una tarjeta bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: La paciente K.L. exhibe estrés patelofemoral y fuerzas de cizallamiento excesivas en extensiones de rodilla en cadena abierta, impulsadas por brazos de momento desfavorables y alta tensión en cuádriceps.

Parte 2: Aplicación de Reglas (PAGA 2018): Según las normas de seguridad de PAGA 2018 (2.ª ed.), las prescripciones deben priorizar la integridad articular cambiando de movimientos de cadena abierta de alto cizallamiento a ejercicios en cadena cerrada que promuevan estabilidad compresiva.

Parte 3: Resolución de la Brecha: Protocolo de 4 semanas: reemplazar extensiones en cadena abierta con prensas de pierna controladas y minisentadillas, ajustando los perfiles de resistencia para minimizar picos de estrés. Tarjeta Bilingüe: "Optimizar la mecánica del torque articular y hacer la transición a ejercicios cinéticos de cadena cerrada protege el cartílago articular y mitiga el estrés ortopédico."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M13_Biomechanical_Movement_Audit.pdf

KIN-101 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
