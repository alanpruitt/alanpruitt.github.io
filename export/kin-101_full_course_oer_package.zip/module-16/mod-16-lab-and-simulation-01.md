# KIN-101: Mod 16 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 16 Capstone Simulation: Final Coaching Portfolio & Case Defense

Proyecto Capstone Aplicado Final: Síntesis Comunitaria y Marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Comprehensive FITT-VP Capstone Synthesis: Unifying aerobic volume (150–300 min/wk), muscle-strengthening (≥2 days/wk across Push/Pull/Hinge/Squat), and Yuma thermal safety into a complete client blueprint. En palabras sencillas: Integrar cardio, fuerza de cuerpo completo y seguridad ante el calor de Yuma en un plan final claro y completo.
- Multi-Gate Clinical Safety Audit: Verifying that AI-generated calculations contain zero contraindicated exercises, zero unacclimatized midday heat exposure, and accurate intensity targets. En palabras sencillas: Confirmar que ningún cálculo de la IA ponga en riesgo las articulaciones, el corazón o la hidratación de tu cliente.
- Verbatim Clinical Case Defense (Active Verification): Articulating the physiological and behavioral rationale behind your prescription in your own authentic coaching voice for both English and Spanish-speaking clients. En palabras sencillas: Defender con tus propias palabras por qué tu programa es seguro, realista y efectivo para nuestra comunidad.

### Comprehensive Community Health & Movement Intervention Synthesis

Welcome to the culmination of your KIN-101 coursework. In this capstone project (worth 15% of your final grade, scored out of 30 total points), you will synthesize the historical, sociological, and physiological foundations of human movement covered throughout the semester. Grounded strictly in our single source of truth, Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , you will audit a real-world community inactivity challenge and design a scalable intervention using the Clinical Framing Protocol (Pattern / Rule / Solve) framework.

Bienvenido a la culminación de su curso KIN-101. En este proyecto capstone (15% de su calificación final, evaluado sobre un total de 30 puntos), sintetizará las bases históricas, sociológicas y fisiológicas del movimiento humano utilizando estrictamente la PAGA 2018 (2.ª ed.) .

- KIN-101.Capstone.AY26-27: Synthesize historical, sociological, and physiological principles to evaluate community-level physical inactivity and design evidence-based interventions. Sintetizar principios históricos, sociológicos y fisiológicos para evaluar la inactividad física comunitaria y diseñar intervenciones basadas en evidencia.
- FERPA Compliance & Academic Integrity: Execute secure text-entry submissions with verified local repository archiving, protecting student privacy without external cloud links. Ejecutar entregas seguras de texto en Canvas protegiendo la privacidad estudiantil sin enlaces a la nube externa.
- Grading Weight / Ponderación: 15% of Final Grade • 30 Total Points (SpeedGrader Text Entry Submission) 15% de la calificación final • 30 Puntos Totales (Entrega mediante cuadro de texto en Canvas SpeedGrader)
- Submission Format / Formato de Entrega: Direct text entry utilizing triple-hash ( ### ) delimiters for all community case data and demographic profiles. Entrada directa de texto utilizando delimitadores de triple numeral (###) para todos los datos de casos comunitarios.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Capstone Core Requirements & Clinical Framing Protocol (Pattern / Rule / Solve) Structure

Requisitos Principales del Capstone y Estructura del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Pattern Phase: Identify and isolate a specific physical inactivity trend, barrier, or health disparity within a target community demographic. Fase de Patrón: Identificar y aislar una tendencia específica de inactividad física o disparidad de salud.
- Rule Phase: Apply federal physical activity guidelines and foundational movement principles from PAGA 2018 (2nd Ed.) to evaluate the scale of the challenge. Fase de Regla: Aplicar pautas de actividad física y principios de movimiento de la PAGA 2018.
- Solve Phase: Propose a practical, scalable community health or physical education intervention plan designed to mitigate the identified issue. Fase de Solución: Proponer un plan de intervención comunitaria práctico y escalable.

### Required Delimiter Protocol & Data Formatting

Protocolo Obligatorio de Delimitadores y Formato de Datos

When incorporating community case data, metrics, or demographic profiles into your text submission, you must wrap the data block within triple hashes as shown below:

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Final Capstone Grading Rubric (30 Total Points • Uniform Mastery Scale)

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 16 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 16 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 16 (Mod 16: Final Coaching Portfolio & Case Defense)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive and screen-reader verified.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Proyecto Capstone Aplicado Final

Síntesis de Salud Comunitaria y Marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)


### Síntesis de Intervención en Salud Comunitaria y Movimiento

En este proyecto capstone (15% de su calificación final, evaluado sobre un total de 30 puntos), sintetizará las bases históricas, sociológicas y fisiológicas del movimiento humano. Utilizando estrictamente la PAGA 2018 (2.ª ed.) , auditará un reto real de inactividad comunitaria y diseñará una intervención escalable aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) .


#### Fase de Patrón

Identifique y aísle una tendencia de inactividad física o disparidad de salud en una comunidad específica.


#### Fase de Regla

Aplique las pautas federales de actividad física y principios de la PAGA 2018 (2.ª ed.) .


#### Fase de Solución

Proponga un plan de intervención escalable para mitigar el problema identificado.


### Rúbrica de Calificación (30 Puntos Totales • Escala Uniforme)

KIN-101 • Module 16 Quick Return Navigation / Regreso Rápido al Módulo 16:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
