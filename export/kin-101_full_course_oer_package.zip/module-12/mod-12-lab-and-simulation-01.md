# KIN-101: Mod 12 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 12 Coaching Sprint Simulation: Building Your Coaching Philosophy

Sesión de Coaching del Módulo 12: Construyendo su Filosofía de Entrenamiento e Integración de IA

- Human-in-the-Loop Clinical Audit (The Centaur Protocol): Using AI prompts to draft baseline workout structures while the human coach audits and overrides unsafe volume jumps, missing rest days, or heat blind spots. En palabras sencillas: Usar la IA para armar el borrador rápido, pero revisando tú mismo que no tenga aumentos bruscos de carga ni errores con el calor de Yuma.
- Wearable Telemetry Drift vs. Subjective Biofeedback: Consumer wrist heart-rate sensors and calorie trackers can drift by 10–25% during sweat or resistance training; cross-check metrics against the Talk Test and Borg RPE. En palabras sencillas: Los relojes inteligentes pueden fallar al sudar o levantar pesas; siempre confirma cómo se siente y respira tu cliente en la vida real.
- Self-Efficacy & Autonomous Coaching Adherence: A client's confidence in their ability to execute a movement habit consistently; built through achievable small wins, bilingual cues, and non-punitive feedback. En palabras sencillas: La confianza real que gana tu cliente cuando ve que sí puede cumplir la rutina paso a paso sin lesionarse ni frustrarse.

### In Plain English

Before you read the details below, here is the short version: Your coaching philosophy is the personal rulebook that guides how you treat clients and use AI safely. In this sprint, you use the Clinical Framing Protocol (Pattern / Rule / Solve) to define your coaching values and test an ethical AI workflow anchored in PAGA 2018.


#### En Palabras Sencillas (Contexto Norteño)

Tu filosofía de coach es como la palabra de honor en el trabajo: define cómo cuidas a tu gente en el calor de Yuma y cómo usas la inteligencia artificial como calculadora sin dejar que tome tu lugar. Si los términos técnicos se ponen pesados, concéntrate primero en poner la seguridad humana antes que cualquier pantalla.

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Kinematic Gait Speed & Wearable Telemetry Auditor (/simulators/gait-speed-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate consumer wearable speed/cadence drift against PAGA 2018 moderate intensity (3.0–5.9 METs; >=150 min/week) before trusting automated AI progressions. Copy your VERIFIED simulator receipt or slider values into the submission template below.

Open Kinematic Gait Speed & Wearable Telemetry Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/gait-speed-auditor y "PAGA"): Calibre la velocidad de marcha y los METs reales frente a PAGA 2018 (3.0–5.9 METs; >=150 min/semana) antes de aceptar rutinas automáticas de IA en el calor de Yuma. Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Select ONE regional scenario below and copy its triple-hash ( ### ) block into Google Gemini:


### Phase 2: Gemini AI Clinical Simulation Workspace (P-T-C-F Prompt)


### Phase 3: Canvas Text Box Submission (10-7-0 Mastery Scale)

- Pattern (Chosen Track & AI Risk): Identify your selected track and the specific safety risk of relying on unverified AI output.
- Rule (PAGA 2018 & Centaur Guardrail): State the PAGA 2018 benchmark and the human-in-the-loop rule you enforce as the Architect/Pilot.
- Solve (My Coaching Philosophy & Bilingual Motto): Write your 150-word personal Coaching Philosophy defense in your own voice plus your bilingual coaching motto (English & Spanish).
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


## Módulo 12 Simulación de Coaching: Construyendo su Filosofía de Entrenamiento

Utilice el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para definir su filosofía profesional de entrenamiento e integrar la inteligencia artificial de forma ética y segura bajo las normas de PAGA 2018 . Envíe su respuesta directamente en el cuadro de texto de Canvas.

KIN-101 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 12 (Mod 12 Coaching Sprint: Building Your Coaching Philosophy)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
