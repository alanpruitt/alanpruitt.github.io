## KIN-101 MODULE-12: ACTIVE INFRASTRUCTURE / Master Content Loop

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## KIN-101: MODULE 12 - ACTIVE INFRASTRUCTURE, PARKS, AND RECREATION / INFRAESTRUCTURA ACTIVA, PARQUES Y RECREACIÓN 

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module examines the critical role of public parks, recreational facilities, and urban active infrastructure in promoting population-level movement longevity. Students will analyze how community spaces, shared-use path networks, and public recreation programming clear environmental barriers to physical activity. All space tracking parameters and facility access benchmarks align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo examina el papel crítico de los parques públicos, las instalaciones recreativas y la infraestructura activa urbana en la promoción de la longevidad del movimiento a nivel de la población. Los estudiantes analizarán cómo los espacios comunitarios, las redes de senderos de uso compartido y la programación de recreación pública eliminan las barreras ambientales para la actividad física. Todos los parámetros de seguimiento de espacios y puntos de referencia de acceso a instalaciones se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.22]):** Evaluate municipal park infrastructures and recreational facilities using federal environmental frameworks to design inclusive, active community access modifications.
* **Español (Regional) ([LO 2.22]):** Evaluar las infraestructuras de parques municipales y las instalaciones recreativas utilizando marcos ambientales federales para diseñar modificaciones inclusivas de acceso a la comunidad activa.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Identify and document environmental access patterns, tracking missing sidewalk connections, unlit public park sectors, or facility usage disparities across regional neighborhood perimeters.
   * **Patrón (Español):** Identificar y documentar los patrones de acceso ambiental, rastreando conexiones de aceras faltantes, sectores de parques públicos sin iluminación o disparidades en el uso de instalaciones a lo largo de perímetros de vecindarios regionales.
2. **Rule (English):** Apply the environmental infrastructure design metrics and community-level facility safety standards highlighted throughout the federal PAGA 2018 framework to map space equity rules.
   * **Regla (Español):** Aplicar las métricas de diseño de infraestructura ambiental y los estándares de seguridad de instalaciones a nivel comunitario destacados en el marco federal de PAGA 2018 para trazar reglas de equidad espacial.
3. **Solve (English):** Engineer a multi-component active infrastructure modification plan or recreational program layout designed to maximize localized population tracking metrics safely.
   * **Solución (Español):** Diseñar un plan de modificación de infraestructura activa de componentes múltiples o un diseño de programa recreativo diseñado para maximizar de forma segura las métricas de seguimiento de la población localizada.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Andamiaje

## Part A: Gemini AI Simulation (Infrastructure Mapping Simulation)

## English

Students will initialize the virtual geographic tracking environment within their sandbox workspace. Ensure your simulated municipal asset data rows remain completely enclosed within the layout delimiters below.

::: {.callout-note}
## Worked Example: Step-by-Step Guidance / Ejemplo Práctico Paso a Paso
**Context & Application:** When completing this lab assignment, follow this structured three-step approach based on our Single Sources of Truth (PAGA 2018 / ACSM 12th Ed.):

1. **Step 1 (Identify Pattern):** Review the client or case profile parameters for baseline activity, physiological constraints, or nutritional markers.
2. **Step 2 (Apply Rule):** Cross-reference the specific federal guidelines, volume targets, or physiological formulas required for the assessment.
3. **Step 3 (Solve):** Formulate your final recommendation or calculation clearly within the submission template below.
:::

```text
## [PASTE SIMULATED RECREATIONAL FACILITY ACCESS MATRIX AND MUNICIPAL PATHWAY GEODATA HERE]
###
```

1. Use the sandbox environment to audit a simulated geographical dataset, evaluating distance coordinates from residential density blocks to active green spaces.
2. Cross-examine virtual infrastructure access lanes against the community design and park mobilization pathways targeted in the federal PAGA document.
3. Execute an automated audit check within the sandbox to verify that proposed public transit linkages deliver sufficient access scores with zero layout gaps.

## Español (Regional)

Los estudiantes inicializarán el entorno de seguimiento geográfico virtual dentro de su espacio de trabajo sandbox. Asegúrese de que las filas de datos de activos municipales simulados permanezcan completamente cerradas dentro de los delimitadores de diseño a continuación.

```text
## [PEGUE LA MATRIZ DE ACCESO A INSTALACIONES RECREATIVAS SIMULADAS Y LOS GEODATOS DE VÍAS MUNICIPALES AQUÍ]
###
```

1. Utilizar el entorno de pruebas (sandbox) para auditar un conjunto de datos geográficos simulados, evaluando las coordenadas de distancia desde los bloques de densidad residencial hasta los espacios verdes activos.
2. Evaluar de forma cruzada los carriles de acceso a la infraestructura virtual frente a las vías de diseño comunitario y movilización de parques previstas en el documento oficial de PAGA.
3. Ejecutar una verificación de auditoría automatizada dentro del sandbox para verificar que los enlaces de tránsito público propuestos ofrezcan puntajes de acceso suficientes sin brechas de diseño.

## Part B: Practical Field Application (Park Asset Screening)

## English

Students will transition into their immediate regional community parks or public paths to execute a practical, zero-cost environmental audit.

1. Complete a visual environment screening log of a local park perimeter, noting the condition of shared paths, illumination placements, and universal access layouts.
2. Document visible safety features and active usage balances across variable age blocks during active tracking periods.
3. Document true structural indicators: record raw infrastructure access variables and cross-examine your field observations against the population tracking benefits prioritized by the federal PAGA guidelines.

## Español (Regional)

Los estudiantes harán la transición a sus parques comunitarios regionales o senderos públicos inmediatos para ejecutar una auditoría ambiental práctica y de costo cero.

1. Completar un registro de evaluación visual del entorno de un perímetro de parque local, anotando el estado de los senderos compartidos, la ubicación de la iluminación y los diseños de acceso universal.
2. Documentar las características de seguridad visibles y los equilibrios de uso activo en variables bloques de edad durante los períodos de seguimiento activos.
3. Documentar los indicadores estructurales reales: registrar las variables de acceso a la infraestructura bruta y evaluar de forma cruzada sus observaciones de campo con los beneficios de seguimiento de la población priorizados por las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This infrastructure module assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación del módulo de infraestructura se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):
  * **English:** Zero-drift integration. All proposed infrastructure modifications and safety rules match PAGA environmental indices exactly; all sandbox simulation inputs remain fenced inside structural layout boundaries.
  * **Español (Regional):** Integración sin desviaciones. Todas las modificaciones de infraestructura propuestas y las reglas de seguridad coinciden exactamente con los índices ambientales de PAGA; todas las entradas de simulación de sandbox permanecen delimitadas dentro de los límites de diseño estructural.
* **7 (Competent) / (Competente):
  * **English:** Minor refactoring required. Core Clinical Framing Protocol steps and facility guidelines are appropriately applied, but minor formatting gaps or bilingual layout omissions are flagged in the final file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los pasos del Protocolo de Encuadre Clínico y las pautas de las instalaciones se aplican adecuadamente, pero se identifican pequeñas brechas de formato u omisiones de diseño bilingüe en el archivo final.
* **0 (Recalibrate) / (Recalibrar):
  * **English:** Critical error in calculating accessibility scores or un-fenced facility geodata that violates federal safety parameters or ignores infrastructure frameworks. Complete rewrite required.
  * **Español (Regional):** Error crítico en el cálculo de los puntajes de accesibilidad o geodatos de instalaciones sin delimitar que violan los parámetros de seguridad federales o ignoran los marcos de infraestructura. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.



<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>


## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
