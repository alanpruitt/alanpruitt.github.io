# KIN-101: Mod 12 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 12 Lab & Simulation: Organizing Your AI Coaching Toolkit

In Plain English Before you read the details below, here is the short version: Your AI Repository is your personal toolkit of tested prompts and audits from this course. In this lab, you organize it and test one prompt again against PAGA 2018. It shows an employer you can use AI safely and check its work.

- Human-in-the-Loop Clinical Audit (The Centaur Protocol): Using AI prompts to draft baseline workout structures while the human coach audits and overrides unsafe volume jumps, missing rest days, or heat blind spots. En palabras sencillas: Usar la IA para armar el borrador rápido, pero revisando tú mismo que no tenga aumentos bruscos de carga ni errores con el calor de Yuma.
- Wearable Telemetry Drift vs. Subjective Biofeedback: Consumer wrist heart-rate sensors and calorie trackers can drift by 10–25% during sweat or resistance training; cross-check metrics against the Talk Test and Borg RPE. En palabras sencillas: Los relojes inteligentes pueden fallar al sudar o levantar pesas; siempre confirma cómo se siente y respira tu cliente en la vida real.
- Self-Efficacy & Autonomous Coaching Adherence: A client's confidence in their ability to execute a movement habit consistently; built through achievable small wins, bilingual cues, and non-punitive feedback. En palabras sencillas: La confianza real que gana tu cliente cuando ve que sí puede cumplir la rutina paso a paso sin lesionarse ni frustrarse.
En Palabras Sencillas (Norteño) Es como la caja de herramientas de tu apá: si cada herramienta está en su lugar y funciona, el trabajo sale rápido y bien. Si los términos técnicos se ponen pesados, concéntrate primero en ordenar lo que ya hiciste.

Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### The Mission / La Misión

Pattern / Rule / Solve applied to your own work this semester.

Part A: Repository Audit (Pattern)

- Open your EXW_Professional_AI_Repository .
- Choose three prompts or audits you built in Modules 01–11.
- For each one, write one sentence: what problem did it solve?
Part B: Capstone Simulation (Rule)

- Choose one of the three and run it again in Gemini with a new fictional client.
- Enclose the client profile inside ### delimiters.
- Check the AI output against PAGA 2018 (2nd Ed.) . Find one thing it got right and one thing you had to correct.
Part C: Professional Reflection (Solve), 150 words In your own words: how will this repository help you in your next course (EXW150, EXW245, or EXW265) or your career track? Quote PAGA 2018 at least once.


### Submit

- Part A list (3 items)
- Part B: the ### client profile, the AI output, and your Auditor's Note (right/corrected)
- Part C reflection (150 words)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Español (Regional)

Parte A: Elige tres prompts o auditorías de los Módulos 01–11 y explica en una oración qué problema resolvió cada uno. Parte B: Vuelve a correr uno con un cliente ficticio nuevo dentro de ### . Compara la respuesta con PAGA 2018: anota un acierto y una corrección. Parte C: Reflexión de 150 palabras: ¿cómo te ayudará este repositorio en tu próximo curso o carrera? Cita PAGA 2018 al menos una vez.

KIN-101 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 12 (Mod 12 Lab: Organizing Your AI Coaching Toolkit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
