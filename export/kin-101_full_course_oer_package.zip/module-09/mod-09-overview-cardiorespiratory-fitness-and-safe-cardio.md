# KIN-101: Mod 09 Overview Cardiorespiratory Fitness And Safe Cardio

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 09 Overview: Cardiorespiratory Fitness & Safe Cardio


### Welcome to Module 09: Cardiorespiratory Fitness & Safe Cardio

Welcome to Week 9! This week, we examine the physiological cardiorespiratory adaptations to endurance training. We explore the mechanics of maximal oxygen uptake (VO2max), stroke volume, cardiac output, and how to program aerobic exercise using frequency, intensity, time, and type (FITT) principles.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will audit aerobic conditioning patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) cardiorespiratory standards, and design individualized conditioning programs tailored to your career track.


### In Plain English: Module 09 Navigation

Welcome to the second half of the semester! Based on your fantastic midterm feedback requesting simpler, more natural explanations, we've added these conversational breakdowns across Modules 09–16. Think of Module 09 as shifting our focus from the broad "why" of physical activity to the specific "how" inside your heart, lungs, and blood vessels.


#### En Palabras Sencillas (Norteño Context)

Bienvenidos al Módulo 09. Si los términos técnicos se ponen pesados esta semana, revisa este resumen para conectar los puntos más rápido y entender cómo el cuerpo se adapta al esfuerzo aeróbico.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 13, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 15, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 18, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 19, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 09 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze cardiorespiratory physiological responses and aerobic conditioning adaptations across diverse populations. Analizar las respuestas fisiológicas cardiorespiratorias y las adaptaciones al acondicionamiento aeróbico.
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) aerobic physical activity standards and FITT principles to structure progressive conditioning programs. Aplicar las normas aeróbicas de la PAGA 2018 y los principios FITT para estructurar programas progresivos.
- CLO 3 (Problem Solving): Formulate an evidence-based cardiorespiratory conditioning plan tailored to clinical, educational, or athletic coaching tracks. Formular un plan de acondicionamiento cardiorespiratorio basado en evidencia adaptado a diferentes rutas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Cardiac rehabilitation programming, VO2peak testing metrics, and graded exercise prescriptions for chronic disease management.

Youth aerobic fitness testing, school-based heart rate monitoring, and community walking programs for metabolic health.

High-intensity interval training (HIIT) prescription, lactate threshold profiling, and aerobic power periodization for endurance sports.


### Module 09 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Cardiorespiratory Adaptations & FITT Principles
- Discussion Board: Aerobic Conditioning vs. Health Outcomes
- Lab Assignment: Cardiorespiratory Prescription Audit & Gemini AI Simulation
- Knowledge Check & Module Summary

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Overview: Cardiorespiratory Fitness & Safe Cardio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 09 Visión General: Aptitud Cardiorespiratoria


### Bienvenido al Módulo 09: Aptitud Cardiorespiratoria, Acondicionamiento Aeróbico y Principios FITT

¡Bienvenido a la Semana 9! Esta semana examinaremos las adaptaciones fisiológicas cardiorespiratorias al entrenamiento de resistencia. Exploraremos la mecánica del consumo máximo de oxígeno (VO2max), el volumen sistólico, el gasto cardíaco y cómo programar el ejercicio aeróbico usando los principios FITT (frecuencia, intensidad, tiempo y tipo).

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , auditarás los patrones de acondicionamiento aeróbico, aplicarás las normas federales de PAGA 2018 (2.ª ed.) y diseñarás programas de acondicionamiento adaptados a tu ruta profesional.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar las respuestas fisiológicas cardiorespiratorias y las adaptaciones al acondicionamiento aeróbico en diversas poblaciones. Analyze cardiorespiratory physiological responses and aerobic conditioning adaptations.
- CLO 2 (Regla): Aplicar las normas de actividad física aeróbica de la PAGA 2018 y los principios FITT para estructurar programas de acondicionamiento progresivos. Apply PAGA 2018 aerobic standards and FITT principles to structure progressive programs.
- CLO 3 (Solución): Formular un plan de acondicionamiento cardiorespiratorio basado en evidencia adaptado a rutas clínicas, educativas o

### Module 09 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 09 Required Readings: Cardiorespiratory Fitness & Safe Cardio →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 09 Discussion: Heart Health & Aerobic Exercise Benefits →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 09 Coaching Sprint: Setting Safe Cardio Intensity →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 09 Lab: Weekly Cardio Plan & Safety Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 09 Summary & Wrap-Up: Cardiorespiratory Fitness & Safe Cardio →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
