# KIN-101: Mod 09 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Coaching Sprint Simulation: Setting Safe Cardio Intensity

- Heart Rate Reserve (HRR — Karvonen Method): Calculates personalized cardio zones using resting heart rate: Target HR = ((HRmax − HRrest) × %Intensity) + HRrest; moderate intensity = 40–59% HRR. En palabras sencillas: Fórmula que toma en cuenta tu pulso en reposo para calcular con exactitud tu zona segura de cardio moderado (40–59% HRR).
- Talk Test & Borg Rating of Perceived Exertion (RPE 12–13): Validated intensity gauge where moderate aerobic activity allows speaking in full sentences without gasping (Borg RPE 12–13 on the 6–20 scale). En palabras sencillas: La Prueba del Habla: en intensidad moderada debes poder platicar en oraciones completas sin quedarte sin aire (RPE 12 a 13).
- Cardiovascular Drift in High Ambient Heat: Upward creep in heart rate during prolonged exercise in warm conditions due to dehydration and skin vasodilation, requiring pace reduction and cooling. En palabras sencillas: Cuando el pulso se sube de más por el calor de Yuma aunque mantengas el mismo paso; obliga a bajar el ritmo o entrenar bajo techo.
- KIN-101.9.1.AY26-27: Apply PAGA 2018 aerobic guidelines to analyze cardiorespiratory adaptations, stroke volume, and VO2max. Aplicar las pautas aeróbicas de la PAGA 2018 para analizar las adaptaciones cardiorespiratorias, el volumen sist\u00f3lico y el VO2max.
- KIN-101.9.2.AY26-27: Audit Frequency, Intensity, Time, Type (FITT) prescription parameters and conditioning protocols across physical education, clinical rehabilitation, and sports coaching contexts. Auditar los parámetros de prescripci\u00f3n FITT y los protocolos de acondicionamiento en contextos educativos, clínicos y deportivos.

### Your Weekly Win: Mastering Cardiorespiratory Conditioning & FITT Programming

How does understanding cardiorespiratory physiology empower physical educators, therapists, and coaches to enhance metabolic health? Examining maximal oxygen uptake, stroke volume, and cardiac output allows practitioners to optimize endurance capacity and reduce chronic disease risk. Following federal PAGA 2018 aerobic guidelines, exercise leaders can design progressive conditioning programs tailored to diverse populations. Choose your coaching track below, chat with your AI Socratic Coach, and master aerobic prescription analysis!

¿Cómo ayuda la fisiología cardiorespiratoria a educadores, terapeutas y entrenadores a optimizar la salud metabólica? Comprender el VO2max y el gasto cardíaco permite mejorar la resistencia y reducir el riesgo de enfermedades. ¡Elija su ruta y dialogue con su coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Scenario: Cardiac rehabilitation participant (R.K., 58) recovering from a recent myocardial infarction, exhibiting low functional capacity and sedentary VO2max decline.

Scenario: Middle school physical education cohort (Grade 7, Age 12) showing declining participation in continuous moderate aerobic activity.

Scenario: Collegiate cross-country runner (D.L., 20) experiencing VO2max plateaus during preseason high-temperature endurance training blocks.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission / Fase 3: Entrega en Canvas (Solo Texto)

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's cardiorespiratory conditioning challenge.
- Cardiorespiratory & FITT Analysis: Explain VO2max, stroke volume, FITT parameters, and PAGA 2018 aerobic standards for your client.
- Part 3: Active Verification & FITT Adjustment: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your FITT prescription adjustment protects myocardial safety and aligns with PAGA 2018 aerobic guidelines for your chosen client.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 09 Coaching Sprint • Track 1 (Clinical / R.K.)

- Chosen Track & Client: Track 1: Clinical & Allied Health Path (R.K., 58). Challenge: R.K. is recovering from a recent myocardial infarction and exhibits low functional capacity, stroke volume depression, and sedentary VO2max decline.
- Track 1: Clinical & Allied Health Path (R.K., 58).
- Challenge: R.K. is recovering from a recent myocardial infarction and exhibits low functional capacity, stroke volume depression, and sedentary VO2max decline.
- Cardiorespiratory & FITT Analysis: PAGA 2018 Aerobic Guidelines & Hemodynamics: Cardiac rehabilitation requires gradually rebuilding myocardial contractility and peripheral oxygen extraction without inducing cardiac ischemia. PAGA 2018 guidelines recommend 150 minutes of moderate aerobic conditioning weekly, structured via safe FITT parameters. Progressive aerobic overload expands stroke volume and enhances metabolic health safely.
- PAGA 2018 Aerobic Guidelines & Hemodynamics: Cardiac rehabilitation requires gradually rebuilding myocardial contractility and peripheral oxygen extraction without inducing cardiac ischemia. PAGA 2018 guidelines recommend 150 minutes of moderate aerobic conditioning weekly, structured via safe FITT parameters.
- Progressive aerobic overload expands stroke volume and enhances metabolic health safely.
- Part 3: Active Verification & FITT Adjustment: "Implement a FITT prescription of 3 days/week frequency, 40%–50% Heart Rate Reserve intensity (RPE 11–13), 20–30 minutes duration, using low-impact stationary cycling." Active Verification: In my clinical judgment, initiating at 40% HRR provides a vital hemodynamic buffer for R.K. His post-infarct myocardium cannot tolerate rapid blood pressure spikes, and beta-blocker therapy limits chronotropic acceleration. Stationary cycling provides a controlled, low-impact modality that builds stroke volume and peripheral capillary beds while strictly observing PAGA 2018 cardiac safety baselines.
- "Implement a FITT prescription of 3 days/week frequency, 40%–50% Heart Rate Reserve intensity (RPE 11–13), 20–30 minutes duration, using low-impact stationary cycling."
- Active Verification: In my clinical judgment, initiating at 40% HRR provides a vital hemodynamic buffer for R.K. His post-infarct myocardium cannot tolerate rapid blood pressure spikes, and beta-blocker therapy limits chronotropic acceleration. Stationary cycling provides a controlled, low-impact modality that builds stroke volume and peripheral capillary beds while strictly observing PAGA 2018 cardiac safety baselines.
- Part 4: My Memorable Coaching Takeaway: EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!" ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!"
- ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M09_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Coaching Sprint: Setting Safe Cardio Intensity)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 09 Simulación de Coaching: Aptitud Cardiorespiratoria

Evaluación Rápida y Auditoría de Prescripción Aeróbica


### Su Logro Semanal: Dominando el Acondicionamiento Aeróbico y la Programación FITT

Esta sesión le permitirá aplicar la fisiología cardiorespiratoria y las pautas aeróbicas de PAGA 2018 para analizar el VO2max, el volumen sistólico y estructurar la prescripción FITT. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Participante de rehabilitación cardíaca (R.K., 58 años) recuperándose de un infarto, con baja capacidad funcional y descenso sedentario del VO2max.

Escenario: Grupo de educación física de secundaria (Grado 7, 12 años) con participación decreciente en actividad aeróbica moderada continua.

Escenario: Corredor universitario de campo traviesa (D.L., 20 años) con estancamiento en la progresión del VO2max durante bloques de entrenamiento en calor extremo.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de acondicionamiento cardiorespiratorio de su cliente.
- Análisis Cardiorespiratorio y FITT: Explique el VO2max, el volumen sistólico, los parámetros FITT y las normas aeróbicas de PAGA 2018 para su cliente.
- Parte 3: Verificación Activa y Ajuste FITT: En una defensa obligatoria (aprox. mínimo 150 palabras (150+ palabras)) con su propia voz clínica, justifique por qué su ajuste de prescripción FITT protege la seguridad miocárdica y se alinea con PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 09 Sesión de Coaching • Ruta 1 (Clínica / R.K.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Profesiones de la Salud (R.K., 58 años). Reto: R.K. se recupera de un infarto de miocardio reciente y presenta baja capacidad funcional, depresión del volumen sistólico y caída del VO2max por sedentarismo.
- Ruta 1: Clínica y Profesiones de la Salud (R.K., 58 años).
- Reto: R.K. se recupera de un infarto de miocardio reciente y presenta baja capacidad funcional, depresión del volumen sistólico y caída del VO2max por sedentarismo.
- Análisis Cardiorespiratorio y FITT: Pautas Aeróbicas de PAGA 2018 y Hemodinámica: La rehabilitación cardíaca requiere reconstruir gradualmente la contractilidad miocárdica y la extracción periférica de oxígeno sin inducir isquemia cardíaca. Las pautas de PAGA 2018 recomiendan 150 minutos semanales de acondicionamiento aeróbico moderado estructurado mediante parámetros FITT seguros. La sobrecarga aeróbica progresiva expande el volumen sistólico y mejora la salud metabólica con seguridad.
- Pautas Aeróbicas de PAGA 2018 y Hemodinámica: La rehabilitación cardíaca requiere reconstruir gradualmente la contractilidad miocárdica y la extracción periférica de oxígeno sin inducir isquemia cardíaca. Las pautas de PAGA 2018 recomiendan 150 minutos semanales de acondicionamiento aeróbico moderado estructurado mediante parámetros FITT seguros.
- La sobrecarga aeróbica progresiva expande el volumen sistólico y mejora la salud metabólica con seguridad.
- Parte 3: Verificación Activa y Ajuste FITT: "Implementar una prescripción FITT de 3 a 4 días por semana de frecuencia, 40%–50% de intensidad de la Reserva de Frecuencia Cardíaca (RPE 11–13), 20–30 minutos de duración, utilizando cicloergómetro estacionario de bajo impacto." Verificación Activa: En mi juicio clínico, iniciar al 40% de la FCR proporciona un amortiguador hemodinámico vital para R.K. Su miocardio post-infarto no tolera picos rápidos de presión arterial, y los betabloqueadores limitan la aceleración cronotrópica. El cicloergómetro estacionario ofrece una modalidad controlada de bajo impacto que expande el volumen sistólico respetando PAGA 2018.
- "Implementar una prescripción FITT de 3 a 4 días por semana de frecuencia, 40%–50% de intensidad de la Reserva de Frecuencia Cardíaca (RPE 11–13), 20–30 minutos de duración, utilizando cicloergómetro estacionario de bajo impacto."
- Verificación Activa: En mi juicio clínico, iniciar al 40% de la FCR proporciona un amortiguador hemodinámico vital para R.K. Su miocardio post-infarto no tolera picos rápidos de presión arterial, y los betabloqueadores limitan la aceleración cronotrópica. El cicloergómetro estacionario ofrece una modalidad controlada de bajo impacto que expande el volumen sistólico respetando PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!" ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!"
- ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M09_Quiz_Sprint.pdf
KIN-101 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
