# KIN-101: Mod 09 Required Readings Cardiorespiratory Fitness And Safe Cardio

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 09 Required Readings: Cardiorespiratory Fitness & Safe Cardio


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Cardiorespiratory fitness is simply how efficiently your heart, lungs, and muscles work together as a team. When you exercise regularly, your heart gets stronger so it pumps more blood with fewer beats, and your muscles get better at pulling oxygen out of that blood. That teamwork is what keeps your energy high and protects your long-term health.


#### En Palabras Sencillas (Norteño Context)

Piensa en tu sistema cardiorespiratorio como el motor de un carro: entre mejor mantenimiento le des con el ejercicio aeróbico, más distancia recorres sin cansarte. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo se adapta al esfuerzo.

This week's literature explores the physiological cardiorespiratory adaptations that occur in response to systematic aerobic endurance training. By examining maximal oxygen uptake, central hemodynamics, and energy substrate utilization, we uncover how the cardiovascular and respiratory systems supply active skeletal muscle during prolonged physical exertion.

Anchored in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , these readings emphasize that regular aerobic conditioning is vital for reducing all-cause mortality, preventing chronic cardiovascular disease, and enhancing metabolic health across diverse clinical, educational, and athletic environments.


### 1. Cardiovascular Dynamics: Stroke Volume, Cardiac Output & VO2max

Maximal oxygen uptake represents the functional capacity of the cardiorespiratory system to transport and utilize oxygen during maximal effort. It is governed by the Fick equation, uniting central hemodynamics and peripheral extraction:

- Cardiac Output (Q): The total volume of blood pumped by the heart per minute, calculated as heart rate multiplied by stroke volume. Endurance training expands left ventricular chamber size and myocardial contractility, significantly increasing maximal stroke volume.
- Arteriovenous Oxygen Difference (a-v O2 diff): The measure of how much oxygen is extracted by working skeletal muscles from arterial blood. Aerobic conditioning increases capillary density and mitochondrial enzyme concentrations, enhancing peripheral extraction efficiency.
- Cardiorespiratory Adaptations: Regular aerobic training decreases resting heart rate through enhanced parasympathetic tone while maximizing oxygen delivery to active tissues.

### 2. Prescription Design: The FITT Principles of Aerobic Training

Translating cardiorespiratory science into safe, effective exercise programming relies on manipulating the core variables of training prescription:

Prescribing cardiorespiratory exercise requires establishing training Frequency (sessions per week), Intensity (percentage of heart rate reserve or VO2max), Time (duration of continuous or interval exertion), and Type (rhythmic, continuous large muscle group movements). Balancing these variables ensures progressive overload while preventing musculoskeletal overuse injuries and excessive cardiovascular strain.


### 3. Lifespan Aerobic Health & Federal PAGA 2018 Alignment

Maintaining cardiovascular fitness across the lifespan is essential for preserving metabolic homeostasis and physical independence. The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) mandate that adults accumulate at least 150 to 300 minutes of moderate-intensity aerobic physical activity (or 75 to 150 minutes of vigorous-intensity aerobic activity) weekly to optimize cardiorespiratory health and mitigate chronic disease risks.


### Workplace Intelligence & AI Security Protocol ()

When utilizing generative AI tools like Google Gemini for cardiorespiratory prescription audits and FITT calculation checks, professionals must enclose all client profile data and testing metrics within triple-hash delimiters:


```text
Cardiorespiratory Prescription Audit: Cardiac Rehabilitation Participant ###:
Client Profile: 54-year-old post-myocardial infarction participant seeking aerobic reconditioning.
Task: Audit heart rate reserve parameters, calculate target training zones, and align with PAGA 2018.
End Case ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Required Readings: Cardiorespiratory Fitness & Safe Cardio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas en Línea: Aptitud Cardiorespiratoria y Acondicionamiento Aeróbico

La literatura de esta semana explora las adaptaciones fisiológicas cardiorespiratorias que ocurren como respuesta al entrenamiento sistemático de resistencia aeróbica. Al examinar el consumo máximo de oxígeno, la hemodinámica central y la utilización de sustratos energéticos, descubrimos cómo los sistemas cardiovascular y respiratorio suministran oxígeno al músculo esquelético activo durante el ejercicio prolongado.

Fundamentadas en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) , estas lecturas enfatizan que el acondicionamiento aeróbico regular es vital para reducir la mortalidad por todas las causas y mejorar la salud metabólica.


### 1. Dinámica Cardiovascular: Volumen Sistólico, Gasto Cardíaco y VO2max

- Gasto Cardíaco (Q): Volumen total de sangre bombeado por el corazón por minuto, calculado multiplicando la frecuencia cardíaca por el volumen sistólico.
- Diferencia Arteriovenosa de Oxígeno (a-v O2 diff): Medida de cuánto oxígeno extraen los músculos activos de la sangre arterial; el entrenamiento aeróbico incrementa la densidad capilar.
- Adaptaciones Cardiorespiratorias: El entrenamiento aeróbico regular disminuye la frecuencia cardíaca en reposo mediante un mayor tono parasimpático.

### 2. Diseño de Prescripción: Los Principios FITT del Entrenamiento Aeróbico

Traducir la ciencia cardiorespiratoria en programas seguros y efectivos se basa en manipular las variables clave de la prescripción:

La prescripción requiere establecer la Frecuencia (sesiones semanales), la Intensidad (% de la reserva de frecuencia cardíaca), el Tiempo (duración) y el Tipo (movimientos rítmicos de grandes grupos musculares).


### 3. Salud Aeróbica y Alineación con PAGA 2018

Mantener la condición cardiovascular a lo largo de la vida es esencial. Las pautas de la PAGA 2018 (2.ª ed.) exigen que los adultos acumulen de 150 a 300 minutos de actividad aeróbica de intensidad moderada (o de 75 a 150 minutos de intensidad vigorosa) semanalmente para optimizar la salud cardiorespiratoria.

KIN-101 • Module 09 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
