# KIN-101: Mod 09 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Discussion: Heart Health & Aerobic Exercise Benefits


### Aerobic Capacity, Endurance Training Zones, & PAGA Federal Mandates

Cardiorespiratory fitness is fundamental to human movement, metabolic health, and longevity. Quantifying aerobic capacity (VO2 max), establishing heart rate training zones, and structuring safe endurance regimens require auditing how cardiovascular and respiratory systems adapt to sustained physical stress.

In this discussion, you will examine how federal standards in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) govern aerobic volume and intensity targets across your chosen Build Your Own Journey Track using our Clinical Framing Protocol (Pattern / Rule / Solve) framework.

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #101-09

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Outpatient cardiac rehabilitation; auditing submaximal cardiorespiratory capacity and heart rate training zones in a sedentary adult with mild hypertension.

Focus: County health department initiative; structuring accessible aerobic walking programs and community health education to combat physical inactivity in Yuma County.

Focus: Human performance lab; analyzing cardiorespiratory adaptations, stroke volume expansion, and mitochondrial biogenesis in endurance athletes.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Cardiorespiratory Profile / Ruta y Perfil Cardiorespiratorio: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and explain the specific cardiorespiratory or inactivity vulnerability in your client scenario. Indique la ruta seleccionada y explique la vulnerabilidad cardiorespiratoria o de inactividad de su cliente.
- Clinical Framing Protocol Audit (Pattern / Rule / Solve) / Análisis del Protocolo de Marco Clínico (Patrón / Regla / Solución): Detail the underlying physiological mechanism (Pattern), apply PAGA 2018 aerobic volume and intensity rules (Rule), and outline your exercise prescription protocol (Solve). Detalle el mecanismo fisiológico (Patrón), aplique las normas aeróbicas de la PAGA 2018 (Regla) y describa su protocolo de prescripción (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence instruction card in English and Spanish guiding the client on aerobic pacing or weekly volume accumulation. Proporcione una tarjeta concisa de 2 oraciones en inglés y en español para guiar al cliente sobre el ritmo aeróbico.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Compare how cardiorespiratory programming and aerobic capacity differ across clinical rehabilitation, public health community initiatives, and athletic performance environments.


### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Discussion: Heart Health & Aerobic Exercise Benefits)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards, featuring semantic hierarchy starting at heading level 2 and screen-reader verification.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Módulo 09 Foro de Discusión: Aptitud Cardiorespiratoria


### Capacidad Aeróbica y Normas PAGA

Analice el caso asignado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) según PAGA 2018 y envíe sus respuestas en Canvas.

KIN-101 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
