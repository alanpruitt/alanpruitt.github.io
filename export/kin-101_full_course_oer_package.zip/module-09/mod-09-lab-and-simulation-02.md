# KIN-101: Mod 09 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Lab & Simulation: Weekly Cardio Plan & Safety Audit

- Heart Rate Reserve (HRR — Karvonen Method): Calculates personalized cardio zones using resting heart rate: Target HR = ((HRmax − HRrest) × %Intensity) + HRrest; moderate intensity = 40–59% HRR. En palabras sencillas: Fórmula que toma en cuenta tu pulso en reposo para calcular con exactitud tu zona segura de cardio moderado (40–59% HRR).
- Talk Test & Borg Rating of Perceived Exertion (RPE 12–13): Validated intensity gauge where moderate aerobic activity allows speaking in full sentences without gasping (Borg RPE 12–13 on the 6–20 scale). En palabras sencillas: La Prueba del Habla: en intensidad moderada debes poder platicar en oraciones completas sin quedarte sin aire (RPE 12 a 13).
- Cardiovascular Drift in High Ambient Heat: Upward creep in heart rate during prolonged exercise in warm conditions due to dehydration and skin vasodilation, requiring pace reduction and cooling. En palabras sencillas: Cuando el pulso se sube de más por el calor de Yuma aunque mantengas el mismo paso; obliga a bajar el ritmo o entrenar bajo techo.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Cardiorespiratory fitness measures how effectively your heart and lungs pump oxygen to working muscles during sustained effort. Regular aerobic conditioning expands stroke volume, meaning your heart pumps more blood with every beat. Applying the FITT formula (Frequency, Intensity, Time, Type) ensures workouts build aerobic stamina safely without overtraining.


#### En Palabras Sencillas (Norteño Context)

El acondicionamiento aeróbico es como afinar la bomba de agua de una noria: entre más eficiente sea, más agua mueve sin esforzarse de más. Si los términos técnicos se ponen pesados, concéntrate primero en aplicar la fórmula FITT para medir cuánto ejercicio aeróbico necesita una persona cada semana.


### Cardiorespiratory Adaptations, FITT Principles, & Aerobic Conditioning

In this laboratory assignment, you will conduct a qualitative cardiorespiratory conditioning audit and construct an evidence-based aerobic prescription protocol. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze VO2max, stroke volume, and FITT parameters, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) cardiorespiratory standards, and execute an AI-driven simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría cualitativa del acondicionamiento cardiorespiratorio y diseñará un protocolo de prescripción aeróbica basado en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando adaptaciones fisiológicas y parámetros FITT.

- KIN-101.9.3.AY26-27: Evaluate cardiorespiratory physiological responses, stroke volume adaptations, and FITT prescription parameters across diverse populations. Evaluar las respuestas fisiológicas cardiorespiratorias, las adaptaciones del volumen sistólico y los parámetros de prescripción FITT en diversas poblaciones.
- KIN-101.9.4.AY26-27: Design cardiorespiratory conditioning protocols and bilingual coaching cue cards aligned with PAGA 2018 aerobic guidelines. Diseñar protocolos de acondicionamiento cardiorespiratorio y tarjetas de instrucción bilingües alineadas con las pautas aeróbicas de la PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, October 13, 2026, at 12:00 AM MST Abre el martes, 13 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 19, 2026, at 11:59 PM MST lunes, 19 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones prácticas

### Lab Objectives / Objetivos del Laboratorio

Objetivos del Laboratorio

- Audit the physiological mechanisms of cardiorespiratory adaptations, stroke volume expansion, and VO2max optimization during aerobic training. Auditar los mecanismos fisiológicos de las adaptaciones cardiorespiratorias, la expansión del volumen sistólico y la optimización del VO2max.
- Apply federal PAGA 2018 (2nd Ed.) aerobic guidelines to structure progressive FITT conditioning programs that preserve cardiovascular health. Aplicar las pautas aeróbicas de la PAGA 2018 para estructurar programas de acondicionamiento FITT progresivos que preserven la salud cardiovascular.
- Formulate a 4-week aerobic conditioning remediation plan paired with bilingual coaching cue cards in English and Spanish. Formular un plan de acondicionamiento aeróbico de 4 semanas con tarjetas de instrucción bilingües en inglés y español.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-09

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos Cardiorespiratorios

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Cardiac rehabilitation; auditing stroke volume depression, functional capacity, and safe FITT parameters post-myocardial infarction.

Focus: Youth physical education and aerobic fitness; structuring climate-safe FITT aerobic games and school conditioning protocols.

Focus: Endurance sports periodization; optimizing VO2max progression and thermal threshold training during high-temperature blocks.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete cardiorespiratory audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline cardiorespiratory profile.
- Part 1: Pattern Recognition: Identify specific cardiorespiratory limitations (VO2max decline, stroke volume depression, thermal strain).
- Part 2: Rule Application: Cite PAGA 2018 aerobic standards and FITT principles for cardiovascular health.
- Part 3: Solving the Gap (Active Verification): In a mandatory text defense (approx. 150 words) written in your own clinical voice, justify why your 4-week aerobic conditioning plan (FITT parameters and progressive overload) aligns with PAGA 2018 standards and protects your client's hemodynamics. Conclude with a 2-sentence bilingual coaching cue card in English and Spanish.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient R.K. is recovering from a recent myocardial infarction and exhibits low functional capacity, marked stroke volume depression, and a sedentary decline in maximal oxygen uptake (VO2max). The cardiovascular system demonstrates reduced myocardial contractility and blunted cardiac output during exertion, restricting oxygen delivery to active skeletal muscle.

Part 2: Rule Application (SSoT PAGA 2018 2nd Ed Standards): Under PAGA 2018 (2nd Ed.) aerobic guidelines, cardiac rehabilitation participants should gradually accumulate 150 minutes of moderate-intensity aerobic conditioning weekly, structured via safe FITT parameters to rebuild myocardial efficiency without inducing ischemia.

Part 3: Solving the Gap (Active Verification): 4-Week Cardiorespiratory Remediation Protocol (3 Days/Week): Key Point — Week 1-2 (Base Building): Stationary cycling at 40%-45% HRR for 20 minutes (RPE 11), emphasizing prolonged warm-up and cool-down. Key Point — Week 3-4 (Progression): Stationary cycling advancing to 50% HRR for 30 minutes (RPE 13) with interval pacing as tolerated. Key Point — Safety Monitoring: Strict heart rate and rating of perceived exertion tracking throughout all sessions. Active Verification: In my clinical judgment, R.K.'s recent myocardial infarction demands a conservative hemodynamic ramp. Because beta-blockade blunts peak heart rate and post-infarct myocardium is vulnerable to ischemia, initiating exercise at 40% HRR prevents dangerous rate-pressure product spikes while stimulating peripheral capillary angiogenesis and stroke volume recovery. Stationary cycling eliminates fall and orthopedic risks, and indoor climate-controlled staging avoids Yuma's extreme thermal strain. This graduated protocol safely bridges R.K. toward the PAGA 150-minute aerobic target without exceeding clinical safety gates.

EN: "Maintain a steady, conversational breathing pace while cycling, keeping your perceived exertion at a comfortable moderate level. Focus on smooth, rhythmic pedaling to support safe cardiovascular recovery."

ES: "Mantenga un ritmo de respiración constante y conversacional mientras pedalea, manteniendo su esfuerzo percibido en un nivel moderado y cómodo. Conéntrese en un pedaleo suave y rítmico para apoyar una recuperación cardiovascular segura."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_101_M09_Cardiorespiratory_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Lab: Weekly Cardio Plan & Safety Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 09 Práctica de Lab y Simulación: Prescripción Cardiorespiratoria y Simulación

Adaptaciones Cardiorespiratorias, Principios FITT y Acondicionamiento Aeróbico


### Adaptaciones Cardiorespiratorias, Principios FITT y Acondicionamiento Aeróbico

En esta práctica de laboratorio, realizará una auditoría cualitativa del acondicionamiento cardiorespiratorio y diseñará un protocolo de prescripción aeróbica. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará el VO2max, el volumen sistólico y los parámetros FITT, aplicará normas aeróbicas de PAGA 2018 (2.ª edición) y ejecutará una simulación con Google Gemini.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Rehabilitación cardíaca; auditoría de la depresión del volumen sistólico, capacidad funcional y parámetros FITT seguros post-infarto.

Enfoque: Educación física juvenil y aptitud aeróbica; estructuración de juegos aeróbicos FITT escolares y protocolos seguros ante el clima.

Enfoque: Periodización de deportes de resistencia; optimización de la progresión del VO2max y umbrales térmicos en bloques de alta temperatura.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Educación / Ruta 3 Deportiva) e incluya sus iniciales.


#### Parte 1: Reconocimiento de Patrones

Identifique la limitación cardiorespiratoria de su cliente (descenso de VO2max, depresión del volumen sistólico o tensión térmica).


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Aplique los estándares aeróbicos de la PAGA 2018 y los principios FITT para la salud cardiovascular.


#### Parte 3: Resolución de la Brecha (Verificación Activa)

En una defensa de texto obligatoria (aprox. 150 palabras) escrita con su propia voz clínica, justifique por qué su plan de acondicionamiento aeróbico de 4 semanas cumple con las normas de PAGA 2018 y protege a su paciente. Concluya con una tarjeta de instrucción bilingüe de 2 oraciones.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: El paciente R.K. se recupera de un infarto de miocardio reciente y presenta baja capacidad funcional, marcada depresión del volumen sistólico y un descenso sedentario en el consumo máximo de oxígeno (VO2max). El sistema cardiovascular muestra contractilidad miocárdica reducida y gasto cardíaco atenuado durante el esfuerzo.

Parte 2: Aplicación de Reglas (PAGA 2018): Según las pautas aeróbicas de la PAGA 2018 (2.ª ed.), los participantes en rehabilitación cardíaca deben acumular gradualmente 150 minutos semanales de acondicionamiento aeróbico moderado mediante parámetros FITT seguros para reconstruir la eficiencia miocárdica sin isquemia.

Parte 3: Resolución de la Brecha (Verificación Activa): Protocolo de 4 semanas: ciclismo estacionario al 40%-45% de la frecuencia cardíaca de reserva durante 20 minutos (RPE 11) semanas 1-2, progresando al 50% durante 30 minutos (RPE 13) semanas 3-4, con monitoreo estricto de frecuencia cardíaca. Verificación Activa: En mi juicio clínico, el infarto reciente de R.K. exige un ascenso hemodinámico conservador. Dado que el betabloqueo atenúa la frecuencia cardíaca máxima y el miocardio post-infarto es vulnerable a la isquemia, iniciar el ejercicio al 40% de la FCR previene picos peligrosos del doble producto mientras estimula la angiogénesis capilar periférica y la recuperación del volumen sistólico. El ciclismo estacionario elimina riesgos ortopédicos y de caídas, y el entorno climatizado bajo techo previene el estrés térmico extremo de Yuma. Tarjeta Bilingüe: "Mantenga un ritmo de respiración constante y conversacional mientras pedalea, manteniendo su esfuerzo percibido en un nivel moderado y cómodo. Conéntrese en un pedaleo suave y rítmico para apoyar una recuperación cardiovascular segura."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M09_Cardiorespiratory_Audit.pdf

KIN-101 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
