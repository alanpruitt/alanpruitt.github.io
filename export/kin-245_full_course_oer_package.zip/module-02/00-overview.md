## KIN-245 (Module 02 Overview): Exercise Testing & Prescription: Clinical Ergometry & Physiological Assessment

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Clinical Grounding / Contexto Clínico

* **Single Source of Truth (SSoT):** ACSM Guidelines for Exercise Testing and Prescription (12th Ed) and PAGA 2018 (2nd Ed).
* **Equipment Framework:** Lode Corival Ergometer utilizing hyperbolic braking. The work rate (Watts) remains absolutely constant regardless of pedal velocity (RPM), ensuring research-grade reproduction accuracy.
* **Location:** AWC Yuma Campus GY 116.

---

## Targeted Learning Objectives / Tracking de Objetivos

* **[LO 2.2]** Execute precise metabolic calculations and cycle ergometry testing protocols following clinical ACSM guidelines.

---

## El Protocolo de Encuadre Clínico / The Clinical Framing Protocol

1. **Pattern:** Isolate client physiological baselines, body weight parameters, and uncalibrated performance discrepancies.
2. **Rule:** Apply the strict ACSM 12th Edition metabolic equation for gross oxygen consumption during cycle ergometry.
3. **Solve:** Mathematically predict target wattages to systematically guide live participant testing without exceeding clinical risk thresholds.

---

## Part A: Gemini AI Simulation (Digital Sandbox)

## Objective: Math Verification & Pre-Lab Audit

Students must pass their raw physiological parameters through Gemini AI within the clinical delimiter protocol triple-hash delimiters to cross-verify all mathematical calculations before stepping into GY 116.

## ACSM 12th Ed Metabolic Equation for Cycle Ergometry

$$\dot{V}\text{O}_2 = 1.8 \cdot \left(\frac{\text{Work Rate}}{\text{M}}\right) + 3.5 + 3.5$$

Where:

* $\dot{V}\text{O}_2$ = Gross oxygen uptake in $\text{mL} \cdot \text{kg}^{-1} \cdot \text{min}^{-1}$
* **Work Rate** = Power output in $\text{kg} \cdot \text{m} \cdot \text{min}^{-1}$ (Note: $1\text{ Watt} = 6.12\text{ kg} \cdot \text{m} \cdot \text{min}^{-1}$)
* **M** = Client body mass in $\text{kg}$
* $1.8$ = Oxygen cost of loading on a cycle ergometer ($\text{mL} \cdot \text{kg}\cdot\text{m}^{-1}$)
* $3.5$ = Oxygen cost of horizontal pedaling against no load ($\text{mL} \cdot \text{kg}^{-1} \cdot \text{min}^{-1}$)
* $3.5$ = Resting metabolic rate component ($\text{mL} \cdot \text{kg}^{-1} \cdot \text{min}^{-1}$)

## Pre-Lab Target Calculation Prompt Template

Enclose the assignment inputs within the required master delimiters when prompting the AI:

```text
## CLIENT_ID: AWC-245-02
GENDER: Female
AGE: 22
BODY_WEIGHT: 65.0 kg
RESTING_HR: 68 bpm
TARGET_VO2_PEAK_ESTIMATE: 35.0 mL/kg/min
## INSTRUCTIONS: Use the ACSM 12th Edition Cycle Ergometry equation to solve for Work Rate (Watts) at 40%, 60%, and 80% of the target Maximum Oxygen Uptake (VO₂ Max) peak estimate. Show all intermediate algebraic steps.
---

## Mastery Performance Standard / Estándar de Ejecución de Maestría
This lab submission is audited via the strict **10/7/0 Mastery Scale**:
* **10 (Exemplary):** Zero-drift integration. Part A math matches the ACSM model exactly; Part B matrix is completed with no layout gaps; all client case parameters remain enclosed within code delimiters triple-hash delimiters.
* **7 (Competent):** Core metrics are safe and accurate, but minor linguistic omissions, formatting errors, or delimiter line misplacements are flagged.
* **0 (Recalibrate):** Critical calculation errors exceeding +- 5%%, failure to employ the bilingual layout, or leaving client data unwrapped.

---

## KIN-245 Module Discussion: Clinical Case Review & Consultation ###
## The Mission (Initial Post) / La Misión

### Due: Thursday @ 11:59 PM

* **English:** Apply the ACSM 12th Edition Guidelines and PAGA 2018 parameters to the workload values captured in GY 116. Identify technical discrepancies and propose a Corrective Action Plan (CAP).
* **Español (Regional):** Aplicar las Pautas de la ACSM 12ª Edición y los parámetros PAGA 2018 a los valores de carga de trabajo capturados en el GY 116. Identificar discrepancias técnicas y proponer un Plan de Acción Correctiva (CAP).

###
```


## Final Inspection


### Closes: Monday @ 11:59 PM


Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.



## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.

## Discussion

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-245` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-245 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-245 (Module 02)
Client Pattern (Context): A 45-year-old asymptomatic male (80 kg, resting BP 128/82 mmHg, RHR 72 bpm) reports to the climate-controlled kinesiology lab for submaximal Lode Corival cycle ergometer VO2max estimation.
Governing SSoT Rule: Per ACSM's Guidelines for Exercise Testing and Prescription (12th Ed., 2025), pre-participation screening precedes testing, leg cycle ergometry VO2 (mL/kg/min) = (10.8 x Watts / Body Mass kg) + 7, and absolute test termination is mandatory if SBP > 250 mmHg or DBP > 115 mmHg.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-245 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 45-year-old asymptomatic male (80 kg, resting BP 128/82 mmHg, RHR 72 bpm) reports to the climate-controlled kinesiology lab for submaximal Lode Corival cycle ergometer VO2max estimation. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)**), I identified two critical clinical errors. First, Per ACSM's Guidelines for Exercise Testing and Prescription (12th Ed., 2025), pre-participation screening precedes testing, leg cycle ergometry VO2 (mL/kg/min) = (10.8 x Watts / Body Mass kg) + 7, and absolute test termination is mandatory if SBP > 250 mmHg or DBP > 115 mmHg. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)**. For the intervention (**Solve**), Verify pre-test screening clearance and calibrate hyperbolic cadence-independent braking (50 W warm-up -> +25 W every 3-minute stage at 60–70 RPM; at 125 W steady state, estimated VO2 = 23.88 mL/kg/min = 6.8 METs) with Stage-by-Stage HR, RPE, and BP monitoring. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
