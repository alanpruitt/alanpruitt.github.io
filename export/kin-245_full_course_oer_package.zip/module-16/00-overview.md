## KIN-245 (Module 16 Overview): Exercise Testing & Prescription: Clinical Ergometry & Physiological Assessment

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This final evaluation block caps the course track, requiring comprehensive verification of testing proficiency, ergometer metrics tracking, and compliance pipelines under strict assessment conditions. All parameters remain anchored to the **ACSM 12th Ed** and **PAGA 2018 (2nd Ed)**.
* *Español (Regional): Este bloque de evaluación final cierra el curso, requiriendo una verificación completa de la competencia en pruebas, seguimiento de métricas del ergómetro y líneas de cumplimiento bajo condiciones estrictas de evaluación. Todos los parámetros permanecen anclados a **ACSM 12ª Ed** y **PAGA 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.10])** Formulate clinical exercise prescriptions using age-specific physiological markers and apply lifespan safety rules to evaluate pediatric and geriatric physical activity parameters.
* *Español (Regional): Formular prescripciones de ejercicio clínico utilizando marcadores fisiológicos específicos de la edad y aplicar reglas de seguridad del ciclo vital para evaluar los parámetros de actividad física pediátrica y geriátrica.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern / Patrón:** Synthesize assessment trends and operation parameters.
2. **Rule / Regla:** Apply final evaluation guidelines and professional boundaries.
3. **Solve / Solución:** Demonstrate mastery on the live testing floor.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Comprehensive Code Audit / Objetivo: Auditoría Completa de Código

```text
## [PASTE FINAL COMPREHENSIVE SIMULATION MATRIX / MATRIZ DE SIMULACIÓN FINAL AQUÍ]
###
```

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Run final validation routines over the entire workspace archive.
2. Audit metabolic calculation blocks to ensure exact alignment with reference equations.
3. Export the processed summary logs within appropriate structural boundaries.

---

## Part B: Lode Corival Practical Application (Onsite Lab) / Aplicación Práctica en Lode Corival (Laboratorio Presencial)

## Location: AWC Yuma Campus GY 116 (Tuesdays 1:30 PM–2:45 PM / Thursdays 2:45 PM–3:10 PM)

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Execute physical testing markers on the Lode Corival system under timed evaluation conditions.
2. Track heart rate lines and physiological stages continuously to verify baseline markers.
3. Complete exit checklists ensuring proper device shutdown and safety restoration.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

* **10 (Exemplary):** Zero error adjustments across hardware settings and software logs.
* **7 (Competent):** Secure operations, but minor formatting gaps are flagged.
* **0 (Recalibrate):** Safety violations or calculation drift.

---

## KIN-245 Module Discussion: Capstone Debrief & Professional Reflection / Reflexión Profesional

## The Mission (Initial Post) / La Misión


### Due: Thursday @ 11:59 PM

* **English:** Summarize your operational performance insights across the semester track and confirm system readiness for professional deployment.
* **Español (Regional):** Resumir sus conclusiones de desempeño operativo a lo largo del semestre y confirmar la preparación del sistema para el despliegue profesional.



## Final Inspection


### Closes: Monday @ 11:59 PM


Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.



## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-245` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-245 • Module 16)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-245 (Module 16)
Client Pattern (Context): A 45-year-old asymptomatic male (80 kg, resting BP 128/82 mmHg, RHR 72 bpm) reports to the climate-controlled kinesiology lab for submaximal Lode Corival cycle ergometer VO2max estimation.
Governing SSoT Rule: Per ACSM's Guidelines for Exercise Testing and Prescription (12th Ed., 2025), pre-participation screening precedes testing, leg cycle ergometry VO2 (mL/kg/min) = (10.8 x Watts / Body Mass kg) + 7, and absolute test termination is mandatory if SBP > 250 mmHg or DBP > 115 mmHg.
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-245 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 45-year-old asymptomatic male (80 kg, resting BP 128/82 mmHg, RHR 72 bpm) reports to the climate-controlled kinesiology lab for submaximal Lode Corival cycle ergometer VO2max estimation. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)**), I identified two critical clinical errors. First, Per ACSM's Guidelines for Exercise Testing and Prescription (12th Ed., 2025), pre-participation screening precedes testing, leg cycle ergometry VO2 (mL/kg/min) = (10.8 x Watts / Body Mass kg) + 7, and absolute test termination is mandatory if SBP > 250 mmHg or DBP > 115 mmHg. Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025)**. For the intervention (**Solve**), Verify pre-test screening clearance and calibrate hyperbolic cadence-independent braking (50 W warm-up -> +25 W every 3-minute stage at 60–70 RPM; at 125 W steady state, estimated VO2 = 23.88 mL/kg/min = 6.8 METs) with Stage-by-Stage HR, RPE, and BP monitoring. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
