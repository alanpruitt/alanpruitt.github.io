## KIN-101: Mod 01 Required Readings Human Movement Audit

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 01 Required Readings: Human Movement Audit

Lecturas Obligatorias y Recursos de Estudio: Auditoría del Movimiento Humano


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Kinesiology is the scientific study of how the human body moves and adapts to physical activity. When you walk, lift, or work in Yuma's heat, your muscles, bones, heart, and nervous system coordinate to produce safe force. Mastering movement audits helps you spot daily inactivity risks and build sustainable PAGA 2018 routines.


#### En Palabras Sencillas (Norteño Context)

Así como revisas las llantas y el motor de tu troca antes de salir a la carretera en verano, la kinesiología nos enseña a revisar cómo se mueve el cuerpo humano todos los días. Si los términos técnicos se ponen pesados, concéntrate primero en la diferencia entre ejercicio planeado y movimiento diario según PAGA 2018.


### Required SSoT Text & Professional Guidelines

Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • Chapter 2 (Physical Activity Fundamentals for Adults & Special Populations).

- PAGA Course Navigation Tool (Interactive SSoT Hub): PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev)
- PAGA Chapters & Official Benchmark Lookup ("PAGA" Tool): PAGA 2018 2nd Edition Official Chapters & Manual ("PAGA" in Course Navigation Bar • paga2018.dev/chapters)
- Interactive PAGA Clinical Calculators ("PAGA" in Left Menu): Activity Audit (2-for-1 Rule) • Intensity & METs • Clinical Case Coach (Pattern / Rule / Solve)
- Required Focus: Chapter 2 (Physical Activity Benchmarks for Adults & Special Populations, pp. 28–45). Capítulo 2: Normas de actividad física para adultos y poblaciones especiales (págs. 28–45).
- Official Journal Article (MSSE): Quantity and Quality of Exercise Position Stand (Garber et al., 2011)
- Canvas Course File Download: Quantity_and_Quality_of_Exercise_for_Developing.26-002.pdf

### Regional Focus: Overcoming Inactivity Barriers in the Desert Southwest

Enfoque Regional: Barreras de Inactividad Física y Clima Extremo en Yuma

In Yuma County and regional border agricultural communities, ambient summer temperatures routinely exceed 105°F (40.5°C). While sedentary behavior elevates chronic cardiometabolic risks, unadapted outdoor exertion during peak solar hours introduces severe heat illness dangers. Kinesiology practitioners must bridge this gap by prescribing accessible, climate-controlled indoor physical activity regimens that fulfill federal PAGA targets without heat injury risk.

En el condado de Yuma y las comunidades agrícolas del suroeste, el calor extremo del verano supera constantemente los 40.5°C (105°F). Aunque el sedentarismo eleva el riesgo de enfermedades cardiometabólicas, el ejercicio al aire libre en horas de calor extremo genera peligro de golpe de calor. Los profesionales de la kinesiología deben prescribir actividad física en interiores climatizados que cumplan con las normas federales PAGA sin riesgos térmicos.


### Reading 1: Federal Physical Activity Guidelines (PAGA 2018 SSoT)

Lectura 1: Normas Federales de Actividad Física y Dosificación Semanal


#### Step 1: Aerobic and Muscle-Strengthening Benchmarks

Metas Semanales de Actividad Aeróbica y Fortalecimiento Muscular

For substantial health benefits, adults must accumulate at least 150 to 300 minutes per week of moderate-intensity aerobic physical activity , or 75 to 150 minutes per week of vigorous-intensity aerobic physical activity (or an equivalent combination of both). Furthermore, adults must perform muscle-strengthening activities involving all major muscle groups on 2 or more days per week .

Para obtener beneficios sustanciales para la salud, los adultos deben acumular al menos 150 a 300 minutos semanales de actividad aeróbica moderada , o 75 a 150 minutos de actividad vigorosa . Además, deben realizar actividades de fortalecimiento muscular que involucren los principales grupos musculares en 2 o más días a la semana .


#### Step 2: Sedentary Physiology and Independent Cardiometabolic Risk

Fisiología del Sedentarismo y Riesgo Cardiometabólico Independiente

Prolonged sedentary time (sitting > 8 hours/day) independently elevates all-cause mortality, cardiovascular disease, and Type 2 diabetes risk, even among individuals who complete 30 minutes of daily exercise. Replacing uninterrupted sitting with light-intensity movement breaks reduces arterial stiffness and improves postprandial glycemic clearance.

Permanecer sentado por periodos prolongados (> 8 horas/día) eleva de forma independiente la mortalidad por todas las causas y el riesgo cardiovascular, incluso si se realiza ejercicio estructurado. Interrumpir el sedentarismo con pausas activas mejora la función arterial y el control de la glucosa.


### Key Terminology / Glosario Clave

Any bodily movement produced by skeletal muscles that results in energy expenditure above resting levels (> 1.5 METs), encompassing occupational, domestic, transportation, and leisure domains.

Cualquier movimiento corporal producido por los músculos esqueléticos que genere gasto energético por encima del reposo (> 1.5 METs).

A planned, structured, repetitive, and intentional subcategory of physical activity specifically aimed at improving or maintaining physical fitness and functional capacity.

Subcategoría planificada, estructurada, repetitiva y con el propósito de mejorar o mantener la condición física.

The ratio of working metabolic rate to resting metabolic rate (1 MET equals approximately 3.5 mL of oxygen consumed per kilogram of body weight per minute, or 1 kcal per kilogram per hour). Moderate intensity ranges from 3.0 to 5.9 METs; vigorous intensity is 6.0 METs or higher.

Razón entre la tasa metabólica de trabajo y la de reposo (1 MET equivale aproximadamente a 3.5 mL de oxígeno consumido por kilogramo de peso corporal por minuto). Moderada = 3.0–5.9 METs; Vigorosa ≥ 6.0 METs.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of core PAGA guidelines before starting Discussion 01 and Lab 01:

English Response: (1) 150 to 300 minutes per week of moderate-intensity aerobic physical activity (or 75 to 150 minutes of vigorous-intensity), and (2) Muscle-strengthening physical activities of moderate or greater intensity involving all major muscle groups on 2 or more days per week.

Respuesta en Español: (1) 150 a 300 minutos semanales de actividad aeróbica moderada (o 75 a 150 min de actividad vigorosa), y (2) Fortalecimiento muscular de intensidad moderada o mayor en todos los grupos musculares principales en 2 o más días por semana.

English Response: Prolonged uninterrupted sitting suppresses muscular lipoprotein lipase (LPL) activity and reduces insulin-stimulated glucose uptake, elevating cardiovascular and mortality risks even in individuals who meet standard exercise guidelines.

Respuesta en Español: Estar sentado por periodos prolongados suprime la actividad de la lipoproteína lipasa (LPL) muscular y reduce la captación de glucosa, aumentando el riesgo cardiovascular independientemente del ejercicio que se realice.

English Response: Moderate-intensity physical activity is defined as Outcome 3.0: to 5.9 METs (e.g., brisk walking at 3.0 to 4.0 mph, recreational cycling), requiring noticeably increased breathing and heart rate while still permitting conversational speech.

Respuesta en Español: La actividad física moderada se define en el rango de Outcome 3.0: a 5.9 METs (caminata rápida a 4.8–6.4 km/h, ciclismo recreativo), elevando la frecuencia cardíaca de forma perceptible pero permitiendo hablar.


### AI Simulation Workspace • PAGA Movement Audit Simulation

Copy the prompt below into Gemini to test your ability to audit weekly movement logs and identify sedentary risk factors:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-101 Module 01 Movement Audit Tool Box ###:
Role: Socratic Kinesiology Mentor and Public Health Movement Specialist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Audit the student's client movement log enclosed within triple-hashes (###) below.
Step 2: Quantify weekly moderate/vigorous aerobic minutes and muscle-strengthening days against PAGA benchmarks.
Step 3: Evaluate the client's daily sedentary hours (>8 hrs/day) and identify cardiometabolic risk markers.
Step 4: Formulate a climate-adapted physical activity prescription for Yuma County's high-heat summer environment.
Step 5: Keep all inputs wrapped inside delimiters.

Client Data Input ###:
Client Weekly Aerobic Minutes: [Insert Minutes]
Client Weekly Resistance Training Days: [Insert Days]
Client Daily Sitting Time: [Insert Hours/Day]
Client Occupational Environment: [Insert Setting, e.g., Desk Worker or Field Harvester]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 01 (Mod 01 Required Readings: Human Movement Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Lecturas Obligatorias: Auditoría del Movimiento Humano


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) • Capítulo 2 (Fundamentos de Actividad Física para Adultos y Poblaciones Especiales).

- Herramienta "PAGA" en la Barra de Navegación del Curso: Herramienta Interactiva PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev)
- Enfoque Obligatorio: Capítulo 2: Metas de actividad física para adultos y poblaciones especiales (págs. 28–45).

### Conceptos Científicos Centrales


#### Step 1: Normas Federales de Actividad Física (PAGA 2018)

Los adultos necesitan de 150 a 300 minutos semanales de actividad aeróbica moderada (o 75 a 150 min de actividad vigorosa), más actividades de fuerza muscular en 2 o más días por semana.


#### Step 2: Riesgo del Sedentarismo

El sedentarismo prolongado (> 8 horas al día) eleva de manera independiente la mortalidad y las enfermedades cardiovasculares, por lo que interrumpir el tiempo sentado con movimiento es prioritario.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para asegurar un entorno de aprendizaje accesible, inclusivo y sin barreras en nuestra comunidad estudiantil.

KIN-101 • Module 01 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 01:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 01)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
