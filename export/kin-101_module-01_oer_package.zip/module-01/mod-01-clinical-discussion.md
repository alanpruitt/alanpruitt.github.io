## KIN-101: Mod 01 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 01 Discussion: Meet Your Classmates & Movement Goals

Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Movimiento


### In Plain English: Discussion Guide

Before you read the details below, here is the short version: This discussion is how we meet each other and connect your personal movement goals to federal physical activity guidelines. You will introduce yourself, pick a career track that interests you, and share how you plan to apply the 150-minute weekly movement rule in Yuma County.


#### En Palabras Sencillas (Contexto Norteño)

Es como la primera plática en la carne asada con gente nueva: cada quien dice de dónde es, qué carrera busca y cómo le gusta moverse aquí en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en presentarte con confianza y compartir tu meta de actividad.


### Discussion Schedule & Deadlines / Horario y Fechas Límite

- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST (150-word minimum (150+ words))
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST (Reply to TWO (2) classmates for our Week 1 Self-Introduction)
- Bilingual Participation Welcome / Participación Bilingüe: You are warmly encouraged to write in English, Spanish, or both!

### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Physical Therapy, Athletic Training, Nursing, or Outpatient Rehabilitation.

K–12 Physical Education, Community Recreation, or Public Health Promotion.

Collegiate/High School Coaching, Strength & Conditioning, or Personal Training.


### Initial Post Requirements (Due Thursday @ 11:59 PM MST • 100–150 Words)

- Community Introduction: Share your name (and preferred name), where you are from, your favorite way to move or fuel your body, and your career goal after AWC.
- Step 1: Pattern Recognition (Context): Identify one common real-world barrier to healthy movement, nutrition, or safe exercise you see in Yuma County / Imperial Valley (such as summer heat, long shifts, or fear of injury).
- Step 2: Rule Application (SSoT Benchmark): Cite one foundational rule from our course Source of Truth (Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.)) that addresses this barrier.
- Step 3: Solve & Personal Action Step: Propose one realistic weekly habit or coaching strategy you want to master this semester, plus a 1-sentence bilingual takeaway (EN / ES).
- Peer Engagement (Due Sunday @ 11:59 PM MST): Reply to at least TWO (2) classmates , welcoming them to the class and connecting with their career track or weekly goal.

### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track: Track 1 (Clinical & Allied Health Path)

Hi everyone! My name is Mateo (I go by Matt), and I was born and raised here in Somerton, AZ. My favorite way to stay active is playing evening pickup basketball and lifting weights at the gym after work. My career goal after AWC is to transfer into a Physical Therapy Assistant (PTA) program so I can help older adults and agricultural workers in Yuma County recover from knee and back injuries.

Pattern / Rule / Solve Application: In my family, the biggest movement barrier ( Pattern ) is our 110°F+ summer heat and long work shifts that leave people exhausted on the couch. According to the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) ( Rule ), adults need 150 to 300 minutes of moderate-intensity aerobic activity plus at least 2 days of muscle-strengthening exercise every week—and every bout counts! My practical strategy ( Solve ) is breaking movement into two 15-minute brisk walks (one at 6:00 AM before the sun gets heavy and one indoors after dinner) plus two 15-minute bodyweight resistance sessions on Tuesdays and Thursdays.

Bilingual Takeaway (EN / ES): EN: "Small 15-minute bouts of brisk walking and twice-weekly strength training beat the Yuma heat and fulfill the PAGA 2018 150-minute health standard!" ES: "¡Caminatas cortas de 15 minutos y dos días de fuerza por semana vencen el calor de Yuma y cumplen la meta federal de 150 minutos de PAGA 2018!"


### Evaluation Rubric (10 Points Total • 10/7/0 Mastery Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 01 (Mod 01 Discussion: Meet Your Classmates & Movement Goals)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Movimiento


### Requisitos de la Publicación Inicial (Jueves 11:59 PM MST • 100–150 Palabras) y 2 Respuestas (Domingo 11:59 PM MST)

- Presentación Personal: Comparta su nombre (y cómo prefiere que le llamen), de dónde es, cómo le gusta mantenerse activo y su meta profesional después de AWC.
- Step 1: Patrón (Contexto Regional): Identifique una barrera común en el condado de Yuma / Valle Imperial (como el calor extremo o turnos largos de trabajo).
- Step 2: Regla (Fuente de Verdad SSoT): Cite una regla fundamental de nuestra Fuente de Verdad (Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.)).
- Step 3: Solución y Meta Semanal: Proponga un hábito práctico para este semestre y una frase de aprendizaje bilingüe (EN / ES).
- Interacción con Compañeros: Responda al menos a DOS (2) compañeros antes del domingo a las 11:59 PM MST. ¡Puede escribir en inglés, español o ambos!
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 01)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
