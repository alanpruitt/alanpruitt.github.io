======================================================================
RECLAIMING OUR TIME: CANVAS LMS INGEST & FACILITATOR PACKAGE
======================================================================
This bundle provides direct ingestion artifacts for Canvas LMS.

PACKAGE CONTENTS:
1. reclaiming-our-time-canvas.imscc
   - Native Canvas Common Cartridge (Modules 00-05, Capstone, Discussion)
2. canvas_speedgrader_rubric.json
   - 4-criterion, 20-point Sovereign Auditor Rubric (Canvas native JSON format)
3. canvas_speedgrader_rubric.csv
   - SpeedGrader Rubric in spreadsheet format for bulk-import tools
4. canvas_assignment_spec.xml
   - SpeedGrader submission definition (allowed attempts, point total)

INSTRUCTIONS FOR CANVAS INGESTION:
1. In your Canvas course shell, go to Settings > Import Course Content.
2. Under "Content Type", select: Common Cartridge 1.x Package.
3. Choose the file: reclaiming-our-time-canvas.imscc.
4. Select "All content" and click "Import".
5. In SpeedGrader, attach the 20-point Sovereign Auditor Rubric directly
   to the Summative Capstone Assignment.
======================================================================
