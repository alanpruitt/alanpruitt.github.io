# HLTH-150: Mod 01 Overview Daily Calorie And Macronutrient Balance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Nutrition for Sports and Exercise


## Mod 01 Overview: Daily Calorie & Macronutrient Balance


### Welcome to Module 01: Daily Calorie & Macronutrient Balance

Welcome to HLTH-150! This week, we establish foundational metabolic math using our primary Single Sources of Truth (SSoTs): the Dietary Guidelines for Americans (DGA / USDA) and the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) . Rather than following commercial wellness fads or marketing hype, you will learn to calculate Basal Metabolic Rate (BMR) and Total Daily Energy Expenditure (TDEE) with mathematical precision.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify energy deficit and surplus patterns, apply federal Acceptable Macronutrient Distribution Ranges (AMDR) and protein standards (1.2–2.0 g/kg for active bodies), and design practical, heat-adapted whole-food meal strategies for active individuals and agricultural workers in Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, August 18, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, August 20, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, August 23, 2026, at 11:59 PM MST
- Lab 01 Direct Submission / Entrega de Laboratorio: Monday, August 24, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 01 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Calculate Basal Metabolic Rate (BMR) using the Mifflin-St Jeor equation and establish Total Daily Energy Expenditure (TDEE) across diverse physical activity tiers. Calcular la Tasa Metabólica Basal (BMR) mediante la fórmula de Mifflin-St Jeor y determinar el Gasto Energético Diario Total (TDEE).
- CLO 2 (Rule Application): Apply federal DGA AMDR percentages (45–65% Carbohydrates, 10–35% Protein, 20–35% Fats) and physical activity protein targets (1.2–2.0 g/kg) to balance metabolic energy intake. Aplicar los rangos AMDR federales y las metas de proteína en personas activas para equilibrar la ingesta energética.
- CLO 3 (Problem Solving): Formulate an evidence-based, climate-adapted whole-food nutrition and hydration protocol for active populations and agricultural workers operating in Yuma County's extreme summer heat. Diseñar un protocolo nutricional y de hidratación basado en alimentos reales y adaptado al calor extremo del condado de Yuma.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit energy balance and macronutrients through your chosen professional track:

Auditing energy availability, lean mass preservation, and metabolic deceleration in sedentary post-rehabilitation patients in outpatient clinical settings.

Prescribing accessible, cost-effective whole-food macronutrient distributions and electrolyte hydration for field workers and families in Yuma County.

Calculating high-volume glycogen replenishment (5–8 g/kg CHO) and tissue remodeling protein targets (1.6–2.2 g/kg) for collegiate and tactical athletes.


### Module 01 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Energy Balance, AMDR Ranges & DGA Federal Standards
- Discussion Board 01: Peer Self-Introduction & Community Connection
- Lab Assignment 01: Energy Balance, Macronutrient Audit & Gemini AI Tool Box
- Module 01 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Overview: Daily Calorie & Macronutrient Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Módulo 01 Visión General: Balance Energético y Macronutrientes


### Bienvenido al Módulo 01: Balance Energético, Matemáticas Metabólicas y Alimentos Reales

¡Bienvenido a HLTH-150! Esta semana estableceremos los cálculos metabólicos fundamentales utilizando nuestras Fuentes Únicas de Verdad (SSoT): las Guías Alimentarias para los Estadounidenses (DGA / USDA) y las Pautas de Actividad Física (PAGA 2018, 2.ª edición) . En lugar de seguir modas comerciales o suplementos costosos, aprenderá a calcular la Tasa Metabólica Basal (BMR) y el Gasto Energético Total (TDEE) con precisión científica.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará patrones de balance calórico, aplicará los rangos AMDR federales y las metas de proteína (1.2 a 2.0 g/kg), y diseñará estrategias de alimentación e hidratación adaptadas al calor extremo del condado de Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 18 de agosto de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 20 de agosto de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 23 de agosto de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 01: Lunes, 24 de agosto de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Calcular el BMR mediante la ecuación de Mifflin-St Jeor y establecer el TDEE en diferentes niveles de actividad física.
- CLO 2 (Regla): Aplicar los porcentajes AMDR federales (45–65% carbohidratos, 10–35% proteína, 20–35% grasas) y metas de proteína (1.2–2.0 g/kg).
- CLO 3 (Solución): Formular un protocolo nutricional con alimentos reales y de hidratación adaptado al clima de alto calor del condado de Yuma.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará el balance energético a través de su ruta profesional:

Auditoría de balance calórico y preservación de masa magra en pacientes sedentarios en rehabilitación.

Prescripción de alimentos integrales económicos e hidratación para trabajadores agrícolas de Yuma.

Cálculo de reposición de glucógeno y metas proteicas para atletas universitarios y tácticos.


### Ruta de Aprendizaje del Módulo 01

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Balance Energético, Rangos AMDR y Pautas DGA
- Foro de Discusión 01: Presentación Personal y Conexión Comunitaria
- Laboratorio 01: Balance Energético, Auditoría de Macronutrientes y Gemini IA
- Comprobación de Conocimientos y Resumen del Módulo 01

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 01 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 01 Required Readings: Daily Calorie & Macronutrient Balance →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 01 Discussion: Meet Your Classmates & Real-Food Goals →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 01 Coaching Sprint: Building a Balanced Real-Food Plate →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 01 Lab: Daily Calorie & Macronutrient Balance Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 01 Summary & Wrap-Up: Daily Calorie & Macronutrient Balance →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
