# HLTH-150: Mod 01 Clinical Discussion

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

HLTH-150 • Foundations of Nutrition for Sport & Exercise / Fundamentos de Nutrición para el Deporte y el Ejercicio


## Mod 01 Discussion: Meet Your Classmates & Real-Food Goals

Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Alimentos Reales


### In Plain English: Discussion Guide

Before you read the details below, here is the short version: This discussion is how we meet each other and connect everyday eating habits to the 2025–2030 Dietary Guidelines for Americans. You will introduce yourself, choose your career track, and share one practical whole-food nutrition goal for active living in Yuma County.


#### En Palabras Sencillas (Contexto Norteño)

Es como sentarse a la mesa con compañeros nuevos: platicamos de dónde somos, qué carrera estudiamos y cómo armar un plato con comida real y buena hidratación para aguantar el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en presentarte y compartir un cambio sencillo de comida real.


### Discussion Schedule & Deadlines / Horario y Fechas Límite

- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST (150-word minimum (150+ words))
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST (Reply to TWO (2) classmates for our Week 1 Self-Introduction)
- Bilingual Participation Welcome / Participación Bilingüe: You are warmly encouraged to write in English, Spanish, or both!

### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Nursing, Dietetics, Physical Therapy, or Outpatient Wellness Counseling.

Community Nutrition, School Health, or Agricultural Workforce Wellness in Yuma County.

Athletic Coaching, Strength & Conditioning, or Tactical/First-Responder Fueling.


### Initial Post Requirements (Due Thursday @ 11:59 PM MST • 100–150 Words)

- Community Introduction: Share your name (and preferred name), where you are from, your favorite way to move or fuel your body, and your career goal after AWC.
- Step 1: Pattern Recognition (Context): Identify one common real-world barrier to healthy movement, nutrition, or safe exercise you see in Yuma County / Imperial Valley (such as summer heat, long shifts, or fear of injury).
- Step 2: Rule Application (SSoT Benchmark): Cite one foundational rule from our course Source of Truth (2025–2030 Dietary Guidelines for Americans (DGA, Real-Food Focus) & USDA AMDR Standards) that addresses this barrier.
- Step 3: Solve & Personal Action Step: Propose one realistic weekly habit or coaching strategy you want to master this semester, plus a 1-sentence bilingual takeaway (EN / ES).
- Peer Engagement (Due Sunday @ 11:59 PM MST): Reply to at least TWO (2) classmates , welcoming them to the class and connecting with their career track or weekly goal.

### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track: Track 2 (Community & Public Health Path)

Hello classmates! My name is Valeria, and I am from San Luis, AZ. I love morning runs along the levee and cooking traditional meals with my grandmother on weekends. I am taking HLTH-150 as part of my Community Health degree so I can teach practical, budget-friendly nutrition to families and field workers here in Yuma County.

Pattern / Rule / Solve Application: A common nutritional challenge I see in our community ( Pattern ) is relying on high-sugar energy drinks and fast food during busy workdays, which causes mid-afternoon energy crashes. Under the 2025–2030 Dietary Guidelines for Americans (DGA) and USDA AMDR standards ( Rule ), daily calories should come from nutrient-dense whole foods balanced at 45–65% complex carbohydrates, 10–35% protein, and 20–35% healthy fats, while keeping added sugars under 10%. My practical intervention ( Solve ) is packing a real-food lunch box with pinto beans, grilled chicken, corn tortillas, avocado, and chilled water with lime and a pinch of salt to sustain energy and hydration in Yuma's heat.

Bilingual Takeaway (EN / ES): EN: "Balancing traditional whole foods like beans, corn tortillas, and lean protein within USDA AMDR ranges delivers steady all-day energy without added-sugar crashes!" ES: "¡Equilibrar alimentos reales tradicionales como frijoles, tortillas de maíz y proteína magra dentro de los rangos AMDR brinda energía constante todo el día sin bajones de azúcar!"


### Evaluation Rubric (10 Points Total • 10/7/0 Mastery Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Discussion: Meet Your Classmates & Real-Food Goals)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

HLTH-150 • Fundamentos de Nutrición para el Deporte y el Ejercicio


## Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Alimentos Reales


### Requisitos de la Publicación Inicial (Jueves 11:59 PM MST • 100–150 Palabras) y 2 Respuestas (Domingo 11:59 PM MST)

- Presentación Personal: Comparta su nombre (y cómo prefiere que le llamen), de dónde es, cómo le gusta mantenerse activo y su meta profesional después de AWC.
- Step 1: Patrón (Contexto Regional): Identifique una barrera común en el condado de Yuma / Valle Imperial (como el calor extremo o turnos largos de trabajo).
- Step 2: Regla (Fuente de Verdad SSoT): Cite una regla fundamental de nuestra Fuente de Verdad (Guías Alimentarias para los Estadounidenses 2025–2030 (DGA, Enfoque en Alimentos Reales) y Rangos AMDR).
- Step 3: Solución y Meta Semanal: Proponga un hábito práctico para este semestre y una frase de aprendizaje bilingüe (EN / ES).
- Interacción con Compañeros: Responda al menos a DOS (2) compañeros antes del domingo a las 11:59 PM MST. ¡Puede escribir en inglés, español o ambos!
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

HLTH-150 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:
