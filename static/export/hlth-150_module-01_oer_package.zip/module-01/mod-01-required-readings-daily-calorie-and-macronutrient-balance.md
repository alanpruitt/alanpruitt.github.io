# HLTH-150: Mod 01 Required Readings Daily Calorie And Macronutrient Balance

**Academic Source of Truth (SSoT):** 2025–2030 Dietary Guidelines for Americans ("Real Food" Focus)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 01 Required Readings: Daily Calorie & Macronutrient Balance

Lecturas Obligatorias y Recursos de Estudio: Balance Energético y Distribución de Macronutrientes


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Energy balance is the relationship between the calories you eat from whole foods and the energy your body burns each day. Macronutrients (carbohydrates, proteins, and fats) provide distinct fuel and repair roles under the 2025–2030 Dietary Guidelines. Auditing daily energy balance lets you support physical training without nutrient deficits.


#### En Palabras Sencillas (Norteño Context)

Manejar tus calorías y macronutrientes es como cuadrar el presupuesto de la quincena y la gasolina de tu troca para llegar a tiempo. Si los términos técnicos se ponen pesados, concéntrate primero en las proporciones de carbohidratos, proteínas y grasas reales según las Guías Alimentarias 2025–2030.


### Required SSoT Text & Federal Guidelines

Single Source of Truth (SSoT): Dietary Guidelines for Americans (DGA / USDA) • Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • Dietary Reference Intakes (DRI) Macronutrient Energy Distribution.

- Official Guidelines Portal: Dietary Guidelines for Americans Official Portal (DGA)
- Canvas Course Download: Dietary_Guidelines_for_Americans_Full_Manual.pdf
- Nutrition and Athletic Performance Consensus: ACSM / AND / DC Joint Position Stand: Nutrition and Athletic Performance

### Regional Focus: Energy Balance & Hydration in the Desert Southwest

Enfoque Regional: Balance Energético y Termorregulación en el Condado de Yuma

In Yuma County and regional agricultural border communities, field harvesters, tactical athletes, and active individuals operate under ambient summer temperatures exceeding 105°F (40.5°C). High thermal strain elevates sweat rates and accelerates glycogen depletion. Rather than relying on commercial energy drinks or processed sports supplements, kinesiology and nutrition professionals emphasize whole-food carbohydrates (fruits, beans, whole grains), complete proteins, and electrolyte hydration to maintain cellular hydration and metabolic homeostasis.

En el condado de Yuma y las comunidades agrícolas fronterizas, los trabajadores de campo y las personas activas operan bajo temperaturas de verano que superan los 40.5°C (105°F). El estrés térmico acelera la sudoración y la depleción de glucógeno. En lugar de depender de suplementos comerciales o bebidas energéticas procesadas, los profesionales enfatizan el uso de alimentos reales (frutas, frijoles, granos enteros), proteínas completas e hidratación con electrólitos para mantener la homeostasis metabólica.


### Reading 1: Metabolic Math & Total Daily Energy Expenditure (TDEE)

Lectura 1: Matemáticas Metabólicas y Gasto Energético Diario Total


#### Step 1: Basal Metabolic Rate (BMR) via the Mifflin-St Jeor Equation

Tasa Metabólica Basal mediante la Ecuación de Mifflin-St Jeor

Basal Metabolic Rate (BMR) represents the baseline energy required to sustain vegetative cellular function at rest. The Mifflin-St Jeor equation calculates BMR with high clinical validity across diverse populations:

Total Daily Energy Expenditure (TDEE) is calculated by multiplying BMR by a validated Physical Activity Level (PAL) multiplier: Sedentary ($1.20$), Moderately Active ($1.55$), or Very Active/Heavy Agricultural Labor ($1.725\text{--}1.90$).

El Gasto Energético Diario Total (TDEE) se obtiene multiplicando el BMR por el factor de actividad física (PAL): Sedentario ($1.20$), Moderadamente Activo ($1.55$) o Muy Activo / Trabajo Agrícola Pesado ($1.725\text{ a }1.90$).


#### Step 2: Acceptable Macronutrient Distribution Ranges (AMDR Standards)

Rangos Aceptables de Distribución de Macronutrientes (AMDR)

The federal DGA establishes AMDR percentages to reduce chronic cardiometabolic disease risk while ensuring adequate essential micronutrient delivery:

- Carbohydrates: 45% to 65% of total daily calories (3.0–8.0 g/kg/day scaled to exercise volume).
- Proteins: 10% to 35% of total daily calories (0.8 g/kg RDA baseline; 1.2–2.0 g/kg for active individuals).
- Dietary Fats: 20% to 35% of total daily calories (prioritizing mono- and polyunsaturated fatty acids).

### Reading 2: Energy Availability (EA) & REDs Prevention

Lectura 2: Disponibilidad Energética y Prevención del Síndrome REDs

Energy Availability (EA) is defined as the amount of dietary energy remaining for essential biological functions (cellular repair, thermoregulation, immune function, reproduction, bone remodeling) after subtracting exercise energy expenditure (EEE) from total daily energy intake (EI), normalized to Fat-Free Mass (FFM):

- Optimal Energy Availability: $\ge 45\text{ kcal/kg FFM/day}$ supports robust metabolic, endocrine, and immune health.
- Subclinical Energy Deficiency: $30\text{--}44\text{ kcal/kg FFM/day}$ requires monitoring to avoid chronic hormonal downregulation.
- Low Energy Availability (LEA): $< 30\text{ kcal/kg FFM/day}$ triggers Relative Energy Deficiency in Sport (REDs), causing amenorrhea, bone demineralization, and metabolic suppression.

### Key Terminology / Glosario Clave

The federal percentage range of intake for carbohydrates, proteins, and fats associated with reduced risk of chronic disease while ensuring adequate essential micronutrient intake.

Rango porcentual de ingesta de carbohidratos, proteínas y grasas asociado con la reducción de enfermedades crónicas y el aporte adecuado de nutrientes esenciales.

BMR is the minimum caloric expenditure required to maintain vegetative cellular life; TDEE is total daily caloric expenditure factoring in physical activity level (PAL) multipliers.

El BMR es el gasto calórico mínimo para mantener las funciones vitales en reposo; el TDEE es el gasto calórico total diario al multiplicar el BMR por el factor de actividad física.

A clinical syndrome of impaired physiological function caused by low energy availability ($< 30\text{ kcal/kg FFM/day}$), affecting metabolic rate, menstrual function, bone density, immunity, and cardiovascular health.

Síndrome clínico de alteración funcional causado por baja disponibilidad energética ($< 30\text{ kcal/kg FFM/día}$), afectando el metabolismo, la salud ósea, la inmunidad y el rendimiento.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Metabólicos

Select each question below to confirm your understanding of energy balance equations before starting Discussion 01 and Lab 01:

English Response: Under federal Dietary Guidelines (DGA / USDA): Carbohydrates: 45%–65% , Proteins: 10%–35% , and Dietary Fats: 20%–35% of total daily caloric intake.

Respuesta en Español: Según las Guías Alimentarias federales (DGA / USDA): Carbohidratos: 45% a 65% , Proteínas: 10% a 35% y Grasas: 20% a 35% del total calórico diario.

English Response: TDEE is calculated by multiplying BMR (derived via the Mifflin-St Jeor formula) by a Physical Activity Level (PAL) multiplier representing occupational and exercise movement (ranging from 1.20 for sedentary up to 1.90 for heavy labor).

Respuesta en Español: El TDEE se calcula multiplicando el BMR (obtenido con la fórmula de Mifflin-St Jeor) por el factor de actividad física (PAL), que va de 1.20 en personas sedentarias hasta 1.90 en trabajos físicos pesados.

English Response: Energy Availability falling below 30 kcal/kg Fat-Free Mass (FFM)/day represents the critical threshold where the body suppresses basal metabolic rate, reproductive hormone production, and bone remodeling.

Respuesta en Español: Una disponibilidad energética inferior a 30 kcal/kg de Masa Libre de Grasa (FFM)/día constituye el umbral crítico que desencadena el síndrome REDs, suprimiendo el metabolismo basal y la síntesis ósea.


### AI Simulation Workspace • Energy Balance Simulation

Copy the prompt below into Gemini to audit client metabolic math, AMDR distribution, and heat-adapted whole-food meal planning:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: HLTH-150 Module 01 Energy Balance Tool Box ###:
Role: Sports Nutritionist and Clinical Dietetic Mentor in the Narrator voice.
SSoT: Dietary Guidelines for Americans (DGA / USDA) and Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Audit the student's client biometric profile enclosed within triple-hashes (###) below.
Step 2: Verify the Basal Metabolic Rate (BMR) calculation using the Mifflin-St Jeor equation and compute Total Daily Energy Expenditure (TDEE).
Step 3: Audit the macronutrient distribution against federal AMDR percentage ranges (CHO 45-65%, PRO 10-35%, FAT 20-35%) and verify protein targets in g/kg.
Step 4: Formulate an evidence-based, heat-adapted whole-food meal and hydration protocol tailored to Yuma County's high-heat climate.
Step 5: Keep all client inputs wrapped within triple-hash (###) delimiters.

Client Data Input ###:
Client Age: [Insert Age]
Biological Sex: [Insert Sex]
Height: [Insert cm or inches]
Weight: [Insert kg or lbs]
Physical Activity Level: [Sedentary | Moderate | Heavy Labor]
Daily Energy Intake: [Insert Total Daily Calories]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in HLTH-150 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: DGA 2025-2030 (Dietary Guidelines for Americans, Real Food Focus) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de HLTH-150 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: DGA 2025-2030 (Guías Alimentarias para los Estadounidenses, Comida Real) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: HLTH-150 • Module 01 (Mod 01 Required Readings: Daily Calorie & Macronutrient Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (DGA 2025-2030 | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in HLTH-150 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de HLTH-150 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

HLTH-150 • Nutrición para el Deporte y el Ejercicio


## Lecturas Obligatorias: Balance Energético y Distribución de Macronutrientes


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Guías Alimentarias para los Estadounidenses (DGA / USDA) • Pautas de Actividad Física (PAGA 2018, 2.ª edición) • Ingestas Dietéticas de Referencia (DRI) para Macronutrientes.

Guías Alimentarias para los Estadounidenses: Macronutrientes y Densidad Nutricional

- Postura Conjunta ACSM / AND / DC: Nutrición y Rendimiento Atlético (MSSE)

### Conceptos Científicos Centrales


#### Step 1: Matemáticas Metabólicas (BMR y TDEE)

La Tasa Metabólica Basal (BMR) se calcula mediante la ecuación de Mifflin-St Jeor. El Gasto Energético Diario Total (TDEE) multiplica el BMR por factores de actividad física (PAL), ajustando las calorías para el trabajo o el deporte.


#### Step 2: Rangos AMDR y Disponibilidad Energética

Los rangos AMDR (Carbohidratos 45–65%, Proteína 10–35%, Grasas 20–35%) protegen la salud cardiometabólica. Mantener una disponibilidad energética $\ge 45\text{ kcal/kg FFM/día}$ evita el síndrome REDs en personas activas.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de HLTH-150 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

HLTH-150 • Module 01 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 01:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
