## HLTH-150: LAB 01 - ENERGY & HYDRATION / ENERGÍA E HIDRATACIÓN 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## > ###  Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (sports nutrition requirements, hydration audits, and energy demands).

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This module establishes the physiological baselines of energy metabolism and hydration strategies for active populations. All nutritional baselines and caloric equations align exclusively with our dual SSoT: the current **U.S. Dietary Guidelines for Americans** and the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* *Español (Regional): Este módulo establece las bases fisiológicas del metabolismo energético y las estrategias de hidratación para poblaciones activas. Todas las líneas de referencia nutricionales se alinean exclusivamente con nuestra doble Fuente Única de Verdad (SSoT): las **Pautas Dietéticas para Estadounidenses** vigentes y las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.2], [LO 2.3])** Describe the physiological relationship between metabolism, nutrition, and physical activity; Identify the importance and impact of hydration and electrolytes on performance recovery and thermoregulation.
* *Español (Regional) ([LO 2.2], [LO 2.3]): Describir la relación fisiológica entre el metabolismo, la nutrición y la actividad física; Identificar la importancia y el impacto de la hidratación y los de los electrolitos en la recuperación del rendimiento y la termorregulación.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Identify personal metabolic trends, activity fluctuations, and timing gaps in daily intake patterns.
2. **Rule / Regla:** Apply formal Acceptable Macronutrient Distribution Ranges (AMDR) and fluid rules established by the current federal U.S. Dietary Guidelines.
3. **Solve / Solución:** Formulate an evidence-based nutrient timing and fluid schedule designed to balance energy systems safely.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Nutrient Timing Verification & Macro Auditing

Students will initialize their nutritional modeling tools inside the digital sandbox workspace using the data wrapped below.

```text
## CLIENT_PROFILE:
- Age: 19 years old (First-year community college athlete)
- Current Activity: 45 minutes of moderate walking, 1 day per week
- Metabolic Complaint: Chronic fatigue during low-intensity lectures
###
```

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Import the target setup variables into the metabolic simulation sandbox tool.
2. Cross-examine the current activity duration against federal guidelines to classify baseline requirements.
3. Verify that the modeled carbohydrate and fluid ranges match acceptable macronutrient distribution boundaries.

---

## Part B: Local Practical Application (Home/Field Activity) / Aplicación Práctica Local (Actividad en el Hogar/Campo)

## Location: Home-Based Environment & Local Temperature Tracking (Yuma Footprint)

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Complete the localized hydration logging matrix tracking fluid shifts across standard metabolic resting states.
2. Formulate a sustainable lifestyle timing schedule that addresses the energy gaps identified during lecture schedules.
3. Document structural compliance entries ensuring final tracking matches the federal dietary standards.

## Yuma Heat Thermal Protocol / Protocolo Térmico de Calor de Yuma

* **English:** Yuma's extreme arid climate requires a localized hydration matrix to mitigate heat-related physiological stress. Students must monitor local temperature changes and log their personal fluid loss/intake metrics (in milliliters) across resting, active, and high-heat exposure windows. All calculations must prioritize sodium-fluid ratios to avoid heat exhaustion or dehydration.
* *Español (Regional): El clima árido extremo de Yuma exige una matriz de hidratación localizada para mitigar el estrés fisiológico térmico. Los estudiantes deben monitorear los cambios de temperatura local y registrar su balance hídrico personal (en mililitros) durante las fases de reposo, actividad y exposición a altas temperaturas. Todos los cálculos deben priorizar la relación sodio-líquidos para evitar el agotamiento por calor o la deshidratación.*

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This assignment is evaluated using the strict **10/7/0 Mastery Scale** / *Esta asignación se evalúa utilizando la escala estricta de Maestría **10/7/0**:*

* **10 (Exemplary / Ejemplar):**
  * **English:** Zero-drift integration. All core guidelines are applied exactly, target parameters remain securely enclosed within delimiter structures (`###`), and bilingual parity is fully preserved.
  * *Español (Regional): Integración con cero desviaciones. Todas las pautas de referencia se aplican exactamente, los parámetros de configuración permanecen contenidos de forma segura dentro de las estructuras delimitadoras (`###`) y se conserva por completo la paridad bilingüe.*
* **7 (Competent / Competente):**
  * **English:** Core performance metrics are safe, safe thermal boundaries are maintained, and calculations are accurate, but minor regional translation gaps, loose formatting, or structural layout misplacements are flagged.
  * *Español (Regional): Las métricas de rendimiento principales son seguras, se mantienen los límites de seguridad térmica y los cálculos son precisos, pero se señalan brechas menores de traducción regional, formato suelto o desalineaciones en la estructura.*
* **0 (Recalibrate / Recalibrar):**
  * **English:** Critical calculation drift is present, safety thresholds are violated, commercial/fad-based trends are promoted instead of the federal SSoT, or core data inputs are left un-delimited.
  * *Español (Regional): Se presenta una desviación crítica en los cálculos, se violan los límites de seguridad, se promueven tendencias comerciales en lugar de la Fuente Única de Verdad (SSoT) federal, o las entradas de datos clave se dejan sin delimitar.*

---

## HLTH-150 Module Discussion: Applied Energy Systems & Hydration Strategies

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Evaluate the target setup parameters to build your tracking files, and defend your fluid scheduling choices using evidence-based guidelines.
* **Español (Regional):** Revise los parámetros de configuración para construir sus archivos de seguimiento y defender sus elecciones de programación de líquidos utilizando pautas basadas en evidencia.
###



## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
