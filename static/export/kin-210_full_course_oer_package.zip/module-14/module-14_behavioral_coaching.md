## Module 14: Behavioral Coaching & Client Relations (Final Evaluation)

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **Behavioral coaching uses active listening, stages of change, and SMART goals to help clients stick with their program long-term.** Even the best workout plan fails if the client stops showing up. Submitting your Module 14 Final Student Course Evaluation this week also unlocks the Module 16 Capstone Practical Defense early on Tuesday, April 20!
>
> **Español (Norteño):** El mejor programa de entrenamiento no sirve si el cliente abandona a la segunda semana; saber escuchar y motivar hace la diferencia. Si los términos técnicos se ponen pesados, concéntrate primero en las etapas de cambio y en enviar tu Evaluación Final del Curso para abrir el Módulo 16.

**Course:** KIN-210 Essentials of Personal Fitness Training | Spring 2027 (16-Week Hybrid)  
**Active Week:** Week 14: Behavioral Coaching & Final Evaluation (April 20, 2027 - April 26, 2027)  
**NASM OPT & Clinical Focus:** Transtheoretical Model (TTM), SMART Goals, Motivational Interviewing & Final Course Evaluation (Unlocks Mod 16 Early)  
**Academic Sources of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018); ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (2025); and National Academy of Sports Medicine (NASM) Optimum Performance Training (OPT) Model  
**Weekly Due Date:** Monday, April 26, 2027 at 11:59 PM MST | **Until / Lock Date:** Friday, May 7, 2027 at 11:59 PM MST (`allowed_attempts = -1` Unlimited for Mastery Revisions)  

---

## Learning Objectives
* **LO 14.1:** Apply the Transtheoretical Model (TTM) Stages of Change, Motivational Interviewing (OARS), and SMART goal setting to client adherence barriers, and complete the Module 14 Final Student Course Evaluation (early-unlocking Module 16).
* **LO 14.2:** Apply the **Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)** to hybrid gymnasium laboratory scenarios in Yuma, AZ (`AS 115` & `GY 116`).
* **LO 14.3:** Audit AI-generated training calculations against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model** on the **10 / 7 / 0 Mastery Grading Scale**.

---

## Overview & Hybrid Meeting Architecture
> **Key Concept:** Behavioral coaching uses active listening, stages of change, and SMART goals to help clients stick with their program long-term.

* **Lecture (Monday / Wednesday, 5:00 PM – 8:00 PM MST):** Yuma Campus, Agriculture & Science (AS) Building, Room 115.
* **Laboratory (Tuesday / Thursday, 5:00 PM – 7:30 PM MST):** Yuma Campus, Gymnasium (GY), Room 116.
* **Digital Toolkit:** Integration with [exwtoolkit.com](https://exwtoolkit.com) for biometric tracking, Overhead Squat Assessment (OHSA) logging, and clinical audit trails.
* **Quantitative Exercise Science Anchor:** TTM Stages: Precontemplation → Contemplation → Preparation → Action → Maintenance

---

## Choose Your Own Journey Pathways (Path A / Path B / Path C)
* **Path A (Clinical Special Populations):** Building self-efficacy and fear-of-movement (kinesiophobia) reduction for post-rehab and chronic-condition clients.
* **Path B (Athletic & Human Performance):** Process vs. outcome SMART goals, mental imagery, and Heart Rate Variability (HRV) readiness communication.
* **Path C (General Fitness & Lifestyle Coaching):** Transtheoretical Model (TTM) Contemplation-to-Action transitions and family social support in Yuma / Imperial Valley.

---

## Clinical Framing Protocol (`Pattern / Rule / Solve` | `Patrón / Regla / Solución`)

```text
### [CLINICAL_PROFILE: Client F.R. | Age: 42 | Location: Yuma, AZ | Stage of Change: Contemplation (considering starting exercise after her doctor warned her about rising blood pressure, but ambivalent due to past gym intimidation and 106°F afternoon heat) | AI Error: Sends an aggressive 'No Excuses 6-Day Hardcore Bootcamp Contract'.] ###
```

* **Pattern (Context / Patrón):** Applying an Action/Maintenance-stage bootcamp contract to a Contemplation-stage client triggers psychological reactance and immediate dropout.
* **Rule (Constraint / Regla):** NASM Behavioral Coaching & PAGA 2018 (2nd Ed.) Adherence Rule: Match coaching interventions to the client's Transtheoretical Model (TTM) Stage of Change using Motivational Interviewing (open-ended questions, affirmations, reflective listening, summaries) and collaborative SMART goals.
* **Solve (Intervention / Solución):** Conduct a 15-minute Motivational Interviewing decisional-balance consultation, co-create a 2-week Preparation-stage SMART goal (two 20-minute indoor sessions in GY 116 + one family morning walk), and submit the Module 14 Final Student Course Evaluation to unlock Module 16.

---

## Laboratory & Practical Application (Four-Part Submission Standard)

## 1. Part 1 (The Engine — P-T-C-F Prompt Template)
Wrap all client case histories, biometric inputs, and Overhead Squat Assessment (OHSA) findings strictly inside triple-hash (`###`) delimiters when prompting your AI calculator:

```text
###
Persona: Act as an Exercise Science Clinical Calculator assisting a Certified Personal Trainer Resident at Arizona Western College.
Task: Audit the AI's 'No Excuses Bootcamp' script for Contemplation-stage Client F.R. and write a Motivational Interviewing (OARS) dialogue and SMART goal plan.
Context: [CLINICAL_PROFILE: Client F.R. | Age: 42 | Location: Yuma, AZ | Stage of Change: Contemplation (considering starting exercise after her doctor warned her about rising blood pressure, but ambivalent due to past gym intimidation and 106°F afternoon heat) | AI Error: Sends an aggressive 'No Excuses 6-Day Hardcore Bootcamp Contract'.] Ground all calculations and safety gates strictly in PAGA 2018 (2nd Ed.), ACSM's Guidelines for Exercise Testing and Prescription (12th Ed.), and the NASM Optimum Performance Training (OPT) Model for Yuma, AZ.
Format: Return a Pattern / Rule / Solve behavioral consultation script using Open-Ended Questions, Affirmations, Reflective Listening, and Summaries (OARS) plus one Process SMART Goal.
###
```

## 2. Part 2 (The Clinical Audit — 150-Word Minimum SSoT Critique)
Write a minimum **150-word Clinical Audit** verifying the AI output against **PAGA 2018**, **ACSM 12th Edition**, and the **NASM Optimum Performance Training (OPT) Model**. Identify at least one clinical, biomechanical, scope-of-practice, or environmental blind spot where generic AI output requires human correction in GY Room 116.

## 3. Part 3 (Active Verification — 150-Word Minimum Verbatim Text Defense in Your Own Human Voice)
Write a minimum **150-word Verbatim Text Defense** in your own authentic human voice (English or Norteño-Spanish, never written or polished by AI) explaining how you will cue, consult, and coach this client in person in **Gymnasium (GY) Room 116** along your chosen pathway (**Path A, Path B, or Path C**) using `Pattern / Rule / Solve` (`Patrón / Regla / Solución`).

## 4. Part 4 (The 10/10 Student Exemplar)
> ### Exemplar: 10/10 Submission Standard (Module 14)
> **Part 1 (Engine):** Submitted the complete P-T-C-F prompt above with the Yuma client profile and GY 116 assessment metrics encapsulated in `###` delimiters.
>
> **Part 2 (Clinical Audit — 150-Word Minimum SSoT Critique):** The AI engine's 'No Excuses 6-Day Hardcore Bootcamp Contract' is a textbook behavioral coaching failure when audited against **NASM Behavioral Coaching Guidelines**, the **Transtheoretical Model (TTM)**, and **PAGA 2018 (2nd Edition)**. First, Client F.R. is in the **Contemplation** stage of change—she recognizes her doctor's blood-pressure warning, but she experiences real ambivalence rooted in gym intimidation and Yuma's 106°F afternoon heat. Prescribing a 6-day high-intensity contract treats her as if she were already in the Maintenance stage, provoking psychological reactance and shame. Second, the AI used directive lecturing ('stop making excuses') instead of **Motivational Interviewing (OARS)** and set an unrealistic outcome goal rather than a client-owned **Process SMART Goal**. I replaced the bootcamp contract with an empathetic decisional-balance consultation and a low-barrier Preparation-stage action plan.
>
> **Part 3 (Active Verification — 150-Word Minimum in Your Own Human Voice):** In plain English, when F.R. walks into GY Room 116 for her first consultation, I put the clipboard down and use Motivational Interviewing so she feels heard, respected, and in control. I start with an Open-Ended Question: 'What would having more energy and healthier blood pressure look like for you and your family here in Yuma?' When she shares that she felt judged in gyms before and hates the afternoon heat, I use Reflective Listening and Affirmations: 'It makes total sense that 106°F afternoons feel exhausting, and showing up here today took real courage.' Together, we co-design a 2-week Preparation SMART Goal: two 20-minute private beginner sessions in our air-conditioned gym on Tuesdays and Thursdays plus one 15-minute 6:30 AM walk with her sister on Sunday. I also completed my Module 14 Final Student Course Evaluation to unlock the Module 16 Capstone.

## 5. Safety Gate & Socratic Guided Learning Simulation
> **Safety Gate (PAGA 2018 / ACSM 12th Ed. / NASM OPT):** NASM Behavioral Coaching & PAGA 2018 (2nd Ed.) Adherence Rule: Match coaching interventions to the client's Transtheoretical Model (TTM) Stage of Change using Motivational Interviewing (open-ended questions, affirmations, reflective listening, summaries) and collaborative SMART goals. Never train a client through acute joint pain, dizziness, hypoglycemia (<100 mg/dL), or uncompensated heat strain.

* **Module Deliverables (Week 14: Behavioral Coaching & Final Evaluation):**
  1. **Mod 14 Coaching Sprint Simulation: Transtheoretical Model (TTM) & Motivational Interviewing Audit**
  2. **Mod 14 Lab & Simulation (GY 116): Live Client Consultation, SMART Goal Setting & Barrier Resolution**
  3. **Mod 14: Final Student Course Evaluation (Must-Submit Unlocks Module 16 Early)**
* **10-7-0 Mastery Grading Scale:**
  * **10 / 10 (Exemplary):** Complete and accurate `Pattern / Rule / Solve` reasoning verified against PAGA 2018, ACSM 12th Ed., and NASM OPT with zero safety errors.
  * **7 / 10 (Competent):** Catches the main clinical issue and AI mistakes with minor gaps in acute variables or citations; revise and resubmit for **10 / 10**.
  * **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical advice; fix and resubmit for full credit before **Friday, May 7, 2027 at 11:59 PM MST**.

---

## Check for Understanding
* Why does using open-ended questions and reflective listening work better than lecturing when a client in Yuma feels ambivalent about starting a fitness program?

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** PAGA 2nd Ed. (2018); ACSM Guidelines 12th Ed. (2025); NASM OPT Model.
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-210` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
