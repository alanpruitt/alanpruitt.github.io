## KIN-245: LAB 14 - EXERCISE PRESCRIPTION FOR LIFESPAN SUBPOPULATIONS (PEDIATRICS & GERIATRICS)

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This laboratory assignment isolates the unique physiological demands, chronological age tracking parameters, and specialized FITT-VP exercise prescription alterations required to design physical activity paths for lifespan subpopulations (Pediatrics and Geriatrics) safely. All growth milestones, balance metrics, and structural safety limits align exclusively with our Single Source of Truth (SSoT): the **ACSM 12th Ed** and **PAGA 2018 (2nd Ed)**.
* *Español (Regional): Esta práctica de laboratorio aísla las demandas fisiológicas únicas, los parámetros de seguimiento de la edad cronológica y las alteraciones especializadas de prescripción de ejercicio FITT-VP requeridos para diseñar rutas de actividad física para subpoblaciones del ciclo vital (Pediatría y Geriatría) de forma segura. Todos los hitos del crecimiento, métricas de equilibrio y límites de seguridad estructural se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): **ACSM 12ª Ed** y **PAGA 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.10])** Formulate clinical exercise prescriptions using age-specific physiological markers and apply lifespan safety rules to evaluate pediatric and geriatric physical activity parameters.
* *Español (Regional): Formular prescripciones de ejercicio clínico utilizando marcadores fisiológicos específicos de la edad y aplicar reglas de seguridad del ciclo vital para evaluar los parámetros de actividad física pediátrica y geriátrica.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Identify and chart distinctive lifespan movement patterns, including accelerated thermoregulatory fatigue lines in pediatric profiles and proprioceptive balance declines or gait variations in geriatric profiles.
2. **Rule / Regla:** Apply strict ACSM 12th Edition guidelines regarding age-based restrictions, avoiding structural overhead maximal loading for immature skeletal systems and enforcing multi-planar balance rules to mitigate fall risks in older demographics.
3. **Solve / Solución:** Engineer a specialized physical activity track that prioritizes playful, bone-anchored multi-joint loading for pediatrics, and functional independent mobility, posture restoration, and neuromotor coordination sequences for geriatrics.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Verification, Simulation, & Pre-Lab Audit / Objetivo: Verificación, Simulación y Auditoría Pre-Laboratorio

Students will initialize the virtual lifespan monitoring engine within their sandbox workspace. Ensure your simulated physiological parameters remain fully wrapped inside the required layout delimiters below.

\`\`\`text

## [PASTE SIMULATED LIFESPAN CAPACITY STRATA DATA / REGISTRO DEL CICLO VITAL VIRTUAL AQUÍ]

## \`\`\`

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Use the sandbox environment to simulate a lifespan case profile, tracking heart rate kinetics, peak relative oxygen consumption lines, and thermal comfort zones under variable environmental stressors.
2. Formulate customized aerobic and resistance volume frameworks that accommodate age-specific physiological markers (such as immature stroke volumes in youth or structural arterial elasticity drops in older populations).
3. Execute an automated audit script within the sandbox to verify that proposed target intensities maintain safe cardiovascular and musculoskeletal margins.

---

## Part B: Lode Corival Practical Application (Onsite Lab) / Aplicación Práctica en Lode Corival (Laboratorio Presencial)

## Location: AWC Yuma Campus GY 116 (Tuesdays 1:30 PM–2:45 PM / Thursdays 2:45 PM–3:10 PM)

## Objective: Research-Grade Physical Assessment / Objetivo: Evaluación Física de Nivel de Investigación

Students will transition into the physical testing space to interface with research-grade instrumentation and tracking setups.

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Organize peer screening protocols for functional age tracking, practicing standardized balance metrics (such as the Timed Up and Go or Single-Leg Stance) to verify baseline proprioceptive stability.
2. Interface with the Lode Corival ergometer using modified, low-resistance warm-up ramps tailored to eliminate abrupt structural loading joint friction.
3. Document true development and functional indicators: record precise physiological tracking marks across exercise blocks and cross-examine workload adjustments against federal PAGA lifespan guidelines.

---

 IMPORTANT: SPECIAL ARCHITECTURE NOTICE
> **Note on Course Infrastructure:** Per institutional tracking updates for the Fall 2026 course fleet, the standard Module 14 Discussion assignment is permanently retired. It has been replaced in the Canvas LMS architecture with the mandatory **Final Student Course Evaluation** assignment to collect zero-friction program metrics.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This lab submission is audited via the strict **10/7/0 Mastery Scale**:

* **10 (Exemplary):** Zero-drift integration. Part A math matches the ACSM model exactly; Part B matrix is completed with no layout gaps; all clinical parameters remain enclosed within code delimiters (`###`).
* **7 (Competent):** Core metrics are safe and accurate, but minor linguistic omissions, formatting errors, or delimiter line misplacements are flagged.
* **0 (Recalibrate):** Critical calculation errors exceeding +- 5%, failure to employ the bilingual layout, or leaving client data unwrapped.

---

## KIN-245 Module Discussion: Final Student Course Evaluation / Evaluación Final del Curso

## The Mission / La Misión

<h3>Closes: Monday @ 11:59 PM</h3>
* **English:** Complete the formal end-of-semester institutional feedback matrix inside Canvas. Your curriculum insights are deployed directly to optimize operational delivery metrics across the department.
* **Español (Regional):** Completar la matriz formal de comentarios institucionales de fin de semestre dentro de Canvas. Sus opiniones sobre el plan de estudios se despliegan directamente para optimizar las métricas de entrega operativa en todo el departamento.

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.


###CASE_DATA_START###
Clinical Case Profile / Student Activity Parameters
###CASE_DATA_END###
