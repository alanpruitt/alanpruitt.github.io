## KIN-245: Module 00 — Course Orientation, GY 116 Lab Safety, & Ready Reference Guide

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you read the details below, here is the short version: **Module 00 is your permanent, semester-long reference guide for how to succeed in KIN-245.** It explains how we pair AI physiological calculators with your own clinical testing judgment in GY 116, how the 10 / 7 / 0 grading scale works, and how to revise any assignment for full 10 / 10 credit. Because this module stays open all semester, bookmark it and return whenever you need to check an ACSM formula, safety gate, or exemplar.

## En Palabras Sencillas (Norteño Context)
Piensa en el Módulo 00 como la lista de chequeo antes de prender la maquinaria en el taller: siempre está abierto durante todo el semestre por si ocupas verificar una fórmula de ACSM, cómo redactar tu Verificación Activa, o cómo subir una calificación a 10 / 10. Si los términos técnicos se ponen pesados, concéntrate primero en medir bien los signos vitales y aplicar `Patrón / Regla / Solución` antes de subir a alguien a la caminadora o al ergómetro.
:::

---

## Lab Overview & Permanent Reference Grounding / Contexto Inicial y Guía Permanente

* **English:** Welcome to **KIN-245: Exercise Testing and Prescription**. This orientation establishes your digital AI sandbox, clinical calculation standards, and physical laboratory safety operations inside **AWC Yuma Campus GY 116**. All testing and prescription pathways strictly follow our Academic Source of Truth (SSoT): **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition (Effective July 10, 2025)** alongside **PAGA 2018 (2nd Ed.)**. **Best Practice Note:** Module 00 remains unlocked the entire 16-week semester so you can reference our ACSM screening rules, grading standards, and 10/10 exemplars at any time.
* **Español (Regional):** Bienvenido a **KIN-245: Pruebas y Prescripción del Ejercicio**. Esta orientación establece el entorno digital de IA, los estándares de cálculo fisiológico y los protocolos de seguridad física del laboratorio en **AWC Campus Yuma GY 116**. Todas las prácticas siguen nuestra Fuente Única de Verdad (SSoT): **Pautas de ACSM para Pruebas y Prescripción del Ejercicio, 12ª Edición (2025)**. **Nota Práctica:** El Módulo 00 permanece abierto durante las 16 semanas del semestre como tu guía de consulta rápida.

---

## Targeted Learning Objectives / Objetivos de Aprendizaje

* **([LO 2.1]):** Formulate structured laboratory workflows using digital simulation sandboxes and apply physical clinic safety configurations (**ACSM 12th Ed.**) to manage research-grade testing setups in GY 116. / Formular flujos de trabajo de laboratorio estructurados y aplicar configuraciones de seguridad clínica física (**ACSM 12ª Ed.**) para gestionar pruebas fisiológicas en GY 116.

---

## The Clinical Framing Protocol (`Pattern

In the **Matador Wellness Center Clinical AI Residency**, you are the **Architect / Pilot** (Preparticipation Screening, Termination Criteria, and Clinical Judgment) and the AI is the **Engine / Calculator** (Metabolic Equations, $\text{VO}_{2\max}$, and Karvonen Math). Throughout the semester, every Discussion, Coaching Sprint, and Lab uses our three-part **Clinical Framing Protocol**:

1. **Pattern (`Patrón` — Context):** Diagnose the client's preparticipation screening profile, resting vitals ($\text{HR}$, $\text{BP}$, $\text{BMI}$), cardiovascular/metabolic/renal signs or symptoms, and Yuma environmental heat exposure.
2. **Rule (`Regla` — Constraint):** Define the exact preparticipation medical clearance gate, testing termination thresholds, metabolic equations, and FITT-VP intensity boundaries from **ACSM's Guidelines for Exercise Testing and Prescription, 12th Edition**.
3. **Solve (`Solución` — Intervention):** Execute a mathematically verified exercise test and FITT-VP prescription, onsite GY 116 Lode Corival protocol, and human **Active Verification**.

---

## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA (Entorno Virtual)
1. Configure your P-T-C-F prompt using triple-hash (`###`) delimiters around all client vital signs and screening data.
2. Audit every AI metabolic calculation ($\text{HRR}$, $\text{VO}_2\text{R}$, $\text{METs}$) by hand against **ACSM 12th Edition** tables.

## Part B: Lode Corival Practical Application (Onsite Lab — AWC Yuma Campus GY 116)
1. Locate the cycle ergometers, calibrated treadmills, sphygmomanometers, fire extinguishers, and the **Automated External Defibrillator (AED)** inside **GY 116**.
2. Verify resting blood pressure and heart rate safety cutoffs before initiating any submaximal or graded exercise test.

---

## Plain-English Guide: Simulations & Simulators (`paga2018.dev` + `exwtoolkit.com`)

* **In Plain English:** Throughout KIN-245, you use two free, zero-login web apps located right in your left-hand Canvas Course Navigation menu—**`paga2018.dev` ("PAGA")** and **`exwtoolkit.com` ("Toolkit")**—to verify **ACSM 12th Edition** preparticipation screening rules, metabolic equations, and FITT-VP prescriptions:
  1. **`paga2018.dev` ("PAGA" in Left Course Menu):**
     * **Activity Audit (`paga2018.dev/activity-audit`):** Audit baseline aerobic and muscle-strengthening volume to determine whether a client is Habitually Active or Sedentary under ACSM Chapter 2 preparticipation screening.
     * **Case Coach (`paga2018.dev/case-coach`):** Step-by-step `Pattern / Rule / Solve` coaching sandbox for testing ACSM clearance triggers, resting vitals cutoffs, and Yuma environmental heat boundaries.
     * **Interactive Case Modals (`###` Copy Blocks):** Pre-built clinical profiles wrapped in triple-hash (`###`) delimiters. Click **"Copy Case (`###`)"** to copy clean vital signs and test data.
     * **Bilingual EN / ES Toggle:** Switch any simulator or clinical benchmark between English and Norteño-grounded Spanish with one click.
  2. **`exwtoolkit.com` ("Toolkit" in Left Course Menu):**
     * **Stage 1 — Weekly Coaching Sprint:** Uses the embedded micro-simulator right on the Canvas assignment page (`Pattern / Rule / Solve` + 150-word Active Verification).
     * **Stage 2 — Weekly Clinical Lab:** Uses **`paga2018.dev`** + the **`exwtoolkit.com` 9-Box Clinical Architecture** (`1. Biometrics Box` $\rightarrow$ `3. Safety Box (ACSM Screening)` $\rightarrow$ `4. Cardio Box (Karvonen HRR)` $\rightarrow$ `9. Solve Box` *"Copy for Canvas Submission"*).
* **En Palabras Sencillas (Contexto Norteño):** *Durante todo KIN-245 usamos dos herramientas gratuitas y sin contraseña que están directo en el menú izquierdo de Canvas: **"PAGA"** (`paga2018.dev`, con **Activity Audit**, **Case Coach** y **Cuadros de Casos `###`**) y **"Toolkit"** (`exwtoolkit.com`). El micro-simulador integrado es para tu **Coaching Sprint (Etapa 1)**, y las aplicaciones completas son para tu **Laboratorio Clínico (Etapa 2)**.*

---

## Active Verification (`Part 3`): What It Is, Why We Use It, & 10/10 Student Exemplars (Harmonized Across `EXW 101 •...

## 1. What is "Active Verification"?
Every Lab and Coaching Sprint requires the **Four-Part Submission Standard**:
* **Part 1 (The Engine):** Your P-T-C-F Engineered Prompt (Persona, Task, Context, Format).
* **Part 2 (The Clinical Audit):** A 150-word critique of the AI's output against the **ACSM 12th Edition** Source of Truth, catching formula drift, wrong intensity zones, or missed medical clearance triggers.
* **Part 3 (Active Verification):** A **mandatory 150-word minimum verbatim text defense written entirely in your own human voice** justifying your ACSM preparticipation screening decision, target heart-rate math, and safety gates.
* **Part 4 (Comparison against the 10/10 Exemplar):** Verifying your work against the module model before submitting.

## 2. Why Do We Use Active Verification? (The Clinical Framework: Pattern / Rule / Solve)
* **In Plain English:** Large language models frequently hallucinate metabolic math, confuse percent of max heart rate ($\%\text{HR}_{\max}$) with percent of Heart Rate Reserve ($\%\text{HRR}$), or prescribe vigorous testing to sedentary clients who require medical clearance first. We require the 150-word **Active Verification** in your own words so you prove that a real human clinician verified the vitals, checked the ACSM 12th Edition algorithm, and protected the client.
* **En Palabras Sencillas (Norteño-Spanish):** *La Verificación Activa (mínimo 150 palabras en tu propia voz) demuestra que tú eres el fisiólogo clínico a cargo y la IA es solo la calculadora. La IA a menudo confunde fórmulas como Karvonen ($\%\text{HRR}$) o ignora cuándo un cliente sedentario ocupa autorización médica según el Capítulo 2 de ACSM 12ª Ed. Aquí demuestras con tus propias palabras que tú verificaste las matemáticas y los signos vitales antes de prescribir el esfuerzo.*

## 3. What It Looks Like: KIN-245 Student Exemplar (`10 / 10 Standard`)

> ### Exemplar: KIN-245 Part 3 — Active Verification (164 words, ACSM 12th Ed. Grounded)
> "In my own words, the AI made a dangerous physiological error by prescribing high-intensity interval sprints on day one and miscalculating target heart rate using standard age-predicted formulas without accounting for the client's resting vitals. Applying `Pattern / Rule / Solve`, the **Pattern** is a 49-year-old sedentary Yuma office manager ($\text{BMI } 31.2\text{ kg/m}^2$, resting $\text{BP } 134/86\text{ mmHg}$, $\text{Resting Heart Rate (RHR) } 78\text{ bpm}$) with no signs or symptoms of cardiovascular, metabolic, or renal disease. The **Rule** under the ACSM Guidelines for Exercise Testing and Prescription (12th Edition, Chapter 2 Preparticipation Screening & Chapter 5 FITT-VP) requires starting sedentary, asymptomatic individuals at light-to-moderate intensity ($40\%\text{ to }59\%\text{ HRR}$) before progressing to vigorous work. Using the Karvonen formula with an estimated $\text{HR}_{\max}$ of $171\text{ bpm}$ ($220 - 49$), his Heart Rate Reserve is $93\text{ bpm}$ ($171 - 78$). My **Solve** sets his initial indoor treadmill walking target between $115\text{ and }133\text{ bpm}$ for 30 minutes, 5 days per week."

---

## The 10-7-0 Mastery Grading Scale & How to Remedy a `Recalibrate (0 / 10)` Score

All Discussions, Coaching Sprints, and Labs in KIN-245 use **The 10-7-0 Mastery Grading Scale**:

* **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **ACSM 12th Edition** with zero calculation or safety errors and a complete 150-word human Active Verification.
* **7 / 10 (Competent):** Catches the main physiological issue and AI mistakes, with minor gaps in formula steps, word count, or ACSM chapter citations. **You can revise and resubmit to reach 10 / 10.**
* **0 / 10 (Recalibrate):** Missing a required section (such as the 150-word Active Verification), unverified AI copy-paste, or unsafe clinical testing/prescription advice (such as missing an ACSM medical clearance gate or hypertensive termination threshold). **`0 / 10` is never a permanent punishment—it is a clinical safety pause and an open invitation to fix the issue and resubmit for full `10 / 10` credit.**

## The 4-Step Remedy Roadmap: How to Fix a `0 / 10 (Recalibrate)` or Upgrade a `7 / 10 (Competent)` Grade

1. **Step 1 — Open Your `Grades` Tab in Canvas (Not the To-Do List):**
   Once an assignment is graded `0 / 10` or `7 / 10`, Canvas removes it from your "To-Do" sidebar. Click **`Grades`** in the left course navigation menu and click the assignment title directly.
2. **Step 2 — Read Coach Alan's *In Plain English* SpeedGrader Note:**
   Every returned assignment includes a specific comment starting with *"In plain English:"* (or *"En palabras sencillas:"*) explaining the exact ACSM 12th Edition rule, Karvonen/METs calculation, or missing section you need to fix.
3. **Step 3 — Revise Only What Was Flagged:**
   Update your submission using **`Pattern / Rule / Solve` (`Patrón / Regla / Solución`)**, cite **ACSM 12th Edition**, and verify that your **Part 3 Active Verification** is at least 150 words in your own human voice.
4. **Step 4 — Click `New Attempt` and Resubmit (Unlimited Attempts Open All Semester):**
   All Labs and Coaching Sprints have **Unlimited Attempts** enabled and remain unlocked through the end of the semester. Click **New Attempt**, submit your updated work, and Coach Alan will re-audit and upgrade your score to **`10 / 10 (Exemplary)`**.

## En Palabras Sencillas: Cómo Recuperar un `0 / 10 (Recalibrate)` o Subir un `7 / 10` a `10 / 10`
*Un `0 / 10 (Recalibrate)` nunca es un castigo definitivo; es una pausa de seguridad clínica y una invitación abierta para corregir y volver a entregar por el `10 / 10` completo. Entra a la pestaña **Grades (Calificaciones)** en Canvas, lee el comentario de Coach Alan en SpeedGrader, corrige el `Patrón / Regla / Solución`, tu cálculo de ACSM o tu Verificación Activa de 150 palabras, y haz clic en **New Attempt (Nuevo Intento)**. Tienes intentos ilimitados durante todo el semestre.*

---

## Check for Understanding
* Before starting Module 01, explain in your own words: Why must a clinician verify Heart Rate Reserve ($\%\text{HRR}$) and ACSM Chapter 2 preparticipation screening rules rather than trusting raw AI output, and what four steps do you take in Canvas to upgrade a `0 / 10 (Recalibrate)` score to `10 / 10`?
