## KIN-245: LAB 07 - BODY COMPOSITION ASSESSMENTS & ANTHROPOMETRIC STANDARDIZATION

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This laboratory assignment isolates the anthropometric measurement techniques and multi-compartment model calculations required to evaluate human body composition. All clinical measurement lines, skinfold site standardizations, and equations align exclusively with our Single Source of Truth (SSoT): the **ACSM 12th Ed** and **PAGA 2018 (2nd Ed)**.
* *Español (Regional): Esta práctica de laboratorio aísla las técnicas de medición antropométrica y los cálculos de modelos de compartimentos múltiples requeridos para evaluar la composición corporal humana. Todas las líneas de medición clínica, estandarizaciones de sitios de pliegues cutáneos y ecuaciones se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): **ACSM 12ª Ed** y **PAGA 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.7])** Formulate body density estimates using multi-site regression equations and apply anthropometric standardization guidelines to audit health risks.
* *Español (Regional): Formular estimaciones de la densidad corporal utilizando ecuaciones de regresión de múltiples sitios y aplicar pautas de estandarización antropométrica para auditar riesgos de salud.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Identify and document structural differences in fat-free mass distributions and localized body fat patterns across case profiles.
2. **Rule / Regla:** Apply strict ACSM 12th Edition anatomical landmark rules to standardize skinfold caliper placement and circumference measurements.
3. **Solve / Solución:** Engineer body fat percentage estimates and waist-to-hip ratio evaluations to establish safe, evidence-based weight management targets.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Verification, Simulation, & Pre-Lab Audit / Objetivo: Verificación, Simulación y Auditoría Pre-Laboratorio

Students will initialize the virtual body composition engine within their sandbox workspace. Ensure your simulated physiological parameters remain fully wrapped inside the required layout delimiters below.

\`\`\`text

## [PASTE SIMULATED ANTHROPOMETRIC STRATA DATA / REGISTRO ANTROPOMÉTRICO VIRTUAL AQUÍ]

## \`\`\`

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Use the sandbox environment to simulate a multi-site anthropometric sequence using a standard Jackson-Pollock 3-Site or 7-Site protocol.
2. Calculate body density ($BD$) lines using the appropriate gender-specific quadratic equations, then convert to body fat percentage via Siri or Schutte formulas: \%BF = (495 / BD) - 450.
3. Execute a verification script within the sandbox to audit the calculation results against established body fat distribution classifications.

---

## Part B: Lode Corival Practical Application (Onsite Lab) / Aplicación Práctica en Lode Corival (Laboratorio Presencial)

## Location: AWC Yuma Campus GY 116 (Tuesdays 1:30 PM–2:45 PM / Thursdays 2:45 PM–3:10 PM)

## Objective: Research-Grade Physical Assessment / Objetivo: Evaluación Física de Nivel de Investigación

Students will transition into the physical testing space to interface with research-grade anthropometric instrumentation.

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Calibrate Lange or Harpenden skinfold calipers and execute a three-site assessment rotation, ensuring all markings match ACSM anatomical guidelines.
2. Perform standardized waist and hip circumference assessments using a spring-loaded anthropometric tape to eliminate skin compression variance.
3. Document true structural metrics: establish physiological waist-to-hip ratio (WHR) values and cross-examine regional adipose tissue accumulation risks against federal PAGA thresholds.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This lab submission is audited via the strict **10/7/0 Mastery Scale**:

* **10 (Exemplary):** Zero-drift integration. Part A math matches the ACSM model exactly; Part B matrix is completed with no layout gaps; all clinical parameters remain enclosed within code delimiters (`###`).
* **7 (Competent):** Core metrics are safe and accurate, but minor linguistic omissions, formatting errors, or delimiter line misplacements are flagged.
* **0 (Recalibrate):** Critical calculation errors exceeding +- 5%, failure to employ the bilingual layout, or leaving client data unwrapped.

---

## KIN-245 Module Discussion: Clinical Case Review & Consultation ###

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Apply the ACSM 12th Edition Guidelines and PAGA 2018 parameters to the workload values captured in GY 116. Identify technical discrepancies and propose a Corrective Action Plan (CAP).
* **Español (Regional):** Aplicar las Pautas de la ACSM 12ª Edición y los parámetros PAGA 2018 a los valores de carga de trabajo capturados en el GY 116. Identificar discrepancias técnicas y proponer un Plan de Acción Correctiva (CAP).

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
