## KIN-245: LAB 04 - METABOLIC EQUATIONS & EXPENDITURE CLAMPING 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Clinical Grounding / Contexto Clínico

* **English:** This weekly lab bridges theoretical physical assessment with research-grade clinical execution. All mathematical models, metabolic equations, and risk stratifications must align exclusively with our Single Source of Truth (SSoT): **ACSM 12th Ed** and **PAGA 2018 (2nd Ed)**.
* *Español (Regional): Este laboratorio semanal conecta la evaluación física teórica con la ejecución clínica de nivel de investigación. Todos los modelos matemáticos, ecuaciones metabólicas y estratificaciones de riesgo deben alinearse exclusivamente con nuestra Fuente Única de Verdad (SSoT): **ACSM 12ª Ed** y **PAGA 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.4])** Execute precise metabolic calculations or testing protocols following federal and clinical guidelines.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Identify client physiological baselines, metabolic metrics, or equipment calibration tracking data.
2. **Rule / Regla:** Apply specific ACSM metabolic formulas or federal PAGA classification thresholds to cross-verify performance values.
3. **Solve / Solución:** Formulate precise, evidence-based exercise prescriptions or equipment load adjustments that mitigate clinical risk lines.

---

## Part A: Gemini AI Simulation (Digital Sandbox)

## Objective: Verification, Simulation, & Pre-Lab Audit

## Tool Box Protocol

Before touching the physical laboratory equipment in GY 116, you must utilize Gemini AI to verify your mathematical baselines and run clinical simulations. Paste your raw client case data, metabolic numbers, or testing profiles inside the required delimiters below to run your pre-lab check.

```text
## [PASTE CLINICAL CASE DATA / CLIENT PROFILE HERE] ###
###
```

## Student Action Items (Part A)

1. Input assigned metabolic equations or client data sets into the Gemini digital workspace.
2. Execute calculation cross-checks (e.g., Maximum Oxygen Uptake (VO₂ Max) max estimation, metabolic MET conversions, or heart rate zone calculations).
3. Export your verified digital log and paste it directly into your Canvas Lab Submission file under the Part A section.

---

## Part B: Lode Corival Practical Application (Onsite Lab)

## Location: AWC Yuma Campus GY 116 (Tuesdays 1:30 PM–2:45 PM / Thursdays 2:45 PM–3:10 PM)

## Objective: Research-Grade Physical Assessment

Step up to the physical Lode Corival ergometer to execute live participant testing. This system utilizes hyperbolic braking to hold a precise, independent wattage workload regardless of the participant's RPM velocity, ensuring absolute clinical replication accuracy.

## Student Action Items (Part B)

1. Perform mandatory pre-test safety screening and clean the Lode ergometer touchpoints.
2. Program the exact wattage step-protocols verified during your Part A digital audit.
3. Execute the physical test, capture live performance metrics (HR, RPE, Watts, blood pressure lines), and record them into your tracking log.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This lab submission is audited via the strict **10/7/0 Mastery Scale**:

* **10 (Exemplary):** Zero-drift integration. Part A math matches the ACSM model exactly; Part B matrix is completed with no layout gaps; all client case parameters remain enclosed within code delimiters (`###`).
* **7 (Competent):** Core metrics are safe and accurate, but minor linguistic omissions, formatting errors, or delimiter line misplacements are flagged.
* **0 (Recalibrate):** Critical calculation errors exceeding +- 5%, failure to employ the bilingual layout, or leaving client data unwrapped.

---

## KIN-245 Module Discussion: Clinical Case Review & Consultation ###

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Apply the ACSM 12th Edition Guidelines and PAGA 2018 parameters to the workload values captured in GY 116. Identify technical discrepancies and propose a Corrective Action Plan (CAP).
* **Español (Regional):** Aplicar las Pautas de la ACSM 12ª Edición y los parámetros PAGA 2018 a los valores de carga de trabajo capturados en el GY 116. Identificar discrepancias técnicas y proponer un Plan de Acción Correctiva (CAP).

###



## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
