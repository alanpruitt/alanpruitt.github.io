## KIN-245: LAB 09 - FLEXIBILITY & RANGE-OF-MOTION STANDARDIZATION / FLEXIBILIDAD Y ESTANDARIZACIÓN DEL RANGO DE MOVIMIENTO 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Foundational Grounding / Contexto Inicial

* **English:** This laboratory assignment isolates the anatomical joint planes, goniometric alignment vectors, and static testing protocols required to evaluate human flexibility safely. All measurement lines, anatomical tracking points, and data boundaries align exclusively with our Single Source of Truth (SSoT): the **ACSM 12th Ed** and **PAGA 2018 (2nd Ed)**.
* *Español (Regional): Esta práctica de laboratorio aísla los planos articulares anatómicos, los vectores de alineación goniométrica y los protocolos de prueba estática requeridos para evaluar la flexibilidad humana de forma segura. Todas las líneas de medición, los puntos de seguimiento anatómico y los límites de datos se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): **ACSM 12ª Ed** y **PAGA 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 2.4])** Formulate angular range-of-motion metrics using goniometric instrumentation and apply anatomical alignment rules to evaluate musculoskeletal flexibility limits.
* *Español (Regional): Formular métricas de rango de movimiento angular utilizando instrumentación goniométrica y aplicar reglas de alineación anatómica para evaluar los límites de flexibilidad musculoesquelética.*

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico
Every laboratory submission requires you to process your data through the strict three-stage clinical auditing loop:

1. **Pattern / Patrón:** Identify and chart regional restrictions, compensatory movement lines, and bilateral asymmetries across static anatomical parameters.
2. **Rule / Regla:** Apply strict ACSM 12th Edition anatomical placement rules for the goniometer axis, fulcrum, stationary arm, and movement arm.
3. **Solve / Solución:** Engineer evidence-based stretching interventions and range-of-motion corrections that align with federal physical activity guidelines to restore musculoskeletal balance.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Estructura

## Part A: Gemini AI Simulation (Digital Sandbox) / Simulación por IA de Gemini (Entorno Virtual)

## Objective: Verification, Simulation, & Pre-Lab Audit / Objetivo: Verificación, Simulación y Auditoría Pre-Laboratorio

Students will initialize the virtual kinematic tracking engine within their sandbox workspace. Ensure your simulated physiological parameters remain fully wrapped inside the required layout delimiters below.

\`\`\`text

## [PASTE SIMULATED KINEMATIC RANGE-OF-MOTION STRATA DATA / REGISTRO GONIOMÉTRICO VIRTUAL AQUÍ]

## \`\`\`

## Student Action Items (Part A) / Acciones de los Estudiantes (Parte A)

1. Use the sandbox environment to simulate joint angle deflection tracks during a series of passive hip flexion and shoulder rotation cases.
2. Calculate net angular deviation lines and compare passive limitations against standard multi-joint flexibility tables using the sandbox environment.
3. Execute a validation script within the sandbox to check for compliance with standard biomechanical safety margins.

---

## Part B: Lode Corival Practical Application (Onsite Lab) / Aplicación Práctica en Lode Corival (Laboratorio Presencial)

## Location: AWC Yuma Campus GY 116 (Tuesdays 1:30 PM–2:45 PM / Thursdays 2:45 PM–3:10 PM)

## Objective: Research-Grade Physical Assessment / Objetivo: Evaluación Física de Nivel de Investigación

Students will transition into the physical testing space to interface with research-grade anthropometric and goniometric instruments.

## Student Action Items (Part B) / Acciones de los Estudiantes (Parte B)

1. Identify exact bony landmarks (e.g., greater trochanter, lateral epicondyle) to locate the precise joint rotational fulcrum per ACSM guidelines.
2. Execute standardized static flexibility assessments including the Canadian Trunk Forward Flexion test and double-arm goniometric joint tracking.
3. Document true structural metrics: record precise angular displacement values and cross-examine movement scores against federal PAGA population classifications to map functional movement health.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría

This lab submission is audited via the strict **10/7/0 Mastery Scale**:

* **10 (Exemplary):** Zero-drift integration. Part A math matches the ACSM model exactly; Part B matrix is completed with no layout gaps; all clinical parameters remain enclosed within code delimiters (`###`).
* **7 (Competent):** Core metrics are safe and accurate, but minor linguistic omissions, formatting errors, or delimiter line misplacements are flagged.
* **0 (Recalibrate):** Critical calculation errors exceeding +- 5%, failure to employ the bilingual layout, or leaving client data unwrapped.

---

## KIN-245 Module Discussion: Clinical Case Review & Consultation / Revisión de Casos Clínicos y Consulta ###

## The Mission (Initial Post) / La Misión

<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Apply the ACSM 12th Edition Guidelines and PAGA 2018 parameters to the workload values captured in GY 116. Identify technical discrepancies and propose a Corrective Action Plan (CAP).
* **Español (Regional):** Aplicar las Pautas de la ACSM 12ª Edición y los parámetros PAGA 2018 a los valores de carga de trabajo capturados en el GY 116. Identificar discrepancias técnicas y proponer un Plan de Acción Correctiva (CAP).

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
