## KIN-245: LAB 02 – LODE CORIVAL WATTAGE MATRIX & METABOLIC ESTIMATION

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Lab Overview & Clinical Grounding / Contexto Clínico

* **Single Source of Truth (SSoT):** ACSM Guidelines for Exercise Testing and Prescription (12th Ed) and PAGA 2018 (2nd Ed).
* **Equipment Framework:** Lode Corival Ergometer utilizing hyperbolic braking. The work rate (Watts) remains absolutely constant regardless of pedal velocity (RPM), ensuring research-grade reproduction accuracy.
* **Location:** AWC Yuma Campus GY 116.

---

## Targeted Learning Objectives / Tracking de Objetivos

* **[LO 2.2]** Execute precise metabolic calculations and cycle ergometry testing protocols following clinical ACSM guidelines.

---

## El Protocolo de Encuadre Clínico / The Clinical Framing Protocol

1. **Pattern:** Isolate client physiological baselines, body weight parameters, and uncalibrated performance discrepancies.
2. **Rule:** Apply the strict ACSM 12th Edition metabolic equation for gross oxygen consumption during cycle ergometry.
3. **Solve:** Mathematically predict target wattages to systematically guide live participant testing without exceeding clinical risk thresholds.

---

## Part A: Gemini AI Simulation (Digital Sandbox)

## Objective: Math Verification & Pre-Lab Audit

Students must pass their raw physiological parameters through Gemini AI within the clinical delimiter protocol triple-hash delimiters to cross-verify all mathematical calculations before stepping into GY 116.

## ACSM 12th Ed Metabolic Equation for Cycle Ergometry

$$\dot{V}\text{O}_2 = 1.8 \cdot \left(\frac{\text{Work Rate}}{\text{M}}\right) + 3.5 + 3.5$$

Where:

* $\dot{V}\text{O}_2$ = Gross oxygen uptake in $\text{mL} \cdot \text{kg}^{-1} \cdot \text{min}^{-1}$
* **Work Rate** = Power output in $\text{kg} \cdot \text{m} \cdot \text{min}^{-1}$ (Note: $1\text{ Watt} = 6.12\text{ kg} \cdot \text{m} \cdot \text{min}^{-1}$)
* **M** = Client body mass in $\text{kg}$
* $1.8$ = Oxygen cost of loading on a cycle ergometer ($\text{mL} \cdot \text{kg}\cdot\text{m}^{-1}$)
* $3.5$ = Oxygen cost of horizontal pedaling against no load ($\text{mL} \cdot \text{kg}^{-1} \cdot \text{min}^{-1}$)
* $3.5$ = Resting metabolic rate component ($\text{mL} \cdot \text{kg}^{-1} \cdot \text{min}^{-1}$)

## Pre-Lab Target Calculation Prompt Template

Enclose the assignment inputs within the required master delimiters when prompting the AI:

```text
## CLIENT_ID: AWC-245-02
GENDER: Female
AGE: 22
BODY_WEIGHT: 65.0 kg
RESTING_HR: 68 bpm
TARGET_VO2_PEAK_ESTIMATE: 35.0 mL/kg/min
## INSTRUCTIONS: Use the ACSM 12th Edition Cycle Ergometry equation to solve for Work Rate (Watts) at 40%, 60%, and 80% of the target Maximum Oxygen Uptake (VO₂ Max) peak estimate. Show all intermediate algebraic steps.
---

## Mastery Performance Standard / Estándar de Ejecución de Maestría
This lab submission is audited via the strict **10/7/0 Mastery Scale**:
* **10 (Exemplary):** Zero-drift integration. Part A math matches the ACSM model exactly; Part B matrix is completed with no layout gaps; all client case parameters remain enclosed within code delimiters triple-hash delimiters.
* **7 (Competent):** Core metrics are safe and accurate, but minor linguistic omissions, formatting errors, or delimiter line misplacements are flagged.
* **0 (Recalibrate):** Critical calculation errors exceeding +- 5%%, failure to employ the bilingual layout, or leaving client data unwrapped.

---

## KIN-245 Module Discussion: Clinical Case Review & Consultation ###
## The Mission (Initial Post) / La Misión
<h3>Due: Thursday @ 11:59 PM</h3>
* **English:** Apply the ACSM 12th Edition Guidelines and PAGA 2018 parameters to the workload values captured in GY 116. Identify technical discrepancies and propose a Corrective Action Plan (CAP).
* **Español (Regional):** Aplicar las Pautas de la ACSM 12ª Edición y los parámetros PAGA 2018 a los valores de carga de trabajo capturados en el GY 116. Identificar discrepancias técnicas y proponer un Plan de Acción Correctiva (CAP).

###
```


## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.

## Discussion
