## KIN-101: Mod 06 Required Readings Energy Systems And Workout Fueling

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Required Readings: Energy Systems & Workout Fueling

Lecturas Obligatorias y Recursos de Estudio: Vías Metabólicas, Bioenergética Humana y Normas PAGA


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Bioenergetics is how your body turns food into energy for movement. The harder you work, the faster your body uses that energy. Adults should be active 150 to 300 minutes each week at a moderate level, like a brisk walk.


#### En Palabras Sencillas (Norteño Context)

Piensa en tu cuerpo como una troca con dos tanques: para el trabajo ligero usa un combustible que dura todo el día, y para el esfuerzo fuerte quema uno rápido que se acaba pronto; y en el calor de Yuma, se vacía todavía más rápido. Si los términos técnicos se ponen pesados, concéntrate primero en cuántos minutos te mueves cada semana.


### Required SSoT Text & Federal Bioenergetic Standards

Primary Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • Chapter 2: Physical Activity Guidelines for Adults (Energy Balance, Intensity & Metabolic Adaptations).

Primary SSoT Anchor: Chapter 2: Physical Activity Guidelines for Adults • Energy Balance, Substrate Utilization, and Metabolic Adaptations.

- Interactive PAGA Clinical Calculators ("PAGA" in Left Menu): Activity Audit (2-for-1 Rule) • Intensity & METs • Clinical Case Coach (Pattern / Rule / Solve)
- Chapter 2 Reference Guide: exw101_ssot_kinesiology_reference.docx
Federal METs & Volume Standards: Classification of aerobic physical activity intensity based on resting metabolic equivalents (1 MET = 3.5 mL O2/kg/min):

- Moderate-Intensity Aerobic Activity: 3.0 to 5.9 METs (e.g., brisk walking at 3.0 to 4.0 mph). Mandate: 150 to 300 minutes weekly .
- Vigorous-Intensity Aerobic Activity: 6.0 METs or greater (e.g., jogging, running, fast cycling). Mandate: 75 to 150 minutes weekly .
- Target Energy Expenditure: 500 to 1,000 MET-minutes per week (equivalent to approx. 1,000 to 2,000 kcal expended weekly).
- Dose-Response Principle: Activity of any duration counts toward daily totals, eliminating the obsolete 10-minute minimum bout requirement.

### Regional Focus: Desert Thermal Stress & Glycogen Kinetics in Yuma County

Enfoque Regional: Estrés Térmico del Desierto, Gasto Energético y Fatiga Metabólica en Yuma

In Yuma County and regional desert border communities, extreme summer ambient temperatures exceeding 105°F (40.5°C) fundamentally alter exercise bioenergetics. Heat stress increases circulatory strain, elevates core body temperature, and triggers sympathetic catecholamine release. This accelerated sympathetic response stimulates intramuscular glycogenolysis, causing a premature shift from fat oxidation to fast glycolysis (the Crossover Concept) even during moderate physical exertion. Exercise specialists at Matador Clinical Partners (MCP) and community recreation centers design temperature-adapted interval sessions, indoor climate-controlled conditioning, and electrolyte-carbohydrate replenishment schedules to mitigate premature metabolic fatigue.

En el condado de Yuma y las comunidades agrícolas del desierto, las temperaturas superiores a 40.5°C (105°F) alteran la bioenergética del esfuerzo. El estrés térmico acelera la glucogenólisis muscular, desplazando el metabolismo hacia los carbohidratos a menor intensidad. Los especialistas de Matador Clinical Partners (MCP) y centros comunitarios diseñan programas por intervalos en ambientes climatizados y esquemas de hidratación para evitar la fatiga celular prematura.


### Reading 1: The Bioenergetic Energy Continuum & ATP Resynthesis

Lectura 1: El Continuo Bioenergético y Vías de Resíntesis de ATP

Adenosine triphosphate (ATP) is the exclusive molecular currency powering actin-myosin cross-bridge cycling during skeletal muscle contraction. Because intramuscular resting stores are minimal (approx. 5 to 6 mmol/kg wet muscle, depleted in 1 to 2 seconds of maximal exertion), muscle cells continuously resynthesize ATP via three integrated metabolic pathways:


### Reading 2: Oxygen Kinetics, Oxygen Deficit & EPOC

Lectura 2: Cinética del Oxígeno, Déficit de Oxígeno y Consumo Excesivo Post-Ejercicio (EPOC)


#### Step 1: Oxygen Deficit at the Onset of Exercise

Déficit de Oxígeno al Iniciar el Esfuerzo

At the transition from rest to steady-state submaximal exercise, the body's ATP demand increases instantaneously. However, pulmonary and cardiovascular oxygen delivery (VO2) requires 1 to 4 minutes to adjust and match cellular demand. The lag in oxygen uptake during the initial stages of exercise is defined as the Oxygen Deficit . During this deficit window, ATP is provided almost entirely through anaerobic pathways (Phosphagen and Fast Glycolysis).


#### Step 2: Excess Post-Exercise Oxygen Consumption (EPOC)

Consumo Excesivo de Oxígeno Post-Ejercicio (EPOC)

Following exercise cessation, oxygen uptake does not drop immediately to resting baseline. Instead, oxygen consumption remains elevated above pre-exercise levels—a physiological phenomenon termed EPOC (Excess Post-Exercise Oxygen Consumption):

- Fast Component (2 to 3 minutes post-exercise): Aerobically resynthesizes intramuscular phosphocreatine (PCr) stores and replenishes myoglobin/hemoglobin oxygen binding.
- Slow Component (hours post-exercise): Elevates metabolic rate to clear accumulated blood lactate, support increased core body temperature, metabolize circulating catecholamines, and replenish glycogen reserves.

### Key Terminology / Glosario Clave

A standardized physiological unit representing the resting energy expenditure of the human body, defined as 3.5 mL of oxygen consumed per kilogram of body weight per minute (1 MET = 3.5 mL O2/kg/min or approx. 1 kcal/kg/hour).

Unidad fisiológica que representa el gasto energético de reposo, definida como 3.5 mL de oxígeno por kilogramo de peso corporal por minuto (1 MET = 3.5 mL O2/kg/min).

The exercise power output or oxygen uptake at which systemic blood lactate concentration systematically increases above baseline resting levels, reflecting a disequilibrium between lactate production and metabolic clearance.

La intensidad de ejercicio donde la concentración de lactato en sangre aumenta exponencialmente por encima de los valores de reposo debido a una mayor tasa de producción que de depuración.

An aerobic mitochondrial recovery process requiring 2 to 5 minutes of passive or low-intensity active recovery to restore cellular phosphocreatine pools post-maximal anaerobic exertion.

Proceso mitocondrial aeróbico que requiere de 2 a 5 minutos de descanso para restaurar las reservas de fosfocreatina muscular tras esfuerzos anaeróbicos máximos.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Bioenergética del Movimiento

Select each question below to confirm your understanding of bioenergetics and PAGA standards before starting Discussion 06 and Lab 06:

English Response: The Phosphagen System (ATP-PCr) produces ATP at the fastest rate (highest power) but has the lowest capacity (<10 seconds). The Oxidative Phosphorylation System produces ATP at the slowest rate but provides a virtually unlimited total yield (highest capacity over hours of physical activity).

Respuesta en Español: El Sistema de Fosfágenos (ATP-PCr) produce ATP a la velocidad más rápida (mayor potencia) pero tiene la menor capacidad (<10 segundos). La Fosforilación Oxidativa produce ATP más lentamente pero con un rendimiento prácticamente ilimitado (mayor capacidad durante horas).

English Response: Oxygen deficit occurs because mitochondrial respiration and cardiorespiratory oxygen delivery take 1 to 4 minutes to ramp up and reach steady state. During this latency period, cellular ATP demands are supplied anaerobically by the Phosphagen and Fast Glycolytic pathways.

Respuesta en Español: El déficit de oxígeno ocurre porque el suministro cardiorrespiratorio y la respiración mitocondrial tardan de 1 a 4 minutos en alcanzar el estado estable. Durante este retraso, la demanda de ATP se cubre anaeróbicamente con fosfágenos y glucólisis rápida.

English Response: Adults should perform 150 to 300 minutes of moderate-intensity (3.0 to 5.9 METs) or 75 to 150 minutes of vigorous-intensity (6.0+ METs) aerobic physical activity weekly (or an equivalent combination), generating 500 to 1,000 MET-minutes per week.

Respuesta en Español: Los adultos deben acumular de 150 a 300 minutos de actividad aeróbica moderada (3.0 a 5.9 METs) o de 75 a 150 minutos de actividad vigorosa (6.0+ METs) a la semana, acumulando de 500 a 1,000 MET-minutos semanales.


### AI Simulation Workspace • Bioenergetics & Metabolic Simulation

Copy the prompt below into Gemini to audit client energy systems, calculate MET-minutes, and design work-to-rest interval conditioning prescriptions:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-101 Module 06 Bioenergetics Tool Box ###:
Role: Academic Kinesiology Mentor and Exercise Physiologist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Energy Expenditure & Aerobic Mandates.

Instructions:
Step 1: Review the client profile enclosed within triple-hashes (###) below.
Step 2: PATTERN: Identify the primary energy systems powering their physical movement (Phosphagen, Fast Glycolysis, Oxidative) and analyze their ATP resynthesis rate and fatigue limiting factors.
Step 3: RULE: Apply federal PAGA 2018 guidelines to evaluate target MET-minutes and weekly aerobic energy expenditure standards.
Step 4: SOLVE: Formulate an individualized interval conditioning routine prescribing appropriate work-to-rest ratios (1:12 to 1:20 for ATP-PCr; 1:3 to 1:5 for glycolysis; 1:1 to 1:3 for oxidative) adapted for Yuma County climate conditions.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
Client Age & Background: [e.g., 42-year-old municipal worker returning to conditioning]
Target Activity / Sport: [e.g., High-intensity interval rowing vs. 5K distance walking]
Session Duration & Workload: [e.g., 30 seconds maximal effort repeats vs. 45 minutes continuous aerobic pace]
Current Fitness Level: [e.g., Experiences severe lactic burn and fatigue after 60 seconds of effort]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 06 (Mod 06 Required Readings: Energy Systems & Workout Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. Digital OER text is fully accessible to screen readers without downloading external PDFs.

Español: Todos los materiales de lectura de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando accesibilidad total para lectores de pantalla sin descargas de pago.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas Obligatorias: Vías Metabólicas y Bioenergética Humana


### Texto Fuente SSoT y Lineamientos de Gasto Energético

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) (Capítulo 2: Pautas de Actividad Física para Adultos • Balance Energético y Adaptaciones Metabólicas).

Manual Oficial y Capítulos PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev/chapters)

- Actividad Moderada: 3.0 a 5.9 METs (150 a 300 minutos semanales).
- Actividad Vigorosa: 6.0 METs o más (75 a 150 minutos semanales).
- Gasto Objetivo: 500 a 1,000 MET-minutos acumulados por semana.

### Conceptos Científicos Centrales


#### Step 1: El Continuo Bioenergético y Resíntesis de ATP

El ATP es la moneda energética directa de la contracción muscular. El sistema de fosfágenos (ATP-PCr) aporta energía inmediata de máxima potencia pero capacidad muy baja (<10 s); la glucólisis rápida anaeróbica sostiene esfuerzos intensos (10 a 120 s); y la fosforilación oxidativa mitocondrial aporta energía aeróbica ilimitada a menor tasa para esfuerzos sostenidos.


#### Step 2: Déficit de Oxígeno y Consumo Post-Ejercicio (EPOC)

Al iniciar el ejercicio, existe un retraso en el consumo de oxígeno (Déficit de Oxígeno) que se compensa anaeróbicamente. Al finalizar, el consumo de oxígeno se mantiene elevado (EPOC) para resintetizar la fosfocreatina, metabolizar el lactato y restaurar la temperatura corporal.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-101 • Module 06 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 06:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 06)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
