## KIN-101: Mod 06 Summary And Wrap Up Energy Systems And Workout Fueling

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 06 Summary & Wrap-Up: Energy Systems & Workout Fueling

Bioenergética del Movimiento, Vías Metabólicas y Normas Federales de Gasto Energético PAGA


### Step 1: Core Bioenergetic Synthesis & Metabolic Pathways

Congratulations on completing Module 06! You have mastered the biochemical and kinesiological principles governing ATP resynthesis, oxygen deficit kinetics, and work-to-rest interval conditioning based on PAGA 2018 standards:

- The Bioenergetic Continuum: Human movement relies on three integrated metabolic systems. Immediate explosive bursts (<10 seconds) draw upon stored phosphagens (ATP-PCr), high-intensity anaerobic efforts (10 to 120 seconds) rely on fast glycolysis with lactate and hydrogen ion formation, and sustained endurance activities (>2 minutes) depend on mitochondrial oxidative phosphorylation.
- Oxygen Deficit & EPOC: The lag in oxygen delivery during movement transitions creates an initial oxygen deficit that is supplied anaerobically. Post-exercise oxygen consumption (EPOC) remains elevated to clear metabolic byproducts, resynthesize phosphocreatine, and restore baseline cellular homeostasis.
- PAGA 2018 Energy Expenditure Targets: Adults should accumulate 150 to 300 minutes of moderate-intensity (3.0 to 5.9 METs) or 75 to 150 minutes of vigorous-intensity (6.0+ METs) aerobic physical activity weekly, aiming for 500 to 1,000 MET-minutes per week to optimize cardiorespiratory and metabolic health.

### Step 2: Workplace Intelligence & AI Bioenergetic Auditing

In cardiorespiratory rehabilitation centers like Matador Clinical Partners (MCP), community wellness facilities, and collegiate athletic complexes at Arizona Western College (AWC), kinesiology specialists leverage generative AI tools to audit client metabolic profiles, evaluate oxygen deficit limitations, and design interval conditioning plans.

- AI-Assisted Metabolic Modeling: Kinesiologists prompt AI preceptors to analyze client workloads, compute weekly MET-minutes, and project fatigue thresholds based on energy system kinetics.
- Delimiter Security Protocol (###): Client biometric files and exercise data (MET levels, session duration, work-to-rest intervals) must be enclosed inside triple hashes ( ### ) to maintain strict data boundaries during automated preceptor audits.
- Human-in-the-Loop Clinical Verification: Exercise specialists verify AI-generated interval training models against federal PAGA 2018 guidelines to ensure work-to-rest ratios (1:12 to 1:20 for phosphagen; 1:3 to 1:5 for glycolysis; 1:1 to 1:2 for oxidative) prevent premature metabolic exhaustion.

### Step 3: Module 06 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 07:

English Response: The Phosphagen System (ATP-PCr) produces ATP at the fastest rate (highest power) but has the lowest capacity (<10 seconds). The Oxidative Phosphorylation System produces ATP at the slowest rate but provides a virtually unlimited total yield (highest capacity over hours of physical activity).

Respuesta en Español: El Sistema de Fosfágenos (ATP-PCr) produce ATP a la tasa más rápida (mayor potencia) pero con la menor capacidad (<10 segundos). La Fosforilación Oxidativa produce ATP más lentamente pero con un rendimiento prácticamente ilimitado durante horas.

English Response: Oxygen deficit occurs because mitochondrial cellular respiration and cardiovascular oxygen delivery take 1 to 4 minutes to adjust and achieve steady-state Maximum Oxygen Uptake (VO₂ Max). During this lag period, the immediate ATP demand is supplied anaerobically by the Phosphagen and Fast Glycolytic pathways.

Respuesta en Español: El déficit de oxígeno ocurre porque el suministro cardiorrespiratorio y la respiración mitocondrial tardan de 1 a 4 minutos en alcanzar el estado estable. Durante este retraso, la demanda de ATP se cubre anaeróbicamente mediante fosfágenos y glucólisis rápida.

English Response: Fast glycolytic training requires a 1:3 to 1:5 work-to-rest ratio (e.g., 30 seconds of high-intensity work followed by 90 to 150 seconds of active recovery) to allow sufficient buffering and clearance of intracellular hydrogen ions (H+) and lactate before the next bout.

Respuesta en Español: El entrenamiento glucolítico rápido requiere una relación de trabajo-descanso de 1:3 a 1:5 (ej. 30 segundos de esfuerzo intenso por 90 a 150 segundos de recuperación activa) para permitir la amortiguación de iones de hidrógeno y lactato.

English Response: Adults should accumulate 150 to 300 minutes of moderate-intensity (3.0 to 5.9 METs) or 75 to 150 minutes of vigorous-intensity (6.0+ METs) aerobic physical activity weekly (or an equivalent combination), generating 500 to 1,000 MET-minutes per week.

Respuesta en Español: Los adultos deben acumular de 150 a 300 minutos de actividad moderada (3.0 a 5.9 METs) o de 75 a 150 minutos de actividad vigorosa (6.0+ METs) por semana, alcanzando de 500 a 1,000 MET-minutos semanales.

English Response: EPOC keeps metabolic rate elevated post-exercise to replenish intramuscular phosphocreatine stores, clear lactate, clear accumulated hydrogen ions, and support elevated heart rate and core temperature recovery.

Respuesta en Español: El EPOC mantiene elevado el metabolismo después del ejercicio para reponer las reservas de fosfocreatina intramuscular, depurar el lactato, eliminar los iones de hidrógeno acumulados y apoyar la recuperación de la frecuencia cardíaca y la temperatura central.

English Response: Enclosing client workout parameters and MET metrics inside triple hashes (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 energy standards.

Respuesta en Español: Encapitular los parámetros de entrenamiento y las métricas de MET entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas energéticas de PAGA 2018.

English Response: Desert heat stress elevates cardiovascular strain and accelerates glycogen depletion, making indoor air-conditioned facilities (72°F / 22°C) vital for safe metabolic testing and conditioning.

Respuesta en Español: El estrés por calor en el desierto eleva la sobrecarga cardiovascular y acelera el agotamiento de glucógeno, haciendo vitales las instalaciones climatizadas (22 °C) para pruebas y acondicionamiento metabólico seguro.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth for all energy expenditure and volume standards.

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal para todas las normas de gasto energético y volumen.


### AI Simulation Workspace • Bioenergetics & Energy Systems Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive bioenergetic review matrix connecting ATP resynthesis rates, oxygen deficit kinetics, and PAGA 2018 energy expenditure standards:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: KIN-101 Module 06 Bioenergetics Synthesis ###:
Role: Academic Kinesiology Mentor and Exercise Physiologist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Energy Expenditure & Metabolic Adaptation Framework.

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
     Bioenergetic Energy Systems (Phosphagen ATP-PCr vs. Fast Glycolysis vs. Oxidative Phosphorylation).
     Kinetic Parameters (Power / ATP Resynthesis Rate, Capacity / Total Yield, Primary Substrates, Limiting Fatigue Factor).
     Interval Conditioning Prescriptions (Target Duration, Recommended Work-to-Rest Ratios, Recovery Mechanisms).
Step 2: Detail the physiological mechanisms of Oxygen Deficit and Excess Post-Exercise Oxygen Consumption (EPOC), explaining how PAGA 2018 MET-minute targets promote long-term mitochondrial health.
Step 3: Keep all formulas in plain text and wrap all data inputs within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 07 — Kinesiology & Motion (Anatomical Planes & Gait)

In plain English, next week in Module 07: Kinesiology & Motion you will learn how to observe human movement across three directions (front-to-back, side-to-side, and rotational planes) and spot joint compensations during walking, squatting, or lifting. Why it matters: training your coaching eye to catch knee cave or lower-back rounding early prevents workplace and gym injuries before they happen.

- Pattern (Context): Analyzing movement across sagittal, frontal, and transverse planes and observing human gait and squat mechanics.
- Rule (Constraint): Applying biomechanical alignment rules and PAGA 2018 injury-prevention progressions before adding external load.
- Solve (Intervention): Completing Mod 07 Discussion: Anatomical Planes & Gait and Mod 07 Lab: Movement Efficiency Analysis .

### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 06 (Mod 06 Summary & Wrap-Up: Energy Systems & Workout Fueling)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 06: Resumen y Cierre del Módulo

Bioenergética del Movimiento, Vías Metabólicas y Gasto Energético PAGA


### Step 1: Síntesis Bioenergética y Vías Metabólicas

¡Felicitaciones por completar el Módulo 06! Ha establecido los conocimientos fundamentales sobre la resíntesis de ATP, la cinética del déficit de oxígeno y la prescripción de intervalos de trabajo y descanso según las normas PAGA 2018:

- Continuo Bioenergético: El movimiento humano depende de tres sistemas: fosfágenos (máxima potencia, <10 s), glucólisis rápida anaeróbica (esfuerzos intensos de 10 a 120 s) y fosforilación oxidativa mitocondrial (resistencia aeróbica prolongada).
- Déficit de Oxígeno y EPOC: El retraso en el suministro de oxígeno crea un déficit inicial cubierto anaeróbicamente, mientras que el EPOC mantiene elevado el consumo de oxígeno post-ejercicio para restaurar la fosfocreatina y depurar el lactato.
- Metas de Gasto Energético PAGA 2018: Se recomienda acumular de 150 a 300 minutos de actividad moderada (o de 500 a 1,000 MET-minutos/semana) para fortalecer la capacidad oxidativa y la salud cardiorrespiratoria.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría Bioenergética con IA

En clínicas de rehabilitación como Matador Clinical Partners (MCP) y centros deportivos de AWC, los especialistas utilizan IA generativa para evaluar perfiles de esfuerzo, auditar el déficit de oxígeno y estructurar entrenamientos por intervalos.

- Modelado Asistido por IA: Cálculo de MET-minutos semanales y simulación de umbrales de fatiga según los sistemas energéticos predominantes.
- Seguridad con Delimitadores (###): Uso de tres numerales ( ### ) para aislar datos biométricos y parámetros de entrenamiento.
- Verificación Clínica Humana: Los profesionales revisan las relaciones de trabajo y descanso de la IA frente a las normas PAGA 2018 para evitar sobrecargas metabólicas.

### Step 3: Autoevaluación del Módulo 06 (Verificación Bilingüe)

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 07:

Respuesta en Español: El Sistema de Fosfágenos (ATP-PCr) produce ATP a la tasa más rápida (mayor potencia) pero tiene la menor capacidad (<10 s). La Fosforilación Oxidativa produce ATP más lentamente pero con un rendimiento ilimitado (mayor capacidad durante horas).

English Response: The Phosphagen System (ATP-PCr) produces ATP at the fastest rate (highest power) but has the lowest capacity (<10 seconds). The Oxidative Phosphorylation System produces ATP at the slowest rate but provides a virtually unlimited total yield.

Respuesta en Español: El déficit de oxígeno ocurre porque el suministro cardiorrespiratorio y la respiración mitocondrial tardan de 1 a 4 minutos en alcanzar el estado estable. Durante este retraso, la demanda de ATP se cubre anaeróbicamente mediante fosfágenos y glucólisis rápida.

English Response: Oxygen deficit occurs because mitochondrial cellular respiration and cardiovascular oxygen delivery take 1 to 4 minutes to adjust and achieve steady-state VO2.

Respuesta en Español: Se recomienda una relación de 1:3 a 1:5 (ej. 30 segundos de trabajo por 90 a 150 segundos de descanso activo) para permitir la amortiguación del lactato y los iones de hidrógeno.

English Response: Fast glycolytic training requires a 1:3 to 1:5 work-to-rest ratio to allow sufficient buffering and clearance of intracellular hydrogen ions and lactate.

Respuesta en Español: Acumular de 150 a 300 minutos de actividad moderada (3.0 a 5.9 METs) o de 75 a 150 minutos de actividad vigorosa (6.0+ METs) a la semana (500 a 1,000 MET-minutos/semana).

English Response: Adults should accumulate 150 to 300 minutes of moderate-intensity or 75 to 150 minutes of vigorous-intensity aerobic physical activity weekly, generating 500 to 1,000 MET-minutes per week.

Respuesta en Español: El EPOC mantiene elevado el metabolismo después del ejercicio para reponer las reservas de fosfocreatina intramuscular, depurar el lactato, eliminar los iones de hidrógeno acumulados y apoyar la recuperación de la frecuencia cardíaca y la temperatura central.

English Response: EPOC keeps metabolic rate elevated post-exercise to replenish intramuscular phosphocreatine stores, clear lactate, clear accumulated hydrogen ions, and support elevated heart rate and core temperature recovery.

Respuesta en Español: Encapitular los parámetros de entrenamiento y las métricas de MET entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva de instrucciones y mantiene una alineación precisa con las normas energéticas de PAGA 2018.

English Response: Enclosing client workout parameters and MET metrics inside triple hashes (`###`) ensures data boundary isolation, prevents instruction drift, and maintains precise alignment with PAGA 2018 energy standards.

Respuesta en Español: El estrés por calor en el desierto eleva la sobrecarga cardiovascular y acelera el agotamiento de glucógeno, haciendo vitales las instalaciones climatizadas (22 °C) para pruebas y acondicionamiento metabólico seguro.

English Response: Desert heat stress elevates cardiovascular strain and accelerates glycogen depletion, making indoor air-conditioned facilities (72°F / 22°C) vital for safe metabolic testing and conditioning.

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal para todas las normas de gasto energético y volumen.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth for all energy expenditure and volume standards.


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: KIN-101 Sintesis Modulo 06 ###:
Rol: Mentor Academico de Kinesiologia y Fisiologo del Ejercicio.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Gasto Energetico y Adaptaciones Metabolicas.

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
     Sistemas Bioenergeticos (Fosfagenos ATP-PCr vs. Glucolisis Rapida vs. Fosforilacion Oxidativa).
     Parametros Cineticos (Potencia / Tasa de Resintesis, Capacidad / Rendimiento Total, Sustratos Principales, Factor Limitante).
     Prescripcion de Intervalos (Duracion Objetivo, Relaciones Trabajo-Descanso Recomendadas, Mecanismos de Recuperacion).
Step 2: Detallar los mecanismos de Deficit de Oxigeno y EPOC, explicando como las metas de MET-minutos de PAGA 2018 mejoran la salud mitocondrial.
Step 3: Mantener todas las formulas en texto plano y los datos entre delimitadores (###).
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 07 — Kinesiología y Movimiento (Planos Anatómicos y Marcha)

En palabras sencillas (Contexto Norteño): antes de meterle más peso a la barra o mandar a alguien a correr, hay que saber ver cómo se mueven sus rodillas, caderas y espalda desde el frente y de lado. Si los nombres anatómicos se ponen pesados la próxima semana, concéntrate primero en los tres planos de movimiento (sagital, frontal y transversal) y en cómo detectar malas posturas al caminar o agacharse.

- Patrón (Contexto): Observar el movimiento humano en los planos sagital, frontal y transversal durante la marcha y la sentadilla.
- Regla (Restricción): Aplicar principios de alineación articular y progresión segura de PAGA 2018 para prevenir lesiones.
- Solución (Intervención): Completar el Foro del Mód 07 (Anatomical Planes & Gait) y el Laboratorio del Mód 07 (Movement Efficiency Analysis) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-101 • Module 06 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 06:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 06)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
