## KIN-101 MODULE-06: SPORT PSYCHOLOGY / Master Content Loop

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## > ###  Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (Kinesiology disciplines and foundational physical activity rules).

## KIN-101: MODULE 06 - INTRODUCTION TO SPORT & EXERCISE PSYCHOLOGY

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module explores the psychological variables influencing physical activity adherence, exercise behavior modification, and the cognitive benefits of regular human movement. Students will examine behavioral models, motivational constructs, and psychological barriers that impact community-wide active lifestyle choices. All psychological metrics and behavioral frameworks align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo explora las variables psicológicas que influyen en la adherencia a la actividad física, la modificación de la conducta de ejercicio y los beneficios cognitivos del movimiento humano regular. Los estudiantes examinarán modelos conductuales, constructos motivacionales y barreras psicológicas que impactan las elecciones de estilo de vida activo en la comunidad. Todos los parámetros psicológicos y los marcos conductuales se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.16]):** Evaluate behavioral adherence patterns across diverse communities and apply federal psychological guidelines to design sustainable exercise motivation frameworks.
* **Español (Regional) ([LO 2.16]):** Evaluar los patrones de adherencia conductual en diversas comunidades y aplicar las pautas psicológicas federales para diseñar marcos sostenibles de motivación para el ejercicio.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Identify and document negative behavior patterns, including drop-out rates, low self-efficacy indicators, and perceived cognitive barriers to physical activity within a community demographic.
   * **Patrón (Español):** Identificar y documentar los patrones de conducta negativos, incluyendo las tasas de abandono, los indicadores de baja autoeficacia y las barreras cognitivas percibidas para la actividad física dentro de una demografía comunitaria.
2. **Rule (English):** Apply the psychological well-being data and mental health guidelines detailed in the federal PAGA 2018 framework to establish target behavior parameters.
   * **Regla (Español):** Aplicar los datos de bienestar psicológico y las pautas de salud mental detalladas en el marco federal de PAGA 2018 para establecer parámetros de conducta objetivo.
3. **Solve (English):** Engineer an evidence-based behavioral intervention strategy using structured goal-setting and social-support networks to improve long-term exercise adherence safely.
   * **Solución (Español):** Diseñar una estrategia de intervención conductual basada en la evidencia utilizando el establecimiento de metas estructuradas y redes de apoyo social para mejorar de forma segura la adherencia al ejercicio a largo plazo.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Andamiaje

## Part A: Gemini AI Simulation (Behavioral Adherence Simulation)

## English

Students will initialize the virtual psychological mapping environment within their sandbox workspace. Ensure your simulated behavioral profile inputs remain completely wrapped within the required layout delimiters below.

```text
## [PASTE SIMULATED COMMUNITY ADHERENCE AND EXERCISE MOTIVATION DATA HERE]
###
```

1. Use the sandbox environment to audit a simulated behavioral dataset, tracking dropout risk timelines and self-efficacy dips.
2. Cross-examine virtual behavioral resistance markers against the cognitive health benefits established in the primary chapters of the federal PAGA source documentation.
3. Execute an automated data validation pass within the sandbox to verify that proposed motivational strategies align with long-term activity volume targets.

## Español (Regional)

Los estudiantes inicializarán la configuración del mapeo psicológico virtual dentro de su espacio de trabajo sandbox. Asegúrese de que las entradas de perfiles conductuales simulados permanezcan completamente envueltas dentro de los delimitadores de diseño requeridos a continuación.

```text
## [PEGUE LOS DATOS SIMULADOS DE ADHERENCIA COMUNITARIA Y MOTIVACIÓN PARA EL EJERCICIO AQUÍ]
###
```

1. Utilizar el entorno de pruebas (sandbox) para auditar un conjunto de datos conductuales simulados, rastreando los cronogramas de riesgo de abandono y las disminuciones en la autoeficacia.
2. Evaluar de forma cruzada los marcadores virtuales de resistencia conductual frente a los beneficios de salud cognitiva establecidos en los capítulos principales de la documentación oficial de PAGA.
3. Ejecutar un pase de validación de datos automatizado dentro del sandbox para verificar que las estrategias motivacionales propuestas se alineen con los objetivos de volumen de actividad a largo plazo.

## Part B: Practical Field Application (Exercise Adherence Barrier Log)

## English

Students will transition into their immediate personal environments to complete a practical, zero-cost qualitative physical activity barrier assessment with a peer.

1. Complete a visual behavior interview and tracking log assessing a peer's historical barriers to exercise, recording specific indicators of amotivation, extrinsic motivation, or intrinsic drive.
2. Map observed cognitive obstacles onto structured behavioral change models, identifying the precise stage of change.
3. Document true psychological indicators: record qualitative motivation indices and cross-examine your field findings against the targets outlined in the federal PAGA guidelines.

## Español (Regional)

Los estudiantes harán la transición a sus entornos personales inmediatos para completar una evaluación cualitativa práctica y de costo cero sobre las barreras para la actividad física con un compañero.

1. Completar una entrevista de conducta visual y un registro de seguimiento que evalúe las barreras históricas de un compañero para el ejercicio, registrando indicadores específicos de amotivación, motivación extrínseca o impulso intrínseco.
2. Mapear los obstáculos cognitivos observados en modelos estructurados de cambio de conducta, identificando la etapa precisa del cambio.
3. Documentar los indicadores psicológicos reales: registrar los índices cualitativos de motivación y evaluar de forma cruzada sus hallazgos de campo con las metas descritas en las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This behavioral module assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación del módulo conductual se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):
  * **English:** Zero-drift integration. All proposed behavior modification interventions align perfectly with PAGA data parameters; all simulation logs remain completely wrapped within delimiters.
  * **Español (Regional):** Integración sin desviaciones. Todas las intervenciones de modificación de conducta propuestas se alinean perfectamente con los parámetros de datos de PAGA; todos los registros de simulación permanecen completamente delimitados dentro de los delimitadores.
* **7 (Competent) / (Competente):
  * **English:** Minor refactoring required. Core Clinical Framing Protocol steps and psychological rules are appropriately applied, but minor formatting gaps are flagged in the final file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los pasos del Protocolo de Encuadre Clínico y las reglas psicológicas se aplican adecuadamente, pero se identifican pequeñas brechas de formato en el archivo final.
* **0 (Recalibrate) / (Recalibrar):
  * **English:** Critical error in identifying behavior modification stages or un-fenced community profiling metrics that violate federal guidelines. Complete rewrite required.
  * **Español (Regional):** Error crítico en la identificación de las etapas de modificación de conducta o métricas de perfil comunitario sin delimitar que violan las pautas federales. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection


### Closes: Monday @ 11:59 PM


Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.






## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 06)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 06)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
