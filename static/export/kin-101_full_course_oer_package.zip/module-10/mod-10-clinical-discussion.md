## KIN-101: Mod 10 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 10) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 10 Discussion: Healthy Body Composition & Energy Balance

Foro de Discusión del Módulo 10: Balance Energético vs. Resultados de Control de Peso


### Discussion Overview: Thermodynamic Principles & Body Composition Auditing

In this week's discussion, we explore the laws of thermodynamics governing energy balance, basal metabolic rate, and body composition assessment. Operating within your chosen career track, you will examine how caloric intake versus expenditure and fat-free mass preservation influence long-term metabolic health and weight management.

En la discusión de esta semana, exploramos las leyes de la termodinámica que rigen el balance energético, la tasa metabólica basal y la evaluación de la composición corporal. Trabajando dentro de su ruta profesional elegida, examinará cómo la ingesta frente al gasto calórico influyen en la salud metabólica.


### Build Your Own Journey • Choose Your Clinical Simulation Track / Elija su Ruta Profesional

Select ONE of the three career-aligned tracks below to guide your initial discussion post and AI preceptor consultation:

Clinical obesity management, DXA body fat distribution analysis, and metabolic syndrome risk reduction protocols. Manejo clínico de la obesidad, análisis de distribución de grasa corporal por DXA y protocolos de reducción de riesgo metabólico.

School-based body composition screening, youth metabolic health education, and community weight management initiatives. Evaluación de composición corporal escolar, educación sobre salud metabólica juvenil e iniciativas comunitarias.

Weight-class optimization for combat sports, lean mass preservation during caloric deficits, and body fat percentage tracking. Optimización de categoría de peso para deportes de combate, preservación de masa magra y seguimiento de grasa corporal.


### Phase 2: Gemini AI Clinical Simulation Consultation / Consulta de IA

Paso 2: Copie la plantilla y consulte a Gemini para auditar su balance energético

Paste your chosen Track case data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Initial Post Prompt & Clinical Framing Protocol Requirements / Requisitos de la Publicación Inicial

Your initial discussion post must address the following four structured components:

- Step 1: Pattern Recognition: Identify the thermodynamic, metabolic, or body composition limitation within your chosen track case profile. Identifique la limitación termodinámica, metabólica o de composición corporal en su perfil de ruta.
- Step 2: Rule Application: Cite the specific weight management and physical activity benchmarks outlined in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) . Cite los estándares específicos de control de peso de la PAGA 2018 (2.ª ed.) .
- Step 3: Solution Formulation: Propose an evidence-based energy balance and lean mass preservation strategy tailored to your track's client. Proponga una estrategia de balance energético y preservación de masa magra adaptada al cliente de su ruta.
- Step 4: Bilingual Summary: Include a 1-sentence bilingual takeaway summarizing your body composition strategy in English and Spanish. Incluya una conclusión bilingüe de una oración que resuma su estrategia de composición corporal.

### Official Student Exemplar / Modelo de Ejemplar Estudiantil

Selected Track: Track 1 (Clinical & Allied Health Path) • Participant J.M. (Age 42)

- Step 1: Pattern Recognition: Participant J.M. exhibits metabolic syndrome risk factors and experienced severe lean mass depletion during prior unguided caloric restriction due to adaptive thermogenesis.
- Step 2: Rule Application: Under PAGA 2018 (2nd Ed.) guidelines, sustainable weight loss maintenance requires >300 minutes of weekly moderate-to-vigorous physical activity paired with muscle-strengthening exercises on 2 or more days per week to preserve Fat-Free Mass.
- Step 3: Solution Formulation (Energy Balance Strategy): Energy Deficit: Moderate 500 kcal/day deficit to prevent extreme metabolic down-regulation. Resistance Training: 3 days per week of progressive compound movements to provide the mechanical stimulus necessary to protect Fat-Free Mass. Aerobic Activity: 250 minutes per week of moderate-intensity activity to support total daily energy expenditure.
- Energy Deficit: Moderate 500 kcal/day deficit to prevent extreme metabolic down-regulation.
- Resistance Training: 3 days per week of progressive compound movements to provide the mechanical stimulus necessary to protect Fat-Free Mass.
- Aerobic Activity: 250 minutes per week of moderate-intensity activity to support total daily energy expenditure.
- Step 4: Bilingual Summary / Resumen Bilingüe: EN: "Preserving fat-free mass through resistance training during a moderate caloric deficit prevents adaptive thermogenesis and ensures sustainable weight loss." ES: "Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible."

### Safety Auditor Protocol & Peer Response Guidelines / Protocolo del Auditor de Seguridad

When drafting your post or auditing peer responses, you must enclose any simulated client profile data or AI preceptor notes within triple-hash delimiters to maintain professional data governance standards:


```text
Discussion Peer Audit: Body Composition Track 1 ###:
Student Auditor: Clinical Track Peer Review
Review Focus: Evaluating TDEE calculations and lean mass preservation protocols against PAGA 2018 standards.
End Audit ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 10 (Mod 10 Discussion: Healthy Body Composition & Energy Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Foro de Discusión del Módulo 10: Balance Energético vs. Resultados de Control de Peso


### Descripción General de la Discusión: Principios Termodinámicos y Composición Corporal

En la discusión de esta semana, exploramos las leyes de la termodinámica que rigen el balance energético, la tasa metabólica basal y la evaluación de la composición corporal. Trabajando dentro de su ruta profesional elegida, examinará cómo la ingesta frente al gasto calórico y la preservación de la masa libre de grasa influyen en la salud metabólica a largo plazo.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , auditará un escenario de balance energético, aplicará las normas federales de PAGA 2018 (2.ª ed.) y participará en la revisión por pares utilizando el protocolo del Auditor de Seguridad.


### Requisitos para la Publicación Inicial

- Step 1: Reconocimiento de Patrones: Identifique la limitación termodinámica, metabólica o de composición corporal descrita en su perfil de ruta.
- Step 2: Aplicación de Reglas: Cite los estándares específicos de control de peso de la PAGA 2018 (2.ª ed.) .
- Step 3: Formulación de Soluciones: Proponga una estrategia de balance energético y preservación de masa magra adaptada al cliente de su ruta.
- Step 4: Resumen Bilingüe: Incluya una frase bilingüe que resuma su estrategia de composición corporal en inglés y español.
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 10)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
