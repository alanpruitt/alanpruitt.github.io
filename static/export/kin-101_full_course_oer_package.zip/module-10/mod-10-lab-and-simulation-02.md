## KIN-101: Mod 10 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Lab & Simulation: Body Composition & Healthy Weight Audit

Laboratorio del Módulo 10: Auditoría de Composición Corporal y Simulación

- Total Daily Energy Expenditure (TDEE) & PAGA Weight-Maintenance Volume: Total 24-hour calorie burn (Resting Metabolic Rate + Physical Activity + Thermic Effect of Food); PAGA 2018 notes that weight stability and fat loss often require 250–300+ minutes/week of moderate aerobic activity. En palabras sencillas: Toda la energía que tu cuerpo gasta al día; para cuidar el peso de forma saludable en Yuma sin dietas extremas, apuntamos a 250–300+ minutos semanales de movimiento moderado.
- Waist-to-Hip Ratio (WHR) & Visceral Adiposity (vs. BMI Alone): Body Mass Index (BMI = kg/m²) cannot distinguish lean muscle from fat; waist circumference (>40 in men / >35 in women) and WHR track deep visceral fat around vital organs. En palabras sencillas: El IMC por sí solo puede confundir músculo con grasa; medir la cintura nos muestra si hay grasa profunda alrededor de los órganos que sube el riesgo cardíaco y metabólico.
- Fat-Free Mass (FFM) Preservation (Resistance Training ≥2 Days/Week): Caloric restriction without resistance training strips away lean muscle and depresses resting metabolism; PAGA 2018 mandates ≥2 days/week of muscle-strengthening across all major muscle groups to preserve FFM. En palabras sencillas: Bajar de peso sin entrenar fuerza te quita músculo y frena el metabolismo; por eso incluimos mínimo 2 días por semana de fuerza para proteger el músculo.

### Thermodynamic Principles, Energy Balance, & Lean Mass Preservation

In this laboratory assignment, you will conduct a qualitative body composition and energy balance audit and construct an evidence-based metabolic remediation protocol. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze basal metabolic rate, total daily energy expenditure, and fat-free mass preservation, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) weight management standards, and execute an AI-driven simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría cualitativa de la composición corporal y el balance energético, diseñando un protocolo metabólico basado en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando principios termodinámicos.

- KIN-101.10.3.AY26-27: Evaluate thermodynamic energy balance equations, basal metabolic rate factors, and body composition assessment methods across diverse populations. Evaluar las ecuaciones de balance energético termodinámico, los factores de la tasa metabólica basal y los métodos de evaluación de la composición corporal.
- KIN-101.10.4.AY26-27: Design energy balance remediation protocols and bilingual coaching cue cards aligned with PAGA 2018 weight management standards. Diseñar protocolos de remediación del balance energético y tarjetas de instrucción bilingües alineadas con las pautas de control de peso de la PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, October 20, 2026, at 12:00 AM MST Abre el martes, 20 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 26, 2026, at 11:59 PM MST lunes, 26 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones prácticas

### Lab Objectives

Objetivos del Laboratorio

- Audit the thermodynamic mechanisms of energy flux, basal metabolic rate determination, and fat-free mass preservation during weight management. Auditar los mecanismos termodinámicos del flujo energético, la determinación de la tasa metabólica basal y la preservación de la masa libre de grasa.
- Apply federal PAGA 2018 (2nd Ed.) weight management standards to structure progressive lifestyle programs that prevent adaptive thermogenesis. Aplicar las pautas de control de peso de la PAGA 2018 para estructurar programas de estilo de vida progresivos que prevengan la termogénesis adaptativa.
- Formulate a 4-week energy balance remediation plan paired with bilingual coaching cue cards in English and Spanish. Formular un plan de remediación del balance energético de 4 semanas con tarjetas de instrucción bilingües en inglés y español.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-10

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos de Composición Corporal

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Clinical obesity management; auditing metabolic syndrome markers, adaptive thermogenesis, and fat-free mass preservation.

Focus: Adolescent health and metabolic literacy; designing school curricula addressing adolescent adiposity and debunking fad diets.

Focus: Weight-class optimization; managing rapid weight cuts, lean mass preservation, and recovery in combat sports.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete body composition audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline body composition profile.
- Part 1: Pattern Recognition: Identify specific thermodynamic or metabolic limitations (adaptive thermogenesis, lean mass depletion, energy flux imbalance).
- Part 2: Rule Application: Cite PAGA 2018 weight management standards and fat-free mass preservation principles.
- Part 3: Solving the Gap (Active Verification & Prescription): In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your 4-week remediation plan protects client safety and aligns with PAGA 2018 guidelines. Detail your progressive resistance overload, energy balance parameters, and 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient J.M. exhibits metabolic syndrome markers and experienced severe lean mass depletion during prior unguided caloric restriction due to adaptive thermogenesis. Severe energy restriction without adequate protein or resistance training drove a metabolic down-regulation, lowering Basal Metabolic Rate and triggering muscle wasting.

Part 2: Rule Application (SSoT PAGA 2018 2nd Ed Standards): Under PAGA 2018 (2nd Ed.) weight management standards, sustainable weight loss maintenance requires high energy flux (>300 minutes weekly of moderate-to-vigorous physical activity) combined with concurrent resistance training on 2 or more days per week to preserve Fat-Free Mass against metabolic down-regulation.

Part 3: Solving the Gap (Active Verification & Prescription): 4-Week Energy Balance Remediation Protocol (3 Days/Week Resistance, Daily Activity): Key Point — Caloric Strategy: Moderate 500 kcal/day deficit relative to TDEE to prevent extreme adaptive thermogenesis. Key Point — Resistance Overload: 3 days per week of compound lifting to provide the mechanical stimulus required to protect Fat-Free Mass. Key Point — Aerobic Flux: 250 to 300 minutes weekly of moderate-intensity activity to support total daily energy expenditure. Active Verification: In my clinical assessment, the most critical intervention for J.M. is protecting his skeletal muscle tissue while establishing a sustainable energy deficit. In past attempts, extreme caloric restriction crashed his resting metabolic rate through adaptive thermogenesis, driving rapid weight rebound and loss of functional strength. By anchoring his plan in progressive resistance training 3 days weekly and maintaining high energy flux with 250+ minutes of aerobic activity, we stimulate muscle protein synthesis and preserve metabolically active fat-free mass. This adheres directly to PAGA 2018 guidelines and guarantees long-term thermodynamic stability rather than dangerous short-term weight fluctuations.

EN: "Preserving fat-free mass through resistance training during a moderate caloric deficit prevents adaptive thermogenesis and ensures sustainable weight loss."

ES: "Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_101_M10_Body_Composition_Audit.pdf


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 10 (Mod 10 Lab: Body Composition & Healthy Weight Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 10 Práctica de Lab y Simulación: Auditoría de Composición Corporal y Simulación

Principios Termodinámicos, Balance Energético y Preservación de Masa Magra


### Principios Termodinámicos, Balance Energético y Preservación de Masa Magra

En esta práctica de laboratorio, realizará una auditoría cualitativa de la composición corporal y el balance energético, diseñando un protocolo metabólico. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará la tasa metabólica basal, el TDEE y la preservación de masa magra, aplicará normas de control de peso de PAGA 2018 (2.ª edición) y ejecutará una simulación con Google Gemini.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Manejo de la obesidad clínica; auditoría de marcadores de síndrome metabólico, termogénesis adaptativa y preservación de masa magra.

Enfoque: Salud adolescente y alfabetización metabólica; diseño de currículos escolares sobre adiposidad y contra mitos de dietas.

Enfoque: Optimización de categoría de peso; manejo de cortes rápidos de peso, preservación de masa magra y recuperación en deportes de combate.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Educación / Ruta 3 Deportiva) e incluya sus iniciales.


#### Parte 1: Reconocimiento de Patrones

Identifique la limitación termodinámica o metabólica de su cliente (termogénesis adaptativa, depleción de masa magra o desequilibrio en el flujo energético).


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Aplique los estándares de control de peso de la PAGA 2018 y los principios de preservación de masa libre de grasa.


#### Parte 3: Resolución de la Brecha

Detalle un plan de balance energético de 4 semanas (objetivos calóricos y sobrecarga de resistencia), junto con una tarjeta de instrucción bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: La paciente J.M. exhibe marcadores de síndrome metabólico y experimentó una severa depleción de masa magra durante restricciones calóricas previas debido a la termogénesis adaptativa. La restricción energética severa sin suficiente proteína ni entrenamiento de resistencia condujo a una regulación a la baja metabólica, reduciendo la TMB y acelerando la pérdida muscular.

Parte 2: Aplicación de Reglas (PAGA 2018): Según las pautas de control de peso de la PAGA 2018 (2.ª ed.), el mantenimiento de la pérdida de peso sostenible requiere un alto flujo energético (>300 minutos semanales de actividad física moderada a vigorosa) combinado con entrenamiento de resistencia concurrente en 2 o más días por semana para preservar la Masa Libre de Grasa.

Parte 3: Resolución de la Brecha (Verificación Activa y Prescripción): Protocolo de 4 semanas: déficit calórico moderado de 500 kcal/día en relación con el TDEE para prevenir la termogénesis adaptativa extrema, combinado con 3 días semanales de levantamiento compuesto y 250-300 minutos de actividad aeróbica semanal. Verificación Activa: En mi juicio clínico, la intervención más crítica para J.M. es proteger su tejido muscular mientras establece un déficit energético sostenible. En intentos previos, la restricción calórica extrema desplomó su tasa metabólica en reposo mediante termogénesis adaptativa, provocando un rápido rebote de peso y pérdida de fuerza funcional. Al anclar su plan en entrenamiento de resistencia progresivo 3 días a la semana y mantener un alto flujo energético con más de 250 minutos de actividad aeróbica, estimulamos la síntesis proteica muscular y preservamos la masa magra metabólicamente activa, cumpliendo plenamente con PAGA 2018. Tarjeta Bilingüe: "Preservar la masa libre de grasa mediante entrenamiento de resistencia durante un déficit calórico moderado previene la termogénesis adaptativa y garantiza una pérdida de peso sostenible."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M10_Body_Composition_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 10)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
