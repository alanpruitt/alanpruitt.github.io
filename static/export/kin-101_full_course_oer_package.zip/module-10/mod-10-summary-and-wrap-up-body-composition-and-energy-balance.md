## KIN-101: Mod 10 Summary And Wrap Up Body Composition And Energy Balance

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 10 Summary & Wrap-Up: Body Composition & Energy Balance


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Module 10 summary synthesizes energy balance principles and body composition management. You reviewed how daily caloric expenditure balances with nutrition to preserve vital lean tissue. This evidence-based foundation equips you to guide clients toward sustainable, healthy body composition.


#### En Palabras Sencillas (Norteño Context)

Hacer el balance energético es como medir el combustible de la troca: si gastas más de lo que le echas, baja el nivel, pero hay que cuidar no dañar el motor. Si los términos técnicos se ponen pesados, concéntrate primero en proteger la masa muscular con buena alimentación y ejercicio.


### Congratulations on Completing Module 10!

You have successfully audited the thermodynamic principles, energy balance equations, and body composition assessment methods governing weight management across the lifespan. This week, you analyzed basal metabolic rate (BMR), total daily energy expenditure (TDEE), and fat-free mass preservation, examined how the laws of thermodynamics dictate energy flux, and explored how federal mandates in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) require high energy flux and concurrent resistance training to prevent adaptive thermogenesis.

By integrating structured caloric strategies, lean mass protection protocols, and evidence-based body composition audits, you are prepared to optimize metabolic health and weight management outcomes across clinical rehabilitation, physical education, and athletic coaching settings.


### Clinical Framing Protocol Synthesis: Module 10 Key Takeaways

- Pattern (Thermodynamic Mechanisms): Body weight regulation is governed by the First Law of Thermodynamics, where severe caloric restriction without adequate protein or resistance training triggers adaptive thermogenesis and accelerates fat-free mass depletion.
- Rule (PAGA 2018 Standards): Federal weight management standards require high energy flux (>300 minutes weekly of moderate-to-vigorous physical activity) combined with muscle-strengthening activities on 2 or more days per week to preserve Fat-Free Mass.
- Solve (Metabolic Optimization): Implement moderate caloric deficits paired with progressive compound resistance training and bilingual cueing to ensure sustainable weight loss and lean tissue protection.

### Module 10 Knowledge Check (Self-Check Review)

Click on each question below to check your understanding of body composition, energy balance, and thermodynamic principles:

English Response: The First Law of Thermodynamics (energy cannot be created or destroyed, only transferred or stored).

Respuesta en Español: La Primera Ley de la Termodinámica (la energía no se crea ni se destruye, solo se transfiere o se almacena).

English Response: Basal Metabolic Rate (BMR), which is heavily dependent on an individual's total amount of Fat-Free Mass (FFM).

Respuesta en Español: La Tasa Metabólica Basal (TMB), la cual depende en gran medida de la cantidad total de Masa Libre de Grasa (FFM) del individuo.

English Response: Adaptive thermogenesis is a metabolic down-regulation where the body expends fewer calories than predicted during weight loss, triggered by severe caloric restriction and muscle mass loss.

Respuesta en Español: La termogénesis adaptativa es una regulación metabólica a la baja donde el cuerpo gasta menos calorías de las previstas durante la pérdida de peso, desencadenada por una restricción calórica severa.

English Response: DXA uses high and low-energy X-ray beams to measure photon attenuation, providing a 3-compartment breakdown of Bone Mineral Content, Fat Mass, and Lean Soft Tissue.

Respuesta en Español: DXA utiliza haces de rayos X de alta y baja energía para medir la atenuación de fotones, proporcionando un desglose de 3 compartimentos.

English Response: Greater than 300 minutes per week of moderate-intensity physical activity.

Respuesta en Español: Más de 300 minutos por semana de actividad física de intensidad moderada.

English Response: It provides the mechanical stimulus required to preserve Fat-Free Mass, mitigating Basal Metabolic Rate reductions and preventing muscle wasting.

Respuesta en Español: Proporciona el estímulo mecánico necesario para preservar la Masa Libre de Grasa, mitigando las reducciones de la Tasa Metabólica Basal.

English Response: Enclosing computational and client case data within triple-hash delimiters (`###`) ensures clean data boundary isolation and precise alignment with PAGA 2018 guidelines.

Respuesta en Español: Encapitular los datos computacionales y de casos clínicos entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos y la alineación con PAGA 2018.

English Response: BIA is an accessible 2-compartment field method measuring tissue electrical resistance (highly sensitive to hydration status), whereas DXA is a clinical 3-compartment imaging standard.

Respuesta en Español: BIA es un método de campo accesible de 2 compartimentos que mide la resistencia eléctrica, mientras que DXA es un estándar clínico de imágenes de 3 compartimentos.

English Response: NEAT represents the energy expended for all spontaneous daily movements outside of structured exercise, such as fidgeting, standing, and daily chores.

Respuesta en Español: NEAT representa la energía gastada en todos los movimientos diarios espontáneos fuera del ejercicio estructurado, como caminar involuntariamente y las tareas diarias.


### Workplace Intelligence & AI Skills Competency Audit

In this Module, you demonstrated professional workforce readiness by leveraging Generative AI (Google Gemini) as a partner for thermodynamic and metabolic analysis. You practiced key workplace AI competencies that directly translate to modern physical education, athletic training, and allied health environments:

You strictly enclosed body composition case profiles within triple-hash ( ### ) delimiters, simulating secure clinical data handling and modular prompt engineering standards.

You cross-examined AI-generated energy balance strategies against federal SSoT standards (PAGA 2018), auditing for correct BMR/TDEE calculations and fat-free mass protection.

You directed the AI to generate culturally and linguistically accessible 2-sentence coaching cue cards in English and Spanish to broaden metabolic literacy for diverse community populations.

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 11 — Lifespan Physical Activity & Special Populations

In plain English, next week in Module 11: Lifespan Physical Activity & Special Populations you will learn how movement rules change across the human lifespan—from children and teens to pregnant women and older adults working to prevent falls. Why it matters: a single cookie-cutter workout does not fit everyone; you will learn the exact PAGA 2018 guidelines for each age group in our community.

- Pattern (Context): Assessing age-specific physiological needs for youth (bone/motor development) and older adults (sarcopenia and fall risk).
- Rule (Constraint): Applying PAGA 2018 lifespan benchmarks: 60 min/day for youth (with 3 days/week muscle + bone strengthening) and multicomponent balance + strength training for older adults.
- Solve (Intervention): Completing Mod 11 Discussion: Lifespan Activity Modifications and Mod 11 Lab: Lifespan Exercise Programming .

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 10 (Mod 10 Summary & Wrap-Up: Body Composition & Energy Balance)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All wrap-up materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are fully mobile-responsive and screen-reader compatible.

Español: Todos los materiales de cierre en KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 10 Resumen y Cierre del Módulo


### ¡Felicidades por completar el Módulo 10!

Ha auditado con éxito los principios termodinámicos, las ecuaciones de balance energético y los métodos de evaluación de la composición corporal que rigen el control de peso a lo largo de la vida. Esta semana analizó la tasa metabólica basal (TMB), el gasto energético diario total (TDEE) y la preservación de la masa libre de grasa, examinó cómo las leyes de la termodinámica dictan el flujo energético y exploró cómo las pautas federales de PAGA 2018 (2.ª edición) exigen un alto flujo energético y entrenamiento de resistencia concurrente para prevenir la termogénesis adaptativa.

Al integrar estrategias calóricas estructuradas, protocolos de protección de masa magra y auditorías de composición corporal basadas en evidencia, está preparado para optimizar la salud metabólica en rehabilitación clínica, educación física y entrenamiento deportivo.


### Síntesis del Protocolo de Encuadre Clínico: Puntos Clave del Módulo 10

- Patrón (Mecanismos Termodinámicos): La regulación del peso corporal se rige por la Primera Ley de la Termodinámica, donde la restricción calórica severa sin suficiente proteína ni entrenamiento de resistencia desencadena la termogénesis adaptativa.
- Regla (Normas PAGA 2018): Las normas federales de control de peso exigen un alto flujo energético (>300 minutos semanales de actividad moderada a vigorosa) combinado con fortalecimiento muscular.
- Solución (Optimización Metabólica): Aplicar déficits calóricos moderados junto con entrenamiento de resistencia progresivo y señales bilingües para garantizar una pérdida de peso sostenible.

#### Inteligencia en el Entorno Laboral y Competencia en IA

En este módulo demostró su preparación profesional al utilizar la IA generativa (Google Gemini) como socio en el análisis termodinámico y metabólico. Practicó competencias clave:

- Protocolo de Delimitadores: Encerró los casos de composición corporal entre triples numerales ( ### ) para estructurar datos clínicos y educativos de forma segura.
- Auditoría de IA: Verificó estrategias de balance energético contra los estándares de la PAGA 2018 para validar los cálculos BMR/TDEE y la protección de masa magra.
- Comunicación Bilingüe: Generó tarjetas de instrucción técnica de 2 oraciones, en inglés y en español, para mejorar la alfabetización metabólica comunitaria.
PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 11 — Actividad Física a lo Largo de la Vida y Poblaciones Especiales

En palabras sencillas (Contexto Norteño): un niño en crecimiento, una mujer embarazada y un abuelito que quiere evitar caídas no pueden entrenar con la misma rutina. Si los detalles clínicos se ponen pesados la próxima semana, concéntrate primero en las reglas exactas de PAGA 2018 por edad : 60 minutos diarios para jóvenes y ejercicio multicomponente (equilibrio + fuerza + cardio) para adultos mayores.

- Patrón (Contexto): Evaluar las necesidades físicas de niños/adolescentes y adultos mayores en familias multigeneracionales del Valle de Yuma.
- Regla (Restricción): Aplicar las metas de PAGA 2018 (60 min/día en jóvenes; entrenamiento multicomponente de equilibrio y fuerza en adultos mayores).
- Solución (Intervención): Completar el Foro del Mód 11 (Lifespan Activity Modifications) y el Laboratorio del Mód 11 (Lifespan Exercise Programming) .
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 10 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 10:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 10)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 10)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
