## KIN-101: Mod 03 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 03) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Discussion: How Physical Culture Shapes Modern Fitness

This week, we evaluate Per Henrik Ling's therapeutic Swedish Medical Gymnastics (corrective alignment) against Friedrich Ludwig Jahn's high-intensity German Turnen apparatus system (mass discipline and strength). Select a career-aligned track below and explore how these 19th-century physical culture philosophies continue to shape modern kinesiology, physical therapy, strength and conditioning, and local Yuma community movement infrastructure!

Esta semana evaluamos la Gimnasia Médica Sueca terapéutica de Per Henrik Ling (alineación correctiva) frente al sistema Turnen alemán de aparatos de alta intensidad de Friedrich Ludwig Jahn (disciplina masiva y fuerza). ¡Seleccione una ruta alineada con su carrera y explore cómo estas filosofías del siglo XIX moldean la kinesiología moderna, la terapia física, la fuerza y el acondicionamiento, y los programas comunitarios en el condado de Yuma!

- Topic Opens / Apertura del Foro: Tuesday, September 1, 2026, at 12:00 AM MST / Martes a las 12:00 AM
- Initial Post Due / Publicación Inicial: Thursday, September 3, 2026, at 11:59 PM MST / Jueves a las 11:59 PM
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 6, 2026, at 11:59 PM MST / Domingo a las 11:59 PM
- Board Closes / Cierre del Foro: Monday, September 7, 2026, at 11:59 PM MST / Lunes a las 11:59 PM
You are warmly encouraged to post in English or Spanish according to your professional comfort. Le animamos a publicar en inglés o en español según su preferencia académica.

Instructor feedback is published openly in this board and in the Gradebook. Reading these threads provides valuable historical context and clinical insights for your learning.


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI Study Preceptor prompt:

Focus: Lineage from Ling's Swedish Medical Gymnastics to modern Physical Therapy, joint mobilization, and postural restoration for desk workers (E.V., 47).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[CASE SUBJECT]: Postural Restoration & Swedish Medical Gymnastics Lineage
[HISTORICAL BASE]: Swedish Medical Gymnastics (Per Henrik Ling) — Anatomical alignment and joint mobilization.
[CLINICAL APPLICATION]: Outpatient Physical Therapy for desk worker (E.V., 47) with thoracic hyperkyphosis.
###
```

Focus: Lineage from Jahn's German Turnen apparatus physical culture to public outdoor fitness stations, adapted for Yuma's high summer heat indices.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CASE SUBJECT]: Public Physical Culture Infrastructure & German Turnen Lineage
[HISTORICAL BASE]: German Turnen Gymnastics (Friedrich Ludwig Jahn) — Open-air apparatus calisthenics.
[COMMUNITY APPLICATION]: Yuma Parks & Recreation adapting outdoor Turnplatz stations to climate-controlled indoor community hubs.
###
```

Focus: Hybridization of Swedish postural joint control and German apparatus power in collegiate Strength & Conditioning (AWC Athletics).


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[CASE SUBJECT]: Hybrid Athletic Conditioning Systems & 19th-Century Synthesis
[HISTORICAL BASE]: Swedish Precision (Ling) + German Apparatus Power (Jahn).
[ATHLETIC APPLICATION]: Collegiate S&C for multi-sport athlete (C.J., 20) merging joint stability with multi-planar power.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a historical kinesiology audit:


```text
Safety Auditor Protocol: KIN-101 Historical Preceptor ###:
Role: Socratic Kinesiology Mentor in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and Historical Physical Culture Framework.

Instructions:
Step 1: Review the student's selected career track case data provided in triple-hash (###) delimiters below.
Step 2: Contrast Ling's Swedish Medical Gymnastics with Jahn's German Turnen across philosophy, mechanics, and apparatus use.
Step 3: Trace how these systems directly influenced the modern sub-discipline in the student's track (Physical Therapy, PE, or Strength & Conditioning).
Step 4: Propose a climate-adapted movement solution for Yuma County populations under high summer heat (105°F+).
Step 5: Maintain all case inputs wrapped within delimiters.

Client Data Input ###:
[Paste Your Selected Track Data Block Here]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Historical Contrast: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance). Contrast why Ling prioritized joint alignment and medical calisthenics, while Jahn prioritized national military readiness, discipline, and heavy apparatus. Indique su ruta seleccionada. Resuma por qué Ling priorizó la alineación articular y la gimnasia médica, mientras que Jahn priorizó la disciplina militar y los aparatos.
- Modern Sub-Disciplinary Echoes: Trace how your selected track directly connects 19th-century physical culture to modern professions (e.g., Physical Therapy rehab vs. Strength & Conditioning vs. Public Health/School PE). ¿Cómo se conecta su ruta elegida con las profesiones modernas (p. ej., terapia física, fuerza y acondicionamiento o salud pública/educación física)?
- Community Application (Yuma Regional Context): For your target population in Yuma County facing extreme summer heat indices (105°F+), explain how you adapt these historical movement philosophies for safe, climate-controlled, or indoor execution. Para su población en Yuma ante el calor extremo (105°F+), ¿cómo adapta estas filosofías para una ejecución segura en interiores climatizados?

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Compare their choice of community movement system with yours, and discuss how environmental heat safety affects outdoor group conditioning.

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Compare su elección de sistema de movimiento con la suya y debata sobre la seguridad frente al calor extremo.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Historical Contrast: Per Henrik Ling developed Swedish Gymnastics as a scientific, medical framework prioritizing anatomical alignment, respiratory expansion, and low-impact calisthenics to restore physiological symmetry. In contrast, Friedrich Ludwig Jahn created German Turnen during a national crisis, emphasizing outdoor heavy apparatus (parallel bars, vaulting horses), physical toughness, and mass military discipline for national defense. Per Henrik Ling desarrolló la Gimnasia Sueca como un marco médico que priorizaba la alineación anatómica, la respiración y la calistenia suave para restaurar la simetría fisiológica. En contraste, Friedrich Ludwig Jahn creó el Turnen alemán enfatizando aparatos pesados al aire libre, resistencia y disciplina militar para la defensa nacional.
- Modern Sub-Disciplinary Echoes: Ling's Swedish Medical Gymnastics is the direct predecessor to modern Physical Therapy, clinical gait analysis, and corrective exercise screening. Jahn's German Turnen echoes strongly in modern Strength & Conditioning, gymnastics conditioning, and high-intensity functional training. La Gimnasia Médica de Ling es la antecesora directa de la Terapia Física moderna, el análisis clínico de la marcha y el ejercicio correctivo. El Turnen de Jahn se refleja en la fuerza y el acondicionamiento modernos, la gimnasia y el entrenamiento funcional.
- Yuma Community Application: For Yuma desk worker E.V. (47) suffering from chronic thoracic hyperkyphosis, Ling's Swedish Medical Gymnastics offers greater immediate physiological benefit. High-impact Turnen apparatus work in Yuma's 105°F summer heat imposes extreme thermal and joint stress. Free-standing, climate-controlled Swedish posture drills safely retract the scapulae, strengthen the rhomboids, and relieve lumbar strain without triggering hyperthermia. Para la trabajadora de escritorio E.V. (47) de Yuma con hipercifosis torácica, la Gimnasia Sueca ofrece un beneficio clínico inmediato superior. Los ejercicios posturales suecos en interiores climatizados retraen las escápulas y alivian la tensión lumbar sin exponer al paciente al calor extremo de 105°F.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 03 (Mod 03 Discussion: How Physical Culture Shapes Modern Fitness)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Foro de Discusión 03: Historia de la Cultura Física

Esta semana evaluamos la Gimnasia Médica Sueca de Per Henrik Ling frente al sistema Turnen alemán de Friedrich Ludwig Jahn. Seleccione una ruta profesional y explore cómo estas filosofías históricas siguen vigentes en las ciencias del ejercicio y en el condado de Yuma.

- Apertura del Foro: Martes, 1 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 3 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 6 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 7 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta y Contraste Histórico: Indique su ruta (Ruta 1 Clínica, Ruta 2 Comunitaria, Ruta 3 Rendimiento). Resuma por qué Ling priorizó la alineación anatómica y Jahn la fuerza y aparatos con fines patrióticos.
- Ecos Subdisciplinarios Modernos: Explique cómo su ruta conecta estas escuelas del siglo XIX con profesiones modernas (Terapia Física, Fuerza y Acondicionamiento o Educación Física Escolar).
- Aplicación en Yuma: Proponga adaptaciones seguras en interiores climatizados para la población de Yuma ante el calor extremo de verano (105°F+).

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 03)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
