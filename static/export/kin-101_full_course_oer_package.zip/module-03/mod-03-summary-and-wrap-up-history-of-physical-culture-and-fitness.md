## KIN-101: Mod 03 Summary And Wrap Up History Of Physical Culture And Fitness

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 03 Summary & Wrap-Up: History of Physical Culture & Fitness

Historia de la Cultura Física, Linajes Europeos y Evolución hacia PAGA 2018


### Step 1: Historical Foundations & Physical Culture Synthesis

Congratulations on completing Module 03! You have deconstructed the historical lineages that shaped modern movement science and physical culture:

- Swedish Medical Gymnastics (Ling): Prioritized anatomical alignment, corrective posture, joint mobilization, and respiratory expansion—serving as the direct clinical ancestor to modern Physical Therapy and corrective exercise.
- German Turnen Gymnastics (Jahn): Pioneered heavy outdoor apparatus calisthenics (parallel bars, vaulting horses, climbing ropes) to build civic unity, physical toughness, and mass strength—laying the foundation for modern Strength & Conditioning.
- Evolution to Public Health (PAGA 2018 SSoT): Traced how 20th-century physical training shifted from militaristic draft screening toward population-level chronic disease prevention and federal physical activity standards.

### Step 2: Workplace Intelligence & AI Historical Auditing

In health networks, school districts, and community fitness centers, modern kinesiology professionals utilize generative AI preceptors to audit exercise traditions, contrast movement lineages, and design climate-adapted public health interventions.

- Movement Lineage Verification: Exercise specialists audit historical systems to select appropriate modalities (corrective calisthenics vs. progressive apparatus loading).
- Delimiter Security (###): Enclosing historical case files and client parameters inside triple hashes ( ### ) ensures precise structured boundaries during AI audits.
- Climate-Adapted Community Prescriptions: Kinesiologists cross-reference AI-generated interventions against PAGA 2018 guidelines to adapt historical outdoor systems for high-heat environments like Yuma County.

### Step 3: Module 03 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 04:

English Response: Swedish Medical Gymnastics (Per Henrik Ling) , due to its clinical emphasis on precise anatomical joint mobilization, postural restoration, and corrective calisthenics.

Respuesta en Español: La Gimnasia Médica Sueca (Per Henrik Ling) , gracias a su enfoque en la movilización articular anatómica, la restauración postural y la calistenia correctiva.

English Response: Jahn engineered heavy outdoor apparatuses (parallel bars, horizontal bars, vaulting horses, climbing ropes) for high-intensity physical power and military preparedness, whereas Ling emphasized free-standing, light apparatus movements for symmetrical alignment.

Respuesta en Español: Jahn diseñó aparatos pesados al aire libre (barras paralelas, barras fijas, potros, cuerdas) para desarrollar potencia física y preparación militar, mientras que Ling priorizaba movimientos libres y ligeros para la simetría.

English Response: Late 20th-century research proved that physical inactivity directly causes hypokinetic lifestyle diseases (cardiovascular disease, Type 2 diabetes), shifting the national focus from wartime recruit screening to lifelong disease prevention and metabolic health.

Respuesta en Español: La investigación epidemiológica demostró que el sedentarismo provoca enfermedades hipocinéticas crónicas, cambiando el enfoque militarista hacia la prevención de enfermedades y la salud metabólica de por vida.

English Response: Friedrich Ludwig Jahn designed Turnen to unify fragmented German populations through physical culture, building nationalism, resilience, and collective physical strength.

Respuesta en Español: Friedrich Ludwig Jahn diseñó el Turnen para unificar a las poblaciones alemanas fragmentadas a través de la cultura física, fomentando el nacionalismo, la resiliencia y la fuerza física colectiva.

English Response: Enclosing case data inside triple hashes ensures strict data boundary isolation, preventing prompt drift and maintaining accuracy against PAGA 2018 standards.

Respuesta en Español: Encapitular los datos del caso dentro de tres numerales asegura un estricto aislamiento de los límites de datos, previniendo la deriva de instrucciones y manteniendo la precisión frente a PAGA 2018.

English Response: 19th-century European outdoor systems were built for temperate climates, whereas Yuma's extreme summer heat mandates indoor air-conditioned facilities (72°F / 22°C) to prevent heat illness.

Respuesta en Español: Los sistemas europeos al aire libre del siglo XIX fueron creados para climas templados, mientras que el calor extremo de verano en Yuma exige instalaciones interiores climatizadas (22 °C) para prevenir enfermedades por calor.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth for all activity standards.

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal para todas las normas de actividad.

English Response: High rates of military draft rejections due to poor physical fitness and chronic health defects prompted national policy shifts toward mandatory school physical education and fitness testing.

Respuesta en Español: Las altas tasas de rechazo en el servicio militar por mala condición física y defectos de salud impulsaron cambios políticos nacionales hacia la educación física escolar obligatoria y pruebas de aptitud.


### AI Simulation Workspace • Physical Culture Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive synthesis connecting 19th-century physical culture with modern exercise science:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: KIN-101 Module 03 Historical Synthesis ###:
Role: Academic Kinesiology Mentor and Public Health Exercise Specialist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) and Foundations of Physical Education.

Instructions:
Step 1: Generate a side-by-side comparison matrix contrasting:
     Swedish Medical Gymnastics (Ling): Principles, movement modalities, and modern lineage.
     German Turnen Gymnastics (Jahn): Principles, apparatus design, and modern lineage.
Step 2: Detail how the transition away from 20th-century military readiness testing established the PAGA 2018 public health guidelines.
Step 3: Formulate an indoor, climate-adapted exercise protocol for Yuma County desk workers blending restorative posture drills with functional bodyweight strength.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 04 — Career Pathways & Credentials

In plain English, next week in Module 04: Career Pathways & Credentials you will explore the different jobs, degrees, and accredited national certifications (such as ACSM, NSCA, and NASM) in kinesiology, coaching, and allied health. Why it matters: you will learn the legal boundary (Scope of Practice) between what a wellness coach can safely recommend and what requires a licensed physician, physical therapist, or registered dietitian.

- Pattern (Context): Evaluating professional roles, NCCA-accredited certifications, and clinical referral networks across Yuma County healthcare and fitness settings.
- Rule (Constraint): Respecting strict legal Scope of Practice boundaries and PAGA 2018 professional standards (coaching vs. medical diagnosis).
- Solve (Intervention): Completing Mod 04 Discussion: Credentials & Scope of Practice and Mod 04 Lab: Career Pathway & Credential Plan .

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 03 (Mod 03 Summary & Wrap-Up: History of Physical Culture & Fitness)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 03: Resumen y Evaluación

Historia de la Cultura Física, Gimnasia Europea y Pautas PAGA 2018


### Step 1: Síntesis de las Bases Históricas de la Cultura Física

¡Felicitaciones por completar el Módulo 03! Ha analizado las tradiciones y fundamentos filosóficos que dieron origen a las ciencias del ejercicio:

- Gimnasia Médica Sueca (Ling): Priorizó la alineación anatómica, la postura correcta y la movilización articular, sentando las bases de la Terapia Física moderna.
- Gimnasia Turnen Alemana (Jahn): Desarrolló la calistenia con aparatos pesados (barras, potros, cuerdas) para fomentar la fuerza y la disciplina militar, base del acondicionamiento de fuerza moderno.
- Evolución a la Salud Pública (SSoT PAGA 2018): Rastreó cómo el acondicionamiento militarista del siglo XX evolucionó hacia pautas de prevención de enfermedades crónicas.

### Step 2: Inteligencia en el Entorno Laboral y Auditoría con IA

Los profesionales de la kinesiología utilizan herramientas de IA generativa para auditar programas de movimiento y diseñar intervenciones comunitarias adaptadas al clima local.

- Verificación de Linajes: Selección de modalidades fundamentadas (alineación sueca vs. sobrecarga funcional alemana).
- Seguridad con Delimitadores (###): El uso de tres numerales ( ### ) asegura la estructura de los datos clínicos.
- Adaptación Climática en Yuma: Adaptación de la calistenia histórica a instalaciones climatizadas para evitar el estrés térmico en verano.

### Step 3: Autoevaluación del Módulo 03 (Verificación Bilingüe)

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 04:

Respuesta en Español: La Gimnasia Médica Sueca (Per Henrik Ling) , gracias a su enfoque en movilización articular anatómica, postura y ejercicios correctivos.

English Response: Swedish Medical Gymnastics (Per Henrik Ling) , due to its clinical emphasis on precise anatomical joint mobilization and corrective calisthenics.

Respuesta en Español: Jahn diseñó aparatos pesados al aire libre (barras paralelas, barras fijas, potros, cuerdas) para generar fuerza y preparación militar, a diferencia de los movimientos libres de Ling.

English Response: Jahn engineered heavy outdoor apparatuses for physical power and military preparedness, whereas Ling emphasized free-standing, light apparatus movements.

Respuesta en Español: La evidencia epidemiológica demostró que la inactividad física es la causa de enfermedades hipocinéticas crónicas, cambiando el enfoque militarista hacia la salud preventiva.

English Response: Epidemiological evidence proved that physical inactivity directly causes chronic hypokinetic diseases, shifting focus from militaristic screening to preventive public health.

Respuesta en Español: Unificar a las poblaciones alemanas fragmentadas a través de la cultura física, fomentando el nacionalismo, la resiliencia y la fuerza colectiva.

English Response: To unify fragmented German populations through physical culture, building nationalism, resilience, and collective physical strength.

Respuesta en Español: Encapitular los datos dentro de tres numerales asegura un estricto aislamiento de límites, previniendo la deriva de instrucciones frente a PAGA 2018.

English Response: Enclosing case data inside triple hashes ensures strict data boundary isolation, preventing prompt drift and maintaining accuracy against PAGA 2018 standards.

Respuesta en Español: Los sistemas europeos se crearon para climas templados, mientras que el calor extremo de verano en Yuma exige instalaciones interiores climatizadas (22 °C).

English Response: European outdoor systems were built for temperate climates, whereas Yuma's extreme summer heat mandates indoor air-conditioned facilities (72°F / 22°C).

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la SSoT federal principal.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth.

Respuesta en Español: Las altas tasas de rechazo militar por mala condición física impulsaron cambios hacia la educación física escolar obligatoria y pruebas de aptitud.

English Response: High rates of military draft rejections due to poor physical fitness prompted national shifts toward mandatory school physical education and fitness testing.


### Caja de Herramientas de IA • Síntesis de Estudio

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Protocolo Review Master: KIN-101 Sintesis Modulo 03 ###:
Rol: Mentor Academico de Kinesiologia y Especialista en Salud Publica.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a ed.).

Instrucciones:
Step 1: Generar una matriz comparativa contrastando la Gimnasia Medica Sueca (Ling) y el Turnen Aleman (Jahn).
Step 2: Explicar como la transicion del acondicionamiento militar del siglo XX dio origen a las pautas PAGA 2018.
Step 3: Formular un protocolo de ejercicio en interiores climatizados para Yuma que combine postura sueca y fuerza funcional alemana.
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 04 — Rutas Profesionales y Certificaciones

En palabras sencillas (Contexto Norteño): en la salud y el deporte cada quien tiene su cancha: el entrenador prescribe movimiento seguro, pero no receta medicinas ni diagnostica enfermedades como el médico. Si los términos profesionales se ponen pesados la próxima semana, concéntrate primero en trazar tu propio mapa de carrera y conocer las certificaciones oficiales (ACSM, NSCA, NASM) y tu límite legal de práctica (Scope of Practice).

- Patrón (Contexto): Analizar las carreras de kinesiología, certificaciones acreditadas y redes de referencia clínica en nuestra región.
- Regla (Restricción): Respetar estrictamente el Alcance de la Práctica (Scope of Practice) y los estándares de PAGA 2018 .
- Solución (Intervención): Completar el Foro del Mód 04 (Credentials & Scope of Practice) y el Laboratorio del Mód 04 (Career Pathway & Credential Plan) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-101 • Module 03 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 03:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 03)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
