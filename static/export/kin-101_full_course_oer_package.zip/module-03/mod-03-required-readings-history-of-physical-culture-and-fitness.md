## KIN-101: Mod 03 Required Readings History Of Physical Culture And Fitness

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Required Readings: History of Physical Culture & Fitness

Lecturas Obligatorias y Recursos de Estudio: Historia de la Cultura Física


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Physical culture history shows how human survival labor evolved into modern clinical exercise science. As daily farm and trade movement declined, chronic diseases rose, leading to the federal PAGA 2018 benchmarks. Knowing this history helps you design culturally respectful movement programs for Yuma and Imperial Valley families.


#### En Palabras Sencillas (Norteño Context)

Antes nuestra gente en el valle hacía todo el ejercicio trabajando en el campo, pero hoy pasamos más tiempo sentados frente a pantallas. Si los términos técnicos se ponen pesados, concéntrate primero en por qué la guía PAGA 2018 recomienda al menos 150 minutos semanales de actividad moderada.


### Required SSoT Text & Professional Guidelines

Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) • Historical Development Framework of Kinesiology and Physical Education.

The History of Kinesiology (LibreTexts OER Chapter 1.01) Capítulo 1.01: La Historia de la Kinesiología y Raíces del Movimiento Humano.

- Per Henrik Ling: Swedish Medical Gymnastics & Corrective Alignment (Britannica)
- Friedrich Ludwig Jahn: The German Turnen Gymnastics Movement & Apparatus (Britannica)
- Turnverein Societies: The Turnverein System and Physical Culture Heritage (Britannica)
- Military Readiness & Public Health: CDC Physical Activity, National Security & Chronic Disease Prevention
- Evolution of Federal Activity Policy: PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev)

### Core Historical & Physiological Concepts


#### Step 1: Swedish Medical Gymnastics vs. German Turnen System

Gimnasia Médica Sueca vs. Sistema Turnen Alemán

Per Henrik Ling developed Swedish Gymnastics around precise anatomical geometry, corrective posture, respiratory mechanics, and calisthenics with zero or lightweight apparatus. In contrast, Friedrich Ludwig Jahn engineered the German Turnen system to cultivate military preparedness, physical power, and national resilience through heavy outdoor apparatus (vaulting horses, parallel bars, climbing ropes, and horizontal bars).

El sistema sueco de Ling se basó en la geometría anatómica, la corrección postural, la mecánica respiratoria y la calistenia libre. El sistema Turnen alemán de Jahn buscaba disciplina militar, potencia física y resistencia grupal mediante aparatos pesados al aire libre (potros, barras paralelas, cuerdas y barras fijas).


#### Step 2: Paradigm Shift: From Militaristic Fitness to Public Health Guidelines

De la Preparación Militarista a las Pautas de Salud Pública (PAGA 2018)

Throughout the early and mid-20th century, physical culture programs in schools and communities were driven by high military recruit rejection rates during World War I and World War II. Over the late 20th century, large-scale epidemiological studies demonstrated that regular physical activity prevented chronic hypokinetic diseases (cardiovascular disease, Type 2 diabetes, metabolic syndrome). This evidence transformed exercise from an instrument of national defense into modern, population-wide public health guidelines codified in PAGA 2018 .

Durante gran parte del siglo XX, los programas de acondicionamiento respondían a las altas tasas de rechazo en los reclutamientos de la Primera y Segunda Guerra Mundial. La investigación epidemiológica demostró que la actividad física regular previene enfermedades hipocinéticas crónicas, transformando el ejercicio militarista en políticas preventivas de salud pública como PAGA 2018.


### Key Terminology / Glosario Clave

A systematized movement discipline designed by Per Henrik Ling to restore musculoskeletal symmetry, re-educate neuromuscular coordination, and correct postural deficiencies.

Disciplina de movimiento sistematizada creada por Ling para restaurar la simetría musculoesquelética, reeducar el sistema neuromuscular y corregir posturas.

An apparatus-based physical training system developed by Friedrich Ludwig Jahn to build functional strength, group cohesion, and physical courage through progressive gymnastic overload.

Sistema de entrenamiento con aparatos creado por Jahn para forjar fuerza funcional, cohesión de grupo y valor mediante sobrecarga gimnástica progresiva.

Pathological conditions directly initiated or accelerated by chronic sedentary lifestyle and physical inactivity, including cardiovascular disease, metabolic syndrome, and musculoskeletal atrophy.

Trastornos o patologías provocadas o agravadas por el sedentarismo crónico y la inactividad física, tales como problemas cardiovasculares y atrofia muscular.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of the core historical frameworks before starting Discussion 03 and Lab 03:

English Response: Swedish Gymnastics relied on unloaded, precise calisthenic patterns focusing on corrective posture, symmetry, and joint mobility with minimal apparatus. German Turnen applied high-intensity mechanical loading via specialized outdoor apparatus (bars, vaulting horses, ropes) to build upper-body strength and physical grit.

Respuesta en Español: La gimnasia sueca empleaba movimientos libres precisos centrados en simetría y movilidad sin aparatos pesados. El Turnen alemán aplicaba sobrecarga mecánica intensa con aparatos (barras, potros, cuerdas) para desarrollar fuerza del tren superior y resistencia.

English Response: While early physical education addressed recruit unfitness during 20th-century drafts, late-20th-century epidemiology revealed that physical inactivity was the root cause of hypokinetic lifestyle diseases. This led to population-level guidelines (PAGA) prioritizing health-related fitness over militaristic performance.

Respuesta en Español: Aunque la educación física inicial respondió a fallas en el reclutamiento militar, la epidemiología demostró que la inactividad era la causa de enfermedades hipocinéticas, dando paso a pautas como PAGA que priorizan la salud sobre el desempeño bélico.

English Response: Ling's emphasis on therapeutic exercise, progressive active and passive joint mobilization, and postural restoration established the clinical principles that evolved into modern orthopedic physical therapy and corrective exercise prescription.

Respuesta en Español: El enfoque de Ling en ejercicio terapéutico, movilización articular progresiva y restauración postural estableció los fundamentos clínicos de la terapia física ortopédica y el ejercicio correctivo moderno.


### AI Simulation Workspace • Historical Comparison Simulation

Copy the prompt below into Gemini to test your ability to connect European gymnastics lineages to modern physical activity prescriptions:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-101 Module 03 Historical Tool Box ###:
Role: Kinesiology Historian and Public Health Exercise Specialist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Generate a side-by-side comparison between Ling's Swedish Medical Gymnastics and Jahn's German Turnen across three pillars:
     Biomechanical Loading and Apparatus Use
     Cultural and Philosophical Objective
     Direct Application to Modern Exercise Science (Physical Therapy vs. Strength & Conditioning)
Step 2: Connect how the 20th-century transition away from military testing shaped the PAGA 2018 baseline of 150-300 minutes of moderate physical activity.
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 03 (Mod 03 Required Readings: History of Physical Culture & Fitness)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Lecturas Obligatorias y Recursos de Estudio: Cultura Física


### Texto Fuente SSoT y Lineamientos Profesionales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) • Marco Histórico del Desarrollo de la Kinesiología.

Historia de la Kinesiología (Capítulo 1.01 de LibreTexts)

- Per Henrik Ling: Gimnasia Médica Sueca y Alineación Postural (Britannica)
- Friedrich Ludwig Jahn: El Movimiento Gimnástico Turnen y sus Aparatos (Britannica)
- Sociedades Turnverein: Historia del Sistema Turnverein y Tradición Física (Britannica)
- Preparación Militar y Salud Pública: CDC Actividad Física, Seguridad y Enfermedades Crónicas
- Evolución de Pautas Federales: Herramienta Interactiva PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev)

### Conceptos Científicos e Históricos Centrales


#### Step 1: Gimnasia Médica Sueca vs. Sistema Turnen Alemán

El sistema sueco de Ling promovía la simetría anatómica, la corrección postural y la calistenia libre sin aparatos pesados. Por el contrario, el Turnen alemán de Jahn fue diseñado con fines patrióticos y de preparación militar mediante aparatos pesados al aire libre.


#### Step 2: Evolución Hacia las Pautas de Salud Pública (PAGA 2018)

A lo largo del siglo XX, el enfoque pasó de preparar reclutas militares a prevenir enfermedades hipocinéticas crónicas mediante actividad física regular, formalizándose en las pautas federales PAGA 2018.


### Glosario Clave

Secuencia estructurada creada por Ling para alinear el aparato locomotor, optimizar la respiración y reeducar el control neuromuscular.

Sistema gimnástico con aparatos creado por Jahn para desarrollar fuerza funcional, disciplina grupal y resistencia física.

Patología o condición adversa provocada o agravada por la falta habitual de movimiento físico y el sedentarismo crónico.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para asegurar un entorno de aprendizaje inclusivo, equitativo y accesible para nuestra comunidad estudiantil.

KIN-101 • Module 03 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 03:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 03)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 03)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
