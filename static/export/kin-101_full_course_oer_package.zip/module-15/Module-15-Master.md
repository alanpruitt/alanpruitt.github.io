## KIN-101: MODULE 15 - FINAL ASSESSMENT PHASE & COMPREHENSIVE CAPSTONE / FASE DE EVALUACIÓN FINAL Y PROYECTO INTEGRADOR

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

> ### Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (Kinesiology disciplines and foundational physical activity rules).

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This final module marks the summative evaluation boundary for the KIN-101 curriculum fleet. Students will synthesize core sub-disciplinary paradigms across the lifespan to construct a comprehensive, community-level physical activity advocacy blueprint. Standard weekly laboratory and discussion structures are concluded. All engineering lines, population targets, and safety thresholds must align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo final marca el límite de la evaluación sumativa para la flota curricular de KIN-101. Los estudiantes sintetizarán los paradigmas subdisciplinarios centrales a lo largo de la vida para construir un plan integral de promoción de la actividad física a nivel comunitario. Las estructuras estándar de laboratorio semanal y discusión han concluido. Todas las líneas de diseño, objetivos de población y límites de seguridad deben alinearse con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.25]):** Synthesize comprehensive kinesiology theories and public health standards across the lifespan to engineer an evidence-based, community-facing physical activity intervention that addresses systemic inactivity barriers.
* **Español (Regional) ([LO 2.25]):** Sintetizar teorías integrales de kinesiología y estándares de salud pública a lo largo de la vida para diseñar una intervención de actividad física orientada a la comunidad basada en la evidencia que aborde las barreras sistémicas de inactividad.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Synthesize and audit multidimensional population inactivity patterns, integrating historical, mechanical, and physiological data barriers across all age cohorts.
   * **Patrón (Español):** Sintetizar y auditar patrones multidimensionales de inactividad poblacional, integrando barreras de datos históricos, mecánicos y fisiológicos en todas las cohortes de edad.
2. **Rule (English):** Apply overlapping federal PAGA 2018 dosage, safety, and multi-sector rules to validate the compliance guidelines of a macro-level community program.
   * **Regla (Español):** Aplicar las reglas superpuestas de dosificación, seguridad y multisectoriales de PAGA 2018 para validar las pautas de cumplimiento de un programa comunitario a nivel macro.
3. **Solve (English):** Formulate an exhaustive, population-level physical activity intervention proposal designed to clear socioeconomic access gaps and optimize long-term health outcomes.
   * **Solución (Español):** Formular una propuesta de intervención de actividad física exhaustiva a nivel de población diseñada para eliminar las brechas de acceso socioeconómico y optimizar los resultados de salud a largo plazo.

---

## Comprehensive Capstone Submission Checkpoint / Punto de Entrega del Proyecto Integrador Final

## English

To fulfill the final assessment requirement, students will deliver their comprehensive capstone proposal within the designated portal. Ensure your complete written project components remain fully enclosed within the required layout delimiters below.

::: {.callout-note}
## Worked Example: Step-by-Step Guidance / Ejemplo Práctico Paso a Paso
**Context & Application:** When completing this lab assignment, follow this structured three-step approach based on our Single Sources of Truth (PAGA 2018 / ACSM 12th Ed.):

1. **Step 1 (Identify Pattern):** Review the client or case profile parameters for baseline activity, physiological constraints, or nutritional markers.
2. **Step 2 (Apply Rule):** Cross-reference the specific federal guidelines, volume targets, or physiological formulas required for the assessment.
3. **Step 3 (Solve):** Formulate your final recommendation or calculation clearly within the submission template below.
:::

```text
## [PASTE YOUR COMPREHENSIVE CAPSTONE PROPOSAL HERE]
###
```

1. **Theoretical Unification:** Document how your proposed intervention synthesizes biomechanical safety limits and behavioral adaptation tracks to ensure movement longevity.
2. **Federal Alignment Audit:** Provide explicit data tracking justifications confirming that your project components satisfy the baseline multi-sector directives of the federal PAGA framework.

## Español (Regional)

Para cumplir con el requisito de evaluación final, los estudiantes entregarán su propuesta de proyecto integrador dentro del portal designado. Asegúrese de que los componentes escritos completos del proyecto permanezcan completamente cerrados dentro de los delimitadores de diseño a continuación.

```text
## [PEGUE SU PROPUESTA DE PROYECTO INTEGRADOR FINAL AQUÍ]
###
```

1. **Unificación Teórica:** Documentar cómo la intervención propuesta sintetiza los límites de seguridad biomecánicos y las vías de adaptación conductual para garantizar la longevidad del movimiento.
2. **Auditoría de Alineación Federal:** Proporcionar justificaciones explícitas de seguimiento de datos que confirmen que los componentes de su proyecto cumplen con las directivas multisectoriales del marco federal de PAGA.

---

## Mastery Performance Standard / Estándar de Ejecución de Maestría
This final summative capstone assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación final sumativa se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):**
  * **English:** Zero-drift integration. The capstone unifies all sub-disciplinary tracks perfectly; intervention models match federal PAGA safety indices exactly, and all workspace entries remain fully fenced.
  * **Español (Regional):** Integración sin desviaciones. El proyecto unifica perfectamente todas las vías subdisciplinarias; los modelos de intervención coinciden exactamente con los índices de seguridad de PAGA y todas las entradas permanecen delimitadas.
* **7 (Competent) / (Competente):**
  * **English:** Minor refactoring required. Main public health frameworks and Clinical Framing Protocol stages are correctly integrated, but minor citation gaps or text formatting errors are flagged in the final file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los principales marcos de salud pública y las etapas del Protocolo de Encuadre Clínico están correctamente integrados, pero se identifican pequeñas brechas de citas o errores de formato de texto.
* **0 (Recalibrate) / (Recalibrar):**
  * **English:** Critical omissions in core safety metrics or un-fenced data sheets that ignore baseline federal guidelines or compromise community wellness vectors. Complete rewrite required.
  * **Español (Regional):** Omisiones críticas en las métricas de seguridad central o páginas de datos sin delimitar que ignoran las pautas federales de referencia o comprometen los vectores de bienestar comunitario. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection


### Closes: Monday @ 11:59 PM


Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.





## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 15)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 15)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
