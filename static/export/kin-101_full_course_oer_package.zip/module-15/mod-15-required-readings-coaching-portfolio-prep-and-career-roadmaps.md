## KIN-101: Mod 15 Required Readings Coaching Portfolio Prep And Career Roadmaps

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 15 Required Readings: Coaching Portfolio Prep & Career Roadmaps

Síntesis Capstone y Hojas de Ruta Profesionales

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from PAGA 2018 (2nd Ed.)), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 15): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: The capstone asks you to bring the whole course together in your own professional work. You will review your past audits and connect them to the federal guidelines. You will also practice spotting fitness myths and protecting client privacy when you use AI.


#### En Palabras Sencillas (Norteño Context)

Piensa en esto como la carne asada del fin de semestre: ya tienes todos los ingredientes, ahora te toca preparar el platillo completo. Si los términos técnicos se ponen pesados, concéntrate primero en mostrar lo que ya sabes.

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)

This week's capstone literature explores the comprehensive synthesis of kinesiological science, wellness informatics, and professional career planning. By reviewing cumulative clinical audits, biomechanical movement screens, and adapted exercise prescriptions, practitioners learn to consolidate their professional competencies into rigorous, verifiable portfolios.

Grounded in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , these readings establish that lifelong professional practice requires continuous evidence-based auditing, secure AI data governance, and proactive career development roadmaps.


### 1. Cumulative Portfolio Synthesis & SSoT Alignment

Consolidating professional expertise across clinical, educational, and athletic tracks requires strict adherence to foundational federal benchmarks:

- Integrating Kinesiologic Science: Unifying cardiorespiratory programming, biomechanical torque optimization, and lifespan adaptations into a cohesive clinical auditing framework.
- Verifiable Single Source of Truth (SSoT): Ensuring all professional artifacts and case syntheses directly cite and comply with the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .
- Eliminating Fitness Misinformation: Utilizing rigorous algorithmic auditing to filter out unverified commercial wellness trends in favor of peer-reviewed physiological standards.
Clinical Rule Verified (Use This in Your Lab & Sprint): Structuring multi-week training phases where weekly aerobic duration or resistance load increases by no more than ~5–10% per week to prevent overuse injury.

En palabras sencillas (Para tu Laboratorio y Sprint): Subir los minutos o el peso poquito a poco (máximo 5 a 10% por semana) para que tendones y músculos se adapten sin lesionarse.


### 2. Clinical Informatics, Data Governance & Secure AI Workflows

Modern kinesiology practice relies heavily on secure digital repositories and ethical generative artificial intelligence integration:

- Zero-Trust Data Isolation: Employing the Safety Auditor protocol ( ### ) to partition client data and maintain strict privacy compliance during AI preceptor consultations.
- Repository Maintenance: Structuring and archiving audit logs, lab simulations, and bilingual cue cards in an organized digital repository ( EXW_Professional_AI_Repository ).
- Bilingual Health Communication: Leveraging AI tools to generate culturally competent, accessible bilingual coaching resources for diverse community populations.
Clinical Rule Verified (Use This in Your Lab & Sprint): Integrating federal PAGA 2018 guidelines, client cultural/environmental realities in Yuma, and human clinical judgment into a defensible coaching portfolio.

En palabras sencillas (Para tu Laboratorio y Sprint): Unir las reglas oficiales de PAGA 2018 con la realidad diaria de tu cliente en Yuma para respaldar cada decisión de tu portafolio.


### 3. Ongoing Professional Development & Career Roadmap Strategy

Transitioning from academic coursework into professional practice requires an active, structured career development strategy:

- Credentialing & Lifelong Learning: Identifying advanced clinical certifications, specialized workshops, and continuing education units necessary to maintain elite practice standards.
- Interprofessional Collaboration: Partnering with physiotherapists, physicians, and public health officials to deliver comprehensive, multidisciplinary patient care.
- Community Leadership: Spearheading evidence-based wellness initiatives that address regional health disparities and promote active living across all demographic groups.
Clinical Rule Verified (Use This in Your Lab & Sprint): Distinguishing the role of an exercise/wellness coach from licensed physical therapy, medical nutrition therapy, and physician clearance gates.

En palabras sencillas (Para tu Laboratorio y Sprint): Reconocer hasta dónde llega nuestro rol como entrenadores y cuándo canalizar al cliente con el médico, fisioterapeuta o nutriólogo.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 15 (Mod 15 Required Readings: Coaching Portfolio Prep & Career Roadmaps)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas en Línea: Síntesis Capstone y Hojas de Ruta Profesionales

La literatura capstone de esta semana explora la síntesis integral de la ciencia cinesiológica, la informática del bienestar y la planificación de la carrera profesional. Al revisar auditorías clínicas acumulativas, evaluaciones biomecánicas y prescripciones de ejercicio adaptado, los profesionales aprenden a consolidar sus competencias en portafolios rigurosos y verificables.

Fundamentadas en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) , estas lecturas establecen que la práctica profesional de por vida requiere auditorías continuas basadas en evidencia, gobernanza de datos segura e IA.


### 1. Síntesis de Portafolio Acumulativo y Alineación SSoT

- Integración de la Ciencia Cinesiológica: Unir la programación cardiorrespiratoria, la optimización de torque y las adaptaciones en un marco de auditoría clínica.
- Fuente Única de Verdad (SSoT): Asegurar que todos los artefactos profesionales citen directamente el cumplimiento de PAGA 2018 (2.ª ed.) .
- Eliminación de Mitos: Utilizar auditorías algorítmicas rigurosas para filtrar tendencias comerciales de bienestar no verificadas.

### 2. Informática Clínica, Gobernanza de Datos y Flujos de IA Seguros

La práctica moderna de la kinesiología depende de repositorios digitales seguros:

- Aislamiento de Datos Zero-Trust: Emplear el protocolo del Auditor de Seguridad ( ### ) para mantener el cumplimiento de privacidad.
- Mantenimiento del Repositorio: Estructurar y archivar registros de auditoría y simulaciones en un repositorio digital designado.
- Comunicación Bilingüe: Aprovechar las herramientas de IA para generar recursos de entrenamiento accesibles y bilingües.

### 3. Desarrollo Profesional Continuo y Estrategia de Carrera

- Certificaciones y Aprendizaje: Identificar certificaciones clínicas avanzadas y educación continua necesarias para mantener la excelencia.
- Colaboración Interprofesional: Asociarse con fisioterapeutas, médicos y oficiales de salud pública para brindar atención multidisciplinaria.
- Liderazgo Comunitario: Encabezar iniciativas de bienestar basadas en evidencia que aborden las disparidades regionales de salud.
KIN-101 • Module 15 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 15:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 15)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 15)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
