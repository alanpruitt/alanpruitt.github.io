## KIN-101: MODULE 08 - MIDTERM EVALUATION & CONTENT SYNTHESIS BOUNDARY

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module serves as a structural content boundary and mid-semester pause within the KIN-101 curriculum fleet. Standard laboratory workflows, simulation inputs, and discussion arrays are temporarily suspended. Instead, students will engage in a comprehensive synthesis review of the five primary sub-disciplinary pillars covered in Modules 02 through 07, while completing the mandatory institutional Midterm Student Course Evaluation. All review parameters track back exclusively to our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo sirve como un límite estructural de contenido y una pausa de mitad de semestre dentro de la flota curricular de KIN-101. Los flujos de trabajo de laboratorio estándar, las entradas de simulación y las matrices de discusión se suspenden temporalmente. En su lugar, los estudiantes participarán en una revisión de síntesis integral de los cinco pilares subdisciplinarios principales cubiertos en los Módulos 02 al 07, al mismo tiempo que completan la Evaluación de Mitad de Semestre de los Estudiantes obligatoria de la institución. Todos los parámetros de revisión se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.18]):** Synthesize core kinesiology concepts across foundational history, sociology, biomechanics, physiology, and motor pathways to evaluate community-level physical activity outcomes.
* **Español (Regional) ([LO 2.18]):** Sintetizar los conceptos centrales de la kinesiología a través de la historia fundamental, la sociología, la biomecánica, la fisiología y las vías motoras para evaluar los resultados de la actividad física a nivel comunitario.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Review, track, and cross-examine intersecting community inactivity patterns and physical limitations analyzed across the first half of the semester.
   * **Patrón (Español):** Revisar, registrar y examinar de forma cruzada los patrones de inactividad comunitaria interconectados y las limitaciones físicas analizadas a lo largo de la primera mitad del semestre.
2. **Rule (English):** Apply overlapping federal PAGA 2018 health metrics to audit multi-system wellness baselines, validating safety parameters across diverse population segments.
   * **Regla (Español):** Aplicar las métricas de salud federales superpuestas de PAGA 2018 para auditar las líneas de base de bienestar de múltiples sistemas, validando los parámetros de seguridad en diversos segmentos de la población.
3. **Solve (English):** Formulate a comprehensive personal mastery synthesis statement that unifies sub-disciplinary kinesiology theories into an actionable, community-facing advocacy blueprint.
   * **Solución (Español):** Formular una declaración de síntesis de maestría personal integral que unifique las teorías subdisciplinarias de la kinesiología en un plan de acción de promoción orientado a la comunidad.

---
## Institutional Midterm Notice / Aviso Institucional de Mitad de Semestre

> ### REQUIRED CHECKPOINT: MIDTERM STUDENT COURSE EVALUATION / COMPROBACIÓN OBLIGATORIA: EVALUACIÓN DE MITAD DE SEMESTRE DE LOS ESTUDIANTES
>
> * **English:** The standard laboratory and discussion structures are closed for this module block. Students are required to log into the Canvas LMS portal, navigate to the Institutional Evaluations tab, and complete the official Midterm Student Course Evaluation. Your anonymous, constructive feedback ensures continuous refinement and operational agility across our kinesiology course architecture.
> * **Español (Regional):** Las estructuras estándar de laboratorio y discusión están cerradas para este bloque de módulos. Se requiere que los estudiantes inicien sesión en el portal de Canvas LMS, naveguen a la pestaña de Evaluaciones Institucionales y completen la Evaluación de Mitad de Semestre de los Estudiantes oficial. Sus comentarios anónimos y constructivos garantizan el perfeccionamiento continuo y la agilidad operativa en nuestra arquitectura de cursos de kinesiología.

---
## Midterm Synthesis Checkpoint / Punto de Verificación de Síntesis de Mitad de Semestre

## English

To satisfy this boundary module block, students will provide a comprehensive synthesis overview within their sandbox environment. Ensure your written responses are fully enclosed within the structural layout delimiters below.

```text
## [PASTE YOUR CORE KINESIOLOGY KNOWLEDGE SYNTHESIS REFLECTION HERE]
###
```

1. **Sub-Disciplinary Integration:** Summarize how historical milestones, sociological access barriers, mechanical parameters, and bioenergetic adaptation lines intersect to dictate physical performance limits.
2. **Federal Metric Audit:** Justify how your current physical activity design philosophy mirrors the long-term epidemiological health outcomes targeted by the federal PAGA guidelines.

## Español (Regional)

Para satisfacer este bloque de módulo de límite, los estudiantes proporcionarán una descripción general de síntesis integral dentro de su entorno sandbox. Asegúrese de que sus respuestas escritas estén completamente cerradas dentro de los delimitadores de diseño estructural a continuación.

```text
## [PEGUE SU REFLEXIÓN DE SÍNTESIS DE CONOCIMIENTOS CENTRALES DE KINESIOLOGÍA AQUÍ]
###
```

1. **Integración Subdisciplinaria:** Resumir cómo se cruzan los hitos históricos, las barreras de acceso sociológicas, los parámetros mecánicos y las líneas de adaptación bioenergética para dictar los límites del rendimiento físico.
2. **Auditoría de Métricas Federales:** Justificar cómo su filosofía actual de diseño de actividad física refleja los resultados de salud epidemiológicos a largo plazo previstos por las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This boundary synthesis checkpoint is evaluated using the strict 10/7/0 institutional scale:
Este punto de verificación de síntesis se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):
  * **English:** Zero-drift integration. Core sub-disciplinary paradigms and public health data lines match PAGA criteria perfectly; all canvas evaluation confirmation parameters are verified, and sandbox text limits remain completely fenced.
  * **Español (Regional):** Integración sin desviaciones. Los paradigmas subdisciplinarios centrales y las líneas de datos de salud pública coinciden perfectamente con los criterios de PAGA; todos los parámetros de confirmación de la evaluación de Canvas están verificados y los límites de texto de sandbox permanecen completamente delimitados.
* **7 (Competent) / (Competente):
  * **English:** Minor refactoring required. Main historical and physiological concepts are integrated appropriately, but minor formatting gaps or delimiter omissions are flagged in the final repository file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los conceptos históricos y fisiológicos principales se integran adecuadamente, pero se identifican pequeñas brechas de formato u omisiones de delimitadores en el archivo final del repositorio.
* **0 (Recalibrate) / (Recalibrar):
  * **English:** Critical omission of core sub-disciplinary links or un-fenced data entries that ignore federal public health frameworks. Complete rewrite required.
  * **Español (Regional):** Omisión crítica de los vínculos subdisciplinarios centrales o entradas de datos sin delimitar que ignoran los marcos federales de salud pública. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Midterm Clinical Audit & Synthesis

## Final Inspection


### Closes: Monday @ 11:59 PM


Review your midterm synthesis submission and verify your course evaluation confirmation in Canvas before the module closes.




## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 08)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 08)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
