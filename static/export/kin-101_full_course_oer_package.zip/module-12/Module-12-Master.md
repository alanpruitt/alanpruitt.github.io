## KIN-101 MODULE-12: ACTIVE INFRASTRUCTURE / Master Content Loop

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

## KIN-101: MODULE 12 - ACTIVE INFRASTRUCTURE, PARKS, AND RECREATION / INFRAESTRUCTURA ACTIVA, PARQUES Y RECREACIÓN

## Module Overview & Foundational Grounding / Contexto Inicial y Visión General

* **English:** This module examines the critical role of public parks, recreational facilities, and urban active infrastructure in promoting population-level movement longevity. Students will analyze how community spaces, shared-use path networks, and public recreation programming clear environmental barriers to physical activity. All space tracking parameters and facility access benchmarks align exclusively with our Single Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA) 2018 (2nd Ed)**.
* **Español (Regional):** Este módulo examina el papel crítico de los parques públicos, las instalaciones recreativas y la infraestructura activa urbana en la promoción de la longevidad del movimiento a nivel de la población. Los estudiantes analizarán cómo los espacios comunitarios, las redes de senderos de uso compartido y la programación de recreación pública eliminan las barreras ambientales para la actividad física. Todos los parámetros de seguimiento de espacios y puntos de referencia de acceso a instalaciones se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): las **Pautas de Actividad Física para Estadounidenses (PAGA) 2018 (2ª Ed)**.

---

## Targeted Learning Objectives / Tracking de Objetivos de Aprendizaje

* **English ([LO 2.22]):** Evaluate municipal park infrastructures and recreational facilities using federal environmental frameworks to design inclusive, active community access modifications.
* **Español (Regional) ([LO 2.22]):** Evaluar las infraestructuras de parques municipales y las instalaciones recreativas utilizando marcos ambientales federales para diseñar modificaciones inclusivas de acceso a la comunidad activa.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern (English):** Identify and document environmental access patterns, tracking missing sidewalk connections, unlit public park sectors, or facility usage disparities across regional neighborhood perimeters.
   * **Patrón (Español):** Identificar y documentar los patrones de acceso ambiental, rastreando conexiones de aceras faltantes, sectores de parques públicos sin iluminación o disparidades en el uso de instalaciones a lo largo de perímetros de vecindarios regionales.
2. **Rule (English):** Apply the environmental infrastructure design metrics and community-level facility safety standards highlighted throughout the federal PAGA 2018 framework to map space equity rules.
   * **Regla (Español):** Aplicar las métricas de diseño de infraestructura ambiental y los estándares de seguridad de instalaciones a nivel comunitario destacados en el marco federal de PAGA 2018 para trazar reglas de equidad espacial.
3. **Solve (English):** Engineer a multi-component active infrastructure modification plan or recreational program layout designed to maximize localized population tracking metrics safely.
   * **Solución (Español):** Diseñar un plan de modificación de infraestructura activa de componentes múltiples o un diseño de programa recreativo diseñado para maximizar de forma segura las métricas de seguimiento de la población localizada.

---
## Dual-Scaffold Laboratory Workflow / Flujo de Trabajo de Laboratorio de Doble Andamiaje

## Part A: Gemini AI Simulation (Infrastructure Mapping Simulation)

## English

Students will initialize the virtual geographic tracking environment within their sandbox workspace. Ensure your simulated municipal asset data rows remain completely enclosed within the layout delimiters below.

::: {.callout-note}
## Worked Example: Step-by-Step Guidance / Ejemplo Práctico Paso a Paso
**Context & Application:** When completing this lab assignment, follow this structured three-step approach based on our Single Sources of Truth (PAGA 2018 / ACSM 12th Ed.):

1. **Step 1 (Identify Pattern):** Review the client or case profile parameters for baseline activity, physiological constraints, or nutritional markers.
2. **Step 2 (Apply Rule):** Cross-reference the specific federal guidelines, volume targets, or physiological formulas required for the assessment.
3. **Step 3 (Solve):** Formulate your final recommendation or calculation clearly within the submission template below.
:::

```text
## [PASTE SIMULATED RECREATIONAL FACILITY ACCESS MATRIX AND MUNICIPAL PATHWAY GEODATA HERE]
###
```

1. Use the sandbox environment to audit a simulated geographical dataset, evaluating distance coordinates from residential density blocks to active green spaces.
2. Cross-examine virtual infrastructure access lanes against the community design and park mobilization pathways targeted in the federal PAGA document.
3. Execute an automated audit check within the sandbox to verify that proposed public transit linkages deliver sufficient access scores with zero layout gaps.

## Español (Regional)

Los estudiantes inicializarán el entorno de seguimiento geográfico virtual dentro de su espacio de trabajo sandbox. Asegúrese de que las filas de datos de activos municipales simulados permanezcan completamente cerradas dentro de los delimitadores de diseño a continuación.

```text
## [PEGUE LA MATRIZ DE ACCESO A INSTALACIONES RECREATIVAS SIMULADAS Y LOS GEODATOS DE VÍAS MUNICIPALES AQUÍ]
###
```

1. Utilizar el entorno de pruebas (sandbox) para auditar un conjunto de datos geográficos simulados, evaluando las coordenadas de distancia desde los bloques de densidad residencial hasta los espacios verdes activos.
2. Evaluar de forma cruzada los carriles de acceso a la infraestructura virtual frente a las vías de diseño comunitario y movilización de parques previstas en el documento oficial de PAGA.
3. Ejecutar una verificación de auditoría automatizada dentro del sandbox para verificar que los enlaces de tránsito público propuestos ofrezcan puntajes de acceso suficientes sin brechas de diseño.

## Part B: Practical Field Application (Park Asset Screening)

## English

Students will transition into their immediate regional community parks or public paths to execute a practical, zero-cost environmental audit.

1. Complete a visual environment screening log of a local park perimeter, noting the condition of shared paths, illumination placements, and universal access layouts.
2. Document visible safety features and active usage balances across variable age blocks during active tracking periods.
3. Document true structural indicators: record raw infrastructure access variables and cross-examine your field observations against the population tracking benefits prioritized by the federal PAGA guidelines.

## Español (Regional)

Los estudiantes harán la transición a sus parques comunitarios regionales o senderos públicos inmediatos para ejecutar una auditoría ambiental práctica y de costo cero.

1. Completar un registro de evaluación visual del entorno de un perímetro de parque local, anotando el estado de los senderos compartidos, la ubicación de la iluminación y los diseños de acceso universal.
2. Documentar las características de seguridad visibles y los equilibrios de uso activo en variables bloques de edad durante los períodos de seguimiento activos.
3. Documentar los indicadores estructurales reales: registrar las variables de acceso a la infraestructura bruta y evaluar de forma cruzada sus observaciones de campo con los beneficios de seguimiento de la población priorizados por las pautas federales de PAGA.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This infrastructure module assignment is evaluated using the strict 10/7/0 institutional scale:
Esta asignación del módulo de infraestructura se evalúa utilizando la estricta escala institucional 10/7/0:

* **10 (Exemplary) / (Ejemplar):
  * **English:** Zero-drift integration. All proposed infrastructure modifications and safety rules match PAGA environmental indices exactly; all sandbox simulation inputs remain fenced inside structural layout boundaries.
  * **Español (Regional):** Integración sin desviaciones. Todas las modificaciones de infraestructura propuestas y las reglas de seguridad coinciden exactamente con los índices ambientales de PAGA; todas las entradas de simulación de sandbox permanecen delimitadas dentro de los límites de diseño estructural.
* **7 (Competent) / (Competente):
  * **English:** Minor refactoring required. Core Clinical Framing Protocol steps and facility guidelines are appropriately applied, but minor formatting gaps or bilingual layout omissions are flagged in the final file.
  * **Español (Regional):** Se requiere una reestructuración menor. Los pasos del Protocolo de Encuadre Clínico y las pautas de las instalaciones se aplican adecuadamente, pero se identifican pequeñas brechas de formato u omisiones de diseño bilingüe en el archivo final.
* **0 (Recalibrate) / (Recalibrar):
  * **English:** Critical error in calculating accessibility scores or un-fenced facility geodata that violates federal safety parameters or ignores infrastructure frameworks. Complete rewrite required.
  * **Español (Regional):** Error crítico en el cálculo de los puntajes de accesibilidad o geodatos de instalaciones sin delimitar que violan los parámetros de seguridad federales o ignoran los marcos de infraestructura. Requiere reescritura completa.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection


### Closes: Monday @ 11:59 PM


Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.







## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.


## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 12)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 12)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
