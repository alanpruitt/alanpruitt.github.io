## KIN-101: Mod 05 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 05) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 05 Lab & Simulation: Muscle Strength & Joint Leverage Audit

Práctica de Laboratorio 05: Sistemas de Palancas Biomecánicos, Pares de Fuerza y Restauración Postural

- Agonist vs. Antagonist Muscle Balance: Pairing prime movers (e.g., quadriceps/pectorals) with opposing stabilizers (hamstrings/upper-back) to maintain healthy joint centration. En palabras sencillas: Entrenar parejo los músculos que empujan y los que jalan para que las articulaciones trabajen alineadas y sin dolor.
- Foundational Movement Pillars (Push, Pull, Hinge, Squat): Multi-joint compound patterns that train all major muscle groups ≥2 days/week as required by PAGA 2018 Chapter 4. En palabras sencillas: Los cuatro movimientos base del cuerpo humano—empujar, jalar, bisagra de cadera y sentadilla—para cumplir los 2 días semanales de fuerza.
- Progressive Overload & 48-Hour Muscle Recovery Window: Gradually increasing resistance or repetitions over time while allowing ~48 hours between heavy sessions for the same muscle group to repair. En palabras sencillas: Subir el reto poco a poco dejando descansar unas 48 horas el mismo grupo muscular para que se recupere más fuerte.

### Biomechanical Auditing, Muscle Mechanics, & Postural Vector Prescription

In this laboratory assignment, you will analyze a client case file using the Clinical Framing Protocol (Pattern / Rule / Solve) framework across your chosen Build Your Own Journey Track . You will evaluate joint torques, audit musculoskeletal lever mechanics, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) muscle-strengthening standards, and formulate a dual-language corrective movement prescription using Google Gemini.

En esta práctica de laboratorio, analizará un expediente de cliente aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para evaluar momentos de fuerza, palancas articulares, pares de fuerza y alineación pélvica según las normas PAGA 2018.

- KIN-101.5.1.AY26-27: Audit socioecological and mechanical barriers to physical activity within occupational, clinical, and rural community settings. Auditar barreras socioecológicas y mecánicas para la actividad física en entornos laborales, clínicos y comunitarios.
- KIN-101.5.2.AY26-27: Formulate community and individual-level physical activity interventions utilizing the Clinical Framing Protocol (Pattern / Rule / Solve) problem-solving model. Formular intervenciones de actividad física individuales y comunitarias utilizando el modelo de resolución del Protocolo de Encuadre Clínico (Patrón / Regla / Solución).
- Module Window / Ventana del Módulo: Opens Tuesday, September 15, 2026, at 12:00 AM MST Abre el martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, September 21, 2026, at 11:59 PM MST Lunes, 21 de septiembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación: Weekly Labs & Clinical Simulations Benchmark (10 Points) Ponderación para laboratorios semanales y simulaciones clínicas (10 Puntos)

### Lab Objectives / Objetivos del Laboratorio

Competencias clave del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Identify musculoskeletal lever classes (1st, 2nd, and 3rd class) and calculate torque vectors operating across the lumbo-pelvic-hip complex. Identificar las clases de palancas musculoesqueléticas y calcular vectores de torque en el complejo lumbo-pélvico-cadera.
- Analyze reciprocal inhibition and agonist-antagonist force-couple imbalances (anterior pelvic tilt, tight hip flexors, inhibited gluteals). Analizar la inhibición recíproca y los desequilibrios de pares de fuerza agonista-antagonista (inclinación pélvica anterior).
- Prescribe a 3-exercise corrective movement routine aligned with PAGA 2018 multi-joint resistance training standards to restore functional alignment. Prescribir una rutina correctiva de 3 ejercicios alineada con las pautas PAGA 2018 para restaurar la alineación funcional.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-05 / Fase 1: Selección de Escenario de Simulación Clínica

Elija su Ruta y Revise los Datos Biomecánicos

Choose ONE of the three career-aligned tracks below to audit in the Gemini AI Tool Box:

Focus: Lumbar spine unloading, hip flexor lengthening, and anterior pelvic tilt postural restoration in outpatient clinical settings at Matador Clinical Partners (MCP).


```text
###
[TRACK / RUTA]: Track 1 - Clinical & Rehabilitation Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: E.M.
[AGE / EDAD]: 52 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma, AZ
[HEIGHT / ESTATURA]: 5 ft 10 in (178 cm) | [WEIGHT / PESO]: 190 lbs (86.2 kg)
[PRESENTATION / PRESENTACIÓN CLÍNICA]: Chronic lower back stiffness and excessive anterior pelvic tilt resulting from daily 8-hour seated operator posture.
[MECHANICAL DEFICIT / DÉFICIT MECÁNICO]: Shortened iliopsoas and rectus femoris pulling pelvis anteriorly; reciprocal inhibition and weakness of gluteus maximus and rectus abdominis.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Physical Therapy.
###
```

Focus: Ergonomic workplace posture safety, public works heavy equipment operators, and community-level musculoskeletal interventions.


```text
###
[TRACK / RUTA]: Track 2 - Community & Public Health Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: E.M.
[AGE / EDAD]: 52 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 5 ft 10 in (178 cm) | [WEIGHT / PESO]: 190 lbs (86.2 kg)
[OCCUPATION / OCUPACIÓN]: Municipal Heavy Equipment Operator (Yuma County Public Works)
[COMMUNITY RISK / RIESGO COMUNITARIO]: Whole-body machine vibration paired with sustained seated hip flexion; restricted active hip extension ROM causing high rates of occupational back disability.
[COMMUNITY SITE]: Yuma County Public Health Services District & Parks Recreation Centers.
###
```

Focus: Kinetic chain torque vectors, glute activation during triple extension, and hip extension lockout mechanics in strength sports.


```text
###
[TRACK / RUTA]: Track 3 - Sports & Athletic Performance Path
[ATHLETE INITIALS / INICIALES DEL ATLETA]: E.M.
[AGE / EDAD]: 52 | [SEX / SEXO]: Male | [LOCATION / UBICACIÓN]: Yuma, AZ
[SPORT / DEPORTE]: Masters Powerlifting (Deadlift and Squat Focus)
[PERFORMANCE BARRIER / BARRERA DE RENDIMIENTO]: Inability to lock out deadlifts cleanly due to shortened hip flexors restricting hip extension torque, causing compensatory lumbar hyperextension under heavy barbell loads.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


```text
Safety Auditor Protocol: KIN-101 Module 05 Biomechanics Tool Box ###:
Role: Socratic Kinesiology Mentor and Biomechanics Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) & Biomechanical Lever Framework.

Instructions:
Step 1: Review the client profile wrapped in triple-hashes (###) below.
Step 2: PATTERN: Identify the class of lever operating at the hip/pelvis during upright trunk stabilization, and define the force-couple dysfunction (anterior pelvic tilt, reciprocal inhibition between iliopsoas, gluteus maximus, and rectus abdominis).
Step 3: RULE: Apply federal PAGA 2018 guidelines regarding multi-joint muscle-strengthening (2+ days/week for major muscle groups) and movement control routines for musculoskeletal health.
Step 4: SOLVE: Detail a 3-exercise corrective routine specific to the chosen track to re-establish pelvic neutrality and protect the lumbar spine. Include a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Template

Plantilla de Entrega en el Cuadro de Texto de Canvas

Copy the template below, populate your responses, and submit directly in Canvas:


```text
KIN-101 Module 05 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]
Client Initials: [Insert Client Initials]

Step 1: Pattern Recognition (Biomechanical Lever Audit & Force Couples):
  Operating Anatomical Lever Class at Hip/Spine (Fulcrum, Effort, Load):
  Hypertonic Muscle Groups (Shortened Agonists):
  Inhibited Muscle Groups (Reciprocal Inhibition):
  Lumbo-Pelvic Force-Couple Imbalance Description (Anterior Pelvic Tilt Vectors):

Step 2: Rule Application (PAGA 2018 Federal Resistance Standards):
  PAGA 2018 Adult Muscle-Strengthening Guidelines (Frequency & Muscle Group Coverage):
  Mechanical Rationale for Corrective Movement Control:
  Target Weekly Schedule Aligned with Federal Standards:

Step 3: Problem Solving (Corrective Movement Routine & Bilingual Card):
  Exercise 1 (Mobility / Lengthening): [Name, Sets, Reps/Hold, Target Muscle]
  Exercise 2 (Activation / Motor Control): [Name, Sets, Reps/Hold, Target Muscle]
  Exercise 3 (Multi-Joint Strength Integration): [Name, Sets, Reps/Hold, Target Muscle]
  Bilingual Client Instruction Card (EN / ES):

Step 4: Part 3 — Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice):
[Write 150-word minimum (150+ words) in your own clinical voice defending your moment-arm torque reduction, force-couple rebalancing, and PAGA 2018 2-day/week resistance progression.]

Step 5: Repository Verification:
AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M05_Biomechanical_Lever_Audit.pdf
End Submission ###:
```

Part 4 — Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, a generic AI workout ignores external moment-arm length ($\tau = F \times d_\perp$) and prescribes heavy straight-leg deadlifts or loaded lumbar extension that amplify L4–L5 shear torque. By auditing the client's pelvic force-couple imbalance (tight hip flexors and erector spinae overpowering inhibited gluteals and deep abdominals), I shorten the external moment arm by keeping loads close to the body's center of mass and prescribe PAGA 2018 multi-joint resistance training twice weekly with 48-hour recovery windows. This biomechanical modification restores neutral pelvic alignment and prevents occupational back injury in Yuma."


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Part 1: Pattern Recognition (Detección de Patrones): Key Point — Lever System Mechanics: The hip joint operates primarily as a 1st class lever system during upright trunk posture balancing (where the femoral head acts as the fulcrum, the spine/upper body represents the load, and the gluteus maximus/hamstrings provide the effort vector). Key Point — Force-Couple Dysfunction: Prolonged 8-hour seated operator posture causes chronic shortening of the anterior hip flexors (iliopsoas and rectus femoris). This creates downward anterior pull on the iliac crest, producing excessive anterior pelvic tilt and accentuated lumbar lordosis. Via reciprocal inhibition, the primary posterior extensor (gluteus maximus) and anterior core stabilizer (rectus abdominis) are inhibited and neurologically weakened, transferring compressive shear loads directly to the L5-S1 lumbar vertebrae.

Part 2: Rule Application (PAGA 2018 2nd Ed Standards): According to PAGA 2018 (2nd Ed., Chapter 2), adults must engage in muscle-strengthening activities involving all major muscle groups on 2 or more days per week. Re-establishing neutral pelvic alignment through targeted hip mobility and posterior kinetic chain strengthening fulfills PAGA's mandate to maintain functional independence, mitigate chronic lower-back discomfort, and restore multi-joint movement capacity.

Part 3: Solving the Gap (Corrective Postural Protocol): Clinical Postural Restoration Protocol (3 Days/Week): Step 1 — Half-Kneeling Active Hip Flexor Stretch: 3 sets of 30-second hold per side (lengthens hypertonic iliopsoas and rectus femoris). Step 2 — Supine Glute Bridges with Abdominal Bracing: 3 sets of 12 reps with 2-second isometric peak hold (re-activates gluteus maximus and re-establishes posterior pelvic torque). Step 3 — Quadruped Bird-Dog with Neutral Spine: 3 sets of 10 reps per side (strengthens multifidus, gluteals, and deep core stabilizers without spinal flexion strain).

EN: "Perform these hip stretches and glute bridges daily to unload your lower back and realign your hips after sitting. Strengthening your glutes will protect your spine when standing and operating machinery."

ES: "Realice estos estiramientos de cadera y puentes de glúteos diariamente para aliviar la espalda baja y realinear su pelvis. Fortalecer los glúteos protegerá su columna vertebral mientras trabaja sentado."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_101_M05_Biomechanical_Lever_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 05 (Mod 05 Lab: Muscle Strength & Joint Leverage Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 05 Laboratorio y Simulación: Palancas y Pares de Fuerza Biomecánicos

Sistemas de Palancas Biomecánicos, Mecánica Muscular y Restauración Postural

En este laboratorio, evaluará el expediente de un cliente utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) para auditar palancas anatómicas, pares de fuerza musculares y alineación pélvica según PAGA 2018.

- Apertura del Módulo: Martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Fecha Límite de Entrega: Lunes, 21 de septiembre de 2026, a las 11:59 PM MST
- Ponderación: Puntuación de laboratorios semanales y auditorías clínicas (10 Puntos)

### Paso 1: Consulta en la Caja de Herramientas de IA Gemini

Pegue los datos de la ruta elegida en Gemini IA y copie esta plantilla debajo:


```text
Protocolo Safety Auditor: KIN-101 Laboratorio 05 ###:
Rol: Mentor Socratico de Kinesiologia y Especialista en Biomecanica con la voz del Narrador.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) y Palancas Biomecanicas.

Instrucciones:
Step 1: Revisar los datos del caso de la ruta seleccionada por el estudiante entre delimitadores (###).
Step 2: PATRON: Identificar la clase de palanca en la cadera/columna y definir la disfuncion del par de fuerza (inclinacion pelvica anterior, inhibicion reciproca entre psoas, gluteo mayor y recto abdominal).
Step 3: REGLA: Aplicar las pautas PAGA 2018 sobre fortalecimiento muscular multiarticular (2+ dias/semana) para restaurar la salud musculoesqueletica.
Step 4: SOLUCION: Disenar una rutina correctiva de 3 ejercicios para restablecer la neutralidad pelvica y proteger la columna lumbar.
Step 5: Generar una tarjeta de instruccion bilingue para el cliente (EN / ES).

Entrada de Datos del Cliente ###:
[PEGUE AQUI LOS DATOS DE SU RUTA ENTRE DELIMITADORES]
Fin de Datos del Cliente ###:
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Plantilla de Entrega en Canvas (Solo Texto)


```text
KIN-101 Entrega de Laboratorio Modulo 05 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clinica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]
Iniciales del Cliente: [Insertar Iniciales]

Step 1: Reconocimiento de Patrones (Auditoria de Palancas y Pares de Fuerza):
  Clase de Palanca Operante en Cadera/Columna (Punto de Apoyo, Fuerza, Resistencia):
  Grupos Musculares Hipertonicos (Agonistas Acortados):
  Grupos Musculares Inhibidos (Inhibicion Reciproca):
  Descripcion del Desequilibrio del Par de Fuerza (Vectores de Inclinacion Pelvica Anterior):

Step 2: Aplicacion de Reglas (Estandares Federales de Fuerza PAGA 2018):
  Pautas PAGA 2018 de Fortalecimiento Muscular (Frecuencia y Cobertura de Grupos Musculares):
  Justificacion Mecanica para el Control del Movimiento Correctivo:
  Cronograma Semanal Objetivo Alineado con los Estandares Federales:

Step 3: Resolucion de Problemas (Rutina Correctiva y Tarjeta Bilingue):
  Ejercicio 1 (Movilidad / Estiramiento): [Nombre, Series, Repeticiones/Tiempo, Musculo Objetivo]
  Ejercicio 2 (Activacion / Control Motor): [Nombre, Series, Repeticiones/Tiempo, Musculo Objetivo]
  Ejercicio 3 (Integracion de Fuerza Multiarticular): [Nombre, Series, Repeticiones/Tiempo, Musculo Objetivo]
  Tarjeta de Instruccion Bilingue para el Cliente (EN / ES):

Step 4: Parte 4 — La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz):
[Escriba de mínimo 150 palabras en su propia voz humana clínica defendiendo su reducción del brazo de momento articular y progresión de fuerza según PAGA 2018.]

Step 5: Verificacion del Repositorio:
Intercambio con la IA exportado y guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M05_Biomechanical_Lever_Audit.pdf
Fin de la Entrega ###:
```

Parte 4 — La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): "En mi juicio clínico, un plan genérico de IA ignora la longitud del brazo de momento externo ($\tau = F \times d_\perp$) y sobrecarga la columna lumbar. Al acercar la carga al eje articular, equilibrar el par de fuerzas pélvico (glúteos y abdomen frente a flexores de cadera) y aplicar 2 días por semana de fuerza según PAGA 2018, protegemos la espalda baja de nuestro trabajador en Yuma."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 05)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
