## KIN-101: Mod 05 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 05) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology / Conceptos de Kinesiología


## Mod 05 Discussion: How Muscles & Joints Work Together

Auditoría de Vectores Biomecánicos, Pares de Fuerza y Palancas Articulares

Analyzing joint torques, lever mechanics, and muscle force couples is essential for preventing injury and optimizing human movement across the lifespan. Select a career-aligned track below and audit a real-world biomechanical scenario using our academic SSoT ( Physical Activity Guidelines for Americans, PAGA 2018, 2nd Edition ) and the Gemini AI Preceptor!

Analizar el torque articular, la mecánica de palancas y los pares de fuerza musculares es fundamental para prevenir lesiones y optimizar el movimiento humano. ¡Seleccione una ruta profesional y audite un escenario biomecánico con las pautas federales PAGA 2018 y el Preceptor de IA Gemini!

- Topic Opens / Apertura del Foro: Tuesday, September 15, 2026, at 12:00 AM MST / Martes a las 12:00 AM
- Initial Post Due / Publicación Inicial: Thursday, September 17, 2026, at 11:59 PM MST / Jueves a las 11:59 PM
- Peer Replies Due / Respuestas a Compañeros: Sunday, September 20, 2026, at 11:59 PM MST / Domingo a las 11:59 PM
- Board Closes / Cierre del Foro: Monday, September 21, 2026, at 11:59 PM MST / Lunes a las 11:59 PM
You are warmly encouraged to post in English or Spanish according to your preference. Le animamos a publicar en inglés o en español según su preferencia académica.

To support your professional biomechanical auditing skills, instructor movement analyses and corrective feedback are posted in this public forum as well as in Gradebook.


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Patient rehabilitation, lumbar spine unloading, and anterior pelvic tilt postural restoration at Matador Clinical Partners (MCP).


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[CLIENT INITIALS]: E.M. | [AGE]: 52 | [LOCATION]: Yuma, AZ
[PRESENTATION]: Chronic lower back stiffness and pronounced anterior pelvic tilt following prolonged seated desk work.
[BIOMECHANICAL FINDING]: Excessive lumbar lordosis, hypertonic iliopsoas/rectus femoris, and reciprocal inhibition of gluteus maximus during hip extension.
[CLINICAL SITE]: Matador Clinical Partners (MCP) Outpatient Physical Therapy.
###
```

Focus: Ergonomic workplace risk mitigation, agricultural operator safety, and community physical activity posture interventions.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CLIENT INITIALS]: E.M. | [AGE]: 52 | [LOCATION]: Yuma County, AZ
[OCCUPATION]: Yuma County Public Works Heavy Machinery Operator
[BIOMECHANICAL RISK]: 8-hour daily exposure to whole-body vibration and static seated postures; restricted hip extension ROM leading to occupational low-back strain claims.
[COMMUNITY SITE]: Yuma County Public Health Services District & Parks Recreation Centers.
###
```

Focus: Kinetic chain power transfer, glute activation during triple extension, and torque mechanics in athletic training.


```text
###
[TRACK]: Track 3 - Sports & Athletic Performance Path
[ATHLETE INITIALS]: E.M. | [AGE]: 52 | [LOCATION]: Yuma, AZ
[SPORT]: Masters Powerlifting / Deadlift Focus
[BIOMECHANICAL LIMITATION]: Restricted hip extension due to shortened hip flexors, causing compensatory lumbar hyperextension during the lockout phase.
[ATHLETIC SITE]: Arizona Western College (AWC) Matador Athletics High-Performance Center.
###
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA

Copy the prompt below into Gemini along with your track data block to conduct a biomechanical force-couple audit:


```text
Safety Auditor Protocol: KIN-101 Biomechanics & Force-Couple Preceptor ###:
Role: Academic Kinesiology Mentor and Biomechanics Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) & Basic Kinesiological Lever Principles.

Instructions:
Step 1: Review the candidate case file wrapped in triple-hashes (###) below.
Step 2: Analyze the PATTERN by identifying 2 joint torque vectors, lever classifications, or postural deviations contributing to the client's dysfunction.
Step 3: Apply the RULE by citing kinesiological force-couple mechanics, reciprocal inhibition principles, and PAGA 2018 muscle-strengthening guidelines.
Step 4: SOLVE by providing 2 track-specific corrective movement strategies, accompanied by a 2-sentence client explanation formatted in both English and Spanish.
Step 5: Maintain all client data wrapped in triple-hash (###) delimiters.

Candidate Data Input ###:
[Paste Your Selected Track Data Block Here]
End Candidate Data ###:
End Safety Auditor Protocol ###:
```


### Discussion Tasks / Tareas de Discusión (Due Thursday by 11:59 PM MST):

- Identify Selected Track & Biomechanical Focus: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and the primary postural dysfunction analyzed. Indique la ruta seleccionada y la disfunción postural principal analizada.
- Clinical Framing Protocol (Pattern / Rule / Solve) Analysis (Pattern / Rule / Solve): Detail the force-couple imbalance and joint torque vectors (Pattern), connect it to kinesiological lever rules or PAGA 2018 strength guidelines (Rule), and outline your corrective exercise intervention (Solve). Detalle el desequilibrio de pares de fuerza (Patrón), conéctelo con las reglas biomecánicas o pautas PAGA 2018 (Regla) y describa su intervención correctiva (Solución).
- Bilingual Client Takeaway: Include a concise 2-sentence explanation of the corrective strategy in both English and Spanish so your client understands the functional reason behind the exercise. Incluya una explicación concisa de 2 oraciones sobre la estrategia correctiva en inglés y español para que su cliente entienda la razón del movimiento.

#### Peer Engagement Requirement / Requisito de Interacción (Due Sunday by 11:59 PM MST)

Respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Compare how their corrective strategies (Clinical vs. Community vs. Sports) address the underlying force-couple imbalance in different real-world settings.

Responda al menos a UN (1) compañero que haya elegido una ruta diferente a la suya (mínimo 1 respuesta). Compare cómo sus estrategias correctivas abordan el desequilibrio biomecánico en diferentes entornos.


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Track & Focus: Track 1 Clinical Rehabilitation. Analyzing anterior pelvic tilt, reciprocal inhibition of the hip extensors, and lumbar compression in a sedentary desk worker. Ruta 1 Rehabilitación Clínica. Analizando la inclinación pélvica anterior, la inhibición recíproca de extensores de cadera y la compresión lumbar.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit: Pattern (Force-Couple Imbalance): Hypertonic hip flexors (iliopsoas and rectus femoris) pull the anterior pelvis downward, creating an anterior pelvic tilt. This reciprocally inhibits the gluteus maximus and forces the lumbar erector spinae into chronic compensatory shortening, creating excessive shear force across L5-S1. Rule (Kinesiological Levers & PAGA 2018): Per PAGA 2018 guidelines, muscle-strengthening activities must target all major muscle groups 2 or more days per week. Re-establishing third-class lever mechanics at the hip requires restoring agonist-antagonist length-tension relationships. Solve (Corrective Strategy): Implement half-kneeling hip flexor active mobility stretches (2 sets of 30 seconds) paired with bilateral glute bridge isometric hold drills (3 sets of 10 to 12 reps) to restore neutral pelvis alignment before progressing to standing resistance exercises. Patrón: Flexores de cadera hipertónicos tiran de la pelvis hacia adelante, inhibiendo el glúteo mayor y creando sobrecarga en L5-S1. Regla: PAGA 2018 exige fortalecimiento de todos los grupos musculares. Solución: Estiramientos de psoas y puentes de glúteo.
- Bilingual Client Handout: EN: "We need to lengthen your tight hip flexors and activate your glutes so your hips properly support your body instead of straining your lower back during long seated days." ES: "Necesitamos estirar los flexores de la cadera y activar los glúteos para que sus caderas soporten su postura correctamente en lugar de sobrecargar la espalda baja."

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 05 (Mod 05 Discussion: How Muscles & Joints Work Together)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Foro de Discusión 05: Auditoría de Vectores Biomecánicos y Pares de Fuerza

Analizar el torque articular, la mecánica de palancas y los pares de fuerza musculares es fundamental para prevenir lesiones y optimizar el rendimiento. Seleccione una ruta profesional y audite un escenario biomecánico con el Preceptor de IA Gemini.

- Apertura del Foro: Martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial: Jueves, 17 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 20 de septiembre de 2026, a las 11:59 PM MST
- Cierre del Foro: Lunes, 21 de septiembre de 2026, a las 11:59 PM MST

### Instrucciones de Discusión (Entrega: Jueves 11:59 PM MST)

- Ruta y Enfoque Biomecánico: Indique la ruta seleccionada (Ruta 1 Clínica, Ruta 2 Comunitaria o Ruta 3 Deportiva) y la disfunción postural principal analizada.
- Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Detalle el desequilibrio del par de fuerza (Patrón), conéctelo con las reglas biomecánicas o pautas PAGA 2018 (Regla) y describa su intervención correctiva (Solución).
- Resumen Bilingüe para el Cliente: Incluya una explicación concisa de 2 oraciones sobre la estrategia correctiva en inglés y español para educar al cliente.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 05)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
