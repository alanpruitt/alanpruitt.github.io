## KIN-101: Mod 05 Required Readings Muscle Strength And Joint Function

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 05 Required Readings: Muscle Strength & Joint Function

Lecturas Obligatorias y Recursos de Estudio: Fisiología Muscular, Reclutamiento de Fibras y Normas de Fuerza


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Biomechanics and muscular strength describe how muscles pull on bones across joints to create stable movement. Progressive resistance training strengthens muscle fibers, tendons, and bone density when joint alignment stays neutral. Auditing joint mechanics prevents sprains and lower-back injuries during heavy lifting.


#### En Palabras Sencillas (Norteño Context)

Cargar cajas pesadas con la espalda doblada es como levantar peso con una grúa chueca: tarde o temprano falla la bisagra. Si los términos técnicos se ponen pesados, concéntrate primero en cómo alinear las articulaciones y fortalecer los grupos musculares principales dos días por semana.


### Required SSoT Text & Professional Resistance Standards

Primary Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • ACSM Guidelines for Exercise Testing and Prescription (12th Edition).

Primary SSoT Anchor: Chapter 2: Physical Activity Guidelines for Adults (Muscle-Strengthening Mandates) & Part F: Health Benefits of Physical Activity.

- Interactive PAGA Clinical Calculators ("PAGA" in Left Menu): Activity Audit (2-for-1 Rule) • Intensity & METs • Clinical Case Coach (Pattern / Rule / Solve)
- Chapter 2 Reference Guide: exw101_ssot_kinesiology_reference.docx
Clinical Cross-Reference: Chapter 6: General Principles of Exercise Prescription • Section 6.4: Resistance Training Parameters.

- Frequency: 2 to 3 days per week targeting all major muscle groups.
- Intensity: 60% to 80% 1RM (moderate to vigorous) to stimulate myofibrillar hypertrophy and neural recruitment.
- Sets & Repetitions: 2 to 4 sets of 8 to 12 repetitions per exercise for general muscular fitness.
- Rest Intervals: 2 to 3 minutes of rest between multi-joint compound sets to allow ATP-PC recovery.

### Regional Focus: Sarcopenia Prevention in Yuma County

Enfoque Regional: Prevención de Sarcopenia y Salud Metabólica en el Condado de Yuma

In Yuma County and regional desert border communities, high summer temperatures often drive older adults and clinical populations into prolonged indoor sedentary behavior. This physical inactivity accelerates age-related sarcopenia, causing selective atrophy of high-threshold Type II muscle fibers and degrading insulin sensitivity. Exercise professionals across local community centers and outpatient facilities at Matador Clinical Partners (MCP) apply PAGA 2018 muscle-strengthening standards (2 or more days weekly) to preserve functional mobility, prevent fall-related injuries, and enhance glycemic control.

En el condado de Yuma y las comunidades agrícolas del desierto, las altas temperaturas de verano incrementan el sedentarismo en interiores en adultos mayores. Esta inactividad acelera la sarcopenia, atrofia selectivamente las fibras musculares Tipo II y reduce la sensibilidad a la insulina. Los profesionales de la kinesiología en centros comunitarios y en Matador Clinical Partners (MCP) aplican las normas PAGA 2018 (2 o más días semanales) para preservar la movilidad funcional y prevenir caídas.


### Reading 1: Excitation-Contraction Coupling & Sarcomere Kinetics

Lectura 1: Acoplamiento Excitación-Contracción y Dinámica del Sarcómero


#### Step 1: Molecular Mechanism of Sarcomere Shortening

Mecanismo Molecular del Acortamiento del Sarcómero

Skeletal muscle force generation begins when an action potential propagates down an alpha motor neuron, releasing Acetylcholine (ACh) across the neuromuscular junction. This depolarizes the sarcolemma, traveling down Transverse Tubules (T-Tubules) to trigger Calcium ion (Ca2+) release from the Sarcoplasmic Reticulum (SR) into the sarcoplasm:

- Troponin-Tropomyosin Shift: Released Calcium (Ca2+) binds directly to Troponin C on the thin filament. This induces a conformational shift that pulls Tropomyosin away from the active binding sites on the Actin filament.
- The Power Stroke: Hydrolyzed ATP (ADP + inorganic phosphate, Pi) on the Myosin globular head binds to the exposed actin site, forming a cross-bridge. The release of Pi triggers the mechanical power stroke, pulling the actin filament toward the central M-line , shortening the H-zone and I-band while the A-band remains constant in length.
- Cross-Bridge Detachment: A fresh molecule of ATP binds to the myosin head, breaking the actin-myosin bond. Myosin ATPase hydrolyzes ATP into ADP + Pi, re-cocking the myosin head for subsequent cross-bridge cycling.

### Reading 2: Motor Unit Typology & Henneman's Size Principle

Lectura 2: Tipología de Unidades Motoras y Principio de Tamaño de Henneman


#### Step 1: Motor Unit Classification Table


#### Step 2: Henneman's Size Principle & Sarcopenia Defense

Principio de Tamaño de Henneman y Defensa contra la Sarcopenia

The central nervous system recruits motor units in a fixed, hierarchical order from smallest soma diameter (Type I slow-twitch) to largest (Type IIx fast-twitch). Low-intensity activity (e.g., casual walking) only activates low-threshold Type I units. To engage high-threshold Type II fibers—which produce peak functional power and suffer the greatest atrophy in sarcopenia—the client must lift heavier loads (60% to 80% 1RM) or perform moderate-load repetitions to momentary muscular fatigue.

El sistema nervioso recluta unidades motoras en orden secuencial desde el menor tamaño (Tipo I) hasta el mayor (Tipo IIx). Para activar las fibras Tipo II de alto umbral—cruciales para evitar caídas y generar potencia—el ejercicio debe presentar una sobrecarga mecánica suficiente (60% a 80% 1RM) o ejecutarse cerca del fallo muscular momentáneo.


### Key Terminology / Glosario Clave

The speed at which muscular contractile force can be generated during the initial phase of contraction, determined by motor unit discharge frequency (rate coding) and fast-twitch fiber recruitment.

La velocidad con la que se produce la fuerza muscular durante la fase inicial de la contracción, determinada por la frecuencia de descarga motora y el reclutamiento de fibras rápidas.

An increase in muscle fiber cross-sectional area driven by the synthesis and dense packing of actin and myosin contractile proteins, leading directly to increased maximal force production.

Aumento en el área de sección transversal de la fibra muscular impulsado por la síntesis de proteínas contráctiles (actina y miosina), incrementando directamente la fuerza máxima.

The age-associated loss of skeletal muscle mass, quality, and contractile strength, characterized by selective denervation and atrophy of Type II fast-twitch muscle fibers.

Pérdida de masa, calidad y fuerza muscular asociada a la edad, caracterizada por la atrofia y denervación selectiva de las fibras musculares rápidas Tipo II.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Fisiología Muscular

Select each question below to confirm your understanding of muscle mechanics and PAGA standards before starting Discussion 05 and Lab 05:

English Response: When released from the Sarcoplasmic Reticulum, Calcium (Ca2+) binds directly to Troponin C. This causes Tropomyosin to shift position, exposing the myosin-binding sites on the actin filament so cross-bridge formation and the power stroke can occur.

Respuesta en Español: Al liberarse del Retículo Sarcoplásmico, el calcio (Ca2+) se une a la Troponina C. Esto desplaza la Tropomiosina, exponiendo los sitios de unión en la actina para que se forme el puente cruzado con la miosina.

English Response: Under Henneman's size principle, low-intensity aerobic walking only recruits low-threshold Type I slow-twitch fibers. Sarcopenia preferentially causes atrophy and loss of Type II fast-twitch fibers. Engaging and preserving Type II fibers requires dedicated moderate-to-vigorous resistance training (at least 2 days/week) involving all major muscle groups.

Respuesta en Español: Según el principio de Henneman, la caminata suave solo activa fibras lentas Tipo I. La sarcopenia atrofia selectivamente las fibras rápidas Tipo II. Para activarlas y preservarlas, PAGA 2018 exige entrenamiento de fuerza de moderado a vigoroso al menos 2 días por semana.

English Response: Adults should perform muscle-strengthening activities of moderate or greater intensity that involve all major muscle groups (legs, hips, back, abdomen, chest, shoulders, and arms) on 2 or more days a week .

Respuesta en Español: Los adultos deben realizar actividades de fortalecimiento muscular de intensidad moderada o mayor que involucren todos los grupos musculares principales 2 o más días por semana .


### AI Simulation Workspace • Muscle Physiology & Sarcopenia Simulation

Copy the prompt below into Gemini to audit fiber recruitment mechanics, evaluate sarcopenia risk, and design progressive overload resistance programs:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-101 Muscle Physiology & Sarcopenia Tool Box ###:
Role: Academic Kinesiology Mentor and Exercise Physiologist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Adult & Older Adult Muscle-Strengthening Guidelines.

Instructions:
Step 1: Review the client profile enclosed within triple-hashes (###) below.
Step 2: Explain the molecular mechanisms of sarcomere contraction and identify the specific motor unit recruitment demands (Henneman's size principle) for their target goal.
Step 3: Evaluate how age-related sarcopenia or physical inactivity impacts Type II fast-twitch muscle fibers in this client.
Step 4: Prescribe a PAGA 2018-aligned resistance training program (2+ days/week, major muscle groups, 60% to 80% 1RM or bodyweight progressions) to build functional capacity.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
Client Age & Background: [e.g., 68-year-old retired farm supervisor]
Current Activity Level: [e.g., Sedentary, walks 10 min daily]
Functional Limitations: [e.g., Difficulty rising from low chairs, mild sarcopenia]
Target Goal: [e.g., Improve lower-body strength and prevent fall risk]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 05 (Mod 05 Required Readings: Muscle Strength & Joint Function)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas Obligatorias: Fisiología Muscular y Normas de Fuerza


### Texto Fuente SSoT y Lineamientos de Fortalecimiento

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) (Capítulo 2: Fortalecimiento Muscular en Adultos) • Guías del ACSM (12.ª edición).

Manual Oficial y Capítulos PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev/chapters)

- Frecuencia: 2 a 3 días por semana en los principales grupos musculares.
- Intensidad: 60% a 80% de 1RM para hipertrofia y fuerza.
- Descanso: 2 a 3 minutos entre series compuestas pesadas para recuperar ATP-PC.

### Conceptos Científicos Centrales


#### Step 1: Acoplamiento Excitación-Contracción

El potencial de acción viaja por los túbulos T liberando calcio (Ca2+) desde el retículo sarcoplásmico. El calcio se une a la troponina C, desplazando la tropomiosina para permitir la unión de la miosina con la actina y el golpe de fuerza hacia la línea M.


#### Step 2: Principio de Tamaño de Henneman y Prevención de Sarcopenia

Las unidades motoras se activan en orden jerárquico de menor a mayor tamaño. Las cargas moderadas a intensas son obligatorias para activar las fibras rápidas Tipo II, principales afectadas por la sarcopenia, garantizando fuerza y estabilidad postural.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-101 • Module 05 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 05:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 05)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 05)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
