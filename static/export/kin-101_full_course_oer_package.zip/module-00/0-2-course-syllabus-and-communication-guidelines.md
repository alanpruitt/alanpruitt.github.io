## KIN-101: 0 2 Course Syllabus And Communication Guidelines

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology / Conceptos de Kinesiología


## 0-2: Course Syllabus & Communication Guidelines / Plan de Estudios y Pautas de Comunicación


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: This page outlines our weekly rhythm, communication expectations, and how Coach Alan supports your progress all semester. New modules open on Tuesdays, Initial Discussion posts are due Thursdays, Peer Replies are due Sundays, and Labs are due Mondays at 11:59 PM. If life gets hectic in Yuma, reach out early in Canvas Inbox so we can keep you on track.


#### En Palabras Sencillas (Norteño Context)

Aquí están las reglas del juego y los días de entrega para que organices tu semana sin sorpresas entre el trabajo y la familia. Si los términos técnicos se ponen pesados, concéntrate primero en el calendario semanal (jueves foro inicial, domingo réplica, lunes laboratorio) y en escribirme si ocupas apoyo.


### THE KINESIOLOGY COURSE CONTRACT

EL CONTRATO DEL CURSO DE KINESIOLOGÍA

- English: Do not download an outdated PDF copy. The active Canvas Syllabus page is our live, real-time contract. It is engineered to load instantly on any mobile screen or browser, keeping our sports nutrition policies, grading parameters, and federal SSoT guidelines completely transparent.
- Español (Regional): No descargue una copia en PDF obsoleta. El plan de estudios activo en Canvas es nuestro contrato en tiempo real. Está diseñado para cargarse de forma instantánea en cualquier pantalla o navegador móvil, manteniendo transparentes las políticas de nutrición y los parámetros de calificación.

### OFFICIAL COMMUNICATION PROTOCOLS

PROTOCOLOS OFICIALES DE COMUNICACIÓN

- English: Always message Coach Alan directly through the Canvas Inbox. Expect a professional response within 24 business hours. For emergency coordination regarding dietary log submission windows, refer to the communication map inside your Module materials.
- Español (Regional): Envíe siempre mensajes directamente a Coach Alan a través de la Bandeja de Entrada de Canvas. Espere una respuesta profesional en un plazo de 24 horas hábiles. Para la coordinación de emergencias relacionadas con la entrega de registros dietéticos, consulte el mapa de comunicación.

### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All course materials and Syllabus guidelines in KIN-101 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools (e.g., Genio).

Español (Regional): Todos los materiales del curso y las pautas del plan de estudios de KIN-101 siguen los principios del Diseño Universal para el Aprendizaje (UDL). Esta página utiliza un diseño centrado en texto y adaptado a dispositivos móviles, compatible al 100% con lectores de pantalla y sistemas de toma de notas con IA.

Process Over Product Evaluation / Evaluación de Proceso:

Course policies and communications are structured to emphasize clear dialogue, professional growth, and accessible learning support without administrative friction.

Accessibility Services • AccessABILITY Resource Services (ARS) / Servicios de Accesibilidad (ARS) :

AccessABILITY Resource Services (ARS) partners with students with disabilities, faculty, and staff to remove barriers in the educational process through thoughtful design and accommodations. Whether you’re scheduling tutoring sessions at the AT Lab, requesting accommodations through our system, or seeking resources to achieve your educational and career goals, our team is here to assist. Located in the College Community Center (3C) on the main campus, we are committed to helping students build self-advocacy skills, overcome obstacles, and succeed academically.

AccessABILITY Resource Services (ARS) colabora con estudiantes con discapacidades, profesores y personal para eliminar barreras en el proceso educativo mediante un diseño cuidadoso y adaptaciones. Ya sea que programe tutorías en el Laboratorio de Tecnología de Asistencia (AT Lab), solicite adaptaciones o busque recursos para alcanzar sus metas académicas y profesionales, nuestro equipo está para apoyarle en el College Community Center (3C) del campus principal.

Location: College Community Center (3C), Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu | Web: AWC Accessibility Services

Our course architecture directly mirrors federal workforce standards set by the U.S. Department of Labor AI Literacy Framework ( Employment and Training Administration Advisory: Training and Employment Notice No. 07-25 , issued February 13, 2026) and institutional equity mandates set by Arizona Western College :

- Step 1: Zero-Cost Equity & Digital Access (DOL Delivery Principle 4 • Equitable Access): All required AI prompts utilize open-access, zero-cost tools (e.g., Google Gemini, exwtoolkit.com , and paga2018.dev ). Mobile-first, text-based formatting ensures seamless access across low-bandwidth connections and mobile devices.
- Step 2: Experiential Context & Prompt Engineering (DOL Content Areas 1, 2 & 3 / Delivery Principles 1 & 2 / Clinical Framing Protocol (Pattern / Rule / Solve)): You learn AI by directing it inside authentic exercise science workflows. All prompt logs must be documented in your cloud repository ( EXW_Professional_AI_Repository ).
- Step 3: Human-in-the-Loop SSoT Auditing (DOL Content Areas 4 & 5 / Delivery Principle 3 / SSoT Rules): Generative AI models are probabilistic and prone to hallucinations. Submitting unverified AI output constitutes an academic integrity violation. You must audit all AI recommendations against our course Single Source of Truth (SSoT).
- Content Area 1 (Understand AI Principles) → The Centaur Protocol: You act as the Clinical Architect / Pilot ; AI serves strictly as a probabilistic calculator requiring verification.
- Content Area 2 (Explore AI Uses) → Coaching Sprints & Clinical Labs: Hands-on exposure to authentic occupational cases using exwtoolkit.com and paga2018.dev .
- Content Area 3 (Direct AI Effectively) → Part 1 (P-T-C-F Prompt Engineering): Structured Persona, Task, Context, and Format prompts wrapped in ### delimiters.
- Content Area 4 (Evaluate Outputs) → Part 2 (150-Word Clinical SSoT Audit): Auditing AI outputs against federal .gov SSoTs ( PAGA 2018 , DGA 2025–2030 , ACSM 12th Ed. , NASM OPT ).
- Content Area 5 (Use AI Responsibly) → Part 3 (150-Word Active Verification) & Traffic Light Policy: Defending clinical decisions in your own voice with zero PII exposure.
- Delivery Principles 1–7 (Community College Execution): Experiential slider calibration (1), Yuma / Imperial Valley borderland context (2), durable human skills via Pattern / Rule / Solve and Sinek’s Golden Circle (3), $0 ZTC OER & Norteño-Spanish HSI parity (4), stackable portfolio pathways (5), faculty enabling tools (6), and Curriculum-as-Code agility (7).
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 00)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 00)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
