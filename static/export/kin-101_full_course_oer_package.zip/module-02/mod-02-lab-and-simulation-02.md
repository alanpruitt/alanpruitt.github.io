## KIN-101: Mod 02 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 02) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Coaching Sprint Simulation: The 3 Planes of Daily Movement

Sesión de Coaching del Módulo 02: Los 3 Planos del Movimiento Cotidiano

- Cardiac Output (Q = Heart Rate × Stroke Volume): Total volume of blood pumped by the heart per minute (L/min), which rises during exercise to deliver oxygen to working skeletal muscle. En palabras sencillas: La cantidad de sangre por minuto que bombea el corazón para llevar oxígeno a los músculos cuando empiezas a moverte.
- Acute Response vs. Chronic Physiological Adaptation: Acute responses are immediate changes during a single workout (higher HR, sweating); chronic adaptations are long-term gains after weeks of training (lower resting HR, higher capillary density). En palabras sencillas: Lo agudo pasa durante la sesión (sube el pulso y sudas); la adaptación crónica es el beneficio duradero tras semanas de constancia.
- Thermoregulatory Heat Strain (Yuma Desert Environment): In ambient temperatures >100°F, blood flow diverts to the skin for cooling, accelerating heart rate and dehydration during outdoor work or exercise. En palabras sencillas: En el calor de Yuma el cuerpo desvía sangre a la piel para enfriarse, lo que sube las pulsaciones más rápido y exige hidratación y sombra.
- KIN-101.2.1.AY26-27: Classify foundational human movements across the three cardinal planes: Sagittal, Frontal, and Transverse. Clasificar los movimientos humanos básicos en los tres planos cardinales: sagital, frontal y transversal.
- KIN-101.2.2.AY26-27: Identify basic joint actions in everyday physical activities and practical fitness settings. Identificar acciones articulares básicas en actividades cotidianas y entornos de ejercicio.

### Your Weekly Win: Unlocking Multi-Planar Movement

This weekly sprint is designed to give you a quick, satisfying mastery "win." Instead of memorizing abstract physics, you will explore how the human body moves in 3D space: Forward/Back (Sagittal), Side-to-Side (Frontal), and Twisting (Transverse). Pick your career track below, chat with your AI Coach, and walk away with a memorable insight you can share with future clients!

Esta sesión semanal está diseñada para brindarle un logro claro y motivador. Elegirá su ruta profesional, conversará con su Coach de IA y obtendrá un aprendizaje clave para aplicarlo en el mundo real.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Elija la ruta que más se alinee con sus metas profesionales

Scenario: Desk worker with stiff lower back who only exercises on a treadmill (forward-only movement) and feels pain when reaching to the side.

Scenario: Senior center walking club member who wants to improve balance and avoid tripping over curbs in Yuma.

Scenario: High school soccer athlete who is strong in straight sprints but slow and uncoordinated when cutting and changing directions.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client situation.
- The 3-Plane Breakdown: Name 1 simple exercise for Sagittal (Forward/Back), 1 for Frontal (Side-to-Side), and 1 for Transverse (Twisting).
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why integrating Frontal (side-to-side) and Transverse (rotational) plane exercises protects your client's joints from single-plane overuse injuries under PAGA 2018 multicomponent standards.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 02 Coaching Sprint • Track 1 (Clinical / Elena)

- Chosen Track & Client: Track 1: Clinical Path (Elena, 42, desk worker). Problem: Elena only walks straight ahead on a treadmill (Sagittal plane). Because she never trains side-to-side or twisting, her hip stabilizers are weak and her lower back hurts when stepping out of her car.
- Track 1: Clinical Path (Elena, 42, desk worker).
- Problem: Elena only walks straight ahead on a treadmill (Sagittal plane). Because she never trains side-to-side or twisting, her hip stabilizers are weak and her lower back hurts when stepping out of her car.
- The 3-Plane Breakdown: Step 1: Sagittal Plane (Forward & Back): Bodyweight Squats (builds knee and hip extension for standing up from her desk). Step 2: Frontal Plane (Side-to-Side): Lateral Resistance Band Steps (strengthens her gluteus medius so she has stable hips when stepping sideways). Step 3: Transverse Plane (Twisting): Standing Torso Rotations with light cable or bodyweight (restores thoracic spine mobility for turning safely).
- Step 1: Sagittal Plane (Forward & Back): Bodyweight Squats (builds knee and hip extension for standing up from her desk).
- Step 2: Frontal Plane (Side-to-Side): Lateral Resistance Band Steps (strengthens her gluteus medius so she has stable hips when stepping sideways).
- Step 3: Transverse Plane (Twisting): Standing Torso Rotations with light cable or bodyweight (restores thoracic spine mobility for turning safely).
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical reasoning, Elena's lower-back and hip discomfort stems directly from sagittal-plane dominance: she sits forward at a desk all day and only walks straight ahead on a treadmill. An unverified AI workout that simply adds more forward walking or sagittal lunges leaves her frontal-plane hip abductors (gluteus medius) and transverse-plane thoracic rotators weak, leaving her lumbar spine vulnerable the moment she twists to step out of her car. By applying PAGA 2018 multicomponent muscle-strengthening guidelines across all three anatomical planes—combining bodyweight squats with lateral band walks and standing torso rotations—we restore 3D pelvifemoral stability and protect her spine during everyday life in Yuma."
- My Memorable Coaching Takeaway: EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!" ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!"
- ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M02_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 02 (Mod 02 Coaching Sprint: The 3 Planes of Daily Movement)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología


## Módulo 02 Simulación de Coaching: Los 3 Planos del Movimiento

Evaluación Rápida y Aprendizaje Práctico del Movimiento Funcional


### Su Logro Semanal: Dominar el Movimiento en 3D

Esta sesión está diseñada para brindarle un logro rápido y motivador. Aprenderá cómo el cuerpo se mueve en 3 dimensiones: Hacia adelante/atrás (sagital), De lado a lado (frontal) y Giros (transversal). ¡Elija su ruta profesional, converse con su Coach de IA y obtenga una enseñanza inolvidable!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el cliente elegido.
- Desglose de los 3 Planos: Nombre 1 ejercicio para el plano Sagital, 1 para el Frontal y 1 para el Transversal.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué integrar ejercicios en los planos Frontal y Transversal protege las articulaciones del cliente contra lesiones por sobreuso en un solo plano según PAGA 2018.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 02 Sesión de Coaching • Ruta 1 (Elena)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica (Elena, 42 años, oficinista). Problema: Solo camina en cinta hacia adelante (plano sagital). Como nunca entrena de lado o girando, sus caderas están débiles y le duele la espalda al bajarse del carro.
- Ruta 1: Clínica (Elena, 42 años, oficinista).
- Problema: Solo camina en cinta hacia adelante (plano sagital). Como nunca entrena de lado o girando, sus caderas están débiles y le duele la espalda al bajarse del carro.
- Desglose de los 3 Planos: Step 1: Plano Sagital (Adelante y Atrás): Sentadillas con peso corporal (fortalece piernas para levantarse de la silla). Step 2: Plano Frontal (Lado a Lado): Pasos laterales con banda de resistencia (fortalece glúteo medio para dar pasos de lado sin dolor). Step 3: Plano Transversal (Giros): Rotaciones de torso de pie (devuelve movilidad a la columna para girar con seguridad).
- Step 1: Plano Sagital (Adelante y Atrás): Sentadillas con peso corporal (fortalece piernas para levantarse de la silla).
- Step 2: Plano Frontal (Lado a Lado): Pasos laterales con banda de resistencia (fortalece glúteo medio para dar pasos de lado sin dolor).
- Step 3: Plano Transversal (Giros): Rotaciones de torso de pie (devuelve movilidad a la columna para girar con seguridad).
- Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi criterio clínico, el dolor de espalda y cadera de Elena proviene de moverse únicamente en el plano sagital: pasa el día sentada frente al escritorio y solo camina hacia adelante en la caminadora. Si una IA genérica le receta más caminata lineal, sus estabilizadores laterales en el plano frontal (glúteo medio) y rotadores en el plano transversal seguirán débiles al girar para bajarse del carro. Al aplicar las pautas de fuerza multicomponente de PAGA 2018 en los tres planos—sumando pasos laterales con banda y rotaciones de torso—devolvemos la estabilidad tridimensional a su cadera y protegemos su columna lumbar."
- Mi Frase Inolvidable de Coaching: EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!" ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- EN: "If you only exercise moving forward, your body is only strong in one-third of the real world. Moving in all three planes keeps your joints healthy and your back pain-free!"
- ES: "¡Si solo haces ejercicio hacia adelante, tu cuerpo solo será fuerte en un tercio del mundo real. Moverte en los tres planos mantiene tus articulaciones sanas y tu espalda sin dolor!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M02_Quiz_Sprint.pdf
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 02)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
