## KIN-101: Mod 02 Clinical Discussion

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 02) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Discussion: How the Body Moves vs. How It Adapts

This week, we deconstruct the breakdown of athletic and functional performance into mechanical joint forces (Biomechanics) versus energy substrate depletion and thermoregulatory fatigue (Exercise Physiology). Select a career-aligned track below and audit a real-world movement breakdown using Google Gemini!

Esta semana, desglosamos el colapso del rendimiento deportivo y funcional en términos de fuerzas mecánicas articulares (Biomecánica), frente al agotamiento de los sustratos energéticos y de la fatiga termorreguladora (Fisiología del Ejercicio). ¡Seleccione una ruta alineada con su carrera y audite una falla de movimiento con Google Gemini!

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM / Martes a las 12:00 AM
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM / Jueves a las 11:59 PM
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM / Domingo a las 11:59 PM
- Board Closes / Cierre del Foro: Monday at 11:59 PM / Lunes a las 11:59 PM
I review every initial submission and post my clinical analyses directly in this public thread as well as inside SpeedGrader. Be sure to check back to see my detailed Feedback on your post and your peers' posts to sharpen your sub-disciplinary auditing skills!

Reviso cada publicación inicial y publico mis análisis clínicos directamente en este hilo público, así como en SpeedGrader. ¡Asegúrese de regresar para ver mis comentarios detallados en su publicación y en la de sus compañeros, para perfeccionar sus habilidades de auditoría!


### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Choose ONE of the three career-aligned tracks below to copy into your AI Preceptor query:

Focus: Post-rotator cuff surgery patient experiencing acute shoulder impingement and muscular fatigue during overhead rehabilitation exercises.

Focus: Outdoor municipal park maintenance worker suffering repetitive lifting spinal strain and heat-induced metabolic fatigue in Yuma summer conditions.

Focus: Collegiate starting right-handed baseball pitcher experiencing a sharp fastball velocity drop and anterior shoulder pain after 50 pitches.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM):

- Identify Selected Track & Case / Identifique la Ruta y Caso Seleccionado: State your chosen track (Track 1 Clinical, Track 2 Community, or Track 3 Performance) and client initials. Indique la ruta seleccionada y las iniciales del cliente.
- Isolate Biomechanical Factors / Aísle los Factores Biomecánicos: What kinetic forces, lever lengths, joint alignment errors, or shearing vectors contributed to the physical movement breakdown? ¿Qué fuerzas cinéticas, longitudes de palanca, errores de alineación articular o vectores de cizallamiento contribuyeron a la falla mecánica?
- Isolate Exercise Physiology Factors / Aísle los Factores de Fisiología del Ejercicio: What metabolic energy depletion (ATP-CP, glycogen), neuromuscular firing degradation, or heat-induced cardiorespiratory drift caused systemic exhaustion? ¿Qué agotamiento de energía metabólica (ATP-PC, glucógeno), degradación de la activación neuromuscular o fatiga cardiorrespiratoria inducida por el calor causó el agotamiento sistémico?

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM , respond to at least ONE (1) classmate who selected a different track than yours (Minimum 1 Reply Required). Evaluate whether they accurately separated mechanical forces from metabolic fatigue in their case example, or suggest an additional corrective exercise drill or physiological recovery intervention!


#### 10/10 High-Fidelity Student Exemplar / Ejemplo de Entrega (10/10)

- Case Selection / Selección de Caso: A starting right-handed baseball pitcher experiencing a sharp fastball velocity drop (from 90 mph down to 82 mph) and anterior shoulder pain after 50 pitches during an afternoon game in Yuma heat. Un lanzador abridor diestro de béisbol que experimenta una caída drástica en la velocidad de su bola rápida (de 90 mph a 82 mph) y dolor anterior en el hombro después de 50 lanzamientos durante un partido por la tarde en el calor de Yuma.
- Biomechanical Audit / Auditoría Biomecánica: During the late cocking and acceleration phases, the pitcher displays insufficient scapular upward rotation and serratus anterior weakness. This allows the humeral head to translate excessively anteriorly, causing subacromial impingement of the supraspinatus tendon. The mechanical error is a joint-alignment vector failure at high angular velocity (τ = F · d). Durante las fases de preparación tardía y aceleración, el lanzador muestra una rotación escapular superior insuficiente y debilidad del serrato anterior. Esto permite que la cabeza humeral se traslade excesivamente hacia adelante, lo que provoca un pinzamiento subacromial del tendón del supraespinoso. El error mecánico es una falla en el vector de alineación articular bajo alta velocidad angular (τ = F · d).
- Exercise Physiology Audit / Auditoría de Fisiología del Ejercicio: High-velocity pitching relies on rapid ATP-CP phosphagen breakdown backed by anaerobic glycolysis. By pitch 50, intramuscular phosphagen depletion and metabolite accumulation reduce the rate of force development. Furthermore, playing in Yuma's 102°F heat triggers severe cardiovascular drift—elevating heart rate to maintain cardiac output as plasma volume drops through sweating—which accelerates central nervous system fatigue and degrades motor unit recruitment. El picheo de alta velocidad depende de la rápida descomposición de fosfágenos (ATP-PC), respaldada por la glucólisis anaerobia. Para el lanzamiento 50, el agotamiento de los fosfágenos intramusculares y la acumulación de metabolitos reducen la tasa de desarrollo de la fuerza. Además, jugar en el calor de 102 °F de Yuma desencadena una severa deriva cardiovascular —elevando la frecuencia cardíaca para mantener el gasto cardíaco a medida que disminuye el volumen plasmático por la sudoración— lo que acelera la fatiga del sistema nervioso central y degrada el reclutamiento de unidades motoras.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 02 (Mod 02 Discussion: How the Body Moves vs. How It Adapts)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Resumen de Navegación en Español (KIN-101 • Conceptos de Kinesiología y Educación Física • Módulo 02)

Este recurso incluye traducción bilingüe integrada en cada sección bajo el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y nuestra Fuente Única de Verdad (Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.)). Usted puede participar y entregar sus análisis en inglés, español o ambos.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 02)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 02)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
