## KIN-101: Mod 11 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 11 Lab & Simulation: Age-Appropriate Exercise Plan Audit

Laboratorio del Módulo 11: Auditoría de Ejercicio para Poblaciones a lo Largo de la Vida y Simulación

- Youth 60-Minute Daily Activity Triad (PAGA 2018 Ch. 3): Children and adolescents (ages 6–17) require ≥60 minutes/day of moderate-to-vigorous activity, including vigorous aerobic, muscle-strengthening, and bone-strengthening (impact/jumping) ≥3 days/week each. En palabras sencillas: Niños y jóvenes necesitan 60 minutos diarios de movimiento activo que incluyan juegos vigorosos, fuerza y saltos para fortalecer los huesos al menos 3 días por semana.
- Older Adult Multicomponent Training (PAGA 2018 Ch. 5): Adults ≥65 years require weekly multicomponent physical activity combining balance training, muscle-strengthening (≥2 days/wk), and aerobic movement (150–300 min/wk as abilities allow) to prevent falls. En palabras sencillas: En adultos mayores combinamos tres piezas cada semana—equilibrio, fuerza y caminata—para evitar caídas y mantener su independencia diaria.
- Sarcopenia & Relative Intensity (0–10 Perceived Effort Scale): Age-related loss of skeletal muscle mass and strength; PAGA 2018 specifies judging older adults' moderate intensity (5–6 out of 10) relative to their own current fitness level. En palabras sencillas: La pérdida de músculo con la edad se frena con fuerza segura, midiendo el esfuerzo (5 a 6 de 10) según la capacidad real de cada persona mayor.

### Sarcopenia Prevention, Multicomponent Physical Activity & Fall Risk Mitigation

In this laboratory assignment, you will conduct a clinical and functional lifespan exercise audit and construct an evidence-based adapted activity prescription. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will evaluate physiological aging markers (sarcopenia, proprioceptive decline, postural instability), apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) older adult standards, and execute an AI-driven simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría de ejercicio a lo largo de la vida, diseñando un protocolo adaptado basado en evidencia, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando la prevención de sarcopenia y caídas según PAGA 2018.

- KIN-101.11.3.AY26-27: Evaluate physiological aging markers, sarcopenia, and fall risk thresholds in older adults across diverse demographic cohorts. Evaluar marcadores de envejecimiento fisiológico, sarcopenia y umbrales de riesgo de caídas en adultos mayores.
- KIN-101.11.4.AY26-27: Design multicomponent exercise prescriptions and bilingual coaching cue cards aligned with PAGA 2018 lifespan standards. Diseñar prescripciones de ejercicio multicomponente y tarjetas de instrucción bilingües alineadas con las normas de PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, October 27, 2026, at 12:00 AM MST Abre el martes, 27 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, November 2, 2026, at 11:59 PM MST Lunes, 2 de noviembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Scale) Ponderación de evaluación para laboratorios semanales y simulaciones prácticas

### Lab Objectives

Objetivos del Laboratorio

- Audit the physiological mechanisms of sarcopenia, loss of motor units, and sensory-motor degradation in aging populations. Auditar los mecanismos fisiológicos de la sarcopenia y la degradación sensoriomotora en poblaciones que envejecen.
- Apply federal PAGA 2018 (2nd Ed.) older adult multicomponent physical activity standards (balance training, aerobic exercise, and progressive muscle strengthening). Aplicar las pautas de actividad física multicomponente de PAGA 2018 para adultos mayores (equilibrio, aeróbico y fuerza progresiva).
- Formulate a 4-week adapted exercise remediation plan paired with bilingual coaching cue cards in English and Spanish. Formular un plan de ejercicio adaptado de 4 semanas con tarjetas de instrucción bilingües en inglés y español.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-11

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos del Caso de Poblaciones Especiales

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Geriatric fall prevention; managing severe sarcopenia, proprioceptive degradation, and fear of falling following a recent fall.

Focus: Community-dwelling older adults; designing an inclusive senior mobility curriculum addressing osteoarthritis stiffness and sedentary deconditioning.

Focus: Master's athletic longevity; managing age-related power loss, tendon stiffness decline, and recovery kinetics in competitive older runners.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete lifespan exercise audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client Initials: Declare chosen track and baseline functional profile.
- Part 1: Pattern Recognition: Identify specific aging markers (sarcopenia, balance deficits, proprioceptive loss, or motor unit shifts).
- Part 2: Rule Application: Cite PAGA 2018 older adult multicomponent physical activity standards and fall prevention benchmarks.
- Part 3: Solving the Gap (Active Verification & Prescription): In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your 4-week multicomponent plan protects client safety and aligns with PAGA 2018 guidelines. Detail your balance progressions, progressive resistance loading, and 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 11 Lab • Track 1 (Clinical / M.G.)

- Selected Track & Client Initials: Track 1: Clinical & Allied Health Path • M.G. (Age 74, Female). Baseline TUG score of 14.8s indicates elevated fall risk, accompanied by bilateral lower extremity muscle atrophy and fear-avoidance behavior.
- Part 1: Pattern Recognition: M.G. demonstrates hallmark physiological manifestations of sarcopenia, including selective loss of Type II muscle fibers, blunted motor unit recruitment, and proprioceptive sensory blunting. Her recent slip triggered an avoidance cycle, increasing physical inactivity and accelerating functional decline.
- Part 2: Rule Application (PAGA 2018 Standards): Under the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , older adults at risk of falls must engage in multicomponent physical activity emphasizing dynamic balance, strength training (>=2 days/week targeting major muscle groups), and moderate aerobic reconditioning (accumulating 150 minutes/week).
- Part 3: Solving the Gap (Active Verification & Prescription): 4-Week Multicomponent Protocol: Balance Component (3x/week): Tandem stance, single-leg balancing with chair support, and heel-to-toe line walking (15 min/session). Resistance Component (2x/week): Sit-to-stand chair squats, resistance band seated rows, and calf raises (2 sets of 10-12 reps at RPE 5-6). Aerobic Component: Continuous recumbent stepping or indoor track walking accumulating 20-30 min/day, 5 days/week. Active Verification: In my clinical reasoning, M.G.'s primary pathology is not simply chronological aging, but a vicious cycle where a fear of falling accelerates disuse atrophy and proprioceptive decay. Prescribing aerobic walking alone would fail to address her vestibular deficits or lower-body power loss. By anchoring her intervention in PAGA 2018 multicomponent principles—specifically integrating dynamic balance training before strength work—we retrain sensory-motor integration, restore quadriceps force production through sit-to-stand transitions, and systematically rebuild her functional autonomy safely without exposing her to unsupported fall hazards. Bilingual Coaching Cue Card: EN: "Focus on pushing firmly through your heels as you stand from the chair, and keep your eyes focused on a steady point ahead during your balance drills." ES: "Concéntrese en empujar firmemente con los talones al levantarse de la silla y mantenga la mirada fija en un punto estable al frente durante sus ejercicios de equilibrio."
- 4-Week Multicomponent Protocol: Balance Component (3x/week): Tandem stance, single-leg balancing with chair support, and heel-to-toe line walking (15 min/session). Resistance Component (2x/week): Sit-to-stand chair squats, resistance band seated rows, and calf raises (2 sets of 10-12 reps at RPE 5-6). Aerobic Component: Continuous recumbent stepping or indoor track walking accumulating 20-30 min/day, 5 days/week.
- Balance Component (3x/week): Tandem stance, single-leg balancing with chair support, and heel-to-toe line walking (15 min/session).
- Resistance Component (2x/week): Sit-to-stand chair squats, resistance band seated rows, and calf raises (2 sets of 10-12 reps at RPE 5-6).
- Aerobic Component: Continuous recumbent stepping or indoor track walking accumulating 20-30 min/day, 5 days/week.
- Active Verification: In my clinical reasoning, M.G.'s primary pathology is not simply chronological aging, but a vicious cycle where a fear of falling accelerates disuse atrophy and proprioceptive decay. Prescribing aerobic walking alone would fail to address her vestibular deficits or lower-body power loss. By anchoring her intervention in PAGA 2018 multicomponent principles—specifically integrating dynamic balance training before strength work—we retrain sensory-motor integration, restore quadriceps force production through sit-to-stand transitions, and systematically rebuild her functional autonomy safely without exposing her to unsupported fall hazards.
- Bilingual Coaching Cue Card: EN: "Focus on pushing firmly through your heels as you stand from the chair, and keep your eyes focused on a steady point ahead during your balance drills." ES: "Concéntrese en empujar firmemente con los talones al levantarse de la silla y mantenga la mirada fija en un punto estable al frente durante sus ejercicios de equilibrio."
- Repository Verification: AI Preceptor simulation exported and archived: EXW_Professional_AI_Repository / EXW_101_M11_Lab_Simulation.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 11 (Mod 11 Lab: Age-Appropriate Exercise Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 11 Práctica de Laboratorio: Auditoría de Ejercicio para Poblaciones Especiales

Evaluación de Envejecimiento Fisiológico, Prevención de Caídas y Prescripción Multicomponente


### Visión General del Laboratorio

Ejecute una auditoría clínica utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluando marcadores de envejecimiento, aplicando pautas multicomponente de PAGA 2018 y redactando su verificación activa en su propia voz profesional.


### Estructura de Entrega


#### Parte 1: Reconocimiento de Patrones

Identifique marcadores de sarcopenia, pérdida propioceptiva y riesgo de caídas en el caso seleccionado.


#### Parte 2: Aplicación de Reglas (Normas PAGA 2018)

Aplique los estándares multicomponente de PAGA 2018 que integran entrenamiento de equilibrio, fuerza progresiva y acondicionamiento aeróbico.


#### Parte 3: Resolución de la Brecha (Verificación Activa y Prescripción)

Detalle el plan de 4 semanas, redacte su verificación activa de 100 a 150 palabras justificando la seguridad y proporcione la tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

Patrón: Paciente de 74 años con sarcopenia acentuada, atrofia en cuádriceps, prueba TUG de 14.8s y miedo post-caída que alimenta un círculo vicioso de inactividad física.

Regla: Las normas de PAGA 2018 para adultos mayores exigen actividad multicomponente con énfasis primordial en equilibrio dinámico, entrenamiento de fuerza (>=2 días/semana) y actividad aeróbica moderada.

Solución y Verificación Activa: En mi juicio clínico, prescribir únicamente caminata a M.G. sería insuficiente y peligroso debido a su déficit propioceptivo. Al estructurar una intervención multicomponente que inicia con equilibrio estático y progresa a transiciones de sentadilla en silla asistida, restauramos la fuerza de soporte y la confianza neuromuscular, rompiendo el ciclo de miedo y previniendo futuras caídas de manera segura.

ES: "Concéntrese en empujar firmemente con los talones al levantarse de la silla y mantenga la mirada fija en un punto estable al frente durante sus ejercicios de equilibrio."

KIN-101 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 11)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 11)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
