## KIN-101: Mod 11 Required Readings Lifespan Physical Activity And Age Appropriate Exercise

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 11 Required Readings: Lifespan Physical Activity & Age-Appropriate Exercise

Actividad Física a lo Largo de la Vida y Poblaciones Especiales


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Our bodies change as we age, and exercise plans should change with them. After about age 30, we slowly lose muscle and strength, and later our balance can get worse. Older adults stay strong and independent by mixing balance, aerobic, and strength activities.


#### En Palabras Sencillas (Norteño Context)

Piensa en tu cuerpo como una casa de adobe: con los años necesita más mantenimiento, pero si la cuidas, sigue firme. Si los términos técnicos se ponen pesados, concéntrate primero en mantener la fuerza y el equilibrio.

This week's advanced literature explores the precise physiological mechanisms governing lifespan physical activity and adapted exercise programming for special populations. By deeply examining age-related physiological changes, geriatric functional decline, neuromuscular degradation, and modified exercise parameters, we uncover how tailored movement prescriptions preserve functional independence and metabolic health across developmental stages.

Anchored in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , these readings establish that lifelong movement requires systematic adaptation to accommodate chronic conditions, prenatal requirements, and older adult safety considerations without sacrificing physical conditioning or neuromuscular vitality.


### 1. Lifespan Physiology, Sarcopenia & Neuromuscular Degradation

Aging and developmental transitions introduce distinct physiological alterations that reshape physical capacity, metabolic turnover, and neuromuscular coordination:

- Sarcopenia & Dynapenia Mechanics: Sarcopenia describes the progressive, involuntary loss of skeletal muscle mass (~3–8% per decade after age 30), while dynapenia refers to the faster loss of muscle strength. Both are heavily driven by type II (fast-twitch) motor unit apoptosis and physical inactivity.
- Cardiovascular & Pulmonary Aging: Progressive reductions in maximal heart rate ($HR_{max}$), myocardial compliance, stroke volume, and maximal oxygen uptake ($VO_2max$) elevate relative submaximal workloads, making cardiorespiratory pacing critical for older adults.
- Neuromuscular & Proprioceptive Decline: Degeneration of joint mechanoreceptors and slowed nerve conduction velocity impair postural stability, significantly increasing fall risks unless countered by targeted balance and neuromuscular training.

### 2. Adapted Exercise Programming for Special Populations

Modifying exercise prescriptions for special populations requires safeguarding participant health while applying progressive overload tailored to specific physiological constraints:

- Older Adults (65+): PAGA 2018 mandates multicomponent physical activity integrating balance training, aerobic conditioning, and progressive resistance exercise to preserve functional autonomy and prevent frailty.
- Prenatal Exercise Adaptations: Focuses on maintaining maternal fitness, preventing excessive gestational weight gain, and avoiding supine exercises after the first trimester (due to vena cava compression). Intensity is monitored via the talk test or modified Borg RPE (11–13).
- Chronic Disease & Functional Limitations: Tailoring FITT variables (Frequency, Intensity, Time, Type) to accommodate pathologies such as osteoarthritis, Type 2 diabetes, or controlled hypertension, ensuring medical clearance and symptom-guided pacing.

### 3. PAGA 2018 Lifespan Mandates & Balance Integration

Federal standards explicitly establish that physical activity requirements adapt across life stages rather than expiring with age. The PAGA 2018 (2nd Ed.) outlines vital lifespan thresholds:

- Multicomponent Activity Mandate: Older adults should perform varied physical activity that includes balance training (to counteract neuromuscular decline) alongside aerobic and muscle-strengthening activities.
- Individualized Capacity Baseline: When chronic conditions or functional limitations prevent older adults from completing 150 minutes of moderate aerobic activity weekly, practitioners must adapt regimens to individual abilities and avoid inactivity.

### Workplace Intelligence & AI Security Protocol ()

In modern health, kinesiology, and wellness informatics, generative artificial intelligence functions as an automated auditing partner. To enforce rigorous institutional and clinical standards, the Safety Auditor Protocol requires you to structure all AI-driven prompt engineering using mandatory triple-hash delimiters ( ### ).

Wrapping variable inputs, clinical case files, and parameters within triple-hashes achieves data boundary isolation and strict SSoT alignment against federal benchmarks like PAGA 2018 (2nd Ed.) .


```text
SYSTEM DIRECTIVE & SECURITY PROTOCOL ###:
[ROLE]: Expert Kinesiology Preceptor & Special Populations Specialist.
[SSoT COMPLIANCE]: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).
[CALCULATION PARAMETERS]: Geriatric Functional Fitness, Balance Protocols, Modified FITT.
[DATA INTEGRITY]: All computational inputs must remain strictly isolated within these delimiters.
END PROTOCOL ###:
```


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-101 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Biometrics Box, Safety Box, Cardio Box, Strength Box, Recovery Box y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-101 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018)) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 11 (Mod 11 Required Readings: Lifespan Physical Activity & Age-Appropriate Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas en Línea: Actividad Física a lo Largo de la Vida

La literatura avanzada de esta semana explora los mecanismos fisiológicos precisos que rigen la actividad física a lo largo de la vida y la programación de ejercicio adaptado para poblaciones especiales. Al examinar a profundidad los cambios fisiológicos relacionados con la edad, el declive funcional geriátrico, la degradación neuromuscular y los parámetros de ejercicio modificados, descubrimos cómo las prescripciones de movimiento personalizadas preservan la independencia funcional y la salud metabólica.

Fundamentadas en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) , estas lecturas establecen que el movimiento a lo largo de la vida requiere una adaptación sistemática para dar cabida a las condiciones crónicas, los requisitos prenatales y las consideraciones de seguridad en adultos mayores sin sacrificar el acondicionamiento físico.


### 1. Fisiología a lo Largo de la Vida, Sarcopenia y Degradación Neuromuscular

- Mecánica de Sarcopenia y Dinapenia: La sarcopenia describe la pérdida involuntaria de masa muscular (~3–8% por década después de los 30 años), mientras que la dinapenia se refiere a la pérdida acelerada de fuerza. Ambas son impulsadas por la apoptosis de unidades motoras y el desuso.
- Envejecimiento Cardiovascular y Pulmonar: Reducciones graduales en la frecuencia cardíaca máxima ($HR_{max}$), adaptabilidad miocárdica, volumen sistólico y VO2max elevan las cargas relativas.
- Deterioro Neuromuscular y Propioceptivo: La degeneración de mecanorreceptores articulares y la menor velocidad de conducción nerviosa deterioran la estabilidad postural y elevan el riesgo de caídas.

### 2. Programación de Ejercicio Adaptado para Poblaciones Especiales

La modificación de las prescripciones de ejercicio requiere proteger la salud del participante aplicando sobrecarga progresiva:

- Adultos Mayores (65+): Actividad física multicomponente que integra entrenamiento de equilibrio, acondicionamiento aeróbico y resistencia progresiva.
- Participantes Prenatales: Mantener la condición materna, evitar ejercicios en decúbito supino después del primer trimestre y controlar la intensidad mediante la prueba del habla.
- Condiciones Crónicas: Adaptar las variables FITT para osteoartritis, diabetes tipo 2 o hipertensión con la debida autorización médica.

### 3. Mandatos de la PAGA 2018 para la Actividad y el Equilibrio

- Mandato de Actividad Multicomponente: Los adultos mayores deben realizar actividad física variada que incluya entrenamiento de equilibrio junto con actividades aeróbicas y de fortalecimiento.
- Base de Capacidad Individualizada: Cuando las condiciones crónicas impidan completar 150 minutos de actividad aeróbica moderada, los profesionales deben adaptar los regímenes a las capacidades individuales.
KIN-101 • Module 11 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 11)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 11)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
