## KIN-101: Mod 13 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 13) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 13 Coaching Sprint Simulation: Spotting & Fixing Unsafe Lifting Form

Sesión de Coaching del Módulo 13: Auditoría Biomecánica y Eficiencia

- Moment Arm & Lumbar Shear vs. Compressive Load: As a weight drifts forward away from the body's center of mass, the horizontal moment arm lengthens and multiplies shear stress on the lumbar intervertebral discs. En palabras sencillas: Entre más se aleja la barra o caja de tu cuerpo al levantarla, más palanca y presión peligrosa recibe la espalda baja.
- Hip Hinge Mechanics vs. Loaded Spinal Flexion: Driving movement through the hips and glutes while keeping a neutral spine braced, preventing disc herniation risk caused by rounding the lower back under load. En palabras sencillas: Doblar desde la cadera empujando las pompis hacia atrás con la espalda derechita, en vez de encorvar la cintura al cargar peso.
- Intra-Abdominal Bracing & Avoiding the Valsalva Maneuver: Stiffening the core 360° while exhaling through the sticking point of a lift, preventing dangerous blood-pressure spikes caused by breath-holding (Valsalva). En palabras sencillas: Apretar el abdomen soltando el aire al hacer el esfuerzo, sin aguantar la respiración para que no se dispare la presión arterial.
- KIN-101.13.1.AY26-27: Audit applied biomechanical patterns, force vectors, and tissue loading constraints across career-aligned professional tracks. Auditar patrones biomecánicos aplicados, vectores de fuerza y restricciones de carga tisular en rutas profesionales.
- KIN-101.13.2.AY26-27: Apply PAGA 2018 safety standards and torque optimization protocols to structure injury-mitigating exercise interventions. Aplicar las normas de seguridad de la PAGA 2018 y protocolos de optimización de torque para estructurar intervenciones.

### Your Weekly Win: Mastering Biomechanical Auditing & Efficiency

How does analyzing force vectors and tissue loading empower practitioners to mitigate orthopedic stress and optimize movement execution? Examining joint torque, moment arms, and viscoelastic stress properties allows exercise leaders to design safe, biomechanically sound remediation protocols. Following federal PAGA 2018 standards, professionals can structure evidence-based interventions tailored to diverse clinical, educational, and athletic pathways. Choose your coaching track below, chat with your AI Socratic Coach, and master applied biomechanics!

¿Cómo ayuda el análisis de vectores de fuerza y carga tisular a los profesionales a mitigar el estrés ortopédico? Examinar el torque articular y las propiedades de estrés permite diseñar protocolos seguros. ¡Elija su ruta y dialogue con su coach de IA!

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Neuromuscular Work-to-Rest & Safe Lifting Recovery Auditor (/simulators/saq-power-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate high-load phosphagen recovery intervals (1:12 to 1:20 work-to-rest ratio; 2–3 min inter-set rest) to prevent fatigue-induced lumbar flexion, knee valgus, and joint shear under PAGA 2018 & ACSM 12th Ed. Copy your VERIFIED simulator receipt or slider values into the submission template below • Paired Biomechanical Torque & Moment-Arm route: /simulators/joint-load-auditor .

Open Neuromuscular Work-to-Rest & Safe Lifting Recovery Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/saq-power-auditor y "PAGA"): Calibre la relación trabajo-descanso (1:12 a 1:20; 2–3 min entre series) para evitar que la fatiga rompa la postura lumbar o cause valgo de rodilla bajo PAGA 2018 y ACSM 12.ª ed. Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Scenario: Post-rehabilitation patient (K.L., 48) exhibiting patellofemoral joint stress and excessive shear forces during open-chain knee rehabilitation.

Scenario: Middle school youth cohort (Average Age, 14) exhibiting postural deviations and spinal loading stress during backpack transport.

Scenario: Collegiate sprinter and jumper (T.M., 20) experiencing force vector leakage and suboptimal ground reaction force application.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission / Fase 3: Entrega en Canvas (Solo Texto)

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's biomechanical challenge.
- Biomechanical & Tissue Analysis: Explain force vectors, torque, tissue loading, and PAGA 2018 safety standards for your client.
- My Biomechanical Strategy: Provide 1 clear, evidence-based torque optimization or movement remediation intervention.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 13 Coaching Sprint • Track 1 (Clinical & Allied Health Path)

- Chosen Track & Client: Track 1: Clinical & Allied Health Path (K.L., 48). Challenge: Exhibiting patellofemoral joint stress and excessive shear forces during early-stage open-chain knee rehabilitation.
- Track 1: Clinical & Allied Health Path (K.L., 48).
- Challenge: Exhibiting patellofemoral joint stress and excessive shear forces during early-stage open-chain knee rehabilitation.
- Biomechanical & Tissue Analysis: PAGA 2018 Standards & Torque: Under PAGA 2018 (2nd Ed.) safety standards, exercise prescriptions must prioritize joint integrity and tissue loading thresholds by shifting from high shear open-chain movements to closed-chain kinetic exercises that promote compressive joint stability. Minimizing unfavorable moment arms protects articular cartilage.
- PAGA 2018 Standards & Torque: Under PAGA 2018 (2nd Ed.) safety standards, exercise prescriptions must prioritize joint integrity and tissue loading thresholds by shifting from high shear open-chain movements to closed-chain kinetic exercises that promote compressive joint stability.
- Minimizing unfavorable moment arms protects articular cartilage.
- My Biomechanical Strategy for K.L.: "Transition from open-chain knee extensions to controlled closed-chain leg presses and mini-squats to distribute joint articulation forces and minimize patellofemoral stress peaks."
- "Transition from open-chain knee extensions to controlled closed-chain leg presses and mini-squats to distribute joint articulation forces and minimize patellofemoral stress peaks."
- My Memorable Coaching Takeaway: EN: "Optimizing joint torque mechanics and transitioning to closed-chain kinetic exercises protects articular cartilage and mitigates orthopedic stress!" ES: "¡Optimizar la mecánica del torque articular y hacer la transición a ejercicios cinéticos de cadena cerrada protege el cartílago articular y mitiga el estrés ortopédico!"
- EN: "Optimizing joint torque mechanics and transitioning to closed-chain kinetic exercises protects articular cartilage and mitigates orthopedic stress!"
- ES: "¡Optimizar la mecánica del torque articular y hacer la transición a ejercicios cinéticos de cadena cerrada protege el cartílago articular y mitiga el estrés ortopédico!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M13_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 13 (Mod 13 Coaching Sprint: Spotting & Fixing Unsafe Lifting Form)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 13 Simulación de Coaching: Auditoría Biomecánica

Evaluación Rápida y Optimización de Torque


### Su Logro Semanal: Dominando la Auditoría Biomecánica y la Eficiencia

Esta sesión le permitirá aplicar los estándares de PAGA 2018 y los principios de torque para analizar la carga tisular y estructurar estrategias de ejercicio adaptado. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Paciente post-rehabilitación (K.L., 48) con estrés patelofemoral y fuerzas de cizallamiento excesivas en rehabilitación de rodilla.

Escenario: Cohorte juvenil de secundaria (Edad promedio, 14) con desviaciones posturales y estrés de carga espinal.

Scenario: Sprinter y saltador universitario (T.M., 20) con pérdida de vectores de fuerza y aplicación subóptima de fuerza de reacción.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío biomecánico de su cliente.
- Análisis Biomecánico y Tisular: Explique los vectores de fuerza, torque, carga tisular y normas de PAGA 2018 para su cliente.
- Mi Estrategia Biomecánica: Escriba 1 intervención de optimización de torque o remediación basada en evidencia.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 13 Sesión de Coaching • Ruta 1 (Clínica / K.L.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Profesiones de la Salud (K.L., 48). Reto: Exhibiendo estrés patelofemoral y fuerzas de cizallamiento excesivas en rehabilitación de rodilla de cadena abierta.
- Ruta 1: Clínica y Profesiones de la Salud (K.L., 48).
- Reto: Exhibiendo estrés patelofemoral y fuerzas de cizallamiento excesivas en rehabilitación de rodilla de cadena abierta.
- Análisis Biomecánico y Tisular: Normas de PAGA 2018 y Torque: Según las normas de seguridad de PAGA 2018, la prescripción debe priorizar la integridad articular cambiando de movimientos de cadena abierta de alto cizallamiento a ejercicios de cadena cerrada que promuevan estabilidad compresiva. Minimizar brazos de momento desfavorables protege el cartílago articular.
- Normas de PAGA 2018 y Torque: Según las normas de seguridad de PAGA 2018, la prescripción debe priorizar la integridad articular cambiando de movimientos de cadena abierta de alto cizallamiento a ejercicios de cadena cerrada que promuevan estabilidad compresiva.
- Minimizar brazos de momento desfavorables protege el cartílago articular.
- Mi estrategia biomecánica para K.L.: "Transicionar de extensiones de rodilla en cadena abierta a prensas de pierna controladas y minisentadillas en cadena cerrada para distribuir las fuerzas articulares y minimizar los picos de estrés patelofemoral."
- "Transicionar de extensiones de rodilla en cadena abierta a prensas de pierna controladas y minisentadillas en cadena cerrada para distribuir las fuerzas articulares y minimizar los picos de estrés patelofemoral."
- Mi Frase Inolvidable de Coaching: EN: "Optimizing joint torque mechanics and transitioning to closed-chain kinetic exercises protects articular cartilage and mitigates orthopedic stress!" ES: "¡Optimizar la mecánica del torque articular y hacer la transición a ejercicios cinéticos de cadena cerrada protege el cartílago articular y mitiga el estrés ortopédico!"
- EN: "Optimizing joint torque mechanics and transitioning to closed-chain kinetic exercises protects articular cartilage and mitigates orthopedic stress!"
- ES: "¡Optimizar la mecánica del torque articular y hacer la transición a ejercicios cinéticos de cadena cerrada protege el cartílago articular y mitiga el estrés ortopédico!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M13_Quiz_Sprint.pdf
KIN-101 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 13)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 13)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
