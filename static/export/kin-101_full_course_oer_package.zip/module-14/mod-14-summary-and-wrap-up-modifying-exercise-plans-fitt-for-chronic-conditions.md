## KIN-101: Mod 14 Summary And Wrap Up Modifying Exercise Plans Fitt For Chronic Conditions

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 14 Summary & Wrap-Up: Modifying Exercise Plans (FITT) for Chronic Conditions


### Special Populations Clinical Field Audits & Advanced FITT Modifications


### Congratulations on Completing Module 14!

You have successfully audited the clinical presentation patterns, physiological risk factors, and advanced FITT modification protocols required when designing exercise programs for special populations. This week, you analyzed pre-participation health screening, chronic disease pathophysiology, and symptom-limited intensity monitoring, examined how systematic FITT adjustments protect vulnerable cohorts, and explored how federal safety mandates in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) mandate safe, equitable physical activity access.

By integrating structured clinical audit workflows, risk stratification strategies, and evidence-based FITT modifications, you are prepared to manage chronic disease risks and optimize functional autonomy across clinical rehabilitation, community wellness, and athletic re-conditioning settings.


### Clinical Framing Protocol (Pattern / Rule / Solve) Synthesis: Key Takeaways

- Pattern (Clinical Pathology): Chronic metabolic and cardiovascular conditions alter acute and chronic exercise tolerance, requiring careful evaluation of hemodynamic responses and functional limitations.
- Rule (PAGA 2018 Safety Standards): Federal safety guidelines mandate that adults with chronic conditions avoid complete inactivity and follow structured, symptom-limited exercise progressions.
- Solve (FITT Customization): Implement accumulated aerobic bouts, RPE-regulated intensity monitoring, and low-impact modality selections paired with bilingual cueing to ensure safe, therapeutic outcomes.

### Module 14 Knowledge Check

Click on each question below to check your understanding of clinical field audits, risk stratification, and advanced FITT modifications:

English Response: To identify known cardiovascular, metabolic, or renal disease symptoms, evaluate risk status, and determine the need for medical clearance prior to exercise participation.

Respuesta en Español: Identificar síntomas de enfermedad cardiovascular, metabólica o renal, evaluar el estado de riesgo y determinar la necesidad de autorización médica.

English Response: They optimize postprandial glycemic control and manage chronic fatigue without triggering excessive cardiovascular or orthopedic strain.

Respuesta en Español: Optimizan el control glucémico posprandial y manejan la fatiga crónica sin desencadenar un esfuerzo cardiovascular u ortopédico excesivo.

English Response: Beta-blockers blunt heart rate responses to exertion, making standard age-predicted heart rate max formulas inaccurate and necessitating the use of RPE scales.

Respuesta en Español: Atenúan la respuesta de la frecuencia cardíaca al esfuerzo, haciendo inexactas las fórmulas estándar y requiriendo el uso de escalas RPE.

English Response: It establishes that some physical activity is better than none, encouraging regular light movement tailored to individual functional abilities.

Respuesta en Español: Establece que algo de actividad física es mejor que nada, fomentando el movimiento ligero regular adaptado a las capacidades funcionales.

English Response: Clinical conditions or acute symptoms (e.g., unstable angina, acute pulmonary embolism) that prohibit participation in structured exercise due to high medical risk.

Respuesta en Español: Condiciones clínicas o síntomas agudos que prohíben la participación en ejercicio estructurado debido a un alto riesgo médico.

English Response: Prioritizing low-impact, weight-supported modalities (e.g., water aerobics, recumbent cycling) protects vulnerable articular cartilage and minimizes fall risks.

Respuesta en Español: Priorizar modalidades de bajo impacto y soporte de peso protege el cartílago articular vulnerable y minimiza el riesgo de caídas.

English Response: Enclosing clinical case profiles within triple-hash delimiters (`###`) ensures zero-trust data boundary isolation and precise SSoT compliance.

Respuesta en Español: Encerrar los perfiles de casos clínicos entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos y el cumplimiento de SSoT.

English Response: It safely manages tissue healing constraints and asymmetrical force output by gradually reintroducing mechanical load and sport-specific agility.

Respuesta en Español: Maneja de manera segura las restricciones de curación tisular reintroduciendo gradualmente la carga mecánica y la agilidad.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición).


### Workplace Intelligence & Clinical Informatics Competency


### Workplace Intelligence & Clinical Informatics Competency

In this Module, you practiced advanced workforce competencies that translate directly to modern clinical, educational, and athletic training environments:

You deployed the Safety Auditor protocol ( ### ) to prevent prompt drift and simulate secure electronic health record (EHR) data partitioning during clinical case audits.

You acted as the primary clinical authority, stress-testing AI-generated FITT prescriptions against federal PAGA 2018 standards to eliminate unverified fitness myths.

You engineered bilingual coaching cues in English and Norteño Spanish to bridge communication gaps for diverse borderland patient populations.

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 15 — Capstone Synthesis & Professional Roadmaps

In plain English, next week in Module 15: Capstone Synthesis & Professional Roadmaps you will bring together all the kinesiology, biomechanics, physiology, and PAGA 2018 skills from the semester to map out your 5-year academic and career timeline. Why it matters: Module 15 prepares your professional roadmap and polishes your clinical reasoning right before your final Module 16 portfolio defense.

- Pattern (Context): Synthesizing your semester clinical audits and aligning your AWC coursework with university transfer or national certification goals.
- Rule (Constraint): Verifying full compliance with PAGA 2018 , legal Scope of Practice, and the Clinical Framing Protocol (Pattern / Rule / Solve) .
- Solve (Intervention): Completing Mod 15 Discussion: 5-Year Career & Transfer Plan and Mod 15 Lab: Integrated Kinesiology Case Study .
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 14 (Mod 14 Summary & Wrap-Up: Modifying Exercise Plans (FITT) for Chronic Conditions)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility

English: All wrap-up materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are fully mobile-responsive and screen-reader compatible.

Español: Todos los materiales de cierre en KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 14 Resumen y Cierre


### ¡Felicidades por completar el Módulo 14!

Ha auditado con éxito los patrones de presentación clínica, los factores de riesgo fisiológico y los protocolos de modificación FITT necesarios al diseñar programas para poblaciones especiales. Esta semana analizó el tamizaje preparticipación, la fisiopatología de enfermedades crónicas y el monitoreo de intensidad limitado por síntomas, examinó cómo los ajustes FITT protegen a cohortes vulnerables y exploró cómo las pautas federales en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) exigen un acceso equitativo.

Al integrar flujos de trabajo de auditoría clínica, estrategias de estratificación de riesgo y modificaciones FITT basadas en evidencia, está preparado para manejar riesgos de enfermedades crónicas en su práctica profesional.


### Síntesis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Puntos Clave

- Patrón (Patología Clínica): Las condiciones metabólicas y cardiovasculares crónicas alteran la tolerancia al ejercicio, requiriendo una evaluación cuidadosa de las respuestas hemodinámicas.
- Regla (Normas PAGA 2018): Las pautas federales exigen que los adultos con condiciones crónicas eviten la inactividad total y sigan progresiones de ejercicio limitadas por síntomas.
- Solución (Personalización FITT): Aplicar bouts aeróbicos acumulados, monitoreo de intensidad regulado por RPE y selección de modalidades de bajo impacto junto con señales bilingües.

#### Inteligencia en el Entorno Laboral e Informática Clínica

En este módulo demostró su preparación profesional al utilizar la IA generativa (Google Gemini) como socio en el análisis clínico. Practicó competencias clave:

- Aislamiento de Datos Zero-Trust: Desplegó el protocolo del Auditor de Seguridad ( ### ) para simular el particionamiento seguro de registros electrónicos de salud.
- Auditoría Algorítmica SSoT: Actuó como la autoridad clínica primaria, probando prescripciones FITT contra los estándares de PAGA 2018.
- Alfabetización en Salud Equitativa: Ingenió señales de coaching bilingües en inglés y español norteño para cerrar brechas de comunicación en poblaciones diversas.
PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 15 — Síntesis Capstone y Mapas de Ruta Profesionales

En palabras sencillas (Contexto Norteño): la próxima semana en el Módulo 15 juntarás todas las piezas del semestre (fisiología, biomecánica y guías PAGA 2018) para armar tu plan profesional y universitario a 5 años. Si sientes que es mucha información, concéntrate primero en organizar tus mejores casos clínicos como preparación directa para tu entrega final del Módulo 16.

- Patrón (Contexto): Integrar tus auditorías del semestre y trazar tu ruta de transferencia universitaria o certificación nacional desde AWC.
- Regla (Restricción): Verificar el cumplimiento total de PAGA 2018 y del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) .
- Solución (Intervención): Completar el Foro del Mód 15 (5-Year Career & Transfer Plan) y el Laboratorio del Mód 15 (Integrated Kinesiology Case Study) .
KIN-101 • Module 14 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 14:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 14)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
