## KIN-101: Mod 14 Lab And Simulation 03

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 14) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 14 Lab & Simulation: Modified Exercise Plan (FITT) Audit

Laboratorio del Módulo 14: Simulación de Modificación FITT para Poblaciones Especiales

- FITT-VP Modification Framework for Chronic Conditions: Systematically adjusting Frequency, Intensity, Time, Type, Volume, and Progression (PAGA 2018 Ch. 6) so clients with hypertension, diabetes, or arthritis exercise safely. En palabras sencillas: Adaptar frecuencia, intensidad, tiempo y tipo de ejercicio para que una persona con presión alta, diabetes o dolor articular entrene sin riesgo.
- Joint-Sparing Low-Impact Modalities & Two-Hour Pain Gate: Swapping high-impact running/jumping for aquatic, recumbent cycling, or brisk flat walking so osteoarthritic joint discomfort never worsens 2 hours post-session. En palabras sencillas: Cambiar saltos o impactos fuertes por bici fija, alberca o caminata controlada para cuidar rodillas y caderas sin dejar dolor después.
- Post-Exercise Hypotension & Extended Gradual Cool-Down: Blood pressure drops after aerobic work; clients on blood-pressure medications require a 5–10 minute gradual cool-down to prevent venous pooling and dizziness. En palabras sencillas: Bajar el ritmo poco a poco durante 5 a 10 minutos al terminar para que la sangre no se estanque en las piernas ni dé mareo.

### Clinical Field Audits, Risk Stratification, & Advanced FITT Modifications

In this laboratory assignment, you will conduct a qualitative clinical case audit and construct an evidence-based FITT (Frequency, Intensity, Time, Type) modification protocol for individuals managing chronic conditions. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will analyze clinical presentation patterns and physiological risk factors, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety standards, and execute an AI-driven simulation using Google Gemini.

En esta práctica de laboratorio, realizará una auditoría cualitativa de un caso clínico y diseñará un protocolo de modificación FITT basado en evidencia para personas con condiciones crónicas, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución).

- KIN-101.14.3.AY26-27: Evaluate clinical presentation patterns, risk stratification frameworks, and FITT adjustment parameters across diverse special populations. Evaluar los patrones de presentación clínica, los marcos de estratificación de riesgo y los parámetros de ajuste FITT en poblaciones especiales.
- KIN-101.14.4.AY26-27: Design clinical modification protocols and bilingual coaching cue cards aligned with PAGA 2018 safety standards. Diseñar protocolos de modificación clínica y tarjetas de instrucción bilingües alineadas con las normas de seguridad de PAGA 2018.
- Module Window / Ventana del Módulo: Opens Tuesday, November 17, 2026, at 12:00 AM MST Abre el martes, 17 de noviembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, November 23, 2026, at 11:59 PM MST lunes, 23 de noviembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones prácticas

### Lab Objectives

Objetivos del Laboratorio

- Audit clinical presentation patterns, pathology considerations, and pre-participation screening requirements for special populations. Auditar patrones de presentación clínica, consideraciones patológicas y requisitos de tamizaje preparticipación en poblaciones especiales.
- Apply federal PAGA 2018 (2nd Ed.) safety standards to structure symptom-limited exercise prescriptions that manage chronic disease risks. Aplicar las normas de seguridad de la PAGA 2018 para estructurar prescripciones de ejercicio limitadas por síntomas que controlen riesgos de enfermedades crónicas.
- Formulate a comprehensive FITT modification plan paired with bilingual coaching cue cards in English and Spanish. Formular un plan integral de modificación FITT con tarjetas de instrucción bilingües en inglés y español.
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-14

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos de Auditoría Clínica

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Focus: Cardiometabolic disease management; auditing FITT adjustments for Type 2 diabetes and hypertension.

Focus: Senior wellness programming; designing inclusive adapted physical activity curriculums for mobility-impaired cohorts.

Focus: Post-surgical athletic re-conditioning; managing modified load parameters for returning collegiate athletes.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete clinical audit directly into the Canvas text box structured under the following headers:

- Selected Track & Client/Patient Details: Declare chosen track and baseline clinical profile.
- Part 1: Pattern Recognition: Identify specific clinical pathology patterns, risk factors, or functional limitations.
- Part 2: Rule Application: Cite PAGA 2018 safety standards and risk stratification principles.
- Part 3: Solving the Gap: Detail a modified FITT prescription (Frequency, Intensity, Time, Type) with a 2-sentence bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition (Detección de Patrones): Patient R.G. exhibits insulin resistance, mild hypertension, and a blunted heart rate response to exertion associated with Type 2 diabetes, requiring careful glycemic and blood pressure monitoring.

Part 2: Rule Application (SSoT PAGA 2018 Safety Standards): Under PAGA 2018 (2nd Ed.) guidelines, exercise prescriptions for chronic metabolic conditions must prioritize consistency and glycemic control by avoiding sudden high-intensity spikes and utilizing symptom-limited RPE monitoring.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): Modified Clinical FITT Prescription (Type 2 Diabetes & Hypertension): Key Point — Frequency: 3 to 5 days per week of aerobic exercise, plus 2 non-consecutive days of resistance training. Key Point — Intensity: Moderate intensity (RPE 11 to 13 on a 6-20 scale), ensuring conversational speech. Key Point — Time: Accumulated 30 minutes daily, broken into three 10-minute bouts to optimize postprandial glucose disposal. Key Point — Type: Low-impact aerobic modalities (recumbent cycling, brisk walking) and machine-based resistance training.

EN: "Customizing FITT parameters and monitoring symptom-limited intensity empowers individuals with chronic conditions to exercise safely and effectively."

ES: "Personalizar los parámetros FITT y monitorear la intensidad limitada por síntomas capacita a las personas con condiciones crónicas para ejercitarse con seguridad."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_101_M14_Special_Populations_Simulation.pdf

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 14 (Mod 14 Lab: Modified Exercise Plan (FITT) Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 14 Práctica de Lab y Simulación: Simulación de Modificación FITT

Auditorías Clínicas, Estratificación de Riesgo y Modificaciones FITT Avanzadas


### Auditorías Clínicas, Estratificación de Riesgo y Modificaciones FITT Avanzadas

En esta práctica de laboratorio, realizará una auditoría cualitativa de un caso clínico y diseñará un protocolo de modificación FITT (Frecuencia, Intensidad, Tiempo, Tipo) para personas con condiciones crónicas. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , evaluará patrones clínicos y factores de riesgo, aplicando normas de seguridad de PAGA 2018 (2.ª edición) .


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Enfoque: Manejo de enfermedad cardiometabólica; auditoría de ajustes FITT para diabetes tipo 2 e hipertensión.

Enfoque: Programación de bienestar para adultos mayores; diseño de currículos inclusivos para personas con movilidad limitada.

Enfoque: Reacondicionamiento atlético post-quirúrgico; manejo de parámetros de carga modificados para atletas universitarios.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini


### Estructura de Entrega de Texto


#### Ruta Seleccionada y Detalles del Cliente/Paciente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Educación / Ruta 3 Deportiva) e incluya los detalles del perfil clínico base.


#### Parte 1: Reconocimiento de Patrones

Identifique patrones específicos de patología clínica, factores de riesgo o limitaciones funcionales.


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Cite las normas de seguridad de PAGA 2018 y los principios de estratificación de riesgo.


#### Parte 3: Resolución de la Brecha

Detalle una prescripción FITT modificada (Frecuencia, Intensidad, Tiempo, Tipo), junto con una tarjeta bilingüe.


#### Verificación del repositorio

Confirme el registro de auditoría exportado y archivado en EXW_Professional_AI_Repository .


### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: El paciente R.G. exhibe resistencia a la insulina, hipertensión leve y una respuesta de frecuencia cardíaca atenuada asociada con la diabetes tipo 2, requiriendo un monitoreo cuidadoso de la glucosa y la presión arterial.

Parte 2: Aplicación de Reglas (PAGA 2018): Según las normas de PAGA 2018 (2.ª ed.), las prescripciones para condiciones metabólicas crónicas deben priorizar la consistencia y el control glucémico evitando picos repentinos de alta intensidad y utilizando monitoreo RPE limitado por síntomas.

Parte 3: Resolución de la Brecha: Prescripción FITT clínica modificada: Key Point — Frecuencia: 3 a 5 días por semana de ejercicio aeróbico, más 2 días no consecutivos de entrenamiento de resistencia. Key Point — Intensidad: Intensidad moderada (RPE 11 a 13 en escala de 6-20), asegurando la capacidad de conversar. Key Point — Tiempo: 30 minutos acumulados diarios, divididos en tres bouts de 10 minutos para optimizar la eliminación de glucosa posprandial. Key Point — Tipo: Modalidades aeróbicas de bajo impacto (ciclismo reclinado, caminata rápida) y entrenamiento de resistencia en máquinas. Tarjeta Bilingüe: "Personalizar los parámetros FITT y monitorear la intensidad limitada por síntomas capacita a las personas con condiciones crónicas para ejercitarse con seguridad."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M14_Special_Populations_Simulation.pdf

KIN-101 • Module 14 Quick Return Navigation / Regreso Rápido al Módulo 14:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 14)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
