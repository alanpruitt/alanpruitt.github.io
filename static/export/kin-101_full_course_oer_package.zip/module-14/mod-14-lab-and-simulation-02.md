## KIN-101: Mod 14 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 14) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 14 Coaching Sprint Simulation: Adjusting Workouts for Chronic Conditions

Sesión de Coaching del Módulo 14: Auditorías Clínicas y Modificaciones Frequency, Intensity, Time, Type (FITT) principle

- FITT-VP Modification Framework for Chronic Conditions: Systematically adjusting Frequency, Intensity, Time, Type, Volume, and Progression (PAGA 2018 Ch. 6) so clients with hypertension, diabetes, or arthritis exercise safely. En palabras sencillas: Adaptar frecuencia, intensidad, tiempo y tipo de ejercicio para que una persona con presión alta, diabetes o dolor articular entrene sin riesgo.
- Joint-Sparing Low-Impact Modalities & Two-Hour Pain Gate: Swapping high-impact running/jumping for aquatic, recumbent cycling, or brisk flat walking so osteoarthritic joint discomfort never worsens 2 hours post-session. En palabras sencillas: Cambiar saltos o impactos fuertes por bici fija, alberca o caminata controlada para cuidar rodillas y caderas sin dejar dolor después.
- Post-Exercise Hypotension & Extended Gradual Cool-Down: Blood pressure drops after aerobic work; clients on blood-pressure medications require a 5–10 minute gradual cool-down to prevent venous pooling and dizziness. En palabras sencillas: Bajar el ritmo poco a poco durante 5 a 10 minutos al terminar para que la sangre no se estanque en las piernas ni dé mareo.
- KIN-101.14.1.AY26-27: Audit clinical presentation patterns, physiological risk factors, and functional limitations across career-aligned special population tracks. Auditar patrones de presentación clínica, factores de riesgo fisiológico y limitaciones funcionales en poblaciones especiales.
- KIN-101.14.2.AY26-27: Apply PAGA 2018 safety standards and FITT modification protocols to structure therapeutic, injury-mitigating exercise interventions. Aplicar las normas de seguridad de la PAGA 2018 y protocolos de modificación FITT para estructurar intervenciones terapéuticas.

### Your Weekly Win: Mastering Special Populations FITT Modifications

How does analyzing chronic metabolic conditions and cardiovascular risks empower practitioners to adapt exercise prescriptions safely? Examining clinical pathology, risk stratification, and symptom-limited intensity monitoring allows exercise leaders to design safe, therapeutic remediation protocols. Following federal PAGA 2018 standards, professionals can structure evidence-based interventions tailored to diverse clinical, educational, and athletic pathways. Choose your coaching track below, chat with your AI Socratic Coach, and master special populations clinical audits!

¿Cómo ayuda el análisis de condiciones metabólicas crónicas a los profesionales a adaptar prescripciones de ejercicio con seguridad? Examinar la patología clínica y la estratificación de riesgo permite diseñar protocolos terapéuticos. ¡Elija su ruta y dialogue con su coach de IA!

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: 3-Track Chronic Condition FITT-VP & Heat Safety Calibrator (/simulators/cyoj-module11) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate modified aerobic volume, low-load resistance frequency (>=2 days/week), balance dosing, and KNYL heat-flag thresholds for clients with chronic conditions (PAGA 2018 Ch. 6). Copy your VERIFIED simulator receipt or slider values into the submission template below.

Open 3-Track Chronic Condition FITT-VP & Heat Safety Calibrator in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/cyoj-module11 y "PAGA"): Calibre el volumen aeróbico modificado, fuerza de bajo impacto (>=2 días/semana), equilibrio y alertas de calor KNYL para clientes con condiciones crónicas (PAGA 2018 Cap. 6). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Scenario: Adult patient with controlled Type 2 diabetes and hypertension seeking structured cardiovascular and resistance training clearance.

Scenario: Community center wellness coordinator designing an inclusive adapted physical activity program for seniors with limited mobility.

Scenario: Collegiate athlete returning from a major knee ligament reconstruction requiring modified periodization.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission / Fase 3: Entrega en Canvas (Solo Texto)

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's clinical pathology or functional limitation.
- Clinical & FITT Analysis: Explain risk stratification, symptom-limited intensity, and PAGA 2018 safety standards for your client.
- My Clinical Modification Strategy: Provide 1 clear, evidence-based FITT adjustment (Frequency, Intensity, Time, or Type).
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 14 Coaching Sprint • Track 1 (Clinical & Allied Health Path)

- Chosen Track & Client: Track 1: Clinical & Allied Health Path (R.G., 55). Challenge: Managing controlled Type 2 diabetes and hypertension requiring safe aerobic and resistance training FITT adjustments.
- Track 1: Clinical & Allied Health Path (R.G., 55).
- Challenge: Managing controlled Type 2 diabetes and hypertension requiring safe aerobic and resistance training FITT adjustments.
- Clinical & FITT Analysis: PAGA 2018 Standards & Risk Stratification: Under PAGA 2018 (2nd Ed.) guidelines, exercise prescriptions for metabolic conditions must prioritize glycemic control and cardiovascular safety by utilizing RPE-based intensity monitoring and avoiding sudden high-intensity spikes. Accumulating bouts prevents excessive post-exercise fatigue.
- PAGA 2018 Standards & Risk Stratification: Under PAGA 2018 (2nd Ed.) guidelines, exercise prescriptions for metabolic conditions must prioritize glycemic control and cardiovascular safety by utilizing RPE-based intensity monitoring and avoiding sudden high-intensity spikes.
- Accumulating bouts prevents excessive post-exercise fatigue.
- My Clinical Modification Strategy for R.G.: "Implement accumulated aerobic bouts (three 10-minute daily walks) and RPE-regulated resistance training (RPE 11-13) to enhance insulin sensitivity safely without triggering hypertensive responses."
- "Implement accumulated aerobic bouts (three 10-minute daily walks) and RPE-regulated resistance training (RPE 11-13) to enhance insulin sensitivity safely without triggering hypertensive responses."
- My Memorable Coaching Takeaway: EN: "Customizing FITT parameters and monitoring symptom-limited intensity empowers individuals with chronic conditions to exercise safely and effectively!" ES: "¡Personalizar los parámetros FITT y monitorear la intensidad limitada por síntomas capacita a las personas con condiciones crónicas para ejercitarse con seguridad!"
- EN: "Customizing FITT parameters and monitoring symptom-limited intensity empowers individuals with chronic conditions to exercise safely and effectively!"
- ES: "¡Personalizar los parámetros FITT y monitorear la intensidad limitada por síntomas capacita a las personas con condiciones crónicas para ejercitarse con seguridad!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M14_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 14 (Mod 14 Coaching Sprint: Adjusting Workouts for Chronic Conditions)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 14 Simulación de Coaching: Auditorías Clínicas

Evaluación Rápida y Modificaciones FITT Avanzadas


### Su Logro Semanal: Dominando las Modificaciones FITT para Poblaciones Especiales

Esta sesión le permitirá aplicar los estándares de PAGA 2018 y los principios de modificación clínica para analizar patologías y estructurar estrategias de ejercicio adaptado. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Paciente adulto con diabetes tipo 2 controlada e hipertensión requiriendo autorización y ajustes FITT.

Escenario: Coordinador de centro comunitario diseñando un programa inclusivo para adultos mayores con movilidad limitada.

Escenario: Atleta universitario retornando de una reconstrucción de ligamento de rodilla con periodización modificada.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y la patología clínica o limitación funcional de su cliente.
- Análisis Clínico y FITT: Explique la estratificación de riesgo, la intensidad limitada por síntomas y las normas de PAGA 2018 para su cliente.
- Mi Estrategia de Modificación Clínica: Escriba 1 ajuste FITT basado en evidencia (Frecuencia, Intensidad, Tiempo o Tipo).
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 14 Sesión de Coaching • Ruta 1 (Clínica / R.G.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Profesiones de la Salud (R.G., 55). Reto: Manejando diabetes tipo 2 e hipertensión controladas, requiriendo ajustes FITT seguros para aeróbico y resistencia.
- Ruta 1: Clínica y Profesiones de la Salud (R.G., 55).
- Reto: Manejando diabetes tipo 2 e hipertensión controladas, requiriendo ajustes FITT seguros para aeróbico y resistencia.
- Análisis Clínico y FITT: Normas de PAGA 2018 y Estratificación: Según las normas de PAGA 2018, la prescripción para condiciones metabólicas debe priorizar el control glucémico y la seguridad cardiovascular utilizando monitoreo de RPE y evitando picos de alta intensidad. Los bouts acumulados previenen la fatiga excesiva post-ejercicio.
- Normas de PAGA 2018 y Estratificación: Según las normas de PAGA 2018, la prescripción para condiciones metabólicas debe priorizar el control glucémico y la seguridad cardiovascular utilizando monitoreo de RPE y evitando picos de alta intensidad.
- Los bouts acumulados previenen la fatiga excesiva post-ejercicio.
- Mi estrategia de modificación clínica para R.G.: "Implementar bouts aeróbicos acumulados (tres caminatas diarias de 10 minutos) y entrenamiento de resistencia regulado por RPE (RPE 11-13) para mejorar la sensibilidad a la insulina sin provocar respuestas hipertensivas."
- "Implementar bouts aeróbicos acumulados (tres caminatas diarias de 10 minutos) y entrenamiento de resistencia regulado por RPE (RPE 11-13) para mejorar la sensibilidad a la insulina sin provocar respuestas hipertensivas."
- Mi Frase Inolvidable de Coaching: EN: "Customizing FITT parameters and monitoring symptom-limited intensity empowers individuals with chronic conditions to exercise safely and effectively!" ES: "¡Personalizar los parámetros FITT y monitorear la intensidad limitada por síntomas capacita a las personas con condiciones crónicas para ejercitarse con seguridad!"
- EN: "Customizing FITT parameters and monitoring symptom-limited intensity empowers individuals with chronic conditions to exercise safely and effectively!"
- ES: "¡Personalizar los parámetros FITT y monitorear la intensidad limitada por síntomas capacita a las personas con condiciones crónicas para ejercitarse con seguridad!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M14_Quiz_Sprint.pdf
KIN-101 • Module 14 Quick Return Navigation / Regreso Rápido al Módulo 14:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 14)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 14)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
