## KIN-101: Mod 09 Required Readings Cardiorespiratory Fitness And Safe Cardio

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 09 Required Readings: Cardiorespiratory Fitness & Safe Cardio


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Cardiorespiratory fitness is simply how efficiently your heart, lungs, and muscles work together as a team. When you exercise regularly, your heart gets stronger so it pumps more blood with fewer beats, and your muscles get better at pulling oxygen out of that blood. That teamwork is what keeps your energy high and protects your long-term health.


#### En Palabras Sencillas (Norteño Context)

Piensa en tu sistema cardiorespiratorio como el motor de un carro: entre mejor mantenimiento le des con el ejercicio aeróbico, más distancia recorres sin cansarte. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo se adapta al esfuerzo.

This week's literature explores the physiological cardiorespiratory adaptations that occur in response to systematic aerobic endurance training. By examining maximal oxygen uptake, central hemodynamics, and energy substrate utilization, we uncover how the cardiovascular and respiratory systems supply active skeletal muscle during prolonged physical exertion.

Anchored in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , these readings emphasize that regular aerobic conditioning is vital for reducing all-cause mortality, preventing chronic cardiovascular disease, and enhancing metabolic health across diverse clinical, educational, and athletic environments.


### 1. Cardiovascular Dynamics: Stroke Volume, Cardiac Output & VO2max

Maximal oxygen uptake represents the functional capacity of the cardiorespiratory system to transport and utilize oxygen during maximal effort. It is governed by the Fick equation, uniting central hemodynamics and peripheral extraction:

- Cardiac Output (Q): The total volume of blood pumped by the heart per minute, calculated as heart rate multiplied by stroke volume. Endurance training expands left ventricular chamber size and myocardial contractility, significantly increasing maximal stroke volume.
- Arteriovenous Oxygen Difference (a-v O2 diff): The measure of how much oxygen is extracted by working skeletal muscles from arterial blood. Aerobic conditioning increases capillary density and mitochondrial enzyme concentrations, enhancing peripheral extraction efficiency.
- Cardiorespiratory Adaptations: Regular aerobic training decreases resting heart rate through enhanced parasympathetic tone while maximizing oxygen delivery to active tissues.

### 2. Prescription Design: The FITT Principles of Aerobic Training

Translating cardiorespiratory science into safe, effective exercise programming relies on manipulating the core variables of training prescription:

Prescribing cardiorespiratory exercise requires establishing training Frequency (sessions per week), Intensity (percentage of heart rate reserve or VO2max), Time (duration of continuous or interval exertion), and Type (rhythmic, continuous large muscle group movements). Balancing these variables ensures progressive overload while preventing musculoskeletal overuse injuries and excessive cardiovascular strain.


### 3. Lifespan Aerobic Health & Federal PAGA 2018 Alignment

Maintaining cardiovascular fitness across the lifespan is essential for preserving metabolic homeostasis and physical independence. The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) mandate that adults accumulate at least 150 to 300 minutes of moderate-intensity aerobic physical activity (or 75 to 150 minutes of vigorous-intensity aerobic activity) weekly to optimize cardiorespiratory health and mitigate chronic disease risks.


### Workplace Intelligence & AI Security Protocol ()

When utilizing generative AI tools like Google Gemini for cardiorespiratory prescription audits and FITT calculation checks, professionals must enclose all client profile data and testing metrics within triple-hash delimiters:


```text
Cardiorespiratory Prescription Audit: Cardiac Rehabilitation Participant ###:
Client Profile: 54-year-old post-myocardial infarction participant seeking aerobic reconditioning.
Task: Audit heart rate reserve parameters, calculate target training zones, and align with PAGA 2018.
End Case ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Required Readings: Cardiorespiratory Fitness & Safe Cardio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Lecturas en Línea: Aptitud Cardiorespiratoria y Acondicionamiento Aeróbico

La literatura de esta semana explora las adaptaciones fisiológicas cardiorespiratorias que ocurren como respuesta al entrenamiento sistemático de resistencia aeróbica. Al examinar el consumo máximo de oxígeno, la hemodinámica central y la utilización de sustratos energéticos, descubrimos cómo los sistemas cardiovascular y respiratorio suministran oxígeno al músculo esquelético activo durante el ejercicio prolongado.

Fundamentadas en las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) , estas lecturas enfatizan que el acondicionamiento aeróbico regular es vital para reducir la mortalidad por todas las causas y mejorar la salud metabólica.


### 1. Dinámica Cardiovascular: Volumen Sistólico, Gasto Cardíaco y VO2max

- Gasto Cardíaco (Q): Volumen total de sangre bombeado por el corazón por minuto, calculado multiplicando la frecuencia cardíaca por el volumen sistólico.
- Diferencia Arteriovenosa de Oxígeno (a-v O2 diff): Medida de cuánto oxígeno extraen los músculos activos de la sangre arterial; el entrenamiento aeróbico incrementa la densidad capilar.
- Adaptaciones Cardiorespiratorias: El entrenamiento aeróbico regular disminuye la frecuencia cardíaca en reposo mediante un mayor tono parasimpático.

### 2. Diseño de Prescripción: Los Principios FITT del Entrenamiento Aeróbico

Traducir la ciencia cardiorespiratoria en programas seguros y efectivos se basa en manipular las variables clave de la prescripción:

La prescripción requiere establecer la Frecuencia (sesiones semanales), la Intensidad (% de la reserva de frecuencia cardíaca), el Tiempo (duración) y el Tipo (movimientos rítmicos de grandes grupos musculares).


### 3. Salud Aeróbica y Alineación con PAGA 2018

Mantener la condición cardiovascular a lo largo de la vida es esencial. Las pautas de la PAGA 2018 (2.ª ed.) exigen que los adultos acumulen de 150 a 300 minutos de actividad aeróbica de intensidad moderada (o de 75 a 150 minutos de intensidad vigorosa) semanalmente para optimizar la salud cardiorespiratoria.

KIN-101 • Module 09 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 09)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
