## KIN-101 (Module 09 Overview): Concepts of Kinesiology: Foundational Movement & Physical Activity

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 09 Overview: Cardiorespiratory Fitness & Safe Cardio


### Welcome to Module 09: Cardiorespiratory Fitness & Safe Cardio

Welcome to Week 9! This week, we examine the physiological cardiorespiratory adaptations to endurance training. We explore the mechanics of maximal oxygen uptake (VO2max), stroke volume, cardiac output, and how to program aerobic exercise using frequency, intensity, time, and type (FITT) principles.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will audit aerobic conditioning patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) cardiorespiratory standards, and design individualized conditioning programs tailored to your career track.


### In Plain English: Module 09 Navigation

Welcome to the second half of the semester! Based on your fantastic midterm feedback requesting simpler, more natural explanations, we've added these conversational breakdowns across Modules 09–16. Think of Module 09 as shifting our focus from the broad "why" of physical activity to the specific "how" inside your heart, lungs, and blood vessels.


#### En Palabras Sencillas (Norteño Context)

Bienvenidos al Módulo 09. Si los términos técnicos se ponen pesados esta semana, revisa este resumen para conectar los puntos más rápido y entender cómo el cuerpo se adapta al esfuerzo aeróbico.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 13, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 15, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 18, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 19, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 09 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze cardiorespiratory physiological responses and aerobic conditioning adaptations across diverse populations. Analizar las respuestas fisiológicas cardiorespiratorias y las adaptaciones al acondicionamiento aeróbico.
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) aerobic physical activity standards and FITT principles to structure progressive conditioning programs. Aplicar las normas aeróbicas de la PAGA 2018 y los principios FITT para estructurar programas progresivos.
- CLO 3 (Problem Solving): Formulate an evidence-based cardiorespiratory conditioning plan tailored to clinical, educational, or athletic coaching tracks. Formular un plan de acondicionamiento cardiorespiratorio basado en evidencia adaptado a diferentes rutas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will continue working within your chosen career track:

Cardiac rehabilitation programming, VO2peak testing metrics, and graded exercise prescriptions for chronic disease management.

Youth aerobic fitness testing, school-based heart rate monitoring, and community walking programs for metabolic health.

High-intensity interval training (HIIT) prescription, lactate threshold profiling, and aerobic power periodization for endurance sports.


### Module 09 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Cardiorespiratory Adaptations & FITT Principles
- Discussion Board: Aerobic Conditioning vs. Health Outcomes
- Lab Assignment: Cardiorespiratory Prescription Audit & Gemini AI Simulation
- Knowledge Check & Module Summary

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Overview: Cardiorespiratory Fitness & Safe Cardio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 09 Visión General: Aptitud Cardiorespiratoria


### Bienvenido al Módulo 09: Aptitud Cardiorespiratoria, Acondicionamiento Aeróbico y Principios FITT

¡Bienvenido a la Semana 9! Esta semana examinaremos las adaptaciones fisiológicas cardiorespiratorias al entrenamiento de resistencia. Exploraremos la mecánica del consumo máximo de oxígeno (VO2max), el volumen sistólico, el gasto cardíaco y cómo programar el ejercicio aeróbico usando los principios FITT (frecuencia, intensidad, tiempo y tipo).

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , auditarás los patrones de acondicionamiento aeróbico, aplicarás las normas federales de PAGA 2018 (2.ª ed.) y diseñarás programas de acondicionamiento adaptados a tu ruta profesional.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar las respuestas fisiológicas cardiorespiratorias y las adaptaciones al acondicionamiento aeróbico en diversas poblaciones. Analyze cardiorespiratory physiological responses and aerobic conditioning adaptations.
- CLO 2 (Regla): Aplicar las normas de actividad física aeróbica de la PAGA 2018 y los principios FITT para estructurar programas de acondicionamiento progresivos. Apply PAGA 2018 aerobic standards and FITT principles to structure progressive programs.
- CLO 3 (Solución): Formular un plan de acondicionamiento cardiorespiratorio basado en evidencia adaptado a rutas clínicas, educativas o

### Module 09 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 09 Required Readings: Cardiorespiratory Fitness & Safe Cardio →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 09 Discussion: Heart Health & Aerobic Exercise Benefits →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 09 Coaching Sprint: Setting Safe Cardio Intensity →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 09 Lab: Weekly Cardio Plan & Safety Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 09 Summary & Wrap-Up: Cardiorespiratory Fitness & Safe Cardio →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 09)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
