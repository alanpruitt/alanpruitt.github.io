## KIN-101: Mod 09 Summary And Wrap Up Cardiorespiratory Fitness And Safe Cardio

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education


## Mod 09 Summary & Wrap-Up: Cardiorespiratory Fitness & Safe Cardio


### Congratulations on Completing Module 09!

You have successfully audited the cardiorespiratory physiological adaptations and Frequency, Intensity, Time, Type (FITT) prescription principles governing aerobic conditioning across the lifespan. This week, you analyzed maximal oxygen uptake (VO2max), stroke volume, and cardiac output, examined how frequency, intensity, time, and type dictate endurance capacity, and explored how federal mandates in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) require progressive aerobic conditioning to support cardiovascular health.

By integrating structured FITT parameters, thermal safety protocols for Yuma County's desert climate, and evidence-based aerobic prescriptions, you are prepared to optimize cardiovascular conditioning and health outcomes across clinical rehabilitation, physical education, and athletic coaching settings.


### Clinical Framing Protocol Synthesis: Module 09 Key Takeaways

- Pattern (Cardiorespiratory Mechanisms): Endurance training drives central hemodynamic adaptations, expanding left ventricular chamber size and maximizing stroke volume to elevate maximal oxygen uptake (VO2max).
- Rule (PAGA 2018 Standards): Federal aerobic guidelines require adults to accumulate 150 to 300 minutes of moderate-intensity (or 75 to 150 minutes of vigorous-intensity) aerobic activity weekly to mitigate chronic disease risk and optimize metabolic health.
- Solve (Aerobic Optimization): Implement precise FITT programming paired with thermal safety monitoring and bilingual cueing to ensure safe and effective cardiorespiratory conditioning.

### Module 09 Knowledge Check (Self-Check Review)

Click on each question below to check your understanding of cardiorespiratory fitness, FITT principles, and aerobic adaptations:

English Response: An increase in maximal stroke volume resulting from expanded left ventricular chamber size and enhanced myocardial contractility.

Respuesta en Español: Un incremento en el volumen sistólico máximo resultante de la expansión del tamaño de la cavidad ventricular izquierda y una mayor contractilidad miocárdica.

English Response: Frequency (sessions per week), Intensity (exertion level via heart rate reserve or RPE), Time (duration of continuous or interval exertion), and Type (rhythmic, continuous large muscle group activities).

Respuesta en Español: Frecuencia (sesiones por semana), Intensidad (nivel de esfuerzo mediante reserva de frecuencia cardíaca o RPE), Tiempo (duración) y Tipo (actividades rítmicas de grandes grupos musculares).

English Response: 150 to 300 minutes of moderate-intensity aerobic activity, or 75 to 150 minutes of vigorous-intensity aerobic activity, spread throughout the week.

Respuesta en Español: De 150 a 300 minutos de actividad aeróbica de intensidad moderada, o de 75 a 150 minutos de actividad aeróbica de intensidad vigorosa, distribuidos a lo largo de la semana.

English Response: The Fick equation states that VO2max is equal to the product of maximal cardiac output (Q) and the difference in oxygen content between arterial and venous blood (a-v O2 difference).

Respuesta en Español: La ecuación de Fick establece que el VO2max es igual al producto del gasto cardíaco máximo (Q) y la diferencia de oxígeno entre la sangre arterial y venosa (diferencia a-v de O2).

English Response: Extreme ambient heat accelerates dehydration and cardiovascular strain (cardiovascular drift), increasing exertional heat illness risks and making indoor climate-controlled facilities vital for safety.

Respuesta en Español: El calor ambiental extremo acelera la deshidratación y la tensión cardiovascular (deriva cardiovascular), elevando el riesgo de enfermedades por calor y haciendo vitales las instalaciones climatizadas.

English Response: Enclosing clinical case data within triple-hash delimiters (`###`) ensures clean data boundary isolation, prevents prompt drift, and maintains precise alignment with PAGA 2018 guidelines.

Respuesta en Español: Encapitular los datos de casos clínicos entre delimitadores de tres numerales (`###`) asegura el aislamiento de datos, previene la deriva y mantiene la alineación con PAGA 2018.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth for all activity mandates.

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal para todas las normas de actividad física.

English Response: Regular aerobic training decreases resting heart rate through enhanced parasympathetic (vagal) tone and increased stroke volume efficiency.

Respuesta en Español: El entrenamiento aeróbico regular disminuye la frecuencia cardíaca en reposo mediante un mayor tono parasimpático (vagal) y una mayor eficiencia del volumen sistólico.

English Response: A cool-down promotes continued skeletal muscle pump activity, preventing venous pooling in the lower extremities and supporting safe blood pressure and heart rate recovery.

Respuesta en Español: Un enfriamiento promueve la actividad continua de la bomba muscular esquelética, previniendo la acumulación venosa en las extremidades inferiores y apoyando una recuperación segura.


### Workplace Intelligence & AI Skills Competency Audit

In this Module, you demonstrated professional workforce readiness by leveraging Generative AI (Google Gemini) as a partner for cardiorespiratory analysis. You practiced key workplace AI competencies that directly translate to modern physical education, athletic training, and allied health environments:

You strictly enclosed cardiorespiratory case profiles within triple-hash ( ### ) delimiters, simulating secure clinical data handling and modular prompt engineering standards.

You cross-examined AI-generated aerobic prescriptions against federal SSoT standards (PAGA 2018), auditing for correct FITT parameter calculations and hemodynamic safety.

You directed the AI to generate culturally and linguistically accessible 2-sentence coaching cue cards in English and Spanish to broaden cardiorespiratory literacy for diverse community populations.

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 10 — Body Composition & Energy Balance

In plain English, next week in Module 10: Body Composition & Energy Balance you will learn why the bathroom scale (BMI) does not tell the whole story about health, and how to measure lean muscle mass, waist circumference, and sustainable energy balance. Why it matters: safe coaches protect muscle mass and metabolic health rather than pushing extreme crash diets or unsafe dehydration.

- Pattern (Context): Distinguishing between Body Mass Index (BMI) screening and true body composition (lean muscle mass vs. visceral fat distribution).
- Rule (Constraint): Applying PAGA 2018 energy-expenditure guidelines (often 300+ min/week of moderate activity for weight maintenance) and safe rate-of-loss limits.
- Solve (Intervention): Completing Mod 10 Discussion: BMI vs. Body Composition and Mod 10 Lab: Body Composition & Energy Balance .

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Summary & Wrap-Up: Cardiorespiratory Fitness & Safe Cardio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All wrap-up materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) standards. Layouts are fully mobile-responsive and screen-reader compatible.

Español: Todos los materiales de cierre en KIN-101 cumplen con los principios de UDL y los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 09 Resumen y Cierre del Módulo


### ¡Felicidades por completar el Módulo 09!

Ha auditado con éxito las adaptaciones fisiológicas cardiorespiratorias y los principios de prescripción FITT que rigen el acondicionamiento aeróbico a lo largo de la vida. Esta semana analizó el consumo máximo de oxígeno (VO2max), el volumen sistólico y el gasto cardíaco, examinó cómo la frecuencia, intensidad, tiempo y tipo determinan la capacidad de resistencia, y exploró cómo las pautas federales de PAGA 2018 (2.ª edición) exigen acondicionamiento aeróbico progresivo para respaldar la salud cardiovascular.

Al integrar parámetros FITT estructurados, protocolos de seguridad térmica para el clima desértico del condado de Yuma y prescripciones aeróbicas basadas en evidencia, está preparado para optimizar el acondicionamiento cardiovascular en rehabilitación clínica, educación física y entrenamiento deportivo.


### Síntesis del Protocolo de Encuadre Clínico: Puntos Clave del Módulo 09

- Patrón (Mecanismos Cardiorespiratorios): El entrenamiento de resistencia impulsa adaptaciones hemodinámicas centrales, expandiendo la cavidad ventricular izquierda y maximizando el volumen sistólico para elevar el VO2max.
- Regla (Normas PAGA 2018): Las pautas aeróbicas federales exigen que los adultos acumulen de 150 a 300 minutos de actividad moderada (o de 75 a 150 minutos de actividad vigorosa) semanalmente.
- Solución (Optimización Aeróbica): Aplicar una programación FITT precisa junto con el monitoreo de seguridad térmica y señales bilingües para garantizar un acondicionamiento seguro y efectivo.

#### Inteligencia en el Entorno Laboral y Competencia en IA

En este módulo demostró su preparación profesional al utilizar la IA generativa (Google Gemini) como socio en el análisis cardiorespiratorio. Practicó competencias clave:

- Protocolo de Delimitadores: Encerró los casos cardiorespiratorios entre triples numerales ( ### ) para estructurar datos clínicos y educativos de forma segura.
- Auditoría de IA: Verificó prescripciones aeróbicas contra los estándares de la PAGA 2018 para validar los cálculos FITT y la seguridad hemodinámica.
- Comunicación Bilingüe: Generó tarjetas de instrucción técnica de 2 oraciones, en inglés y en español, para mejorar la alfabetización cardiorespiratoria comunitaria.
PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 10 — Composición Corporal y Balance Energético

En palabras sencillas (Contexto Norteño): la báscula y el IMC (BMI) no saben distinguir entre músculo fuerte y grasa visceral alrededor de la cintura. Si los cálculos metabólicos se ponen pesados la próxima semana, concéntrate primero en cómo proteger la masa muscular del cliente y usar el movimiento constante (PAGA 2018) en lugar de dietas extremas o trajes plásticos para sudar en el calor.

- Patrón (Contexto): Diferenciar el Índice de Masa Corporal (IMC) de la composición corporal real (masa magra frente a tejido adiposo visceral).
- Regla (Restricción): Aplicar las guías de gasto energético de PAGA 2018 y límites seguros sin déficits calóricos peligrosos.
- Solución (Intervención): Completar el Foro del Mód 10 (BMI vs. Body Composition) y el Laboratorio del Mód 10 (Body Composition & Energy Balance) .
KIN-101 • Module 09 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 09)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
