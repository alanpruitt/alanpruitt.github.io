## KIN-101: Mod 09 Lab And Simulation 01

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 09) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Coaching Sprint Simulation: Setting Safe Cardio Intensity

- Heart Rate Reserve (HRR — Karvonen Method): Calculates personalized cardio zones using resting heart rate: Target HR = ((HRmax − HRrest) × %Intensity) + HRrest; moderate intensity = 40–59% HRR. En palabras sencillas: Fórmula que toma en cuenta tu pulso en reposo para calcular con exactitud tu zona segura de cardio moderado (40–59% HRR).
- Talk Test & Borg Rating of Perceived Exertion (RPE 12–13): Validated intensity gauge where moderate aerobic activity allows speaking in full sentences without gasping (Borg RPE 12–13 on the 6–20 scale). En palabras sencillas: La Prueba del Habla: en intensidad moderada debes poder platicar en oraciones completas sin quedarte sin aire (RPE 12 a 13).
- Cardiovascular Drift in High Ambient Heat: Upward creep in heart rate during prolonged exercise in warm conditions due to dehydration and skin vasodilation, requiring pace reduction and cooling. En palabras sencillas: Cuando el pulso se sube de más por el calor de Yuma aunque mantengas el mismo paso; obliga a bajar el ritmo o entrenar bajo techo.
- KIN-101.9.1.AY26-27: Apply PAGA 2018 aerobic guidelines to analyze cardiorespiratory adaptations, stroke volume, and VO2max. Aplicar las pautas aeróbicas de la PAGA 2018 para analizar las adaptaciones cardiorespiratorias, el volumen sist\u00f3lico y el VO2max.
- KIN-101.9.2.AY26-27: Audit Frequency, Intensity, Time, Type (FITT) prescription parameters and conditioning protocols across physical education, clinical rehabilitation, and sports coaching contexts. Auditar los parámetros de prescripci\u00f3n FITT y los protocolos de acondicionamiento en contextos educativos, clínicos y deportivos.

### Your Weekly Win: Mastering Cardiorespiratory Conditioning & FITT Programming

How does understanding cardiorespiratory physiology empower physical educators, therapists, and coaches to enhance metabolic health? Examining maximal oxygen uptake, stroke volume, and cardiac output allows practitioners to optimize endurance capacity and reduce chronic disease risk. Following federal PAGA 2018 aerobic guidelines, exercise leaders can design progressive conditioning programs tailored to diverse populations. Choose your coaching track below, chat with your AI Socratic Coach, and master aerobic prescription analysis!

¿Cómo ayuda la fisiología cardiorespiratoria a educadores, terapeutas y entrenadores a optimizar la salud metabólica? Comprender el VO2max y el gasto cardíaco permite mejorar la resistencia y reducir el riesgo de enfermedades. ¡Elija su ruta y dialogue con su coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Scenario: Cardiac rehabilitation participant (R.K., 58) recovering from a recent myocardial infarction, exhibiting low functional capacity and sedentary VO2max decline.

Scenario: Middle school physical education cohort (Grade 7, Age 12) showing declining participation in continuous moderate aerobic activity.

Scenario: Collegiate cross-country runner (D.L., 20) experiencing VO2max plateaus during preseason high-temperature endurance training blocks.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission / Fase 3: Entrega en Canvas (Solo Texto)

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's cardiorespiratory conditioning challenge.
- Cardiorespiratory & FITT Analysis: Explain VO2max, stroke volume, FITT parameters, and PAGA 2018 aerobic standards for your client.
- Part 3: Active Verification & FITT Adjustment: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your FITT prescription adjustment protects myocardial safety and aligns with PAGA 2018 aerobic guidelines for your chosen client.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 09 Coaching Sprint • Track 1 (Clinical / R.K.)

- Chosen Track & Client: Track 1: Clinical & Allied Health Path (R.K., 58). Challenge: R.K. is recovering from a recent myocardial infarction and exhibits low functional capacity, stroke volume depression, and sedentary VO2max decline.
- Track 1: Clinical & Allied Health Path (R.K., 58).
- Challenge: R.K. is recovering from a recent myocardial infarction and exhibits low functional capacity, stroke volume depression, and sedentary VO2max decline.
- Cardiorespiratory & FITT Analysis: PAGA 2018 Aerobic Guidelines & Hemodynamics: Cardiac rehabilitation requires gradually rebuilding myocardial contractility and peripheral oxygen extraction without inducing cardiac ischemia. PAGA 2018 guidelines recommend 150 minutes of moderate aerobic conditioning weekly, structured via safe FITT parameters. Progressive aerobic overload expands stroke volume and enhances metabolic health safely.
- PAGA 2018 Aerobic Guidelines & Hemodynamics: Cardiac rehabilitation requires gradually rebuilding myocardial contractility and peripheral oxygen extraction without inducing cardiac ischemia. PAGA 2018 guidelines recommend 150 minutes of moderate aerobic conditioning weekly, structured via safe FITT parameters.
- Progressive aerobic overload expands stroke volume and enhances metabolic health safely.
- Part 3: Active Verification & FITT Adjustment: "Implement a FITT prescription of 3 days/week frequency, 40%–50% Heart Rate Reserve intensity (RPE 11–13), 20–30 minutes duration, using low-impact stationary cycling." Active Verification: In my clinical judgment, initiating at 40% HRR provides a vital hemodynamic buffer for R.K. His post-infarct myocardium cannot tolerate rapid blood pressure spikes, and beta-blocker therapy limits chronotropic acceleration. Stationary cycling provides a controlled, low-impact modality that builds stroke volume and peripheral capillary beds while strictly observing PAGA 2018 cardiac safety baselines.
- "Implement a FITT prescription of 3 days/week frequency, 40%–50% Heart Rate Reserve intensity (RPE 11–13), 20–30 minutes duration, using low-impact stationary cycling."
- Active Verification: In my clinical judgment, initiating at 40% HRR provides a vital hemodynamic buffer for R.K. His post-infarct myocardium cannot tolerate rapid blood pressure spikes, and beta-blocker therapy limits chronotropic acceleration. Stationary cycling provides a controlled, low-impact modality that builds stroke volume and peripheral capillary beds while strictly observing PAGA 2018 cardiac safety baselines.
- Part 4: My Memorable Coaching Takeaway: EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!" ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!"
- ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M09_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 09 (Mod 09 Coaching Sprint: Setting Safe Cardio Intensity)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 09 Simulación de Coaching: Aptitud Cardiorespiratoria

Evaluación Rápida y Auditoría de Prescripción Aeróbica


### Su Logro Semanal: Dominando el Acondicionamiento Aeróbico y la Programación FITT

Esta sesión le permitirá aplicar la fisiología cardiorespiratoria y las pautas aeróbicas de PAGA 2018 para analizar el VO2max, el volumen sistólico y estructurar la prescripción FITT. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Participante de rehabilitación cardíaca (R.K., 58 años) recuperándose de un infarto, con baja capacidad funcional y descenso sedentario del VO2max.

Escenario: Grupo de educación física de secundaria (Grado 7, 12 años) con participación decreciente en actividad aeróbica moderada continua.

Escenario: Corredor universitario de campo traviesa (D.L., 20 años) con estancamiento en la progresión del VO2max durante bloques de entrenamiento en calor extremo.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de acondicionamiento cardiorespiratorio de su cliente.
- Análisis Cardiorespiratorio y FITT: Explique el VO2max, el volumen sistólico, los parámetros FITT y las normas aeróbicas de PAGA 2018 para su cliente.
- Parte 3: Verificación Activa y Ajuste FITT: En una defensa obligatoria (aprox. mínimo 150 palabras (150+ palabras)) con su propia voz clínica, justifique por qué su ajuste de prescripción FITT protege la seguridad miocárdica y se alinea con PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-101 Módulo 09 Sesión de Coaching • Ruta 1 (Clínica / R.K.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Profesiones de la Salud (R.K., 58 años). Reto: R.K. se recupera de un infarto de miocardio reciente y presenta baja capacidad funcional, depresión del volumen sistólico y caída del VO2max por sedentarismo.
- Ruta 1: Clínica y Profesiones de la Salud (R.K., 58 años).
- Reto: R.K. se recupera de un infarto de miocardio reciente y presenta baja capacidad funcional, depresión del volumen sistólico y caída del VO2max por sedentarismo.
- Análisis Cardiorespiratorio y FITT: Pautas Aeróbicas de PAGA 2018 y Hemodinámica: La rehabilitación cardíaca requiere reconstruir gradualmente la contractilidad miocárdica y la extracción periférica de oxígeno sin inducir isquemia cardíaca. Las pautas de PAGA 2018 recomiendan 150 minutos semanales de acondicionamiento aeróbico moderado estructurado mediante parámetros FITT seguros. La sobrecarga aeróbica progresiva expande el volumen sistólico y mejora la salud metabólica con seguridad.
- Pautas Aeróbicas de PAGA 2018 y Hemodinámica: La rehabilitación cardíaca requiere reconstruir gradualmente la contractilidad miocárdica y la extracción periférica de oxígeno sin inducir isquemia cardíaca. Las pautas de PAGA 2018 recomiendan 150 minutos semanales de acondicionamiento aeróbico moderado estructurado mediante parámetros FITT seguros.
- La sobrecarga aeróbica progresiva expande el volumen sistólico y mejora la salud metabólica con seguridad.
- Parte 3: Verificación Activa y Ajuste FITT: "Implementar una prescripción FITT de 3 a 4 días por semana de frecuencia, 40%–50% de intensidad de la Reserva de Frecuencia Cardíaca (RPE 11–13), 20–30 minutos de duración, utilizando cicloergómetro estacionario de bajo impacto." Verificación Activa: En mi juicio clínico, iniciar al 40% de la FCR proporciona un amortiguador hemodinámico vital para R.K. Su miocardio post-infarto no tolera picos rápidos de presión arterial, y los betabloqueadores limitan la aceleración cronotrópica. El cicloergómetro estacionario ofrece una modalidad controlada de bajo impacto que expande el volumen sistólico respetando PAGA 2018.
- "Implementar una prescripción FITT de 3 a 4 días por semana de frecuencia, 40%–50% de intensidad de la Reserva de Frecuencia Cardíaca (RPE 11–13), 20–30 minutos de duración, utilizando cicloergómetro estacionario de bajo impacto."
- Verificación Activa: En mi juicio clínico, iniciar al 40% de la FCR proporciona un amortiguador hemodinámico vital para R.K. Su miocardio post-infarto no tolera picos rápidos de presión arterial, y los betabloqueadores limitan la aceleración cronotrópica. El cicloergómetro estacionario ofrece una modalidad controlada de bajo impacto que expande el volumen sistólico respetando PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!" ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- EN: "Systematic aerobic conditioning expands stroke volume and strengthens the heart for lifelong metabolic health!"
- ES: "¡El acondicionamiento aeróbico sistemático expande el volumen sistólico y fortalece el corazón para una salud metabólica duradera!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_101_M09_Quiz_Sprint.pdf
KIN-101 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 09)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 09)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
