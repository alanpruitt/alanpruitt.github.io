## KIN-101 (Module 04 Overview): Concepts of Kinesiology: Foundational Movement & Physical Activity

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology


## Mod 04 Overview: Career Pathways & Credentials


### Welcome to Module 04: Career Pathways & Credentials

Welcome to Week 4! This week, we transition from exercise physiology fundamentals to professional career architecture and legal scope-of-practice boundaries across the movement sciences. Using our academic Single Source of Truth (SSoT)—the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —alongside national credentialing boards (ACSM, NSCA, NASM, and CAAHEP), we audit the professional credentials required to prescribe exercise safely and legally across diverse populations.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify scope-of-practice boundary patterns, apply federal and accreditation rules (differentiating Certified Personal Trainers from Clinical Exercise Physiologists and Physical Therapists), and map your academic transfer pathway from Arizona Western College to university completion and clinical internship placement.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 8, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 10, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 13, 2026, at 11:59 PM MST
- Lab 04 Direct Submission / Entrega de Laboratorio: Monday, September 14, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 04 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Differentiate the legal scopes of practice, educational prerequisites, and supervisory roles across Certified Personal Trainers (CPT), Certified Strength and Conditioning Specialists (CSCS), and Clinical Exercise Physiologists (CEP). Diferenciar los alcances de la práctica legal, requisitos académicos y roles de supervisión entre CPT, CSCS y Fisiólogos del Ejercicio Clínico (CEP).
- CLO 2 (Rule Application): Audit ethical and legal scope-of-practice boundaries, identifying violations in clinical, post-rehabilitation, and athletic populations based on PAGA 2018 and professional accreditation guidelines. Auditar los límites éticos y legales del alcance de la práctica, identificando infracciones en poblaciones clínicas y deportivas según PAGA 2018 y normas de acreditación.
- CLO 3 (Problem Solving): Construct a personalized 4-year academic degree map from Arizona Western College to university transfer (NAU-Yuma / UArizona) that incorporates credential examination milestones and clinical internship hours. Diseñar un plan de estudios de 4 años desde AWC hacia la transferencia universitaria que integre exámenes de certificación e internados clínicos.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit career credentials and professional scopes through your selected track:

Auditing clinical exercise physiology (ACSM-CEP), Physical Therapy (DPT), and Occupational Therapy (OT) pathways, clinical shadowing prerequisites, and hospital credentialing.

Mapping health promotion specialist, wellness director, and community fitness leadership credentials to advance physical activity equity across Yuma County.

Evaluating NSCA-CSCS certification requirements, collegiate strength coaching pathways, tactical performance standards, and athletic liability governance.


### Module 04 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Professional Credentials, Scopes of Practice & Transfer Mapping
- Discussion Board 04: Career Pathway Alignment & Ethical Scope Auditing
- Lab Assignment 04: Academic Degree Roadmap & Gemini AI Tool Box
- Module 04 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 04 (Mod 04 Overview: Career Pathways & Credentials)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Módulo 04 Visión General: Rutas Profesionales y Credenciales


### Bienvenido al Módulo 04: Credenciales Profesionales, Planificación Académica y Alcances de la Práctica

¡Bienvenido a la Semana 4! Esta semana pasaremos de los fundamentos fisiológicos a la arquitectura profesional y los límites legales del alcance de la práctica en las ciencias del movimiento. Utilizando nuestra Fuente Única de Verdad (SSoT)—las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) —y los estándares de los organismos de certificación (ACSM, NSCA, NASM, CAAHEP), auditaremos los requisitos necesarios para prescribir ejercicio de forma segura y ética.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará límites profesionales, aplicará reglas de acreditación (diferenciando entrenadores personales de fisiólogos clínicos y fisioterapeutas) y diseñará su ruta de transferencia académica desde Arizona Western College hacia la graduación universitaria.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 10 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 13 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 04: Lunes, 14 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Diferenciar los alcances de la práctica legal, requisitos académicos y funciones entre CPT, CSCS y Fisiólogos del Ejercicio Clínico (CEP).
- CLO 2 (Regla): Auditar los límites éticos y legales de la práctica, identificando infracciones en poblaciones clínicas y atléticas según PAGA 2018.
- CLO 3 (Solución): Diseñar un plan de estudios de 4 años desde AWC hacia la transferencia universitaria (NAU-Yuma / UArizona) que integre certificaciones e internados.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará credenciales y alcances legales a través de su ruta profesional:

Auditoría de rutas en fisiología clínica (ACSM-CEP), Fisioterapia (DPT) y Terapia Ocupacional (OT), requisitos de internado y acreditación hospitalaria.

Planificación de credenciales en promoción de la salud y liderazgo comunitario para impulsar la equidad en la actividad física en el condado de Yuma.

Evaluación de requisitos de certificación NSCA-CSCS, entrenamiento de fuerza universitario, rendimiento táctico y responsabilidad legal deportiva.


### Ruta de Aprendizaje del Módulo 04

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Obligatorias: Credenciales Profesionales, Alcances de la Práctica y Transferencia
- Foro de Discusión 04: Alineación de Rutas Profesionales y Auditoría Ética
- Laboratorio 04: Mapa de Grado Académico y Consulta de IA
- Comprobación de Conocimientos y Resumen del Módulo 04

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar un acceso equitativo, inclusivo y sin barreras en nuestra comunidad estudiantil.


### Module 04 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 04 Required Readings: Career Pathways & Credentials →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 04 Discussion: Choosing Your Exercise Science Career Path →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 04 Coaching Sprint: Certifications & Scope of Practice →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 04 Lab: Professional Career & Certification Plan →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 04 Summary & Wrap-Up: Career Pathways & Credentials →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 04)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
