## KIN-101: Mod 04 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 04) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology / Conceptos de Kinesiología


## Mod 04 Coaching Sprint Simulation: Certifications & Scope of Practice

Sesión de Coaching del Módulo 04: Carreras Profesionales, Credenciales y Alcances de la Práctica

- Kinesiology Scope of Practice (Fitness Coaching vs. Medical Care): Exercise professionals design PAGA-aligned movement and habit programs, but never diagnose medical disease, prescribe medications, or override physician restrictions. En palabras sencillas: Como entrenadores diseñamos planes de movimiento seguro, pero nunca diagnosticamos enfermedades ni cambiamos recetas médicas.
- Preparticipation Health Screening (PAR-Q+ & Red-Flag Symptoms): Identifying chest pain, unexplained dizziness, or uncontrolled cardiometabolic conditions that require medical clearance before vigorous exercise. En palabras sencillas: Revisar señales de alerta como mareo, dolor de pecho o presión descontrolada para saber cuándo pedir autorización médica primero.
- Interprofessional Allied Health Referral: Coordinating client transitions between Certified Personal Trainers (CPT), Physical Therapists (PT), Registered Dietitians (RD), and primary care physicians. En palabras sencillas: Trabajar en equipo con fisioterapeutas, nutriólogos y médicos cuando el cliente necesita atención clínica especializada.
- KIN-101.4.1.AY26-27: Evaluate professional career trajectories and specialization tracks within kinesiology, exercise science, and allied health. Evaluar trayectorias profesionales y especializaciones dentro de la kinesiología y la salud aliada.
- KIN-101.4.2.AY26-27: Identify accredited national certification bodies (e.g., ACSM, NSCA, NASM) and educational prerequisites for industry credentials. Identificar organismos de certificación nacional acreditados y requisitos educativos para credenciales de la industria.

### Your Weekly Win: Mapping Your Professional Blueprint

Where can a degree in kinesiology take you? From clinical rehabilitation and strength coaching to community wellness and physical therapy, the options are vast! Navigating your career requires understanding industry-standard NCCA-accredited certifications and academic transfer milestones. Choose your coaching track below, chat with your AI Socratic Coach, and map out your professional future!

¿A dónde puede llevarle un título en kinesiología? Desde la rehabilitación clínica y el acondicionamiento de fuerza hasta la salud comunitaria y la terapia física, ¡las opciones son amplias! Elija su ruta, dialogue con su Coach de IA y trace su plan profesional.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Elija la ruta que más se alinee con su interés vocacional

Scenario: Community college student (Elena, 20) aspiring to become a Doctor of Physical Therapy (DPT) wondering about undergraduate coursework and clinical observation hours.


```text
###
[TRACK]: Track 1 - Clinical & Physical Therapy Path
[CLIENT]: Pre-PT Student (Elena, 20) | [LOCATION]: Yuma, AZ
[SITUATION]: Planning a transition from Arizona Western College to a university DPT program. Overwhelmed by prerequisite science courses and required clinical observation hours.
[COACHING GOAL]: Map out the educational trajectory and prerequisite milestones required for competitive entry into clinical graduate programs.
###
```

Scenario: Kinesiology student (Marcus, 21) looking to lead youth wellness programs and wondering which certifications carry weight in public school and community settings.


```text
###
[TRACK]: Track 2 - Community & Youth Coaching Path
[CLIENT]: Community Wellness Aspirant (Marcus, 21) | [LOCATION]: Yuma County, AZ
[SITUATION]: Wants to work in local community youth programs but is confused about whether to pursue general coaching certificates or specialized youth fitness credentials.
[COACHING GOAL]: Identify community-focused credentialing bodies and practical networking strategies for regional public health and youth sports roles.
###
```

Scenario: Student entrepreneur (Sarah, 22) planning to open a private training studio who needs to choose between major NCCA-accredited personal training certifications (ACSM, NSCA, NASM).


```text
###
[TRACK]: Track 3 - Adult Fitness & Strength Coaching Path
[CLIENT]: Future Strength Coach & Entrepreneur (Sarah, 22) | [LOCATION]: Yuma, AZ
[SITUATION]: Preparing to enter the commercial fitness industry and debating which NCCA-accredited credential (such as ACSM-CPT or NSCA-CSCS) best aligns with her business goals.
[COACHING GOAL]: Compare major NCCA-accredited national certifications and outline the professional standards required for elite coaching practice.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-101 Career & Credentialing Tool Box ###:
Role: Supportive KIN-101 Kinesiology Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) & Professional Credentialing Scopes (ACSM, NSCA, NASM).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in simple terms the landscape of kinesiology career tracks and major NCCA-accredited credentialing bodies (such as ACSM, NSCA, NASM) relevant to the client's goals.
Step 3: Guide the student to outline ONE actionable next step or educational milestone the client should pursue right now.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how intentional credentialing unlocks professional opportunity.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected career track and client's professional goal or dilemma.
- Career Pathway & Credentials Analysis: Explain the relevant industry pathways and NCCA-accredited certifications associated with your chosen track.
- My Actionable Next Step: Provide 1 clear, strategic educational or professional milestone for your client.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why holding an NCCA-accredited credential (ACSM, NSCA, NASM, ACE) and respecting legal Scope of Practice referral boundaries protects clients in Yuma County.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 04 Coaching Sprint • Track 3 (Strength / Sarah)

- Chosen Track & Client: Track 3: Adult Fitness & Strength Coaching (Sarah, 22). Dilemma: Sarah is preparing to open a private training studio and needs to select the right NCCA-accredited certification to establish instant professional credibility and client trust.
- Track 3: Adult Fitness & Strength Coaching (Sarah, 22).
- Dilemma: Sarah is preparing to open a private training studio and needs to select the right NCCA-accredited certification to establish instant professional credibility and client trust.
- Career Pathway & Credentials Analysis: Industry Pathway: Commercial fitness and private strength coaching entrepreneurship. Credential Options: Comparing ACSM-CPT, NASM-CPT, and NSCA-CSCS. For advanced athletic strength, the NSCA-CSCS is the gold standard; for general adult coaching and health club management, ACSM or NASM provide robust foundational standards.
- Industry Pathway: Commercial fitness and private strength coaching entrepreneurship.
- Credential Options: Comparing ACSM-CPT, NASM-CPT, and NSCA-CSCS. For advanced athletic strength, the NSCA-CSCS is the gold standard; for general adult coaching and health club management, ACSM or NASM provide robust foundational standards.
- My Actionable Next Step for Sarah: "Register for an NCCA-accredited prep course, schedule her CPR/AED certification, and map out her 90-day exam study timeline before launching her studio."
- "Register for an NCCA-accredited prep course, schedule her CPR/AED certification, and map out her 90-day exam study timeline before launching her studio."
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, earning an NCCA-accredited certification like the NSCA-CPT or ACSM-CPT is not just a resume credential—it is a public safety safeguard. Unregulated online weekend certificates and generic AI workout bots routinely cross legal Scope of Practice boundaries by attempting to diagnose joint pain or prescribe restrictive clinical diets. For Sarah opening a training studio in Yuma, NCCA accreditation proves competency in pre-participation risk screening, PAGA 2018 exercise progression, and emergency referral protocols. When a client presents with acute orthopedic pain or metabolic red flags, knowing exactly when to pause training and refer to a licensed Physical Therapist or Registered Dietitian protects client health and builds lasting community trust."
- My Memorable Coaching Takeaway: EN: "An accredited certification isn't just a piece of paper—it's your professional passport to trust and authority!" ES: "¡Una certificación acreditada no es solo un papel; es su pasaporte profesional hacia la confianza y la autoridad!"
- EN: "An accredited certification isn't just a piece of paper—it's your professional passport to trust and authority!"
- ES: "¡Una certificación acreditada no es solo un papel; es su pasaporte profesional hacia la confianza y la autoridad!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M04_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 04 (Mod 04 Coaching Sprint: Certifications & Scope of Practice)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Módulo 04 Simulación de Coaching: Carreras Profesionales y Credenciales

Evaluación Rápida y Planificación de Trayectorias en Kinesiología


### Su Logro Semanal: Mapeando Su Futuro Profesional

Esta sesión le permitirá conocer las diferentes trayectorias profesionales en kinesiología, desde la rehabilitación clínica hasta el entrenamiento de fuerza y la salud comunitaria. Aprenda a identificar certificaciones acreditadas por la NCCA. ¡Elija su caso, dialogue con su Coach de IA y trace su ruta profesional!


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-101 Carreras y Credenciales ###:
Rol: Coach de Kinesiologia de KIN-101 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) y Alcances Profesionales (ACSM, NSCA, NASM).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla el panorama de carreras en kinesiologia y los principales organismos de certificacion acreditados por la NCCA relevantes para las metas del cliente.
Step 3: Guiar al estudiante para delinear UN siguiente paso u hito educativo que el cliente deba realizar ahora mismo.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como la certificacion intencional abre oportunidades profesionales.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta profesional y el objetivo o dilema de su cliente.
- Análisis de Carrera y Credenciales: Explique las trayectorias de la industria y certificaciones acreditadas por la NCCA para la ruta elegida.
- Mi Siguiente Paso Accionable: Describa 1 hito educativo o profesional claro para su cliente.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué contar con una certificación acreditada por la NCCA y respetar los límites legales del Alcance de la Práctica protege a los clientes en el condado de Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, obtener una certificación acreditada por la NCCA como NSCA-CPT o ACSM-CPT es una garantía de seguridad pública. Los certificados rápidos sin acreditación y los bots genéricos de IA suelen invadir el Alcance Legal de la Práctica intentando diagnosticar lesiones o recetar dietas clínicas. Para Sarah en Yuma, la acreditación NCCA respalda el filtro previo de seguridad, la aplicación de PAGA 2018 y la referencia oportuna a un fisioterapeuta (PT) o nutriólogo registrado (RD) cuando surgen señales de alerta."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 04)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
