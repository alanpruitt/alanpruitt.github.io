## KIN-101: Mod 04 Required Readings Career Pathways And Credentials

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 04 Required Readings: Career Pathways & Credentials

Lecturas Obligatorias y Recursos de Estudio: Rutas Profesionales, Credenciales y Alcances de la Práctica


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Scope of practice defines the legal boundary between health coaching and licensed medical treatment. As an exercise professional, you prescribe PAGA 2018 movement habits while referring medical pain or disease diagnosis to clinicians. Clear professional boundaries protect your clients' safety and build career credibility.


#### En Palabras Sencillas (Norteño Context)

En una obra de construcción cada quien tiene su oficio: el electricista no hace el trabajo del plomero ni viceversa. Si los términos técnicos se ponen pesados, concéntrate primero en cuándo aplicar las guías PAGA 2018 y cuándo referir a un cliente con un médico.


### Required SSoT Text & Professional Credentialing Guidelines

Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) • National Professional Credentialing Standards (ACSM, NSCA, NASM, CAAHEP Scope of Practice Directives).

- Certification Portal: ACSM Certification & Clinical Credentials Overview
- Certified Personal Trainer (CPT): ACSM-CPT Scope & Exam Content Outline (PDF)
- Clinical Exercise Physiologist (CEP): ACSM-CEP Clinical Credentials & 1,200-Hour Internship Prerequisites
- Governance & Code of Ethics: NSCA Professional Codes, Policies & Standards
- Certified Strength & Conditioning Specialist (CSCS): NSCA CSCS Official Certification Handbook (PDF)
- CPT Scope Guide: NASM-CPT Scope of Practice & Professional Boundaries
- Code of Ethics: NASM Code of Professional Conduct & Ethics Standards (PDF)

### Regional Focus: Kinesiology Career Opportunities in Yuma County

Enfoque Regional: Oportunidades Laborales de Kinesiología en el Condado de Yuma

In Yuma County and regional border agricultural communities, healthcare and fitness systems face acute shortages of certified exercise professionals. Students transferring from Arizona Western College into university partner programs (such as NAU-Yuma or UArizona) bridge critical community needs: Certified Personal Trainers (CPT) promote accessible workplace fitness; Strength & Conditioning Specialists (CSCS) support collegiate and high-school athletics; and Clinical Exercise Physiologists (CEP) lead cardiac, pulmonary, and metabolic rehabilitation across outpatient health centers.

En el condado de Yuma y las comunidades agrícolas fronterizas, el sistema de salud y acondicionamiento físico enfrenta una alta demanda de profesionales certificados. Los estudiantes de AWC que transfieren a programas universitarios (NAU-Yuma o UArizona) cubren necesidades comunitarias esenciales: los CPT lideran el bienestar laboral, los especialistas CSCS apoyan el deporte escolar y universitario, y los fisiólogos clínicos CEP dirigen la rehabilitación cardiopulmonar y metabólica en centros ambulatorios.


### Reading 1: Legal Scope of Practice & Professional Boundaries

Lectura 1: Límites Legales del Alcance de la Práctica y Ética Profesional


#### Step 1: Scope of Practice Across Credentials

Diferenciación de Alcances por Credencial Profesional

- Certified Personal Trainer (CPT): Qualified to design exercise programs for apparently healthy, medically cleared individuals. Legally prohibited from diagnosing injuries, prescribing medical nutrition therapy, or treating uncleared clinical patients.
- Certified Strength and Conditioning Specialist (CSCS): Requires a Bachelor's degree; specializes in athletic performance enhancement, power development, and injury prevention in uninjured athletes and tactical populations.
- Clinical Exercise Physiologist (ACSM-CEP): Requires a CAAHEP-accredited Bachelor's degree and 1,200 documented clinical hours. Legally authorized to conduct diagnostic stress testing, interpret telemetry ECGs, and manage outpatient Phase II/III cardiac, pulmonary, and metabolic rehabilitation under medical supervision.

#### Step 2: Identifying Legal and Ethical Scope Violations

Identificación de Infracciones Legales y Éticas en el Ejercicio

Kinesiologists must recognize legal liability boundaries. Prescribing meal plans with specific caloric restriction for disease management, diagnosing musculoskeletal tears, performing joint manipulations, or independently clearing unstable cardiac patients constitutes an illegal breach of practice and triggers professional liability.

Los profesionales deben respetar los límites de responsabilidad legal. Prescribir dietas restrictivas para patologías, diagnosticar desgarros musculares, manipular articulaciones o dar de alta a pacientes cardíacos inestables sin autorización médica constituye una violación grave del alcance profesional.


### Key Terminology / Glosario Clave

The defined legal, ethical, and professional boundaries established by governing bodies and state laws specifying the activities, assessments, and interventions a practitioner is qualified and licensed to execute.

Límites legales, éticos y profesionales establecidos por ley y organismos reguladores que definen las actividades que un profesional certificado está autorizado a realizar.

An allied health professional with a Bachelor's degree and 1,200 clinical internship hours trained to administer exercise stress testing, telemetry ECG monitoring, and exercise prescription for individuals with cardiovascular, pulmonary, or metabolic disease.

Profesional de la salud con título universitario y 1,200 horas de internado clínico capacitado para pruebas de esfuerzo, telemetría y prescripción en patologías crónicas.

Commission on Accreditation of Allied Health Education Programs; the gold standard programmatic accreditation ensuring university kinesiology curricula meet clinical board eligibility requirements.

Comisión de Acreditación de Programas Educativos de Salud; estándar de calidad que garantiza la preparación académica para certificaciones clínicas nacionales.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Alcances Profesionales

Select each question below to confirm your understanding of professional credentialing before starting Discussion 04 and Lab 04:

English Response: A Certified Personal Trainer (CPT) is limited to training apparently healthy individuals who are medically cleared for unmonitored exercise. An ACSM Clinical Exercise Physiologist (CEP) is qualified to work with high-risk clinical populations (e.g., post-CABG, heart failure, COPD, stroke) utilizing diagnostic ECG telemetry and physician collaboration.

Respuesta en Español: Un CPT está limitado a personas aparentemente sanas con autorización médica. Un CEP de ACSM está certificado para atender a pacientes clínicos de alto riesgo (pos-CABG, insuficiencia cardíaca, EPOC) utilizando telemetría y bajo supervisión médica.

English Response: Prescribing individualized therapeutic diet plans to treat chronic pathology constitutes Medical Nutrition Therapy (MNT), which is legally restricted to licensed Registered Dietitian Nutritionists (RDN) or licensed physicians. Fitness professionals may only share general public health nutrition guidelines (such as the federal Dietary Guidelines for Americans).

Respuesta en Español: Prescribir dietas terapéuticas para tratar enfermedades constituye Terapia Médico-Nutricional (MNT), reservada legalmente a Dietistas Registrados (RDN) o médicos. Los entrenadores solo pueden compartir pautas generales de salud pública como las Guías Alimentarias.

English Response: Candidates must hold a minimum of a Bachelor's degree in Exercise Science or Kinesiology from a CAAHEP-accredited program, current BLS/ACLS certification, and 1,200 hours of documented clinical experience in cardiopulmonary, metabolic, or neuromuscular exercise programming.

Respuesta en Español: Se requiere título universitario en Kinesiología/Ciencias del Ejercicio de un programa acreditado por CAAHEP, certificación de soporte vital (BLS/ACLS) y 1,200 horas documentadas de internado clínico.


### AI Simulation Workspace • Career & Scope Auditor Simulation

Copy the prompt below into Gemini to audit career prerequisites, map transfer requirements, and screen for ethical scope violations:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-101 Module 04 Scope & Career Tool Box ###:
Role: Academic Kinesiology Advisor and Professional Credentialing Specialist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) & Professional Credential Scopes (ACSM, NSCA, NASM).

Instructions:
Step 1: Audit the student's career target and case scenario enclosed within triple-hashes (###) below.
Step 2: Differentiate the credential requirements (degree, certification board, clinical internship hours) for their chosen career path.
Step 3: Identify potential legal or ethical scope-of-practice violations in the provided client scenario.
Step 4: Formulate an academic transfer milestone timeline from Arizona Western College to university degree completion.
Step 5: Keep all inputs wrapped inside delimiters.

Student Career & Case Input ###:
Target Career Goal: [e.g., Physical Therapist, Clinical Exercise Physiologist, Strength Coach]
Current Academic Status: [e.g., AWC Kinesiology Major]
Scenario for Scope Audit: [Describe practice scenario to audit for legal boundaries]
End Input ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 04 (Mod 04 Required Readings: Career Pathways & Credentials)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 Double-Contrast Guard) contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (9:1 Double-Contrast Guard), garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Lecturas Obligatorias: Rutas Profesionales y Credenciales


### Texto Fuente SSoT y Lineamientos Profesionales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) • Estándares y Alcances de la Práctica Profesional de ACSM, NSCA, NASM y CAAHEP.

- Portal de Certificación: Panorama General de Credenciales Clínicas de ACSM
- Fisiólogo del Ejercicio Clínico (CEP): Requisitos de 1,200 horas de internado clínico y programas acreditados por CAAHEP.
- Especialista en Fuerza y Acondicionamiento (CSCS): Normas y códigos éticos de gobernanza profesional.

### Conceptos Científicos Centrales


#### Step 1: Límites Legales del Alcance de la Práctica

Los entrenadores personales (CPT) atienden legalmente a poblaciones sanas con autorización médica. Los especialistas CSCS optimizan el rendimiento atlético. Los fisiólogos clínicos (CEP) dirigen pruebas de esfuerzo y rehabilitación ambulatoria en hospitales con supervisión médica.


#### Step 2: Prevención de Infracciones Éticas y Legales

Prescribir dietas restrictivas para patologías, diagnosticar lesiones o dar de alta a pacientes cardíacos sin autorización médica constituye una violación legal del alcance profesional.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.2 AA (9:1 Double-Contrast Guard) para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-101 • Module 04 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 04:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 04)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 04)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
