## KIN-101: ASSIGNMENT 01 - INTRODUCTION TO KINESIOLOGY & PHYSICAL INACTIVITY PATTERNS 

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you dive into the dense physiological literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.

## En Palabras Sencillas (Norteño Context)
Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.
:::

::: {.callout-note}
## Course Welcome & Navigation Guide (In Plain English)
Welcome to the course! If you are feeling overwhelmed by online navigation or academic jargon, take a deep breath. This course is built to be straightforward: every module follows a predictable rhythm, and you will always know what is expected of you. 

## En Palabras Sencillas (Norteño Context)
Pásele con confianza. Aquí no venimos a perdernos entre palabras difíciles; venimos a aprender cómo funciona el cuerpo humano y cómo aplicar el conocimiento en la vida real. Si en algún momento no haya por dónde empezar, revise la guía del módulo o mándeme un mensaje. ¡Estamos para avanzar juntos!
:::

> ### Institutional Outcome Alignment
> This curriculum module is systematically aligned with the **AY26-27 Learning Mastery Framework**. Student submissions are assessed using evidence-based guidelines to verify competency in institutional outcomes (Kinesiology disciplines and foundational physical activity rules).

## Assignment Overview & Foundational Grounding / Contexto Inicial

* **English:** This assignment introduces the foundational history, sociology, and physiological concepts of human movement. All analysis methods and population-level health trends align exclusively with our Single Source of Truth (SSoT): the **PAGA 2018 (2nd Ed)**.
* *Español (Regional): Esta tarea introduce la historia fundacional, la sociología y los conceptos fisiológicos del movimiento humano. Todos los métodos de análisis y las tendencias de salud a nivel poblacional se alinean exclusivamente con nuestra Fuente Única de Verdad (SSoT): la **PAGA 2018 (2ª Ed)**.*

---

## Targeted Learning Objectives / Tracking de Objetivos

* **([LO 1.1])** Identify population-level physical inactivity patterns and apply federal public health rules to evaluate community health risks.

---

## The Clinical Framing Protocol / El Protocolo de Encuadre Clínico

1. **Pattern / Patrón:** Identify and document community-level physical inactivity trends or sedentary behavior tracking data.
2. **Rule / Regla:** Apply specific federal public health guidelines and rules outlined in the PAGA 2018 to evaluate population risks.
3. **Solve / Solución:** Formulate sustainable, evidence-based physical activity interventions that mitigate chronic physiological risk lines at the community level.

---

## Student Action Items

Students will utilize the integrated digital workspace to complete this module case work. Ensure your assigned tracking case metrics remain fully wrapped inside the required layout delimiters below.

```text
###
## [PASTE COMMUNITY CASE DATA / REGISTRO DE CASO AQUÍ]
###
```

1. Extract the physical activity metrics from your assigned community tracking sheet.
2. Run a baseline audit to verify if the recorded movement lines meet the minimum guidelines outlined in the PAGA.
3. Export your finished summary analysis and upload your file straight to your Canvas Assignment portal.

---
## Mastery Performance Standard / Estándar de Ejecución de Maestría
This assignment is evaluated using the strict 10/7/0 institutional scale:

* **10 (Exemplary):** Zero-drift integration. Core tracking values match federal guidelines exactly; data profiles remain fully wrapped with no structural layout gaps.
* **7 (Competent):** Minor refactoring required. Performance metrics are safe and accurate, but minor formatting gaps or delimiter omissions are flagged.
* **0 (Recalibrate):** Critical guideline miscalculation or raw student metrics left unwrapped. Complete rewrite required.

## ---

## KIN-101 Module Discussion: Applied Clinical Audit

## Final Inspection

<h3>Closes: Monday @ 11:59 PM</h3>

Review any feedback provided to your own post. Use Sunday/Monday to refine your understanding before the Module Checklist.
<!-- EXW Fleet 1-Click Clipboard Engine for Code Blocks & Prompt Cards -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-attach Copy Prompt buttons to all <pre><code> code blocks
  document.querySelectorAll('pre code').forEach((block) => {
    const container = block.parentElement;
    if (!container || container.querySelector('.copy-prompt-btn')) return;

    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-prompt-btn';
    copyBtn.type = 'button';
    copyBtn.style.cssText = 'position: absolute; top: 8px; right: 8px; background-color: #003366; color: #FFFFFF; border: none; border-radius: 4px; padding: 4px 10px; font-size: 0.75rem; font-weight: 700; cursor: pointer; z-index: 10; transition: background-color 0.2s ease;';
    const isSpanish = document.documentElement.lang === 'es' || window.location.pathname.includes('/es/');
    copyBtn.textContent = isSpanish ? 'Copiar Prompt' : 'Copy Prompt';

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(block.innerText.trim());
        const originalText = copyBtn.textContent;
        copyBtn.style.backgroundColor = '#065F46';
        copyBtn.textContent = isSpanish ? ' ¡Copiado!' : ' Copied!';

        setTimeout(() => {
          copyBtn.style.backgroundColor = '#003366';
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy prompt text:', err);
      }
    });

    if (getComputedStyle(container).position === 'static') {
      container.style.position = 'relative';
    }
    container.appendChild(copyBtn);
  });
});
</script>

## Navigation Roadmap & Success Standards
> **How to succeed in this course:**
> 1. **Check the Home Page first:** Your weekly overview and active links are always front and center.
> 2. **Read the Plain English Guide:** Every major section opens with a plain-language summary and regional context.
> 3. **Review the 10/10 Exemplar:** Every assignment includes a clear model of what top-tier work looks like so you never have to guess.

## High-Fidelity 10/10 Student Exemplar Target
> **What success looks like:** A top-tier submission does not get bogged down in dense academic jargon. It directly states the core pattern, applies the federal or clinical rule accurately, and solves the scenario using clear, real-world reasoning.
> * **Why this scores a 10/10:** It uses concise sentences, connects the data to an everyday human movement or regional example, and leaves zero ambiguity about the outcome.
