# KIN-101: Mod 01 Lab And Simulation 09

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Assignment 01

- Metabolic Equivalent of Task (METs — 3.0 to 5.9 Moderate): Ratio of working metabolic rate to resting metabolic rate (1 MET = quiet sitting); PAGA 2018 defines moderate intensity as 3.0–5.9 METs and vigorous as ≥6.0 METs. En palabras sencillas: Cuánto esfuerzo hace el cuerpo comparado con estar sentado (1 MET); caminar a paso firme cuenta como moderado (3.0 a 5.9 METs).
- Sedentary Behavior vs. Physical Inactivity: Prolonged waking sitting/reclining (≤1.5 METs) increases cardiometabolic risk independently of whether a client exercises later in the day. En palabras sencillas: Pasar 8 a 10 horas sentado daña la circulación y el azúcar aunque hagas ejercicio después; hay que cortar las horas de silla con pausas activas.
- Bout Fractionation (Every Minute Counts — PAGA 2018): The 2018 PAGA 2nd Edition removed the legacy 10-minute minimum bout rule; any duration of moderate-to-vigorous movement counts toward the 150–300 min/week total. En palabras sencillas: Ya no necesitas 30 minutos seguidos: tres caminatas de 10 minutos bajo techo con aire acondicionado suman igual para tus 150 minutos semanales.

```text
###
[PASTE COMMUNITY CASE DATA / REGISTRO DE CASO AQUÍ]
###
```

Step 1 — Extract the physical activity metrics from your assigned community tracking sheet. Step 2 — Run a baseline audit to verify if the recorded movement lines meet the minimum guidelines outlined in the PAGA. Step 3 — Export your finished summary analysis and upload your file straight to your Canvas Assignment portal.

Mastery Performance Standard / Estándar de Ejecución de Maestría This assignment is evaluated using the strict 10/7/0 institutional scale: 10 (Exemplary): Zero-drift integration. Core tracking values match federal guidelines exactly; data profiles remain fully wrapped with no structural layout gaps. 7 (Competent): Minor refactoring required. Performance metrics are safe and accurate, but minor formatting gaps or delimiter omissions are flagged. 0 (Recalibrate): Critical guideline miscalculation or raw student metrics left unwrapped. Complete rewrite required.

- 10 (Exemplary): Zero-drift integration. Core tracking values match federal guidelines exactly; data profiles remain fully wrapped with no structural layout gaps.
- 7 (Competent): Minor refactoring required. Performance metrics are safe and accurate, but minor formatting gaps or delimiter omissions are flagged.
- 0 (Recalibrate): Critical guideline miscalculation or raw student metrics left unwrapped. Complete rewrite required.
###

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### High-Fidelity 10/10 Student Exemplar Target


### In Plain English: Reading Navigation Guide

Before you dive into the dense literature below, here is the short version: This section breaks down how human systems adapt to physical stress, nutrition, and practical application. Focus on the core teamwork between variables before getting lost in technical terminology.


#### En Palabras Sencillas (Norteño Context)

Piensa en estos sistemas como el motor de una troca: entre mejor mantenimiento y combustible les des con el ejercicio y la nutrición, más distancia recorres sin fallas. Si los términos técnicos se ponen pesados, concéntrate primero en cómo el cuerpo responde al esfuerzo diario.

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
