# KIN-101: Mod 01 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology / Conceptos de Kinesiología


## Mod 01 Coaching Sprint Simulation: Daily Activity & The 150-Minute Goal

Sesión de Coaching del Módulo 01: Patrones de Inactividad y la Meta de los 150 Minutos

- Metabolic Equivalent of Task (METs — 3.0 to 5.9 Moderate): Ratio of working metabolic rate to resting metabolic rate (1 MET = quiet sitting); PAGA 2018 defines moderate intensity as 3.0–5.9 METs and vigorous as ≥6.0 METs. En palabras sencillas: Cuánto esfuerzo hace el cuerpo comparado con estar sentado (1 MET); caminar a paso firme cuenta como moderado (3.0 a 5.9 METs).
- Sedentary Behavior vs. Physical Inactivity: Prolonged waking sitting/reclining (≤1.5 METs) increases cardiometabolic risk independently of whether a client exercises later in the day. En palabras sencillas: Pasar 8 a 10 horas sentado daña la circulación y el azúcar aunque hagas ejercicio después; hay que cortar las horas de silla con pausas activas.
- Bout Fractionation (Every Minute Counts — PAGA 2018): The 2018 PAGA 2nd Edition removed the legacy 10-minute minimum bout rule; any duration of moderate-to-vigorous movement counts toward the 150–300 min/week total. En palabras sencillas: Ya no necesitas 30 minutos seguidos: tres caminatas de 10 minutos bajo techo con aire acondicionado suman igual para tus 150 minutos semanales.
- KIN-101.1.1.AY26-27: Identify historical and modern patterns of physical inactivity across diverse community demographics. Identificar patrones históricos y actuales de inactividad física en diversas poblaciones comunitarias.
- KIN-101.1.2.AY26-27: Apply PAGA 2018 guidelines to evaluate chronic hypokinetic disease risks in community populations. Aplicar las pautas PAGA 2018 para evaluar los riesgos de enfermedades hipocinéticas crónicas.

### Your Weekly Win: The 150-Minute Rule of Thumb

Welcome to your first weekly Coaching Sprint ! This assignment is designed to give you a quick, confidence-building win. Instead of stressing over high-stakes test questions, you will choose a real-world client scenario below, chat with your AI Socratic Coach, and master the two essential federal rules of physical activity: 150 to 300 minutes of moderate movement per week plus 2 days of full-body strength training . Walk away with a memorable, bilingual insight you can use immediately in your life and career!

Esta sesión semanal está diseñada para brindarle un logro claro y motivador. Elegirá su ruta profesional, conversará con su Coach de IA y dominará las dos pautas básicas de salud federal: de 150 a 300 minutos semanales de actividad moderada y 2 días de entrenamiento de fuerza.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track / Fase 1: Selección de Escenario de Simulación Clínica

Seleccione el caso correspondiente a su trayectoria vocacional

Scenario: Sedentary hospital desk worker (Jorge, 45) who only walks 30 minutes once a week on Sundays and struggles with constant afternoon fatigue and pre-hypertension.


```text
###
[TRACK]: Track 1 - Clinical & Rehabilitation Path
[CLIENT]: Hospital Administrative Clerk (Jorge, 45) | [LOCATION]: Yuma, AZ
[SITUATION]: Sits 9 hours a day at a desk. Accumulates only 30 minutes of casual walking on Sunday afternoons. Feels constant afternoon fatigue and has elevated pre-hypertension.
[COACHING GOAL]: Help Jorge break down the 150-minute weekly goal into manageable 30-minute weekday chunks and add 2 days of bodyweight strengthening.
###
```

Scenario: Busy parent and community organizer (Maria, 34) who believes exercise only counts if you spend an hour in a gym sweating heavily.


```text
###
[TRACK]: Track 2 - Community & Public Health Path
[CLIENT]: Community Organizer & Parent (Maria, 34) | [LOCATION]: Yuma County, AZ
[SITUATION]: Gets overwhelmed trying to find a full hour for the gym, so she does zero exercise during the week. Thinks short 10- or 15-minute brisk walks "don't count."
[COACHING GOAL]: Dispel the "all-or-nothing" myth using PAGA 2018 standards (every minute of moderate movement counts toward the 150-minute goal).
###
```

Scenario: College esports competitor (Sam, 19) who plays video games 6 hours a day and thinks high finger reflex speed replaces real cardiovascular training.


```text
###
[TRACK]: Track 3 - Sports & Youth Fitness Path
[CLIENT]: Collegiate Esports Competitor (Sam, 19) | [LOCATION]: Yuma, AZ
[SITUATION]: Sits in a gaming chair 40+ hours a week. Argues that fast gaming reflexes keep his heart healthy despite zero aerobic or muscular training.
[COACHING GOAL]: Show Sam how meeting the 150-minute aerobic and 2-day strength baseline boosts gaming reaction time, mental focus, and cardiovascular health.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data into Gemini, then paste this prompt directly below it:


```text
Safety Auditor Protocol: KIN-101 Inactivity Coaching Tool Box ###:
Role: Supportive KIN-101 Kinesiology Coach in an encouraging, clear Socratic voice designed for community college students.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition).

Instructions:
Step 1: Review the client scenario wrapped in triple-hashes (###) provided by the student.
Step 2: Explain in clear, simple terms why uninterrupted sitting causes hypokinetic health risks and how the PAGA 2018 baseline (150-300 minutes of moderate aerobic activity + 2 days of strength) solves the client's specific challenge.
Step 3: Guide the student to create an easy weekly action plan (e.g., 30 minutes a day, 5 days a week) that fits into the client's routine without overwhelming them.
Step 4: Help the student formulate ONE memorable, punchy takeaway sentence (in English and Spanish) about how consistent daily movement drives long-term vitality.
Step 5: Provide a congratulatory mastery certification string when complete.
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and the client's physical inactivity challenge.
- PAGA Baseline Rules: State the exact federal standard (150–300 min moderate aerobic OR 75–150 min vigorous + 2 days full-body strength).
- My Easy Weekly Action Plan: Describe a realistic 5-day schedule that helps the client hit the 150-minute target and 2 strength days.
- Part 3: Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why breaking the 150-minute PAGA 2018 goal into heat-safe daily bouts and adding 2 strength days protects your client better than an generic weekend-warrior workout.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-101 Module 01 Coaching Sprint • Track 2 (Community / Maria)

- Chosen Track & Client: Track 2: Community & Public Health (Maria, 34, busy parent). Problem: Maria feels guilty because she cannot spend an entire hour at the gym, so she does zero exercise. She does not know that even 10-to-15-minute walks during the day accumulate toward better cardiovascular health and satisfy federal guidelines.
- Track 2: Community & Public Health (Maria, 34, busy parent).
- Problem: Maria feels guilty because she cannot spend an entire hour at the gym, so she does zero exercise. She does not know that even 10-to-15-minute walks during the day accumulate toward better cardiovascular health and satisfy federal guidelines.
- PAGA Baseline Rules: Aerobic Guideline: Accumulate at least 150 to 300 minutes of moderate-intensity physical activity per week (or 75 to 150 minutes of vigorous activity). Muscle-Strengthening Guideline: Perform full-body muscle-strengthening exercises involving all major muscle groups on at least 2 days per week.
- Aerobic Guideline: Accumulate at least 150 to 300 minutes of moderate-intensity physical activity per week (or 75 to 150 minutes of vigorous activity).
- Muscle-Strengthening Guideline: Perform full-body muscle-strengthening exercises involving all major muscle groups on at least 2 days per week.
- My Easy Weekly Action Plan for Maria: Monday through Friday: Two 15-minute brisk walks daily (one in the morning before work and one in the evening with her kids) = 30 minutes/day × 5 days = 150 minutes total . Tuesday and Thursday: 10 minutes of bodyweight squats, wall push-ups, and core bridges at home before bed = 2 strength days .
- Monday through Friday: Two 15-minute brisk walks daily (one in the morning before work and one in the evening with her kids) = 30 minutes/day × 5 days = 150 minutes total .
- Tuesday and Thursday: 10 minutes of bodyweight squats, wall push-ups, and core bridges at home before bed = 2 strength days .
- Part 3: Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, David's biggest obstacle is the all-or-nothing belief that exercise only counts if he spends an uninterrupted hour sweating in a gym. For a 46-year-old working long shifts in Yuma, a generic AI plan prescribing 60-minute outdoor afternoon runs would trigger severe heat fatigue and immediate burnout. Under PAGA 2018 (2nd Ed.), bouts of any duration count toward the 150-to-300-minute weekly moderate aerobic target. Splitting his movement into 15-minute brisk morning and evening walks keeps his heart rate in a safe Talk Test zone while avoiding peak desert heat, and pairing it with two 10-minute home bodyweight strength sessions preserves his lean muscle mass and metabolic health."
- My Memorable Coaching Takeaway: EN: "You don't have to spend hours in the gym to be healthy—just 30 minutes of brisk daily movement adds up to a longer, more energetic life!" ES: "¡No tienes que pasar horas en el gimnasio para estar sano; solo 30 minutos de movimiento diario se suman para darte una vida más larga y con más energía!"
- EN: "You don't have to spend hours in the gym to be healthy—just 30 minutes of brisk daily movement adds up to a longer, more energetic life!"
- ES: "¡No tienes que pasar horas en el gimnasio para estar sano; solo 30 minutos de movimiento diario se suman para darte una vida más larga y con más energía!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M01_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 01 (Mod 01 Coaching Sprint: Daily Activity & The 150-Minute Goal)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología


## Módulo 01 Simulación de Coaching: Inactividad y la Meta de los 150 Minutos

Evaluación Rápida y Aprendizaje Práctico de las Pautas Federales de Salud


### Su Logro Semanal: La Regla de Oro de los 150 Minutos

¡Bienvenido a su primera sesión de coaching! Esta actividad está diseñada para darle un logro claro y sin estrés. Elegirá un caso práctico, conversará con su Coach de IA y dominará las dos pautas básicas de salud: 150 a 300 minutos semanales de actividad moderada y 2 días de fortalecimiento .


### Paso 1: Consulte a su Coach de IA

Pegue los datos de la ruta elegida en Gemini y copie este mensaje debajo:


```text
Protocolo Safety Auditor: KIN-101 Inactividad Fisica ###:
Rol: Coach de Kinesiologia de KIN-101 con voz motivadora y socratica para estudiantes universitarios.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion).

Instrucciones:
Step 1: Revisar el caso del estudiante delimitado por triples numerales (###).
Step 2: Explicar de forma sencilla por que el sedentarismo continuo dana la salud y como la meta basica (150-300 min de actividad moderada + 2 dias de fuerza) ayuda al cliente.
Step 3: Guiar al estudiante para elaborar un plan semanal accesible (ej. 30 minutos al dia, 5 dias a la semana) que se ajuste a su rutina.
Step 4: Ayudar a redactar UNA frase memorable (en ingles y espanol) sobre como el movimiento diario constante impulsa la vitalidad a largo plazo.
Step 5: Proporcionar una certificacion de logro al terminar.
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y el desafío de inactividad de su cliente.
- Pautas Básicas PAGA 2018: Cite la meta federal exacta (150–300 min aeróbicos moderados + 2 días de fuerza corporal).
- Mi Plan Semanal Práctico: Describa un horario realista de 5 días para alcanzar los 150 minutos y los 2 días de fuerza.
- Parte 3: La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué dividir la meta de 150 minutos de PAGA 2018 en sesiones diarias seguras ante el calor de Yuma y sumar 2 días de fuerza protege mejor a su cliente.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
Verificación Activa Ejemplar (10/10): "En mi criterio clínico, el mayor obstáculo de David es creer que el ejercicio solo cuenta si pasa una hora seguida en el gimnasio. Para un trabajador de 46 años en Yuma, un plan genérico de IA de 60 minutos bajo el sol de la tarde causaría agotamiento por calor y abandono. Según PAGA 2018, cada bloque de movimiento suma hacia los 150 minutos semanales. Dividir su actividad en caminatas rápidas de 15 minutos por la mañana y noche con dos sesiones de fuerza en casa protege su corazón y asegura constancia."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-101 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:
