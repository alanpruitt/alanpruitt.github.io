# KIN-101: Mod 01 Overview Human Movement Audit

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 01 Overview: Human Movement Audit


### Welcome to Mod 01 Overview: Human Movement Audit

Welcome to Week 1 of KIN-101! This week, we establish the foundational lens of Kinesiology by examining how daily physical activity, structured exercise, and sedentary behavior shape human health and longevity. Rather than relying on commercial fitness myths, you will learn to audit real-world movement habits against our primary Academic Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) .

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will diagnose daily activity deficits and environmental heat barriers in Yuma County (Pattern), apply federal PAGA 2018 aerobic (150–300 minutes/week moderate or 75–150 minutes/week vigorous) and muscle-strengthening (at least 2 days/week) benchmarks (Rule), and design realistic weekly movement interventions tailored to your career track (Solve).


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday at 11:59 PM MST
- Coaching Sprint & Lab Simulations / Entrega de Simulaciones de Sprint y Laboratorio: Monday at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje

- CLO 1 (Pattern Recognition): Audit baseline daily physical activity vs. sedentary behavior patterns and identify regional environmental barriers to movement in Yuma County. Auditar los patrones básicos de actividad física diaria frente al sedentarismo e identificar las barreras ambientales en el condado de Yuma.
- CLO 2 (Rule Application): Apply federal PAGA 2018 (2nd Ed.) aerobic volume (150–300 min/week) and multicomponent muscle-strengthening (≥2 days/week) guidelines. Aplicar las pautas federales de volumen aeróbico (150–300 min/semana) y fortalecimiento muscular (≥2 días/semana) de la PAGA 2018.
- CLO 3 (Problem Solving): Formulate a safe, practical weekly movement schedule and human Active Verification tailored to clinical, educational, or athletic coaching tracks. Formular un programa semanal de movimiento seguro y una Verificación Activa adaptada a rutas clínicas, educativas o deportivas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

Auditing sedentary behavior, cardiometabolic risk, and safe walking/strengthening progressions for adult outpatient clients.

Designing heat-adapted school and community activity schedules to help Yuma families reach PAGA 2018 daily movement targets.

Balancing off-season aerobic conditioning, multi-joint strength training, and recovery volume for collegiate athletes.


### Module 01 Learning Roadmap / Ruta de Aprendizaje

- Mod 01 Overview: Human Movement Audit (You are here!)
- Mod 01 Required Readings: Human Movement Audit (PAGA 2018 Benchmarks & Subdisciplines)
- Mod 01 Discussion: Meet Your Classmates & Movement Goals (Initial Post Thu / 2 Peer Replies Sun)
- Mod 01 Coaching Sprint: Daily Activity & The 150-Minute Goal (Due Monday 11:59 PM MST)
- Mod 01 Lab: Human Movement Audit (Due Monday 11:59 PM MST)
- Mod 01 Summary & Wrap-Up: Human Movement Audit

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 01 (Mod 01 Overview: Human Movement Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-101 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA (9:1 contrast override) standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-101 cumplen con los estándares UDL y WCAG 2.2 AA (contraste 9:1), garantizando un acceso digital equitativo y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 01 Visión General: Auditoría del Movimiento Humano


### Introducción al Módulo 01

¡Bienvenido a la Semana 1 de KIN-101! Esta semana establecemos la base de la Kinesiología examinando cómo la actividad física diaria, el ejercicio estructurado y el sedentarismo impactan la salud humana. En lugar de seguir mitos comerciales, auditarás hábitos reales utilizando nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) .

Utilizando el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , diagnosticarás el déficit de movimiento y las barreras de calor en el condado de Yuma (Patrón), aplicarás los estándares federales de PAGA 2018 de 150 a 300 minutos aeróbicos moderados y 2 días de fuerza por semana (Regla), y diseñarás un plan semanal práctico con tu Verificación Activa (Solución).


### Module 01 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 01 Required Readings: Human Movement Audit →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 01 Discussion: Meet Your Classmates & Movement Goals →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 01 Coaching Sprint: Daily Activity & The 150-Minute Goal →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 01 Lab: Human Movement Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 01 Summary & Wrap-Up: Human Movement Audit →
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
