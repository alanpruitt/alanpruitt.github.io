## KIN-101: Mod 01 Lab And Simulation 02

> **In Plain English / En Palabras Sencillas**
>
> **English:** Before you read the details below, here is the short version: **KIN-101 (Module 01) trains you to diagnose client movement and health patterns using Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).** You act as the clinical Architect while auditing AI calculations for regional safety. Every exercise supports unlimited revisions so you build confident workforce mastery.
>
> **Español (Norteño):** Piensa en esta guía como revisar los niveles y sensores antes de salir a carretera en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en identificar el Patrón del cliente, aplicar la Regla oficial (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)) y escribir tu Solución con tus propias palabras.

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 01 Lab & Simulation: Human Movement Audit

Módulo 01 Laboratorio: Auditoría del Movimiento Humano y Meta Federal PAGA 2018

- Metabolic Equivalent of Task (METs — 3.0 to 5.9 Moderate): Ratio of working metabolic rate to resting metabolic rate (1 MET = quiet sitting); PAGA 2018 defines moderate intensity as 3.0–5.9 METs and vigorous as ≥6.0 METs. En palabras sencillas: Cuánto esfuerzo hace el cuerpo comparado con estar sentado (1 MET); caminar a paso firme cuenta como moderado (3.0 a 5.9 METs).
- Sedentary Behavior vs. Physical Inactivity: Prolonged waking sitting/reclining (≤1.5 METs) increases cardiometabolic risk independently of whether a client exercises later in the day. En palabras sencillas: Pasar 8 a 10 horas sentado daña la circulación y el azúcar aunque hagas ejercicio después; hay que cortar las horas de silla con pausas activas.
- Bout Fractionation (Every Minute Counts — PAGA 2018): The 2018 PAGA 2nd Edition removed the legacy 10-minute minimum bout rule; any duration of moderate-to-vigorous movement counts toward the 150–300 min/week total. En palabras sencillas: Ya no necesitas 30 minutos seguidos: tres caminatas de 10 minutos bajo techo con aire acondicionado suman igual para tus 150 minutos semanales.
- KIN-101.1.1.AY26-27: Evaluate daily physical activity volume and sedentary time against federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).
- KIN-101.2.1.AY26-27: Design a heat-adapted, multicomponent weekly activity prescription and Active Verification for Yuma County populations.
- Pattern (Context): Calculate current weekly moderate-to-vigorous physical activity (MVPA) minutes, daily sedentary hours, and heat-related inactivity barriers.
- Rule (SSoT Benchmark): Apply PAGA 2018 (2nd Ed.) adult standards: 150–300 minutes/week of moderate-intensity aerobic activity (or 75–150 minutes vigorous) plus muscle-strengthening activities on at least 2 days/week.
- Solve (Intervention & Active Verification): Formulate a realistic 5-day movement progression, a 2-sentence bilingual client instruction card (EN / ES), and a 150-word minimum Active Verification (Part 3) in your own voice.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Case Coach • Activity Audit • Intensity & METs • PAGA 2018 Chapters PDF → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach, Activity Audit, Intensity y Capítulos PAGA 2018) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 1: Biometrics Box → 5. Strength Box / 6. Cardio Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #101-01 / Fase 1: Selección de Escenario de Simulación Clínica

Select ONE of the three career-aligned case files below (wrapped in triple-hash ### delimiters):

Outpatient adult (Roberto M., 54) in Yuma, AZ sitting 10 hours/day at a desk with prehypertension (BP 134/84 mmHg), currently completing only two 15-minute casual walks per week (30 min/week total; 0 strength days).

Community wellness participant (Lucia G., 36, agricultural packing supervisor in San Luis, AZ) experiencing evening fatigue, logging 45 minutes/week of brisk walking and 0 structured muscle-strengthening days.

Off-season collegiate recreational athlete (Marcus T., 20, Yuma, AZ) lifting weights 4 days/week (upper/lower split) but performing only 20 minutes/week of aerobic conditioning and sitting 8 hours/day gaming.


### Phase 2: Gemini AI Clinical Simulation Workspace / Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Paste your chosen Case File data wrapped in triple-hashes ( ### ) into Google Gemini, then paste this P-T-C-F prompt directly below it:

AI Disclosure: This workflow uses Google Gemini as a Clinical Calculator. Residents must audit all AI claims against the PAGA 2018 Source of Truth. AI can make mistakes.


### Phase 3: Canvas Text Box Submission Requirements / Fase 3: Requisitos de Entrega en Canvas (Solo Texto)

- Selected Track & Client Baseline: State your chosen track and client case profile.
- Part 1: Pattern Recognition (Context & Deficit Audit): Diagnose the client's movement/plane or activity volume deficit and regional Yuma environmental stressors.
- Part 2: Rule Application (PAGA 2018 SSoT Audit): Cite the exact federal PAGA 2018 (2nd Ed.) volume, frequency, intensity (Talk Test / RPE), and biomechanical/physiological rules that govern this case.
- Part 3: Solve & Bilingual Client Card (EN / ES): Provide your structured weekly prescription and a 2-sentence bilingual instruction card in English and Spanish.
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own authentic clinical voice, justify why your specific adjustments protect this client better than a generic, unverified AI workout plan in Yuma's climate.
- Repository Verification: Confirm archive to EXW_Professional_AI_Repository / EXW_101_M01_Movement_Audit.pdf .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track & Case: Track 1: Clinical & Allied Health Path (Roberto M., Age 54, Yuma, AZ)

- Part 1: Pattern Recognition: Roberto currently completes only 30 minutes/week of walking and 0 days/week of muscle-strengthening exercise while sitting 10 hours/day. This creates a weekly deficit of 120 minutes of moderate aerobic activity (150 min target − 30 min current = 120 min deficit) and a deficit of 2 muscle-strengthening days/week . In Yuma's 108°F afternoon heat, outdoor midday walking also poses a severe heat-exhaustion barrier.
- Part 2: Rule Application (PAGA 2018 SSoT): Under the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , adults must accumulate 150 to 300 minutes/week of moderate-intensity aerobic physical activity (3.0–5.9 METs; RPE 12–13; able to talk but not sing on the Talk Test) AND perform multicomponent muscle-strengthening activities involving all major muscle groups on 2 or more days/week . PAGA 2018 also confirms that bouts of any duration count toward the weekly total and that breaking up prolonged sitting improves cardiometabolic markers.
- Part 3: Solve & Bilingual Client Card: 5-Day Heat-Safe Yuma Prescription (150 Min Aerobic + 2 Days Strength): Monday through Friday: Two 15-minute brisk walks per day (6:15 AM outdoors before peak solar load and 7:30 PM indoors at an air-conditioned mall/hallway = 30 min/day × 5 days = 150 min/week at RPE 12). Tuesday & Thursday: 20 minutes of indoor full-body resistance training (chair squats, wall push-ups, resistance-band rows, and glute bridges; 2 sets × 12 reps). Bilingual Client Card (EN / ES): EN: "Walk briskly for 15 minutes each morning and evening where you can talk but not sing, and complete your 20-minute indoor strength routine every Tuesday and Thursday." ES: "Camine a paso ligero durante 15 minutos cada mañana y noche a un ritmo donde pueda hablar pero no cantar, y complete su rutina de fuerza en interiores cada martes y jueves."
- Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment as Roberto's movement architect, an automated AI calculator might simply tell him to walk 30 minutes outside after work at 5:00 PM—which is dangerous in Yuma when ambient temperatures exceed 108°F and his baseline blood pressure is already 134/84 mmHg. Furthermore, jumping straight from 30 minutes to 150 continuous minutes causes joint soreness and early dropout in sedentary desk workers. By leveraging the PAGA 2018 rule that all movement bouts count, splitting his brisk walking into 15-minute morning and indoor evening sessions eliminates thermal cardiovascular drift while breaking up his 10-hour sitting blocks. Pairing this with twice-weekly bodyweight resistance training protects lean muscle mass, improves vascular compliance, and builds sustainable confidence. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week."
- Repository Verification: AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_101_M01_Movement_Audit.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 01 (Mod 01 Lab: Human Movement Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Módulo 01 Laboratorio y Simulación: Auditoría del Movimiento Humano y Meta Federal PAGA 2018


### Fase 3: Requisitos de Entrega en Canvas (Solo Texto en Español o Inglés)

- Ruta y Caso Seleccionado: Indique la ruta profesional y el perfil del cliente.
- Parte 1: Reconocimiento de Patrones (Patrón): Diagnostique el déficit de movimiento/planos o volumen aeróbico y las barreras de calor en Yuma.
- Parte 2: Aplicación de Reglas (Regla PAGA 2018): Cite las reglas exactas de volumen, frecuencia, intensidad (Prueba del Habla / RPE) y biomecánica/fisiología de PAGA 2018.
- Parte 3: Solución y Tarjeta Bilingüe (Solución): Presente su prescripción semanal y una tarjeta bilingüe de 2 oraciones (EN / ES).
- Parte 4: Verificación Activa Obligatoria (Mínimo 150 Palabras en su Propia Voz Humana): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué sus ajustes protegen la seguridad del cliente frente a los errores comunes de la IA en el clima de Yuma.
- Verificación del Repositorio: Confirme el archivo en EXW_Professional_AI_Repository / EXW_101_M01_Movement_Audit.pdf .

### Modelo de Verificación Activa 10/10 (En Palabras Sencillas / Norteño)

"En mi criterio clínico como arquitecto del movimiento de Roberto, una calculadora automática de IA podría indicarle caminar 30 minutos al salir del trabajo a las 5:00 PM, lo cual es peligroso en Yuma cuando la temperatura supera los 108°F y su presión arterial basal es de 134/84 mmHg. Al aplicar la regla de PAGA 2018 de que cada bloque de movimiento cuenta, dividir su caminata en sesiones de 15 minutos por la mañana temprano y por la noche bajo techo elimina la deriva cardiovascular por calor e interrumpe sus 10 horas de sedentarismo. Sumar dos días de fuerza con peso corporal protege su masa muscular y asegura la adherencia a largo plazo."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:

---

## 4-Tier Educational Alignment & Instructor Adoption Guide

### Course Learning Objectives & Multi-Framework Standards Crosswalk

- **Course Learning Objectives (CLOs):** Analyze regional client biometrics and environmental stressors (**Pattern**), verify physiological thresholds against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** (**Rule**), and prescribe safe, culturally responsive interventions (**Solve**).
- **Tier 1 — Primary Clinical Single Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018).
- **Tier 2 — Federal Workforce AI Literacy & National Readiness:** U.S. Department of Labor (DOL) ETA Training and Employment Notice `US-DOL-TEN-07-25` (5 Content Areas: Understand AI Principles, Explore AI Uses, Direct AI Effectively, Evaluate Outputs, Use AI Responsibly) and National Science Foundation `NSF-TECHACCESS-AI-READY-2026`.
- **Tier 3 — Collegiate General Education Outcomes:** Higher Learning Commission (HLC) & Institutional Learning Outcomes in Critical Thinking, Quantitative & Scientific Reasoning, and Bilingual Community Communication.
- **Tier 4 — OER Commons & K–16 Dual-Enrollment Bridge Standards:** `CCSS.ELA-LITERACY.W.11-12.6` (technology-mediated iterative writing and revision in response to feedback), `WA.ELA.11-12.W.6` (Washington State digital composition & professional communication), and `CCSS.ELA-LITERACY.RST.11-12.7` (multi-source quantitative and technical synthesis).

### Instructor Facilitation & Zero-Textbook-Cost ($0 ZTC) Adoption Notes

- **Turnkey Classroom & Dual-Enrollment Utility:** Adopting faculty at 2-year community colleges, 4-year kinesiology/health departments, and high school CTE dual-enrollment programs may deploy this `KIN-101` module asynchronously online, in hybrid classrooms, or in onsite laboratories with **$0 textbook cost** under `CC BY-NC-SA 4.0`.
- **Accessibility & Bilingual Equity:** Verified against **WCAG 2.2 AA (9:1 Double-Contrast Guard)** with sequential `h2 -> h3` screen-reader hierarchy, zero decorative emojis, and bilingual English / Norteño-Spanish scaffolding.

---

## Guided Practice Exercise & Worked 10/10 Mastery Exemplar

### Interactive Simulator & P-T-C-F Practice Exercise (KIN-101 • Module 01)

 Under **The Centaur Protocol**, you are the **Architect/Pilot** (Problem Framing & Clinical Judgment) and the AI + [exwtoolkit.com](https://exwtoolkit.com) edge calculators serve as your **Engine/Clinical Calculator**. Complete the three-step practice sequence below before submitting your module lab:

1. **Step 1 — Tactile Simulator Calibration & Engineered P-T-C-F Prompt (Part 1 Engine):** Open [exwtoolkit.com](https://exwtoolkit.com) to compute baseline metrics for the regional case below, then draft a **Persona / Task / Context / Format (P-T-C-F)** prompt wrapping all client metrics inside triple-hash delimiters (`###`).
2. **Step 2 — 150-Word SSoT Clinical Audit (Part 2 Audit):** Audit the AI draft line-by-line against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**, flagging any unsafe intensity jumps, missing heat/hydration precautions, or unverified mathematical assumptions.
3. **Step 3 — 150-Word Verbatim Active Verification Defense (Part 3 Defense):** Write a 150-word clinical defense in your own voice explaining your `Pattern / Rule / Solve` intervention for a Yuma, AZ / Imperial Valley, CA client.

```text
###CASE_DATA_START###
Course & Module: KIN-101 (Module 01)
Client Pattern (Context): A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat.
Governing SSoT Rule: Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow').
Interactive Edge Simulator: https://exwtoolkit.com
###CASE_DATA_END###
```

### 10-7-0 Mastery Assessment Rubric (Unlimited Revisions • `allowed_attempts = -1`)

- **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** with zero safety errors across Part 1 (Engine), Part 2 (Audit), and Part 3 (Active Verification).
- **7 / 10 (Competent):** Identifies the primary clinical issue and AI calculation gaps, with minor omissions in SSoT citation detail; **unlimited revisions (`allowed_attempts = -1`)** remain open through the end of term to reach **10 / 10**.
- **0 / 10 (Recalibrate):** Missing a required section, unverified AI copy-paste, or unsafe clinical prescription; revise with instructor coaching feedback and resubmit for full credit.

### Exemplar: 10/10 Submission Standard

- **Part 1 (The Engine — P-T-C-F Prompt):** *Persona:* Act as an Exercise Science Clinical Calculator supporting a KIN-101 resident. *Task:* Organize a week-1 baseline plan from my verified simulator values. *Context:* `### A 34-year-old Yuma County administrative worker reports 0 minutes/week of structured exercise, sits 9 hours/day, and avoids outdoor afternoon walking due to 106°F summer heat. ###`. *Format:* Return a structured `Pattern / Rule / Solve` table citing **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)** so I can audit every threshold.
- **Part 2 (The Audit — 150-Word Clinical Critique Against SSoT):** The initial AI output suggested jumping straight into high-volume outdoor afternoon conditioning without accounting for regional desert heat or gradual baseline progression. Auditing that draft against our Academic Source of Truth (**Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**), I identified two critical clinical errors. First, Per HHS PAGA 2nd Edition (2018), adults require 150–300 minutes/week of moderate-intensity aerobic activity (3.0–5.9 METs) plus muscle-strengthening activities on 2 or more days/week; sedentary individuals must progress gradually ('start low and go slow'). Prescribing abrupt high-intensity volume in Week 1 violates graded progression and elevates musculoskeletal and thermoregulatory risk. Second, afternoon ambient temperatures in Yuma County frequently exceed 100°F, which accelerates cardiovascular drift and dehydration if indoor climate control or early-morning scheduling is omitted. By cross-checking the raw biometrics inside [exwtoolkit.com](https://exwtoolkit.com) before accepting the AI table, I corrected the weekly volume, intensity ceiling, and environmental safety gates so every number aligns strictly with federal and clinical guidelines.
- **Part 3 (Active Verification — 150-Word Verbatim Clinical Defense):** In my own clinical judgment as the human Architect, my priority is keeping this Yuma / Imperial Valley client safe, consistent, and confident during Week 1 rather than chasing an aggressive workout target on paper. Following the `Pattern / Rule / Solve` protocol, the client's baseline presentation (**Pattern**) shows clear environmental and physiological constraints that make generic internet routines unsafe. Applying our governing guideline (**Rule**), I anchored every target directly to **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)**. For the intervention (**Solve**), Calibrate brisk indoor mall/track walking (3.3 METs) in exwtoolkit.com starting at 3 days x 20 minutes/week (60 min/week Week 1, advancing +15–20 min/week toward 150 min/week) paired with 2 days/week of bodyweight chair squats, wall push-ups, and glute bridges. Presenting these targets in plain language (and Norteño-Spanish when serving bilingual families) ensures the client understands both how hard to work and which warning signs require stopping immediately.

### Check for Understanding (Deeper Learning Reflection)

- How would your **Rule** safety gate and **Solve** progression change if this same Yuma / Imperial Valley client reported new dizziness during exertion or lost access to an indoor climate-controlled facility during a 108°F heat advisory?

---

## AI Transparency, Human Authorship & Open License Disclosure

- **Primary Human Author & Instructional Architect:** Alan Lee Pruitt (Coach Alan), Adjunct Faculty of Exercise Science, Arizona Western College; Founder, Webcognita LLC (`https://alanpruitt.com/` • `ORCID: https://orcid.org/0009-0002-5038-7111`).
- **Human-in-the-Loop Governance (ISKME / OER Commons AI Attribution):** Pedagogical design, regional Yuma / Imperial Valley clinical cases, `Pattern / Rule / Solve` rubrics, and `WCAG 2.2 AA (9:1 Double-Contrast Guard)` verification were authored and audited by Alan Lee Pruitt (`ORCID: 0009-0002-5038-7111`) under deterministic Curriculum-as-Code (`W3C PROV-O`) provenance.
- **Open Educational Resource License:** Licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (`CC BY-NC-SA 4.0` • `$0 ZTC` Zero-Textbook-Cost)** (`https://creativecommons.org/licenses/by-nc-sa/4.0/`).

> *"AI Disclosure: This content was synthesized using Google Gemini. Residents must audit all clinical claims against the Source of Truth. AI can make mistakes."*
