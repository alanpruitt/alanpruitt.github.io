# KIN-101: Mod 01 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-101 • Concepts of Kinesiology & Physical Education / Conceptos de Kinesiología y Educación Física


## Mod 01 Discussion: Meet Your Classmates & Movement Goals

Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Movimiento


### In Plain English: Discussion Guide

Before you read the details below, here is the short version: This discussion is how we meet each other and connect your personal movement goals to federal physical activity guidelines. You will introduce yourself, pick a career track that interests you, and share how you plan to apply the 150-minute weekly movement rule in Yuma County.


#### En Palabras Sencillas (Contexto Norteño)

Es como la primera plática en la carne asada con gente nueva: cada quien dice de dónde es, qué carrera busca y cómo le gusta moverse aquí en el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en presentarte con confianza y compartir tu meta de actividad.


### Discussion Schedule & Deadlines / Horario y Fechas Límite

- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST (150-word minimum (150+ words))
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST (Reply to TWO (2) classmates for our Week 1 Self-Introduction)
- Bilingual Participation Welcome / Participación Bilingüe: You are warmly encouraged to write in English, Spanish, or both!

### Phase 1: Select Your Clinical Simulation Track & Case / Fase 1: Selección de Escenario de Simulación Clínica

Physical Therapy, Athletic Training, Nursing, or Outpatient Rehabilitation.

K–12 Physical Education, Community Recreation, or Public Health Promotion.

Collegiate/High School Coaching, Strength & Conditioning, or Personal Training.


### Initial Post Requirements (Due Thursday @ 11:59 PM MST • 100–150 Words)

- Community Introduction: Share your name (and preferred name), where you are from, your favorite way to move or fuel your body, and your career goal after AWC.
- Step 1: Pattern Recognition (Context): Identify one common real-world barrier to healthy movement, nutrition, or safe exercise you see in Yuma County / Imperial Valley (such as summer heat, long shifts, or fear of injury).
- Step 2: Rule Application (SSoT Benchmark): Cite one foundational rule from our course Source of Truth (Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.)) that addresses this barrier.
- Step 3: Solve & Personal Action Step: Propose one realistic weekly habit or coaching strategy you want to master this semester, plus a 1-sentence bilingual takeaway (EN / ES).
- Peer Engagement (Due Sunday @ 11:59 PM MST): Reply to at least TWO (2) classmates , welcoming them to the class and connecting with their career track or weekly goal.

### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Track: Track 1 (Clinical & Allied Health Path)

Hi everyone! My name is Mateo (I go by Matt), and I was born and raised here in Somerton, AZ. My favorite way to stay active is playing evening pickup basketball and lifting weights at the gym after work. My career goal after AWC is to transfer into a Physical Therapy Assistant (PTA) program so I can help older adults and agricultural workers in Yuma County recover from knee and back injuries.

Pattern / Rule / Solve Application: In my family, the biggest movement barrier ( Pattern ) is our 110°F+ summer heat and long work shifts that leave people exhausted on the couch. According to the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) ( Rule ), adults need 150 to 300 minutes of moderate-intensity aerobic activity plus at least 2 days of muscle-strengthening exercise every week—and every bout counts! My practical strategy ( Solve ) is breaking movement into two 15-minute brisk walks (one at 6:00 AM before the sun gets heavy and one indoors after dinner) plus two 15-minute bodyweight resistance sessions on Tuesdays and Thursdays.

Bilingual Takeaway (EN / ES): EN: "Small 15-minute bouts of brisk walking and twice-weekly strength training beat the Yuma heat and fulfill the PAGA 2018 150-minute health standard!" ES: "¡Caminatas cortas de 15 minutos y dos días de fuerza por semana vencen el calor de Yuma y cumplen la meta federal de 150 minutos de PAGA 2018!"


### Evaluation Rubric (10 Points Total • 10/7/0 Mastery Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 01) / Simulación Clínica y Dominio de Resultados (Módulo 01)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-101 Module 01 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: PAGA 2018 (Physical Activity Guidelines for Americans, 2nd Ed.) & ACSM 12th Ed. ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 01 de KIN-101 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: PAGA 2018 (Guías de Actividad Física para los Estadounidenses, 2.ª ed.) y ACSM 12th Ed. ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-101 • Module 01 (Mod 01 Discussion: Meet Your Classmates & Movement Goals)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (PAGA 2018 | ACSM 12th Ed.) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-101 • Conceptos de Kinesiología y Educación Física


## Foro de Discusión del Módulo 01: Conozca a sus Compañeros y Metas de Movimiento


### Requisitos de la Publicación Inicial (Jueves 11:59 PM MST • 100–150 Palabras) y 2 Respuestas (Domingo 11:59 PM MST)

- Presentación Personal: Comparta su nombre (y cómo prefiere que le llamen), de dónde es, cómo le gusta mantenerse activo y su meta profesional después de AWC.
- Step 1: Patrón (Contexto Regional): Identifique una barrera común en el condado de Yuma / Valle Imperial (como el calor extremo o turnos largos de trabajo).
- Step 2: Regla (Fuente de Verdad SSoT): Cite una regla fundamental de nuestra Fuente de Verdad (Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.)).
- Step 3: Solución y Meta Semanal: Proponga un hábito práctico para este semestre y una frase de aprendizaje bilingüe (EN / ES).
- Interacción con Compañeros: Responda al menos a DOS (2) compañeros antes del domingo a las 11:59 PM MST. ¡Puede escribir en inglés, español o ambos!
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-101 • Module 01 Quick Return Navigation / Regreso Rápido al Módulo 01:
