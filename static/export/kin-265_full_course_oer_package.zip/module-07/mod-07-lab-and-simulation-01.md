# KIN-265: Mod 07 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 07 Discussion: Safe Exercise Windows for Metabolic Syndrome

- Metabolic Syndrome Diagnostic Cluster (≥3 of 5 Risk Factors): Abdominal obesity (>40 in men / >35 in women), elevated triglycerides (≥150 mg/dL), low HDL (<40/50 mg/dL), elevated BP (≥130/85 mmHg), and elevated fasting glucose (≥100 mg/dL). En palabras sencillas: Conjunto de 3 o más factores de riesgo—cintura amplia, triglicéridos altos, colesterol bueno bajo, presión alta y glucosa elevada—que responden muy bien al ejercicio.
- Cardiometabolic Volume Progression (150 → 300 Min/Week): Progressing aerobic volume from 150 toward 250–300 minutes/week of moderate low-impact activity maximizes visceral fat reduction and lipid profile improvement. En palabras sencillas: Avanzar gradualmente de 150 a 250–300 minutos por semana de actividad aeróbica de bajo impacto para reducir grasa abdominal y mejorar triglicéridos.
- Combined Aerobic + Resistance Metabolic Synergy: Pairing aerobic conditioning with ≥2 days/week of large-muscle-group resistance training increases skeletal muscle glucose disposal and resting insulin sensitivity. En palabras sencillas: Sumar al menos 2 días de fuerza al cardio semanal multiplica la capacidad de tus músculos para limpiar el azúcar y la grasa de la sangre.

### Metabolic Syndrome, Energy Substrate Utilization, & PAGA Federal Mandates

Prescribing exercise for individuals managing Metabolic Syndrome and complex metabolic disorders requires precise clinical auditing. Standard aerobic and resistance targets must be balanced against insulin sensitivity parameters, abdominal adiposity thresholds, dyslipidemia management, and multi-component volume guidelines.

In this discussion, you will audit how federal standards in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) guide metabolic conditioning, energy expenditure targets, and chronic disease mitigation across your chosen Build Your Own Journey Track .

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-0607

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Outpatient metabolic rehabilitation; auditing high-volume energy expenditure protocols and lipid profile responses in a patient presenting with Metabolic Syndrome.

Focus: County health metabolic risk reduction initiative; structuring accessible community walking and circuit programs for populations with high prevalence of metabolic syndrome.

Focus: Master athlete conditioning; optimizing metabolic rate, body composition, and substrate oxidation efficiency during heavy training blocks.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Metabolic Profile / Ruta y Perfil Metabólico: State your chosen track and explain the specific metabolic syndrome risk factors in your client scenario. Indique la ruta seleccionada y explique los factores de riesgo del síndrome metabólico de su cliente.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit (Pattern / Rule / Solve) / Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Detail the underlying physiological mechanism (Pattern), apply PAGA 2018 volume and intensity mandates for metabolic conditioning (Rule), and outline your exercise prescription protocol (Solve). Detalle el mecanismo fisiológico (Patrón), aplique las normas PAGA 2018 de volumen (Regla) y describa su protocolo de prescripción (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence instruction card in English and Spanish guiding the client on weekly volume accumulation or substrate pacing. Proporcione una tarjeta concisa de 2 oraciones en inglés y en español para guiar al cliente sobre la acumulación de volumen semanal.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least TWO (2) classmates who selected a different track than yours (Minimum 2 Replies Required). Compare how metabolic conditioning and volume prescription differ across clinical rehabilitation, public health community initiatives, and master athletic environments.


### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 07 (Mod 07 Discussion: Safe Exercise Windows for Metabolic Syndrome)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials adhere strictly to UDL principles and WCAG 2.1 AA standards, featuring semantic hierarchy starting at heading level 2 and screen-reader verification.

Español: Todos los materiales cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Foro de Discusión 06 y 07: Prescripción de Ejercicio para Condiciones Metabólicas


### Síndrome Metabólico y Normas PAGA

Analice el caso asignado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) según la ruta profesional seleccionada.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:
