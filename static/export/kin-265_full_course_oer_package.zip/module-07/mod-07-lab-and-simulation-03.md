# KIN-265: Mod 07 Lab And Simulation 03

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 07 Lab & Simulation: Metabolic Syndrome Exercise Plan Audit

Laboratorio del Módulo 07: Prescripción para Condiciones Metabólicas y Simulación del Auditor de Seguridad

- Metabolic Syndrome Diagnostic Cluster (≥3 of 5 Risk Factors): Abdominal obesity (>40 in men / >35 in women), elevated triglycerides (≥150 mg/dL), low HDL (<40/50 mg/dL), elevated BP (≥130/85 mmHg), and elevated fasting glucose (≥100 mg/dL). En palabras sencillas: Conjunto de 3 o más factores de riesgo—cintura amplia, triglicéridos altos, colesterol bueno bajo, presión alta y glucosa elevada—que responden muy bien al ejercicio.
- Cardiometabolic Volume Progression (150 → 300 Min/Week): Progressing aerobic volume from 150 toward 250–300 minutes/week of moderate low-impact activity maximizes visceral fat reduction and lipid profile improvement. En palabras sencillas: Avanzar gradualmente de 150 a 250–300 minutos por semana de actividad aeróbica de bajo impacto para reducir grasa abdominal y mejorar triglicéridos.
- Combined Aerobic + Resistance Metabolic Synergy: Pairing aerobic conditioning with ≥2 days/week of large-muscle-group resistance training increases skeletal muscle glucose disposal and resting insulin sensitivity. En palabras sencillas: Sumar al menos 2 días de fuerza al cardio semanal multiplica la capacidad de tus músculos para limpiar el azúcar y la grasa de la sangre.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Exercise acts like medicine by moving glucose directly from the bloodstream into working muscles. In clients with diabetes or metabolic syndrome, physical exertion can dramatically alter blood sugar and blood pressure. You must monitor glucose before exercise, recognize hypoglycemia signs immediately, and enforce safe blood pressure boundaries to protect your clients.


#### En Palabras Sencillas (Norteño Context)

Hacer ejercicio con diabetes es como calibrar la bomba de inyección de una troca: si le metes acelerador de golpe sin revisar el combustible, el motor se te apaga a medio camino. Si los términos técnicos se ponen pesados, concéntrate primero en revisar que el azúcar esté entre 100 y 250 antes de empezar a entrenar.


### Metabolic Pathology Kinetics, Glycemic Regulation, & Hemodynamic Safeguards

Managing chronic metabolic pathologies—including Type 2 Diabetes Mellitus (T2D), dyslipidemia, and Metabolic Syndrome—demands precise clinical exercise auditing. Muscular contraction stimulates non-insulin-dependent glucose uptake via GLUT4 translocation; however, prescribing exercise without verifying glycemic safety exposes clients to life-threatening acute hypoglycemia ($< 70\text{ to }100\text{ mg/dL}$) or hyperosmolar hyperglycemic crisis ($> 250\text{ to }300\text{ mg/dL}$ with ketosis). Concurrently, autonomic neuropathy and peripheral vascular stiffness elevate hypertensive risks, mandating immediate exercise termination if systolic blood pressure exceeds $220\text{ mmHg}$ or diastolic exceeds $105\text{ mmHg}$. In this lab, you will evaluate clinical laboratory profiles, calculate aerobic energy expenditure targets exceeding $250\text{ to }300\text{ min/week}$ for metabolic disease management under PAGA 2018 (2nd Ed., Chapter 6) and ACSM's Guidelines (12th Ed.) , and audit an AI simulation using Google Gemini.

En este laboratorio, evaluará perfiles clínicos, calculará metas de gasto energético semanal según la PAGA 2018 y ACSM 12.ª Edición, y auditará una simulación clínica con Google Gemini.

- KIN-265.7.1.AY26-27: Prescribe aerobic and resistance exercise programming for individuals with metabolic syndrome and Type 2 Diabetes following PAGA 2018 and ACSM 12th Edition guidelines. Prescribir ejercicio aeróbico y de fuerza para personas con síndrome metabólico y diabetes tipo 2 según PAGA 2018 y ACSM.
- KIN-265.7.2.AY26-27: Execute clinical safety auditing protocols for glycemic control (100–250 mg/dL safety window), hypoglycemia management (Rule of 15), and hemodynamic stop criteria. Ejecutar protocolos de auditoría de seguridad para control glucémico (ventana 100-250 mg/dL), manejo de hipoglucemia (Regla del 15) y criterios hemodinámicos de parada.
- Module Window / Ventana del Módulo: Opens Tuesday, September 29, 2026, at 12:00 AM MST Abre el martes, 29 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 5, 2026, at 11:59 PM MST Lunes, 5 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Mastery Scale) Ponderación para laboratorios semanales y simulaciones clínicas

### Lab Objectives / Objetivos del Laboratorio

- Analyze client biometrics against ATP III metabolic syndrome diagnostic criteria (central adiposity, elevated triglycerides, low HDL, elevated fasting glucose, hypertension).
- Enforce the clinical 100 to 250 mg/dL glycemic window and execute the clinical Rule of 15 for pre-exercise hypoglycemia.
- Structure an individualized FITT-VP prescription targeting 150 to 300 minutes/week of moderate-intensity aerobic training plus 2 to 3 days/week of resistance exercise without Valsalva breath-holding.
- Audit an AI-generated exercise prescription for instructional drift, recognizing unmonitored HIIT, hypertensive risks, and extreme Yuma heat contraindications.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File structure

Fase 1: Seleccione su archivo de caso clínico (haga clic en la caja para copiar los datos delimitados)

Scenario: Outpatient metabolic rehabilitation patient (David, 56) with Metabolic Syndrome and T2D whose AI-generated plan prescribed dangerous unmonitored HIIT.

Scenario: Somerton walking group participant (Elena, 58) with T2D presenting with pre-exercise capillary glucose of 88 mg/dL and early neuroglycopenic symptoms.

Scenario: Masters endurance cyclist (Carlos, 45) with pre-diabetes and hypertension suffering from exertional post-exercise hypotension and delayed hypoglycemia.


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Paso 2: Copie la plantilla y consulte a Gemini para auditar el caso clínico bajo el protocolo Pattern / Rule / Solve

Paste your chosen Track data wrapped in triple-hashes (###) into Google Gemini, then paste this engineered prompt directly below it:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas (Solo Texto)

Type or paste your complete clinical audit directly into the Canvas text box structured under these five mandatory headings:

- Selected Track & Client Initials: State your chosen track, client initials, age, resting vitals, and primary metabolic condition.
- Part 1: Pattern Recognition (The Engine Audit): Critique the AI's clinical assessment. Identify metabolic syndrome criteria, glycemic instability, and specific instructional drift errors.
- Part 2: Rule Application (SSoT Benchmark): Cite PAGA 2018 (Chapter 6) and ACSM 12th Edition standards for metabolic exercise prescription, the 100–250 mg/dL glycemic window, Rule of 15, and hemodynamic stop limits.
- Part 3: Solving the Gap (Active Verification & Plan): Provide your corrected FITT-VP exercise prescription. In a mandatory 150-word text defense written in your own voice, justify why this plan protects cardiovascular and glycemic safety. Conclude with a 2-sentence bilingual coaching cue card in English and Spanish.
- Repository Verification: Confirm your prompt exchange is archived in Google Drive: EXW_Professional_AI_Repository / EXW265_M07_Metabolic_Audit.pdf .
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying your $100\text{–}250\text{ mg/dL}$ glycemic safety gate, $\le 48\text{-hour}$ GLUT4 frequency rule, and Yuma heat/foot-care safeguards.

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

This high-fidelity exemplar illustrates the depth, mathematical precision, and clinical reasoning required for full mastery points.

Selected Track: Track 1 - Clinical & Chronic Disease Prevention Path (Patient: David, 56 yrs, 98 kg, BP 138/88 mmHg)

Part 1: Pattern Recognition: David presents with all 5 ATP III diagnostic criteria for Metabolic Syndrome: waist circumference 42 in (>40 in), fasting glucose 142 mg/dL (>100 mg/dL), triglycerides 220 mg/dL (>150 mg/dL), HDL 34 mg/dL (<40 mg/dL), and BP 138/88 mmHg (>130/85 mmHg). The AI-generated prescription exhibited severe instructional drift by recommending unmonitored outdoor HIIT sprints at 2:00 PM in Yuma heat (108°F) followed by heavy breath-holding leg presses. In a sedentary patient on Metformin with autonomic impairment, this creates acute risks of exertional hypoglycemia, severe hypertensive spikes exceeding 220 mmHg from the Valsalva maneuver, and rapid heat exhaustion.

Part 2: Rule Application (SSoT): Under PAGA 2018 (Chapter 6: Adults with Chronic Health Conditions) and ACSM 12th Edition guidelines, initial programming must prioritize moderate-intensity aerobic exercise accumulating 150 to 300 minutes weekly spread across at least 3 to 5 days, avoiding more than 2 consecutive days of inactivity to maintain non-insulin GLUT4 translocation. Resistance training must utilize light-to-moderate loads (10–15 repetitions) with continuous rhythmic exhalation on exertion. Crucially, pre-exercise capillary blood glucose must be verified within the 100 to 250 mg/dL safety window, and exercise must be terminated if systolic BP exceeds 220 mmHg or diastolic BP exceeds 105 mmHg.

Part 3: Solving the Gap (Active Verification): I redesigned David's prescription into an indoor, climate-controlled progression: Aerobic: 30 minutes of stationary cycling or treadmill walking at 45–55% Heart Rate Reserve (RPE 12, "somewhat hard") 5 days weekly, accumulating 150 minutes in Month 1 and progressing to 225 minutes by Month 2. Resistance: 2 days weekly using selectorized machines (chest press, seated row, leg press, lat pulldown) at 50–60% 1RM for 2 sets of 12 reps, strictly enforcing continuous exhalation during effort to prevent blood pressure spikes. Glucose is tested 15 minutes before and after every session; if pre-exercise glucose is <100 mg/dL, 15g fast-acting carbohydrates are administered before moving. Hydration is enforced at 8 oz water every 20 minutes indoors. Bilingual Client Instruction Card: "Check your blood sugar before starting, and never hold your breath while lifting weights so your blood pressure stays safe. If you feel shaky or dizzy, stop immediately and take your glucose tablets." "Revise su nivel de azúcar antes de entrenar y nunca contenga la respiración al levantar pesas para proteger su presión arterial. Si siente temblores o mareos, deténgase de inmediato y tome sus tabletas de glucosa."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI exercise plan that prescribes high-impact outdoor barefoot or minimalist running for a client with Metabolic Syndrome and peripheral neuropathy risks plantar ulceration, heat exhaustion, and glycemic instability. As the human clinician, I enforce the 100–250 mg/dL pre-exercise blood glucose window, schedule moderate aerobic and resistance sessions every 24–48 hours so insulin-independent GLUT4 translocation never decays, mandate silica-gel/cushioned footwear with daily post-exercise foot inspections, and move sessions indoors during Yuma heat advisories. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

Repository Verification: Archived to EXW_Professional_AI_Repository / EXW265_M07_Metabolic_Audit.pdf


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 07 (Mod 07 Lab: Metabolic Syndrome Exercise Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 07 Práctica de Lab y Simulación: Prescripción para Condiciones Metabólicas

Auditoría de Síndrome Metabólico, Control Glucémico y Parámetros Hemodinámicos


### En Palabras Sencillas: Guía de Navegación

Antes de leer los detalles técnicos, aquí está la versión corta: El ejercicio funciona como medicina porque mete la glucosa de la sangre directamente a los músculos que están trabajando. En personas con diabetes o síndrome metabólico, el esfuerzo físico puede cambiar drásticamente el azúcar y la presión. Debe medir la glucosa antes de entrenar, reconocer los síntomas de bajón de azúcar y no permitir que la presión suba demasiado.


#### Contexto Norteño Regional

Hacer ejercicio con diabetes es como calibrar la bomba de inyección de una troca: si le metes acelerador de golpe sin revisar el combustible, el motor se te apaga a medio camino. Si los términos técnicos se ponen pesados, concéntrate primero en revisar que el azúcar esté entre 100 y 250 antes de empezar a entrenar.


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione uno de los tres escenarios clínicos (Ruta 1 Clínica: David 56 años con síndrome metabólico; Ruta 2 Comunitaria: Elena 58 años en Somerton con hipoglucemia pre-ejercicio; Ruta 3 Rendimiento Deportivo: Carlos 45 años ciclista de fondo). Copie el bloque con delimitadores ### y consulte a Gemini con la plantilla de auditoría.


### Fase 3: Requisitos de Entrega en Canvas (Solo Texto)

- Ruta Seleccionada e Iniciales del Paciente: Especifique su ruta y signos vitales basales.
- Parte 1: Reconocimiento del Patrón: Audite los criterios de síndrome metabólico y los errores clínicos del plan inicial.
- Parte 2: Aplicación de Reglas (PAGA 2018 / ACSM 12.ª Ed.): Cite el volumen aeróbico, la ventana glucémica de 100-250 mg/dL y los límites de presión arterial.
- Parte 3: Resolución de la Brecha y Tarjeta Bilingüe: Presente su prescripción FITT-VP y defensa clínica de 150 palabras con tarjeta bilingüe.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
- Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica la ventana glucémica de $100\text{–}250\text{ mg/dL}$, la frecuencia $\le 48\text{ horas}$ para GLUT4 y el cuidado podológico y térmico en Yuma.

### Accesibilidad Universal (ARS)

Todos los materiales de KIN-265 cumplen estrictamente con los estándares UDL y WCAG 2.1 AA. Para adaptaciones académicas, contacte a AccessABILITY Resource Services (ARS), Edificio 3C del Campus de Yuma: access@azwestern.edu .

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:

Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, un programa genérico de IA no protege contra el riesgo de hipoglucemia ni de úlceras plantares en pacientes con síndrome metabólico y neuropatía periférica en Yuma. Al verificar glucosa entre 100 y 250 mg/dL, programar ejercicio al menos cada 48 horas para sostener la translocación de GLUT4 y exigir calzado protector con revisión diaria de pies según PAGA 2018, garantizamos un entrenamiento seguro."
