# KIN-265: Mod 07 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 07 Coaching Sprint Simulation: Daily Blood Sugar & Weight Management Checks

Sesión de Coaching del Módulo 07: Patologías Metabólicas y Protocolos de Seguridad Clínica

- Metabolic Syndrome Diagnostic Cluster (≥3 of 5 Risk Factors): Abdominal obesity (>40 in men / >35 in women), elevated triglycerides (≥150 mg/dL), low HDL (<40/50 mg/dL), elevated BP (≥130/85 mmHg), and elevated fasting glucose (≥100 mg/dL). En palabras sencillas: Conjunto de 3 o más factores de riesgo—cintura amplia, triglicéridos altos, colesterol bueno bajo, presión alta y glucosa elevada—que responden muy bien al ejercicio.
- Cardiometabolic Volume Progression (150 → 300 Min/Week): Progressing aerobic volume from 150 toward 250–300 minutes/week of moderate low-impact activity maximizes visceral fat reduction and lipid profile improvement. En palabras sencillas: Avanzar gradualmente de 150 a 250–300 minutos por semana de actividad aeróbica de bajo impacto para reducir grasa abdominal y mejorar triglicéridos.
- Combined Aerobic + Resistance Metabolic Synergy: Pairing aerobic conditioning with ≥2 days/week of large-muscle-group resistance training increases skeletal muscle glucose disposal and resting insulin sensitivity. En palabras sencillas: Sumar al menos 2 días de fuerza al cardio semanal multiplica la capacidad de tus músculos para limpiar el azúcar y la grasa de la sangre.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Safety auditing means catching clinical red flags before an exercise session begins. For individuals with diabetes, exercising with blood sugar below 100 mg/dL can cause fainting and seizures. Learning how to apply the Rule of 15 and monitor blood pressure ensures safe and empowering physical activity.


#### En Palabras Sencillas (Norteño Context)

Ser auditor de seguridad es como ser el copiloto en un viaje largo: antes de arrancar revisas que el carro traiga aceite y gasolina para no quedarte tirado en el monte. Si los términos técnicos se ponen pesados, concéntrate primero en saber qué hacer si a un cliente le baja el azúcar de repente.

- KIN-265.7.1.AY26-27: Prescribe aerobic and resistance exercise programming for individuals with metabolic syndrome and Type 2 Diabetes following PAGA 2018 and ACSM 12th Edition guidelines. Prescribir ejercicio aeróbico y de fuerza para personas con síndrome metabólico y diabetes tipo 2 según PAGA 2018 y ACSM.
- KIN-265.7.2.AY26-27: Execute clinical safety auditing protocols for glycemic control (100–250 mg/dL safety window), hypoglycemia management (Rule of 15), and hemodynamic stop criteria. Ejecutar protocolos de auditoría de seguridad para control glucémico (ventana 100-250 mg/dL), manejo de hipoglucemia (Regla del 15) y criterios hemodinámicos de parada.
- Module Window / Ventana del Módulo: Opens Tuesday, September 29, 2026, at 12:00 AM MST Abre el martes, 29 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 5, 2026, at 11:59 PM MST Lunes, 5 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Coaching Sprint Benchmark (10/7/0 Mastery Scale) Ponderación para sesiones semanales de coaching y simulación

### Your Weekly Win: Mastering Metabolic Safety Gates & Glycemic Windows

As an exercise professional, your primary responsibility is client safety. While physical training powerfully improves insulin sensitivity, exertional drops in blood glucose can lead to sudden loss of consciousness. Knowing the exact clinical boundaries—the 100 to 250 mg/dL pre-exercise window , the Rule of 15 (15 grams of fast carbs, wait 15 minutes), and hemodynamic redlines—empowers you to coach with confidence. Select your coaching track below, consult your AI Socratic Coach, and claim your weekly coaching win!

¿Cómo garantizar la seguridad metabólica? Conocer la ventana de seguridad glucémica (100-250 mg/dL) y aplicar la Regla del 15 ante una hipoglucemia previene emergencias médicas. ¡Seleccione su ruta y dialogue con su Coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Selección de Escenario de Simulación Clínica

Scenario: Cardiac and metabolic rehab client (David, 56) with elevated blood pressure and Type 2 Diabetes attempting high-intensity interval training.

Scenario: Somerton walking group participant (Elena, 58) arriving with blood sugar of 88 mg/dL (<100 mg/dL floor) feeling shaky and weak.

Scenario: Masters endurance cyclist (Carlos, 45) experiencing post-exercise hypotension and delayed hypoglycemia after long desert rides.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's primary metabolic safety challenge.
- Clinical Safety Analysis: Explain PAGA 2018 and ACSM metabolic guidelines, the 100–250 mg/dL glycemic window, and hemodynamic redlines.
- My Clinical Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository / EXW265_M07_Quiz_Sprint.pdf .
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying why enforcing the $100\text{–}250\text{ mg/dL}$ pre-exercise glycemic window, never skipping the 48-hour resistance/aerobic gap for Type 2 Diabetes, and avoiding rapid-insulin injection into active limbs in Yuma's heat protect your client.

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

- Chosen Track & Client: Track 2 - Community & Public Health Path (Elena, 58 yrs, Somerton walking club).
- Clinical Safety Analysis: Elena arrived with a pre-walk blood glucose of 88 mg/dL, which is below the safe clinical floor of 100 mg/dL. Walking increases muscular glucose uptake without insulin; without an intervention, her glucose would drop further into severe hypoglycemia (<70 mg/dL). Under ACSM and PAGA guidelines, exercise must be withheld until blood glucose is restored.
- My Clinical Safety Audit: Administer the clinical "Rule of 15": give Elena 15 grams of fast-acting carbohydrate (e.g., 4 oz apple juice or 3–4 glucose tablets), have her rest seated in the shade, and recheck capillary glucose after 15 minutes. She may only begin her walk once her glucose is at or above 100 mg/dL.
- My Memorable Coaching Takeaway: EN: "Checking blood sugar before you move turns exercise into life-saving medicine instead of an emergency!" ES: "¡Revisar el azúcar en la sangre antes de moverte convierte el ejercicio en una medicina que salva vidas en vez de una emergencia!"
- EN: "Checking blood sugar before you move turns exercise into life-saving medicine instead of an emergency!"
- ES: "¡Revisar el azúcar en la sangre antes de moverte convierte el ejercicio en una medicina que salva vidas en vez de una emergencia!"
- Repository Verification: Confirmed saved to EXW_Professional_AI_Repository / EXW265_M07_Quiz_Sprint.pdf .
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, generic weight-loss workouts ignore the acute glycemic hazards of Type 2 Diabetes and Metabolic Syndrome in Yuma's heat. Because skeletal muscle contraction triggers insulin-independent GLUT4 glucose uptake while heat vasodilation accelerates subcutaneous insulin absorption, starting exercise below 100 mg/dL or injecting rapid-acting insulin into an active thigh can cause sudden hypoglycemia. By enforcing the 100–250 mg/dL pre-exercise gate, administering a 15-gram fast-acting carbohydrate snack when below 100 mg/dL, and scheduling PAGA 2018 bouts so no more than 48 consecutive hours pass without movement, we maintain continuous insulin sensitivity safely. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu


### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 07 (Mod 07 Coaching Sprint: Daily Blood Sugar & Weight Management Checks)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 07 Simulación de Coaching: Patologías Metabólicas y Seguridad

Sesión Rápida de Coaching Clínico: Ventana Glucémica y Parámetros Hemodinámicos


### En Palabras Sencillas: Guía de Navegación

Antes de leer los detalles técnicos, aquí está la versión corta: Ser auditor de seguridad significa detectar alertas médicas antes de iniciar el ejercicio. Para personas con diabetes, hacer ejercicio con menos de 100 mg/dL de azúcar puede provocar mareos y desmayos. Aplicar la Regla del 15 y vigilar la presión asegura un entrenamiento seguro y positivo.


#### Contexto Norteño Regional

Ser auditor de seguridad es como ser el copiloto en un viaje largo: antes de arrancar revisas que el carro traiga aceite y gasolina para no quedarte tirado en el monte. Si los términos técnicos se ponen pesados, concéntrate primero en saber qué hacer si a un cliente le baja el azúcar de repente.


### Fase 1: Selección de Escenario de Simulación Clínica

Elija entre la Ruta 1 (David, clínica), Ruta 2 (Elena, comunitaria) o Ruta 3 (Carlos, deportiva). Copie los datos con delimitadores ### y consulte a su Coach de IA con la plantilla rápida.


### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Especifique su ruta y desafío metabólico.
- Análisis de Seguridad Clínica: Explique la ventana glucémica de 100-250 mg/dL y las normas de PAGA/ACSM.
- Mi Ajuste de Seguridad: Presente su corrección clínica (Regla del 15, control de presión).
- Mi Frase Inolvidable de Coaching: Escriba su frase en inglés y español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica justificando la ventana glucémica segura ($100\text{–}250\text{ mg/dL}$) y la regla de no dejar pasar más de 48 horas sin ejercicio bajo PAGA 2018 en Yuma.

### Accesibilidad Universal (ARS)

Todos los materiales de KIN-265 cumplen con UDL y WCAG 2.1 AA. Contacte a AccessABILITY Resource Services (ARS), Edificio 3C del Campus de Yuma: access@azwestern.edu .

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 07 Quick Return Navigation / Regreso Rápido al Módulo 07:

La Verificación Activa (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, iniciar ejercicio con glucosa menor a 100 mg/dL o bajo el calor de Yuma sin control glucémico arriesga una hipoglucemia aguda porque la contracción muscular activa receptores GLUT4 y el calor acelera la absorción de insulina. Aplicando la ventana segura de 100–250 mg/dL y evitando más de 48 horas consecutivas sin actividad según PAGA 2018, mantenemos la sensibilidad a la insulina con total seguridad."
