# KIN-265: Mod 07 Overview Metabolic Syndrome And Blood Sugar Management

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 07 Overview: Metabolic Syndrome & Blood Sugar Management

Diabetes Mellitus, Síndrome Metabólico y Cinética de la Glucosa en el Ejercicio


### Welcome to Module 07: Metabolic Syndrome & Blood Sugar Management

Welcome to Week 7! This week, we focus specifically on Type 1 and Type 2 Diabetes Mellitus and Metabolic Syndrome . When prescribing physical activity for individuals with metabolic dysregulation, your primary clinical objective is to manage glucose uptake kinetics, prevent acute exercise-induced hypoglycemia or hyperglycemia, and enhance insulin sensitivity across long-term physiological adaptations.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in our Single Source of Truth (SSoT)—the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —you will audit baseline glycemic metrics wrapped in our mandatory delimiter protocol (### BEGIN CLIENT PROFILE ###), apply federal safety windows (pre-exercise blood glucose targets of 100 to 250 mg/dL), and construct multi-component exercise routines tailored across your chosen career track in Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 29, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 1, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 4, 2026, at 11:59 PM MST
- Lab 07 Direct Submission / Entrega de Laboratorio: Monday, October 5, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 07 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze the pathophysiological mechanisms of insulin resistance, GLUT4 translocation kinetics, and the risks of exercise-induced hypoglycemia or hyperglycemia. Analizar los mecanismos fisiopatológicos de la resistencia a la insulina, la translocación de GLUT4 y los riesgos de hipoglucemia o hiperglucemia inducidas por el ejercicio.
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) metabolic safety mandates, establishing pre-exercise blood glucose screening rules (100 to 250 mg/dL window; carbohydrate ingestion protocols for readings under 100 mg/dL) using the Safety Auditor protocol. Aplicar mandatos de PAGA 2018 regulando reglas de evaluación glucémica previa al ejercicio (ventana de 100 a 250 mg/dL) utilizando el protocolo del Auditor de Seguridad.
- CLO 3 (Problem Solving): Formulate an individualized aerobic and resistance prescription that maximizes insulin sensitivity, accommodates continuous glucose monitor (CGM) telemetry, and integrates bilingual clinical communication. Diseñar una prescripción de ejercicio aeróbico y de fuerza que maximice la sensibilidad a la insulina, integre telemetría de MCG y comunicación clínica bilingüe.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit metabolic exercise prescription across your chosen career track:

Supervised outpatient exercise programming for patients with complex type 2 diabetes and peripheral neuropathy at Matador Clinical Partners (MCP), utilizing continuous glucose telemetry.

Developing culturally tailored, bilingual lifestyle intervention initiatives addressing metabolic syndrome and diabetes prevention across agricultural communities in Yuma County.

Managing type 1 diabetes mellitus in tactical operators and competitive athletes, optimizing carbohydrate periodization, and mitigating severe glycemic volatility during high-intensity stress.


### Module 07 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Clinical Readings: Glycemic Kinetics, Insulin Sensitivity & PAGA Standards
- Discussion Board 07: Delimiter Audits & Hypoglycemia Risk Mitigation
- Lab Assignment 07: Metabolic Prescription & Safety Auditor Simulation
- Module 07 Knowledge Check & Summary Wrap-Up

### Interactive Clinical Simulation & Outcome Gate (Module 07) / Simulación Clínica y Dominio de Resultados (Módulo 07)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 07 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 07 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 07 (Mod 07 Overview: Metabolic Syndrome & Blood Sugar Management)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 07 Visión General: Condiciones Metabólicas y Regulación Glucémica

Diabetes Mellitus, Síndrome Metabólico y Cinética de la Glucosa en el Ejercicio


### Bienvenido al Módulo 07: Patologías Metabólicas y Seguridad en el Ejercicio

¡Bienvenido a la Semana 7! Esta semana nos enfocamos en la Diabetes Mellitus Tipo 1 y Tipo 2 y el Síndrome Metabólico . Al prescribir actividad física para personas con alteración metabólica, su objetivo clínico principal es manejar la cinética de la glucosa, prevenir la hipoglucemia o hiperglucemia inducida por el esfuerzo y mejorar la sensibilidad a la insulina.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y las pautas de PAGA 2018 (2.ª edición) , auditará perfiles clínicos delimitados (### BEGIN CLIENT PROFILE ###), aplicará ventanas federales de seguridad glucémica (100 a 250 mg/dL) y construirá rutinas adaptadas a su ruta profesional.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 29 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 1 de octubre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 4 de octubre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 07: Lunes, 5 de octubre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar los mecanismos fisiopatológicos de la resistencia a la insulina, la translocación de GLUT4 y los riesgos glucémicos durante el esfuerzo.
- CLO 2 (Regla): Aplicar las normas de PAGA 2018 estableciendo reglas de evaluación previa al ejercicio (ventana de 100 a 250 mg/dL) mediante el protocolo del Auditor de Seguridad.
- CLO 3 (Solución): Formular prescripciones de ejercicio aeróbico y de fuerza maximizando la sensibilidad a la insulina e integrando telemetría de MCG.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la prescripción metabólica a través de su ruta profesional:

Programación de ejercicio ambulatorio supervisado para pacientes con diabetes tipo 2 y neuropatía en Matador Clinical Partners (MCP) con telemetría de glucosa.

Desarrollo de iniciativas comunitarias bilingües para la prevención del síndrome metabólico y la diabetes en el condado de Yuma.

Manejo de la diabetes tipo 1 en atletas y operadores tácticos, optimización de carbohidratos y mitigación de volatilidad glucémica.


### Ruta de Aprendizaje del Módulo 07

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Clínicas Obligatorias: Cinética Glucémica, Sensibilidad a la Insulina y Normas PAGA
- Foro de Discusión 07: Auditorías con Delimitadores y Mitigación de Riesgos de Hipoglucemia
- Laboratorio 07: Prescripción Metabólica y Simulación del Auditor de Seguridad
- Comprobación de Conocimientos y Resumen del Módulo 07

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 07 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 07 Required Readings: Metabolic Syndrome & Blood Sugar Management →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 07 Discussion: Safe Exercise Windows for Metabolic Syndrome →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 07 Coaching Sprint: Daily Blood Sugar & Weight Management Checks →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 07 Lab: Metabolic Syndrome Exercise Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 07 Summary & Wrap-Up: Metabolic Syndrome & Blood Sugar Management →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
