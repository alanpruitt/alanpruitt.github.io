# KIN-265: Mod 02 Overview Type 2 Diabetes And Blood Sugar Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Overview: Type 2 Diabetes & Blood Sugar Safety

Visión General del Módulo 02: Diabetes Tipo 2, Puertas Glucémicas y Adaptación Clínica

Welcome to Module 02 of Exercise for Special Populations! This week, we analyze clinical exercise prescription for Type 2 Diabetes Mellitus (T2DM), pre-activity blood glucose gating thresholds, and sensory peripheral neuropathy adaptations using our academic Single Source of Truth (SSoT): the ADA/ACSM Joint Position Statement on Exercise and Type 2 Diabetes and the 2018 Physical Activity Guidelines for Americans (Chapter 6: Chronic Conditions) .

¡Bienvenido al Módulo 02 de Ejercicio para Poblaciones Especiales! Esta semana analizaremos la prescripción clínica de ejercicio para Diabetes Tipo 2 (DM2), los umbrales de seguridad glucémica y las adaptaciones para neuropatía periférica según la postura conjunta de la ADA y el ACSM.

- KIN-265.2.1.AY26-27: Execute pre-activity clinical screening and evaluate blood glucose safety gates (<100, 100–250, >250 mg/dL with ketones) against ADA/ACSM clinical standards. Ejecutar la evaluación clínica previa y auditar las puertas de seguridad glucémica (<100, 100–250, >250 mg/dL con cetonas) según normas de la ADA/ACSM.
- KIN-265.2.4.AY26-27: Prescribe adapted exercise modalities (non-weight-bearing) and calculate personalized 40%–59% HRR training zones using the Gellish formula for metabolic clients. Prescribir modalidades adaptadas (sin impacto) y calcular zonas de entrenamiento de 40%–59% HRR usando la fórmula de Gellish para clientes metabólicos.

### Learning Objectives / Objetivos de Aprendizaje

- Apply ADA Glycemic Gates: Execute pre-exercise blood glucose screening protocols: enforcing the Rule of 15 for blood glucose <100 mg/dL, clearing the 100–250 mg/dL safe therapeutic window, and testing for ketones if >250 mg/dL to prevent diabetic ketoacidosis (DKA). Aplicar las puertas glucémicas de la ADA: Regla del 15 si es <100 mg/dL, zona segura de 100–250 mg/dL y prueba de cetonas si es >250 mg/dL para evitar cetoacidosis.
- Calculate Gellish HRR Training Zones: Calculate age-predicted Max Heart Rate using the Gellish formula [207 − (0.7 × Age)], determine Heart Rate Reserve (HRR), and establish moderate-intensity (40%–59% HRR) aerobic training zones. Calcular la FC Máx con la fórmula de Gellish [207 − (0.7 × Edad)], determinar la Reserva de Frecuencia Cardíaca (HRR) y fijar zonas de 40%–59% HRR.
- Prescribe Neuropathy Adaptations: Select joint- and skin-protective non-weight-bearing exercise modalities (recumbent cycling, water aerobics) and design daily hand-mirror foot inspection protocols to prevent silent ulcerations. Prescribir modalidades sin impacto (bicicleta reclinada, natación) y protocolos de inspección de pies con espejo para prevenir úlceras por fricción.

### Module Checklist / Lista de Tareas del Módulo:

- Required Clinical Readings: Review the ADA/ACSM Joint Position Statement on Type 2 Diabetes and Gellish HRR formulas. Lecturas Clínicas: Revisar la postura conjunta de ADA/ACSM sobre Diabetes y las fórmulas de Gellish.
- Discussion 02: Post your clinical screening audit by Thursday 11:59 PM MST and submit peer evaluations by Sunday 11:59 PM MST. Discusión 02: Publicación inicial el jueves y respuestas a compañeros el domingo.
- Coaching Sprint 02: Chat with your AI Clinical Preceptor, complete your special populations reflection, and submit plain-text responses. Sesión de Coaching 02: Consultar al Preceptor de IA y entregar respuestas en texto plano.
- Lab 02: Complete the Type 2 Diabetes clinical screening and HRR audit and submit directly into the Canvas text box by Monday 11:59 PM MST. Laboratorio 02: Completar la auditoría de evaluación y HRR en Canvas antes del lunes.

### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 02 (Mod 02 Overview: Type 2 Diabetes & Blood Sugar Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### UDL & ACCESSIBILITY / ACCESIBILIDAD Y UDL

English: All Module overview materials and learning activities in KIN-265 follow Universal Design for Learning (UDL) principles. This page uses a text-first, mobile-responsive layout designed for 100% compatibility with screen readers, assistive technologies, and AI note-taking tools.

Español: Todos los materiales de descripción del curso en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando total accesibilidad para lectores de pantalla.

Process Over Product Evaluation / Evaluación de Proceso:

Weekly learning objectives and clinical audits emphasize patient safety, glycemic control, and evidence-based clinical reasoning over rote testing pressure.

AccessABILITY Resource Services (ARS) Support / Servicios de Apoyo:

3C Building, Yuma Campus | Phone: (928) 344-7674 | Email: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Visión General del Módulo 02: Diabetes Tipo 2 y Puertas Glucémicas Clínicas

Evaluación Previa, Control Glucémico y Adaptación para Neuropatía

¡Bienvenido al Módulo 02 de Ejercicio para Poblaciones Especiales! Esta semana analizaremos la prescripción clínica de ejercicio para Diabetes Tipo 2 (DM2), los umbrales de seguridad glucémica antes del ejercicio y las adaptaciones para neuropatía sensorial periférica según la postura conjunta de la ADA y el ACSM y las Guías de Actividad Física de 2018 (Capítulo 6: Condiciones Crónicas).


### Objetivos de Aprendizaje

- Aplicar Puertas Glucémicas de la ADA: Aplicar los protocolos de evaluación de glucosa antes de entrenar: ejecutar la Regla del 15 si es <100 mg/dL, verificar la zona segura de 100–250 mg/dL y revisar cetonas si es >250 mg/dL para prevenir la cetoacidosis diabética (CAD).
- Calcular Zonas de Entrenamiento HRR con Gellish: Calcular la Frecuencia Cardíaca Máxima con la fórmula de Gellish [207 − (0.7 × Edad)], determinar la Reserva de Frecuencia Cardíaca (HRR) y establecer zonas aeróbicas moderadas (40%–59% HRR).
- Prescribir Adaptaciones para Neuropatía: Seleccionar modalidades de ejercicio sin impacto (bicicleta reclinada, aeróbicos acuáticos) y estructurar inspecciones diarias de pies con espejo de mano para prevenir úlceras silenciosas.

### Lista de Tareas del Módulo:

- Lecturas Clínicas Obligatorias: Revisar la postura conjunta de ADA/ACSM sobre Diabetes y las fórmulas de Gellish.
- Discusión 02: Publicación inicial antes del jueves y respuestas a compañeros antes del domingo.
- Sesión de Coaching 02: Consultar al Preceptor de IA y enviar respuestas en texto plano.
- Laboratorio 02: Completar la evaluación clínica de Diabetes Tipo 2 y la auditoría de HRR en Canvas antes del lunes 11:59 PM MST.

### ACCESIBILIDAD Y UDL

Todos los materiales de visión general en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando total accesibilidad para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu


### Module 02 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 02 Required Readings: Type 2 Diabetes & Blood Sugar Safety →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 02 Discussion: Exercise & Blood Sugar Control in Type 2 Diabetes →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 02 Coaching Sprint: Preventing Low Blood Sugar During Workouts →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 02 Lab: Type 2 Diabetes Exercise & Foot-Safety Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 02 Summary & Wrap-Up: Type 2 Diabetes & Blood Sugar Safety →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
