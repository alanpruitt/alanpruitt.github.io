# KIN-265: Mod 02 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 02 Lab & Simulation: Type 2 Diabetes Exercise & Foot-Safety Audit

Laboratorio del Módulo 02: Programación de Ejercicio para Diabetes Tipo 2 y Resistencia a la Insulina

- Insulin-Independent GLUT4 Glucose Uptake: Contracting skeletal muscle translocates GLUT4 transporters to the cell membrane without needing insulin, lowering blood glucose for 24–48 hours post-exercise. En palabras sencillas: Al moverse, el músculo absorbe azúcar de la sangre por sí mismo durante 24 a 48 horas, ayudando a controlar la diabetes tipo 2.
- 48-Hour Maximum Inter-Session Gap (Type 2 Diabetes Rule): Because exercise-induced insulin sensitivity fades within 48 hours, clients with diabetes should never go more than 2 consecutive days without aerobic activity. En palabras sencillas: Como el efecto del ejercicio sobre la glucosa dura unas 48 horas, nunca debemos dejar pasar más de 2 días seguidos sin actividad aeróbica.
- Pre-Exercise Hypoglycemia Safety Gate (<100 mg/dL): If pre-exercise blood glucose is <100 mg/dL (especially on insulin or sulfonylureas), ingest 15–30 g fast-acting carbohydrates and recheck in 15 minutes before starting. En palabras sencillas: Si el azúcar antes de entrenar está abajo de 100 mg/dL, el paciente debe tomar 15–30 g de carbohidrato rápido y volver a medir a los 15 minutos.
Welcome to your second practical laboratory assignment in Special Populations! This week, we analyze exercise prescription parameters for individuals with metabolic dysfunction. You will design a specialized, clinically safe conditioning program for a client with Type 2 Diabetes Mellitus (T2DM) presenting with metabolic complications, utilizing our primary academic Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, Chapter 6) and the ADA/ACSM Joint Position Statement on Exercise and Type 2 Diabetes .

Bienvenido a su segunda práctica de laboratorio de Ejercicio para Poblaciones Especiales. Esta semana analizaremos los parámetros de prescripción de ejercicio para personas con disfunción metabólica y diabetes tipo 2 utilizando las pautas de PAGA 2018 y estándares clínicos de seguridad glucémica de la ADA/ACSM.

- KIN-265.2.3.AY26-27: Formulate physical activity protocols to enhance insulin sensitivity and GLUT4 translocation while mitigating neuropathic foot trauma. Formular protocolos de actividad física para mejorar la sensibilidad a la insulina y la translocación de GLUT4 evitando el trauma neuropático en el pie.
- KIN-265.2.4.AY26-27: Audit clinical hypoglycemia thresholds (glucose <100 mg/dL), ketone gating rules, and pre-exercise carbohydrate strategies under high-heat conditions. Auditar umbrales clínicos de hipoglucemia (glucosa <100 mg/dL), reglas de cetonas y carbohidratos previos en calor extremo.
- Module Window / Ventana del Módulo: Opens Tuesday at 12:00 AM MST / Abre el martes a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday by 11:59 PM MST / Lunes a las 11:59 PM MST
- Submission Format / Formato: Text-only entry typed or pasted directly into the Canvas text box. (No file uploads accepted). / Texto directo en Canvas (No se aceptan archivos adjuntos).

### Lab Objectives / Objetivos del Laboratorio

- Identify critical pre-exercise blood glucose gating thresholds and emergency interventions to prevent exercise-induced hypoglycemia or severe hyperglycemia. Identificar los umbrales críticos de glucosa en sangre previos al ejercicio e intervenciones de emergencia.
- Formulate non-weight-bearing or low-shear alternative activities to bypass mechanical foot injuries or vascular strain in patients presenting with diabetic complications. Formular actividades sin soporte de peso corporal o de bajo cizallamiento para evitar lesiones mecánicas en los pies.
- Calculate target exercise intensity ranges utilizing the Gellish Heart Rate Reserve (HRR) formula for an insulin-resistant client. Calcular los rangos de intensidad de ejercicio objetivo utilizando la fórmula de Gellish y Reserva de Frecuencia Cardíaca (HRR).
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-02

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos Clínicos

Choose ONE of the three career-aligned clinical tracks below before invoking Google Gemini:

Focus: Obese, insulin-dependent T2DM patient (T.M., 49) presenting with advanced diabetic peripheral neuropathy, bilateral mid-calf sensory loss, and prior calcaneus ulcer history.

Focus: Agricultural community worker with T2DM (S.R., 54) managing heat exposure, oral hypoglycemic medication timing, and foot ulcer prevention.

Focus: Masters recreational athlete with T2DM (E.V., 51) optimizing glucose disposal and muscle insulin sensitivity through structured resistance and ergometer training.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI along with your chosen track data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas (Solo Texto Plano)

- Selected Track & Client Baseline: Declare chosen track and baseline clinical profile. Indique la ruta seleccionada y el perfil clínico del cliente.
- Part 1: Pattern Recognition (BMI & Biomechanical Risk): Calculate BMI, classify weight category, and explain the mechanical shear risks of high-impact exercise with peripheral neuropathy or ulcer history. Parte 1: Reconocimiento de Patrones (Calcule el IMC, clasifique el peso y explique los riesgos de impacto ante neuropatía).
- Part 2: Rule Application & Clinical Calculations: Detail pre-exercise blood glucose gating rules (<100, 100–250, >250 mg/dL with ketones) and calculate 40% to 59% HRR range using the Gellish formula. Parte 2: Aplicación de Reglas y Cálculos Clínicos (Compuertas de glucosa y rango de 40% a 59% HRR con Gellish).
- Part 3: Solving the Gap & Bilingual Client Card: Prescribe a 4-week FITT-VP plan (non-weight-bearing modalities, weekly progression, and diabetic foot care protocols) with a 2-sentence bilingual client card in English and Spanish. Parte 3: Resolución Práctica y Tarjeta Bilingüe (Plan FITT-VP de 4 semanas sin impacto y tarjeta bilingüe de 2 oraciones).
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): In 150-word minimum (150+ words) written in your own clinical voice, justify why your non-weight-bearing modality selection, Gellish 40–59% HRR intensity zone, and strict 48-hour gap rule protect this Type 2 Diabetes client from plantar ulceration and glycemic volatility in Yuma. Parte 4: Verificación Activa Obligatoria (mínimo 150 palabras en su propia voz humana justificando la modalidad sin impacto, el rango 40–59% HRR y la regla de no pasar más de 48 horas sin ejercicio).
- Repository Verification: Confirm that your complete AI prompt exchange has been saved to your Google Drive repository ( EXW_Professional_AI_Repository ). Confirmación del Repositorio: Verifique que el registro de IA esté guardado en su carpeta de Google Drive.

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Part 1: Pattern Recognition (Detección de Patrones): Key Point — Biometric Conversions: Weight = 265 lbs / 2.2 = Outcome 120.5: kg . Height = 69 in × 0.0254 = Outcome 1.75: meters . Key Point — BMI Equation: 120.5 / (1.75 × 1.75) = 120.5 / 3.0625 = Outcome 39.35: kg/m² (Class II Obesity) . Key Point — Neuropathic Contraindications: Complete sensory numbness below mid-calf with prior calcaneus ulcer history strictly contraindicates high-impact weight-bearing exercise (treadmill walking/running). Repetitive vertical impact and friction cause undetected skin shear and blisters that rapidly progress to non-healing plantar ulcers or osteomyelitis.

Part 2: Rule Application & Target Calculations (ADA/ACSM & Gellish): Key Point — Pre-Exercise Blood Glucose Gates: Key Point: <100 mg/dL: Ingest 15–30g fast-acting carbs; retest in 15 min; delay exercise until glucose >100 mg/dL. Key Point: 100 to 250 mg/dL: Safe therapeutic zone; proceed with conditioning. Key Point: >250 mg/dL: Test urine ketones. If ketones are present, cancel exercise immediately; if negative, exercise with caution. Key Point — Gellish Max HR (Age 49): 207 − (0.7 × 49) = 207 − 34.3 = Outcome 172.7: bpm (~173 bpm) . Key Point — Heart Rate Reserve (HRR): 173 − 78 (Resting HR) = 95 bpm . Key Point — Target Intensity Range (40% to 59% HRR): (95 × 0.40) + 78 = 116 bpm to (95 × 0.59) + 78 = 134 bpm. Target Zone: 116 to 134 bpm .

Part 3: Solving the Gap (Resolución de Intervención): Key Point — Modalities: Recumbent stationary cycling and seated upper-body arm ergometry to eliminate plantar foot shear forces. Key Point — FITT-VP: 3 non-consecutive days/week at 116 to 134 bpm (RPE 11–13). Begin at 20 mins/session, progressing by 5 mins weekly up to 40 mins. Key Point — Foot Care Protocols: Inspect feet before and after every workout with a hand mirror (specifically examining plantar surfaces and interdigital spaces); wear seamless synthetic socks and professionally fitted wide-toe-box orthotic athletic shoes.

EN: "Check your blood sugar before exercising; if it is under 100, eat a 15-gram carb snack first. Ride a recumbent bike at a moderate pace and check your feet with a mirror after every workout to prevent blisters."

ES: "Revise su glucosa antes de ejercitarse; si está por debajo de 100, consuma 15 gramos de carbohidratos primero. Use una bicicleta reclinada a paso moderado y revise sus pies con un espejo tras cada sesión para evitar ampollas."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M02_Diabetes_Prescription_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 02) / Simulación Clínica y Dominio de Resultados (Módulo 02)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 02 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 02 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 02 (Mod 02 Lab: Type 2 Diabetes Exercise & Foot-Safety Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 follow Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This assignment is text-first, untimed, and screen-reader verified.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando accesibilidad total para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 02 Laboratorio y Simulación: Diabetes Tipo 2 y Auditoría Glucémica

Programación de Ejercicio, Control Glucémico y Prevención Neuropática


### Prescripción de Ejercicio en Diabetes Tipo 2 y Resistencia a la Insulina

En este laboratorio, diseñará una prescripción clínica de acondicionamiento para un cliente con diabetes tipo 2 utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , aplicando las compuertas de seguridad glucémica y seleccionando modalidades sin carga de peso.


### Fase 1: Selección de Escenario de Simulación Clínica #265-02

Elija UNA de las tres rutas profesionales para realizar su auditoría:

Paciente con Diabetes Tipo 2 insulino-dependiente (T.M., 49 años) con neuropatía periférica avanzada y antecedente de úlcera calcánea.

Trabajadora agrícola con Diabetes Tipo 2 (S.R., 54 años) bajo calor extremo (42°C / 108°F) tomando sulfonilurea (Glipizida).

Atleta recreativo master con Diabetes Tipo 2 (E.V., 51 años) optimizando la captación de glucosa con entrenamiento aeróbico y fuerza.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


### Fase 3: Estructura de Entrega en Canvas (Solo Texto Plano)

- Ruta y Cliente: Indique la ruta seleccionada y el perfil clínico del cliente.
- Parte 1 (Reconocimiento de Patrones): Calcule el IMC, clasifique el peso y explique los riesgos de impacto ante neuropatía.
- Parte 2 (Reglas y Cálculos): Detalle las compuertas de glucosa y calcule el rango de 40% a 59% HRR con Gellish.
- Parte 3 (Solución y Tarjeta Bilingüe): Prescriba un plan FITT-VP de 4 semanas sin impacto y redacte la tarjeta bilingüe de 2 oraciones.
- Parte 4 (Verificación Activa Obligatoria): En mínimo 150 palabras (150+ palabras) escritas en su propia voz clínica, justifique por qué la modalidad sin impacto, la zona de 40–59% HRR con Gellish y la regla de máximo 48 horas protegen al paciente diabético en Yuma.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Evaluación en Español (Escala 10/7/0)


### Modelo de Respuesta de Alta Fidelidad 10/10 en Español

Parte 1: Reconocimiento de Patrones: Peso = 120.5 kg, Altura = 1.75 m. IMC = 39.35 kg/m² (Obesidad Clase II). La neuropatía periférica con pérdida sensorial distal bajo la pantorrilla y antecedente de úlcera calcánea contraindica estrictamente ejercicios con impacto vertical (caminata/trote en banda) por riesgo de fuerzas de cizallamiento y ampollas no percibidas que progresen a úlceras u osteomielitis.

Parte 2: Aplicación de Reglas y Cálculos Clínicos: Key Point — Compuertas Glucémicas ADA/ACSM: Key Point: <100 mg/dL: Ingerir 15 a 30 g de carbohidratos rápidos; reevaluar en 15 min; posponer ejercicio hasta glucosa >100 mg/dL. Key Point: 100 a 250 mg/dL: Zona segura; proceder con el entrenamiento. Key Point: >250 mg/dL: Medir cetonas. Si están presentes, cancelar de inmediato; si es negativo, ejercitar con precaución. Key Point — FC Máxima (Gellish, Edad 49): 207 − (0.7 × 49) = 172.7 lpm (~173 lpm). Key Point — Reserva de FC (HRR): 173 − 78 (FC Reposo) = 95 lpm . Key Point — Rango Moderado (40% a 59% HRR): (95 × 0.40) + 78 = 116 lpm a (95 × 0.59) + 78 = 134 lpm. Rango Meta: 116 a 134 lpm .

Parte 3: Resolución de la Brecha: Key Point — Modalidades: Bicicleta estacionaria reclinada y ergómetro de brazos en posición sentada para eliminar el cizallamiento en los pies. Key Point — FITT-VP: 3 días no consecutivos/semana a 116–134 lpm (RPE 11–13). Iniciar con 20 min/sesión, progresando 5 min por semana hasta alcanzar 40 min. Key Point — Cuidado del Pie: Inspección visual con espejo antes y después de cada sesión (plantas y entre los dedos); uso de calcetines sintéticos sin costuras y calzado ortopédico con horma ancha. Tarjeta Bilingüe: "Revise su glucosa antes de ejercitarse; si está por debajo de 100, consuma 15 gramos de carbohidratos primero. Use una bicicleta reclinada a paso moderado y revise sus pies con un espejo tras cada sesión para evitar ampollas."

Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M02_Diabetes_Prescription_Audit.pdf


### ACCESIBILIDAD Y UDL

Todos los materiales de laboratorio en KIN-265 cumplen con los principios del Diseño Universal para el Aprendizaje (UDL) y los estándares WCAG 2.1 AA, garantizando total accesibilidad para lectores de pantalla.

Servicios AccessABILITY (ARS) | Edificio 3C, Campus de Yuma | Teléfono: (928) 344-7674 | Correo: access@azwestern.edu

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi criterio clínico, prescribir caminata en banda a un paciente con obesidad y neuropatía periférica representa un peligro biomecánico: el peso corporal multiplica las fuerzas de reacción del suelo mientras la pérdida de sensibilidad oculta microtraumas hasta formar una úlcera plantar. Al descartar las recomendaciones genéricas de caminata de la IA y prescribir bicicleta reclinada sin impacto a 40–59% HRR (fórmula de Gellish), activamos los transportadores GLUT4 para reducir la glucosa sin fricción en los pies. Cumplir la regla de no dejar pasar más de 48 horas entre sesiones mantiene la sensibilidad a la insulina con total seguridad."

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 02 Quick Return Navigation / Regreso Rápido al Módulo 02:
