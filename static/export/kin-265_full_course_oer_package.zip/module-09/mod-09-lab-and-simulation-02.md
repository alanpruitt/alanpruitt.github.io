# KIN-265: Mod 09 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Lab & Simulation: Heart Condition Exercise Plan & Safety Audit

- Chronotropic Incompetence & Pacemaker/ICD Rate Ceilings: Clients with pacemakers or implantable cardioverter-defibrillators (ICDs) have programmed heart-rate limits; target HR must remain ≥10–15 bpm below the ICD shock threshold. En palabras sencillas: En pacientes con marcapasos o desfibrilador (ICD) mantenemos el pulso al menos 10 a 15 latidos por debajo del límite programado por su cardiólogo.
- Sternal & Upper-Limb Lead Precautions: Avoiding vigorous overhead shoulder elevation or heavy chest loading after pacemaker implantation or sternotomy until full surgical clearance is granted. En palabras sencillas: Cuidar los movimientos bruscos de hombro por encima de la cabeza o carga en el pecho tras cirugía cardíaca o colocación de marcapasos.
- Thermal Cardiac Strain in Yuma Heat: High ambient heat forces the heart to pump extra blood to the skin while sweat losses reduce stroke volume; cardiac patients must exercise in climate-controlled indoor spaces. En palabras sencillas: El calor extremo obliga al corazón a trabajar el doble; todo paciente cardíaco en Yuma debe ejercitarse bajo techo con aire acondicionado.

### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Blood pressure medications like beta-blockers keep heart rates artificially low, so pulse rates cannot tell you how hard a cardiac patient is exercising. When training clients with hypertension or past heart attacks, you must use the Borg RPE (perceived exertion) scale to measure intensity. If systolic blood pressure rises above 220 mmHg or diastolic above 105 mmHg, stop exercise immediately.


#### En Palabras Sencillas (Norteño Context)

Si el cliente toma pastillas para la presión, el pulso no le va a subir aunque el cuerpo esté trabajando al máximo, como una troca con el velocímetro descompuesto. Si los términos técnicos se ponen pesados, concéntrate primero en vigilar el esfuerzo con la escala Borg RPE y medir la presión arterial antes y después.


### Cardiovascular Hemodynamics, Autonomic Blunting, & PAGA Federal Mandates

In this laboratory assignment, you will construct and audit a tailored exercise prescription for a client presenting with chronic cardiovascular pathologies (Post-Myocardial Infarction, Stage 2 Hypertension, or Metabolic Syndrome). Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will evaluate vascular compliance and beta-blockade chronotropic blunting, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety rules, and execute an AI-driven clinical simulation using Google Gemini.

En este laboratorio, construirá y auditará una prescripción de ejercicio adaptada para un cliente con patología cardiovascular, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y evaluando la hemodinámica y las pautas de PAGA 2018.

- KIN-265.9.1.AY26-27: Prescribe safe aerobic exercise intensity using the Borg RPE scale for clients with cardiovascular disease and altered heart rate responses across diverse career tracks. Prescribir intensidad de ejercicio aeróbico segura usando la escala Borg RPE para clientes con cardiopatías y respuestas cardíacas alteradas en diversas rutas profesionales.
- KIN-265.9.2.AY26-27: Audit clinical blood pressure safety limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de seguridad de presión arterial y aplicar protocolos de verificación de IA basados en delimitadores.
- Module Window / Ventana del Módulo: Opens Tuesday, October 13, 2026, at 12:00 AM MST Abre el martes, 13 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 19, 2026, at 11:59 PM MST Lunes, 19 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark (10/7/0 Mastery Scale) Ponderación para laboratorios semanales y simulaciones clínicas

### Lab Objectives / Objetivos del Laboratorio

- Audit hemodynamic alterations, blunted chronotropic heart rate responses from beta-blockade, and Valsalva pressure hazards during exertion. Auditar alteraciones hemodinámicas, respuestas cronotrópicas atenuadas por betabloqueadores y riesgos de presión por Valsalva durante el esfuerzo.
- Apply federal PAGA 2018 (2nd Ed.) mandates to establish blood pressure stop-test limits (SBP > 220 mmHg, DBP > 105 mmHg) and RPE exertion gating (Borg RPE 11–14). Aplicar las normas de la PAGA 2018 para establecer límites de interrupción por presión arterial (PAS > 220 mmHg, PAD > 105 mmHg) y control de esfuerzo por Borg RPE (11–14).
- Formulate a comprehensive 12-week cardiovascular exercise prescription with continuous breathing mechanics and a 2-sentence bilingual client instruction card in English and authentic Spanish. Formular una prescripción de ejercicio cardiovascular de 12 semanas con mecánica respiratoria continua y una tarjeta de instrucción bilingüe de 2 oraciones.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-09

Fase 1: Selección de Escenario de Simulación Clínica Clínico

Choose ONE of the three career-aligned tracks below before executing your AI diagnostic query:

Scenario: Clinical rehabilitation patient (Robert, 62) post-myocardial infarction taking Metoprolol (beta-blocker); presents with resting bradycardia (58 bpm), resting BP 130/82 mmHg, and requires safe Phase II aerobic progression.

Scenario: Senior community center participant (Elena, 71) with Stage 2 Hypertension (resting BP 162/98 mmHg, HR 74 bpm) and mild knee osteoarthritis seeking safe aerobic walking group participation in Yuma County.

Scenario: Law enforcement officer (Marcus, 45) with metabolic syndrome and borderline hypertension (resting BP 142/88 mmHg, resting HR 82 bpm); designing occupational tactical conditioning without excessive blood pressure elevation.


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Paso 2: Copie la plantilla y ejecute la auditoría clínica en Gemini Sandbox

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete clinical audit directly into the Canvas text box structured under the following numbered headers:

- Selected Track & Client Baseline: Declare chosen track, client initials, cardiovascular diagnosis, and resting vitals.
- Step 1: Pattern Recognition (Hemodynamics & Pharmacology): Analyze the client's hemodynamic pattern, beta-blocker blunting (or vascular resistance), and why standard heart rate formulas fail.
- Step 2: Rule Alignment (SSoT Clinical Audit - PAGA 2018): Cite federal PAGA 2018 cardiovascular safety rules, blood pressure stop-test criteria (SBP > 220 / DBP > 105), and subjective exertion gating using Borg RPE (11–14).
- Part 3: Clinical Solve (Active Verification & Client Card): In a mandatory text defense (approx. 150 words) written in your own clinical voice, justify why your 12-week cardiovascular exercise protocol strictly enforces PAGA 2018 safety gates, Borg RPE gating, and Valsalva avoidance for your patient. Conclude with a mandatory 2-sentence bilingual client instruction card in English and Spanish.
- Repository Verification: Confirm complete Gemini AI consultation log is exported and saved to Google Drive: EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Selected Track: Track 1 (Clinical & Chronic Disease Prevention Path) • Patient Robert (Age 62)

- Selected Track & Client Baseline: Client: Robert, 62-year-old post-myocardial infarction patient taking Metoprolol (50 mg BID) in Yuma, AZ. Biometrics: Resting BP = 130/82 mmHg | Resting HR = 58 bpm | Height: 178 cm | Weight: 84 kg. Primary Clinical Risk: Beta-blocker therapy suppresses sympathetic chronotropic response, rendering target heart rate formulas inaccurate and dangerous.
- Client: Robert, 62-year-old post-myocardial infarction patient taking Metoprolol (50 mg BID) in Yuma, AZ.
- Biometrics: Resting BP = 130/82 mmHg | Resting HR = 58 bpm | Height: 178 cm | Weight: 84 kg.
- Primary Clinical Risk: Beta-blocker therapy suppresses sympathetic chronotropic response, rendering target heart rate formulas inaccurate and dangerous.
- Step 1: Pattern Breakdown (Hemodynamics & Pharmacology): Autonomic Blunting: Metoprolol competitively antagonizes beta-1 adrenergic receptors in cardiac nodal tissue. Even during moderate aerobic exercise, Robert's heart rate will rise sluggishly, peaking far below standard age-predicted maximums ($220 - 62 = 158\text{ bpm}$). Relying on pulse rate to push him into a standard $65\%\text{ HRR}$ zone would overload myocardial oxygen demand and trigger myocardial ischemia. Hemodynamic Stability: Resting BP is currently controlled (130/82 mmHg). However, during aerobic exercise, peripheral vascular resistance must drop appropriately. Exercise must be terminated immediately if SBP breaches 220 mmHg or DBP breaches 105 mmHg.
- Autonomic Blunting: Metoprolol competitively antagonizes beta-1 adrenergic receptors in cardiac nodal tissue. Even during moderate aerobic exercise, Robert's heart rate will rise sluggishly, peaking far below standard age-predicted maximums ($220 - 62 = 158\text{ bpm}$). Relying on pulse rate to push him into a standard $65\%\text{ HRR}$ zone would overload myocardial oxygen demand and trigger myocardial ischemia.
- Hemodynamic Stability: Resting BP is currently controlled (130/82 mmHg). However, during aerobic exercise, peripheral vascular resistance must drop appropriately. Exercise must be terminated immediately if SBP breaches 220 mmHg or DBP breaches 105 mmHg.
- Step 2: Rule Alignment (SSoT Clinical Audit - PAGA 2018): Under PAGA 2018 (2nd Ed.) chronic condition standards, cardiac rehab participants must accumulate at least 150 minutes of moderate-intensity aerobic physical activity per week, progression permitting. Because beta-blockade invalidates heart rate monitoring, intensity must be gated strictly using the Borg Rating of Perceived Exertion (RPE 11–13, "Light" to "Somewhat Hard") on the 6–20 scale. Hemodynamic safety mandates: Exercise is paused immediately if SBP exceeds 220 mmHg, DBP exceeds 105 mmHg, or if angina symptoms, dizziness, or ventricular ectopy occur.
- Under PAGA 2018 (2nd Ed.) chronic condition standards, cardiac rehab participants must accumulate at least 150 minutes of moderate-intensity aerobic physical activity per week, progression permitting.
- Because beta-blockade invalidates heart rate monitoring, intensity must be gated strictly using the Borg Rating of Perceived Exertion (RPE 11–13, "Light" to "Somewhat Hard") on the 6–20 scale.
- Hemodynamic safety mandates: Exercise is paused immediately if SBP exceeds 220 mmHg, DBP exceeds 105 mmHg, or if angina symptoms, dizziness, or ventricular ectopy occur.
- Part 3: Clinical Solve (Active Verification & Client Card): Phase II Aerobic Conditioning (Weeks 1–6): Semi-recumbent cycle ergometer or treadmill walking 3 days/week, 25–30 minutes per session (warm-up 5 min at RPE 9; interval walking 20 min at RPE 11–13, 2.2 mph; cool-down 5 min at RPE 9). Resistance Conditioning (Weeks 4–12): Machine-based circuit (seated chest press, leg press, seated row), 2 sets x 12 reps at RPE 11–12. Strict avoidance of isometric holding and Valsalva maneuvers: coach continuous exhalation during concentric effort. Environmental Mitigation: Perform all exercise in an indoor, climate-controlled facility ($< 75^\circ\text{F}$) during Yuma summer months to avoid exacerbating myocardial workload. Active Verification: In my clinical reasoning, Robert's post-MI cardiac profile combined with beta-blocker therapy invalidates age-predicted heart rate formulas. Pushing him to meet an arbitrary pulse target would induce silent myocardial ischemia or dangerous ventricular arrhythmia. By gating his aerobic progression strictly to Borg RPE 11–13, we decouple cardiovascular conditioning from chronotropic blunting. Furthermore, coaching continuous exhalation mechanics prevents dangerous intrathoracic pressure spikes associated with the Valsalva maneuver, protecting against acute afterload surges and keeping blood pressure well below the 220/105 mmHg safety termination gate. Performing all exercise indoors eliminates Yuma's extreme thermal strain on myocardial oxygen demand. Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: EN: "Because your blood pressure medication holds your pulse low, never use heart rate monitors to judge your effort; instead, keep your exercise at a comfortable, conversational pace (RPE 11 to 13) and exhale steadily on every lift to protect your heart." ES: "Como su medicamento para la presión mantiene su pulso bajo, nunca use monitores de ritmo cardíaco para medir su esfuerzo; en su lugar, mantenga un paso cómodo donde pueda hablar (RPE 11 a 13) y exhale continuamente en cada esfuerzo para proteger su corazón."
- Phase II Aerobic Conditioning (Weeks 1–6): Semi-recumbent cycle ergometer or treadmill walking 3 days/week, 25–30 minutes per session (warm-up 5 min at RPE 9; interval walking 20 min at RPE 11–13, 2.2 mph; cool-down 5 min at RPE 9).
- Resistance Conditioning (Weeks 4–12): Machine-based circuit (seated chest press, leg press, seated row), 2 sets x 12 reps at RPE 11–12. Strict avoidance of isometric holding and Valsalva maneuvers: coach continuous exhalation during concentric effort.
- Environmental Mitigation: Perform all exercise in an indoor, climate-controlled facility ($< 75^\circ\text{F}$) during Yuma summer months to avoid exacerbating myocardial workload.
- Active Verification: In my clinical reasoning, Robert's post-MI cardiac profile combined with beta-blocker therapy invalidates age-predicted heart rate formulas. Pushing him to meet an arbitrary pulse target would induce silent myocardial ischemia or dangerous ventricular arrhythmia. By gating his aerobic progression strictly to Borg RPE 11–13, we decouple cardiovascular conditioning from chronotropic blunting. Furthermore, coaching continuous exhalation mechanics prevents dangerous intrathoracic pressure spikes associated with the Valsalva maneuver, protecting against acute afterload surges and keeping blood pressure well below the 220/105 mmHg safety termination gate. Performing all exercise indoors eliminates Yuma's extreme thermal strain on myocardial oxygen demand.
- Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW265_Mod09_CardioPrescription_Robert.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 09 (Mod 09 Lab: Heart Condition Exercise Plan & Safety Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 09 Práctica de Laboratorio: Prescripción del Ejercicio Cardiovascular y Auditoría Clínica

Regulación hemodinámica, betabloqueadores y normas de seguridad PAGA 2018


### En Palabras Sencillas: Guía de Navegación

Si el cliente toma pastillas para la presión, el pulso no le va a subir aunque el cuerpo esté trabajando al máximo, como una troca con el velocímetro descompuesto. Si los términos técnicos se ponen pesados, concéntrate primero en vigilar el esfuerzo con la escala Borg RPE y medir la presión arterial antes y después.


### Visión General: Estabilidad Hemodinámica y Auditoría Clínica

En esta práctica de laboratorio, diseñará y auditará una prescripción de ejercicio adaptada para un cliente con patología cardiovascular utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , aplicando las normas de seguridad de PAGA 2018 (2.ª edición) y ejecutando una simulación clínica con Google Gemini.


### Estructura de Entrega en Cuadro de Texto de Canvas


#### Ruta Seleccionada e Iniciales del Cliente

Indique qué ruta completó (Ruta 1 Clínica / Ruta 2 Comunitaria / Ruta 3 Deportiva) e incluya las iniciales del cliente.


#### Paso 1: Reconocimiento de Patrones (Hemodinámica y Farmacología)

Analice el bloqueo de la frecuencia cardíaca por betabloqueadores o picos de presión arterial por Valsalva.


#### Paso 2: Aplicación de Reglas (Guías PAGA 2018)

Aplique los estándares de PAGA 2018 para límites de presión arterial (PAS > 220 / PAD > 105) e intensidad según Borg RPE (11–14).


#### Paso 3: Solución Clínica (Verificación Activa y Tarjeta de Cliente)

En una defensa obligatoria (aprox. 150 palabras) con su propia voz clínica, justifique por qué su prescripción de ejercicio de 12 semanas protege la seguridad hemodinámica según PAGA 2018 y evita Valsalva, y concluya con una tarjeta de instrucciones bilingüe de 2 oraciones.


### Modelo de Respuesta de Alta Fidelidad 10/10

Paso 1: Reconocimiento de Patrones: El paciente Robert recibe tratamiento con metoprolol (betabloqueador), lo que atenúa su respuesta cronotrópica (FC de reposo: 58 bpm). Las fórmulas tradicionales de frecuencia cardíaca máxima son inválidas y peligrosas, ya que exigirían una sobrecarga miocárdica desmedida. La presión arterial basal está controlada (130/82 mmHg), pero debe vigilarse para evitar picos hipertensivos durante la sesión.

Paso 2: Aplicación de Reglas (PAGA 2018): Según la PAGA 2018 (2.ª edición), los pacientes en rehabilitación cardíaca deben acumular al menos 150 minutos de actividad aeróbica moderada por semana. La intensidad debe regularse exclusivamente mediante la escala Borg RPE (11–13, "Ligero" a "Algo Pesado") . La sesión debe detenerse de inmediato si la PAS supera los 220 mmHg o la PAD supera los 105 mmHg.

Paso 3: Solución Clínica (Verificación Activa y Tarjeta Bilingüe): Se prescribe entrenamiento aeróbico en bicicleta reclinada 3 días por semana durante 25–30 minutos a RPE 11–13, combinado con ejercicios de fuerza en máquinas (2 series de 12 repeticiones a RPE 11–12) evitando la maniobra de Valsalva mediante exhalación continua durante el esfuerzo. Verificación Activa: En mi criterio clínico, el perfil posinfarto de Robert con betabloqueadores invalida el cálculo tradicional de frecuencia cardíaca. Forzar una meta de pulsaciones provocaría isquemia miocárdica silenciosa. Al dosificar por la escala Borg RPE 11–13, desacoplamos el esfuerzo del bloqueo cronotrópico. La enseñanza de la exhalación continua previene picos de presión por la maniobra de Valsalva, protegiendo al paciente de sobrecargas agudas y manteniendo la presión debajo del límite de 220/105 mmHg. Tarjeta Bilingüe: "Como su medicamento para la presión mantiene su pulso bajo, nunca use monitores de ritmo cardíaco para medir su esfuerzo; en su lugar, mantenga un paso cómodo donde pueda hablar (RPE 11 a 13) y exhale continuamente en cada esfuerzo para proteger su corazón."

Verificación del Repositorio: Registro de auditoría exportado y archivado en Google Drive: EXW_Professional_AI_Repository / EXW265_Mod09_CardioPrescription_Robert.pdf

KIN-265 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
