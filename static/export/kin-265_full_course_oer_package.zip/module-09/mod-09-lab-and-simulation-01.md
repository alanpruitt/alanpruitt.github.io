# KIN-265: Mod 09 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 09 Coaching Sprint Simulation: Managing Heart Rate, Blood Pressure & Heat

- Chronotropic Incompetence & Pacemaker/ICD Rate Ceilings: Clients with pacemakers or implantable cardioverter-defibrillators (ICDs) have programmed heart-rate limits; target HR must remain ≥10–15 bpm below the ICD shock threshold. En palabras sencillas: En pacientes con marcapasos o desfibrilador (ICD) mantenemos el pulso al menos 10 a 15 latidos por debajo del límite programado por su cardiólogo.
- Sternal & Upper-Limb Lead Precautions: Avoiding vigorous overhead shoulder elevation or heavy chest loading after pacemaker implantation or sternotomy until full surgical clearance is granted. En palabras sencillas: Cuidar los movimientos bruscos de hombro por encima de la cabeza o carga en el pecho tras cirugía cardíaca o colocación de marcapasos.
- Thermal Cardiac Strain in Yuma Heat: High ambient heat forces the heart to pump extra blood to the skin while sweat losses reduce stroke volume; cardiac patients must exercise in climate-controlled indoor spaces. En palabras sencillas: El calor extremo obliga al corazón a trabajar el doble; todo paciente cardíaco en Yuma debe ejercitarse bajo techo con aire acondicionado.
- KIN-265.9.1.AY26-27: Prescribe safe aerobic exercise intensity using the Borg RPE scale for clients with cardiovascular disease and altered heart rate responses across diverse career tracks. Prescribir intensidad de ejercicio aeróbico segura usando la escala Borg RPE para clientes con cardiopatías y respuestas cardíacas alteradas en diversas rutas profesionales.
- KIN-265.9.2.AY26-27: Audit clinical blood pressure safety limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de seguridad de presión arterial y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering Cardiovascular Hemodynamics & RPE Intensity Gating

How can fitness professionals safely monitor exercise intensity when a client is taking medications like beta-blockers that lower heart rate? Because standard age-predicted heart rate formulas do not apply, exercise specialists use the Borg RPE scale (6 to 20) to measure subjective exertion. Following strict PAGA 2018 clinical guidelines, trainers can monitor blood pressure stop limits (SBP > 220 / DBP > 105) and protect client health. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master clinical safety auditing!

¿Cómo pueden los profesionales monitorear la intensidad del ejercicio cuando un cliente toma betabloqueadores? Usando la escala Borg RPE y los límites de presión arterial de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría clínica!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Clinical rehabilitation client post-myocardial infarction managing controlled blood pressure while taking daily beta-blockers; establishing safe aerobic progression using the Borg RPE scale.

Scenario: Senior community center participant with Stage 2 hypertension and mild osteoarthritis; formulating a safe walking group intensity protocol and blood pressure monitoring plan.

Scenario: Law enforcement officer with metabolic syndrome and elevated resting heart rate; designing a preventive occupational conditioning and interval training framework.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Robert, Elena, or Marcus).
- Cardiovascular Analysis: Explain the key hemodynamic or pharmacological consideration for your selected client.
- Part 3: Active Verification & Safety Audit: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your hemodynamic safety parameter, Borg RPE gating, or exercise prescription adjustment protects your client under PAGA 2018 standards.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 09 Coaching Sprint • Track 1 (Robert)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Robert (Age 62).
- Cardiovascular Analysis: Robert is post-myocardial infarction and takes metoprolol (a beta-blocker), which blunts his heart rate response during exertion. Standard heart rate formulas do not work for him, so we use the Borg RPE scale (11–13) to measure perceived exertion while protecting myocardial oxygen demand.
- Part 3: Active Verification & Safety Audit: "Monitor Robert's workout intensity strictly using Borg RPE (11–13) instead of heart rate, and terminate exercise immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic per PAGA 2018." Active Verification: In my clinical reasoning, Robert's post-infarction status combined with metoprolol therapy blunts his chronotropic acceleration. Pushing him to reach an age-predicted pulse target would cause silent ischemia. Instead, gating his workout strictly to Borg RPE 11–13 allows safe cardiorespiratory conditioning without exceeding myocardial oxygen supply. Exercising in an indoor facility avoids Yuma's intense thermal stress, and enforcing continuous exhalation prevents blood pressure spikes from approaching the 220/105 mmHg safety cutoff.
- "Monitor Robert's workout intensity strictly using Borg RPE (11–13) instead of heart rate, and terminate exercise immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic per PAGA 2018."
- Active Verification: In my clinical reasoning, Robert's post-infarction status combined with metoprolol therapy blunts his chronotropic acceleration. Pushing him to reach an age-predicted pulse target would cause silent ischemia. Instead, gating his workout strictly to Borg RPE 11–13 allows safe cardiorespiratory conditioning without exceeding myocardial oxygen supply. Exercising in an indoor facility avoids Yuma's intense thermal stress, and enforcing continuous exhalation prevents blood pressure spikes from approaching the 220/105 mmHg safety cutoff.
- Part 4: My Memorable Coaching Takeaway: EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!" "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!"
- "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M09_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 09 (Mod 09 Coaching Sprint: Managing Heart Rate, Blood Pressure & Heat)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 09 Simulación de Coaching: Patologías Cardiovasculares y Hemodinámica

Evaluación Rápida y Auditoría de Seguridad Cardiovascular


### Su Logro Semanal: Dominando la Hemodinámica y el Esfuerzo Percibido

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar la escala Borg RPE y proteger la demanda miocárdica de oxígeno cuando los medicamentos alteran la frecuencia cardíaca. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente de rehabilitación clínica post-infarto que toma betabloqueadores; establecer una progresión aeróbica segura usando la escala Borg RPE.

Escenario: Participante de centro comunitario con hipertensión Estadio 2 y osteoartritis leve; formular un protocolo seguro de intensidad para caminatas y monitoreo de presión arterial.

Escenario: Oficial de policía con síndrome metabólico y frecuencia cardíaca elevada en reposo; diseñar un marco preventivo de acondicionamiento e intervalos.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Robert, Elena o Marcus).
- Análisis Cardiovascular: Explique la consideración hemodinámica o farmacológica clave para su cliente.
- Parte 3: Verificación Activa y Auditoría de Seguridad: En una defensa de texto obligatoria (aprox. mínimo 150 palabras (150+ palabras)) redactada con su propia voz clínica, justifique por qué su parámetro de seguridad hemodinámica, control de esfuerzo Borg RPE o ajuste de prescripción protege a su cliente bajo los estándares de PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su frase inolvidable de aprendizaje en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 09, Sesión de Coaching • Ruta 1 (Robert)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Robert (62 años).
- Análisis Cardiovascular: Robert es post-infarto y toma metoprolol, lo que reduce su frecuencia cardíaca en reposo y blunts su aumento durante el ejercicio. Usamos la escala Borg RPE (11–13) para medir el esfuerzo protegiendo la demanda miocárdica de oxígeno.
- Parte 3: Verificación Activa y Auditoría de Seguridad para Robert: "Monitorear la intensidad del entrenamiento de Robert usando estrictamente la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca, y suspender el ejercicio si la presión arterial supera 220 mmHg sistólica o 105 mmHg diastólica según PAGA 2018." Verificación Activa: En mi criterio clínico, el estado post-infarto de Robert junto con el metoprolol reduce su respuesta cronotrópica. Forzarlo a alcanzar una frecuencia cardíaca meta calculada por edad provocaría isquemia silente. En su lugar, regular su sesión estrictamente con la escala Borg RPE 11–13 permite un acondicionamiento cardiorrespiratorio seguro sin superar la oferta miocárdica de oxígeno. Realizar el ejercicio en interiores evita el calor extremo de Yuma, y exigir una exhalación continua previene picos de presión arterial que se acerquen al límite de seguridad de 220/105 mmHg.
- "Monitorear la intensidad del entrenamiento de Robert usando estrictamente la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca, y suspender el ejercicio si la presión arterial supera 220 mmHg sistólica o 105 mmHg diastólica según PAGA 2018."
- Verificación Activa: En mi criterio clínico, el estado post-infarto de Robert junto con el metoprolol reduce su respuesta cronotrópica. Forzarlo a alcanzar una frecuencia cardíaca meta calculada por edad provocaría isquemia silente. En su lugar, regular su sesión estrictamente con la escala Borg RPE 11–13 permite un acondicionamiento cardiorrespiratorio seguro sin superar la oferta miocárdica de oxígeno. Realizar el ejercicio en interiores evita el calor extremo de Yuma, y exigir una exhalación continua previene picos de presión arterial que se acerquen al límite de seguridad de 220/105 mmHg.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!" "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- EN: "Protecting the heart after a cardiac event means monitoring perceived effort and respecting blood pressure limits!"
- "¡Proteger el corazón después de un evento cardíaco significa monitorear el esfuerzo percibido y respetar los límites de presión arterial!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M09_Quiz_Sprint.pdf
KIN-265 • Module 09 Quick Return Navigation / Regreso Rápido al Módulo 09:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
