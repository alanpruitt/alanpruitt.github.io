# KIN-265: Mod 09 Required Readings Heart Conditions Medical Clearance And Heat Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 09 Required Readings: Heart Conditions, Medical Clearance & Heat Safety


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Cardiovascular pathologies are heart and blood vessel conditions that require strict clinical safety limits during exercise. When medications alter heart rate, we track exertion using the Borg RPE scale (rating effort from 6 to 20). Monitoring blood pressure stop limits and perceived effort protects your clients from dangerous cardiac strain, especially during hot Yuma workouts.


#### En Palabras Sencillas (Norteño Context)

Pensar en el corazón de un cliente hipertenso es como manejar una troca cargada subiendo una cuesta bajo el calor de Yuma; no puedes acelerar a fondo sin vigilar la aguja de la temperatura. Si los términos técnicos se ponen pesados, concéntrate primero en vigilar los límites de presión arterial y escuchar el esfuerzo percibido de la persona.


### Regional Focus: Managing Cardiovascular Risk in Yuma County

Enfoque Regional: Manejo del Riesgo Cardiovascular en el Condado de Yuma

In Yuma County and across Southwest Arizona, exercise specialists frequently encounter aging adults, agricultural workers, and community members managing hypertension, coronary artery disease, and metabolic syndrome. Designing safe activity programs requires strict adherence to federal standards (PAGA 2018) and understanding hemodynamic responses to physical exertion.

En el condado de Yuma y el suroeste de Arizona, los especialistas en ejercicio frecuentemente atienden a adultos mayores y miembros de la comunidad que manejan hipertensión y cardiopatías. Diseñar programas seguros exige apego a las normas federales (PAGA 2018).


### Reading 1: Hemodynamics & Cardiovascular Disease Mechanisms

Lectura 1: Hemodinámica y Mecanismos de las Enfermedades Cardiovasculares


#### Step 1: Blood Pressure Responses and Rate Pressure Product (RPP)

Respuestas de Presión Arterial y Producto de Doble Multiplicación (RPP)

During aerobic exercise, systolic blood pressure (SBP) rises linearly with workload while diastolic blood pressure (DBP) remains relatively stable or decreases slightly. In hypertensive or post-myocardial infarction populations, monitoring the Rate Pressure Product (RPP = Heart Rate × Systolic Blood Pressure) provides a reliable clinical index of myocardial oxygen demand.

Durante el ejercicio aeróbico, la presión sistólica aumenta linealmente mientras la diastólica se mantiene estable. En poblaciones con hipertensión, el RPP proporciona un índice clínico confiable de la demanda de oxígeno miocárdico.


#### Step 2: Absolute and Relative Contraindications to Exercise

Contraindicaciones Absolutas y Relativas para el Ejercicio

Exercise professionals must immediately recognize clinical red flags—such as unstable angina, uncompensated heart failure, or complex arrhythmias—that represent absolute contraindications requiring immediate medical cessation and referral.

Los profesionales del ejercicio deben reconocer de inmediato signos de alarma clínica (como angina inestable o arritmias complejas) que representan contraindicaciones absolutas.


### Reading 2: PAGA 2018 Prescriptive Standards for Cardiac Health

Lectura 2: Normas Prescriptivas de PAGA 2018 para la Salud Cardíaca


#### Step 1: Aerobic Frequency, Intensity, Time, and Type (FITT)

Frecuencia, Intensidad, Tiempo y Tipo Aeróbico (FITT)

In strict alignment with the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , adults with stable cardiovascular disease should accumulate 150 to 300 minutes of moderate-intensity aerobic activity weekly. Intensity must be gauged using individualized heart rate reserve (HRR) or Rating of Perceived Exertion (RPE 11–13 on the 6–20 Borg scale).

En alineación con PAGA 2018, los adultos con cardiopatías estables deben acumular de 150 a 300 minutos de actividad aeróbica semanal de intensidad moderada, usando la escala RPE de Borg.


#### Step 2: Resistance Training Precautions in Hypertension

Precauciones del Entrenamiento de Fuerza en Hipertensión

Resistance training is highly beneficial for metabolic health but requires strict breathing instructions to prevent excessive blood pressure spikes caused by the Valsalva maneuver. Prescribe moderate loads (40–60% of 1-RM) with higher repetitions and continuous exhalation.

El entrenamiento de fuerza es muy beneficioso pero requiere instrucciones estrictas de respiración para evitar picos excesivos de presión arterial causados por la maniobra de Valsalva.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of cardiovascular pathology baselines before proceeding:

English Response: Systolic blood pressure (SBP) rises linearly with workload, while diastolic blood pressure (DBP) remains relatively stable or decreases slightly.

Respuesta en Español: La presión sistólica aumenta linealmente con la carga de trabajo, mientras que la diastólica se mantiene estable o disminuye ligeramente.

English Response: Accumulation of 150 to 300 minutes of moderate-intensity aerobic activity weekly, or 75 to 150 minutes of vigorous-intensity aerobic activity.

Respuesta en Español: Acumulación de 150 a 300 minutos de actividad aeróbica de intensidad moderada semanalmente, o de 75 a 150 minutos de intensidad vigorosa.

English Response: It causes a dramatic, dangerous spike in blood pressure and places excessive acute strain on the cardiovascular system.

Respuesta en Español: Provoca un aumento dramático y peligroso en la presión arterial y ejerce una tensión aguda excesiva sobre el sistema cardiovascular.

KIN-265 • Module 09 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 09:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.


### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 09 (Mod 09 Required Readings: Heart Conditions, Medical Clearance & Heat Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```
