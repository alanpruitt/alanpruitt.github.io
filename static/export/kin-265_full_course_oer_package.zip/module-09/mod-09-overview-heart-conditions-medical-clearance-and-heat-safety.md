# KIN-265: Mod 09 Overview Heart Conditions Medical Clearance And Heat Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 09 Overview: Heart Conditions, Medical Clearance & Heat Safety


### Welcome to Module 09: Heart Conditions, Medical Clearance & Heat Safety

Welcome to Week 9! Building upon our foundational clinical auditing framework, this week we examine Heart Conditions, Medical Clearance & Heat Safety . Cardiovascular disease (CVD), hypertension, heart failure, and peripheral artery disease represent primary clinical challenges in community and rehabilitation settings across Yuma County and Arizona.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify cardiovascular risk patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) prescriptive thresholds, and design safe, medically supervised activity interventions.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 13, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 15, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 18, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 19, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 09 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze clinical indicators, hemodynamic responses, and contraindications associated with cardiovascular pathologies. Analizar indicadores clínicos y respuestas hemodinámicas asociadas con patologías cardiovasculares.
- CLO 2 (Rule Application): Apply PAGA 2018 physical activity guidelines, heart rate reserve parameters, and rating of perceived exertion (RPE) safety thresholds. Aplicar las pautas de PAGA 2018, parámetros de reserva de frecuencia cardíaca y umbrales de esfuerzo percibido.
- CLO 3 (Problem Solving): Formulate an evidence-based exercise prescription and clinical safety audit tailored to individuals managing cardiovascular disease. Formular una prescripción de ejercicio basada en evidencia y auditoría de seguridad clínica adaptada a cardiopatías.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will work within your chosen career track:

Monitoring telemetry, telemetry strip interpretation, and managing Phase II cardiac rehabilitation exercise protocols.

Designing hypertension management walking groups and senior center cardiovascular health initiatives in Yuma County.

Screening first responders and law enforcement personnel for hidden cardiovascular risk factors and establishing preventative conditioning.


### Module 09 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Cardiovascular Pathologies, Hemodynamics & PAGA 2018 Prescriptions
- Discussion Board: Clinical Screening, Risk Stratification & Prescriptive Safety
- Lab Assignment: Cardiovascular Exercise Prescription Audit & Gemini AI Tool Kit
- Knowledge Check & Module Summary

### Interactive Clinical Simulation & Outcome Gate (Module 09) / Simulación Clínica y Dominio de Resultados (Módulo 09)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 09 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 09 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 09 (Mod 09 Overview: Heart Conditions, Medical Clearance & Heat Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 09 Visión General: Patologías Cardiovasculares y Ejercicio


### Bienvenido al Módulo 09: Enfermedades Cardiovasculares y Seguridad Prescriptiva

¡Bienvenido a la Semana 9! Basándonos en nuestro marco de auditoría clínica, esta semana examinamos las Patologías Cardiovasculares y la Prescripción de Ejercicio . Las cardiopatías, la hipertensión y la insuficiencia cardíaca representan desafíos clínicos primarios en entornos de rehabilitación en Yuma y Arizona.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificarás patrones de riesgo cardiovascular, aplicarás los umbrales de PAGA 2018 y diseñarás intervenciones de actividad física supervisada.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar indicadores clínicos, respuestas hemodinámicas y contraindicaciones de patologías cardiovasculares.
- CLO 2 (Regla): Aplicar las pautas de actividad física de PAGA 2018, la reserva de frecuencia cardíaca y umbrales de esfuerzo percibido.
- CLO 3 (Solución): Formular una prescripción de ejercicio basada en evidencia y auditoría de seguridad clínica adaptada a cardiopatías.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, trabajará dentro de la ruta seleccionada:

Monitoreo de telemetría y manejo de protocolos de ejercicio en rehabilitación cardíaca Fase II.

Diseño de caminatas para control de hipertensión y programas cardiovasculares senior en Yuma.

Tamizaje de personal de primera respuesta para factores de riesgo cardiovascular ocultos.


### Ruta de Aprendizaje del Módulo 09

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Patologías Cardiovasculares, Hemodinámica y PAGA 2018
- Foro de Discusión: Tamizaje Clínico, Estratificación de Riesgo y Seguridad
- Práctica de Laboratorio: Auditoría de Prescripción Cardiovascular y Caja de Herramientas
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 09 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 09 Required Readings: Heart Conditions, Medical Clearance & Heat Safety →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 09 Discussion: Medical Clearance & Heart Safety Rules →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 09 Coaching Sprint: Managing Heart Rate, Blood Pressure & Heat →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 09 Lab: Heart Condition Exercise Plan & Safety Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 09 Summary & Wrap-Up: Heart Conditions, Medical Clearance & Heat Safety →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
