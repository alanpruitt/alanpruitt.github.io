## KIN-265: Module 00 — Course Orientation & Ready Reference Guide / Orientación del Curso y Guía de Referencia Permanente

::: {.callout-note}
## In Plain English: Reading Navigation Guide
Before you read the details below, here is the short version: **Module 00 is your permanent, semester-long reference guide for how to succeed in KIN-265.** It explains how we pair AI tools with your own clinical judgment for older adults and chronic conditions, how the 10 / 7 / 0 grading scale works, and how to revise any assignment for full 10 / 10 credit. Because this module stays open all semester, bookmark it and return whenever you need a safety rule or an example.

## En Palabras Sencillas (Norteño Context)
Piensa en el Módulo 00 como tu manual de seguridad clínica en el bolsillo: siempre está abierto durante todo el semestre por si ocupas checar cómo proteger a un adulto mayor o paciente con condición crónica en el calor de Yuma, o cómo subir una calificación a 10 / 10. Si los términos técnicos se ponen pesados, concéntrate primero en identificar los medicamentos y riesgos del cliente (`Patrón / Regla / Solución`) antes de ponerlo a hacer ejercicio.
:::

---

## Course Orientation & Permanent Reference Grounding / Orientación del Curso

* **English:** Welcome to **KIN-265: Exercise for Special Populations**. This portal prepares you to design safe, inclusive, and evidence-based movement programs for older adults, pregnant/postpartum women, and individuals managing chronic conditions or disabilities in the **Yuma, Arizona and Imperial Valley** region. Every module uses the **Clinical Framing Protocol (`Pattern / Rule / Solve`)** grounded in our Academic Source of Truth (SSoT): the **Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 and 6**. **Best Practice Note:** Module 00 remains unlocked the entire 16-week semester so you can reference our grading rules, pharmacology/heat safety gates, and 10/10 exemplars at any time.
* **Español (Regional):** Bienvenido a **KIN-265: Ejercicio para Poblaciones Especiales**. Este portal te prepara para diseñar programas de movimiento seguros, inclusivos y basados en evidencia para adultos mayores, mujeres en etapa prenatal/posparto y personas con condiciones crónicas en la región de **Yuma, Arizona y el Valle Imperial**. Todo nuestro trabajo se fundamenta en el **Protocolo de Encuadre Clínico (`Patrón / Regla / Solución`)** y las **Pautas de Actividad Física para Estadounidenses (PAGA), 2ª Edición (2018), Capítulos 5 y 6**. **Nota Práctica:** El Módulo 00 permanece abierto durante las 16 semanas del semestre como tu guía de consulta rápida.

---

## Targeted Learning Objectives / Objetivos de Aprendizaje

* **([LO 1.1 / 2.1]):** Analyze the pathophysiology, medication interactions, and functional movement limitations of special populations using the **Clinical Framing Protocol (`Pattern / Rule / Solve`)**. / Analizar la fisiopatología, interacciones medicamentosas y limitaciones funcionales de poblaciones especiales mediante el **Protocolo de Encuadre Clínico (`Patrón / Regla / Solución`)**.
* **([LO 3.1]):** Prescribe safe, modified, multicomponent exercise programs grounded in **PAGA 2018 (Chapters 5 & 6)** that account for Yuma environmental extremes. / Prescribir programas de ejercicio multicomponente seguros y adaptados según **PAGA 2018 (Capítulos 5 y 6)** considerando el clima extremo de Yuma.

---

## The Clinical Framing Protocol (`Pattern

In the **Matador Wellness Center Clinical AI Residency**, you are the **Architect / Pilot** (Clinical Contraindications, Medication Modifications, and Fall/Heat Safety) and the AI is the **Engine / Calculator** (Drafting Baseline Templates). Throughout the semester, every Discussion, Coaching Sprint, and Lab uses our three-part **Clinical Framing Protocol**:

1. **Pattern (`Patrón` — Context):** Diagnose the client's chronic condition(s), functional mobility, medication effects (such as beta-blockers blunting heart rate or diuretics increasing dehydration risk), and Yuma environmental heat exposure.
2. **Rule (`Regla` — Constraint):** Define the clinical boundaries, contraindications, intensity monitoring rules (such as using $\text{RPE } 11\text{ to }13$ or the Talk Test instead of heart-rate formulas when medicated), and multicomponent benchmarks from **PAGA 2018 (Chapters 5 & 6)**.
3. **Solve (`Solución` — Intervention):** Execute a modified, accessible exercise prescription (aerobic + muscle-strengthening + balance), patient safety card, and human **Active Verification**.

---

## Plain-English Guide: Simulations & Simulators (`paga2018.dev` + `exwtoolkit.com`)

* **In Plain English:** Throughout KIN-265, you use two free, zero-login web apps located right in your left-hand Canvas Course Navigation menu—**`paga2018.dev` ("PAGA")** and **`exwtoolkit.com` ("Toolkit")**—to test special-population client cases against **PAGA 2018 (Chapters 5 & 6)**:
  1. **`paga2018.dev` ("PAGA" in Left Course Menu):**
     * **Activity Audit (`paga2018.dev/activity-audit`):** Audit your client's multicomponent volume (aerobic + muscle-strengthening + balance training) against PAGA Chapters 5 and 6.
     * **Special Populations Coach & Case Coach (`paga2018.dev/special-pops-coach`):** Step-by-step `Pattern / Rule / Solve` coaching sandbox for checking medication effects (such as beta-blockers requiring $\text{RPE } 11\text{ to }13$ / Talk Test instead of heart-rate math), fall prevention, and Yuma heat modifications.
     * **Interactive Case Modals (`###` Copy Blocks):** Pre-built clinical profiles wrapped in triple-hash (`###`) delimiters. Click **"Copy Case (`###`)"** to copy clean patient data without formatting clutter.
     * **Bilingual EN / ES Toggle:** Switch any simulator or federal PAGA rule between English and Norteño-grounded Spanish with one click.
  2. **`exwtoolkit.com` ("Toolkit" in Left Course Menu):**
     * **Stage 1 — Weekly Coaching Sprint:** Uses the embedded micro-simulator right on the Canvas assignment page (`Pattern / Rule / Solve` + 150-word Active Verification).
     * **Stage 2 — Weekly Clinical Lab:** Uses **`paga2018.dev`** + the **`exwtoolkit.com` 9-Box Clinical Architecture** (`1. Biometrics Box` $\rightarrow$ `3. Safety Box` $\rightarrow$ `8. Special Pops Box` $\rightarrow$ `9. Solve Box` *"Copy for Canvas Submission"*).
* **En Palabras Sencillas (Contexto Norteño):** *Durante todo KIN-265 usamos dos herramientas gratuitas y sin contraseña que están directo en el menú izquierdo de Canvas: **"PAGA"** (`paga2018.dev`, con **Activity Audit**, **Special Populations Coach** y **Cuadros de Casos `###`**) y **"Toolkit"** (`exwtoolkit.com`). El micro-simulador integrado en la página es para tu **Coaching Sprint (Etapa 1)**, y las aplicaciones completas son para tu **Laboratorio Clínico (Etapa 2)**.*

---

## Active Verification (`Part 3`): What It Is, Why We Use It, & 10/10 Student Exemplars (Harmonized Across `EXW 101 •...

## 1. What is "Active Verification"?
Every Lab and Coaching Sprint requires the **Four-Part Submission Standard**:
* **Part 1 (The Engine):** Your P-T-C-F Engineered Prompt (Persona, Task, Context, Format).
* **Part 2 (The Clinical Audit):** A 150-word critique of the AI's output against **PAGA 2018 (Chapters 5 & 6)**, catching missed contraindications, medication blind spots, or fall/heat hazards.
* **Part 3 (Active Verification):** A **mandatory 150-word minimum verbatim text defense written entirely in your own human voice** justifying how your modified exercise plan protects your special-population client.
* **Part 4 (Comparison against the 10/10 Exemplar):** Verifying your work against the module model before submitting.

## 2. Why Do We Use Active Verification? (The Clinical Framework: Pattern / Rule / Solve)
* **In Plain English:** When working with special populations—such as an older adult in the Yuma Foothills taking beta-blockers, a patient with Type 2 diabetes and peripheral neuropathy, or a client recovering from a stroke—an unverified AI mistake can cause a fall, a hypoglycemic episode, or a heat-stroke emergency. We require the 150-word **Active Verification** in your own words to prove that **you**—the human specialist—caught the medication and safety risks that the AI missed.
* **En Palabras Sencillas (Norteño-Spanish):** *La Verificación Activa (mínimo 150 palabras en tu propia voz) demuestra que tú eres el especialista clínico al mando y la IA es solo un borrador inicial. En poblaciones especiales (adultos mayores, hipertensión, diabetes, artritis), un error de la IA con los medicamentos o el calor de Yuma puede causar una caída o emergencia médica. Aquí explicas con tus propias palabras cómo aplicaste `Patrón / Regla / Solución` y PAGA 2018 (Capítulos 5 y 6) para proteger a tu paciente.*

## 3. What It Looks Like: KIN-265 Student Exemplar (`10 / 10 Standard`)

> ### Exemplar: KIN-265 Part 3 — Active Verification (161 words, PAGA 2018 Ch. 5 & 6 Grounded)
> "In my own words, I corrected the AI's output because it used a standard heart-rate zone formula (`220 - age`) for a 67-year-old Foothills retiree taking a daily beta-blocker (metoprolol) for hypertension and living with knee osteoarthritis. Under `Pattern / Rule / Solve`, the **Pattern** is an older adult whose medication blunts heart-rate response and creates orthostatic dizziness risk, especially when walking outdoors in $105^\circ\text{F}$ ($40.6^\circ\text{C}$) Yuma heat. The **Rule** from the 2018 Physical Activity Guidelines for Americans (Chapters 5 and 6) requires multicomponent physical activity—combining aerobic, muscle-strengthening, and balance training—while regulating intensity via Rating of Perceived Exertion ($\text{RPE } 11\text{ to }13$ on the 6–20 Borg scale, or the Talk Test) whenever beta-blockers invalidate heart-rate targets. My **Solve** moves her sessions into an indoor pool and air-conditioned studio at 8:00 AM, pairing low-impact aquatic walking with seated chair-stand strength and tandem-stance balance drills plus a 10-minute gradual cool-down."

---

## The 10-7-0 Mastery Grading Scale & How to Remedy a `Recalibrate (0 / 10)` Score

All Discussions, Coaching Sprints, and Labs in KIN-265 use **The 10-7-0 Mastery Grading Scale**:

* **10 / 10 (Exemplary):** Complete and accurate clinical reasoning (`Pattern / Rule / Solve`), verified against **PAGA 2018 (Chapters 5 & 6)** with zero contraindication or safety errors and a complete 150-word human Active Verification.
* **7 / 10 (Competent):** Catches the main special-population clinical issue and AI mistakes, with minor gaps in modification detail, word count, or PAGA guideline citations. **You can revise and resubmit to reach 10 / 10.**
* **0 / 10 (Recalibrate):** Missing a required section (such as the 150-word Active Verification), unverified AI copy-paste, or unsafe clinical advice (such as ignoring a beta-blocker, prescribing high-impact plyometrics to a client with severe osteoarthritis/osteoporosis, or exercising outdoors in extreme Yuma heat). **`0 / 10` is never a permanent punishment—it is a clinical safety pause and an open invitation to fix the issue and resubmit for full `10 / 10` credit.**

## The 4-Step Remedy Roadmap: How to Fix a `0 / 10 (Recalibrate)` or Upgrade a `7 / 10 (Competent)` Grade

1. **Step 1 — Open Your `Grades` Tab in Canvas (Not the To-Do List):**
   Once an assignment is graded `0 / 10` or `7 / 10`, Canvas removes it from your "To-Do" sidebar. Click **`Grades`** in the left course navigation menu and click the assignment title directly.
2. **Step 2 — Read Coach Alan's *In Plain English* SpeedGrader Note:**
   Every returned assignment includes a specific comment starting with *"In plain English:"* (or *"En palabras sencillas:"*) explaining the exact PAGA 2018 Chapter 5/6 rule, contraindication, or missing section you need to fix.
3. **Step 3 — Revise Only What Was Flagged:**
   Update your submission using **`Pattern / Rule / Solve` (`Patrón / Regla / Solución`)**, cite **PAGA 2018 (Chapters 5 & 6)**, and verify that your **Part 3 Active Verification** is at least 150 words in your own human voice.
4. **Step 4 — Click `New Attempt` and Resubmit (Unlimited Attempts Open All Semester):**
   All Labs and Coaching Sprints have **Unlimited Attempts** enabled and remain unlocked through the end of the semester. Click **New Attempt**, submit your updated work, and Coach Alan will re-audit and upgrade your score to **`10 / 10 (Exemplary)`**.

## En Palabras Sencillas: Cómo Recuperar un `0 / 10 (Recalibrate)` o Subir un `7 / 10` a `10 / 10`
*Un `0 / 10 (Recalibrate)` nunca es un castigo definitivo; es una pausa de seguridad clínica y una invitación abierta para corregir y volver a entregar por el `10 / 10` completo. Entra a la pestaña **Grades (Calificaciones)** en Canvas, lee el comentario de Coach Alan en SpeedGrader, corrige el `Patrón / Regla / Solución` o tu Verificación Activa de 150 palabras, y haz clic en **New Attempt (Nuevo Intento)**. Tienes intentos ilimitados durante todo el semestre.*

---

## Check for Understanding
* Before starting Module 01, explain in your own words: Why does using `220 - age` to set heart-rate zones for a client on beta-blockers result in a `0 / 10 (Recalibrate)` safety pause, and what four steps do you take in Canvas to revise and upgrade that score to `10 / 10`?


###CASE_DATA_START###
Clinical Case Profile / Student Activity Parameters
###CASE_DATA_END###
