# KIN-265: 0 6 Discussion Squad Qa

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: The Squad Q&A is your open community lounge to ask course questions, share study tips, and connect with classmates. If you have a general question about an assignment, a link, or a clinical concept, post it here so the whole class benefits. For private grade or personal questions, message Coach Alan directly in Canvas Inbox.


### En Palabras Sencillas (Norteño Context)

Este foro es como la banca del gimnasio donde platicamos dudas generales entre compañeros y nos echamos la mano. Si los términos técnicos se ponen pesados, concéntrate primero en preguntar sin pena cualquier duda sobre el curso o mandar mensaje directo por Inbox si es algo privado.


### COMM CHECK: SQUAD Q&A / CONTROL DE COMUNICACIÓN: PREGUNTAS Y RESPUESTAS

"Radio check. Over." / "Prueba de radio. Adelante."


#### Open Frequency / Frecuencia Abierta

- English: Got a question? Someone else probably has the same one. This discussion board is our open forum for course-related questions. If you are confused about an instruction, can't find a reading, or found a technical glitch, post it here.
- Español (Regional): ¿Tiene alguna pregunta? Es probable que alguien más tenga la misma duda. Este foro de discusión es nuestro espacio abierto para preguntas relacionadas con el curso. Si tiene dudas sobre alguna instrucción, no encuentra una lectura o detecta una falla técnica, publíquela aquí.

#### Ghost Mode Enabled / Modo Fantasma Activado

- English: Anonymous Posting is enabled. To encourage open communication, you can ask questions without attaching your name. (Though remember: there are no dumb questions, only unchecked errors).
- Español (Regional): La publicación anónima está activada. Para fomentar una comunicación abierta, puede realizar preguntas sin vincular su nombre. (Recuerde: no hay preguntas tontas, solo errores que no se reportan).

#### Rules of Engagement / Reglas de Participación

- English (Check the Map First): Before you call for support, check the Syllabus and the Module onboarding pages. Español (Regional - Verifique el Mapa Primero): Antes de solicitar asistencia, revise el Plan de Estudios y las páginas de introducción del Módulo.
- English (No Personal Intel): Do not post about your specific grades here. Message Coach Alan directly via Canvas Inbox for private matters. Español (Regional - Sin Datos Personales): No publique información sobre sus calificaciones específicas aquí. Envíe un mensaje directo a Coach Alan a través de la Bandeja de Entrada de Canvas para asuntos privados.
- English (Help Your Squad): If you see a question and know the solution, jump in! Crowd-sourced intelligence makes the squad stronger. Español (Regional - Ayude a su Grupo): Si ve una pregunta y conoce la solución, ¡participe! El conocimiento colectivo fortalece a todo el grupo.
Pro Tip: Click "Subscribe" / Consejo Profesional: Haga clic en "Suscribirse" English: Click the Subscribe button at the top of this thread to get notified when questions are answered. Español (Regional): Haga clic en el botón de Suscribirse en la parte superior de este hilo para recibir notificaciones cuando se respondan las preguntas.

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
