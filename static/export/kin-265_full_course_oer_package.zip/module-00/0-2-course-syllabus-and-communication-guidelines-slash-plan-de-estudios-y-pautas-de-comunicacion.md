# KIN-265: 0 2 Course Syllabus And Communication Guidelines Slash Plan De Estudios Y Pautas De Comunicacion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## THE ADAPTIVE EXERCISE COURSE CONTRACT

EL CONTRATO DEL CURSO DE EJERCICIO ADAPTATIVO

- English: Do not download an outdated PDF copy. The active Canvas Syllabus page is our live, real-time contract. It is engineered to load instantly on any mobile screen, while keeping our clinical safety boundaries, grading parameters, and strict PAGA-compliant special-population standards transparent.
- Español (Regional): No descargue una copia en PDF obsoleta. El plan de estudios activo en Canvas es nuestro contrato en tiempo real. Está diseñado para cargarse de forma instantánea en cualquier pantalla o navegador móvil, manteniendo transparentes las barreras de seguridad clínica, los parámetros de calificación y los estándares de PAGA para poblaciones especiales.

### OFFICIAL COMMUNICATION PROTOCOLS

PROTOCOLOS OFICIALES DE COMUNICACIÓN

- English: Always message Coach Alan directly through the Canvas Inbox. Expect a professional response within 24 business hours. For coordination regarding adaptive laboratory assignments or safety evaluations, use this direct frequency.
- Español (Regional): Envíe siempre mensajes a Coach Alan directamente a través de la Bandeja de Entrada de Canvas. Espere una respuesta profesional dentro de las 24 horas hábiles. Para coordinación sobre tareas de laboratorio adaptativo o evaluaciones de seguridad, use esta frecuencia directa.

## Official Arizona Western College Master Syllabus & Institutional Alignment Contract

In Plain English: Before you read the institutional table below, here is the short version: This section contains your official Arizona Western College course description, credit hours, learning outcomes, and degree pathway transfer rules. Per the AWC Faculty & Instructor Handbook (pp. 18–20) and Instruction Procedures 601.3, 615.2, and 615.3 , every AWC course pairs this immutable Official Course Syllabus with the Instructor Course Outline above so your credits transfer cleanly to ASU, NAU, and UA. En palabras sencillas: Esta sección presenta las competencias oficiales de Arizona Western College, las horas crédito (`PREREQUISITE: None`) y cómo este curso cuenta directamente para tu título y transferencia universitaria.


### Step 1: Official AWC Course Specifications & Procedure 601.3 Contact-Hour Equivalency


### Step 2: Official AWC Course Competencies & Observable Student Learning Outcomes (SLOs)

Evaluated at the Highly Developed tier of the AWC Academic Program Learning Outcomes Rubric and assessed on the 10 / 7 / 0 Mastery Grading Scale via Pattern / Rule / Solve and 150-word Active Verification :


### Step 3: Alignment with AWC Guiding Principles for Learning (GPLs) & Institutional Competencies

- Analytical Reasoning & Metacognition (Critical Inquiry & Quantitative Analysis): Students calibrate biometric, metabolic, and environmental parameters in exwtoolkit.com and audit AI outputs against federal clinical rules ( Pattern / Rule ).
- Ethical Growth & Wellness (Scientific Literacy): Students enforce clinical safety gates, scope-of-practice boundaries, and desert heat acclimatization protocols to protect client health in Yuma and Imperial Valley communities.
- Application & Creation of Knowledge (Digital Literacy): Students engineer structured P-T-C-F clinical prompts and formulate individualized prescriptions verified against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018, Ch. 5 & 6) & ACSM 12th Edition (2025) ( Solve ).
- Collaboration & Inclusion + Aesthetics & Creative Thinking (Communication & Civic Discourse): Students engage in bilingual-accessible (Plain English / Norteño-Spanish) peer clinical discussions and author authentic 150-word Active Verification defenses.
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
