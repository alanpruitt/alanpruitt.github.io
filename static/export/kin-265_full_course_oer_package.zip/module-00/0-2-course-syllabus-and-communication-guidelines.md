# KIN-265: 0 2 Course Syllabus And Communication Guidelines

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: This page outlines our weekly rhythm, communication expectations, and how Coach Alan supports your progress all semester. New modules open on Tuesdays, Initial Discussion posts are due Thursdays, Peer Replies are due Sundays, and Labs are due Mondays at 11:59 PM. If life gets hectic in Yuma, reach out early in Canvas Inbox so we can keep you on track.


### En Palabras Sencillas (Norteño Context)

Aquí están las reglas del juego y los días de entrega para que organices tu semana sin sorpresas entre el trabajo y la familia. Si los términos técnicos se ponen pesados, concéntrate primero en el calendario semanal (jueves foro inicial, domingo réplica, lunes laboratorio) y en escribirme si ocupas apoyo.


### THE ADAPTIVE EXERCISE COURSE CONTRACT

EL CONTRATO DEL CURSO DE EJERCICIO ADAPTATIVO

- English: Do not download an outdated PDF copy. The active Canvas Syllabus page is our live, real-time contract. It is engineered to load instantly on any mobile screen, while keeping our clinical safety boundaries, grading parameters, and strict PAGA-compliant special-population standards transparent.
- Español (Regional): No descargue una copia en PDF obsoleta. El plan de estudios activo en Canvas es nuestro contrato en tiempo real. Está diseñado para cargarse de forma instantánea en cualquier pantalla o navegador móvil, manteniendo transparentes las barreras de seguridad clínica, los parámetros de calificación y los estándares de PAGA para poblaciones especiales.

### OFFICIAL COMMUNICATION PROTOCOLS

PROTOCOLOS OFICIALES DE COMUNICACIÓN

- English: Always message Coach Alan directly through the Canvas Inbox. Expect a professional response within 24 business hours. For coordination regarding adaptive laboratory assignments or safety evaluations, use this direct frequency.
- Español (Regional): Envíe siempre mensajes a Coach Alan directamente a través de la Bandeja de Entrada de Canvas. Espere una respuesta profesional dentro de las 24 horas hábiles. Para coordinación sobre tareas de laboratorio adaptativo o evaluaciones de seguridad, use esta frecuencia directa.
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
