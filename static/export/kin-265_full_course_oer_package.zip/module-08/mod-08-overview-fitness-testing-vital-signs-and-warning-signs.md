# KIN-265: Mod 08 Overview Fitness Testing Vital Signs And Warning Signs

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 08 Overview: Fitness Testing, Vital Signs & Warning Signs

Pruebas de Esfuerzo Clínico, Telemetría y Evaluación de Mitad de Término


### Welcome to Module 08: Fitness Testing, Vital Signs & Warning Signs

Welcome to Week 8! This week marks our midterm milestone. We focus on clinical stress testing integration, heart rate monitoring, and safe cardiorespiratory programming . When designing exercise routines for clients at Matador Clinical Partners (MCP), your primary goal is to understand how to safely monitor exercise intensity, recognize physical warning signs, and follow proper safety guidelines.

Please note that this week's Discussion board is replaced by the Midterm Student Course Evaluation . Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in our Single Source of Truth (SSoT)—the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) —you will audit clinical case data wrapped in our mandatory delimiter protocol (### BEGIN CLINICAL CASE DATA ###), enforce strict stop-test criteria, and formulate safe cardiorespiratory conditioning programs.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 6, 2026, at 12:00 AM MST
- Midterm Evaluation Submission / Evaluación de Mitad de Término: Thursday, October 8, 2026, at 11:59 PM MST
- Knowledge Check Completion / Comprobación de Conocimientos: Sunday, October 11, 2026, at 11:59 PM MST
- Lab 08 Direct Submission / Entrega de Laboratorio: Monday, October 12, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 08 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze basic exercise test reports, heart rate responses, and perceived exertion levels in clients with chronic conditions. Analizar reportes básicos de pruebas de esfuerzo, respuestas de la frecuencia cardíaca y niveles de esfuerzo percibido.
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) safety rules, enforcing blood pressure stop-test limits (SBP > 220 mmHg, DBP > 105 mmHg) and RPE intensity monitoring for clients taking beta-blockers. Aplicar normas de PAGA 2018 aplicando límites de paro por presión arterial (PAS > 220 mmHg, PAD > 105 mmHg) y monitoreo de RPE.
- CLO 3 (Problem Solving): Formulate a modified aerobic and strength exercise prescription for Matador Clinical Partners (MCP) that maintains safe intensity levels. Diseñar una prescripción aeróbica y de fuerza modificada para Matador Clinical Partners (MCP) manteniendo niveles seguros de intensidad.

### Module 08 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Clinical Readings: Cardiorespiratory Monitoring & Safety
- Midterm Student Course Evaluation (Replaces Discussion Board 08)
- Lab Assignment 08: Cardiorespiratory Prescription & Safety Auditor Simulation
- Module 08 Knowledge Check & Summary Wrap-Up

### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 08 (Mod 08 Overview: Fitness Testing, Vital Signs & Warning Signs)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 08 Visión General: Pruebas de Esfuerzo Clínico y Telemetría

Pruebas de Esfuerzo Clínico, Telemetría y Evaluación de Mitad de Término


### Bienvenido al Módulo 08: Pruebas de Esfuerzo y Evaluación de Mitad de Término

¡Bienvenido a la Semana 8 y a nuestra evaluación de mitad de término! Esta semana nos enfocamos en la integración de pruebas de esfuerzo clínico, el monitoreo de la frecuencia cardíaca y la programación segura de ejercicio cardiorrespiratorio . El objetivo en Matador Clinical Partners (MCP) es comprender cómo monitorear la intensidad de forma segura y aplicar pautas de protección adecuadas.

Tenga en cuenta que el foro de discusión ha sido sustituido por la Evaluación de Mitad de Término del Curso . Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y las pautas de PAGA 2018 (2.ª edición) , auditará datos clínicos delimitados (### BEGIN CLINICAL CASE DATA ###) y formulará programas seguros.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 6 de octubre de 2026, a las 12:00 AM MST
- Entrega de Evaluación de Mitad de Término: Jueves, 8 de octubre de 2026, a las 11:59 PM MST
- Comprobación de Conocimientos: Domingo, 11 de octubre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 08: Lunes, 12 de octubre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar reportes básicos de pruebas de esfuerzo, respuestas de la frecuencia cardíaca y niveles de esfuerzo percibido.
- CLO 2 (Regla): Aplicar las normas de PAGA 2018 estableciendo límites hemodinámicos de paro (PAS > 220 mmHg, PAD > 105 mmHg) y monitoreo de RPE.
- CLO 3 (Solución): Diseñar una prescripción de ejercicio aeróbico y de fuerza modificada para Matador Clinical Partners (MCP) manteniendo niveles seguros.

### Ruta de Aprendizaje del Módulo 08

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Clínicas Obligatorias: Monitoreo Cardiorrespiratorio y Seguridad
- Evaluación de Mitad de Término del Curso (Sustituye al Foro de Discusión 08)
- Laboratorio 08: Prescripción Cardiorrespiratoria y Simulación del Auditor de Seguridad
- Comprobación de Conocimientos y Resumen del Módulo 08

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 08 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 08 Required Readings: Fitness Testing, Vital Signs & Warning Signs →
- Step 2 — Complete the Student Course Evaluation (Paso 2 — Evaluación del Curso): Mod 08: Midterm Student Course Evaluation →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 08 Coaching Sprint: Spotting Stop-Exercise Warning Signs →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 08 Lab: Vital Signs & Exercise Monitoring Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 08 Summary & Wrap-Up: Fitness Testing, Vital Signs & Warning Signs →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
