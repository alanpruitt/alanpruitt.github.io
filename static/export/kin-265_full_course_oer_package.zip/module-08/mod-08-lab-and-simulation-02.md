# KIN-265: Mod 08 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 08 Coaching Sprint Simulation: Spotting Stop-Exercise Warning Signs

Sesión de Coaching del Módulo 08: Monitoreo Cardiorrespiratorio y Seguridad

- Submaximal Functional Field Testing (6-Minute Walk Test & Sit-to-Stand): Safe, self-paced clinical assessments for older or deconditioned populations that measure functional aerobic endurance and lower-body strength without maximal strain. En palabras sencillas: Pruebas clínicas seguras como la Caminata de 6 Minutos y Sentarse-Pararse en Silla para evaluar la condición física sin exponer al paciente al límite.
- Hemodynamic Exercise Response (Normal vs. Hypotensive/Hypertensive): Systolic BP should rise progressively with workload while diastolic BP remains stable (±10 mmHg); a drop in SBP >10 mmHg or SBP >250 / DBP >115 mmHg requires immediate termination. En palabras sencillas: Al subir el esfuerzo la presión sistólica debe subir de forma gradual; si cae más de 10 puntos o supera 250/115 mmHg, detenemos la prueba al instante.
- Pre- and Post-Session Vital Sign Verification Log: Recording resting heart rate, blood pressure, SpO2, symptoms, and medication timing before and after every clinical conditioning session. En palabras sencillas: Anotar pulso, presión arterial, oxigenación y si el paciente tomó sus medicamentos antes y después de cada sesión.
- KIN-265.8.1.AY26-27: Prescribe safe aerobic exercise intensity using the Borg RPE scale for clients with altered heart rate responses across diverse career tracks. Prescribir intensidad de ejercicio aeróbico segura usando la escala Borg RPE para clientes con respuestas cardíacas alteradas en diversas rutas profesionales.
- KIN-265.8.2.AY26-27: Audit clinical blood pressure safety limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de seguridad de presión arterial y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering Heart Rate Safety & RPE Intensity Gating

How can fitness professionals safely monitor exercise intensity when a client is taking medications like beta-blockers that lower heart rate? Because standard age-predicted heart rate formulas do not apply, exercise specialists use the Borg RPE scale (6 to 20) to measure subjective exertion. Following strict PAGA 2018 clinical guidelines, trainers can monitor blood pressure stop limits (SBP > 220 / DBP > 105) and protect client health. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master clinical safety auditing!

¿Cómo pueden los profesionales monitorear la intensidad del ejercicio cuando un cliente toma betabloqueadores? Usando la escala Borg RPE y los límites de presión arterial de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría clínica!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Adult client managing controlled hypertension while taking daily beta-blockers; establishing safe walking intensity using the Borg RPE scale.

Scenario: Senior community center participant managing chronic heart failure and taking beta-blockers; establishing a safe indoor walking pace and monitoring fatigue via RPE.

Scenario: Active-duty military veteran and law enforcement officer with stress-induced hypertension; designing a heart-rate independent conditioning framework for duty readiness.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Robert, Margaret, or Sergeant Davis).
- Cardiorespiratory Analysis: Explain how beta-blockers affect heart rate responses and why Borg RPE is used instead of standard heart rate formulas.
- My Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment utilizing the Safety Auditor protocol.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why human recognition of absolute stop-exercise warning signs (chest discomfort, dizziness, $\text{SBP}$ drop $>10\text{ mmHg}$, $\text{SpO}_2 < 88\%$) and Borg RPE gating cannot be outsourced to a smartwatch.

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 08 Coaching Sprint • Track 1 (Robert)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Robert (Age 58).
- Cardiorespiratory Analysis: Robert takes a beta-blocker, which lowers his resting heart rate and keeps his heart rate from rising normally during exercise. Standard heart rate formulas do not work for him, so we use the Borg RPE scale (11–13) to measure how hard he feels he is working.
- My Safety Audit for Robert: "Monitor Robert's workout intensity strictly using Borg RPE (11–13) instead of heart rate, and terminate exercise immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic per PAGA 2018."
- "Monitor Robert's workout intensity strictly using Borg RPE (11–13) instead of heart rate, and terminate exercise immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic per PAGA 2018."
- My Memorable Coaching Takeaway: EN: "When medication changes your heart rate, listening to your perceived effort keeps your workout safe and effective!" "¡Cuando los medicamentos cambian su frecuencia cardíaca, escuchar su esfuerzo percibido mantiene su entrenamiento seguro y efectivo!"
- EN: "When medication changes your heart rate, listening to your perceived effort keeps your workout safe and effective!"
- "¡Cuando los medicamentos cambian su frecuencia cardíaca, escuchar su esfuerzo percibido mantiene su entrenamiento seguro y efectivo!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M08_Quiz_Sprint.pdf
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, a smartwatch optical sensor cannot detect pale, clammy skin, ataxia, angina equivalents, or a 10 mmHg drop in systolic blood pressure during increasing workload—all of which mandate immediate test termination. Furthermore, when a client takes beta-blockers or exercises in Yuma's heat (cardiovascular drift), heart-rate formulas become clinically unreliable. By combining active human visual/verbal telemetry, the Borg RPE Talk Test (11–13), and strict PAGA 2018 stop-exercise gates, I protect my client from acute cardiovascular events. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 08 (Mod 08 Coaching Sprint: Spotting Stop-Exercise Warning Signs)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 08 Simulación de Coaching: Monitoreo Cardiorrespiratorio y Seguridad

Evaluación Rápida y Auditoría de Seguridad


### Su Logro Semanal: Dominando la Seguridad Cardíaca y el Esfuerzo Percibido

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar la escala Borg RPE cuando los medicamentos alteran la frecuencia cardíaca. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Adulto con hipertensión controlada que toma betabloqueadores; establecer una intensidad de caminata segura usando la escala Borg RPE.

Escenario: Participante de centro comunitario con insuficiencia cardíaca crónica tomando betabloqueadores; establecer un ritmo de caminata interior seguro y monitorear fatiga con RPE.

Scenario: Veterano militar en servicio activo y oficial de policía con hipertensión inducida por estrés; diseñar un marco de acondicionamiento independiente de la frecuencia cardíaca para la preparación operativa.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Robert, Margaret o Sergeant Davis).
- Análisis Cardiorrespiratorio: Explique cómo los betabloqueadores afectan la frecuencia cardíaca y por qué se usa la escala Borg RPE.
- Mi Auditoría de Seguridad: Escriba 1 parámetro de seguridad claro o ajuste de prescripción usando el protocolo del Auditor de Seguridad.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica explicando por qué la detección humana de signos de alarma para detener el ejercicio y la escala Borg RPE no pueden reemplazarse por un reloj inteligente.

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 08, Sesión de Coaching • Ruta 1 (Robert)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Robert (58 años).
- Análisis Cardiorrespiratorio: Robert toma un betabloqueador que reduce su frecuencia cardíaca e impide que suba normalmente al hacer ejercicio. Las fórmulas estándar no funcionan, por lo que usamos la escala Borg RPE (11–13).
- Mi Auditoría de Seguridad para Robert: "Monitorear la intensidad del entrenamiento de Robert usando estrictamente la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca, y suspender el ejercicio si la presión arterial supera 220 mmHg sistólica o 105 mmHg diastólica según PAGA 2018."
- "Monitorear la intensidad del entrenamiento de Robert usando estrictamente la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca, y suspender el ejercicio si la presión arterial supera 220 mmHg sistólica o 105 mmHg diastólica según PAGA 2018."
- Mi Frase Inolvidable de Coaching: EN: "When medication changes your heart rate, listening to your perceived effort keeps your workout safe and effective!" "¡Cuando los medicamentos cambian su frecuencia cardíaca, escuchar su esfuerzo percibido mantiene su entrenamiento seguro y efectivo!"
- EN: "When medication changes your heart rate, listening to your perceived effort keeps your workout safe and effective!"
- "¡Cuando los medicamentos cambian su frecuencia cardíaca, escuchar su esfuerzo percibido mantiene su entrenamiento seguro y efectivo!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M08_Quiz_Sprint.pdf
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, un reloj inteligente no puede detectar palidez, mareo, angina ni una caída de 10 mmHg en la presión sistólica durante el esfuerzo. Además, los betabloqueadores y la deriva cardiovascular por el calor de Yuma alteran el pulso, por lo que la supervisión clínica humana con Borg RPE (11–13) y la prueba del habla bajo PAGA 2018 es indispensable."
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 08 Quick Return Navigation / Regreso Rápido al Módulo 08:
