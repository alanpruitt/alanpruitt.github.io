# KIN-265: Mod 08 Lab And Simulation 03

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 08 Lab & Simulation: Vital Signs & Exercise Monitoring Audit

Laboratorio del Módulo 08: Monitoreo Cardiorrespiratorio y Simulación

- Submaximal Functional Field Testing (6-Minute Walk Test & Sit-to-Stand): Safe, self-paced clinical assessments for older or deconditioned populations that measure functional aerobic endurance and lower-body strength without maximal strain. En palabras sencillas: Pruebas clínicas seguras como la Caminata de 6 Minutos y Sentarse-Pararse en Silla para evaluar la condición física sin exponer al paciente al límite.
- Hemodynamic Exercise Response (Normal vs. Hypotensive/Hypertensive): Systolic BP should rise progressively with workload while diastolic BP remains stable (±10 mmHg); a drop in SBP >10 mmHg or SBP >250 / DBP >115 mmHg requires immediate termination. En palabras sencillas: Al subir el esfuerzo la presión sistólica debe subir de forma gradual; si cae más de 10 puntos o supera 250/115 mmHg, detenemos la prueba al instante.
- Pre- and Post-Session Vital Sign Verification Log: Recording resting heart rate, blood pressure, SpO2, symptoms, and medication timing before and after every clinical conditioning session. En palabras sencillas: Anotar pulso, presión arterial, oxigenación y si el paciente tomó sus medicamentos antes y después de cada sesión.

### Heart Rate Responses, Borg RPE, & PAGA Federal Safety Mandates

In this laboratory assignment, you will build and audit a safe exercise routine for an adult client taking medications that alter heart rate or blood pressure. Using the Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will evaluate how beta-blockers affect heart rate, apply Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety rules, use triple-hash delimiters (`###`), and complete an AI-guided simulation using Google Gemini.

En esta práctica de laboratorio, diseñará y auditará una rutina de ejercicio segura para un cliente que toma medicamentos que alteran la frecuencia cardíaca o la presión arterial, aplicando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución).

- KIN-265.8.1.AY26-27: Prescribe safe aerobic exercise intensity using the Borg RPE scale for clients with altered heart rate responses. Prescribir intensidad de ejercicio aeróbico segura usando la escala Borg RPE para clientes con respuestas cardíacas alteradas.
- KIN-265.8.2.AY26-27: Audit clinical blood pressure safety limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de seguridad de presión arterial y aplicar protocolos de verificación de IA basados en delimitadores.
- Module Window / Ventana del Módulo: Opens Tuesday, October 6, 2026, at 12:00 AM MST Abre el martes, 6 de octubre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, October 12, 2026, at 11:59 PM MST Lunes, 12 de octubre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación de Calificación: Weekly Labs & Simulations Benchmark Ponderación de evaluación para laboratorios semanales y simulaciones clínicas

### Lab Objectives

Objetivos del Laboratorio

- Analyze how beta-blocker medications change resting and exercise heart rate responses. Analizar cómo los medicamentos betabloqueadores cambian las respuestas de la frecuencia cardíaca.
- Apply federal PAGA 2018 rules for blood pressure safety limits (stop test if SBP > 220 or DBP > 105). Aplicar las reglas federales de PAGA 2018 para los límites de seguridad de la presión arterial.
- Formulate a safe 4-week exercise plan using the Safety Auditor protocol (`###`) and a bilingual client instruction card. Formular un plan de ejercicio seguro de 4 semanas usando el protocolo del Auditor de Seguridad y una tarjeta bilingüe.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-08

Fase 1: Selección de Escenario de Simulación Clínica y Revise los Datos Clínicos

Choose ONE of the client case profiles below:

Focus: Managing controlled hypertension while taking daily beta-blockers; establishing safe walking intensity using the Borg RPE scale.


### Phase 2: Gemini AI Clinical Simulation Workspace

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI, keeping your chosen case profile inside the triple-hash delimiters:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

- Client Name: State the client profile you selected.
- Part 1: Pattern Recognition: Explain how beta-blocker medications affect heart rate and why standard heart rate targets do not apply.
- Part 2: Rule Application: Cite PAGA 2018 safety limits for blood pressure stop tests (SBP > 220 or DBP > 105) and Borg RPE intensity targets.
- Part 3: Solving the Gap: Outline a simple 4-week exercise plan and include the 2-sentence bilingual client instruction card.
- Repository Verification: Confirm your AI prompt exchange is saved to EXW_Professional_AI_Repository .
- Part 3: Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice justifying your pre-exercise vital-sign clearance gates, Borg RPE / Talk Test monitoring, and absolute stop-exercise criteria in Yuma's climate.

### Grading Rubric (10/7/0 Mastery Scale • Safety Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega

Part 1: Pattern Recognition: Robert takes a beta-blocker (metoprolol) for high blood pressure, which lowers his resting heart rate and stops his heart rate from rising normally during exercise. Standard heart rate formulas will not work for him, so we must monitor his workout intensity using the Borg RPE scale.

Part 2: Rule Application: According to PAGA 2018 guidelines, trainers must stop an exercise session immediately if blood pressure exceeds 220 mmHg systolic or 105 mmHg diastolic. We will keep Robert's walking intensity at a light-to-moderate level (Borg RPE 11 to 13) and use triple-hash delimiters (`###`) for our AI verification audit.

Part 3: Solving the Gap (Prescription Plan & Bilingual Card): Key Point — Aerobic Routine: Indoor treadmill or neighborhood walking 3 days per week for 30 minutes, maintaining an easy conversation pace (Borg RPE 11–13). Key Point — Strength Routine: Light resistance exercises 2 days per week focusing on major muscle groups, using continuous breathing to avoid breath-holding. Key Point — Safety Rule: Stop exercising if dizzy, short of breath, or if blood pressure crosses safety limits.

EN: "Because your blood pressure medication lowers your heart rate, use your perceived effort scale (RPE 11 to 13) to guide your workout instead of checking your pulse. Always breathe continuously while lifting weights to keep your blood pressure stable."

ES: "Debido a que su medicamento para la presión arterial reduce su frecuencia cardíaca, use su escala de esfuerzo percibido (RPE 11 a 13) para guiar su entrenamiento en lugar del pulso. Respire continuamente al levantar pesas para mantener estable su presión arterial."

Part 3: Active Verification (150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified AI fitness app that pushes a client to 85% age-predicted HRmax ignores both beta-blocker chronotropic blunting and thermal cardiovascular drift in Yuma. As the human clinician, I verify resting blood pressure (<180/110 mmHg), pulse oximetry (>=88%), and blood glucose (100–250 mg/dL) before every session, regulate intensity using Borg RPE 11–13 and the Talk Test, and stand ready to terminate exertion immediately if SBP drops >10 mmHg with increasing workload or exceeds 220/105 mmHg. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M08_Lab_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 08) / Simulación Clínica y Dominio de Resultados (Módulo 08)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 08 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 08 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 08 (Mod 08 Lab: Vital Signs & Exercise Monitoring Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All assignment materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA standards. Layouts are mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 08 Práctica de Lab y Simulación: Monitoreo Cardiorrespiratorio y Simulación

Frecuencia cardíaca, escala Borg RPE y normas de seguridad PAGA


### Respuestas de la frecuencia cardíaca, escala Borg RPE y normas PAGA

En esta práctica de laboratorio, diseñará y auditará una rutina de ejercicio segura para un cliente que toma medicamentos que alteran la frecuencia cardíaca. Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , evaluará cómo los betabloqueadores afectan el ritmo cardíaco, aplicará las normas de seguridad de PAGA 2018 (2.ª edición) y completará una simulación con Google Gemini.


### Estructura de Entrega de Texto


#### Nombre del Cliente

Indique el perfil del cliente seleccionado (Robert).


#### Parte 1: Reconocimiento de Patrones

Explique cómo los betabloqueadores afectan la frecuencia cardíaca y por qué las fórmulas tradicionales no funcionan.


#### Parte 2: Aplicación de Reglas (Guías PAGA 2018)

Cite los límites de seguridad de PAGA 2018 para la presión arterial (PAS > 220 / PAD > 105) y las metas de esfuerzo Borg RPE.


#### Parte 3: Resolución de la Brecha

Delinee un plan de ejercicio simple de 4 semanas e incluya la tarjeta de instrucciones bilingüe.


### Modelo de Respuesta de Alta Fidelidad 10/10

Parte 1: Reconocimiento de Patrones: Robert toma un betabloqueador para la presión arterial alta, lo que reduce su frecuencia cardíaca en reposo e impide que su pulso suba normalmente al hacer ejercicio. Las fórmulas estándar no funcionan, por lo que debemos usar la escala RPE de Borg.

Parte 2: Aplicación de Reglas: Según las pautas de PAGA 2018, debemos detener el ejercicio de inmediato si la presión arterial supera los 220 mmHg sistólica o los 105 mmHg diastólica. Mantendremos la intensidad en un nivel moderado (Borg RPE 11 a 13) y usaremos delimitadores de tres numerales (`###`).

Parte 3: Resolución de la Brecha: Caminata en interior o vecindario 3 días por semana durante 30 minutos (RPE 11–13) y ejercicios de fuerza ligeros 2 días por semana. Tarjeta Bilingüe: "Debido a que su medicamento para la presión arterial reduce su frecuencia cardíaca, use su escala de esfuerzo percibido (RPE 11 a 13) para guiar su entrenamiento en lugar del pulso. Respire continuamente al levantar pesas para mantener estable su presión arterial."

Parte 3: La Verificación Activa (Obligatoria — Mínimo 150 Palabras en su Propia Voz): Justifique en su propia voz clínica sus filtros de signos vitales en reposo, el monitoreo con Borg RPE / prueba del habla y los criterios absolutos para detener el ejercicio en Yuma.

Parte 3: La Verificación Activa (Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, una aplicación de IA que exige alcanzar el 85% de la FCmáx teórica ignora el bloqueo cardíaco por betabloqueadores y la deriva térmica en el calor de Yuma. Como especialista humano, verifico signos vitales en reposo (PA <180/110 mmHg, SpO2 >=88%, glucosa 100–250 mg/dL), regulo la carga con Borg RPE 11–13 y detengo la sesión de inmediato ante cualquier signo de alarma hemodinámica."

Verificación del Repositorio: Registro de auditoría guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M08_Lab_Audit.pdf

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 08 Quick Return Navigation / Regreso Rápido al Módulo 08:
