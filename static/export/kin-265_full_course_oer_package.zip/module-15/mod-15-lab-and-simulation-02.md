# KIN-265: Mod 15 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 15 Lab & Simulation: Organizing Your Special Populations Portfolio

- Energy Envelope Pacing & Preventing Post-Exertional Malaise (PEM): In fibromyalgia and chronic fatigue conditions, keeping session exertion within the client's available daily energy envelope prevents delayed 24–48 hour symptom crashes ('boom-and-bust' cycle). En palabras sencillas: Dosificar la energía para terminar la sesión sintiéndose con reserva, evitando el error de excederse un día y caer agotado o adolorido los siguientes dos días.
- Central Sensitization & Low-Threshold Warm-Water / Aerobic Onboarding: Starting at light-to-moderate intensity (Borg RPE 9–11, 10–15 min bouts) in warm water (83–88°F) or indoor walking to calm hyperexcitable pain pathways without triggering flares. En palabras sencillas: Empezar suave (10 a 15 minutos en RPE 9–11, en agua templada o caminata bajo techo) para bajar la sensibilidad al dolor sin provocar brotes.
- Special Populations Portfolio Triage & Documentation: Organizing multi-condition client cases by screening red flags first, mapping medication interactions second, and prescribing modified FITT-VP parameters third. En palabras sencillas: Ordenar tu portafolio clínico revisando primero señales de alerta, segundo medicamentos y tercero el plan FITT-VP adaptado.

### Lab Overview: Terminal Capstone Portfolio Compilation & Clinical Audit

In this terminal laboratory practical, you will assemble, format, and audit your comprehensive Capstone Portfolio , compiling all clinical case audits, Frequency, Intensity, Time, Type (FITT) prescriptions, and Clinical Framing Protocol (Pattern / Rule / Solve) problem sets accumulated across Modules 1 through 15 into a unified professional deliverable.

You will verify absolute compliance with federal standards ( PAGA 2018 ) and use the Gemini AI Tool Kit with secure triple-hash delimiters (###) to perform your terminal safety audit.


### Thanksgiving Week Lab Logistics & Deadlines / Logística y Fechas Límite

- Due Date / Fecha Límite: Monday, November 30, 2026, at 11:59 PM MST / Lunes 30 de noviembre de 2026 a las 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry & Google Drive Archive / Entrada en Canvas y Archivo en Drive
- Points / Puntos: 30 Total Points (10/7/0 Exemplary / Competent / Recalibrate Scale)
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Part A: Capstone Portfolio Structure & Requirements / Estructura del Portafolio

Your terminal Capstone Portfolio must include the following sections organized cleanly in your professional repository:

- Executive Summary & Professional Philosophy: Your guiding principles as a clinical exercise specialist working with special populations. Resumen ejecutivo y filosofía profesional como especialista en ejercicio clínico.
- Multi-Pathology Clinical Case Repository: Summaries of at least 5 distinct client case audits across metabolic, cardiovascular, pulmonary, neurological, and musculoskeletal/oncological domains. Repositorio de casos clínicos multi-patología cubriendo dominios metabólicos, cardiovasculares, pulmonares, neurológicos y musculoesqueléticos/oncológicos.
- Terminal Safety Audit Summary: Gemini AI Tool Kit verification logs confirming zero contraindications and strict adherence to PAGA 2018 standards using triple-hash delimiters (###). Resumen de auditoría de seguridad terminal con registros de verificación de IA Gemini y delimitadores.

### Part B: Gemini AI Tool Kit & Safety Auditor Protocol


```text
Safety Auditor Protocol: KIN-265 Module 15 Capstone ###:
Role: Senior Clinical Exercise Physiologist and Master Safety Auditor.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Audit my complete terminal Capstone Portfolio across all 15 modules.
Step 2: Verify absolute adherence to PAGA 2018 standards, zero contraindications, and proper delimiter usage (###).
Step 3: Provide terminal certification of clinical safety and professional readiness.

Portfolio Data Input ###:
Student Name: [Insert Name]
Repository Link: [Insert Google Drive / GitHub link]
Key Case Summaries: [Insert summary of audited cases]
End Portfolio Data ###:
End Safety Auditor Protocol ###:
```


### Submission Template / Plantilla de Entrega


```text
KIN-265 Module 15 Capstone Portfolio Submission ###:
Student Name / ID: [Insert Name / ID]
Repository Archive Link: [Insert Google Drive / GitHub link]

Step 1: Executive Summary & Professional Philosophy:
Key Point: [Insert brief summary]

Step 2: Clinical Case Repository Overview (Modules 1–15):
Key Point: Metabolic / Cardiovascular / Pulmonary / Neurological / Oncological / Musculoskeletal Cases Included:

Step 3: Terminal AI Safety Audit Reflection:
Key Point: Summary of Senior Auditor feedback, delimiter compliance (###), and zero-contraindication verification:
End Capstone Submission ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric / Rúbrica de Calificación (30 Points Total • 10/7/0 Scale)

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 15 (Mod 15 Lab: Organizing Your Special Populations Portfolio)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 15 Lab: Ensamblaje del Portafolio Capstone (The Heavy Lift)


### Visión General del Laboratorio: Compilación del Portafolio Capstone y Auditoría

En esta práctica terminal (The Heavy Lift), ensamblarás y auditarás tu Portafolio Capstone , compilando todas las auditorías clínicas, prescripciones FITT y problemas acumulados en los módulos 1 al 15.

Verificarás el cumplimiento de las normas federales ( PAGA 2018 ) y usarás la Caja de Herramientas Gemini con delimitadores seguros (###).


### Logística de Acción de Gracias y Fechas Límite

- Fecha Límite: Lunes 30 de noviembre de 2026 a las 11:59 PM MST
- Formato: Entrada en Canvas y Archivo en Google Drive
- Puntaje: 30 Puntos Totales (Escala 10/7/0 Exemplary / Competent / Recalibrate)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Estructura del Portafolio Capstone

- Resumen Ejecutivo y Filosofía Profesional: Principios rectores como especialista en ejercicio clínico.
- Repositorio de Casos Clínicos Multi-Patología: Al menos 5 auditorías de casos clínicos en dominios metabólicos, cardiovasculares, pulmonares, neurológicos y musculoesqueléticos.
- Resumen de Auditoría de Seguridad Terminal: Registros de verificación de la IA Gemini confirmando cero contraindicaciones.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 15 Quick Return Navigation / Regreso Rápido al Módulo 15:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
