# KIN-265: Mod 15 Overview Autoimmune Flare Ups Energy Pacing And Portfolio Prep

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 15 Overview: Autoimmune Flare-Ups, Energy Pacing & Portfolio Prep

El Porqué del Módulo 15 (Círculo Dorado — Contexto Norteño): “¿Por qué las rutinas rígidas fallan cuando hay brotes autoinmunes, y cómo el ajuste inteligente de energía permite seguir activos sin provocar inflamación?”


### Module 15 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 15: Autoimmune Flare-Ups, Energy Pacing & Portfolio Prep

Welcome to Week 15! In this module, we examine Musculoskeletal Limitations and Autoimmune Conditions (including osteoarthritis, rheumatoid arthritis, and fibromyalgia) while initiating the heavy lift of our terminal Capstone Portfolio synthesis. Note: Please review the adjusted holiday deadlines below to accommodate the Thanksgiving break (November 26–27).

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify chronic pain loops, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) joint preservation rules, and compile your complete clinical audit portfolio.


### Thanksgiving Holiday Schedule & Deadlines / Horario y Fechas Límite

- Module Opens / Apertura: Tuesday, November 24, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Wednesday, November 25, 2026, at 11:59 PM MST (Shifted early for holiday)
- Campus Holiday Closure (Thanksgiving): Thursday, Nov. 26 & Friday, Nov. 27, 2026 (No classes)
- Discussion Peer Replies / Respuestas: Sunday, November 29, 2026, at 11:59 PM MST
- Capstone Portfolio Due / Entrega de Portafolio: Monday, November 30, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 15 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze joint degeneration mechanics, systemic inflammation, and chronic pain modulation. Analizar la mecánica de degeneración articular, inflamación sistémica y modulación del dolor crónico.
- CLO 2 (Rule Application): Apply PAGA 2018 low-impact loading guidelines, pain-monitoring scales, and energy envelope pacing. Aplicar pautas de carga de bajo impacto de PAGA 2018, escalas de dolor y ritmo de reserva energética.
- CLO 3 (Problem Solving): Compile and synthesize the comprehensive terminal Capspot Portfolio integrating all clinical audits. Compilar y sintetizar el Portafolio Capstone terminal integrando todas las auditorías clínicas.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Capspot Lab, you will work within your chosen career track:

Managing joint-sparing functional conditioning and physical therapy protocols for patients with advanced arthritic limitations.

Designing community-based movement classes for older adults managing fibromyalgia and chronic joint stiffness in Yuma.

Screening tactical personnel and heavy-labor workers for cumulative joint trauma and designing ergonomic mitigation protocols.


### Module 15 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Joint Mechanics, Autoimmune Pacing & PAGA 2018 Standards
- Discussion Board: Arthritis Pain Management & Cross-System Barriers (Initial post due Wednesday before Thanksgiving)
- Coaching Sprint: Applied Clinical Reasoning & Practical Coaching Drills
- Lab Assignment: Capstone Portfolio Assembly (The Heavy Lift)
- Summary & Wrap-Up: Knowledge Check & Transition to Final Module 16
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 15 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 15 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 15 (Mod 15 Overview: Autoimmune Flare-Ups, Energy Pacing & Portfolio Prep)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 15 Visión General: Limitaciones Musculoesqueléticas y Portafolio Final


### Bienvenido al Módulo 15: Artritis, Fibromialgia y Portafolio Capstone

¡Bienvenido a la Semana 15! En este módulo examinamos las Limitaciones Musculoesqueléticas y Condiciones Autoinmunes mientras iniciamos el ensamblaje de nuestro Portafolio Capstone terminal. Nota: Revise las fechas ajustadas debido al feriado de Acción de Gracias (26-27 de noviembre).

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones de dolor crónico, aplicarás las normas de PAGA 2018 y compilarás tu portafolio de auditoría clínica.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar la mecánica de degeneración articular y modulación del dolor.
- CLO 2 (Regla): Aplicar normas de PAGA 2018, carga de bajo impacto y ritmo energético.
- CLO 3 (Solución): Compilar y sintetizar el Portafolio Capstone terminal con todas las auditorías.

### Construya su Propio Camino • Vista previa de las 3 rutas

En las actividades de este módulo, trabajarás dentro de la ruta seleccionada:

Manejo de acondicionamiento funcional y protocolos de fisioterapia para pacientes con artritis avanzada.

Diseño de clases comunitarias para adultos mayores con fibromialgia y rigidez articular en Yuma.

Tamizaje de personal táctico para trauma articular acumulativo y diseño de protocolos ergonómicos.


### Ruta de Aprendizaje del Módulo 15

- Visión General y Objetivos del Módulo (¡Estás aquí!)
- Lectura Principal: Mecánica Articular, Ritmo y PAGA 2018
- Foro de Discusión: Artritis, Dolor y Barreras (Publicación inicial el miércoles antes de Acción de Gracias)
- Sprint de Entrenamiento: Razonamiento Clínico Aplicado y Práctica
- Práctica de Laboratorio: Ensamblaje del Portafolio Capstone
- Comprobación de Conocimientos y Transición al Módulo 16

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 15 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 15 Required Readings: Autoimmune Flare-Ups, Energy Pacing & Portfolio Prep →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 15 Discussion: Pacing Exercise Around Autoimmune Flare-Ups →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 15 Coaching Sprint: Daily Energy Pacing & Joint Protection →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 15 Lab: Organizing Your Special Populations Portfolio →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 15 Summary & Wrap-Up: Autoimmune Flare-Ups, Energy Pacing & Portfolio Prep →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
