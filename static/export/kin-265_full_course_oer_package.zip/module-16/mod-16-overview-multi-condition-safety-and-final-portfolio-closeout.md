# KIN-265: Mod 16 Overview Multi Condition Safety And Final Portfolio Closeout

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 16 Overview: Multi-Condition Safety & Final Portfolio Closeout

El Porqué del Módulo 16 (Círculo Dorado — Contexto Norteño): “¿Por qué los pacientes reales casi nunca tienen una sola condición aislada, y cómo demuestra tu Portafolio Final que sabes priorizar la seguridad integral?”


### Module 16 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 16: Multi-Condition Safety & Final Portfolio Closeout

Welcome to our final week! In this compressed 5-day sprint (Monday, November 30 – Friday, December 4, 2026), we examine Renal Physiology, Chronic Kidney Disease (CKD Stages 3–5), and Intradialytic Exercise while completing our terminal capstone synthesis and final portfolio safety audit. Note: As our final week of the semester, all deliverables are due by Friday to complete course closeout.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify uremic myopathy patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) renal safety rules, and execute your terminal portfolio audit.


### 5-Day Sprint Schedule & Deadlines / Horario y Fechas Límite (Sprint de 5 Días)

- Module Opens / Apertura: Monday, November 30, 2026, at 12:00 AM MST
- Coaching Sprint Check-In: Wednesday, December 2, 2026, at 11:59 PM MST
- Terminal Capstone Synthesis & Final Portfolio Audit Due: Friday, December 4, 2026, at 11:59 PM MST (Semester Closeout)

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 16 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze renal physiology, uremic myopathy, and fluid/electrolyte imbalances in CKD stages 3–5. Analizar la fisiología renal, la miopatía urémica y los desequilibrios de líquidos en la ERC etapas 3–5.
- CLO 2 (Rule Application): Apply PAGA 2018 renal safety standards and intradialytic exercise precautions. Aplicar normas de seguridad renal de PAGA 2018 y precauciones para el ejercicio intradialítico.
- CLO 3 (Problem Solving): Execute the terminal Capstone Synthesis and Final Portfolio Safety Audit verifying zero contraindications. Ejecutar la síntesis terminal de Capstone y la auditoría final de seguridad del portafolio verificando cero contraindicaciones.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this final Module's Lab and Capstone Audit, you will work within your chosen career track:

Managing intradialytic exercise protocols and blood pressure stability in hospital-affiliated dialysis clinics.

Designing community-based renal health and low-impact conditioning programs for older adults managing stage 3 CKD in Yuma.

Screening tactical personnel for hydration status, electrolyte balance, and heat-stress renal vulnerability.


### Module 16 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Renal Physiology, CKD & PAGA 2018 Standards
- Discussion Board: (Omitted for 5-day sprint compression)
- Coaching Sprint: Applied Clinical Reasoning & Intradialytic Protocols
- Lab Assignment: Capstone Synthesis & Final Portfolio Safety Audit
- Summary & Wrap-Up: Semester Closeout & Repository Archival
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 16 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 16 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 16 (Mod 16 Overview: Multi-Condition Safety & Final Portfolio Closeout)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 16 Visión General: Enfermedad Renal Crónica y Cierre del Curso (Sprint de 5 Días)


### Bienvenido al Módulo 16: Enfermedad Renal Crónica, Ejercicio Intradialítico y Cierre

¡Bienvenido a nuestra última semana! En este sprint comprimido de 5 días (lunes 30 de noviembre – viernes 4 de diciembre de 2026), examinamos la Fisiología Renal, la Enfermedad Renal Crónica (ERC Etapas 3–5) y el Ejercicio Intradialítico mientras completamos nuestra síntesis terminal y auditoría final del portafolio. Nota: Al ser nuestra última semana, todas las entregas vencen el viernes.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones de miopatía urémica, aplicarás las normas de PAGA 2018 y ejecutarás tu auditoría final.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar la fisiología renal, la miopatía urémica y los desequilibrios de líquidos en la ERC etapas 3–5.
- CLO 2 (Regla): Aplicar normas de seguridad renal de PAGA 2018 y precauciones para el ejercicio intradialítico.
- CLO 3 (Solución): Ejecutar la síntesis terminal de Capstone y la auditoría final de seguridad del portafolio.

### Construya su Propio Camino • Vista previa de las 3 rutas

En las actividades de este módulo, trabajarás dentro de la ruta seleccionada:

Manejo de protocolos de ejercicio intradialítico y estabilidad de la presión arterial en clínicas de diálisis.

Diseño de programas comunitarios de salud renal y acondicionamiento para adultos mayores con ERC etapa 3 en Yuma.

Tamizaje de personal táctico para estado de hidratación, balance electrolítico y vulnerabilidad renal por estrés térmico.


### Ruta de Aprendizaje del Módulo 16

- Visión General y Objetivos del Módulo (¡Estás aquí!)
- Lectura Principal: Fisiología Renal, ERC y PAGA 2018
- Foro de Discusión: (Omitido por compresión de sprint)
- Sprint de Entrenamiento: Razonamiento Clínico e Intradialítico
- Práctica de Laboratorio: Síntesis Capstone y Auditoría Final
- Resumen y Cierre del Semestre

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 16 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 16 Required Readings: Multi-Condition Safety & Final Portfolio Closeout →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 16 Coaching Sprint: Multi-Condition Safety & Final Review →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 16: Final Special Populations Portfolio & Safety Defense →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 16 Summary & Wrap-Up: Multi-Condition Safety & Final Portfolio Closeout →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
