# KIN-265: Mod 16 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 16 Coaching Sprint Simulation: Multi-Condition Safety & Final Review

Sesión de Coaching del Módulo 16: Enfermedad Renal y Seguridad Intradialítica

- Multi-Comorbidity Safety Hierarchy (Most Restrictive Rule Wins): When a client presents with multiple conditions (e.g., hypertension + Type 2 diabetes + knee osteoarthritis), the prescription must satisfy the strictest safety gate of every condition simultaneously. En palabras sencillas: Cuando un paciente tiene varias condiciones a la vez (ej. presión alta, diabetes y desgaste de rodilla), siempre respetamos la regla de seguridad más estricta de cada una.
- Polypharmacy & Exercise-Medication Interaction Audit: Accounting for combined effects of beta-blockers (blunted HR), insulin/secretagogues (hypoglycemia risk), diuretics (dehydration/electrolyte loss in Yuma heat), and vasodilators (post-exercise hypotension). En palabras sencillas: Revisar cómo interactúan todas las pastillas del paciente con el ejercicio y el calor de Yuma (betabloqueadores, insulina, diuréticos).
- Comprehensive Multicomponent FITT-VP & Emergency Stop Defense: Delivering an evidence-based aerobic, resistance, and balance program with explicit numeric stop criteria and a plain-language bilingual client action card. En palabras sencillas: Presentar un programa completo de cardio, fuerza y equilibrio con límites numéricos claros para detenerse a tiempo y su guía bilingüe.
- KIN-265.16.1.AY26-27: Prescribe safe exercise intensity for clients with chronic kidney disease managing dialysis and fluid balance across diverse career tracks. Prescribir intensidad de ejercicio seguro para clientes con enfermedad renal crónica manejando diálisis y balance de líquidos.
- KIN-265.16.2.AY26-27: Audit intradialytic safety limits and apply delimiter-based AI verification protocols. Auditar límites de seguridad intradialítica y aplicar protocolos de verificación con IA basados en delimitadores.

### Your Weekly Win: Mastering Intradialytic Rules & Renal Safety Protocols

How can fitness professionals safely monitor exercise intensity when a client is undergoing hemodialysis treatments? Because standard metrics do not capture uremic myopathy or fluid shifts, exercise specialists use RPE tracking and intradialytic cycling precautions. Following strict PAGA 2018 clinical guidelines, trainers improve functional capacity during dialysis. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master renal safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente recibe hemodiálisis? Usando seguimiento de RPE y precauciones de ciclismo intradialítico de PAGA 2018. ¡Elija una ruta, dialogue con su coach de IA y domine la auditoría renal!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient hemodialysis clinic client with stage 5 CKD experiencing uremic myopathy and fatigue; establishing intradialytic cycling progression.

Scenario: Community wellness center participant with stage 3 CKD and secondary hypertension; formulating a low-impact renal health walking routine.

Scenario: Military service member recovering from exertional heat injury with mild acute kidney injury (AKI) history; designing a hydration and electrolyte monitoring protocol.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Robert, Theresa, or Specialist Gomez).
- Renal Analysis: Explain the key uremic myopathy or fluid balance consideration for your selected client.
- My Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment utilizing the Safety Auditor protocol.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 16 Coaching Sprint • Track 1 (Robert)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Robert (Age 58).
- Renal Analysis: Robert has end-stage renal disease undergoing hemodialysis with uremic myopathy. Because muscle wasting impairs functional capacity, we use intradialytic cycling during the first two hours of dialysis to combat atrophy safely.
- My Safety Audit for Robert: "Monitor Robert's blood pressure stability and execute intradialytic cycling exclusively during the first two hours of hemodialysis before fluid shifts cause hypotension per PAGA 2018 guidelines."
- "Monitor Robert's blood pressure stability and execute intradialytic cycling exclusively during the first two hours of hemodialysis before fluid shifts cause hypotension per PAGA 2018 guidelines."
- My Memorable Coaching Takeaway: EN: "Exercising during dialysis combats muscle wasting and turns treatment time into active recovery!" "¡Hacer ejercicio durante la diálisis combate la pérdida muscular y convierte el tiempo de tratamiento en recuperación activa!"
- EN: "Exercising during dialysis combats muscle wasting and turns treatment time into active recovery!"
- "¡Hacer ejercicio durante la diálisis combate la pérdida muscular y convierte el tiempo de tratamiento en recuperación activa!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M16_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 16 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 16 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 16 (Mod 16 Coaching Sprint: Multi-Condition Safety & Final Review)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 16 Simulación de Coaching: Enfermedad Renal y Seguridad Intradialítica

Evaluación Rápida y Auditoría de Seguridad Renal


### Su Logro Semanal: Dominando las Reglas Intradialíticas y Protocolos Renales

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar seguimiento de RPE y ciclismo intradialítico en pacientes con enfermedad renal. ¡Elija una ruta, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente en hemodiálisis con ERC etapa 5 y miopatía urémica; establecer ciclismo intradialítico.

Escenario: Participante con ERC etapa 3 e hipertensión secundaria; formular caminata aeróbica de salud renal.

Escenario: Militar recuperándose de lesión por calor con historial de LRA; diseñar protocolo de hidratación renal.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Robert, Theresa o Specialist Gomez).
- Análisis Renal: Explique la consideración clave de miopatía urémica o balance de líquidos para su cliente.
- Mi Auditoría de Seguridad: Escriba 1 parámetro de seguridad claro o ajuste de prescripción usando la sincronización de diálisis.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 16, Sesión de Coaching • Ruta 1 (Robert)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Robert (58 años).
- Análisis Renal: Robert tiene enfermedad renal terminal en hemodiálisis con miopatía urémica. Usamos ciclismo intradialítico durante las primeras dos horas para combatir la atrofia sin causar hipotensión.
- Mi Auditoría de Seguridad para Robert: "Monitorear la estabilidad de la presión arterial de Robert y ejecutar el ciclismo intradialítico exclusivamente durante las primeras dos horas de hemodiálisis según PAGA 2018."
- "Monitorear la estabilidad de la presión arterial de Robert y ejecutar el ciclismo intradialítico exclusivamente durante las primeras dos horas de hemodiálisis según PAGA 2018."
- Mi Frase Inolvidable de Coaching: EN: "Exercising during dialysis combats muscle wasting and turns treatment time into active recovery!" "¡Hacer ejercicio durante la diálisis combate la pérdida muscular y convierte el tiempo de tratamiento en recuperación activa!"
- EN: "Exercising during dialysis combats muscle wasting and turns treatment time into active recovery!"
- "¡Hacer ejercicio durante la diálisis combate la pérdida muscular y convierte el tiempo de tratamiento en recuperación activa!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M16_Quiz_Sprint.pdf
KIN-265 • Module 16 Quick Return Navigation / Regreso Rápido al Módulo 16:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
