# KIN-265: Mod 16 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 16 Capstone Simulation: Final Special Populations Portfolio & Safety Defense

- Multi-Comorbidity Safety Hierarchy (Most Restrictive Rule Wins): When a client presents with multiple conditions (e.g., hypertension + Type 2 diabetes + knee osteoarthritis), the prescription must satisfy the strictest safety gate of every condition simultaneously. En palabras sencillas: Cuando un paciente tiene varias condiciones a la vez (ej. presión alta, diabetes y desgaste de rodilla), siempre respetamos la regla de seguridad más estricta de cada una.
- Polypharmacy & Exercise-Medication Interaction Audit: Accounting for combined effects of beta-blockers (blunted HR), insulin/secretagogues (hypoglycemia risk), diuretics (dehydration/electrolyte loss in Yuma heat), and vasodilators (post-exercise hypotension). En palabras sencillas: Revisar cómo interactúan todas las pastillas del paciente con el ejercicio y el calor de Yuma (betabloqueadores, insulina, diuréticos).
- Comprehensive Multicomponent FITT-VP & Emergency Stop Defense: Delivering an evidence-based aerobic, resistance, and balance program with explicit numeric stop criteria and a plain-language bilingual client action card. En palabras sencillas: Presentar un programa completo de cardio, fuerza y equilibrio con límites numéricos claros para detenerse a tiempo y su guía bilingüe.

### Lab Overview: Terminal Capstone Synthesis & Final Safety Audit

In this final laboratory practical of the semester, you will execute your Capstone Synthesis and run your complete multi-pathology portfolio through the Gemini AI Tool Kit Safety Auditor protocol, verifying absolute zero contraindications and full compliance with federal standards ( PAGA 2018 ).

You will utilize secure triple-hash delimiters (`###`) to complete your terminal evaluation and close out the course fleet.


### 5-Day Sprint Lab Logistics & Deadlines / Logística y Fechas Límite

- Due Date / Fecha Límite: Friday, December 4, 2026, at 11:59 PM MST / Viernes 4 de diciembre de 2026 a las 11:59 PM MST (Semester Closeout)
- Format / Formato: Direct Canvas Text Entry & Google Drive Archive / Entrada en Canvas y Archivo en Drive
- Points / Puntos: 30 Total Points (10/7/0 Exemplary / Competent / Recalibrate Scale)
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Part A: Capstone Synthesis & Multi-Pathology Defense / Síntesis Capstone

Your final synthesis requires you to analyze an overlapping multi-pathology client profile (e.g., an aging individual presenting with cardiovascular, metabolic, and renal comorbidities) and defend your exercise prescription against PAGA 2018 standards.


### Part B: Gemini AI Tool Kit & Final Safety Auditor Protocol


```text
Safety Auditor Protocol: KIN-265 Module 16 Final Audit ###:
Role: Senior Clinical Exercise Physiologist and Terminal Safety Auditor.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Audit my complete 16-module portfolio and Capstone Synthesis.
Step 2: Verify absolute adherence to PAGA 2018 standards, zero contraindications, and proper delimiter usage (###).
Step 3: Provide final professional certification of clinical safety and readiness.

Terminal Audit Input ###:
Student Name: [Insert Name]
Repository Archive Link: [Insert Google Drive / GitHub link]
Multi-Pathology Synthesis Summary: [Insert summary]
End Terminal Audit Input ###:
End Safety Auditor Protocol ###:
```


### Submission Template / Plantilla de Entrega


```text
KIN-265 Module 16 Final Lab & Portfolio Audit Submission ###:
Student Name / ID: [Insert Name / ID]
Repository Archive Link: [Insert Google Drive / GitHub link]

Step 1: Capstone Synthesis (Multi-Pathology Client Analysis):
Key Point: Client Profile & Overlapping Comorbidities:
Key Point: Prioritized PAGA 2018 Safety Guidelines:

Step 2: Final Portfolio Safety Audit Logs:
Key Point: Summary of Senior Auditor feedback, delimiter compliance (###), and zero-contraindication verification:
End Final Submission ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric / Rúbrica de Calificación (30 Points Total • 10/7/0 Scale)

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 16 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 16 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 16 (Mod 16: Final Special Populations Portfolio & Safety Defense)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 16 Lab: Síntesis Capstone y Auditoría Final de Seguridad


### Visión General del Laboratorio: Síntesis Capstone y Auditoría Terminal

En esta práctica terminal del semestre, ejecutarás tu Síntesis Capstone y auditarás tu portafolio completo a través del Auditor de Seguridad Gemini , verificando cero contraindicaciones y cumplimiento con PAGA 2018.

Utilizarás delimitadores de tres numerales (`###`) para completar tu evaluación terminal y cerrar el curso.


### Logística del Sprint y Fechas Límite

- Fecha Límite: Viernes 4 de diciembre de 2026 a las 11:59 PM MST (Cierre del semestre)
- Formato: Entrada en Canvas y Archivo en Google Drive
- Puntaje: 30 Puntos Totales (Escala 10/7/0 Exemplary / Competent / Recalibrate)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Síntesis Capstone

Analiza un perfil de cliente con múltiples patologías superpuestas y defiende tu prescripción de ejercicio frente a las normas PAGA 2018.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 16 Quick Return Navigation / Regreso Rápido al Módulo 16:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
