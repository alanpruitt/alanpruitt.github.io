# KIN-265: Mod 14 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 14 Coaching Sprint Simulation: Managing Fatigue & Safety in Cancer Recovery

Sesión de Coaching del Módulo 14: Oncología del Ejercicio y Seguridad en la Supervivencia

- Cancer-Related Fatigue (CRF) & Daily Autoregulated Pacing: Unlike normal fatigue, CRF is not relieved by rest alone; short, light-to-moderate bouts (10–30 min at RPE 11–12) reduce CRF when volume is adjusted daily to treatment cycles. En palabras sencillas: La fatiga por tratamiento de cáncer mejora con caminatas y fuerza suave de 10 a 30 minutos (RPE 11–12), ajustando la sesión según cómo amanezca el paciente cada día.
- Lymphedema & Post-Surgical Resistance Progression: Gradual, low-load progressive resistance training is safe and does not trigger lymphedema when progressed slowly while monitoring for limb heaviness or swelling (compression sleeve if prescribed). En palabras sencillas: El ejercicio de fuerza progresivo y suave es seguro tras cirugía de cáncer; subimos peso poco a poco vigilando que no haya inflamación en el brazo o pierna.
- Chemotherapy/Radiation Safety Gates (Anemia, Neutropenia & Cardiotoxicity): Avoid public pools/crowded gyms during severe neutropenia (infection risk), avoid swimming over irradiated skin, and monitor HR/RPE closely after cardiotoxic chemotherapy. En palabras sencillas: Si las defensas están bajas por quimioterapia, evitar albercas públicas o gimnasios llenos para prevenir infecciones y vigilar de cerca el corazón.
- KIN-265.14.1.AY26-27: Prescribe safe aerobic and resistance exercise intensity for cancer survivors managing fatigue, bone metastases, or lymphedema across diverse career tracks. Prescribir intensidad de ejercicio seguro para sobrevivientes de cáncer manejando fatiga, metástasis óseas o linfedema en diversas rutas.
- KIN-265.14.2.AY26-27: Audit clinical oncology safety limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de seguridad oncológica y aplicar protocolos de verificación con IA basados en delimitadores.

### Your Weekly Win: Mastering Oncology Fatigue Management & Bone Safety Rules

How can fitness professionals safely monitor exercise intensity when a client is managing cancer-related fatigue or bone metastases? Because standard metrics do not capture oncological exhaustion, exercise specialists use energy envelope pacing, symptom-guided RPE tracking, and bone-loading precautions. Following strict PAGA 2018 clinical guidelines, trainers combat fatigue while protecting compromised skeletal areas. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master oncology safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente padece fatiga por cáncer o metástasis óseas? Usando ritmos de reserva energética, seguimiento guiado de RPE y precauciones óseas de PAGA 2018. ¡Elija una ruta, dialogue con su coach de IA y domine la auditoría oncológica!

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Oncology Fatigue Pacing (RPE 3–5) & Multicomponent Safety Calibrator (/simulators/cyoj-module11) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate symptom-guided aerobic and resistance dosing (relative intensity RPE 3–5 on 0–10 scale, micro-bout pacing, and anemia/lymphedema red-flag gates per PAGA 2018 Ch. 6). Copy your VERIFIED simulator receipt or slider values into the submission template below • Paired Oncology & Autoimmune Fatigue Pacing route: /simulators/fatigue-pacing-auditor .

Open Oncology Fatigue Pacing (RPE 3–5) & Multicomponent Safety Calibrator in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale)

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/cyoj-module11 y "PAGA"): Calibre la dosis guiada por síntomas (RPE 3–5 en escala 0–10, pausas frecuentes y alertas de anemia/linfedema según PAGA 2018 Cap. 6). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Post-chemotherapy breast cancer survivor experiencing persistent cancer-related fatigue and mild upper-extremity lymphedema; establishing gradual aerobic and resistance conditioning.

Scenario: Senior community center participant in prostate cancer remission with localized bone metastases in the thoracic spine; formulating a spine-safe weight-bearing walking routine.

Scenario: Fire department captain returning to duty following cancer treatment with localized deconditioning and neuropathy; designing a graduated occupational work-hardening protocol.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Sarah, Arthur, or Captain Miller).
- Oncological Analysis: Explain the key fatigue or skeletal consideration for your selected client.
- My Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment utilizing the Safety Auditor protocol.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 14 Coaching Sprint • Track 1 (Sarah)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Sarah (Age 52).
- Oncological Analysis: Sarah is a breast cancer survivor experiencing persistent fatigue and mild left-arm lymphedema. Because fatigue does not improve with rest alone, we use gradual aerobic progression and ensure compression-supported strength training.
- My Safety Audit for Sarah: "Monitor Sarah's fatigue levels using an energy envelope approach, start aerobic exercise in short 10-minute bouts, and ensure she wears her prescribed compression sleeve during upper-extremity resistance exercises per PAGA 2018 guidelines."
- "Monitor Sarah's fatigue levels using an energy envelope approach, start aerobic exercise in short 10-minute bouts, and ensure she wears her prescribed compression sleeve during upper-extremity resistance exercises per PAGA 2018 guidelines."
- My Memorable Coaching Takeaway: EN: "Gentle, consistent movement safely recharges your energy and helps you reclaim your strength after cancer treatment!" "¡El movimiento suave y constante recarga de manera segura tu energía y te ayuda a recuperar tu fuerza después del tratamiento contra el cáncer!"
- EN: "Gentle, consistent movement safely recharges your energy and helps you reclaim your strength after cancer treatment!"
- "¡El movimiento suave y constante recarga de manera segura tu energía y te ayuda a recuperar tu fuerza después del tratamiento contra el cáncer!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M14_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 14 (Mod 14 Coaching Sprint: Managing Fatigue & Safety in Cancer Recovery)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 14 Simulación de Coaching: Oncología del Ejercicio y Seguridad

Evaluación Rápida y Auditoría de Seguridad Oncológica


### Su Logro Semanal: Dominando el Manejo de la Fatiga y las Reglas Óseas

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para manejar la fatiga oncológica y las precauciones óseas. ¡Elija una ruta, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Sobreviviente de cáncer de mama con fatiga persistente y linfedema leve; establecer acondicionamiento gradual.

Escenario: Participante senior con metástasis óseas estables en columna torácica; formular caminata aeróbica segura.

Escenario: Capitán de bomberos regresando al servicio tras tratamiento de cáncer con neuropatía; diseñar protocolo de reendurecimiento.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Sarah, Arthur o Captain Miller).
- Análisis Oncológico: Explique la consideración clave de fatiga o esquelética para su cliente.
- Mi Auditoría de Seguridad: Escriba 1 parámetro de seguridad claro o ajuste de prescripción.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Exemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 14, Sesión de Coaching • Ruta 1 (Sarah)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Sarah (52 años).
- Análisis Oncológico: Sarah es sobreviviente de cáncer de mama con fatiga y linfedema. Usamos progresión aeróbica gradual y fuerza con compresión.
- Mi Auditoría de Seguridad para Sarah: "Monitorear los niveles de fatiga de Sarah en sesiones cortas de 10 minutos y asegurar que use su manga de compresión durante ejercicios de resistencia superior según PAGA 2018."
- "Monitorear los niveles de fatiga de Sarah en sesiones cortas de 10 minutos y asegurar que use su manga de compresión durante ejercicios de resistencia superior según PAGA 2018."
- Mi Frase Inolvidable de Coaching: EN: "Gentle, consistent movement safely recharges your energy and helps you reclaim your strength after cancer treatment!" "¡El movimiento suave y constante recarga de manera segura tu energía y te ayuda a recuperar tu fuerza después del tratamiento contra el cáncer!"
- EN: "Gentle, consistent movement safely recharges your energy and helps you reclaim your strength after cancer treatment!"
- "¡El movimiento suave y constante recarga de manera segura tu energía y te ayuda a recuperar tu fuerza después del tratamiento contra el cáncer!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M14_Quiz_Sprint.pdf
KIN-265 • Module 14 Quick Return Navigation / Regreso Rápido al Módulo 14:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
