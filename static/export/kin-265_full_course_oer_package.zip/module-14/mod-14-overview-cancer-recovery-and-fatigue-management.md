# KIN-265: Mod 14 Overview Cancer Recovery And Fatigue Management

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 14 Overview: Cancer Recovery & Fatigue Management

El Porqué del Módulo 14 (Círculo Dorado — Contexto Norteño): “¿Por qué el ejercicio pasó del reposo absoluto a ser parte esencial de la recuperación del cáncer, y cómo dosificamos el esfuerzo según la energía de cada día?”


### Module 14 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 14: Cancer Recovery & Fatigue Management

Welcome to Week 14! Moving into exercise oncology, this week we examine Cancer Recovery & Fatigue Management . Cancer treatments such as chemotherapy, radiation, and surgery present unique physiological barriers including cancer-related fatigue (CRF), treatment-induced cardiotoxicity, bone fragility, and upper-extremity lymphedema risks.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify oncological fatigue patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety thresholds, and design safe aerobic and resistance conditioning programs.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, November 17, 2026, at 12:00 AM MST
- Course Evaluation Due / Evaluación del Curso: Thursday, November 19, 2026, at 11:59 PM MST
- Coaching Sprint & Peer Engagement: Sunday, November 22, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, November 23, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 14 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze tumor-specific physiological impacts, treatment cardiotoxicity, and cancer-related fatigue. Analizar impactos fisiológicos tumorales, cardiotoxicidad del tratamiento y fatiga relacionada con el cáncer.
- CLO 2 (Rule Application): Apply PAGA 2018 safety standards, bone metastasis precautions, and lymphedema compression rules. Aplicar normas de seguridad de PAGA 2018, precauciones por metástasis ósea y reglas de compresión para linfedema.
- CLO 3 (Problem Solving): Formulate an evidence-based aerobic and resistance prescription for a post-chemotherapy survivor. Formular una prescripción aeróbica y de fuerza basada en evidencia para un sobreviviente postquimioterapia.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Coaching Sprint and Lab, you will work within your chosen career track:

Managing post-chemotherapy fatigue, cardiotoxicity monitoring, and gradual aerobic conditioning in outpatient oncology clinics.

Designing community survivorship fitness programs for older adults managing bone metastases and osteopenia in Yuma.

Screening tactical personnel and public safety workers returning to heavy-duty work following cancer remission and lymph node surgery.


### Module 14 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Exercise Oncology, Fatigue Management & PAGA 2018 Standards
- Final Student Course Evaluation (Replacing standard Discussion)
- Coaching Sprint: Applied Clinical Reasoning & Practical Coaching Drills
- Lab Assignment: Oncology Exercise Prescription Audit & Gemini AI Tool Kit
- Summary & Wrap-Up: Knowledge Check & Transition to Module 15

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 14) / Simulación Clínica y Dominio de Resultados (Módulo 14)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 14 (Mod 14 Overview: Cancer Recovery & Fatigue Management)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 14 Visión General: Oncología del Ejercicio y Supervivencia al Cáncer


### Bienvenido al Módulo 14: Fatiga Oncológica, Metástasis Óseas y Ejercicio

¡Bienvenido a la Semana 14! Entrando en la oncología del ejercicio, esta semana examinamos la Prescripción de Ejercicio Oncológico . Los tratamientos contra el cáncer presentan barreras fisiológicas como la fatiga relacionada con el cáncer (CRF), la cardiotoxicidad y el riesgo de linfedema.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones de fatiga, aplicarás las normas de PAGA 2018 y diseñarás programas de acondicionamiento seguros.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar impactos tumorales, cardiotoxicidad y fatiga relacionada con el cáncer.
- CLO 2 (Regla): Aplicar normas de PAGA 2018, precauciones óseas y reglas de linfedema.
- CLO 3 (Solución): Formular una prescripción aeróbica y de fuerza para un sobreviviente postquimioterapia.

### Construya su Propio Camino • Vista previa de las 3 rutas

En las actividades de este módulo, trabajarás dentro de la ruta seleccionada:

Manejo de fatiga postquimioterapia, cardiotoxicidad y acondicionamiento aeróbico gradual en clínicas oncológicas.

Diseño de programas de supervivencia para adultos mayores con metástasis óseas y osteopenia en Yuma.

Tamizaje de personal táctico que regresa al trabajo pesado tras remisión de cáncer y cirugía linfática.


### Ruta de Aprendizaje del Módulo 14

- Visión General y Objetivos del Módulo (¡Estás aquí!)
- Lectura Principal: Oncología del Ejercicio, Fatiga y PAGA 2018
- Evaluación Final del Curso (Reemplaza el foro de discusión)
- Sprint de Entrenamiento: Razonamiento Clínico Aplicado y Práctica
- Práctica de Laboratorio: Auditoría Oncológica y Caja de Herramientas
- Comprobación de Conocimientos y Transición al Módulo 15

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 14 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 14 Required Readings: Cancer Recovery & Fatigue Management →
- Step 2 — Complete the Student Course Evaluation (Paso 2 — Evaluación del Curso): Mod 14: Final Student Course Evaluation →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 14 Coaching Sprint: Managing Fatigue & Safety in Cancer Recovery →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 14 Lab: Cancer Survivorship Exercise Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 14 Summary & Wrap-Up: Cancer Recovery & Fatigue Management →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
