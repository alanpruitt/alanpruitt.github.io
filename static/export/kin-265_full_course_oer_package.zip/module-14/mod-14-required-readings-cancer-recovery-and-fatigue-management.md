# KIN-265: Mod 14 Required Readings Cancer Recovery And Fatigue Management

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 14 Required Readings: Cancer Recovery & Fatigue Management

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from PAGA 2018 (2nd Ed., Chapters 5 & 6) & ACSM 12th Ed.), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 14): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Cancer-related fatigue is a deep, persistent exhaustion caused by tumors, chemotherapy, radiation, or surgery that rest alone does not fix. Gentle, auto-regulated aerobic and resistance exercise preserves muscle mass, heart health, and energy when daily intensity adapts to treatment symptoms. Checking for anemia, bone metastasis, lymphedema, and infection precautions keeps oncology survivors safe.


#### En Palabras Sencillas (Norteño Context)

En la recuperación del cáncer, la energía del cliente cambia día con día; por eso ajustamos la dosis de movimiento según cómo amanezca el cuerpo. Si los términos técnicos se ponen pesados, concéntrate primero en la autorregulación diaria por síntomas de fatiga y las precauciones ante linfedema o defensas bajas.


### Core Literature & Federal Standards (SSoT)

To successfully complete Module 14 workflows, course evaluations, and laboratory assignments, review the core readings below. All instructional materials are anchored strictly in our Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .

Explore how physical activity safely combats cancer-related fatigue, how to adapt resistance training for bone metastases and lymphedema, and how tailored exercise improves quality of life during survivorship.


### Reading 1: PAGA 2018 (2nd Ed.) & Exercise Oncology • Combating Treatment-Related Fatigue

Learn how tailored physical activity safely reduces cancer-related fatigue (CRF). Unlike typical tiredness, cancer-related fatigue does not improve with rest alone. PAGA 2018 guidelines show that regular, moderate aerobic and resistance exercise helps restore energy levels, improves immune function, and enhances emotional well-being during and after cancer treatments.

Study Tip: Think of exercise as a natural energy booster—gentle, consistent movement helps break the cycle of treatment-related inactivity.

Lectura 1: PAGA 2018 (2.ª ed.) y oncología del ejercicio • Combate de la fatiga relacionada con el tratamiento: Aprenda cómo la actividad física reduce de forma segura la fatiga oncológica.


### Reading 2: Clinical Guidelines & Safety Rules • Bone Metastases and Lymphedema Precautions

Understand how to modify exercise programs for clients with bone fragility or lymphedema risks. Certain cancer treatments impact bone density or require lymph node removal. Trainers must avoid high-impact or heavy loading on compromised skeletal areas and use gradual progression with compression garments when managing upper-extremity lymphedema.

Study Tip: Always check medical clearance details regarding bone metastasis sites before prescribing resistance training.

Lectura 2: Pautas clínicas y reglas de seguridad • Metástasis óseas y precauciones para el linfedema: Comprenda cómo modificar los programas de ejercicio para clientes con fragilidad ósea.


### Reading 3: Environmental Physiology & Community Support & Survivorship in Yuma

Discover how supportive community exercise environments improve recovery outcomes for cancer survivors in Yuma. Post-treatment recovery requires careful management of environmental stressors. Utilizing indoor, climate-controlled fitness spaces (72°F / 22°C) protects immune-compromised clients from extreme desert heat while fostering a supportive social network.

Study Tip: Encourage group fitness settings that offer peer encouragement and safe indoor temperatures.

Lectura 3: Fisiología ambiental y apoyo comunitario • Supervivencia en Yuma: Descubra cómo los entornos comunitarios de ejercicio mejoran la recuperación de los sobrevivientes de cáncer.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 14 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 14 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 14 (Mod 14 Required Readings: Cancer Recovery & Fatigue Management)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading texts in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los textos de lectura obligatoria en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Obligatorias del Módulo 14: Oncología del Ejercicio, Fatiga y Guías Prácticas


### Literatura Principal y Normas Federales (SSoT)

Para completar con éxito las actividades del Módulo 14, revise las lecturas principales ancladas en nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) .

Explore cómo la actividad física combate la fatiga por cáncer, cómo adaptar el entrenamiento ante metástasis óseas y linfedema, y cómo el ejercicio mejora la calidad de vida.


### Lectura 1: PAGA 2018 (2.ª ed.) y oncología • Combate de la fatiga por tratamiento

Aprenda cómo el ejercicio moderado ayuda a restaurar los niveles de energía y mejora la función inmune durante y después del tratamiento del cáncer.

Consejo de estudio: Piense en el ejercicio como un revitalizador natural que rompe el ciclo de la inactividad.


### Lectura 2: Pautas clínicas • Metástasis óseas y precauciones para el linfedema

Comprenda cómo modificar los programas para clientes con fragilidad ósea o riesgo de linfedema mediante cargas graduales y prendas de compresión.

Consejo de estudio: Verifique siempre las autorizaciones médicas sobre las áreas de metástasis antes de prescribir fuerza.


### Lectura 3: Fisiología ambiental • Supervivencia y apoyo en Yuma

Descubra por qué los espacios interiores climatizados (22°C) protegen a los clientes inmunodeprimidos del calor desértico mientras fomentan redes de apoyo.

Consejo de estudio: Fomente entornos grupales que ofrezcan estímulo entre pares y temperaturas interiores seguras.

KIN-265 • Module 14 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 14:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
