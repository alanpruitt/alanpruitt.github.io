# KIN-265: Mod 05 Overview Breathing And Lung Conditions Copd And Asthma

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 05 Overview: Breathing & Lung Conditions (COPD & Asthma)


### Welcome to Module 05: Breathing & Lung Conditions (COPD & Asthma)

Welcome to Week 5! This week, we evaluate respiratory pathologies, focusing on Chronic Obstructive Pulmonary Disease (COPD) and Exercise-Induced Bronchospasm (EIB) using our academic Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) . Unlike healthy populations where heart rate reserve dictates cardiovascular intensity, pulmonary exercise prescription relies strictly on subjective ventilatory strain (Modified 0 to 10 Borg Dyspnea Scale) and pulse oximetry thresholds (SpO2).

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will audit dynamic hyperinflation, apply federal chronic condition safety mandates (terminating exercise if arterial oxygen saturation drops below 88%), and construct interval-based conditioning protocols featuring pursed-lip breathing cues tailored to clinical, community, and athletic populations across Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 15, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 17, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 20, 2026, at 11:59 PM MST
- Lab 05 Direct Submission / Entrega de Laboratorio: Monday, September 21, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 05 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze the pathophysiological mechanisms of air trapping, dynamic hyperinflation, dyspnea onset, and arterial oxygen desaturation (SpO2) during physical exertion. Analizar los mecanismos fisiopatológicos de atrapamiento de aire, hiperinsuflación dinámica y desaturación de oxígeno (SpO2).
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) chronic condition mandates, utilizing the Modified 0 to 10 Borg Dyspnea Scale (targeting 3 to 4) and safety stop-test thresholds (SpO2 less than 88%). Aplicar normas de PAGA 2018 regulando la intensidad mediante la escala de disnea de Borg (3 a 4) y límites de seguridad (SpO2 menor a 88%).
- CLO 3 (Problem Solving): Formulate an individualized, interval-based physical activity prescription incorporating pursed-lip breathing cues, environmental air quality monitoring, and bilingual patient education cards. Diseñar una prescripción de ejercicio por intervalos con respiración con labios fruncidos y tarjetas educativas bilingües.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit pulmonary exercise prescription across your chosen career track:

Outpatient pulmonary rehabilitation, continuous pulse oximetry monitoring, supplemental oxygen titrations, and GOLD Stage II COPD management at Matador Clinical Partners (MCP).

Auditing Air Quality Index (AQI) levels, managing particulate triggers, and organizing indoor climate-controlled walking groups for retired agricultural workers in Yuma County.

Managing Exercise-Induced Bronchospasm (EIB), structuring refractory period interval warm-ups, and optimizing inhaler timing for athletes in arid desert climates.


### Module 05 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Clinical Readings: Respiratory Kinetics & PAGA Standards
- Discussion Board 05: Dyspnea Rating Scales vs. Heart Rate Limits
- Lab Assignment 05: Pulmonary Prescription & Gemini AI Simulation
- Module 05 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 05 (Mod 05 Overview: Breathing & Lung Conditions (COPD & Asthma))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for zero-cost OER equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 05 Visión General: Patologías Pulmonares (EPOC/Asma)


### Bienvenido al Módulo 05: Cinética Respiratoria y Prescripción Guiada por Disnea

¡Bienvenido a la Semana 5! Esta semana estudiamos las patologías respiratorias, enfocándonos en la Enfermedad Pulmonar Obstructiva Crónica (EPOC) y el Broncoespasmo Inducido por el Ejercicio (BIE) . A diferencia de las personas sanas, la prescripción de ejercicio pulmonar se guía estrictamente por la escala de disnea percibida y los límites de saturación de oxígeno por pulsioximetría (SpO2).

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , auditará el atrapamiento de aire, aplicará las normas de PAGA 2018 (2.ª edición) para condiciones crónicas (detener el ejercicio si la SpO2 cae por debajo del 88%) y diseñará rutinas por intervalos adaptadas a su ruta profesional.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 15 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 17 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 20 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 05: Lunes, 21 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar los mecanismos fisiopatológicos del atrapamiento de aire, la hiperinsuflación dinámica y la desaturación de oxígeno (SpO2).
- CLO 2 (Regla): Aplicar las normas de PAGA 2018 regulando la intensidad con la escala de disnea de Borg (3 a 4) y límites de seguridad (SpO2 menor al 88%).
- CLO 3 (Solución): Diseñar prescripciones de ejercicio por intervalos con respiración con labios fruncidos y tarjetas educativas bilingües.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la prescripción pulmonar a través de su ruta profesional:

Rehabilitación pulmonar ambulatoria, monitoreo de pulsioximetría, titulación de oxígeno y manejo de EPOC en Matador Clinical Partners (MCP).

Auditoría del Índice de Calidad del Aire (AQI), control de alérgenos y grupos de caminata climatizados para trabajadores agrícolas retirados en Yuma.

Manejo del broncoespasmo inducido por el ejercicio (BIE), calentamiento con intervalos refractarios y uso de inhaladores en clima desértico.


### Ruta de Aprendizaje del Módulo 05

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Clínicas Obligatorias: Cinética Respiratoria y Pautas PAGA 2018
- Foro de Discusión 05: Escalas de Disnea vs. Límites de Frecuencia Cardíaca
- Laboratorio 05: Prescripción de Ejercicio Pulmonar y Consulta de IA
- Comprobación de Conocimientos y Resumen del Módulo 05

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 05 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 05 Required Readings: Breathing & Lung Conditions (COPD & Asthma) →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 05 Discussion: Using the Breathlessness Scale for COPD & Asthma →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 05 Coaching Sprint: Pacing & Breathing Tips for COPD & Asthma →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 05 Lab: COPD & Asthma Exercise Safety Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 05 Summary & Wrap-Up: Breathing & Lung Conditions (COPD & Asthma) →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
