# KIN-265: Mod 05 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 05 Discussion: Using the Breathlessness Scale for COPD & Asthma


### Ventilatory Efficiency, Dynamic Hyperinflation, & PAGA Federal Mandates

Prescribing physical activity for individuals managing Chronic Obstructive Pulmonary Disease (COPD) or asthma requires precise clinical auditing. Standard aerobic targets must be balanced against ventilatory efficiency, oxygen saturation thresholds (SpO2 > 88%), and dyspnea rating scales (Borg CR10).

In this discussion, you will audit how federal standards in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) guide pulmonary rehabilitation, SpO2 monitoring, and exercise progression across your chosen Build Your Own Journey Track .

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #265-05

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Outpatient pulmonary rehabilitation; auditing dynamic hyperinflation, SpO2 desaturation, and interval pacing in a patient with moderate COPD.

Focus: Community pulmonary health initiative; managing group walking programs for individuals with mild asthma and chronic bronchitis exposed to agricultural dust.

Focus: Endurance athlete conditioning; managing exercise-induced bronchospasm (EIB) and ventilatory thresholds during high-output training sessions.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Pattern Diagnosis (Ventilatory & Environmental Audit): State your selected Case File (#265-05A, #265-05B, or #265-05C) and diagnose the primary respiratory risk (dynamic hyperinflation / air trapping in COPD, oxyhemoglobin desaturation below $\text{SpO}_2\ 88\%$, or Exercise-Induced Bronchoconstriction triggered by Yuma agricultural dust and low desert humidity).
- Rule Application (PAGA 2018 & Pulmonary Safety Gates): Cite PAGA 2018 (2nd Ed.) guidelines alongside the Borg CR10 Dyspnea Scale ($3\text{–}4/10$ target ceiling) and the pulse oximetry safety gate (pause exercise if $\text{SpO}_2 < 88\%$).
- Solve (Pursed-Lip Breathing, Interval Pacing & Bilingual Cue): Prescribe a safe interval conditioning protocol incorporating pursed-lip breathing ($1:2$ or $1:3$ inhalation-to-exhalation ratio), a 15-minute gradual warm-up, and a 2-sentence bilingual breathing cue card (EN/ES).
- Peer Reply (Due Sunday 11:59 PM MST): Reply to at least one classmate who audited a different pulmonary track, comparing how COPD air trapping differs from acute asthma bronchospasm in Yuma's climate.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Official 10/10 Discussion Post Exemplar

Pattern (#265-05A — COPD Pulmonary Rehabilitation): During continuous treadmill walking, the client's shortened expiratory time causes dynamic hyperinflation (air trapping), driving his Borg CR10 dyspnea rating to $6/10$ and dropping $\text{SpO}_2$ to $87\%$.

Rule (PAGA 2018 & Pulmonary Gates): Under PAGA 2018 (2nd Ed.) and clinical pulmonary standards, aerobic conditioning must be regulated by the Borg CR10 Dyspnea Scale ($3\text{–}4/10$ moderate breathlessness) rather than heart rate alone, and exercise must pause immediately whenever pulse oximetry falls below $\text{SpO}_2\ 88\%$.

Solve & Bilingual Cue: Transition from continuous walking to interval walking (2 minutes at 1.8 mph / 1 minute seated or leaning recovery) paired with pursed-lip breathing (inhale 2 seconds through the nose, exhale 4 seconds through pursed lips) to maintain positive airway pressure and prevent small-airway collapse. EN: "Inhale slowly through your nose for two counts and breathe out gently through pursed lips for four counts to empty trapped air and keep your breathlessness at a comfortable 3 or 4 out of 10." ES: "Inhale despacio por la nariz contando hasta dos y sople suavemente con los labios fruncidos contando hasta cuatro para vaciar el aire atrapado y mantener su falta de aire en un nivel seguro de 3 o 4 sobre 10."


### Interactive Clinical Simulation & Outcome Gate (Module 05) / Simulación Clínica y Dominio de Resultados (Módulo 05)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 05 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 05 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 05 (Mod 05 Discussion: Using the Breathlessness Scale for COPD & Asthma)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Foro de Discusión del Módulo 05: Uso de la Escala de Disnea en EPOC y Asma

- Diagnóstico del Patrón (Jueves 11:59 PM MST): Identifique el riesgo respiratorio de su caso (#265-05A, #265-05B o #265-05C: hiperinflación dinámica en EPOC, desaturación $\text{SpO}_2 < 88\%$ o broncoespasmo inducido por ejercicio y polvo en Yuma).
- Aplicación de la Regla (PAGA 2018): Cite las pautas PAGA 2018, el rango seguro en la escala de disnea Borg CR10 ($3\text{–}4/10$) y el límite de seguridad de oximetría ($\text{SpO}_2 \ge 88\%$).
- Solución y Tarjeta Bilingüe: Proponga intervalos de caminata con respiración con labios fruncidos (relación $1:2$) y una instrucción bilingüe (EN/ES).
- Réplica a un Compañero (Domingo 11:59 PM MST): Responda a un compañero que haya elegido una ruta distinta.
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 05 Quick Return Navigation / Regreso Rápido al Módulo 05:
