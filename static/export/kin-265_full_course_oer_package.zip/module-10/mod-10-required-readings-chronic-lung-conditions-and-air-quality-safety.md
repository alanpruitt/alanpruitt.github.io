# KIN-265: Mod 10 Required Readings Chronic Lung Conditions And Air Quality Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Required Readings: Chronic Lung Conditions & Air Quality Safety

Lecturas Obligatorias: Patologías Pulmonares y Seguridad Clínica


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Pulmonary rehabilitation trains clients with chronic lung disease to breathe efficiently during physical exertion. Exercise specialists track oxygen levels so exertion never drops blood saturation below 88 percent. Mastering these safety rules prevents dangerous respiratory fatigue in our community.


#### En Palabras Sencillas (Norteño Context)

Piense en los pulmones como el filtro de aire de una troca en una polvareda de San Luis: cuando se llena de polvo, el motor batalla para respirar. Si los términos técnicos se ponen pesados, concéntrate primero en mantener la saturación de oxígeno arriba de 88%.


### Regional Focus: Air Quality & Respiratory Health in Yuma County

Enfoque Regional: Calidad del Aire y Salud Respiratoria en el Condado de Yuma

In Yuma County, agricultural dust, desert particulate matter, and extreme summer temperatures present significant environmental challenges for individuals managing COPD or asthma. Exercise specialists must understand pulmonary mechanics, oxygen saturation thresholds (SpO2 ≥ 88%), and breathing retraining to ensure safe, effective rehabilitation.

En el condado de Yuma, el polvo agrícola y el material particulado del desierto presentan desafíos ambientales significativos para la EPOC o el asma. Los especialistas deben dominar los umbrales de saturación de oxígeno (SpO2 ≥ 88%) y la reeducación respiratoria.


### Reading 1: Pulmonary Mechanics & Ventilatory Limitations in COPD

Lectura 1: Mecánica Pulmonar y Limitaciones Ventilatorias en la EPOC


#### Step 1: Airflow Obstruction and Dynamic Hyperinflation

Obstrucción del Flujo de Aire e Hiperinsuflación Dinámica

COPD encompasses chronic bronchitis and emphysema, characterized by progressive expiratory airflow limitation. During exercise, increased respiratory rates lead to incomplete exhalation, causing dynamic hyperinflation (air trapping), increased work of breathing, and premature exercise termination due to dyspnea.

La EPOC incluye bronquitis crónica y enfisema. Durante el ejercicio, el aumento de la frecuencia respiratoria provoca una exhalación incompleta, generando hiperinsuflación dinámica y disnea.


#### Step 2: Pursed-Lip Breathing and Interval Pacing Strategies

Respiración con Labios Fruncidos y Estrategias de Espaciamiento

Pursed-lip breathing creates back-pressure that prevents premature airway collapse during expiration, reducing trapping and improving tidal volume. Interval training (short bouts of work interspersed with recovery periods) allows COPD clients to accumulate significant exercise volume without overwhelming ventilatory capacity.

La respiración con labios fruncidos crea una contrapresión que previene el colapso bronquial durante la espiración. El entrenamiento a intervalos permite acumular volumen sin agotar la capacidad ventilatoria.


### Reading 2: PAGA 2018 Standards for Pulmonary Rehabilitation

Lectura 2: Normas de PAGA 2018 para la Rehabilitación Pulmonar


#### Step 1: Aerobic and Resistance Frequency, Intensity, Time, Type (FITT) principle Guidelines for Respiratory Patients

Directrices FITT Aeróbicas y de Fuerza para Pacientes Respiratorios

Aligning with Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) , pulmonary rehabilitation programs should prescribe aerobic activity 3 to 5 days per week, utilizing the Borg CR10 dyspnea scale (maintaining ratings between 3 and 5, representing "moderate" to "severe" breathing effort). Lower extremity resistance training is vital to combat skeletal muscle dysfunction associated with chronic hypoxia.

Alineándose con PAGA 2018, la rehabilitación pulmonar debe prescribir ejercicio 3 a 5 días por semana, utilizando la escala de disnea Borg CR10 (manteniendo calificaciones entre 3 y 5).


#### Step 2: Oxygen Saturation Monitoring and Exercise Termination Rules

Monitoreo de Saturación de Oxígeno y Reglas de Cese de Ejercicio

Exercise specialists must continuously monitor pulse oximetry (SpO2). Any drop in arterial oxygen saturation below 88% represents an absolute clinical stop limit requiring supplemental oxygen titration or immediate exercise cessation.

Los especialistas en ejercicio deben monitorear continuamente la pulsioximetría (SpO2). Cualquier caída por debajo del 88% representa un límite clínico absoluto que requiere detener el ejercicio.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clave

Select each question below to confirm your understanding of pulmonary pathology baselines before proceeding:

English Response: Increased respiratory rates lead to incomplete exhalation, trapping air in the lungs and increasing the work of breathing.

Respuesta en Español: El aumento de la frecuencia respiratoria provoca una exhalación incompleta, atrapando aire en los pulmones y aumentando el trabajo respiratorio.

English Response: It creates back-pressure that prevents premature airway collapse during expiration, reducing air trapping and improving gas exchange.

Respuesta en Español: Crea contrapresión que previene el colapso bronquial prematuro durante la espiración, reduciendo el aire atrapado y mejorando el intercambio.

English Response: An arterial oxygen saturation drop below 88% represents an absolute clinical stop limit.

Respuesta en Español: Una caída de la saturación arterial de oxígeno por debajo del 88% representa un límite clínico absoluto de parada.


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 10 (Mod 10 Required Readings: Chronic Lung Conditions & Air Quality Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 10 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 10:
