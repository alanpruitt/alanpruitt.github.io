# KIN-265: Mod 10 Overview Chronic Lung Conditions And Air Quality Safety

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 10 Overview: Chronic Lung Conditions & Air Quality Safety


### Welcome to Module 10: Chronic Lung Conditions & Air Quality Safety

Welcome to Week 10! Building upon our cardiovascular auditing framework, this week we examine Chronic Lung Conditions & Air Quality Safety . Chronic obstructive pulmonary disease (COPD), asthma, and restrictive respiratory disorders present unique physiological barriers to exercise, primarily through airflow limitation, dynamic hyperinflation, and exertional dyspnea.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify respiratory compromise patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) endurance thresholds, and design safe breathing and conditioning interventions.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 20, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 22, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, October 25, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, October 26, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 10 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze respiratory mechanics, gas exchange deficits, and ventilatory limitations associated with COPD and asthma. Analizar la mecánica respiratoria y las limitaciones ventilatorias asociadas con la EPOC y el asma.
- CLO 2 (Rule Application): Apply PAGA 2018 endurance standards, dyspnea rating scales (e.g., Borg CR10), and oxygen saturation monitoring rules. Aplicar normas de resistencia de PAGA 2018 y escalas de disnea (Borg CR10).
- CLO 3 (Problem Solving): Formulate an evidence-based pulmonary rehabilitation prescription integrating pursed-lip breathing and interval pacing. Formular una prescripción de rehabilitación pulmonar integrando respiración con labios fruncidos.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will work within your chosen career track:

Managing outpatient pulmonary rehabilitation for severe COPD patients requiring supplemental oxygen titration.

Designing indoor air-quality conscious exercise classes for older adults with chronic bronchitis in Yuma.

Screening industrial workers exposed to agricultural dust and particulate matter for exercise-induced bronchospasm.


### Module 10 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Core Reading & Lecture: Pulmonary Mechanics, Dyspnea Management & PAGA 2018 Prescriptions
- Discussion Board: Ventilatory Limitations, SpO2 Monitoring & Prescriptive Safety
- Lab Assignment: Pulmonary Exercise Prescription Audit & Gemini AI Tool Kit
- Knowledge Check & Module Summary

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 10 (Mod 10 Overview: Chronic Lung Conditions & Air Quality Safety)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 10 Visión General: Patologías Pulmonares y Ejercicio


### Bienvenido al Módulo 10: EPOC, Asma y Manejo de la Disnea

¡Bienvenido a la Semana 10! Basándonos en nuestro marco cardiovascular, esta semana examinamos las Patologías Pulmonares y la Prescripción de Ejercicio . La EPOC y el asma presentan barreras fisiológicas al ejercicio debido a la limitación del flujo de aire y la disnea.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificarás patrones de compromiso respiratorio, aplicarás las normas de PAGA 2018 y diseñarás intervenciones respiratorias seguras.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar la mecánica respiratoria y limitaciones ventilatorias asociadas con la EPOC y el asma.
- CLO 2 (Regla): Aplicar normas de resistencia de PAGA 2018 y escalas de disnea (Borg CR10).
- CLO 3 (Solución): Formular una prescripción de rehabilitación pulmonar integrando respiración con labios fruncidos.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, trabajará dentro de la ruta seleccionada:

Manejo de rehabilitación pulmonar ambulatoria para pacientes con EPOC severa requiriendo titulación de oxígeno.

Diseño de clases de ejercicio conscientes de la calidad del aire interior para adultos mayores con bronquitis crónica en Yuma.

Tamizaje de trabajadores industriales expuestos a polvo agrícola y material particulado para broncoespasmo.


### Ruta de Aprendizaje del Módulo 10

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Mecánica Pulmonar, Disnea y PAGA 2018
- Foro de Discusión: Limitaciones Ventilatorias, SpO2 y Seguridad
- Práctica de Laboratorio: Auditoría Pulmonar y Caja de Herramientas
- Comprobación de Conocimientos y Resumen del Módulo

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.


### Module 10 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 10 Required Readings: Chronic Lung Conditions & Air Quality Safety →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 10 Discussion: Breathing Limits & Air Quality Safety in Yuma →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 10 Coaching Sprint: Coaching Clients Through Shortness of Breath →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 10 Lab: Chronic Lung Condition Exercise Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 10 Summary & Wrap-Up: Chronic Lung Conditions & Air Quality Safety →
