# KIN-265: Mod 10 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 10 Coaching Sprint Simulation: Coaching Clients Through Shortness of Breath

Sesión de Coaching del Módulo 10: Patologías Pulmonares y Manejo de la Disnea

- Pursed-Lip & Diaphragmatic Breathing (Preventing Dynamic Hyperinflation): Slowing expiration through pursed lips (1:2 inhale-to-exhale ratio) keeps airways open longer, reduces trapped air in COPD, and relieves exercise dyspnea. En palabras sencillas: Respirar con los labios fruncidos soltando el aire el doble de lento que al inhalar para vaciar el aire atrapado y calmar la sensación de ahogo.
- Pulse Oximetry Safety Gate (Maintain SpO2 ≥88–90%): Continuous or interval monitoring of arterial oxygen saturation; if SpO2 drops below 88–90%, pause exercise, cue pursed-lip breathing, and follow supplemental O2 orders. En palabras sencillas: Vigilar con el oxímetro de dedo que la saturación de oxígeno (SpO2) se mantenga en 88–90% o más durante toda la sesión.
- Interval Aerobic Pacing & Dyspnea Borg 3–4/10 Target: Alternating short bouts of walking/cycling (e.g., 2–5 minutes) with active recovery rest intervals so shortness of breath stays at a manageable 3–4 on the 0–10 Borg Dyspnea Scale. En palabras sencillas: Dividir la caminata o bicicleta en bloques cortos de 2 a 5 minutos con pausas de recuperación para que la falta de aire nunca pase de nivel 3 a 4 sobre 10.
- KIN-265.10.1.AY26-27: Prescribe safe aerobic exercise intensity using the Borg CR10 dyspnea scale and SpO2 monitoring for clients with chronic respiratory disease across diverse career tracks. Prescribir intensidad de ejercicio aeróbico segura usando la escala Borg CR10 y monitoreo de SpO2 para clientes con enfermedades respiratorias crónicas en diversas rutas profesionales.
- KIN-265.10.2.AY26-27: Audit clinical oxygen saturation stop limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de parada por saturación de oxígeno y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering SpO2 Gating & Pursed-Lip Breathing Protocols

How can fitness professionals safely monitor exercise intensity when a client is managing chronic obstructive pulmonary disease (COPD) or asthma? Because standard heart rate metrics do not capture ventilatory distress, exercise specialists use the Borg CR10 scale to measure exertional dyspnea. Following strict PAGA 2018 clinical guidelines, trainers monitor pulse oximetry stop limits (SpO2 < 88%) and enforce pursed-lip breathing to prevent air trapping. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master clinical pulmonary safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente padece EPOC o asma? Usando la escala Borg CR10 y el monitoreo de SpO2 de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría pulmonar!


### The Clinical Framing Protocol (Pattern / Rule / Solve | Patrón / Regla / Solución)

Pattern / Patrón: Identify client pulmonary baseline, ventilatory distress symptoms, or resting SpO2 levels.

Rule / Regla: Apply PAGA 2018 pulmonary baselines and strict clinical oxygen saturation stop limits (SpO2 < 88%).

Solve / Solución: Prescribe personalized interval conditioning, pursed-lip breathing, and pacing strategies.

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient clinical rehabilitation client managing moderate-to-severe COPD with exertional oxygen desaturation (SpO2 87% on room air); establishing safe pacing and pursed-lip breathing.

Scenario: Senior community participant with chronic bronchitis and mild dyspnea on exertion; formulating an indoor air-conditioned walking program incorporating pursed-lip breathing.

Scenario: Agricultural equipment inspector with exercise-induced asthma (EIA); designing a pre-exercise bronchodilator protocol and interval conditioning routine for field inspections.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Arthur, Beatrice, or Mateo).
- Pulmonary Analysis: Explain the key ventilatory limitation or breathing mechanics consideration for your selected client.
- Part 3: Active Verification & Safety Audit: In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your SpO2 stop limits, Borg CR10 dyspnea gating, or pursed-lip breathing protocol protects your client under PAGA 2018 pulmonary standards.
- Part 4: My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 10 Coaching Sprint • Track 1 (Arthur)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Arthur (Age 70).
- Pulmonary Analysis: Arthur has moderate COPD, which causes air trapping and dynamic hyperinflation during exercise. Because standard heart rate metrics do not reflect ventilatory distress, we use the Borg CR10 scale to monitor his breathlessness and pulse oximetry to track oxygen saturation.
- Part 3: Active Verification & Safety Audit: "Monitor Arthur's SpO2 continuously during exercise, ensuring saturation remains at or above 88%, and halt activity immediately if SpO2 drops below this threshold per PAGA 2018 guidelines." Active Verification: In my clinical reasoning, Arthur's GOLD Stage II COPD creates severe dynamic hyperinflation, meaning his lungs cannot fully empty before the next breath during exercise. Relying on heart rate formulas would fail to detect ventilatory distress and exercise-induced hypoxemia. Gating his workout to a continuous SpO2 stop limit of 88% and a Borg CR10 dyspnea score between 3 and 5 ensures we stimulate aerobic endurance without inducing respiratory exhaustion. Enforcing a 1:2 pursed-lip breathing cadence creates positive expiratory backpressure, stenting open bronchioles and preventing air trapping. This protects Arthur from acute desaturation while upholding PAGA 2018 pulmonary rehabilitation safety mandates.
- "Monitor Arthur's SpO2 continuously during exercise, ensuring saturation remains at or above 88%, and halt activity immediately if SpO2 drops below this threshold per PAGA 2018 guidelines."
- Active Verification: In my clinical reasoning, Arthur's GOLD Stage II COPD creates severe dynamic hyperinflation, meaning his lungs cannot fully empty before the next breath during exercise. Relying on heart rate formulas would fail to detect ventilatory distress and exercise-induced hypoxemia. Gating his workout to a continuous SpO2 stop limit of 88% and a Borg CR10 dyspnea score between 3 and 5 ensures we stimulate aerobic endurance without inducing respiratory exhaustion. Enforcing a 1:2 pursed-lip breathing cadence creates positive expiratory backpressure, stenting open bronchioles and preventing air trapping. This protects Arthur from acute desaturation while upholding PAGA 2018 pulmonary rehabilitation safety mandates.
- Part 4: My Memorable Coaching Takeaway: EN: "Keeping a steady rhythm with pursed-lip breathing and watching your oxygen levels makes pulmonary exercise safe and manageable!" "¡Mantener un ritmo constante con respiración de labios fruncidos y vigilar sus niveles de oxígeno hace que el ejercicio pulmonar sea seguro y manejable!"
- EN: "Keeping a steady rhythm with pursed-lip breathing and watching your oxygen levels makes pulmonary exercise safe and manageable!"
- "¡Mantener un ritmo constante con respiración de labios fruncidos y vigilar sus niveles de oxígeno hace que el ejercicio pulmonar sea seguro y manejable!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M10_Quiz_Sprint.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 10) / Simulación Clínica y Dominio de Resultados (Módulo 10)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 10 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 10 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 10 (Mod 10 Coaching Sprint: Coaching Clients Through Shortness of Breath)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 10 Simulación de Coaching: Patologías Pulmonares y Manejo de la Disnea

Evaluación Rápida y Auditoría de Seguridad Pulmonar


### Su Logro Semanal: Dominando la SpO2 y la Respiración con Labios Fruncidos

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar la escala Borg CR10 y el monitoreo de SpO2 en pacientes con EPOC o asma. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente de rehabilitación clínica con EPOC moderada-severa y desaturación de oxígeno al esfuerzo (SpO2 87% en reposo ambiental); establecer un ritmo seguro y respiración de labios fruncidos.

Escenario: Participante senior con bronquitis crónica y disnea leve al esfuerzo; formular un programa de caminata interior con aire acondicionado incorporando respiración de labios fruncidos.

Escenario: Inspector de equipos agrícolas con asma inducida por ejercicio (EIA); diseñar un protocolo de broncodilatador pre-ejercicio y rutina de acondicionamiento por intervalos para inspecciones de campo.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Arthur, Beatrice o Mateo).
- Análisis Pulmonar: Explique la limitación ventilatoria clave para su cliente.
- Parte 3: Verificación Activa y Auditoría de Seguridad: En una defensa obligatoria (aprox. mínimo 150 palabras (150+ palabras)) con su propia voz clínica, justifique por qué los límites de SpO2, la escala Borg CR10 o la respiración con labios fruncidos protegen a su cliente según las normas de PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 10, Sesión de Coaching • Ruta 1 (Arthur)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Arthur (70 años).
- Análisis Pulmonar: Arthur tiene EPOC moderada que causa hiperinsuflación dinámica. Como la frecuencia cardíaca no refleja su dificultad respiratoria, usamos la escala Borg CR10 para medir la disnea y la oximetría para vigilar la saturación de oxígeno.
- Parte 3: Verificación Activa y Auditoría de Seguridad: "Monitorear la SpO2 de Arthur continuamente durante el ejercicio, asegurando que se mantenga en o por encima del 88%, y suspender la actividad si la saturación cae por debajo de este límite según PAGA 2018." Verificación Activa: En mi juicio clínico, la EPOC Estadio GOLD II de Arthur genera una hiperinsuflación dinámica severa, impidiendo el vaciado alveolar completo durante el ejercicio. Depender de la frecuencia cardíaca no detectaría la hipoxemia inducida por el esfuerzo. Monitorear con un límite estricto de SpO2 del 88% y una escala Borg CR10 entre 3 y 5 garantiza el estímulo aeróbico sin fatiga ventilatoria. Exigir la respiración con labios fruncidos en relación 1:2 genera contrapresión positiva que previene el colapso bronquiolar y el atrapamiento aéreo, cumpliendo plenamente con PAGA 2018.
- "Monitorear la SpO2 de Arthur continuamente durante el ejercicio, asegurando que se mantenga en o por encima del 88%, y suspender la actividad si la saturación cae por debajo de este límite según PAGA 2018."
- Verificación Activa: En mi juicio clínico, la EPOC Estadio GOLD II de Arthur genera una hiperinsuflación dinámica severa, impidiendo el vaciado alveolar completo durante el ejercicio. Depender de la frecuencia cardíaca no detectaría la hipoxemia inducida por el esfuerzo. Monitorear con un límite estricto de SpO2 del 88% y una escala Borg CR10 entre 3 y 5 garantiza el estímulo aeróbico sin fatiga ventilatoria. Exigir la respiración con labios fruncidos en relación 1:2 genera contrapresión positiva que previene el colapso bronquiolar y el atrapamiento aéreo, cumpliendo plenamente con PAGA 2018.
- Parte 4: Mi Frase Inolvidable de Coaching: EN: "Keeping a steady rhythm with pursed-lip breathing and watching your oxygen levels makes pulmonary exercise safe and manageable!" "¡Mantener un ritmo constante con respiración de labios fruncidos y vigilar sus niveles de oxígeno hace que el ejercicio pulmonar sea seguro y manejable!"
- EN: "Keeping a steady rhythm with pursed-lip breathing and watching your oxygen levels makes pulmonary exercise safe and manageable!"
- "¡Mantener un ritmo constante con respiración de labios fruncidos y vigilar sus niveles de oxígeno hace que el ejercicio pulmonar sea seguro y manejable!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M10_Quiz_Sprint.pdf
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 10 Quick Return Navigation / Regreso Rápido al Módulo 10:
