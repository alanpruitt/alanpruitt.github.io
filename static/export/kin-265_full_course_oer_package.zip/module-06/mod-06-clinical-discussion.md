# KIN-265: Mod 06 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Discussion: High Blood Pressure & Medication Safety in Exercise

Foro de Discusión del Módulo 06: Hipertensión Arterial y Seguridad Farmacológica en el Ejercicio


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Blood pressure medications change how the heart and blood vessels respond to exercise, especially in Yuma's heat. Beta-blockers keep heart rate artificially low (so we use the Borg RPE Talk Test instead of heart-rate formulas), vasodilators and diuretics can cause dizziness if a client stops moving suddenly, and holding your breath while lifting (the Valsalva maneuver) causes dangerous blood pressure spikes. Auditing these medication rules keeps every workout safe.

En Palabras Sencillas (Contexto Norteño): Los medicamentos para la presión cambian cómo responden el corazón y las venas durante el ejercicio, sobre todo con el calor de Yuma. Si los términos técnicos se ponen pesados, concéntrate primero en tres reglas de oro: usar la prueba del habla (RPE) cuando toman betabloqueadores, exhalar en cada esfuerzo para no aguantar la respiración (Valsalva) y enfriar despacio por 10 minutos para evitar mareos.


### Phase 1: Select Your Clinical Simulation Case File #265-06 / Fase 1: Selección de Escenario de Simulación Clínica


```text
STRUCTURAL_DELIMITER_BOUND_1 ###:
[CASE FILE]: #265-06A (Track 1: Clinical & Cardiac Rehab Path)
[CLIENT]: Sr. Roberto M., Age 62 (Yuma, AZ; Stage 2 Hypertension on Metoprolol 50 mg/day; Resting BP: 136/84 mmHg; Resting HR: 54 bpm)
[CLINICAL PRESENTATION]: Generic smartwatch AI tells him he must reach 135 bpm (80% age-predicted HRmax) to get cardiovascular benefit; he pushes to exhaustion trying to raise his pharmacologically blunted heart rate.
[DISCUSSION TASK]: Audit beta-blocker negative chronotropic/inotropic effects and pivot to Borg RPE 11-13 (6-20 scale) & the Talk Test under PAGA 2018.
STRUCTURAL_DELIMITER_BOUND_1 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_2 ###:
[CASE FILE]: #265-06B (Track 2: Community Wellness & Active Aging Path)
[CLIENT]: Sra. Elena G., Age 66 (Foothills / Yuma, AZ; Hypertension on Lisinopril + Hydrochlorothiazide; Resting BP: 132/80 mmHg)
[CLINICAL PRESENTATION]: Completes brisk walking class in a warm gym and stops abruptly to sit down; experiences lightheadedness and venous pooling (BP drops to 96/60 mmHg).
[DISCUSSION TASK]: Audit vasodilator/diuretic venous pooling + thermal cutaneous vasodilation and prescribe an extended 8-10 minute active cool-down and hydration protocol.
STRUCTURAL_DELIMITER_BOUND_2 ###:
```


```text
STRUCTURAL_DELIMITER_BOUND_3 ###:
[CASE FILE]: #265-06C (Track 3: Strength & Conditioning Path)
[CLIENT]: Marcos T., Age 47 (San Luis, AZ; Hypertension; arrives at gym after skipping morning Amlodipine with Resting BP: 184/112 mmHg)
[CLINICAL PRESENTATION]: Wants to perform heavy isometric planks and maximal 1-RM leg presses while holding his breath (Valsalva maneuver).
[DISCUSSION TASK]: Enforce the resting BP contraindication gate (>= 180/110 mmHg = hold exercise & refer) and redesign his future cleared resistance routine using rhythmic exhalation (exhale on concentric effort) and moderate loads (60-70% 1-RM, 12-15 reps).
STRUCTURAL_DELIMITER_BOUND_3 ###:
```


### Phase 2: Gemini AI Clinical Simulation Consultation / Consulta de IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Pattern Diagnosis (Hemodynamic & Medication Audit): State your selected Case File (#265-06A, #265-06B, or #265-06C) and explain the interaction between your client's blood pressure medication (or missed dose), vascular mechanics, and Yuma environmental heat.
- Rule Application (PAGA 2018 & Blood Pressure Gates): Cite PAGA 2018 (2nd Ed.) aerobic + muscle-strengthening guidelines alongside clinical blood pressure safety gates (hold exercise at rest if $\text{SBP} \ge 180\text{ mmHg}$ or $\text{DBP} \ge 110\text{ mmHg}$; terminate exertion if $\text{SBP} > 220\text{ mmHg}$ or $\text{DBP} > 105\text{ mmHg}$; regulate intensity at Borg RPE $11\text{–}13$ on the 6–20 scale).
- Solve (Medication-Safe Modification & Bilingual Cue): Provide a concrete exercise modification (RPE Talk Test pacing, 10-minute active cool-down, or concentric exhalation to prevent the Valsalva maneuver) plus a 2-sentence bilingual client instruction card (EN/ES).
- Peer Reply (Due Sunday 11:59 PM MST): Reply to at least one classmate who selected a different medication track, comparing how beta-blockers, ACE inhibitors/diuretics, and calcium-channel blockers alter exercise monitoring.

### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Official 10/10 Discussion Post Exemplar

Pattern (#265-06A — Beta-Blocker HR Blunting): Metoprolol competitively blocks $eta_1$-adrenergic receptors on the SA node and myocardium, blunting Sr. Roberto's resting and exercise heart rate. Relying on an unadjusted smartwatch target of $135\text{ bpm}$ ($80\%\ \text{HR}_{\max}$) forces him into severe metabolic overexertion.

Rule (PAGA 2018 & Hemodynamic Gates): Under PAGA 2018 (2nd Ed.) and clinical hypertension standards, once resting blood pressure is verified below $180/110\text{ mmHg}$ ($136/84\text{ mmHg}$ cleared), clients on beta-blockers must regulate moderate aerobic intensity using the Borg 6–20 RPE Scale ($11\text{–}13$, "light to somewhat hard") and the Talk Test , while stopping if exercise BP exceeds $220/105\text{ mmHg}$.

Solve & Bilingual Cue: Disable the smartwatch heart-rate alarm and guide Roberto through 30 minutes of indoor track walking at Borg RPE $12/20$ (able to speak in full sentences without gasping), followed by a 10-minute gradual cool-down and rhythmic exhalation during machine resistance exercises. EN: "Because your beta-blocker medication intentionally keeps your pulse low to protect your heart, ignore your watch's heart-rate alarm and pace your walk at a 12 out of 20 effort where you can speak in full sentences comfortably. Exhale smoothly on every lift and cool down for 10 minutes so your blood pressure stays steady." ES: "Debido a que su medicamento betabloqueador mantiene su pulso bajo para proteger su corazón, ignore la alarma de frecuencia cardíaca de su reloj y camine a un esfuerzo de 12 sobre 20 donde pueda hablar en oraciones completas con comodidad. Exhale suavemente en cada levantamiento y enfríe durante 10 minutos para mantener estable su presión arterial."


### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 06 (Mod 06 Discussion: High Blood Pressure & Medication Safety in Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Foro de Discusión del Módulo 06: Hipertensión Arterial y Seguridad Farmacológica en el Ejercicio

- Diagnóstico del Patrón (Jueves 11:59 PM MST): Identifique el riesgo hemodinámico y farmacológico de su caso (#265-06A betabloqueador, #265-06B vasodilatador/diurético e hipotensión post-ejercicio en el calor de Yuma, o #265-06C crisis hipertensiva $\ge 180/110\text{ mmHg}$ y maniobra de Valsalva).
- Aplicación de la Regla (PAGA 2018): Cite PAGA 2018, los límites de presión arterial ($<180/110\text{ mmHg}$ en reposo; $<220/105\text{ mmHg}$ en esfuerzo) y el uso de la escala Borg RPE $11\text{–}13$.
- Solución y Tarjeta Bilingüe: Proponga una adaptación segura (prueba del habla RPE, enfriamiento activo de 10 min o exhalación rítmica sin Valsalva) y una tarjeta bilingüe de 2 oraciones (EN/ES).
- Réplica a un Compañero (Domingo 11:59 PM MST): Responda a un compañero que haya auditado una clase de medicamento distinta.
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:
