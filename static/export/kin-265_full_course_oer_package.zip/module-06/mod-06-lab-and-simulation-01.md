# KIN-265: Mod 06 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 06 Coaching Sprint Simulation: Adjusting Intensity for Blood Pressure Meds

Sesión de Coaching del Módulo 06: Salud Cardiovascular y Metabólica

- Resting Blood Pressure Contraindication Gate (SBP ≥180 or DBP ≥110 mmHg): If resting systolic BP is ≥180 mmHg or diastolic BP is ≥110 mmHg, do not initiate exercise; refer the client for medical stabilization first. En palabras sencillas: Si antes de empezar la presión en reposo está en 180/110 mmHg o más, no se inicia el ejercicio y se canaliza al médico.
- Beta-Blocker Heart Rate Attenuation (Use Borg RPE 11–13 / Talk Test): Beta-adrenergic blockers (e.g., metoprolol, atenolol) blunt maximal and submaximal heart rate; age-predicted HR formulas are invalid, so use RPE 11–13 and the Talk Test. En palabras sencillas: Los betabloqueadores frenan las pulsaciones; por eso en estos pacientes no usamos fórmulas de pulso sino la Prueba del Habla y el esfuerzo percibido (RPE 11–13).
- Valsalva Avoidance & Antihypertensive Orthostatic Precaution: Exhale on every lifting effort to prevent dangerous blood-pressure spikes, and transition slowly from floor/seated positions to standing to prevent orthostatic dizziness. En palabras sencillas: Soltar siempre el aire al hacer fuerza y levantarse despacio de la silla o piso para evitar mareos por los medicamentos de la presión.
- KIN-265.6.1.AY26-27: Apply PAGA 2018 clinical guidelines for blood pressure regulation, glycemic window monitoring, and exercise prescription in chronic cardiovascular and metabolic conditions. Aplicar las pautas clínicas de PAGA 2018 para la regulación de la presión arterial, el monitoreo de ventanas glucémicas y la prescripción en afecciones cardiovasculares y metabólicas.
- KIN-265.6.2.AY26-27: Audit clinical safety parameters, beta-blocker/antihypertensive protocols, and Valsalva avoidance strategies for clients with hypertension and type 2 diabetes. Auditar los parámetros de seguridad clínica, los protocolos de betabloqueadores y de antihipertensivos, y las estrategias para evitar la maniobra de Valsalva.

### Your Weekly Win: Empowering Cardio-Metabolic Health Through Exercise

How can structured exercise reduce blood pressure, improve Insulin sensitivity, and lower cardiovascular risk for individuals managing hypertension (HTN) or type 2 diabetes (T2D)? Multi-component physical activity promotes vascular compliance, stimulates non-insulin-mediated glucose uptake (GLUT4 translocation), and enhances metabolic stability. Following strict PAGA 2018 clinical guidelines, exercise specialists can assess hemodynamic limits, monitor blood glucose within safety windows, and prevent exertion-related risks. Choose your coaching track below, chat with your AI Socratic Coach, and master clinical safety auditing!

¿Cómo puede el ejercicio estructurado reducir la presión arterial y mejorar la sensibilidad a la insulina en HTA o DM2? El ejercicio promueve la elasticidad vascular y el control glucémico. ¡Elija su ruta y dialogue con su coach de IA!

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track

Fase 1: Selección de Escenario de Simulación Clínica

Scenario: Outpatient cardiac/metabolic rehab patient (M.R., 62) with Stage 2 Hypertension and Type 2 Diabetes taking beta-blockers who presents with blunted heart rate and pre-exercise glucose of 94 mg/dL.

Scenario: Agricultural community member (Elena, 58) with metabolic syndrome and Type 2 Diabetes participating in an afternoon walking group who experiences post-exercise dizziness.

Scenario: Masters fitness client (Carlos, 45) with controlled hypertension wanting to perform heavy resistance training without triggering extreme blood pressure spikes.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen Track data wrapped in triple-hashes (###) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Chosen Track & Client: State your selected track and client's cardiovascular or metabolic condition.
- Clinical Safety & Programming Analysis: Explain PAGA 2018 cardio-metabolic guidelines, blood pressure thresholds, and glycemic safety parameters for your client.
- My Clinical Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment.
- Active Verification (Part 3 — Mandatory 150-Word Minimum in Your Own Human Voice): Write a 150-word minimum Active Verification (Part 3) in your own human clinical voice explaining why clients on blood pressure medications must use Borg RPE ($11\text{–}13$) and the Talk Test, exhale during every lift (no Valsalva), and complete an extended cool-down in Yuma's heat.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 06 Coaching Sprint • Track 1 (Clinical / M.R.)

- Chosen Track & Client: Track 1: Clinical & Hospital Outpatient Path (M.R., 62). Challenge: M.R. has Stage 2 HTN and Type 2 Diabetes, takes Metoprolol (beta-blocker), which blunts HR response (resting HR 56 bpm), and presents with pre-exercise glucose of 94 mg/dL.
- Track 1: Clinical & Hospital Outpatient Path (M.R., 62).
- Challenge: M.R. has Stage 2 HTN and Type 2 Diabetes, takes Metoprolol (beta-blocker), which blunts HR response (resting HR 56 bpm), and presents with pre-exercise glucose of 94 mg/dL.
- Clinical Safety & Programming Analysis: PAGA 2018 Guidelines for HTN & T2D: Beta-blocker therapy artificially suppresses heart rate, rendering age-predicted target heart rate formulas invalid. Exercise intensity must be monitored using Borg Rating of Perceived Exertion (RPE 11–14). Pre-exercise blood glucose under 100 mg/dL requires a 15–30g fast-acting carbohydrate snack before exertion to prevent exercise-induced hypoglycemia. Hemodynamic stop-test thresholds mandate terminating exercise if SBP > 220 mmHg or DBP > 105 mmHg. Breathing must be coached continuously during all resistance and aerobic movements to avoid Valsalva-induced blood pressure spikes.
- PAGA 2018 Guidelines for HTN & T2D: Beta-blocker therapy artificially suppresses heart rate, rendering age-predicted target heart rate formulas invalid. Exercise intensity must be monitored using Borg Rating of Perceived Exertion (RPE 11–14). Pre-exercise blood glucose under 100 mg/dL requires a 15–30g fast-acting carbohydrate snack before exertion to prevent exercise-induced hypoglycemia. Hemodynamic stop-test thresholds mandate terminating exercise if SBP > 220 mmHg or DBP > 105 mmHg.
- Breathing must be coached continuously during all resistance and aerobic movements to avoid Valsalva-induced blood pressure spikes.
- My Clinical Safety Audit for M.R.: "Administer 15g fast-acting carbohydrates for pre-exercise blood glucose of 94 mg/dL, verify re-test levels exceed 100 mg/dL, and regulate aerobic intensity strictly using Borg RPE (11–13) rather than heart rate per PAGA 2018."
- "Administer 15g fast-acting carbohydrates for pre-exercise blood glucose of 94 mg/dL, verify re-test levels exceed 100 mg/dL, and regulate aerobic intensity strictly using Borg RPE (11–13) rather than heart rate per PAGA 2018."
- Active Verification (Part 3 — 150-Word Minimum in Student's Own Human Voice): "In my clinical judgment, an unverified smartwatch or AI workout that uses age-predicted maximum heart rate ($220 - \text{age}$) is hazardous for clients taking beta-blockers because the medication intentionally blunts heart rate and can mask hypoglycemia symptoms. Under PAGA 2018 and clinical hemodynamic rules, I pivot intensity monitoring to Borg RPE 11–13 and the Talk Test, enforce pre-exercise blood pressure (<180/110 mmHg) and glucose (100–250 mg/dL) gates, cue continuous exhalation to prevent Valsalva pressure spikes, and extend the active cool-down to prevent venous pooling in Yuma's heat. Following our Pattern / Rule / Solve clinical reasoning protocol in Yuma and the Imperial Valley, I verified every calculation and safety boundary myself as the human Architect rather than blindly trusting an automated AI output, ensuring this client has a practical, culturally grounded, and heat-safe plan they can sustain week after week. By combining our federal Academic Source of Truth benchmarks with real-world coaching adjustments for desert temperatures and work schedules, we protect long-term health and adherence."
- My Memorable Coaching Takeaway: EN: "In cardio-metabolic training, regulating blood pressure and checking glycemic windows turn clinical risk into lifelong strength!" ¡En el entrenamiento cardiometabólico, regular la presión arterial y controlar las ventanas glucémicas convierten el riesgo clínico en una fuerza para toda la vida!"
- EN: "In cardio-metabolic training, regulating blood pressure and checking glycemic windows turn clinical risk into lifelong strength!"
- ¡En el entrenamiento cardiometabólico, regular la presión arterial y controlar las ventanas glucémicas convierten el riesgo clínico en una fuerza para toda la vida!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M06_Quiz_Sprint.pdf

### Interactive Clinical Simulation & Outcome Gate (Module 06) / Simulación Clínica y Dominio de Resultados (Módulo 06)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 06 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 06 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 06 (Mod 06 Coaching Sprint: Adjusting Intensity for Blood Pressure Meds)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 06 Simulación de Coaching: Salud Cardiovascular y Metabólica

Evaluación Rápida y Auditoría de Seguridad Cardíometabólica


### Su Logro Semanal: Fortaleciendo la Salud Cardio-Metabólica Mediante el Ejercicio

Esta sesión le permitirá aplicar las directrices clínicas de PAGA 2018 para regular la presión arterial, controlar las ventanas glucémicas y estructurar de forma segura la prescripción. ¡Elija su caso, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione UNO de los siguientes casos para copiar sus datos en el prompt de IA:

Escenario: Paciente de rehabilitación cardíaca/metabólica (M.R., 62 años) con hipertensión en estadio 2 y diabetes tipo 2, en tratamiento con betabloqueadores, con FC atenuada y glucemia inicial de 94 mg/dL.

Escenario: Integrante de la comunidad agrícola (Elena, 58 años) con síndrome metabólico y diabetes tipo 2, en un grupo de caminata vespertino, que presenta mareos posejercicio.

Escenario: Cliente máster de acondicionamiento (Carlos, 45 años) con hipertensión controlada que realiza entrenamiento de fuerza pesada sin control respiratorio.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos de la ruta elegida (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta y Cliente Seleccionado: Indique la ruta y la condición cardiovascular o metabólica de su cliente.
- Análisis de Seguridad Clínica y Programación: Explique las directrices de la PAGA 2018 sobre los umbrales de presión arterial y los parámetros de glucosa para su cliente.
- Mi Auditoría de Seguridad Clínica: Escriba 1 parámetro de seguridad claro y basado en evidencia, o un ajuste de la prescripción.
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en su Propia Voz): Escriba una defensa de mínimo 150 palabras en su propia voz humana clínica explicando por qué los clientes con medicamentos para la presión arterial deben guiarse por Borg RPE ($11\text{–}13$), evitar la maniobra de Valsalva y realizar un enfriamiento prolongado en Yuma.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 06, Sesión de Coaching • Ruta 1 (Clínica / M.R.)

- Ruta y Cliente Seleccionado: Ruta 1: Clínica y Hospitalaria (M.R., 62 años). Reto: M.R. tiene HTA estadio 2 y diabetes tipo 2; toma metoprolol (betabloqueador), que bloquea la respuesta de la FC (FC de reposo: 56 bpm), y presenta una glucemia inicial de 94 mg/dL.
- Ruta 1: Clínica y Hospitalaria (M.R., 62 años).
- Reto: M.R. tiene HTA estadio 2 y diabetes tipo 2; toma metoprolol (betabloqueador), que bloquea la respuesta de la FC (FC de reposo: 56 bpm), y presenta una glucemia inicial de 94 mg/dL.
- Análisis de Seguridad Clínica y Programación: Directrices PAGA 2018 para HTA y DM2: La terapia con betabloqueadores suprime artificialmente la frecuencia cardíaca, lo que invalida las fórmulas tradicionales. La intensidad debe monitorearse mediante la escala de esfuerzo percibido de Borg (RPE 11–14). Una glucemia menor de 100 mg/dL requiere un refrigerio de 15–30 g de carbohidratos de acción rápida antes de ejercitarse para prevenir la hipoglucemia. Los umbrales de parada exigen detener el ejercicio si PAS > 220 mmHg o PAD > 105 mmHg. Se debe entrenar la respiración continua en cada ejercicio para evitar picos de presión arterial causados por la maniobra de Valsalva.
- Directrices PAGA 2018 para HTA y DM2: La terapia con betabloqueadores suprime artificialmente la frecuencia cardíaca, lo que invalida las fórmulas tradicionales. La intensidad debe monitorearse mediante la escala de esfuerzo percibido de Borg (RPE 11–14). Una glucemia menor de 100 mg/dL requiere un refrigerio de 15–30 g de carbohidratos de acción rápida antes de ejercitarse para prevenir la hipoglucemia. Los umbrales de parada exigen detener el ejercicio si PAS > 220 mmHg o PAD > 105 mmHg.
- Se debe entrenar la respiración continua en cada ejercicio para evitar picos de presión arterial causados por la maniobra de Valsalva.
- Mi Auditoría de Seguridad Clínica para M.R.: "Administrar 15g de carbohidratos de acción rápida debido a una glucemia inicial de 94 mg/dL, verificar que la reevaluación supere los 100 mg/dL y regular la intensidad aeróbica estrictamente mediante la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca según PAGA 2018."
- "Administrar 15g de carbohidratos de acción rápida debido a una glucemia inicial de 94 mg/dL, verificar que la reevaluación supere los 100 mg/dL y regular la intensidad aeróbica estrictamente mediante la escala Borg RPE (11–13) en lugar de la frecuencia cardíaca según PAGA 2018."
- La Verificación Activa (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi juicio clínico, usar fórmulas estándar de frecuencia cardíaca en pacientes que toman betabloqueadores es peligroso porque el fármaco reduce el pulso y oculta síntomas de hipoglucemia. Bajo las reglas de PAGA 2018, regulamos la intensidad con la escala Borg RPE (11–13) y la prueba del habla, verificamos glucosa entre 100 y 250 mg/dL, indicamos exhalar en cada esfuerzo para evitar picos por Valsalva y aplicamos un enfriamiento activo prolongado en Yuma."
- Mi Frase Inolvidable de Coaching: EN: "In cardio-metabolic training, regulating blood pressure and checking glycemic windows turn clinical risk into lifelong strength!" ¡En el entrenamiento cardiometabólico, regular la presión arterial y controlar las ventanas glucémicas convierten el riesgo clínico en una fuerza para toda la vida!"
- EN: "In cardio-metabolic training, regulating blood pressure and checking glycemic windows turn clinical risk into lifelong strength!"
- ¡En el entrenamiento cardiometabólico, regular la presión arterial y controlar las ventanas glucémicas convierten el riesgo clínico en una fuerza para toda la vida!"
- Verificación del Repositorio: Registro de auditoría de IA guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M06_Quiz_Sprint.pdf
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 06 Quick Return Navigation / Regreso Rápido al Módulo 06:
