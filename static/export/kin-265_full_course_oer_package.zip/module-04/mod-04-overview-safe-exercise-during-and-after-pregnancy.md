# KIN-265: Mod 04 Overview Safe Exercise During And After Pregnancy

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 04 Overview: Safe Exercise During & After Pregnancy


### Welcome to Module 04: Safe Exercise During & After Pregnancy

Welcome to Week 4! This week, we evaluate anatomical and hemodynamic adaptations during pregnancy and postpartum recovery using our academic Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) supported by clinical consensus from the American College of Obstetricians and Gynecologists (ACOG). We investigate gestational biomechanics, relaxin-mediated pelvic ligamentous laxity, center-of-gravity shifts, and the vascular mechanics of supine hypotensive syndrome (inferior vena cava compression after 16 weeks gestation).

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify biomechanical vulnerability patterns, apply federal activity guidelines (at least 150 minutes of moderate-intensity aerobic activity weekly), enforce position-based contraindications, and construct climate-adapted exercise programs in Yuma County that prioritize fetal safety and maternal vitality.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, September 8, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, September 10, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, September 13, 2026, at 11:59 PM MST
- Lab 04 Direct Submission / Entrega de Laboratorio: Monday, September 14, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje del Curso

Upon successful completion of Module 04 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Explain the vascular mechanics of supine hypotensive syndrome after 16 weeks gestation and identify structural joint instability caused by systemic relaxin release. Explicar la mecánica vascular del síndrome hipotensivo supino después de las 16 semanas e identificar la inestabilidad articular mediada por relaxina.
- CLO 2 (Rule Application): Apply PAGA 2018 gestational aerobic standards (150 minutes of moderate activity weekly, RPE 12-14) and identify clinical warning signs mandating immediate exercise cessation. Aplicar las pautas aeróbicas gestacionales de PAGA 2018 (150 minutos semanales moderados, RPE 12-14) e identificar signos clínicos de alarma.
- CLO 3 (Problem Solving): Formulate an adapted, indoor climate-controlled exercise and hydration prescription that eliminates supine positioning and high-impact contact risks in Yuma's high summer heat. Diseñar una prescripción adaptada en interiores climatizados que elimine la posición supina y el riesgo de impacto bajo el calor de Yuma.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will audit gestational exercise programming across your chosen career track:

Managing second-trimester gestational diabetes and pelvic girdle pain (M.T., 31) in outpatient clinical facilities at Matador Clinical Partners (MCP).

Designing inclusive, climate-controlled low-impact community walking and water aerobics for pregnant mothers in Yuma County.

Modifying strength periodization, eliminating Valsalva maneuvers, and mitigating thermal strain for an active prenatal CrossFit athlete.


### Module 04 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Clinical Readings: Gestational Biomechanics & PAGA 2018 Standards
- Discussion Board 04: Gestational Biomechanics & Safe Programming
- Lab Assignment 04: Pregnancy & Biomechanical Safety Audit (Gemini AI Tool Box)
- Module 04 Knowledge Check & Summary

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 04 (Mod 04 Overview: Safe Exercise During & After Pregnancy)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 04 Visión General: Embarazo, Biomecánica Gestacional y Seguridad


### Bienvenido al Módulo 04: Mecánica Gestacional, Compresión de Vena Cava y Seguridad Materna

¡Bienvenido a la Semana 4! Esta semana evaluaremos las adaptaciones anatómicas y hemodinámicas durante el embarazo y el posparto utilizando nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) y las recomendaciones clínicas del Colegio Americano de Obstetras y Ginecólogos (ACOG). Analizaremos la laxitud articular por relaxina, el cambio del centro de gravedad y el síndrome hipotensivo en decúbito supino.

Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificará patrones de vulnerabilidad biomecánica, aplicará la meta federal de al menos 150 minutos semanales de actividad moderada, evitará posiciones contraindicadas y diseñará prescripciones seguras adaptadas al calor de Yuma.


### Horario Semanal y Fechas Límite

- Apertura del Módulo: Martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Publicación Inicial en Foro: Jueves, 10 de septiembre de 2026, a las 11:59 PM MST
- Respuestas a Compañeros: Domingo, 13 de septiembre de 2026, a las 11:59 PM MST
- Entrega de Laboratorio 04: Lunes, 14 de septiembre de 2026, a las 11:59 PM MST

### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Explicar la mecánica vascular del síndrome hipotensivo supino después de las 16 semanas e identificar la inestabilidad articular mediada por relaxina.
- CLO 2 (Regla): Aplicar las pautas de PAGA 2018 para el embarazo (150 min/semana moderados, RPE 12-14) e identificar signos de alarma para detener el ejercicio.
- CLO 3 (Solución): Diseñar una prescripción en interiores climatizados que elimine el decúbito supino y el riesgo de impacto bajo el calor de Yuma.

### Construya su Propio Camino • Vista previa de las 3 rutas

En la discusión y el laboratorio de este módulo, auditará la prescripción gestacional a través de su ruta profesional:

Manejo de diabetes gestacional y dolor pélvico (M.T., 31 años) en instalaciones ambulatorias de Matador Clinical Partners (MCP).

Diseño de programas inclusivos de caminata y aeróbicos acuáticos climatizados para mujeres embarazadas en Yuma.

Modificación de fuerza, eliminación de la maniobra de Valsalva y control térmico en atletas activas durante el embarazo.


### Ruta de Aprendizaje del Módulo 04

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lecturas Clínicas Obligatorias: Biomecánica Gestacional y Pautas PAGA 2018
- Foro de Discusión 04: Biomecánica Gestacional y Programación Segura
- Laboratorio 04: Auditoría de Seguridad Biomecánica en el Embarazo y Gemini IA
- Comprobación de Conocimientos y Resumen del Módulo 04

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.


### Module 04 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 04 Required Readings: Safe Exercise During & After Pregnancy →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 04 Discussion: Safe Exercise Guidelines During Pregnancy →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 04 Coaching Sprint: Posture, Balance & Warning Signs in Pregnancy →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 04 Lab: Prenatal & Postpartum Exercise Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 04 Summary & Wrap-Up: Safe Exercise During & After Pregnancy →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
