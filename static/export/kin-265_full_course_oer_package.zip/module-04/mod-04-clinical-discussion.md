# KIN-265: Mod 04 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 04 Discussion: Safe Exercise Guidelines During Pregnancy


### Postural Shifts, Pelvic Floor Stability, & PAGA Federal Mandates

Prescribing physical activity during pregnancy requires precise clinical auditing of maternal hemodynamic responses, shifting center of gravity, lumbar lordosis, and pelvic floor stability. Standard exercise prescriptions must be balanced against absolute termination criteria and thermoregulatory limits.

In this discussion, you will audit how federal standards in the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) guide prenatal physical activity, biomechanical adjustments, and safety protocols across your chosen Build Your Own Journey Track .

- Topic Opens / Apertura del Foro: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Closes / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST

### Phase 1: Select Your Clinical Simulation Case File #265-04

Choose ONE of the three career-aligned tracks below to copy into your AI prompt query:

Focus: Prenatal clinical rehabilitation; auditing pelvic girdle pain, diastasis recti risks, and autonomic hemodynamic changes during second-trimester exercise.

Focus: Community prenatal wellness program; designing safe aerobic conditioning and thermoregulatory pacing guidelines for pregnant women in warm climates.

Focus: Prenatal athletic conditioning; modifying high-impact resistance training, managing intra-abdominal pressure, and adjusting training volume during gestation.


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST):

- Identify Selected Track & Biomechanical Vulnerability / Ruta y Vulnerabilidad: State your chosen track and explain the specific postural or biomechanical vulnerability in your client scenario. Indique la ruta seleccionada y explique la vulnerabilidad biomecánica específica de su cliente.
- Clinical Framing Protocol (Pattern / Rule / Solve) Audit (Pattern / Rule / Solve) / Análisis del Protocolo de Encuadre Clínico (Patrón / Regla / Solución): Detail the underlying physiological mechanism (Pattern), apply PAGA 2018 prenatal activity mandates and safety rules (Rule), and outline your exercise modification protocol (Solve). Detalle el mecanismo fisiológico (Patrón), aplique las normas PAGA 2018 para embarazadas (Regla) y describa su protocolo (Solución).
- Bilingual Client Instruction Card / Tarjeta de Instrucción Bilingüe: Provide a concise 2-sentence instruction card in English and Spanish guiding the client on safe posture, core management, or thermoregulation. Proporcione una tarjeta concisa de 2 oraciones en inglés y en español para guiar al cliente sobre la postura segura.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least TWO (2) classmates who selected a different track than yours (Minimum 2 Replies Required). Compare how prenatal biomechanical adjustments and safety guidelines differ across clinical rehabilitation, community wellness, and athletic performance environments.


### Evaluation Rubric (10 Points Total • 10/7/0 Grading Scale)


### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 04 (Mod 04 Discussion: Safe Exercise Guidelines During Pregnancy)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials adhere strictly to UDL principles and WCAG 2.1 AA standards, featuring semantic hierarchy starting at heading level 2 and screen-reader verification.

Español: Todos los materiales cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Foro de Discusión 04: Embarazo y Biomecánica


### Cambios Posturales y Normas PAGA

Analice el caso asignado utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) según la ruta profesional seleccionada.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:
