# KIN-265: Mod 04 Summary And Wrap Up Safe Exercise During And After Pregnancy

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 04 Summary & Wrap-Up: Safe Exercise During & After Pregnancy

Embarazo, Biomecánica, Relajina, Supino en II/III Trimestre y Pautas PAGA 2018


### Step 1: Core Pregnancy & Biomechanical Adaptations Synthesis

Congratulations on completing Module 04! You have mastered the physiological and biomechanical adaptations of exercise during pregnancy, including hormonal joint laxity, center of gravity shifts, supine positional precautions, and safe physical activity programming under PAGA 2018 standards:

- Hormonal Laxity & Relaxin Mechanics: Elevated circulating relaxin hormone softens pelvic ligaments and connective tissue, increasing joint laxity and elevating musculoskeletal injury risks during high-impact or ballistic movements.
- Center of Gravity & Postural Shifts: Anterior uterine expansion shifts the body's center of gravity forward, exaggerating lumbar lordosis, altering spinal biomechanics, and demanding targeted core stabilization.
- Supine Hypotensive Syndrome Prevention: Avoiding prolonged supine positioning during the second and third trimesters prevents the gravid uterus from compressing the inferior vena cava, which maintains venous return and maternal cardiac output.
- PAGA 2018 Maternal Mandate: Formulated structured cardiorespiratory routines (150 minutes of moderate-intensity aerobic activity weekly) for uncomplicated pregnancies, incorporating the "Talk Test" for intensity regulation.

### Step 2: Workplace Intelligence & AI Clinical Auditing

In prenatal wellness clinics, hospital outpatient fitness centers, and community health programs, exercise specialists leverage generative AI preceptors to audit client gestational logs, screen for absolute contraindications, and structure modified biomechanical routines.

- AI-Assisted Gestational Screening: Specialists prompt AI assistants to audit prenatal exercise prescriptions against strict PAGA 2018 stop-test guidelines (e.g., vaginal bleeding, amniotic fluid leakage, dyspnea before exertion).
- Delimiter Security Protocol (###): Client biometric metrics (gestational age, pre-pregnancy activity level, joint laxity symptoms, resting vitals) must remain enclosed inside triple hashes ( ### ) for data isolation during AI queries.
- Human-in-the-Loop Safeguard: All AI-generated prenatal routines must be verified by a clinician against federal standards to ensure absolute protection against hyperthermia and pelvic instability.

### Step 3: Module 04 Self-Check Knowledge Verification (Bilingual Companion)

Select each item below to verify your understanding before progressing to Module 05:

English Response: Relaxin increases the laxity of ligaments and connective tissues throughout the body, preparing the pelvis for childbirth but simultaneously raising the risk of joint sprains and musculoskeletal injury during physical activity.

Respuesta en Español: La relaxina aumenta la laxitud de los ligamentos y tejidos conectivos, preparando la pelvis para el parto pero elevando el riesgo de esguinces articulares y lesiones musculoesqueléticas durante la actividad física.

English Response: Lying flat on the back compresses the inferior vena cava by the weight of the gravid uterus, reducing venous return to the heart, dropping cardiac output, and causing maternal supine hypotension.

Respuesta en Español: Acostarse boca arriba comprime la vena cava inferior debido al peso del útero grávido, reduciendo el retorno venoso al corazón, disminuyendo el gasto cardíaco y causando hipotensión supina materna.

English Response: Anterior uterine growth shifts the body's center of gravity forward, increasing lumbar lordosis, altering spinal alignment, and placing increased mechanical stress on the lower back and pelvis.

Respuesta en Español: El crecimiento uterino anterior desplaza el centro de gravedad del cuerpo hacia adelante, aumentando la lordosis lumbar, alterando la alineación espinal y ejerciendo mayor estrés mecánico en la zona lumbar y la pelvis.

English Response: PAGA 2018 recommends accumulating at least 150 minutes of moderate-intensity aerobic activity weekly during pregnancy and the postpartum period.

Respuesta en Español: PAGA 2018 recomienda acumular al menos 150 minutos semanales de actividad aeróbica de intensidad moderada durante el embarazo y el período postnatal.

English Response: The Talk Test is a simple self-monitoring method where moderate-intensity exercise allows the individual to converse comfortably without gasping for breath during exertion.

Respuesta en Español: La prueba de la charla es un método simple de autocontrol donde el ejercicio de intensidad moderada permite conversar cómodamente sin quedarse sin aliento durante el esfuerzo.

English Response: Vaginal bleeding, regular painful uterine contractions, amniotic fluid leakage, dyspnea before exertion, dizziness, headache, chest pain, or calf pain and swelling.

Respuesta en Español: Sangrado vaginal, contracciones uterinas dolorosas regulares, pérdida de líquido amniótico, disnea antes del esfuerzo, mareos, dolor de cabeza, dolor en el pecho o dolor e hinchazón en las pantorrillas.

English Response: Enclosing gestational client metrics within triple-hash delimiters (`###`) ensures secure data isolation, prevents prompt drift, and maintains clinical alignment with PAGA 2018 maternal standards.

Respuesta en Español: Envolver las métricas gestacionales entre delimitadores de tres numerales (`###`) asegura el aislamiento seguro de datos, evita la deriva de las instrucciones y mantiene la alineación clínica con los estándares maternos de PAGA 2018.

English Response: Maternal hyperthermia (core body temperature elevation above 39°C / 102.2°F) during early gestation can impair embryonic development. Indoor climate-controlled exercise (72°F / 22°C) prevents desert heat stress.

Respuesta en Español: La hipertermia materna (elevación de la temperatura corporal central por encima de 39 °C) durante la gestación temprana puede alterar el desarrollo embrionario. El ejercicio en interiores climatizados (22 °C) previene el estrés por calor del desierto.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth for all special populations programming.

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal para la programación de ejercicio en poblaciones especiales.


### AI Simulation Workspace • Maternal Biomechanics Simulation & Synthesis

Copy the prompt below into Gemini to generate a comprehensive clinical review matrix connecting gestational biomechanics, relaxin joint laxity, and PAGA 2018 standards:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Review Master Protocol: KIN-265 Module 04 Pregnancy Synthesis ###:
Role: Clinical Exercise Physiologist and Prenatal Movement Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Chapter 5 Pregnancy & Postpartum.

Instructions:
Step 1: Generate a side-by-side comparative summary table linking:
   Key Point: Gestational Biomechanical Mechanisms (Relaxin joint laxity, Center of gravity anterior shift, Supine vena cava compression).
   Key Point: Clinical Monitoring & Warning Signs (Talk Test intensity limits, SpO2/vitals, Absolute contraindications like bleeding/fluid leakage).
   Key Point: Evidence-Based Exercise Modifications (Low-impact non-weight-bearing modalities, Left-side lying or wedge support in supine, Indoor climate-controlled 72°F / 22°C pacing).
Step 2: Detail pre-exercise screening protocols for uncomplicated pregnancies and explain how Safety Auditor prompt delimiters protect maternal clinical data in Yuma County.
Step 3: Keep all formulas in plain text and wrap all data inputs within triple-hash (###) delimiters.
End Review Master Protocol ###:
```

SEQUENTIAL MODULE BRIDGE • IN PLAIN ENGLISH


### Looking Ahead: Module 05 — Pulmonary Pathologies (COPD & Asthma)

In plain English, next week in Module 05: Pulmonary Pathologies (COPD/Asthma) you will learn how to help clients with chronic lung conditions exercise without gasping for air by using pulse oximetry ($\text{SpO}_2$), the Borg Dyspnea (breathlessness) scale, and pursed-lip breathing intervals. Why it matters: agricultural dust, seasonal pollen, and desert heat in Yuma trigger airway spasms—knowing how to pace intervals and keep oxygen saturation at or above 88% keeps pulmonary clients active.

- Pattern (Context): Differentiating COPD (expiratory air trapping) from Exercise-Induced Bronchospasm (asthma) and auditing environmental air-quality triggers.
- Rule (Constraint): Enforcing the clinical oxygen floor ( stop exercise if $\text{SpO}_2 < 88\%$ ), Borg Dyspnea target (3–4 out of 10), and mandatory rescue-inhaler verification.
- Solve (Intervention): Completing Mod 05 Discussion: Air Quality & Pulmonary Safety and Mod 05 Lab: Pulmonary Exercise Prescription .

### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 04 (Mod 04 Summary & Wrap-Up: Safe Exercise During & After Pregnancy)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 04: Resumen y Evaluación

Embarazo, Biomecánica, Relajina, Supino en II/III Trimestre y Pautas PAGA 2018


### Step 1: Síntesis de Adaptaciones del Embarazo y Biomecánica

¡Felicitaciones por completar el Módulo 04! Ha dominado las adaptaciones fisiológicas y biomecánicas del ejercicio durante el embarazo, incluyendo la laxitud articular por relaxina, los cambios en el centro de gravedad, las precauciones en posición supina y la programación segura de la actividad física bajo las normas de PAGA 2018:

- Laxitud Hormonal y Mecánica de la Relaxina: La hormona relaxina ablanda los ligamentos y el tejido conectivo, incrementando la laxitud articular y elevando el riesgo de lesiones musculoesqueléticas durante movimientos de alto impacto.
- Centro de Gravedad y Cambios Posturales: La expansión uterina anterior desplaza el centro de gravedad hacia adelante, exagerando la lordosis lumbar y exigiendo estabilización del núcleo.
- Prevención del Síndrome Hipotensivo Supino: Evitar posiciones decúbito supino prolongadas en el segundo y tercer trimestre previene que el útero grávido comprima la vena cava inferior, manteniendo el gasto cardíaco materno.
- Mandato Materno de PAGA 2018: Formulación de rutinas cardiorespiratorias (150 minutos semanales de actividad aeróbica moderada) para embarazos sin complicaciones, incorporando la "Prueba de la Charla".

### Step 2: Inteligencia en el Entorno Laboral y Auditoría con IA

En clínicas de bienestar prenatal, centros de fitness ambulatorios y programas de salud comunitaria, los especialistas utilizan IA generativa para auditar registros gestacionales, evaluar contraindicaciones y estructurar rutinas biomecánicas modificadas.

- Detección Gestacional Asistida por IA: Contraste de prescripciones prenatales frente a las directrices federales PAGA 2018 para detener el ejercicio ante signos de alerta.
- Protocolo con Delimitadores (###): Las métricas gestacionales y signos vitales deben aislarse entre tres numerales ( ### ) para consultas de IA.
- Verificación Clínica Humana: Todas las rutinas prenatales generadas por IA deben ser verificadas por un clínico para proteger contra la hipertermia e inestabilidad pélvica.

### Step 3: Autoevaluación del Módulo 04 (Acompañamiento Bilingüe)

Presione cada elemento para verificar su comprensión antes de avanzar al Módulo 05:

Respuesta en Español: La relaxina aumenta la laxitud de los ligamentos y tejidos conectivos, preparando la pelvis para el parto pero elevando el riesgo de esguinces articulares y lesiones musculoesqueléticas durante la actividad física.

English Response: Relaxin increases the laxity of ligaments and connective tissues, preparing the pelvis for childbirth but simultaneously raising the risk of joint sprains and musculoskeletal injury during physical activity.

Respuesta en Español: Acostarse boca arriba comprime la vena cava inferior debido al peso del útero grávido, reduciendo el retorno venoso al corazón, disminuyendo el gasto cardíaco y causando hipotensión supina materna.

English Response: Lying flat on the back compresses the inferior vena cava by the weight of the gravid uterus, reducing venous return to the heart, dropping cardiac output, and causing maternal supine hypotension.

Respuesta en Español: El crecimiento uterino anterior desplaza el centro de gravedad del cuerpo hacia adelante, aumentando la lordosis lumbar, alterando la alineación espinal y ejerciendo mayor estrés mecánico en la zona lumbar y la pelvis.

English Response: Anterior uterine growth shifts the body's center of gravity forward, increasing lumbar lordosis, altering spinal alignment, and placing increased mechanical stress on the lower back and pelvis.

Respuesta en Español: PAGA 2018 recomienda acumular al menos 150 minutos semanales de actividad aeróbica de intensidad moderada durante el embarazo y el período postnatal.

English Response: PAGA 2018 recommends accumulating at least 150 minutes of moderate-intensity aerobic activity weekly during pregnancy and the postpartum period.

Respuesta en Español: La prueba de la charla es un método simple de autocontrol donde el ejercicio de intensidad moderada permite conversar cómodamente sin quedarse sin aliento durante el esfuerzo.

English Response: The Talk Test is a simple self-monitoring method where moderate-intensity exercise allows the individual to converse comfortably without gasping for breath during exertion.

Respuesta en Español: Sangrado vaginal, contracciones uterinas dolorosas regulares, pérdida de líquido amniótico, disnea antes del esfuerzo, mareos, dolor de cabeza, dolor en el pecho o dolor e hinchazón en las pantorrillas.

English Response: Vaginal bleeding, regular painful uterine contractions, amniotic fluid leakage, dyspnea before exertion, dizziness, headache, chest pain, or calf pain and swelling.

Respuesta en Español: Envolver las métricas gestacionales entre delimitadores de tres numerales (`###`) asegura el aislamiento seguro de datos, evita la deriva de las instrucciones y mantiene la alineación clínica con los estándares maternos de PAGA 2018.

English Response: Enclosing gestational client metrics within triple-hash delimiters (`###`) ensures secure data isolation, prevents prompt drift, and maintains clinical alignment with PAGA 2018 maternal standards.

Respuesta en Español: La hipertermia materna (elevación de la temperatura corporal central por encima de 39 °C) durante la gestación temprana puede alterar el desarrollo embrionario. El ejercicio en interiores climatizados (22 °C) previene el estrés por calor del desierto.

English Response: Maternal hyperthermia (core body temperature elevation above 39°C / 102.2°F) during early gestation can impair embryonic development. Indoor climate-controlled exercise (72°F / 22°C) prevents desert heat stress.

Respuesta en Español: Las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª edición) sirven como la Fuente Única de Verdad federal principal para la programación de ejercicio en poblaciones especiales.

English Response: The Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) serves as the primary federal Single Source of Truth for all special populations programming.


### Caja de Herramientas de IA • Síntesis Biomecánica Materna

(Haga clic dentro del cuadro para seleccionar todo el texto y presione Ctrl + C / Cmd + C para copiar)


```text
Review Master Protocol: KIN-265 Module 04 Pregnancy Synthesis ###:
Rol: Fisiologo del Ejercicio Clinico y Especialista en Movilidad Prenatal en la voz del Narrador.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) - Capitulo 5 Embarazo y Postparto.

Instrucciones:
Step 1: Generar una tabla comparativa vinculando:
   Key Point: Mecanismos Biomecanicos Gestacionales (Laxitud articular por relaxina, Desplazamiento anterior del centro de gravedad, Compresion de vena cava en supino).
   Key Point: Monitoreo Clinico y Signos de Alerta (Limites de intensidad Talk Test, SpO2/signos vitales, Contraindicaciones absolutas como sangrado/perdida de liquido).
   Key Point: Modificaciones de Prescripcion Basadas en Evidencia (Modalidades sin impacto, Soporte de cuña o decúbito lateral en supino, Climatización interior a 22°C).
Step 2: Detallar protocolos de tamizaje previo al ejercicio para embarazos sin complicaciones y explicar como los delimitadores protegen los datos clínicos en Yuma.
Step 3: Mantener todas las formulas en texto plano y los datos entre delimitadores (###).
Fin del Protocolo Review Master ###:
```

PUENTE SECUENCIAL DEL MÓDULO • EN PALABRAS SENCILLAS


### Mirando Hacia Adelante: Módulo 05 — Patologías Pulmonares (EPOC y Asma)

En palabras sencillas (Contexto Norteño): cuando un cliente tiene EPOC o asma, el polvo agrícola y el aire caliente de Yuma pueden cerrarle los bronquios o dejarle aire atrapado en los pulmones. Si los términos respiratorios se ponen pesados la próxima semana, concéntrate primero en tres reglas de seguridad: verificar que traiga su inhalador de rescate, enseñar la respiración con labios fruncidos y detener el ejercicio si el oxímetro baja de $\text{SpO}_2 < 88\%$ .

- Patrón (Contexto): Diferenciar el EPOC del asma inducida por ejercicio y evaluar la calidad del aire en el Valle de Yuma.
- Regla (Restricción): Mantener la saturación de oxígeno en $\text{SpO}_2 \ge 88\%$ , usar la escala de disnea de Borg (3–4/10) y emplear intervalos cortos.
- Solución (Intervención): Completar el Foro del Mód 05 (Air Quality & Pulmonary Safety) y el Laboratorio del Mód 05 (Pulmonary Exercise Prescription) .

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 04 Wrap-Up & Quick Navigation / Navegación de Cierre del Módulo 04:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
