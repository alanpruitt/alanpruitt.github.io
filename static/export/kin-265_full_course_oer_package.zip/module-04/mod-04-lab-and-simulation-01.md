# KIN-265: Mod 04 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 04 Lab & Simulation: Prenatal & Postpartum Exercise Plan Audit

Laboratorio del Módulo 04: Biomecánica Gestacional y Programación Segura para el Embarazo

- PAGA 2018 Maternal Benchmark (≥150 Min/Week Moderate Aerobic): Pregnant and postpartum women without medical/obstetric contraindications should accumulate at least 150 minutes/week of moderate-intensity aerobic activity. En palabras sencillas: Durante el embarazo sin complicaciones médicas se recomiendan al menos 150 minutos semanales de actividad aeróbica moderada.
- Supine Hypotensive Syndrome (Avoid Flat Back Position After 1st Trimester): Lying flat on the back after week 16–20 allows the gravid uterus to compress the inferior vena cava, reducing venous return and causing dizziness; use incline or side-lying positions. En palabras sencillas: Después del primer trimestre evitamos ejercicios acostada boca arriba para que el peso del bebé no presione la vena cava ni cause mareo.
- Absolute Obstetric Warning Signs to Terminate Exercise: Stop exercise immediately and seek medical evaluation for vaginal bleeding, regular painful contractions, amniotic fluid leakage, dyspnea before exertion, or dizziness. En palabras sencillas: Detener la sesión de inmediato y acudir al médico si hay sangrado, contracciones dolorosas, salida de líquido, mareo o falta de aire en reposo.
Welcome to your fourth practical laboratory assignment in Special Populations. This week, we analyze gestational movement mechanics, maternal-fetal hemodynamics, and thermal safety parameters during pregnancy. You will evaluate a pregnant client's athletic regimen and modify her programming utilizing our primary academic Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) supported by clinical gestational exercise standards from ACOG.

Bienvenido a su cuarta práctica de laboratorio de Ejercicio para Poblaciones Especiales. Esta semana analizaremos la mecánica gestacional, la hemodinámica materno-fetal y los parámetros de seguridad térmica durante el embarazo utilizando las pautas de PAGA 2018 y las normas clínicas de ACOG.

- KIN-265.4.1.AY26-27: Apply PAGA 2018 clinical guidelines for maternal-fetal safety, postural adaptations, and biomechanical shifts during pregnancy. Aplicar las pautas clínicas de PAGA 2018 para la seguridad materno-fetal, adaptaciones posturales y cambios biomecánicos durante el embarazo.
- KIN-265.4.2.AY26-27: Audit clinical safety parameters, supine position restrictions, and intensity regulations for prenatal exercise prescriptions. Auditar parámetros de seguridad clínica, restricciones en decúbito supino y regulación de intensidad para prescripciones de ejercicio prenatal.
- Module Window / Ventana del Módulo: Opens Tuesday, September 8, 2026, at 12:00 AM MST Abre el martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Submission Deadline / Fecha Límite de Entrega: Monday, September 14, 2026, at 11:59 PM MST Lunes, 14 de septiembre de 2026, a las 11:59 PM MST
- Grading Weight / Ponderación: Weekly Labs & Clinical Simulations Benchmark (10 Points) Ponderación para laboratorios semanales y simulaciones clínicas (10 Puntos)

### Lab Objectives / Objetivos del Laboratorio

Competencias clave del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Analyze maternal cardiovascular adaptations and the anatomical mechanics of supine hypotensive syndrome (inferior vena cava compression after 16 weeks). Analizar las adaptaciones cardiovasculares maternas y la mecánica anatómica del síndrome hipotensivo en decúbito supino.
- Evaluate relaxin-induced ligamentous laxity on gestational pelvic girdle stability and lumbar biomechanics. Evaluar la laxitud ligamentosa inducida por la relaxina en la estabilidad de la cintura pélvica y en la biomecánica lumbar.
- Synthesize a safe, heat-mitigated FITT-VP gestational conditioning routine incorporating clinical exercise termination warning signs. Sintetizar un programa de acondicionamiento gestacional FITT-VP adaptado al calor que incorpore señales clínicas de detención.
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Select Your Clinical Simulation Case File #265-04 / Fase 1: Selección de Escenario de Simulación Clínica

Elija su Ruta y Revise los Datos Gestacionales

Choose ONE of the three career-aligned tracks below to audit in the Gemini AI Tool Box:

Focus: Second-trimester primigravida patient (L.D., 32) presenting with symptomatic pelvic girdle pain, pubic symphysis dysfunction, and supine dizziness.


```text
###
[TRACK / RUTA]: Track 1 - Clinical Rehabilitation Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: L.D.
[AGE / EDAD]: 32 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 5 ft 5 in (165 cm)
[GESTATIONAL STATUS / ESTADO GESTACIONAL]: 22 Weeks Gestation (Second Trimester), low-risk singleton pregnancy. Cleared by OB/GYN.
[CLINICAL PRESENTATION / PRESENTACIÓN CLÍNICA]: Severe pelvic girdle pain (pubic symphysis shear), lumbar lordosis discomfort, and dizziness when lying flat supine during clinical evaluations.
[RESTING METRICS / MÉTRICAS EN REPOSO]: Resting HR: 72 bpm | Resting BP: 114/72 mmHg
[GOAL & REFERRAL / OBJETIVO Y REFERENCIA]: Pelvic alignment, core stabilization, and elimination of IVC occlusion risks. Referral: Matador Clinical Partners (MCP) Women's Health Physical Therapy.
###
```

Focus: Community participant (M.S., 26) seeking indoor group prenatal conditioning adapted for Yuma's high summer temperatures (108°F heat index).


```text
###
[TRACK / RUTA]: Track 2 - Community & Public Health Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: M.S.
[AGE / EDAD]: 26 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 5 ft 3 in (160 cm)
[GESTATIONAL STATUS / ESTADO GESTACIONAL]: 18 Weeks Gestation (Second Trimester), low-risk pregnancy.
[COMMUNITY PROFILE / PERFIL COMUNITARIO]: Agricultural field worker on modified desk duties; attempts outdoor walking in 108°F summer heat index.
[RESTING METRICS / MÉTRICAS EN REPOSO]: Resting HR: 70 bpm | Resting BP: 110/68 mmHg
[GOAL & REFERRAL / OBJETIVO Y REFERENCIA]: Safe indoor climate-controlled group exercise, fluid replenishment, heat exhaustion prevention. Referral: Yuma County Maternal Health Community District & Matador Clinical Partners (MCP).
###
```

Focus: Competitive recreational runner and lifter (J.V., 29) modifying high-impact running and heavy supine lifting into a safe second-trimester athletic routine.


```text
###
[TRACK / RUTA]: Track 3 - Sports & Athletic Performance Path
[CLIENT INITIALS / INICIALES DEL CLIENTE]: J.V.
[AGE / EDAD]: 29 | [SEX / SEXO]: Female | [LOCATION / UBICACIÓN]: Yuma County, AZ
[HEIGHT / ESTATURA]: 5 ft 7 in (170 cm)
[GESTATIONAL STATUS / ESTADO GESTACIONAL]: 20 Weeks Gestation (Second Trimester), low-risk singleton pregnancy. Cleared by OB/GYN.
[ATHLETIC ROUTINE / RUTINA DEPORTIVA]: Outdoor running (3-4 miles, 3 days/week); heavy barbell back squats, flat bench press, lying crunches (2 days/week).
[RESTING METRICS / MÉTRICAS EN REPOSO]: Resting HR: 68 bpm | Resting BP: 112/70 mmHg
[GOAL & REFERRAL / OBJETIVO Y REFERENCIA]: Maintain high athletic capacity, modify joint shear, avoid IVC compression. Referral: Matador Clinical Partners (MCP) Outpatient Maternal-Fetal Wellness.
###
```


### Phase 2: Gemini AI Clinical Simulation Workspace / Espacio de Simulación con IA

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Copy the prompt template below into Gemini AI. Keep your chosen case data enclosed inside the triple-hash ( ### ) delimiters:


```text
Safety Auditor Protocol: KIN-265 Module 04 Gestational Tool Box ###:
Role: Socratic Maternal-Fetal Exercise Specialist in the Narrator voice.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Edition) - Active Pregnant and Postpartum Women & ACOG Committee Opinion No. 804.

Instructions:
Step 1: Review the clinical gestational profile wrapped in triple-hashes (###) below.
Step 2: PATTERN: Explain the vascular anatomy of supine hypotensive syndrome (inferior vena cava compression after 16 weeks gestation) and the biomechanics of relaxin-induced pelvic girdle instability.
Step 3: RULE: Detail ACOG/PAGA target heart rate ranges (135-150 bpm for active females under 30; 130-145 bpm for active females 30+) and absolute clinical warning signs to terminate exercise immediately.
Step 4: SOLVE: Design a modified gestational FITT-VP program (including 45-degree incline modifications, pelvic floor strengthening, and indoor climate-controlled hydration) suited for Yuma's high summer heat. Include a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
[PASTE YOUR SELECTED TRACK CASE DATA HERE BETWEEN DELIMITERS]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Phase 3: Canvas Text Box Submission Template

Plantilla de Entrega en el Cuadro de Texto de Canvas

Copy the template below, populate your responses, and submit directly in Canvas:


```text
KIN-265 Module 04 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Athletic Performance]
Client Initials: [Insert Client Initials]

Step 1: Pattern Recognition (Physiological Gap Analysis & Gestational Biomechanics):
Key Point: Gestational Status & Trimester: [e.g., 20 Weeks Gestation, Second Trimester]
Key Point: Supine Hypotensive Syndrome & IVC Compression Mechanics:
Key Point: Relaxin Hormone Joint Laxity (Pubic Symphysis / Sacroiliac Joint Shear):
Key Point: Environmental Heat Hazards & Maternal Thermoregulation in Yuma:

Step 2: Rule Application (ACOG / PAGA Target Parameters & Hydration Math):
Key Point: Age-Appropriate ACOG Target Heart Rate Range: ___ to ___ bpm (or RPE 12-14)
Key Point: Plain-Text Hydration Calculations (Pre-, Intra-, and Post-Session Volumes in oz):
  Key Point: Pre-Exercise Hydration (2 hours prior): ___ oz
  Key Point: Intra-Exercise Hydration (Hourly / Interval Target): ___ oz
  Key Point: Post-Exercise Recovery Hydration: ___ oz
  Key Point: Total Target Session Fluid Intake: ___ oz

Step 3: Problem Solving (Modified Gestational FITT-VP & Warning Signs):
Key Point: Cardiovascular Modalities, Frequency & Duration (Climate-Controlled):
Key Point: Resistance Modifications (45-degree incline, bilateral symmetry, no Valsalva):
Key Point: Pelvic Floor / Transversus Abdominis Stabilization Protocol:
Key Point: ACOG Emergency Exercise Termination Warning Signs:
Key Point: Bilingual Client Instruction Card (EN / ES):

Step 4: Part 3 — Active Verification (Mandatory 150-Word Minimum in Your Own Human Voice):
Key Point: [In 150-word minimum (150+ words) written in your own clinical voice, justify how your Talk Test / RPE 12-13 intensity gate, elimination of supine vena cava compression, pelvic-floor breathing, and Yuma indoor thermal protection safeguard maternal and fetal health under PAGA 2018]

Step 5: Repository Verification:
AI Prompt Exchange exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M04_Pregnancy_Prescription_Audit.pdf
End Submission ###:
```


### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar / Modelo de Entrega (10/10 Benchmark)

Part 1: Physiological Gap Analysis (Análisis de Brecha Fisiológica): Key Point — Supine Hypotensive Syndrome Anatomy: After 16 weeks gestation, lying flat in a supine position (flat bench press, lying crunches) allows the heavy gravid uterus to compress the Inferior Vena Cava (IVC) and abdominal aorta against the spine, collapsing venous return, stroke volume, and maternal blood pressure, thereby compromising uteroplacental blood flow. Key Point — Relaxin & Pelvic Laxity: Elevated relaxin increases laxity at the pubic symphysis and sacroiliac (SI) joints. Outdoor road running and heavy back squats impose high asymmetric shear across these unstable structures, driving lower-back pain and pelvic floor strain. Key Point — Thermoregulatory Heat Hazards: Maternal core temperatures exceeding 102.2°F (39.0°C) risk fetal hyperthermia; outdoor running in Yuma's 108°F heat index is strictly contraindicated.

Part 2: Rule Application & Target Calculations (ACOG Standards): Key Point — Gestational Biometrics: 20 Weeks Gestation | Age: 29 | Low-risk singleton pregnancy cleared by OB/GYN. Key Point — Target Heart Rate Range (<30 Years, Active Female): 135 to 150 bpm (RPE 12-14 "somewhat hard"). Key Point — Indoor Hydration Math (45-Minute Session): Key Point: Pre-Exercise (2 hours prior): 16 oz water. Key Point: Intra-Exercise: 8 oz every 15 min = (45 min / 15 min) * 8 oz = 24 oz water. Key Point: Post-Exercise: 16 oz water. Key Point: Total Session Target: 16 oz + 24 oz + 16 oz = 56 total ounces .

Part 3: Solving the Gap (Prescription & Precautions): Key Point — Cardiovascular: Replace outdoor road running with low-impact recumbent cycling or incline treadmill walking, 3 to 4 days/week for 30 minutes in a 72°F room at 135 to 150 bpm. Key Point — Resistance & Core: 45-degree incline dumbbell bench press (replaces flat barbell bench), supported dumbbell goblet squats (replaces heavy barbell back squats), standing cable Pallof presses (replaces lying floor crunches), and daily pelvic floor Kegels (3 sets of 10 contractions). Strict elimination of the Valsalva maneuver. Key Point — Emergency Stop Signs: Immediately terminate exercise upon vaginal bleeding, fluid leakage, dizziness/syncope, pre-exercise dyspnea, chest pain, calf swelling (DVT risk), or regular painful uterine contractions.

EN: "Exercise in an air-conditioned room at an inclined angle to prevent blood vessel compression, and drink 56 ounces of water during your workout. Stop exercising immediately and contact your doctor if you experience dizziness, bleeding, chest pain, or contractions."

ES: "Haga ejercicio en un lugar climatizado usando una inclinación para evitar comprimir sus vasos sanguíneos, y tome 56 onzas de agua en su sesión. Deténgase de inmediato y llame a su médico si siente mareo, sangrado, dolor de pecho o contracciones."

Repository Verification: Complete Gemini AI audit log exported and archived in Google Drive folder: EXW_Professional_AI_Repository / EXW_265_M04_Pregnancy_Prescription_Audit.pdf


### Interactive Clinical Simulation & Outcome Gate (Module 04) / Simulación Clínica y Dominio de Resultados (Módulo 04)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 04 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 04 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 04 (Mod 04 Lab: Prenatal & Postpartum Exercise Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 04 Laboratorio y Simulación: Biomecánica Gestacional y Embarazo

Programación Segura, Hemodinámica Materno-Fetal y Prevención Térmica

En este laboratorio, evaluará el régimen de ejercicio de una cliente embarazada utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , adaptando posiciones que eviten la compresión de la vena cava y aplicando las pautas clínicas de PAGA 2018 y ACOG.

- Apertura del Módulo: Martes, 8 de septiembre de 2026, a las 12:00 AM MST
- Fecha Límite de Entrega: Lunes, 14 de septiembre de 2026, a las 11:59 PM MST
- Ponderación: Puntuación de laboratorios semanales y simulaciones clínicas (10 Puntos)

### Paso 1: Consulta en la Caja de Herramientas de IA Gemini

Pegue los datos de la ruta elegida en Gemini IA y copie esta plantilla debajo:


```text
Protocolo Safety Auditor: KIN-265 Laboratorio 04 ###:
Rol: Especialista Socratico en Ejercicio Materno-Fetal con la voz del Narrador.
SSoT: Pautas de Actividad Fisica para los Estadounidenses (PAGA 2018, 2.a edicion) y Normas Clinicas de ACOG.

Instrucciones:
Step 1: Revisar los datos del caso gestacional entre delimitadores (###).
Step 2: PATRON: Explicar la anatomia vascular del sindrome hipotensivo supino (oclusion de la vena cava inferior tras 16 semanas) y la biomecanica de la inestabilidad pelvica por relaxina.
Step 3: REGLA: Detallar los rangos de frecuencia cardiaca meta de ACOG (135 a 150 lpm para menores de 30 anos; 130 a 145 lpm para mayores de 30) y los signos de alarma para detener el ejercicio de inmediato.
Step 4: SOLUCION: Disenar un programa FITT-VP gestacional adaptado (banco inclinado a 45 grados, fortalecimiento de piso pelvico e hidratacion en interiores climatizados de Yuma).
Step 5: Generar una tarjeta de instruccion bilingue para el cliente (EN / ES).

Entrada de Datos del Cliente ###:
[PEGUE AQUI LOS DATOS DE SU RUTA ENTRE DELIMITADORES]
Fin de Datos del Cliente ###:
Fin del Protocolo Safety Auditor ###:
```


#### Paso 2: Plantilla de Entrega en Canvas (Solo Texto)


```text
KIN-265 Entrega de Laboratorio Modulo 04 ###:
Ruta Profesional Seleccionada: [Ruta 1: Clinica | Ruta 2: Comunitaria | Ruta 3: Rendimiento Deportivo]
Iniciales del Cliente: [Insertar Iniciales]

Step 1: Reconocimiento de Patrones (Analisis Fisiologico y Biomecanica Gestacional):
Key Point: Estado Gestacional y Trimestre: [ej. 20 semanas de gestacion, segundo trimestre]
Key Point: Mecanica del Sindrome Hipotensivo Supino y Compresion de la VCI:
Key Point: Laxitud Articular por Relaxina (Cizallamiento en Sinfisis Pubica y Sacroiliaca):
Key Point: Riesgos del Calor Extremo y Termorregulacion Materna en Yuma:

Step 2: Aplicacion de Reglas (Parametros ACOG / PAGA y Matematicas de Hidratacion):
Key Point: Rango de Frecuencia Cardiaca Meta segun la Edad: ___ a ___ lpm (o RPE 12-14)
Key Point: Calculo de Hidratacion en Texto Plano (Volumenes en Onzas):
  Key Point: Hidratacion Pre-Ejercicio (2 horas antes): ___ oz
  Key Point: Hidratacion Intra-Ejercicio (Meta por intervalo): ___ oz
  Key Point: Hidratacion de Recuperacion Post-Ejercicio: ___ oz
  Key Point: Ingesta Total de Liquidos por Sesion: ___ oz

Step 3: Resolucion de Problemas (FITT-VP Gestacional Modificado y Signos de Alarma):
Key Point: Modalidades Cardiovasculares en Sala Climatizada (22°C):
Key Point: Modificaciones de Fuerza (Inclinacion a 45 grados, simetria, sin Valsalva):
Key Point: Protocolo de Estabilidad de Core Profundo y Piso Pelvico:
Key Point: Signos de Alarma de Emergencia de ACOG:
Key Point: Tarjeta de Instruccion Bilingue para el Cliente (EN / ES):

Step 4: Verificación Activa Clinica Obligatoria (Mínimo 150 Palabras en su Propia Voz Humana):
Key Point: [En mínimo 150 palabras (150+ palabras) escritas en su propia voz clinica, justifique como el uso de la Prueba del Habla (RPE 12-13), la eliminacion de posturas supinas, el piso pelvico y el control termico en Yuma protegen la salud materno-fetal segun PAGA 2018]

Step 5: Verificacion del Repositorio:
Intercambio con la IA exportado y guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M04_Pregnancy_Prescription_Audit.pdf
Fin de la Entrega ###:
```

Parte 4: La Verificación Activa Ejemplar (Parte 3 — Mínimo 150 Palabras en la Voz del Estudiante): "En mi razonamiento clínico como especialista en ejercicio prenatal, usar fórmulas genéricas de frecuencia cardíaca máxima o rutinas de IA sin verificar en el segundo y tercer trimestre es inseguro debido a la expansión del volumen sanguíneo materno. Por ello, PAGA 2018 y ACOG exigen regular la intensidad mediante la Prueba del Habla y la escala RPE (12–13, 150 minutos semanales). Además, eliminar las posturas supinas evita la compresión de la vena cava inferior, y entrenar exclusivamente en interiores climatizados en Yuma previene la hipertermia materna (>39.0°C) y la deshidratación."


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 04 Quick Return Navigation / Regreso Rápido al Módulo 04:
