# KIN-265: Mod 13 Required Readings Nerve Conditions Stroke Parkinsons And Ms

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 13 Required Readings: Nerve Conditions (Stroke, Parkinson's & MS)

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from PAGA 2018 (2nd Ed., Chapters 5 & 6) & ACSM 12th Ed.), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 13): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Neurological conditions—such as stroke, Parkinson's disease, and multiple sclerosis (MS)—disrupt how the brain and spinal cord send signals to muscles. Task-specific gait training, rhythmic cueing, seated/supported stations, and strict cooling protocols (especially for heat-sensitive MS clients in Yuma) restore safe functional independence. Scheduling sessions during peak medication effectiveness ('on-time') maximizes balance and coordination.


#### En Palabras Sencillas (Norteño Context)

Cuando los cables que llevan la señal del cerebro al músculo fallan o se calientan con el sol de Yuma, adaptamos el entorno con soporte firme y aire fresco. Si los términos técnicos se ponen pesados, concéntrate primero en la prevención de caídas, el entrenamiento en horario de mejor efecto del medicamento y evitar el sobrecalentamiento en esclerosis múltiple.


### Core Literature & Federal Standards (SSoT)

To successfully complete Module 13 workflows, discussions, and laboratory assignments, review the core readings below. All instructional materials are anchored strictly in our Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .

Explore how repeated practice helps stroke survivors rebuild movement skills, how balance and stepping drills assist individuals with Parkinson's disease, and how managing body temperature protects clients with multiple sclerosis in Yuma's climate.


### Reading 1: PAGA 2018 (2nd Ed.) & Brain Plasticity • Rebuilding Movement After Stroke

Learn how regular, task-focused exercise helps the brain rewire itself after a stroke. When someone has a stroke, brain pathways get damaged, making movement difficult on one side of the body. PAGA 2018 guidelines show that doing structured aerobic and strength exercises helps spark new brain connections, improves physical independence, and lowers long-term health risks.

Study Tip: Think of brain plasticity like building a new road when the old bridge is closed—repeating the exercise makes the new pathway stronger.

Lectura 1: PAGA 2018 (2.ª ed.) y plasticidad cerebral • Reconstrucción del movimiento tras un ACV: Aprenda cómo el ejercicio enfocado ayuda al cerebro a reconectarse después de un derrame cerebral.


### Reading 2: Clinical Guidelines & Balance Rules • Managing Parkinson's Disease Through Movement

Understand how large, controlled movements and balance practice help clients with Parkinson's disease. Parkinson's can cause slow movement, shaking, and balance issues. Trainers following PAGA 2018 rules use big arm and leg motions, rhythmic cues (like a steady beat), and gentle strength exercises to help clients stay steady on their feet and reduce the risk of falls.

Study Tip: Focus on big steps and steady pacing to help clients overcome freezing and maintain everyday mobility.

Lectura 2: Pautas clínicas y reglas de equilibrio • Manejo de la enfermedad de Parkinson mediante el movimiento: Comprenda cómo los movimientos amplios y el equilibrio ayudan a los clientes con Parkinson.


### Reading 3: Environmental Physiology & Temperature Control & Multiple Sclerosis in Yuma

Discover why keeping cool is essential when designing workouts for clients with Multiple Sclerosis (MS). MS affects how nerves send signals, and getting too hot can temporarily make symptoms like fatigue and muscle weakness worse. Because Yuma gets very warm, workouts should always take place in air-conditioned spaces (72°F / 22°C) with plenty of water and cool-down breaks.

Study Tip: Always check room temperature and keep water nearby so clients stay cool and comfortable during exercise.

Lectura 3: Fisiología ambiental y control de temperatura • Esclerosis múltiple en Yuma: Descubra por qué mantenerse fresco es esencial al diseñar rutinas para clientes con esclerosis múltiple.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 13 (Mod 13 Required Readings: Nerve Conditions (Stroke, Parkinson's & MS))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading texts in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los textos de lectura obligatoria en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Obligatorias del Módulo 13: Patologías del SNC, Plasticidad y Guías Prácticas


### Literatura Principal y Normas Federales (SSoT)

Para completar con éxito las actividades del Módulo 13, revise las lecturas principales ancladas en nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) .

Explore cómo la práctica ayuda a los sobrevivientes de ACV, cómo los ejercicios de equilibrio asisten al Parkinson y cómo controlar la temperatura corporal protege a los clientes con esclerosis múltiple en Yuma.


### Lectura 1: PAGA 2018 (2.ª ed.) y plasticidad cerebral • Reconstrucción del movimiento tras un ACV

Aprenda cómo el ejercicio constante ayuda al cerebro a crear nuevas conexiones y mejorar la independencia física después de un derrame cerebral.

Consejo de estudio: Piense en la plasticidad cerebral como la creación de un nuevo camino cuando la ruta anterior está bloqueada.


### Lectura 2: Pautas clínicas • Manejo de la enfermedad de Parkinson

Comprenda cómo los movimientos amplios y el entrenamiento del equilibrio ayudan a los clientes con Parkinson a mantenerse estables y reducir caídas.

Consejo de estudio: Concéntrese en pasos firmes y amplios para mejorar la movilidad diaria del cliente.


### Lectura 3: Fisiología ambiental • Esclerosis múltiple en Yuma

Descubra por qué hacer ejercicio en espacios con aire acondicionado (22°C) protege a los clientes con esclerosis múltiple del calor excesivo y la fatiga.

Consejo de estudio: Verifique siempre la temperatura del lugar y tenga agua a la mano para mantener frescos a los clientes.

KIN-265 • Module 13 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 13:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
