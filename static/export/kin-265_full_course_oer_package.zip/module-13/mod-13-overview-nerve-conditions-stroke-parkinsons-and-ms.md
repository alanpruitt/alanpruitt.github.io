# KIN-265: Mod 13 Overview Nerve Conditions Stroke Parkinsons And Ms

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 13 Overview: Nerve Conditions (Stroke, Parkinson's & MS)

El Porqué del Módulo 13 (Círculo Dorado — Contexto Norteño): “¿Por qué el calor de Yuma y la falta de equilibrio amenazan la independencia en secuelas de embolia, Parkinson y esclerosis múltiple, y cómo el ejercicio bajo techo devuelve la seguridad?”


### Module 13 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 13: Nerve Conditions (Stroke, Parkinson's & MS)

Welcome to Week 13! Moving from musculoskeletal health into central nervous system pathologies, this week we examine Nerve Conditions (Stroke, Parkinson's & MS) . Stroke, Parkinson's Disease, and Multiple Sclerosis present unique challenges including motor control impairments, balance deficits, spasticity, and autonomic/thermal dysregulation.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify neurodegenerative movement patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety thresholds and RPE tracking, and design dual-task functional mobility interventions.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, November 10, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, November 12, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, November 15, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, November 16, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 13 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze central nervous system pathologies, motor control deficits, and neuroplasticity pathways. Analizar patologías del sistema nervioso central, déficits de control motor y vías de neuroplasticidad.
- CLO 2 (Rule Application): Apply PAGA 2018 safety thresholds, RPE tracking, and stability-focused progression rules. Aplicar umbrales de seguridad de PAGA 2018, seguimiento de RPE y reglas de progresión enfocadas en la estabilidad.
- CLO 3 (Problem Solving): Formulate an evidence-based dual-task mobility prescription for a client with Parkinson's disease. Formular una prescripción de movilidad de doble tarea basada en evidencia para un cliente con enfermedad de Parkinson.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will work within your chosen career track:

Managing post-stroke gait re-education and neuroplasticity-focused functional conditioning in outpatient clinics.

Designing community balance and agility classes for older adults managing early-stage Parkinson's Disease in Yuma.

Screening tactical personnel for vestibular, balance, and autonomic recovery following traumatic head injuries.


### Module 13 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Central Nervous System Pathologies & PAGA 2018 Standards
- Discussion Board: Neuroplasticity, Motor Control & Safety
- Coaching Sprint: Applied Clinical Reasoning & Practical Coaching Drills
- Lab Assignment: Neurological Exercise Prescription Audit & Gemini AI Tool Kit
- Summary & Wrap-Up: Knowledge Check & Transition to Module 14
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 13 (Mod 13 Overview: Nerve Conditions (Stroke, Parkinson's & MS))
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 13 Visión General: Patologías Neurológicas y Neuroplasticidad


### Bienvenido al Módulo 13: Accidente Cerebrovascular, Parkinson y Esclerosis Múltiple

¡Bienvenido a la Semana 13! Pasando de la salud musculoesquelética a las patologías del sistema nervioso central, esta semana examinamos las Patologías Neurológicas y la Prescripción de Ejercicio . El ACV, el Parkinson y la Esclerosis Múltiple presentan desafíos únicos que incluyen impedimentos motores y desregulación autonómica.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones de movimiento neurodegenerativo, aplicarás las normas de PAGA 2018 y diseñarás intervenciones de movilidad de doble tarea.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar patologías del sistema nervioso central y vías de neuroplasticidad.
- CLO 2 (Regla): Aplicar umbrales de seguridad de PAGA 2018 y seguimiento de RPE.
- CLO 3 (Solución): Formular una prescripción de movilidad de doble tarea para Parkinson.

### Construya su Propio Camino • Vista previa de las 3 rutas

En las actividades de este módulo, trabajarás dentro de la ruta seleccionada:

Manejo de reeducación de la marcha post-ACV y acondicionamiento enfocado en neuroplasticidad.

Diseño de clases comunitarias de equilibrio para adultos mayores con enfermedad de Parkinson en Yuma.

Tamizaje de personal táctico para recuperación vestibular y autonómica tras lesiones craneales.


### Ruta de Aprendizaje del Módulo 13

- Visión General y Objetivos del Módulo (¡Estás aquí!)
- Lectura Principal: Patologías del Sistema Nervioso Central y PAGA 2018
- Foro de Discusión: Neuroplasticidad, Control Motor y Seguridad
- Sprint de Entrenamiento: Razonamiento Clínico Aplicado y Práctica
- Práctica de Laboratorio: Auditoría Neurológica y Caja de Herramientas
- Comprobación de Conocimientos y Transición al Módulo 14

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 13 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 13 Required Readings: Nerve Conditions (Stroke, Parkinson's & MS) →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 13 Discussion: Supporting Balance & Mobility in Stroke, Parkinson's & MS →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 13 Coaching Sprint: Preventing Falls & Heat Fatigue in Nerve Conditions →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 13 Lab: Stroke, Parkinson's & MS Exercise Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 13 Summary & Wrap-Up: Nerve Conditions (Stroke, Parkinson's & MS) →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
