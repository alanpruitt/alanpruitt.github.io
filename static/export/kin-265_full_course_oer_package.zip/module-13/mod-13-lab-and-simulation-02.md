# KIN-265: Mod 13 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 13 Lab & Simulation: Stroke, Parkinson's & MS Exercise Plan Audit

- Uhthoff's Phenomenon in Multiple Sclerosis (Thermosensitivity Gate): Even a 0.5°C rise in core body temperature temporarily blocks demyelinated nerve conduction in MS, worsening vision, balance, and weakness; mandate <72°F indoor AC, cooling vests/fans, and cool water in Yuma. En palabras sencillas: En Esclerosis Múltiple el calor empeora de inmediato la fuerza y el equilibrio (Fenómeno de Uhthoff); es obligatorio entrenar bajo techo frío (<72°F) con ventilador y agua fresca en Yuma.
- Parkinson's Freezing of Gait & External Rhythmic Cueing: Using visual floor lines, metronome beats, wide-stance stepping, and big-amplitude movements (LSVT BIG principles) to bypass basal ganglia gait freezing. En palabras sencillas: Usar líneas visuales en el piso, ritmo con palmadas o metrónomo y pasos amplios para ayudar al paciente con Parkinson a destrabar la marcha.
- Post-Stroke Hemiparesis & Fall-Safe Seated/Recumbent Ergometry: Securing the affected limb (foot straps/grip assist) on a recumbent stepper or cycle ergometer and training task-specific sit-to-stand and balance transfers. En palabras sencillas: Usar bicicleta reclinada o aparatos con soporte seguro para el lado afectado tras una embolia (EVC), cuidando siempre el equilibrio.

### Lab Overview: Neurological Risk Audit & PAGA 2018 Prescription Formulation

In this laboratory practical, you will execute a comprehensive neurological risk audit and formulate an evidence-based exercise prescription for a client presenting with stroke recovery, Parkinson's disease, or post-concussion vestibular/thermal sensitivity.

You will apply the Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in federal standards ( PAGA 2018 ) and use the Gemini AI Tool Kit with secure triple-hash delimiters (###) to audit your clinical safety.


### Lab Logistics & Deadlines / Logística y Fechas Límite

- Due Date / Fecha Límite: Monday, November 16, 2026, at 11:59 PM MST / Lunes 16 de noviembre de 2026 a las 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry / Entrada de texto directa en Canvas
- Points / Puntos: 30 Total Points (10/7/0 Exemplary / Competent / Recalibrate Scale)
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Part A: Choose Your Career Track & Clinical Case File / Seleccione su Ruta y Caso Clínico

Client: 58-year-old male, 6 months post-stroke with left hemiparesis and balance deficits. Prescribe a neuroplasticity-focused gait re-education routine. Cliente: Varón de 58 años, 6 meses post-ACV con hemiparesia izquierda y déficits de equilibrio. Prescriba rutina de reeducación de marcha enfocada en neuroplasticidad.

Client: 68-year-old female with early-stage Parkinson's Disease (Hoehn & Yahr Stage 2). Formulate an amplitude-focused movement and dual-task balance routine. Cliente: Mujer de 68 años con Parkinson en etapa temprana (Hoehn & Yahr Etapa 2). Formule movimientos de amplitud y rutina de estabilidad de doble tarea.

Client: 42-year-old first responder recovering from mild traumatic brain injury with vestibular and thermal sensitivity. Design a climate-controlled conditioning protocol. Cliente: Primer respondedor de 42 años recuperándose de lesión cerebral con sensibilidad vestibular y térmica. Diseñe protocolo en clima controlado.


### Part B: Clinical Framing Protocol (Pattern

Rule / Solve) Clinical Audit / Auditoría del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Pattern Recognition / Reconocimiento de Patrones: Identify all central nervous system deficits, motor control bottlenecks, and safety considerations. Identifique déficits del sistema nervioso central, cuellos de botella de control motor y consideraciones de seguridad.
- Rule Application / Aplicación de Reglas: Apply PAGA 2018 neurological parameters, RPE tracking, stability rules, and climate-controlled environment parameters. Aplique parámetros neurológicos de PAGA 2018, seguimiento de RPE, reglas de estabilidad y parámetros ambientales.
- Problem Solving / Resolución de Problemas: Formulate a 3-phase FITT-VP prescription and neurological safety monitoring plan. Formule una prescripción FITT-VP de 3 fases y un plan de monitoreo de seguridad neurológica.

### Part C: Gemini AI Tool Kit & Safety Auditor Protocol


```text
Safety Auditor Protocol: KIN-265 Module 13 Lab ###:
Role: Clinical Exercise Physiologist and Neurological Safety Auditor.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Audit the student's neurological case audit and FITT-VP prescription.
Step 2: Evaluate adherence to PAGA 2018 standards, RPE tracking, and stability/thermal parameters.
Step 3: Verify secure delimiter usage (###).

Client Data Input ###:
Career Track: [Insert Track 1, 2, or 3]
Client Case Summary: [Insert summary]
Student Clinical Framing Protocol (Pattern / Rule / Solve) Analysis: [Insert student analysis]
Student FITT-VP Prescription: [Insert prescription]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Submission Template / Plantilla de Entrega


```text
KIN-265 Module 13 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Tactical]

Step 1: Pattern Recognition (Neurological Risk Audit):
Key Point: Client Profile & CNS/Balance Baselines (Resting BP/HR, Hemiparesis/Tremor/Vestibular notes):
Key Point: Absolute/Relative Contraindications Identified:

Step 2: Rule Application (PAGA 2018 Standards):
Key Point: FITT-VP Neurological & Stability Parameters:
Key Point: Intensity Monitoring (RPE Tracking & Thermal/Fall Prevention Rules):

Step 3: Problem Solving (Prescription & Safety Plan):
Key Point: 3-Phase Prescription:
Key Point: Neurological Modifications & Emergency Stop Limits:

Step 4: AI Tool Kit Audit Reflection:
Key Point: Summary of Gemini AI Safety Auditor feedback and delimiter compliance:
End Submission ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric / Rúbrica de Calificación (30 Points Total • 10/7/0 Scale)

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 13 (Mod 13 Lab: Stroke, Parkinson's & MS Exercise Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 13 Lab: Prescripción de Ejercicio Neurológico y Auditoría


### Visión General del Laboratorio: Auditoría de Riesgo Neurológico y PAGA 2018

En esta práctica de laboratorio, ejecutarás una auditoría integral de riesgo neurológico y formularás una prescripción de ejercicio para un cliente con ACV, Parkinson o sensibilidad vestibular/térmica.

Aplicarás el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) anclado en normas federales ( PAGA 2018 ) y usarás la Caja de Herramientas Gemini con delimitadores seguros (###).


### Logística de Laboratorio y Fechas Límite

- Fecha Límite: Lunes 16 de noviembre de 2026 a las 11:59 PM MST
- Formato: Entrada de texto directa en Canvas
- Puntaje: 30 Puntos Totales (Escala 10/7/0 Exemplary / Competent / Recalibrate)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Seleccione su Ruta y Caso Clínico

Elija la ruta profesional correspondiente a su enfoque:

Varón de 58 años, 6 meses post-ACV con hemiparesia izquierda. Prescriba rutina de reeducación de marcha enfocada en neuroplasticidad.

Mujer de 68 años con Parkinson (Etapa 2). Formule movimientos de amplitud y rutina de estabilidad de doble tarea.

Primer respondedor de 42 años con síndrome postconmoción y sensibilidad al calor. Diseñe protocolo en clima controlado.


### Parte B: Auditoría del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Reconocimiento de Patrones: Identifique déficits del sistema nervioso central y consideraciones de seguridad.
- Aplicación de Reglas: Aplique parámetros neurológicos de PAGA 2018, seguimiento de RPE y estabilidad.
- Resolución de Problemas: Formule una prescripción FITT-VP de 3 fases y un plan de monitoreo de seguridad.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
