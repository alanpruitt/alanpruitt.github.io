# KIN-265: Mod 13 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 13 Discussion: Supporting Balance & Mobility in Stroke, Parkinson's & MS

Foro de Discusión del Módulo 13: Patologías del Sistema Nervioso Central y Seguridad en el Movimiento

- Uhthoff's Phenomenon in Multiple Sclerosis (Thermosensitivity Gate): Even a 0.5°C rise in core body temperature temporarily blocks demyelinated nerve conduction in MS, worsening vision, balance, and weakness; mandate <72°F indoor AC, cooling vests/fans, and cool water in Yuma. En palabras sencillas: En Esclerosis Múltiple el calor empeora de inmediato la fuerza y el equilibrio (Fenómeno de Uhthoff); es obligatorio entrenar bajo techo frío (<72°F) con ventilador y agua fresca en Yuma.
- Parkinson's Freezing of Gait & External Rhythmic Cueing: Using visual floor lines, metronome beats, wide-stance stepping, and big-amplitude movements (LSVT BIG principles) to bypass basal ganglia gait freezing. En palabras sencillas: Usar líneas visuales en el piso, ritmo con palmadas o metrónomo y pasos amplios para ayudar al paciente con Parkinson a destrabar la marcha.
- Post-Stroke Hemiparesis & Fall-Safe Seated/Recumbent Ergometry: Securing the affected limb (foot straps/grip assist) on a recumbent stepper or cycle ergometer and training task-specific sit-to-stand and balance transfers. En palabras sencillas: Usar bicicleta reclinada o aparatos con soporte seguro para el lado afectado tras una embolia (EVC), cuidando siempre el equilibrio.
- KIN-265.13.1.AY26-27: Analyze central nervous system pathologies, motor control deficits, and autonomic/thermal dysregulation risks across diverse career tracks. Analizar patologías del sistema nervioso central, déficits de control motor y riesgos de desregulación autonómica/térmica en diversas rutas profesionales.
- KIN-265.13.2.AY26-27: Apply PAGA 2018 guidelines and formulate an evidence-based dual-task mobility prescription incorporating safety and RPE thresholds using secure AI verification protocols. Aplicar las pautas de PAGA 2018 y formular una prescripción de movilidad de doble tarea incorporando seguridad y umbrales de RPE utilizando protocolos seguros con IA.

### Your Weekly Win: Auditing Neurological Risk & Prescriptive Safety

How can fitness professionals safely audit neurological risk and design dual-task exercise prescriptions for clients recovering from a stroke, managing Parkinson's disease, or living with multiple sclerosis? Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, exercise specialists identify central nervous system bottlenecks, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) safety thresholds, and formulate adaptive mobility programs. Choose one of the three career tracks below, chat with your AI Safety Auditor using mandatory triple-hash delimiters (`###`), and master neurological safety auditing!

¿Cómo pueden los profesionales auditar el riesgo neurológico y diseñar prescripciones de doble tarea para clientes con ACV, Parkinson o esclerosis múltiple? Utilizando el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución), aplicamos las pautas de PAGA 2018 y diseñamos programas adaptativos. ¡Elija una ruta, dialogue con su auditor de seguridad y domine la auditoría neurológica!

- Topic Opens / Apertura: Tuesday at 12:00 AM MST / Martes a las 12:00 AM MST
- Initial Post Due / Publicación Inicial: Thursday at 11:59 PM MST / Jueves a las 11:59 PM MST
- Peer Replies Due / Respuestas a Compañeros: Sunday at 11:59 PM MST / Domingo a las 11:59 PM MST
- Board Ccloses / Cierre del Foro: Monday at 11:59 PM MST / Lunes a las 11:59 PM MST
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Post-stroke outpatient rehabilitation client experiencing left-sided hemiparesis and balance deficits; establishing neuroplasticity-focused functional conditioning.

Scenario: Community center participant with early-stage Parkinson's Disease (Hoehn and Yahr Stage 2); formulating a dual-task agility and stability routine.

Scenario: First responder recovering from mild traumatic brain injury with vestibular and thermal sensitivity; designing a climate-controlled conditioning protocol.


### Phase 2: Gemini AI Safety Simulation Workspace

Paso 2: Copie la plantilla y consulte a su auditor de seguridad para evaluar su caso

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Discussion Tasks / Tareas de Discusión (Due Thursday / Jueves 11:59 PM MST)

- Pattern Recognition & Risk Stratification: State your chosen career track and client profile, identifying key central nervous system deficits, motor control bottlenecks, and safety considerations. Indique su ruta profesional y perfil de cliente, señalando déficits del sistema nervioso central y consideraciones de seguridad.
- Rule Application (PAGA 2018 FITT-VP Prescription): Design a 3-phase FITT-VP dual-task mobility prescription adhering strictly to PAGA 2018 guidelines and stability/RPE thresholds. Diseñe una prescripción FITT-VP de doble tarea adhiriéndose estrictamente a las pautas de PAGA 2018 y umbrales de estabilidad/RPE.
- Problem Solving & Safety Audit: Explain how you will monitor patient safety (e.g., thermal regulation, RPE tracking, fall prevention) during exercise sessions. Explique cómo monitoreará la seguridad del paciente (regulación térmica, seguimiento de RPE, prevención de caídas) durante las sesiones.

#### Peer Engagement Requirement / Requisito de Interacción

By Sunday at 11:59 PM MST , respond to at least ONE (1) classmate who selected a different track. Evaluate their neurological risk stratifications and suggest one additional safety precaution or neuroplasticity-focused modification.

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 13 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 13 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 13 (Mod 13 Discussion: Supporting Balance & Mobility in Stroke, Parkinson's & MS)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Foro de Discusión del Módulo 13: Patologías del SNC y Seguridad en el Movimiento

Auditoría de Riesgo Neurológico y Prescripción Segura


### Su Logro Semanal: Auditando el Riesgo Neurológico y la Seguridad Prescriptiva

¡Bienvenidos a la discusión de la Semana 13! En este foro interactivo, examinará un caso clínico neurológico, aplicará el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y diseñará una prescripción de movilidad basada en PAGA 2018. ¡Elija una ruta, consulte a su auditor de seguridad y participe!

- Apertura del Foro: Martes a las 12:00 AM MST
- Publicación Inicial: Jueves a las 11:59 PM MST
- Respuestas a Compañeros: Domingo a las 11:59 PM MST
- Cierre del Foro: Lunes a las 11:59 PM MST

### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN caso)

Seleccione el caso para su análisis y participación en el foro:

Paciente post-ACV con hemiparesia izquierda. Meta: Establecer una rutina de reeducación de marcha enfocada en neuroplasticidad.

Participante con Parkinson (Etapa 2). Meta: Implementar movimientos enfocados en amplitud y rutina de estabilidad de doble tarea.

Primer respondedor con síndrome postconmoción y sensibilidad al calor. Meta: Diseñar protocolo de estabilización vestibular en clima controlado.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del caso (en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Tareas del Foro (Jueves 11:59 PM MST)

- Reconocimiento de Patrones y Estratificación: Indique su ruta y señale déficits del sistema nervioso central y consideraciones de seguridad.
- Aplicación de Reglas (Prescripción FITT-VP): Diseñe una prescripción de doble tarea adhiriéndose a PAGA 2018 y umbrales de estabilidad/RPE.
- Resolución y Seguridad: Explique cómo monitoreará la seguridad del paciente (regulación térmica, RPE, prevención de caídas) durante las sesiones.
KIN-265 • Module 13 Quick Return Navigation / Regreso Rápido al Módulo 13:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
