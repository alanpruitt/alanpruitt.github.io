# KIN-265: Mod 03 Required Readings Bone Density Muscle Loss And Fall Prevention

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 03 Required Readings: Bone Density, Muscle Loss & Fall Prevention

Lecturas Clínicas Obligatorias: Osteoporosis, Densidad Ósea y Prevención de Caídas


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Osteoporosis (porous, fragile bone) and sarcopenia (age-related muscle loss) increase fall and fracture risk in older adults. Weight-bearing aerobic movement, multi-component balance training, and posture-safe resistance exercise stimulate bone-building cells and leg strength. Avoiding loaded spinal flexion (rounding the back under weight) prevents vertebral fractures.


#### En Palabras Sencillas (Norteño Context)

Los huesos y músculos se mantienen firmes cuando les damos trabajo seguro, igual que los postes de una cerca bien plantada. Si los términos técnicos se ponen pesados, concéntrate primero en el entrenamiento multicomponente (fuerza, equilibrio y carga ósea) sin flexión peligrosa de la columna.


### Required SSoT Text & Clinical Guidelines

Single Source of Truth (SSoT): Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) • Chapter 2 (Physical Activity Fundamentals), Chapter 5 (Active Older Adults), and Chapter 6 (Chronic Health Conditions and Disabilities).

PAGA 2018 Interactive SSoT Tool ("PAGA" in Course Navigation Bar • paga2018.dev) Pautas Federales PAGA 2018: Actividad Física Multicomponente, Densidad Ósea y Prevención de Caídas.

- Bone Health & Osteoporosis Foundation (BHOF): BHOF Clinician's Guide to Prevention and Treatment of Osteoporosis
- CDC STEADI Fall Prevention Clinical Framework: CDC STEADI: Stopping Elderly Accidents, Deaths, & Injuries
- Interactive PAGA Clinical Calculators ("PAGA" in Left Menu): Activity Audit (2-for-1 Rule) • Intensity & METs • Clinical Case Coach (Pattern / Rule / Solve)
- Offline AI Repository Document: exw265_ssot_special_populations_reference.docx (Local AI Preceptor and study file)

### Regional Focus: Fall Prevention & Bone Density in the Desert Southwest

Enfoque Regional: Prevención de Caídas y Preservación Ósea en el Condado de Yuma

In Yuma County and regional border communities, seasonal climate extremes (summer ambient temperatures exceeding 105°F) force many older adults into indoor sedentary isolation for multiple consecutive months. This extended physical inactivity accelerates sarcopenia and trabecular bone demineralization, dramatically increasing fall and fracture risks. Clinical exercise specialists must prescribe safe, climate-controlled, neutral-spine multicomponent programs that rebuild balance and bone density without hazardous outdoor thermal exposure.

En el condado de Yuma y las comunidades fronterizas, el calor extremo del verano (superando 40.5°C) obliga a muchos adultos mayores a un confinamiento sedentario en interiores durante meses. Esta inactividad prolongada acelera la sarcopenia y la desmineralización ósea, elevando el riesgo de caídas y fracturas. Los especialistas en ejercicio deben prescribir programas multicomponente en ambientes climatizados que fortalezcan el equilibrio y la masa ósea sin exponer al paciente al calor extremo.


### Reading 1: Wolff's Law & DXA T-Score Risk Stratification

Lectura 1: Ley de Wolff, Remodelación Ósea y Puntuaciones T en DXA

Bone tissue remodels dynamically according to Wolff's Law : mechanical strain and muscle tensile forces stimulate osteoblast bone formation along lines of stress, while unloading and physical inactivity accelerate osteoclast-mediated bone resorption. Diagnostic risk is stratified via Dual-Energy X-ray Absorptiometry (DXA) T-scores comparing bone mineral density (BMD) to a young adult reference mean:

El tejido óseo se remodela según la Ley de Wolff : la deformación mecánica y la tensión muscular estimulan la formación ósea por osteoblastos, mientras que el reposo y la inactividad aceleran la reabsorción por osteoclastos. El diagnóstico clínico se clasifica mediante la puntuación T en DXA:

- Normal Bone Density (T-score ≥ -1.0 SD): Standard high-impact loading and progressive resistance training per PAGA guidelines. Densidad Ósea Normal (T ≥ -1.0 DE): Carga mecánica progresiva estándar según las pautas federales.
- Osteopenia / Low Bone Mass (-1.0 > T-score > -2.5 SD): Moderate site-specific axial resistance training (squats, step-ups, standing posture alignment) and brisk walking. Osteopenia / Masa Ósea Baja (-1.0 a -2.5 DE): Carga axial moderada y caminata activa para preservar la masa mineral.
- Osteoporosis (T-score ≤ -2.5 SD): High clinical fracture risk. Requires neutral-spine axial loading and multicomponent balance drills with strict prohibition of loaded spinal flexion, rapid rotation, and high-impact ballistic jumping . Osteoporosis (T ≤ -2.5 DE): Alto riesgo de fractura. Exige fuerza axial con columna neutral y equilibrio, con prohibición estricta de flexión espinal con carga y giros bruscos.

### Reading 2: Absolute Biomechanical Contraindications in Osteoporosis

Lectura 2: Contraindicaciones Biomecánicas Absolutas y Prevención de Fracturas

In clients with osteopenia or osteoporosis, specific exercise motions generate high anterior compressive and shear loads across compromised vertebral bodies, triggering acute vertebral wedge compression fractures. Exercise specialists must strictly enforce these safety boundaries:

En personas con osteoporosis, ciertos movimientos generan altas fuerzas de cizallamiento y compresión anterior sobre cuerpos vertebrales debilitados, provocando fracturas vertebrales en cuña. Los especialistas deben evitar estrictamente estos movimientos:


### Reading 3: PAGA 2018 Multicomponent Physical Activity Mandates

Lectura 3: Estándares de Actividad Física Multicomponente de PAGA 2018

For older adults and individuals with chronic conditions affecting mobility and bone density, PAGA 2018 (2nd Ed.) mandates a Multicomponent Physical Activity framework:

Para adultos mayores y personas con afecciones crónicas, PAGA 2018 (2.ª ed.) establece un marco obligatorio de Actividad Física Multicomponente :

- Step 1: Multicomponent Balance & Functional Training: At least 3 days per week of dedicated balance training (tandem stance, single-leg balancing with support, dynamic heel-to-toe walking, obstacle navigation) to reduce fall risk.
- Step 2: Muscle-Strengthening & Bone-Loading Activity: At least 2 or more days per week targeting all major muscle groups (8–12 repetitions at moderate to vigorous intensity) using neutral-spine axial loading (squats, leg press, wall sits) to stimulate bone mineral retention.
- Step 3: Aerobic Physical Activity: 150 to 300 minutes per week of moderate-intensity aerobic activity (brisk walking, indoor recumbent cycling) tailored to the individual's functional capacity and thermal tolerance.

### Key Terminology / Glosario Clave

The biological adaptation principle stating that bone architecture remodels in direct proportion to mechanical forces and muscle traction placed upon it, requiring axial loading to stimulate osteoblastic mineral deposition.

Principio de adaptación biológica que establece que el hueso se remodela en respuesta a la tensión mecánica y muscular, requiriendo carga axial para estimular la mineralización osteoblástica.

An acute structural failure of the anterior vertebral body caused by excessive forward trunk flexion and compressive shear forces acting on demineralized osteoporotic bone; strictly prevented by maintaining a neutral spine.

Colapso estructural agudo de la parte anterior del cuerpo vertebral causado por flexión del tronco con carga sobre hueso osteoporótico; se previene manteniendo siempre la columna neutra.

A physical activity paradigm mandated by PAGA 2018 for older adults that integrates balance training, progressive muscle resistance, and aerobic movement within a single comprehensive routine to prevent falls and preserve functional independence.

Marco prescrito por PAGA 2018 para adultos mayores que combina equilibrio, fuerza muscular y ejercicio aeróbico en una sola rutina para evitar caídas y preservar la autonomía funcional.


### Reading Knowledge Verification

Verificación Rápida de Lectura y Conceptos Clínicos

Select each question below to confirm your understanding of bone remodeling and clinical contraindications before starting Discussion 03 and Lab 03:

English Response: Forward flexion shifts the center of pressure anteriorly onto the weakened trabecular bone of the vertebral body. Adding external load or dynamic compression drastically increases anterior shear, risking acute vertebral wedge compression fractures.

Respuesta en Español: La flexión hacia adelante traslada la presión hacia la parte anterior del cuerpo vertebral debilitado. Añadir carga o compresión dinámica eleva el cizallamiento anterior, provocando fracturas vertebrales en cuña.

English Response: Bone strengthens specifically in the anatomical regions experiencing mechanical strain. To stimulate osteogenesis at the femoral neck and hip, exercises must provide vertical axial loading and ground reaction forces through the lower limbs (e.g., squats, lunges, step-ups, brisk walking) rather than non-weight-bearing activities like swimming.

Respuesta en Español: El hueso se fortalece en las zonas que experimentan tensión mecánica. Para estimular la osteogénesis en el cuello femoral y la cadera, los ejercicios deben generar carga axial gravitacional en miembros inferiores (sentadillas, subidas al escalón, caminata) en lugar de ejercicios sin carga como la natación.

English Response: The PAGA 2018 multicomponent framework requires combining: (1) Dynamic and static balance training (≥3 days/week), (2) Progressive muscle-strengthening and axial resistance training (≥2 days/week), and (3) Moderate-intensity aerobic physical activity (150–300 min/week).

Respuesta en Español: El marco multicomponente de PAGA 2018 exige combinar: (1) Entrenamiento de equilibrio estático y dinámico (≥3 días/sem), (2) Fortalecimiento muscular con carga axial (≥2 días/sem), y (3) Actividad aeróbica moderada (150 a 300 min/sem).


### AI Simulation Workspace • Clinical Bone Health Simulation

Copy the prompt below into Gemini to audit DXA T-scores, screen for biomechanical contraindications, and design a multicomponent exercise prescription:

(Click inside the box below to select all text, then press Ctrl + C / Cmd + C to copy)


```text
Safety Auditor Protocol: KIN-265 Module 03 Bone Health Tool Box ###:
Role: Clinical Exercise Physiologist and Geriatric Mobility Specialist.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) - Active Older Adults & Chronic Conditions.

Instructions:
Step 1: Audit the student's clinical case data enclosed within triple-hash (###) delimiters below.
Step 2: Classify the client's bone density status (Normal, Osteopenia, Osteoporosis) based on their DXA T-score at the lumbar spine and femoral neck.
Step 3: Screen proposed exercises and audit against absolute biomechanical contraindications (prohibit loaded spinal flexion and rapid spinal rotation).
Step 4: Formulate a PAGA 2018 multicomponent exercise prescription combining neutral-spine axial loading, progressive resistance, and dynamic balance drills.
Step 5: Provide a 2-sentence bilingual client instruction card in English and Spanish.

Client Data Input ###:
Client Age: [Insert Age]
Biological Sex: [Insert Sex]
DXA Lumbar Spine T-score: [Insert T-score, e.g., -2.8]
DXA Femoral Neck T-score: [Insert T-score, e.g., -2.2]
Functional Limitations / Fall History: [Insert Fall History]
Proposed Exercise Routine: [List Exercises]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 03 (Mod 03 Required Readings: Bone Density, Muscle Loss & Fall Prevention)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable OER access.

Español: Todos los materiales de KIN-265 cumplen con los estándares UDL y WCAG 2.1 AA, garantizando un acceso digital equitativo, accesible y compatible con lectores de pantalla.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Clínicas Obligatorias: Osteoporosis, Densidad Ósea y Prevención de Caídas


### Texto Fuente SSoT y Lineamientos Federales

Fuente Única de Verdad (SSoT): Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) • Capítulo 2 (Fundamentos), Capítulo 5 (Adultos Mayores Activos) y Capítulo 6 (Condiciones Crónicas).

Herramienta Interactiva PAGA 2018 ("PAGA" en el Menú Izquierdo del Curso • paga2018.dev)

- Fundación de Salud Ósea y Osteoporosis (BHOF): Guía Clínica de BHOF para Prevención y Tratamiento
- Marco Clínico de Prevención de Caídas STEADI del CDC: CDC STEADI: Prevención de Accidentes y Caídas en Adultos Mayores

### Conceptos Clínicos Centrales


#### Step 1: Ley de Wolff y Puntuación T en DXA

La remodelación ósea responde a la carga mecánica axial y la tensión muscular. Las puntuaciones T de DXA clasifican el estado óseo: Normal (T ≥ -1.0 DE), Osteopenia (-1.0 a -2.5 DE) y Osteoporosis (T ≤ -2.5 DE), exigiendo adaptaciones específicas de seguridad.


#### Step 2: Contraindicaciones Biomecánicas Absolutas en Osteoporosis

En pacientes con osteoporosis se debe prohibir estrictamente la flexión anterior de tronco con carga (abdominales tradicionales), la torsión espinal dinámica (giros con peso) y la pliometría de alto impacto para prevenir fracturas vertebrales en cuña.


### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen con los estándares WCAG 2.1 AA para asegurar un entorno de aprendizaje inclusivo, equitativo y accesible para toda nuestra comunidad estudiantil.

KIN-265 • Module 03 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 03:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
