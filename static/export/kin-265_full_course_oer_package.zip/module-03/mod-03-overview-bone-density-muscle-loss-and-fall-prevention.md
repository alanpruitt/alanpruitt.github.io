# KIN-265: Mod 03 Overview Bone Density Muscle Loss And Fall Prevention

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise Programming for Special Populations / Programación de Ejercicio para Poblaciones Especiales


## Mod 03 Overview: Bone Density, Muscle Loss & Fall Prevention


### Welcome to Module 03: Bone Density, Muscle Loss & Fall Prevention

Welcome to Module 03! This week, we examine the clinical biomechanics and physiology of osteopenia, osteoporosis, and age-related sarcopenia . By applying Wolff's Law (bone remodels in response to site-specific mechanical strain) alongside federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed., Older Adult Chapter) , you will learn how to stimulate osteoblast bone formation and preserve fast-twitch motor units without exceeding vertebral fracture thresholds.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will stratify DXA T-score and Timed Up and Go (TUG) fall risk patterns, enforce the strict spinal safety gate ( zero weighted spinal flexion or rapid end-range twisting in osteoporosis), and design multicomponent balance + resistance prescriptions for older adults in Yuma County.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday at 11:59 PM MST
- Coaching Sprint & Lab Simulations / Entrega de Simulaciones de Sprint y Laboratorio: Monday at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de Aprendizaje

- CLO 1 (Pattern Recognition): Stratify bone mineral density via WHO DXA T-scores (Normal ≥ −1.0, Osteopenia −1.0 to −2.4, Osteoporosis ≤ −2.5) and evaluate sarcopenia and fall risk (TUG ≥ 12 seconds).
- CLO 2 (Rule Application): Apply PAGA 2018 (2nd Ed.) multicomponent older adult standards (aerobic + muscle-strengthening + ≥3 days/week balance training) and enforce the strict contraindication against weighted spinal flexion.
- CLO 3 (Problem Solving): Prescribe a neutral-spine osteogenic resistance and fall-prevention program defended in your own clinical voice.

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 03 (Mod 03 Overview: Bone Density, Muscle Loss & Fall Prevention)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Módulo 03 Visión General: Densidad Ósea, Pérdida Muscular y Prevención de Caídas

¡Bienvenido al Módulo 03! Esta semana aplicamos la Ley de Wolff y las pautas federales de PAGA 2018 (2.ª ed.) para diseñar programas multicomponente que fortalezcan la densidad mineral ósea (puntajes T de DXA) y prevengan fracturas vertebrales evitando estrictamente la flexión espinal con carga.


### Module 03 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 03 Required Readings: Bone Density, Muscle Loss & Fall Prevention →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 03 Discussion: Protecting Bone Density & Muscle as We Age →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 03 Coaching Sprint: Spine-Safe Movements & Fall Prevention →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 03 Lab: Bone-Building & Fall-Safe Exercise Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 03 Summary & Wrap-Up: Bone Density, Muscle Loss & Fall Prevention →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
