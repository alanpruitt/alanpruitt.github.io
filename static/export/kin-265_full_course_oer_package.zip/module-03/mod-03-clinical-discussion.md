# KIN-265: Mod 03 Clinical Discussion

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise Programming for Special Populations / Programación de Ejercicio para Poblaciones Especiales


## Mod 03 Discussion: Protecting Bone Density & Muscle as We Age

Foro de Discusión del Módulo 03: Protección de la Densidad Ósea, Sarcopenia y Prevención de Caídas


### Musculoskeletal Integrity, Wolff's Law Bone Loading, & PAGA 2018 Mandates

Prescribing exercise for individuals managing osteoporosis (DXA T-score ≤ −2.5) and age-related sarcopenia requires precise clinical auditing. Standard resistance and multicomponent training targets must stimulate osteoblast bone remodeling (Wolff's Law) while strictly avoiding anterior vertebral compression forces (weighted spinal flexion) and fall hazards.

En esta discusión, auditará cómo las normas federales de la PAGA 2018 (2.ª ed.) guían la carga osteogénica, la preservación muscular y la prevención de caídas mientras se evita estrictamente la flexión espinal con carga.


### Phase 1: Select Your Clinical Simulation Case File #265-03


### Phase 2: Gemini AI Clinical Simulation Consultation / Espacio de Simulación con IA


### Discussion Tasks (Initial Post Due Thursday 11:59 PM MST • Peer Reply Due Sunday 11:59 PM MST)

- Step 1: Pattern Recognition: Stratify the client's DXA T-score (Osteopenia vs. Osteoporosis), sarcopenia presentation, and vertebral compression or fall risk.
- Step 2: Rule Application (PAGA 2018 & Spinal Gate): Cite the PAGA 2018 multicomponent older adult mandate (aerobic + resistance + balance ≥3 days/week) and explain why weighted spinal flexion (sit-ups/toe touches) is strictly contraindicated.
- Step 3: Solve & Bilingual Takeaway: Propose a neutral-spine osteogenic resistance and progressive balance prescription, plus a 1-sentence takeaway in English and Spanish.
- Peer Engagement: Reply to at least ONE (1) classmate by Sunday 11:59 PM MST auditing their spinal alignment and fall-prevention safety gate.

### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Track 1 (Clinical Path — Patient M.L., Age 72, Lumbar T-Score −2.8):

- Pattern: M.L. has WHO-classified osteoporosis (T-score −2.8 ≤ −2.5) at the lumbar spine alongside sarcopenic quadriceps weakness and elevated fall risk (TUG = 14.2 sec > 12 sec threshold). Performing weighted sit-ups would concentrate anterior compressive shear on her porous vertebral bodies, risking an acute wedge compression fracture.
- Rule (PAGA 2018 & Wolff's Law): Under PAGA 2018 (2nd Ed.), older adults require multicomponent physical activity combining moderate aerobic work, progressive muscle-strengthening (≥2 days/week), and balance training (≥3 days/week). Clinical bone-loading safety gates mandate strict neutral-spine posture and forbid weighted spinal flexion or rapid end-range trunk rotation.
- Solve & Bilingual Summary: Replace sit-ups with neutral-spine isometric bird-dogs/wall planks, chair-supported sit-to-stands, resistance-band rows (retracting scapulae to counter thoracic kyphosis), and daily tandem-stance balance progressions. EN: "Neutral-spine resistance training and daily balance drills stimulate bone density via Wolff's Law while protecting osteoporotic vertebrae from compression fractures!" ES: "¡El entrenamiento de fuerza con columna neutra y el equilibrio diario estimulan la densidad ósea según la Ley de Wolff mientras protegen las vértebras de fracturas por compresión!"

### Interactive Clinical Simulation & Outcome Gate (Module 03) / Simulación Clínica y Dominio de Resultados (Módulo 03)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 03 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 03 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 03 (Mod 03 Discussion: Protecting Bone Density & Muscle as We Age)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


## Foro de Discusión del Módulo 03: Densidad Ósea, Sarcopenia y Prevención de Caídas

Analice su caso bajo el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) : estratifique el puntaje T de DXA, aplique las normas multicomponente de PAGA 2018 prohibiendo la flexión espinal con carga, y proponga ejercicios de fuerza con columna neutra y equilibrio progresivo. Responda al menos a UN (1) compañero antes del domingo a las 11:59 PM MST.

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) • Matador Wellness Center • Arizona Western College.

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.

KIN-265 • Module 03 Quick Return Navigation / Regreso Rápido al Módulo 03:
