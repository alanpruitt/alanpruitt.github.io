# KIN-265: Mod 12 Required Readings Arthritis Joint Stiffness And Bone Safe Exercise

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 12 Required Readings: Arthritis, Joint Stiffness & Bone-Safe Exercise

As you read below, follow our three-step Golden Circle clinical progression: start with Ring 1: THE WHY (diagnosing the client and Yuma environmental Pattern ), move to Ring 2: THE HOW (applying the federal Rule from PAGA 2018 (2nd Ed., Chapters 5 & 6) & ACSM 12th Ed.), and finish with Ring 3: THE WHAT (formulating your verified Solve in the Coaching Sprint and Lab).

Lente de Lectura del Círculo Dorado (Módulo 12): Sigue las tres etapas mientras lees: Step 1: EL PORQUÉ (Patrón) → Step 2: EL CÓMO (Regla federal) → Step 3: EL QUÉ (Solución práctica) .

How to Use This Page / Cómo Usar Esta Lectura: Read the 3 short clinical sections below and click each 30-Second Quick Rule Check accordion to test the exact SSoT numbers you will need in this week's Coaching Sprint and Lab. (Lea las 3 secciones y abra cada Autoevaluación Rápida de 30 Segundos para confirmar las reglas exactas que usará en el Sprint y el Laboratorio.)


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Osteoarthritis and rheumatoid arthritis cause joint cartilage wear or autoimmune inflammation, leading to morning stiffness and movement pain. Extended warm-ups, pain-free range-of-motion drills, and low-impact strengthening lubricate joints with synovial fluid and build shock-absorbing muscle. Applying the Two-Hour Pain Rule tells you immediately if yesterday's workout volume was too high.


#### En Palabras Sencillas (Norteño Context)

Una articulación con artritis es como una bisagra reseca por el polvo del desierto: primero se mueve suave para lubricarla antes de ponerle carga. Si los términos técnicos se ponen pesados, concéntrate primero en la Regla del Dolor de Dos Horas y cómo reducir la carga durante un brote inflamatorio agudo.


### Core Literature & Federal Standards (SSoT)

To successfully complete Module 12 workflows, discussions, and laboratory assignments, review the core readings below. All instructional materials are anchored strictly in our Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .

Review the reading summaries below to understand how low-impact exercise protects arthritic joints, how bone loading prevents osteoporosis, and how environmental factors in Yuma affect musculoskeletal comfort.


### Reading 1: PAGA 2018 (2nd Ed.) • Joint Health and Arthritis Management Through Exercise

Learn how low-impact movement and muscle strengthening reduce pain and improve function in osteoarthritis. Regular physical activity helps lubricate joint cartilage, strengthens supporting periarticular muscles, and reduces systemic low-grade inflammation. PAGA 2018 guidelines emphasize that appropriate low-impact aerobic and strengthening activities do not accelerate cartilage degradation; rather, they improve mobility and decrease joint loading stress in arthritic populations.

Lectura 1: PAGA 2018 (2.ª ed.) • Salud articular y manejo de la artritis mediante el ejercicio: Aprenda cómo el movimiento de bajo impacto y el fortalecimiento muscular reducen el dolor y mejoran la función en la osteoartritis.


### Reading 2: Clinical Guidelines & Bone Loading Protocols for Osteoporosis

Examine weight-bearing exercise rules and fall prevention strategies for bone mineral density preservation. Bone remodeling responds directly to mechanical loading (Wolff's Law). Trainers must prescribe progressive resistance training and weight-bearing aerobic activities while strictly avoiding high-risk spinal flexion and rapid twisting movements for clients diagnosed with osteoporosis or osteopenia to prevent vertebral compression fractures.

Lectura 2: Pautas clínicas • Protocolos de carga ósea para la osteoporosis: Examine las reglas de ejercicio con peso y las estrategias de prevención de caídas para preservar la densidad mineral ósea.


### Reading 3: Environmental Physiology & Musculoskeletal Comfort in Yuma

Analyze how seasonal barometric pressure changes and desert heat impact arthritic joint stiffness. Older adults in Yuma frequently report increased joint discomfort during seasonal shifts and extreme temperature fluctuations. Indoor climate-controlled exercise facilities (72°F / 22°C) provide a stable thermal and humidity environment that minimizes arthritic stiffness and enhances exercise adherence.

Lectura 3: Fisiología ambiental • Comodidad musculoesquelética en el clima de Yuma: Analice cómo los cambios de presión barométrica y el calor del desierto impactan la rigidez de las articulaciones artríticas.

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 12 (Mod 12 Required Readings: Arthritis, Joint Stiffness & Bone-Safe Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading texts in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los textos de lectura obligatoria en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Obligatorias del Módulo 12: Mecánica Articular y Densidad Mineral Ósea


### Literatura Principal y Normas Federales (SSoT)

Para completar con éxito las actividades del Módulo 12, revise los resúmenes de lectura a continuación, anclados en nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) .

Revise los puntos clave sobre la salud articular, la carga ósea para la osteoporosis y el confort en el clima de Yuma.


### Lectura 1: PAGA 2018 (2.ª ed.) • Salud articular y manejo de la artritis mediante el ejercicio

Aprenda cómo el movimiento de bajo impacto reduce el dolor en la osteoartritis. Las pautas de PAGA 2018 enfatizan que el ejercicio adecuado mejora la movilidad sin degradar el cartílago.


### Lectura 2: Pautas clínicas • Protocolos de carga ósea para la osteoporosis

Examine las reglas de ejercicio con peso para preservar la densidad ósea. Se debe evitar la flexión espinal extrema y las torsiones rápidas para prevenir fracturas por compresión.


### Lectura 3: Fisiología ambiental • Comodidad musculoesquelética en el clima de Yuma

Analice cómo los cambios de presión barométrica impactan la rigidez articular. Las instalaciones climatizadas (22°C) ayudan a mantener un entorno estable para el ejercicio.

KIN-265 • Module 12 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 12:

This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
