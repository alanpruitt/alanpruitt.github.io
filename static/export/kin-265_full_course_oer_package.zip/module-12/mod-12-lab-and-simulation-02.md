# KIN-265: Mod 12 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 12 Lab & Simulation: Arthritis & Bone-Safe Exercise Plan Audit

- The Two-Hour Joint Pain Rule (Osteoarthritis & Rheumatoid Arthritis): If joint pain is worse 2 hours after exercising than it was before starting, the session volume or impact was too high and must be scaled back at the next session. En palabras sencillas: La Regla de las Dos Horas: si a las 2 horas de terminar duele más la articulación que antes de empezar, bajamos la carga o duración en la siguiente sesión.
- Acute Inflammatory Flare Gate (Gentle ROM Only): During an acute rheumatoid or osteoarthritic flare (hot, red, swollen joint), avoid heavy resistance or high-impact loading and perform only gentle, pain-free range-of-motion movements. En palabras sencillas: Cuando una articulación amanece caliente, inflamada o en brote agudo, no se le mete peso; solo se mueve suave sin dolor.
- Osteoporosis Spine-Sparing Mechanics & Fall Prevention: Replacing spinal flexion/twisting with neutral-spine hip hinges, posture extensors, weight-bearing walking, and daily balance training. En palabras sencillas: Proteger la columna evitando encorvarse o girar brusco con peso, fortaleciendo espalda, cadera y equilibrio para prevenir caídas.

### Lab Overview: Musculoskeletal Risk Audit & PAGA 2018 Prescription Formulation

In this laboratory practical, you will execute a comprehensive musculoskeletal risk audit and formulate an evidence-based exercise prescription for a client presenting with osteoarthritis, osteoporosis, or degenerative disc disease.

You will apply the Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in federal standards ( PAGA 2018 ) and use the Gemini AI Tool Kit with secure triple-hash delimiters (###) to audit your clinical safety.


### Lab Logistics & Deadlines / Logística y Fechas Límite

- Due Date / Fecha Límite: Monday, November 9, 2026, at 11:59 PM MST / Lunes 9 de noviembre de 2026 a las 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry / Entrada de texto directa en Canvas
- Points / Puntos: 100 Total Points (Exemplary / Competent / Recalibrate Rubric)
Lab 9-Box Command Center Consult ([WHAT] Ring 3 • "Toolkit" in Course Navigation • Open 9-Box Command Center (exwtoolkit.com) ): In your Coaching Sprint ( [HOW] ) , you calibrated a single-rule /simulators/* micro-widget. Now in this Lab Assignment ( [WHAT] ) , use the full 9-Box Command Center along the workflow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") to synthesize your complete 4-part clinical consult (verify all outputs against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards ).

PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case to cross-check federal guidelines and build your Pattern / Rule / Solve audit.

Centro de Comando de 9 Cajas para el Laboratorio ([WHAT] Anillo 3 • "Toolkit" y "PAGA"): Después de calibrar el micro-simulador en su Sprint, use el Centro de Comando de 9 Cajas en "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) y "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para respaldar su entrega completa de 4 partes verificando cada dato contra la Fuente de Verdad.


### Part A: Choose Your Career Track & Clinical Case File / Seleccione su Ruta y Caso Clínico

Client: 64-year-old female with bilateral knee osteoarthritis and chronic joint pain (4/10). Prescribe a low-impact functional conditioning routine. Cliente: Mujer de 64 años con osteoartritis bilateral de rodilla y dolor articular (4/10). Prescriba rutina de bajo impacto.

Client: 72-year-old male with osteoporosis (T-score -2.6) and mild balance impairment. Formulate a weight-bearing bone-loading and balance routine. Cliente: Varón de 72 años con osteoporosis (T-score -2.6) y equilibrio alterado. Formule rutina de carga ósea y equilibrio.

Client: 46-year-old military veteran and heavy-labor instructor with degenerative disc disease. Design a spine-sparing core stabilization protocol. Cliente: Instructor militar de 46 años con discopatía degenerativa. Diseñe un protocolo de estabilización central.


### Part B: Clinical Framing Protocol (Pattern

Rule / Solve) Clinical Audit / Auditoría del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Pattern Recognition / Reconocimiento de Patrones: Identify all joint limitations, bone density deficits, and orthopedic contraindications. Identifique limitaciones articulares, déficit de densidad ósea y contraindicaciones ortopédicas.
- Rule Application / Aplicación de Reglas: Apply PAGA 2018 musculoskeletal parameters, joint pain monitoring thresholds (pain < 3/10), and bone-loading rules. Aplique parámetros musculoesqueléticos de PAGA 2018, umbrales de dolor y reglas de carga ósea.
- Problem Solving / Resolución de Problemas: Formulate a 3-phase Frequency, Intensity, Time, Type (FITT) prescription and orthopedic safety monitoring plan. Formule una prescripción FITT de 3 fases y un plan de monitoreo de seguridad ortopédica.

### Part C: Gemini AI Tool Kit & Safety Auditor Protocol


```text
Safety Auditor Protocol: KIN-265 Module 12 Lab ###:
Role: Clinical Exercise Physiologist and Musculoskeletal Safety Auditor.
SSoT: Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.).

Instructions:
Step 1: Audit the student's musculoskeletal case audit and FITT prescription.
Step 2: Evaluate adherence to PAGA 2018 standards, pain monitoring, and bone loading parameters.
Step 3: Verify secure delimiter usage (###).

Client Data Input ###:
Career Track: [Insert Track 1, 2, or 3]
Client Case Summary: [Insert summary]
Student Clinical Framing Protocol (Pattern / Rule / Solve) Analysis: [Insert student analysis]
Student FITT Prescription: [Insert prescription]
End Client Data ###:
End Safety Auditor Protocol ###:
```


### Submission Template / Plantilla de Entrega


```text
KIN-265 Module 12 Lab Submission ###:
Selected Career Track: [Track 1: Clinical | Track 2: Community | Track 3: Tactical]

Step 1: Pattern Recognition (Musculoskeletal Risk Audit):
Key Point: Client Profile & Joint/Bone Baselines (Pain Scale, T-score, Spine Strain):
Key Point: Absolute/Relative Contraindications Identified:

Step 2: Rule Application (PAGA 2018 Standards):
Key Point: FITT Neuromuscular & Loading Parameters:
Key Point: Intensity Monitoring (Pain Scale Thresholds & Fall Prevention):

Step 3: Problem Solving (Prescription & Safety Plan):
Key Point: 3-Phase Prescription:
Key Point: Joint-Sparing Modifications & Emergency Stop Limits:

Step 4: AI Tool Kit Audit Reflection:
Key Point: Summary of Gemini AI Safety Auditor feedback and delimiter compliance:
End Submission ###:
```

10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric / Rúbrica de Calificación (100 Points Total)

Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 12 (Mod 12 Lab: Arthritis & Bone-Safe Exercise Plan Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 12 Lab: Prescripción de Ejercicio Neuromuscular y Auditoría


### Visión General del Laboratorio: Auditoría de Riesgo Musculoesquelético y PAGA 2018

En esta práctica de laboratorio, ejecutarás una auditoría integral de riesgo musculoesquelético y formularás una prescripción de ejercicio basada en evidencia para un cliente con osteoartritis, osteoporosis o discopatía.

Aplicarás el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) anclado en normas federales ( PAGA 2018 ) y usarás la Caja de Herramientas Gemini con delimitadores seguros (###).


### Logística de Laboratorio y Fechas Límite

- Fecha Límite: Lunes 9 de noviembre de 2026 a las 11:59 PM MST
- Formato: Entrada de texto directa en Canvas
- Puntaje: 100 Puntos Totales (Exemplary / Competent / Recalibrate)
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Parte A: Seleccione su Ruta y Caso Clínico

Elija la ruta profesional correspondiente a su enfoque:

Mujer de 64 años con osteoartritis bilateral de rodilla y dolor articular (4/10). Prescriba rutina de bajo impacto.

Varón de 72 años con osteoporosis (T-score -2.6) y equilibrio alterado. Formule rutina de carga ósea y equilibrio.

Instructor militar de 46 años con discopatía degenerativa. Diseñe un protocolo de estabilización central.


### Parte B: Auditoría del Protocolo de Encuadre Clínico (Patrón / Regla / Solución)

- Reconocimiento de Patrones: Identifique limitaciones articulares, déficit de densidad ósea y contraindicaciones ortopédicas.
- Aplicación de Reglas: Aplique parámetros musculoesqueléticos de PAGA 2018, umbrales de dolor y reglas de carga ósea.
- Resolución de Problemas: Formule una prescripción FITT de 3 fases y un plan de monitoreo de seguridad ortopédica.

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales de KIN-265 cumplen estrictamente con los estándares WCAG 2.1 AA para garantizar la inclusión y el acceso equitativo en toda nuestra comunidad estudiantil.

KIN-265 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
