# KIN-265: Mod 12 Lab And Simulation 01

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---


## Mod 12 Coaching Sprint Simulation: Modifying Exercises for Pain-Free Joints

Sesión de Coaching del Módulo 12: Salud Musculoesquelética y Seguridad Articular

- The Two-Hour Joint Pain Rule (Osteoarthritis & Rheumatoid Arthritis): If joint pain is worse 2 hours after exercising than it was before starting, the session volume or impact was too high and must be scaled back at the next session. En palabras sencillas: La Regla de las Dos Horas: si a las 2 horas de terminar duele más la articulación que antes de empezar, bajamos la carga o duración en la siguiente sesión.
- Acute Inflammatory Flare Gate (Gentle ROM Only): During an acute rheumatoid or osteoarthritic flare (hot, red, swollen joint), avoid heavy resistance or high-impact loading and perform only gentle, pain-free range-of-motion movements. En palabras sencillas: Cuando una articulación amanece caliente, inflamada o en brote agudo, no se le mete peso; solo se mueve suave sin dolor.
- Osteoporosis Spine-Sparing Mechanics & Fall Prevention: Replacing spinal flexion/twisting with neutral-spine hip hinges, posture extensors, weight-bearing walking, and daily balance training. En palabras sencillas: Proteger la columna evitando encorvarse o girar brusco con peso, fortaleciendo espalda, cadera y equilibrio para prevenir caídas.
- KIN-265.12.1.AY26-27: Prescribe safe low-impact and weight-bearing exercise intensity for clients with arthritis or osteoporosis across diverse career tracks. Prescribir intensidad de ejercicio seguro de bajo impacto y con peso para clientes con artritis u osteoporosis en diversas rutas profesionales.
- KIN-265.12.2.AY26-27: Audit clinical pain scale limits and apply delimiter-based AI verification protocols. Auditar límites clínicos de la escala de dolor y aplicar protocolos de verificación de IA basados en delimitadores.

### Your Weekly Win: Mastering Joint-Sparing Rules & Bone Loading Protocols

How can fitness professionals safely monitor exercise intensity when a client is managing osteoarthritis or osteoporosis? Because standard metrics do not capture joint stress, exercise specialists use pain monitoring scales (e.g., keeping joint pain below 3/10) and Wolfe's Law bone-loading parameters. Following strict PAGA 2018 clinical guidelines, trainers protect arthritic joints and prevent vertebral compression fractures. Choose one of the three coaching tracks below, chat with your AI Socratic Coach using mandatory triple-hash delimiters (`###`), and master musculoskeletal safety auditing!

¿Cómo pueden los profesionales monitorear el ejercicio cuando un cliente padece osteoartritis u osteoporosis? Usando escalas de dolor y parámetros de carga ósea de PAGA 2018. ¡Elija una de las tres rutas, dialogue con su coach de IA y domine la auditoría musculoesquelética!

Coaching Sprint Rule Calibrator ([HOW] Ring 2 • Embedded Micro-Widget: Joint-Safe Multicomponent & Osteoarthritis ROM Auditor (/simulators/fall-risk-auditor) ): In this Coaching Sprint ( [HOW] ) , use the focused interactive simulator below to test a single safety Rule before running your full 9-Box consult in the Lab Assignment. Calibrate >=3 days/week balance, >=2 days/week low-load joint-friendly strength, and 150 min/week low-impact aerobic activity while enforcing the 2-Hour Joint Pain Rule (PAGA 2018 Ch. 5 & 6). Copy your VERIFIED simulator receipt or slider values into the submission template below • Paired Biomechanical Joint-Load & Pain-Free ROM route: /simulators/joint-load-auditor .

Open Joint-Safe Multicomponent & Osteoarthritis ROM Auditor in Full Browser Tab Companion OER Lookup ("PAGA" in Course Navigation): Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale)

Accessibility & SSoT Verification Note: All sliders support keyboard arrow keys ( Tab + Left/Right ). Always verify simulator calculations against Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018) and ACSM Clinical Standards .

Simulador Rápido del Sprint ([HOW] Anillo 2 • exwtoolkit.com/simulators/fall-risk-auditor y "PAGA"): Calibre >=3 días/semana de equilibrio, >=2 días/semana de fuerza amigable con las articulaciones y 150 min/semana aeróbicos de bajo impacto respetando la Regla del Dolor de 2 Horas (PAGA 2018 Cap. 5 y 6). Copie su recibo VERIFIED en la plantilla de entrega y consulte "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para verificar cada cifra contra la Fuente de Verdad.


### Phase 1: Pick Your Clinical Simulation Track (Select ONE Case Profile)

Fase 1: Elija una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient clinical rehabilitation client with bilateral knee osteoarthritis managing joint pain and stiffness; establishing low-impact aquatic or cycling progression.

Scenario: Senior community center participant with osteoporosis and mild balance impairment; formulating a safe weight-bearing walking and fall-prevention routine.

Scenario: Military veteran and heavy-labor instructor with cumulative lumbar spine strain and degenerative disc disease; designing an ergonomic core stability and unloading framework.


### Phase 2: Gemini AI Clinical Simulation Workspace

Paso 2: Copie la plantilla y consulte a Gemini para obtener su aprendizaje clave

Paste your chosen client profile data wrapped in triple-hashes into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission

Escriba o pegue sus respuestas directamente en el cuadro de texto de Canvas

- Selected Track & Client Name: State your chosen career track and client profile (Brenda, Harold, or Sergeant Vance).
- Musculoskeletal Analysis: Explain the key joint limitation or bone loading consideration for your selected client.
- My Safety Audit: Provide 1 clear, evidence-based safety parameter or exercise prescription adjustment utilizing the Safety Auditor protocol.
- My Memorable Coaching Takeaway: Write your favorite memorable takeaway sentence in English and Spanish.
- Repository Verification: Confirm export to EXW_Professional_AI_Repository .
10 / 10 Pre-Flight Check Before You Click Submit (Check All 4 Boxes / Verifique los 4 Puntos):


### Grading Rubric (10/7/0 Mastery Scale • Low-Stakes Coaching Win)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 12 Coaching Sprint • Track 1 (Brenda)

- Selected Track & Client Name: Track 1: Clinical Rehabilitation • Brenda (Age 64).
- Musculoskeletal Analysis: Brenda has bilateral knee osteoarthritis causing joint pain and stiffness. Because high-impact loading increases joint shear stress, we use low-impact aquatic or stationary cycling exercise and keep joint pain below 3/10.
- My Safety Audit for Brenda: "Monitor Brenda's joint discomfort using the pain scale, ensuring pain does not exceed 3/10 during exercise, and modify range of motion or reduce resistance immediately if sharp pain occurs per PAGA 2018 guidelines."
- "Monitor Brenda's joint discomfort using the pain scale, ensuring pain does not exceed 3/10 during exercise, and modify range of motion or reduce resistance immediately if sharp pain occurs per PAGA 2018 guidelines."
- My Memorable Coaching Takeaway: EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!" "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!"
- "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- Repository Verification: AI Diagnostic Chat exported and archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M12_Quiz_Sprint.pdf
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 12 (Mod 12 Coaching Sprint: Modifying Exercises for Pain-Free Joints)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 12 Simulación de Coaching: Salud Musculoesquelética y Seguridad Articular

Evaluación Rápida y Auditoría de Seguridad Musculoesquelética


### Su Logro Semanal: Dominando las Reglas Articulares y la Carga Ósea

Esta sesión le permitirá aplicar las directrices de PAGA 2018 para usar escalas de dolor y parámetros de carga ósea en pacientes con artritis u osteoporosis. ¡Elija una de las tres rutas, dialogue con su coach de IA y obtenga una lección memorable!


### Fase 1: Selección de Escenario de Simulación Clínica (Seleccione UN perfil)

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente de rehabilitación clínica con osteoartritis bilateral de rodilla y dolor articular; establecer una progresión acuática o de ciclismo de bajo impacto.

Escenario: Participante senior con osteoporosis y equilibrio levemente alterado; formular una rutina segura de caminata con peso y prevención de caídas.

Escenario: Veterano e instructor con tensión lumbar crónica y discopatía degenerativa; diseñar estabilidad central y marco ergonómico.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (Brenda, Harold o Sergeant Vance).
- Análisis Musculoesquelético: Explique la consideración clave articular u ósea para su cliente.
- Mi Auditoría de Seguridad: Escriba 1 parámetro de seguridad claro o ajuste de prescripción usando la escala de dolor.
- Mi Frase Inolvidable de Coaching: Escriba su aprendizaje clave en inglés y en español.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio Exemplary / Competent / Recalibrate)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265, Módulo 12, Sesión de Coaching • Ruta 1 (Brenda)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • Brenda (64 años).
- Análisis Musculoesquelético: Brenda tiene osteoartritis bilateral de rodilla. Como el impacto elevado aumenta la tensión articular, usamos ejercicio acuático o bicicleta estática y mantenemos el dolor por debajo de 3/10.
- Mi Auditoría de Seguridad para Brenda: "Monitorear la incomodidad articular de Brenda usando la escala de dolor, asegurando que no exceda 3/10 durante el ejercicio, y modificar el rango de movimiento si ocurre dolor agudo según PAGA 2018."
- "Monitorear la incomodidad articular de Brenda usando la escala de dolor, asegurando que no exceda 3/10 durante el ejercicio, y modificar el rango de movimiento si ocurre dolor agudo según PAGA 2018."
- Mi Frase Inolvidable de Coaching: EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!" "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- EN: "Protecting your joints with low-impact movement keeps you strong, mobile, and pain-free!"
- "¡Proteger tus articulaciones con movimiento de bajo impacto te mantiene fuerte, móvil y libre de dolor!"
- Verificación del Repositorio: Registro guardado en Google Drive: EXW_Professional_AI_Repository / EXW_265_M12_Quiz_Sprint.pdf
KIN-265 • Module 12 Quick Return Navigation / Regreso Rápido al Módulo 12:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
