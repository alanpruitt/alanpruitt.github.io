# KIN-265: Mod 12 Overview Arthritis Joint Stiffness And Bone Safe Exercise

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 12 Overview: Arthritis, Joint Stiffness & Bone-Safe Exercise

El Porqué del Módulo 12 (Círculo Dorado — Contexto Norteño): “¿Por qué dejar de moverse vuelve más rígidas las articulaciones con artritis y debilita el hueso, y cómo el movimiento de bajo impacto funciona como medicina diaria?”


### Module 12 Golden Circle Roadmap (`THE WHY` → `THE HOW` → `THE WHAT`) / Ruta del Círculo Dorado


### Welcome to Module 12: Arthritis, Joint Stiffness & Bone-Safe Exercise

Welcome to Week 12! Building upon our metabolic auditing framework, this week we examine Arthritis, Joint Stiffness & Bone-Safe Exercise . Osteoarthritis, rheumatoid arthritis, and osteoporosis present unique physiological barriers to exercise, primarily through joint pain, inflammation, cartilage degradation, and bone mineral density loss.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) (Pattern / Rule / Solve) framework, you will identify musculoskeletal compromise patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) joint-loading and resistance thresholds, and design safe physical activity interventions.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, November 3, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, November 5, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, November 8, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, November 9, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 12 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze joint mechanics, cartilage degeneration, and bone mineral density loss associated with arthritis and osteoporosis. Analizar la mecánica articular, la degradación del cartílago y la pérdida de densidad mineral ósea.
- CLO 2 (Rule Application): Apply PAGA 2018 musculoskeletal standards, joint-loading rules, and pain-monitoring parameters. Aplicar normas musculoesqueléticas de PAGA 2018 y parámetros de monitoreo del dolor.
- CLO 3 (Problem Solving): Formulate an evidence-based neuromuscular prescription integrating low-impact aerobic conditioning and weight-bearing exercise. Formular una prescripción neuromuscular integrando acondicionamiento aeróbico de bajo impacto y ejercicio con peso.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will work within your chosen career track:

Managing physical therapy and joint-sparing functional conditioning for patients with advanced knee and hip osteoarthritis.

Designing community-based balance and weight-bearing exercise classes for older adults managing osteoporosis in Yuma.

Screening tactical personnel and heavy-labor workers for cumulative joint trauma and designing ergonomic mitigation protocols.


### Module 12 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Joint Mechanics, Bone Mineral Density & PAGA 2018 Standards
- Discussion Board: Arthritis Pain Management, Osteoporosis Loading & Safety
- Coaching Sprint: Applied Clinical Reasoning & Practical Coaching Drills
- Lab Assignment: Neuromuscular Exercise Prescription Audit & Gemini AI Tool Kit
- Summary & Wrap-Up: Knowledge Check & Transition to Module 13
Live Yuma Heat Safety & OER Verification: Check hourly NWS KNYL / KYNL (MCAS Yuma) Outdoor Activity Color Flags at the top of Toolkit (exwtoolkit.com) (click ? for User Guide; Light/Dark mode in toolbar) and verify all guidelines in PAGA (paga2018.dev) .

Seguridad de Calor en Yuma y Verificación: Consulte el clima por hora de NWS KNYL / KYNL (MCAS Yuma) y sus banderas de color arriba en Toolkit y verifique cada regla en PAGA .

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 12 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 12 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 12 (Mod 12 Overview: Arthritis, Joint Stiffness & Bone-Safe Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 12 Visión General: Patologías Neuromusculares y Musculoesqueléticas


### Bienvenido al Módulo 12: Artritis, Osteoporosis y Salud Articular

¡Bienvenido a la Semana 12! Basándonos en nuestro marco metabólico, esta semana examinamos las Patologías Neuromusculares y Musculoesqueléticas y la Prescripción de Ejercicio . La osteoartritis, la artritis reumatoide y la osteoporosis presentan barreras fisiológicas debido al dolor articular y la pérdida de densidad ósea.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) (Patrón / Regla / Solución) , identificarás patrones de compromiso articular, aplicarás las normas de PAGA 2018 y diseñarás intervenciones neuromusculares seguras.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar la mecánica articular, el cartílago y la pérdida ósea en artritis y osteoporosis.
- CLO 2 (Regla): Aplicar normas musculoesqueléticas de PAGA 2018 y parámetros de monitoreo del dolor.
- CLO 3 (Solución): Formular una prescripción neuromuscular integrando acondicionamiento aeróbico y ejercicio con peso.

### Construya su Propio Camino • Vista previa de las 3 rutas

En las actividades de este módulo, trabajará dentro de la ruta seleccionada:

Manejo de fisioterapia y acondicionamiento funcional para pacientes con osteoartritis avanzada de rodilla y cadera.

Diseño de clases comunitarias de equilibrio y ejercicio con peso para adultos mayores con osteoporosis en Yuma.

Tamizaje de personal táctico y trabajadores para trauma articular acumulativo y diseño de protocolos ergonómicos.


### Ruta de Aprendizaje del Módulo 12

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Mecánica Articular, Densidad Ósea y PAGA 2018
- Foro de Discusión: Dolor de Artritis, Carga Ósea y Seguridad
- Sprint de Entrenamiento: Razonamiento Clínico Aplicado y Práctica
- Práctica de Laboratorio: Auditoría Neuromuscular y Caja de Herramientas
- Comprobación de Conocimientos y Transición al Módulo 13

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 12 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 12 Required Readings: Arthritis, Joint Stiffness & Bone-Safe Exercise →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 12 Discussion: Exercising Safely with Arthritis & Joint Stiffness →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 12 Coaching Sprint: Modifying Exercises for Pain-Free Joints →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 12 Lab: Arthritis & Bone-Safe Exercise Plan Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 12 Summary & Wrap-Up: Arthritis, Joint Stiffness & Bone-Safe Exercise →
This curriculum is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Arizona Western College, para fines no comerciales y bajo la misma licencia.
