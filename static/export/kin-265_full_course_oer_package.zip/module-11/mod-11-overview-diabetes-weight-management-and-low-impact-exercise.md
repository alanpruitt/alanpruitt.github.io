# KIN-265: Mod 11 Overview Diabetes Weight Management And Low Impact Exercise

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 11 Overview: Diabetes, Weight Management & Low-Impact Exercise


### Welcome to Module 11: Diabetes, Weight Management & Low-Impact Exercise

Welcome to Week 11! Building upon our pulmonary auditing framework, this week we examine Diabetes, Weight Management & Low-Impact Exercise . Type 1 and Type 2 diabetes mellitus, metabolic syndrome, and obesity present unique physiological barriers to exercise, primarily through impaired glycemic regulation, insulin resistance, and cardiovascular comorbidities.

Using our Clinical Framing Protocol (Pattern / Rule / Solve) framework, you will identify metabolic compromise patterns, apply federal Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) metabolic thresholds, and design safe blood glucose monitoring and caloric expenditure interventions.


### Weekly Schedule & Deadlines / Horario Semanal y Fechas Límite

- Module Opens / Apertura: Tuesday, October 27, 2026, at 12:00 AM MST
- Discussion Initial Post / Publicación Inicial: Thursday, October 29, 2026, at 11:59 PM MST
- Discussion Peer Replies / Respuestas a Compañeros: Sunday, November 1, 2026, at 11:59 PM MST
- Lab Assignment & Wrap-Up Due / Entrega de Laboratorio: Monday, November 2, 2026, at 11:59 PM MST

### Course Learning Objectives (CLOs) / Objetivos de aprendizaje del curso

Upon successful completion of Module 11 workflows, you will demonstrate competency toward the following Course Learning Objectives (CLOs):

- CLO 1 (Pattern Recognition): Analyze glycemic regulation, insulin resistance, and metabolic syndrome indicators associated with diabetes and obesity. Analizar la regulación glucémica, resistencia a la insulina e indicadores de síndrome metabólico.
- CLO 2 (Rule Application): Apply PAGA 2018 metabolic standards, blood glucose pre-exercise safety thresholds, and hypoglycemia prevention rules. Aplicar normas metabólicas de PAGA 2018 y umbrales de seguridad de glucosa en sangre.
- CLO 3 (Problem Solving): Formulate an evidence-based metabolic conditioning prescription integrating caloric expenditure and carbohydrate management. Formular una prescripción de acondicionamiento metabólico integrando gasto calórico y manejo de carbohidratos.

### Build Your Own Journey • 3-Track Clinical Simulation Preview

In this Module's Discussion and Lab, you will work within your chosen career track:

Managing outpatient cardiac and metabolic rehabilitation for patients with insulin-dependent Type 2 diabetes requiring continuous glucose monitoring.

Designing community wellness center programs for older adults managing metabolic syndrome and prediabetes in Yuma.

Screening tactical personnel and first responders for metabolic risk factors and designing shift-work nutrition and activity protocols.


### Module 11 Learning Roadmap / Ruta de Aprendizaje

- Module Overview & Objectives (You are here!)
- Required Readings: Glycemic Regulation, Metabolic Syndrome & PAGA 2018 Standards
- Discussion Board: Blood Glucose Monitoring, Hypoglycemia Prevention & Prescriptive Safety
- Coaching Sprint: Applied Clinical Reasoning & Practical Coaching Drills
- Lab Assignment: Metabolic Exercise Prescription Audit & Gemini AI Tool Kit
- Summary & Wrap-Up: Knowledge Check & Transition to Module 12

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 11 (Mod 11 Overview: Diabetes, Weight Management & Low-Impact Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards. This layout is mobile-responsive, screen-reader verified, and designed for equitable access.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA, garantizando la accesibilidad para lectores de pantalla y dispositivos móviles.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 11 Visión General: Patologías Metabólicas y Endocrinas


### Bienvenido al Módulo 11: Diabetes Mellitus, Síndromes Metabólicos y Glucemia

¡Bienvenido a la Semana 11! Basándonos en nuestro marco pulmonar, esta semana examinamos las Patologías Metabólicas y Endocrinas y la Prescripción de Ejercicio . La diabetes y la obesidad presentan barreras fisiológicas debido a la alteración de la regulación de la glucosa y la resistencia a la insulina.

Utilizando nuestro marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) , identificarás patrones de compromiso metabólico, aplicarás las normas de PAGA 2018 y diseñarás intervenciones seguras de monitoreo glucémico.


### Objetivos de Aprendizaje del Curso (CLOs)

- CLO 1 (Patrón): Analizar la regulación glucémica, resistencia a la insulina e indicadores de síndrome metabólico.
- CLO 2 (Regla): Aplicar normas metabólicas de PAGA 2018 y umbrales de seguridad de glucosa en sangre.
- CLO 3 (Solución): Formular una prescripción de acondicionamiento metabólico integrando gasto calórico y carbohidratos.

### Construya su Propio Camino • Vista previa de las 3 rutas

En las actividades de este módulo, trabajará dentro de la ruta seleccionada:

Manejo de rehabilitación para pacientes con diabetes tipo 2 insulinodependiente requiriendo monitoreo continuo de glucosa.

Diseño de programas de bienestar para adultos mayores con síndrome metabólico y prediabetes en Yuma.

Tamizaje de personal táctico para factores de riesgo metabólico y diseño de protocolos de nutrición y actividad.


### Ruta de Aprendizaje del Módulo 11

- Visión General y Objetivos del Módulo (¡Está aquí!)
- Lectura Principal: Regulación Glucémica, Síndrome Metabólico y PAGA 2018
- Foro de Discusión: Glucemia, Prevención de Hipoglucemia y Seguridad
- Sprint de Entrenamiento: Razonamiento Clínico Aplicado y Práctica
- Práctica de Laboratorio: Auditoría Metabólica y Caja de Herramientas
- Comprobación de Conocimientos y Transición al Módulo 12

### Accesibilidad Universal y Diseño Universal para el Aprendizaje

Todos los materiales del curso en KIN-265 cumplen estrictamente con los principios del Diseño Universal para el Aprendizaje (UDL) y con los estándares de contraste WCAG 2.1 AA.

Servicios de Recursos AccessABILITY (ARS) | Edificio 3C del Campus de Yuma | (928) 344-7674 | Contacto: access@azwestern.edu


### Module 11 Checklist & Direct Links / Lista de Pasos y Enlaces Directos

In Plain English: Work through these steps in order. Click any link below to jump straight to that activity: En palabras sencillas: Avanza paso por paso en este orden. Haz clic en cualquier enlace para ir directo a la actividad:

- Step 1 — Read the Core Concepts (Paso 1 — Lectura Principal): Mod 11 Required Readings: Diabetes, Weight Management & Low-Impact Exercise →
- Step 2 — Join the Class Discussion (Paso 2 — Foro de Discusión): Mod 11 Discussion: Low-Impact Exercise for Obesity & Joint Comfort →
- Step 3 — Complete the Coaching Sprint (Paso 3 — Práctica Rápida): Mod 11 Coaching Sprint: Safe Meal & Insulin Timing Around Workouts →
- Step 4 — Submit the Applied Lab / Portfolio (Paso 4 — Laboratorio Aplicado): Mod 11 Lab: Diabetes & Weight Management Exercise Audit →
- Step 5 — Review Summary & Looking Ahead (Paso 5 — Resumen y Cierre): Mod 11 Summary & Wrap-Up: Diabetes, Weight Management & Low-Impact Exercise →
Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
