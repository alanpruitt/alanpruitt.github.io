# KIN-265: Mod 11 Lab And Simulation 02

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations / Ejercicio para Poblaciones Especiales


## Mod 11 Lab & Simulation: Diabetes & Weight Management Exercise Audit

Práctica de Laboratorio del Módulo 11: Prescripción de Ejercicio Metabólico y Auditoría

- Exogenous Insulin Peak & Exercise-Induced Hypoglycemia: Exercising during the peak action of rapid-acting insulin accelerates glucose clearance and suppresses hepatic glucose output; schedule workouts away from peak insulin or adjust carbohydrate intake per physician guidance. En palabras sencillas: Evitar hacer ejercicio justo en el pico máximo de acción de la insulina rápida para prevenir un bajón peligroso de azúcar (hipoglucemia).
- Pre-Exercise Blood Glucose Safety Gates (<100 mg/dL vs. >250 mg/dL): If glucose is <100 mg/dL, take 15–30 g fast-acting carbs first; if >250 mg/dL with ketones (or >300 mg/dL without ketones), postpone exercise and hydrate/seek medical care. En palabras sencillas: Si la glucosa está abajo de 100 mg/dL se toman 15–30 g de carbohidrato rápido antes de empezar; si pasa de 250 mg/dL con cetonas (o >300 mg/dL), se suspende el ejercicio.
- Joint Off-Loading & Peripheral Neuropathy Foot Inspection: In diabetes and obesity, use low-impact modalities (aquatic, recumbent bike) and inspect feet daily with proper footwear to prevent neuropathic ulcers. En palabras sencillas: Usar bicicleta reclinada o alberca para cuidar las articulaciones y revisar siempre los pies y el calzado cuando hay neuropatía diabética.
- KIN-265.11.1.AY26-27: Formulate a comprehensive metabolic risk audit and individualized Frequency, Intensity, Time, Type (FITT) prescription for special populations managing diabetes mellitus or metabolic syndrome. Formular una auditoría de riesgo metabólico y una prescripción FITT individualizada para poblaciones especiales con diabetes o síndrome metabólico.
- KIN-265.11.2.AY26-27: Execute the Clinical Framing Protocol (Pattern / Rule / Solve) and defend clinical safety parameters using delimiter-based AI auditing. Ejecutar el Protocolo de Encuadre Clínico (Patrón / Regla / Solución) y defender los parámetros de seguridad mediante auditoría de IA con delimitadores.

### Lab Overview: Metabolic Risk Audit & PAGA 2018 Prescription Formulation

In this laboratory practical, you will execute a comprehensive metabolic risk audit and formulate an evidence-based exercise prescription for a client presenting with Type 2 diabetes mellitus, metabolic syndrome, or prediabetes. You will apply the Clinical Framing Protocol (Pattern / Rule / Solve) framework anchored in federal standards ( PAGA 2018 ) and use the Gemini AI Tool Kit with secure triple-hash delimiters ( ### ) to audit your clinical safety.

En este laboratorio, ejecutará una auditoría de riesgo metabólico y formulará una prescripción FITT anclada en PAGA 2018 para diabetes o síndrome metabólico usando el Protocolo de Encuadre Clínico y delimitadores de IA.


### Lab Logistics & Deadlines / Logística y Fechas Límite

- Due Date / Fecha Límite: Monday, November 2, 2026, at 11:59 PM MST / Lunes 2 de noviembre de 2026 a las 11:59 PM MST
- Format / Formato: Direct Canvas Text Entry / Entrada de texto directa en Canvas
- Points / Puntos: 10/7/0 Mastery Scale (Exemplary / Competent / Recalibrate)
PAGA Physical Activity & Nutrition Tool Kit PWA ("PAGA" in Course Navigation • Open PAGA PWA ): Click "PAGA" in your left Canvas navigation bar or open Special Populations Case Coach • PAGA 2018 Ch. 5–6 PDF Lookup • Activity Audit • Relative Intensity (0–10 Scale) → Paste your ### delimited case or weekly log to run a Pattern / Rule / Solve audit and build your 4-part Canvas submission.

Optional Experimental Biometric & FITT Calculator ("Toolkit" in Course Navigation • https://exwtoolkit.com ): Follow Step 4: Safety Box (PAR-Q+ & Clinical Gates) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ("Copy for Canvas Submission") (optional experimental tool — verify all outputs against our course SSoT and share any feedback with Coach Alan).

Herramientas Digitales en el Menú Izquierdo ("PAGA" y "Toolkit"): Abra "PAGA" ( paga2018.dev → Case Coach para Poblaciones Especiales, Capítulos 5–6 PAGA 2018 y Activity Audit) para pegar su caso entre líneas ### y armar su entrega de 4 partes, o use "Toolkit" ( https://exwtoolkit.com → Step 4: Safety Box (Tamizaje Clínico) → 6. Cardio Box / 5. Strength Box → 9. Solve Box ) de forma experimental opcional verificando cada dato contra la Fuente de Verdad.


### Phase 1: Choose Your Clinical Simulation Track & Case Profile

Fase 1: Seleccione una de las tres rutas profesionales y su respectivo perfil de caso

Scenario: Outpatient clinical rehabilitation client managing insulin-dependent Type 2 diabetes with peripheral neuropathy and resting blood glucose of 168 mg/dL.

Scenario: Senior community participant with metabolic syndrome, prediabetes (fasting glucose 118 mg/dL), and mild obesity formulating a caloric expenditure plan.

Scenario: Law enforcement officer with early insulin resistance and shift-work metabolic disruption designing an adaptive conditioning plan.


### Phase 2: Gemini AI Simulation Workspace & Safety Auditor Protocol

Espacio de Simulación con IA (Gemini): Copie la plantilla y ejecute la auditoría en Gemini

Paste your chosen client profile wrapped in triple-hashes ( ### ) into Gemini, then paste this prompt directly below it:


### Phase 3: Canvas Text Box Submission Requirements

Requisitos de Entrega en el Cuadro de Texto de Canvas

Type or paste your complete metabolic risk audit directly into the Canvas text box structured under the following headers:

- Selected Career Track & Client Name: Declare your chosen track and client profile (David, Maria, or Officer Jackson).
- Part 1: Pattern Recognition (Metabolic Risk Audit): Detail resting blood glucose, insulin sensitivity, contraindications, and metabolic risk flags.
- Part 2: Rule Application (PAGA 2018 Standards): Detail aerobic and resistance FITT parameters, pre-exercise blood glucose screening rules (100–250 mg/dL thresholds), and rapid carbohydrate availability.
- Part 3: Solving the Gap (Active Verification & Safety Protocol): In a mandatory text defense (approx. 150-word minimum (150+ words)) written in your own clinical voice, justify why your exercise prescription, glycemic screening rules, and emergency stop limits protect client safety, stimulate GLUT4 glucose uptake, and align with PAGA 2018 guidelines. Detail your 3-phase progression and bilingual coaching cue card.
- Repository Verification: Confirm AI prompt exchange is saved to EXW_Professional_AI_Repository .

### Grading Rubric (10/7/0 Mastery Scale • Auditor Protocol)


### Official Student Exemplar (10/10 High-Fidelity Benchmark)

Selected Assessment: KIN-265 Module 11 Lab • Track 1 (David)

- Selected Career Track & Client Name: Track 1: Clinical Rehabilitation • David (Age 58). Goal: Establish a safe glycemic conditioning routine with pre-exercise glucose checks, low-impact loading, and acute hypoglycemia prevention.
- Part 1: Pattern Recognition (Metabolic Risk Audit): Glycemic Baseline: David presents with insulin-dependent Type 2 diabetes mellitus, resting blood glucose of 168 mg/dL, resting BP of 134/84 mmHg, and BMI of 31.4 kg/m². Risk Factors & Contraindications: Mild peripheral neuropathy elevates fall and foot ulceration risks. High-impact ballistic exercise is contraindicated due to sensory impairment. Exercise must be scheduled around exogenous insulin peak times to prevent acute exercise-induced hypoglycemia.
- Glycemic Baseline: David presents with insulin-dependent Type 2 diabetes mellitus, resting blood glucose of 168 mg/dL, resting BP of 134/84 mmHg, and BMI of 31.4 kg/m².
- Risk Factors & Contraindications: Mild peripheral neuropathy elevates fall and foot ulceration risks. High-impact ballistic exercise is contraindicated due to sensory impairment. Exercise must be scheduled around exogenous insulin peak times to prevent acute exercise-induced hypoglycemia.
- Part 2: Rule Application (PAGA 2018 Standards): Aerobic FITT: Frequency: 4-5 days/week (no more than 2 consecutive sedentary days to sustain insulin sensitivity). Intensity: Moderate (40-59% VO2R / 11-13 RPE on 6-20 scale). Time: Progressing from 20 to 35 minutes daily. Type: Non-weight-bearing cycle ergometer or recumbent stepper to protect neuropathic feet. Resistance FITT: Frequency: 2-3 non-consecutive days/week. Intensity: 60-70% 1RM (8-10 major muscle groups, 1-2 sets of 10-15 repetitions). Avoid Valsalva maneuver to safeguard vascular beds. Glycemic Safety Rules: Measure capillary glucose 15 minutes pre-exercise. If <100 mg/dL, consume 15-20g fast-acting carbohydrate before moving. If >250 mg/dL with ketones present, postpone exercise per PAGA 2018 guidelines. Always have rapid-acting carbohydrates immediately accessible.
- Aerobic FITT: Frequency: 4-5 days/week (no more than 2 consecutive sedentary days to sustain insulin sensitivity). Intensity: Moderate (40-59% VO2R / 11-13 RPE on 6-20 scale). Time: Progressing from 20 to 35 minutes daily. Type: Non-weight-bearing cycle ergometer or recumbent stepper to protect neuropathic feet.
- Resistance FITT: Frequency: 2-3 non-consecutive days/week. Intensity: 60-70% 1RM (8-10 major muscle groups, 1-2 sets of 10-15 repetitions). Avoid Valsalva maneuver to safeguard vascular beds.
- Glycemic Safety Rules: Measure capillary glucose 15 minutes pre-exercise. If <100 mg/dL, consume 15-20g fast-acting carbohydrate before moving. If >250 mg/dL with ketones present, postpone exercise per PAGA 2018 guidelines. Always have rapid-acting carbohydrates immediately accessible.
- Part 3: Solving the Gap (Active Verification & Safety Protocol): 3-Phase Progression: Phase 1 (Weeks 1-2): 20 min recumbent cycling at 40% VO2R + seated machine resistance to verify glycemic stability. Phase 2 (Weeks 3-4): Increase to 30 min at 50% VO2R and add multi-joint standing balance. Phase 3 (Maintenance): 150 min/week moderate aerobic + 2 days resistance. Active Verification: In my clinical reasoning, managing David's exercise prescription requires prioritizing metabolic safety over aggressive caloric expenditure. Because David uses exogenous insulin, muscle contractions stimulate GLUT4 translocation independently of insulin, creating a potent synergistic glucose uptake that can rapidly induce hypoglycemia. Relying on automated wearable calorie counters without pre-exercise capillary checks would expose him to neuroglycopenic shock. Under PAGA 2018 standards, maintaining glucose within the 100-250 mg/dL corridor and selecting non-weight-bearing recumbent cycling protects his neuropathic plantar tissues while systematically restoring glycemic control. Bilingual Coaching Cue Card: EN: "Always test your blood sugar before starting, keep quick-acting glucose close at hand, and enjoy smooth pedaling that builds lasting insulin sensitivity." ES: "Siempre revise su azúcar en sangre antes de comenzar, tenga glucosa de acción rápida a la mano y disfrute un pedaleo suave que construya sensibilidad a la insulina duradera."
- 3-Phase Progression: Phase 1 (Weeks 1-2): 20 min recumbent cycling at 40% VO2R + seated machine resistance to verify glycemic stability. Phase 2 (Weeks 3-4): Increase to 30 min at 50% VO2R and add multi-joint standing balance. Phase 3 (Maintenance): 150 min/week moderate aerobic + 2 days resistance.
- Active Verification: In my clinical reasoning, managing David's exercise prescription requires prioritizing metabolic safety over aggressive caloric expenditure. Because David uses exogenous insulin, muscle contractions stimulate GLUT4 translocation independently of insulin, creating a potent synergistic glucose uptake that can rapidly induce hypoglycemia. Relying on automated wearable calorie counters without pre-exercise capillary checks would expose him to neuroglycopenic shock. Under PAGA 2018 standards, maintaining glucose within the 100-250 mg/dL corridor and selecting non-weight-bearing recumbent cycling protects his neuropathic plantar tissues while systematically restoring glycemic control.
- Bilingual Coaching Cue Card: EN: "Always test your blood sugar before starting, keep quick-acting glucose close at hand, and enjoy smooth pedaling that builds lasting insulin sensitivity." ES: "Siempre revise su azúcar en sangre antes de comenzar, tenga glucosa de acción rápida a la mano y disfrute un pedaleo suave que construya sensibilidad a la insulina duradera."
- Repository Verification: AI Safety Auditor prompt exchange and FITT prescription archived in Google Drive: EXW_Professional_AI_Repository / EXW_265_M11_Lab_Metabolic.pdf

### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 11 (Mod 11 Lab: Diabetes & Weight Management Exercise Audit)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All course materials in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.2 AA contrast standards.

Español: Todos los materiales de KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.2 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Módulo 11 Lab: Prescripción de Ejercicio Metabólico y Auditoría

Práctica de Laboratorio del Módulo 11: Auditoría de Riesgo Metabólico y Prescripción FITT


### Visión General del Laboratorio: Auditoría de Riesgo Metabólico y PAGA 2018

En esta práctica de laboratorio, ejecutará una auditoría integral de riesgo metabólico y formulará una prescripción de ejercicio basada en evidencia para un cliente con diabetes tipo 2, síndrome metabólico o prediabetes. Aplicará el marco del Protocolo de Encuadre Clínico (Patrón / Regla / Solución) anclado en normas federales ( PAGA 2018 ) y usará la Caja de Herramientas Gemini con delimitadores seguros (###).


### Logística de Laboratorio y Fechas Límite

- Fecha Límite: Lunes 2 de noviembre de 2026 a las 11:59 PM MST
- Formato: Entrada de texto directa en Canvas
- Puntaje: Escala de Dominio 10/7/0 (Ejemplar / Competente / Recalibrar)

### Fase 1: Selección de Escenario de Simulación Clínica

Seleccione el caso para copiar sus datos en el prompt de IA:

Escenario: Cliente con diabetes tipo 2 insulinodependiente, neuropatía periférica leve y glucemia en reposo de 168 mg/dL.

Escenario: Participante senior con síndrome metabólico, prediabetes (glucemia 118 mg/dL) y obesidad grado 1.

Escenario: Oficial de policía con resistencia temprana a la insulina y alteración metabólica por turnos de trabajo.


### Fase 2: Espacio de Simulación Clínica con IA (Gemini)

Pegue los datos del cliente (envueltos en ###) en Gemini y copie este mensaje debajo:


#### Fase 3: Entrega en Canvas (Solo Texto)

- Ruta Seleccionada y Nombre del Cliente: Indique la ruta elegida y el perfil del cliente (David, Maria o Officer Jackson).
- Parte 1: Reconocimiento de Patrones (Auditoría de Riesgo Metabólico): Detalle la glucemia en reposo, sensibilidad a la insulina, contraindicaciones y riesgos metabólicos.
- Parte 2: Aplicación de Reglas (Normas PAGA 2018): Detalle parámetros FITT aeróbicos y de resistencia, reglas de glucosa previa (100–250 mg/dL) y disponibilidad de carbohidratos rápidos.
- Parte 3: Solución de Brechas (Verificación Activa y Protocolo de Seguridad): En una defensa de texto obligatoria (aprox. mínimo 150 palabras (150+ palabras)) escrita en su propia voz clínica, justifique por qué su prescripción FITT, reglas de glucemia y límites de parada protegen al cliente, estimulan la captación de glucosa por GLUT4 y cumplen con PAGA 2018. Incluya la progresión de 3 fases y la tarjeta de entrenamiento bilingüe.
- Verificación del Repositorio: Confirme el guardado en EXW_Professional_AI_Repository .

### Rúbrica de Calificación (Escala de Dominio 10/7/0)


### Modelo de Respuesta Ejemplar del Estudiante (10/10)

Evaluación Seleccionada: KIN-265 Módulo 11 Lab • Ruta 1 (David)

- Ruta Seleccionada y Nombre del Cliente: Ruta 1: Rehabilitación Clínica • David (58 años). Meta: Establecer una rutina de acondicionamiento glucémico segura con revisiones de glucosa previa, ejercicio de bajo impacto y prevención de hipoglucemia.
- Parte 1: Reconocimiento de Patrones (Auditoría de Riesgo Metabólico): Línea Base Glucémica: David presenta diabetes mellitus tipo 2 insulinodependiente, glucosa en reposo de 168 mg/dL, PA en reposo de 134/84 mmHg e IMC de 31.4 kg/m². Factores de Riesgo y Contraindicaciones: La neuropatía periférica leve eleva el riesgo de caídas y úlceras plantares. El ejercicio balístico de alto impacto está contraindicado. El ejercicio debe programarse lejos de los picos de insulina exógena para evitar hipoglucemia inducida por el ejercicio.
- Línea Base Glucémica: David presenta diabetes mellitus tipo 2 insulinodependiente, glucosa en reposo de 168 mg/dL, PA en reposo de 134/84 mmHg e IMC de 31.4 kg/m².
- Factores de Riesgo y Contraindicaciones: La neuropatía periférica leve eleva el riesgo de caídas y úlceras plantares. El ejercicio balístico de alto impacto está contraindicado. El ejercicio debe programarse lejos de los picos de insulina exógena para evitar hipoglucemia inducida por el ejercicio.
- Parte 2: Aplicación de Reglas (Normas PAGA 2018): FITT Aeróbico: Frecuencia: 4-5 días/semana (no más de 2 días sedentarios consecutivos para preservar la sensibilidad a la insulina). Intensidad: Moderada (40-59% VO2R / RPE 11-13). Tiempo: Progresar de 20 a 35 minutos diarios. Tipo: Bicicleta reclinada o escalador sentado para proteger los pies neuropáticos. FITT de Fuerza: Frecuencia: 2-3 días no consecutivos/semana. Intensidad: 60-70% 1RM (8-10 grupos musculares, 1-2 series de 10-15 repeticiones). Evitar la maniobra de Valsalva. Reglas de Seguridad Glucémica: Medir glucosa capilar 15 min antes del ejercicio. Si es <100 mg/dL, consumir 15-20g de carbohidratos de acción rápida. Si es >250 mg/dL con cetonas, posponer el ejercicio según PAGA 2018. Disponer siempre de carbohidratos accesibles.
- FITT Aeróbico: Frecuencia: 4-5 días/semana (no más de 2 días sedentarios consecutivos para preservar la sensibilidad a la insulina). Intensidad: Moderada (40-59% VO2R / RPE 11-13). Tiempo: Progresar de 20 a 35 minutos diarios. Tipo: Bicicleta reclinada o escalador sentado para proteger los pies neuropáticos.
- FITT de Fuerza: Frecuencia: 2-3 días no consecutivos/semana. Intensidad: 60-70% 1RM (8-10 grupos musculares, 1-2 series de 10-15 repeticiones). Evitar la maniobra de Valsalva.
- Reglas de Seguridad Glucémica: Medir glucosa capilar 15 min antes del ejercicio. Si es <100 mg/dL, consumir 15-20g de carbohidratos de acción rápida. Si es >250 mg/dL con cetonas, posponer el ejercicio según PAGA 2018. Disponer siempre de carbohidratos accesibles.
- Parte 3: Solución de Brechas (Verificación Activa y Protocolo de Seguridad): Progresión de 3 Fases: Fase 1 (Semanas 1-2): 20 min en bicicleta reclinada al 40% VO2R + fuerza sentado para confirmar estabilidad glucémica. Fase 2 (Semanas 3-4): Progresar a 30 min al 50% VO2R y equilibrio estático de pie. Fase 3 (Mantenimiento): 150 min/semana de cardio moderado + 2 días de resistencia. Verificación Activa: En mi criterio clínico, el manejo de David requiere priorizar la seguridad metabólica sobre el gasto calórico agresivo. Debido a la insulina exógena, la contracción muscular estimula la translocación de GLUT4 de manera independiente a la insulina, generando una captación sinérgica que puede inducir hipoglucemia rápida. Confiar en contadores automáticos de calorías sin verificación capilar previa expondría al paciente a un choque neuroglucopénico. Conforme a PAGA 2018, mantener la glucosa dentro del corredor de 100-250 mg/dL y seleccionar ciclismo reclinado protege sus tejidos plantares y restaura progresivamente el control glucémico. Tarjeta de Entrenamiento Bilingüe: EN: "Always test your blood sugar before starting, keep quick-acting glucose close at hand, and enjoy smooth pedaling that builds lasting insulin sensitivity." ES: "Siempre revise su azúcar en sangre antes de comenzar, tenga glucosa de acción rápida a la mano y disfrute un pedaleo suave que construya sensibilidad a la insulina duradera."
- Progresión de 3 Fases: Fase 1 (Semanas 1-2): 20 min en bicicleta reclinada al 40% VO2R + fuerza sentado para confirmar estabilidad glucémica. Fase 2 (Semanas 3-4): Progresar a 30 min al 50% VO2R y equilibrio estático de pie. Fase 3 (Mantenimiento): 150 min/semana de cardio moderado + 2 días de resistencia.
- Verificación Activa: En mi criterio clínico, el manejo de David requiere priorizar la seguridad metabólica sobre el gasto calórico agresivo. Debido a la insulina exógena, la contracción muscular estimula la translocación de GLUT4 de manera independiente a la insulina, generando una captación sinérgica que puede inducir hipoglucemia rápida. Confiar en contadores automáticos de calorías sin verificación capilar previa expondría al paciente a un choque neuroglucopénico. Conforme a PAGA 2018, mantener la glucosa dentro del corredor de 100-250 mg/dL y seleccionar ciclismo reclinado protege sus tejidos plantares y restaura progresivamente el control glucémico.
- Tarjeta de Entrenamiento Bilingüe: EN: "Always test your blood sugar before starting, keep quick-acting glucose close at hand, and enjoy smooth pedaling that builds lasting insulin sensitivity." ES: "Siempre revise su azúcar en sangre antes de comenzar, tenga glucosa de acción rápida a la mano y disfrute un pedaleo suave que construya sensibilidad a la insulina duradera."
- Verificación del Repositorio: Registro de auditoría de IA y prescripción guardados en Google Drive: EXW_Professional_AI_Repository / EXW_265_M11_Lab_Metabolic.pdf
KIN-265 • Module 11 Quick Return Navigation / Regreso Rápido al Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
