# KIN-265: Mod 11 Required Readings Diabetes Weight Management And Low Impact Exercise

**Academic Source of Truth (SSoT):** Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018)  
**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0 • $0 ZTC)

---

KIN-265 • Exercise for Special Populations


## Mod 11 Required Readings: Diabetes, Weight Management & Low-Impact Exercise


### In Plain English: Reading Navigation Guide

Before you read the details below, here is the short version: Managing Type 2 diabetes alongside obesity and joint pain requires pairing daily insulin-sensitizing movement with low-impact joint unloading. Breaking aerobic activity into bouts after meals blunts blood sugar spikes while water exercise, cycling, or walking protects knees and ankles. Never going more than 48 hours without physical activity keeps muscle glucose uptake switched on.


#### En Palabras Sencillas (Norteño Context)

Para cuidar tanto el azúcar como las rodillas, el secreto es moverse seguido sin golpear las articulaciones, no dejar pasar más de dos días sin actividad. Si los términos técnicos se ponen pesados, concéntrate primero en la regla de no pasar más de 48 horas sin ejercicio y proteger los pies y articulaciones.


### Core Literature & Federal Standards (SSoT)

To successfully complete Module 11 workflows, discussions, and laboratory assignments, review the core readings below. All instructional materials are anchored strictly in our Single Source of Truth (SSoT): the Physical Activity Guidelines for Americans (PAGA 2018, 2nd Ed.) .

Review the reading summaries below to understand how exercise helps control blood sugar, what safety checks are needed before working out, and how to keep clients safe in Yuma's desert heat.


### Reading 1: PAGA 2018 (2nd Ed.) • How Exercise Helps Control Blood Sugar

Learn how muscle movement acts like an open door for glucose without needing extra insulin. When muscles contract during exercise, they trigger natural cell pathways that pull sugar out of the bloodstream to use as energy. This effect keeps blood sugar lower and improves insulin sensitivity for up to 48 hours after a workout. Following the PAGA 2018 weekly activity goals (like 150 to 300 minutes of moderate activity plus strength training) is one of the best ways to manage Type 2 diabetes.

Lectura 1: PAGA 2018 (2.ª ed.) • Cómo el ejercicio ayuda a controlar el azúcar en sangre: Aprenda cómo el movimiento muscular ayuda a absorber el azúcar de la sangre sin depender únicamente de la insulina.


### Reading 2: Clinical Guidelines • Checking Blood Sugar Before You Start

Examine pre-exercise blood glucose screening rules and safety limits. Trainers must check blood sugar levels before starting a session: if a client's blood sugar is below 100 mg/dL, they need a small snack to prevent dangerous low blood sugar (hypoglycemia) during exercise. If blood sugar is over 250 mg/dL with ketones present, exercise must be postponed. Trainers also need to watch for nerve numbness (neuropathy) to protect clients' feet during workouts.

Lectura 2: Pautas clínicas • Verificación de la glucosa antes de empezar: Examine las reglas de evaluación de la glucosa y los límites de seguridad para prevenir la hipoglucemia.


### Reading 3: Environmental Physiology & Staying Safe in Yuma's Heat

Analyze how extreme desert heat affects the body when managing metabolic conditions. In Yuma's hot climate, the body has to send extra blood to the skin to cool off. This extra stress forces the heart to work harder and can mix dangerously with dehydration. Because heat and dehydration can throw off blood sugar levels, workouts for clients with diabetes should take place in air-conditioned indoor facilities (72°F / 22°C) with plenty of water breaks.

Lectura 3: Fisiología ambiental • Cómo mantenerse seguro con el calor de Yuma: Analice cómo el calor extremo afecta al cuerpo y por qué es importante entrenar en instalaciones con clima controlado.


### In Plain English • Optional EXW Digital Tool Kit ( exwtoolkit.com ) & Feedback (Modules 10–16)

Before you read the details below, here is the short version: Starting in Module 10 of Fall 2026, you have the option to experiment with the new EXW Digital Tool Kit ( https://exwtoolkit.com ) —including the Safety Box (contraindications), Biometrics Box, Cardio Box (RPE/Talk Test), Strength/Flexibility Boxes, and Solve Box —on an experimental basis if needed. Using the toolkit is completely optional this semester: if you try it out, please share any feedback, usability notes, or suggestions directly with Coach Alan (via Canvas Inbox or in your SpeedGrader submission comments). Student Verification Rule: Whenever you use the toolkit on an experimental basis, you are 100% responsible for verifying all toolkit outputs against our KIN-265 Academic Source of Truth (Physical Activity Guidelines for Americans (PAGA), 2nd Edition (2018), Chapters 5 & 6) during your Pattern / Rule / Solve audit and Part 3: Active Verification .

En Palabras Sencillas (Contexto Norteño) • Opción Experimental (Módulos 10–16): A partir del Módulo 10 de Otoño 2026, tienes la opción de experimentar con el nuevo Kit de Herramientas Digitales EXW ( https://exwtoolkit.com ) (incluyendo Safety Box (contraindicaciones), Biometrics Box, Cardio Box (RPE/Prueba del Habla), Strength/Flexibility Boxes y Solve Box ) de manera experimental si lo necesitas. Su uso es totalmente opcional este semestre: si decides probarlo, te invitamos a enviar cualquier comentario o sugerencia directamente al Coach Alan por la Bandeja de Entrada (Inbox) o en tus comentarios de entrega. Regla de Verificación del Estudiante: Si usas la herramienta de forma experimental, tú eres 100% responsable de verificar todos los resultados contra la Fuente Académica de Verdad de KIN-265 (Guías de Actividad Física para los Estadounidenses (PAGA), 2.ª Edición (2018), Capítulos 5 y 6) en tu análisis Patrón / Regla / Solución y tu Parte 3: Verificación Activa .


### Interactive Clinical Simulation & Outcome Gate (Module 11) / Simulación Clínica y Dominio de Resultados (Módulo 11)

Process Over Product (Clinical Framing Protocol): Every resident analysis, discussion defense, and lab submission in KIN-265 Module 11 is evaluated against the three-step clinical reasoning trail: Pattern (diagnosing the Yuma / Imperial Valley client context, environmental heat stressors, and vitals) → Rule (applying the Academic Source of Truth: ACSM 12th Ed. (Guidelines for Exercise Testing and Prescription) & PAGA 2018 ) → Solve (formulating an evidence-based clinical intervention and safe exercise/nutrition prescription in your own voice).

Proceso Sobre Producto ( Patrón / Regla / Solución ): Cada análisis, defensa en el foro y entrega de laboratorio en el Módulo 11 de KIN-265 se evalúa bajo la ruta de razonamiento clínico: Patrón (Pattern: diagnosticar el caso en Yuma / Valle Imperial y signos vitales) → Regla (Rule: aplicar la Fuente Académica de Verdad: ACSM 12th Ed. (Guías para Pruebas de Ejercicio y Prescripción) y PAGA 2018 ) → Solución (Solve: formular una intervención clínica segura y una prescripción práctica con tu propia voz).


```text
###CASE_DATA_START###
Course & Module: KIN-265 • Module 11 (Mod 11 Required Readings: Diabetes, Weight Management & Low-Impact Exercise)
Clinical Framing Trail: Pattern (Yuma / Imperial Valley Context & Vitals) -> Rule (ACSM 12th Ed. | PAGA 2018) -> Solve (Clinical Intervention & Prescription)
FERPA & Active Verification Boundary: Verified de-identified clinical simulation record (10 / 7 / 0 Mastery Scale).
###CASE_DATA_END###
```


### Universal Design & Accessibility / Accesibilidad Universal

English: All required reading texts in KIN-265 adhere strictly to Universal Design for Learning (UDL) principles and WCAG 2.1 AA contrast standards.

Español: Todos los textos de lectura obligatoria en KIN-265 cumplen con los principios de UDL y los estándares WCAG 2.1 AA.

AccessABILITY Resource Services (ARS) | Yuma Campus 3C Building | (928) 344-7674 | Contact: access@azwestern.edu

KIN-265 • Ejercicio para Poblaciones Especiales


## Lecturas Obligatorias del Módulo 11: Control del Azúcar en Sangre y Salud Metabólica


### Literatura Principal y Normas Federales (SSoT)

Para completar con éxito las actividades del Módulo 11, revise los resúmenes de lectura a continuación, anclados en nuestra Fuente Única de Verdad (SSoT): las Pautas de Actividad Física para los Estadounidenses (PAGA 2018, 2.ª ed.) .

Revise los puntos clave sobre cómo el ejercicio ayuda a controlar el azúcar, las reglas de evaluación previa y la seguridad ante el calor.


### Lectura 1: PAGA 2018 (2.ª ed.) • Cómo el ejercicio ayuda a controlar el azúcar en sangre

Aprenda cómo el movimiento muscular ayuda a absorber el azúcar de la sangre sin depender únicamente de la insulina. Seguir las metas de actividad de PAGA 2018 ayuda a manejar la diabetes tipo 2.


### Lectura 2: Pautas clínicas • Verificación de la glucosa antes de empezar

Examine las reglas de evaluación de la glucosa. Si el azúcar está por debajo de 100 mg/dL, se necesita un bocadillo; si está por encima de 250 mg/dL con cetonas, se debe posponer el ejercicio.


### Lectura 3: Fisiología ambiental • Cómo mantenerse seguro con el calor de Yuma

Analice cómo el calor extremo afecta al cuerpo y por qué es importante entrenar en instalaciones con clima controlado (22°C) para proteger la salud metabólica.

KIN-265 • Module 11 Next Steps (Apply What You Read) / Próximos Pasos del Módulo 11:

Curriculum Architect: Coach Alan Pruitt • Wellness & Physical Education Digital Infrastructure • Arizona Western College (Yuma Campus)

This curriculum and instructional framework are licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0) .

Usted es libre de compartir y adaptar este material educativo abierto (OER) con atribución a Coach Alan Pruitt y Arizona Western College, para fines no comerciales y bajo la misma licencia (CC BY-NC-SA 4.0).
